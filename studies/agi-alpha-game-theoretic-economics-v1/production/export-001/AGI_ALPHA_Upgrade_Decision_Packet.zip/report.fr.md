# Votre décision de mise à niveau

**Conservez le verrou actuel de l'application native. Ces preuves des composants peuvent servir à la qualification complète suivante.**

Les 61 exigences déclarées ont réussi avant et après le changement. Le chemin FastAPI d'origine et le délai réel de 15 secondes ont été vérifiés dans les observations consignées par le chercheur.

Ce produit revérifie les observations consignées. Il n'exécute pas le code des composants ni l'application.

## Versions examinées

| Dépendance | Avant | Après |
|---|---|---|
| starlette | 1.7.0 | 1.10.0 |
| anyio | 4.15.1 | 4.15.1 |
| pydantic | 2.13.5 | 2.14.1 |
| pydantic-core | 2.46.5 | 2.50.1 |
| annotated-types | 0.8.0 | 0.8.0 |
| typing-extensions | 4.16.0 | 4.16.0 |
| typing-inspection | 0.4.4 | 0.4.4 |
| idna | 3.20 | 3.20 |
| fastapi | 0.141.1 | 0.141.1 |
| annotated-doc | 0.0.5 | 0.0.5 |

## Ce qui est établi

- Encadrement et taille des requêtes, origine, déconnexion, délai d'expiration réel et octets transmis.
- En-têtes de sécurité déclarés.
- Validation stricte et sérialisation complète des entrées Mission, Review et Control sélectionnées.

## Votre prochaine action

1. Décider si cette mise à niveau est nécessaire.
2. Réconcilier et qualifier l'ensemble des dépendances et plateformes de l'application.
3. Faire exécuter les contrôles autorisés d'authentification, de persistance et de mission complète.
4. Obtenir la revue des responsables et les contrôles requis avant toute adoption.

## Preuves et limites

Un seul dossier interne de développement, pas 61 clients ni une preuve universelle. L'acceptation par un client et l'adoption opérationnelle ne sont pas établies.

- [Source 1](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/blob/804e1afeb78ea48fb4807d76b336803aa0906a20/alpha_factory_v1/core/runtime/api.py)
- [Source 2](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/blob/804e1afeb78ea48fb4807d76b336803aa0906a20/alpha_factory_v1/core/runtime/models.py)
- [Source 3](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/blob/804e1afeb78ea48fb4807d76b336803aa0906a20/tests/runtime/test_api_boundary.py)

research/ contient les fichiers originaux et leur manifeste. componentChecks dans decision-record.json conserve la nouvelle revérification. Aucun original n'est réécrit.

## Coût complet

Coûts monétaires marginal, récurrent et complet : inconnus. Prix et minutes client/opérateur : inconnus. Paiements clients observés : zéro. Surplus disponible : inconnu. Les ressources mesurées, les échecs et les coûts non mesurés restent distincts.

automated-costs.json · cost-analysis.json · ledger.json · ledger-analysis.json · checksums.json
