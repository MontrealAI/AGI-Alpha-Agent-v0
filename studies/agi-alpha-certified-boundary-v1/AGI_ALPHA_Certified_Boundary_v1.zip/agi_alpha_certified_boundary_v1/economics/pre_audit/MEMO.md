# Economic scope: reproducibility and review of one existing certificate

## Conclusion

This study establishes a checkable mathematical research artifact. It does **not** establish a sale, demand, a repeatable supply of solved open problems, or observed enterprise profit. Actual customers, recognized revenue and cash receipts are all zero. Complete actual study cost and actual profit remain unknown because authoring, frontier-model and infrastructure bills were not supplied.

The executable model evaluates a narrowly defined possible service: reproduce, independently review, package and integrate **this fixed existing certificate**, with a one-year response and maintenance commitment. It never prices a promise to solve a future open problem. All fees are sensitivity inputs. Labor hours are human-resource planning or replacement estimates, not observed agent time or evidence of willingness to pay. There is no assertion that a market will buy mathematical findings at these amounts.

## Scope and acceptance

A beneficiary could be a research group, foundation, mathematical software organization or publisher requiring an independently reviewable exact certificate and integration assistance. This describes possible beneficiaries; none was contacted. The deliverable contains the original problem definition, frozen rational witness, two independently implemented checkers, analytic reductions, failed-candidate record, source attribution, documented reproduction and integration within the beneficiary's agreed environment. Acceptance requires the checks to pass and the stated scope to survive qualified human review. External peer review is pending. The model includes a correction allowance rather than assuming flawless first delivery.

No exclusive ownership of the theorem or problem is sold. The proof artifact can be read and checked independently. Fees, if agreed, would buy scoped professional work and commitments. Buyers must accept a shared core review, nonexclusive access and compatible requirements for the joint cost figures to apply. Extra exclusivity, divergent environments, legal terms or extensive new research require separate pricing. Source licenses, attribution and rights must be preserved. No token issue, token appreciation, customer deposit or financing principal is operating revenue.

## Complete central resource estimate

The central model includes 110 fixed human hours: discovery including failed search (24), certificate construction and repair (18), independent mathematical review (20), publication/reproduction packaging (12), correction (12), oversight and rights (6), acquisition and coordination (10), and shared maintenance (8). Rates are explicit analyst assumptions of $90--$140 per hour. These are professional service resource estimates, not hourly wage quotes. Overhead of 20% covers general business administration, tools, insurance and unallocated support; the same items are not charged again elsewhere. Fixed compute and storage allowances are $360. Fixed cost is $15,168.

Each beneficiary adds 10.5 hours for integration, acceptance checking, onboarding, support and correction, plus overhead and a $40 compute/distribution allowance: $1,426 per beneficiary. Processing fees are 3% of collected fees. One-year expected support and maintenance are already in these costs. A further cash reserve equal to 5% of earned revenue is an encumbrance for adverse obligations, not a second expense. All figures are pre-tax; pass-through sales taxes, if applicable, would be excluded from revenue. Actual tax treatment requires the eventual contract and jurisdiction.

Discovery and certificate construction, including the fixed compute allowance, total $5,844 in the central estimate and are counted **once**. The model separately reports delivery operating surplus before this development allocation and full-project profit including it. This distinction is a managerial view, not a claim about statutory R&D accounting. Because the artifact already exists, a forward-looking release decision may exclude sunk costs; that does not establish that the complete historical project was profitable.

## Three deterministic scenarios

| Scenario | Prospective buyers | Assumed fee each | Conditional revenue | Complete project cost | Full-project profit | Break-even fee at stated count | Added cash needed above $5,000 initial capital |
|---|---:|---:|---:|---:|---:|---:|---:|
| Favorable | 5 | $6,000 | $30,000 | $14,001.73 | $15,998.27 | $2,701.39 | $2,202.50 |
| Central | 4 | $6,000 | $24,000 | $21,592.00 | $2,408.00 | $5,379.38 | $6,573.20 |
| Adverse | 2 | $6,000 | $12,000 | $31,968.80 | **−$19,968.80** | $16,293.20 | $18,880.80 |

The favorable scenario uses 65% of central hours and 90% of central rates. The adverse uses 160% of hours and 110% of rates. These are transparent sensitivity ranges, not calibrated probability distributions or measured productivity changes. Counts vary to expose participation risk. A fixed-demand grid in `fee_participation_grid.csv` separately varies one to twelve buyers and eight fees under unchanged central costs. No probability, expected commercial value or market valuation is inferred from the scenarios.

For fixed cost F, marginal delivery cost v, price p, processing fraction q and buyer count N, full-project profit is N[p(1−q)−v]−F. The fee threshold is (F/N+v)/(1−q); the participant threshold is ceil(F/[p(1−q)−v]) when the denominator is positive. At $6,000, central break-even requires four accepted, paying beneficiaries; three leave a loss of $1,986. Under adverse resource costs, the same fee requires nine buyers. Those thresholds do not imply that the buyers exist.

`conditional_participation_discounts.csv` tests illustrative fees of $18,000, $10,000, $6,000, $4,800 and $4,000 at committed group sizes one, two, four, six and eight. Central full-project profits are respectively $866, $1,380, $2,408, $4,212 and $4,464. This is a transparent participation-sensitive schedule, not an optimized price or market offer. A value-based price would require evidence of the beneficiary's avoided review work, avoided invalid reliance, integration value and willingness to pay. None was measured. The resource floor and the unknown customer value remain separate.

## Profit does not supply the required cash

The stage ledger begins with exactly $5,000 of assumed unrestricted capital. Buyers place 40% refundable deposits; these stay restricted and unearned until core acceptance. Another 30% is collected at core acceptance and 30% at final acceptance. The illustrative cost schedule pays or prepays 25% of fixed costs before contracting; another 40% plus 25% of beneficiary costs before core acceptance; and the remainder before final acceptance, including prepaid maintenance commitments. The purpose is to expose timing requirements. Negative unfinanced balances are **counterfactual funding gaps**, not permissions to spend restricted deposits or records of actual transfers. Work must stop at the first funding gap unless lawful unrestricted financing is committed.

Central full-project profit is positive, yet the project requires **$6,573.20 of additional unrestricted funding** before core acceptance. It is therefore conditionally profitable but underfunded on the stated schedule. At that checkpoint, gross account cash would be $3,026.80 against $9,600 of refundable deposit liabilities; the apparent balance is unavailable for operating use. If all sponsors cancel before acceptance, the $9,600 is refundable in full; modeled unrecovered cost is $11,573.20, including nonrefundable payment fees. The refund retires a liability; it is not an invented operating expense or negative sale.

The model also evaluates a strictly hypothetical 90-day bridge with a 2% fee withheld and 12% simple annual interest. Gross principal must be $6,707.35 to make $6,573.20 available after the fee. Total finance cost is $335.37, leaving central full-project profit of $2,072.63. No lender offer or availability was verified. Financing does not repair the adverse economic loss. An alternative is an earlier, separately accepted and earned milestone for a useful part of the existing dossier; its acceptance and payment must be negotiated, not assumed, and an unearned refundable deposit cannot be relabeled as income.

## Enterprise complementarity and the strongest shared comparator

`arrangements.csv` separates five arrangements. The executed finite MILP attempts produce useful finite evidence but fail the all-n acceptance requirement. Commercial coordination alone does not change that failure. The exact certificate satisfies the digital mathematical acceptance checks. A single $6,000 sponsor does not fund the central complete project; four compatible sponsors can share fixed review and publication costs. An equally capable conventional shared arrangement with the **same artifact, information, reviewers, permissions, buyer assumptions, prices and commitments has exactly the same scientific outcome and economic numbers**.

The supported coordination mechanism is ordinary fixed-cost sharing. No exclusive technical-commercial interaction, game-theoretic optimum or AGI-specific commercial Alpha is established. A factorial commercial effect is not estimated because the finite-MILP arms fail the requested universal deliverable and therefore do not supply comparable accepted products. Their costs are not fabricated to manufacture an interaction. The useful scientific distinction is the universal certificate; the economic premise remains conditional sponsorship.

## Retention decision

Keeping the frozen proof and checker in an ordinary library preserves the useful result. A separately packaged specialist skill is estimated to add $1,042 for extraction ($330), additional validation ($280), integration ($220), one-year upkeep ($200) and storage ($12). No incremental benefit over a competent agent given the same ordinary-library asset has been measured. The planning model therefore admits zero benefit and recommends **HOLD** on paid specialist extraction; it does not assert a measured zero capability effect. Future retention requires fresh-task evidence and positive net benefit after these additional costs. Discovery already paid for is not charged a second time.

## Reproduction and decision

Run `python3 economics/model.py` from the package root. It writes JSON plus CSV scenarios, activity costs, the funding ledger, the fixed-assumption fee/count grid, conditional discounts and arrangements. The model uses exact rational accounting internally, with four-decimal output for inspection. Financial figures should be communicated to the nearest dollar or cent rather than treated as forecast precision.

The smallest commercial next step is an authorized, scoped willingness-to-pay and acceptance interview with a plausible sponsor, followed by an actual resource quote and milestone terms. No such contact has been made. The smallest scientific next step is external expert review of the original problem scope and exact proof. Scientific acceptance and buyer acceptance remain distinct gates.
