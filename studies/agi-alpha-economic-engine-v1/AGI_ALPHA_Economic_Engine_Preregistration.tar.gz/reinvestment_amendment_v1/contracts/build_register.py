# SPDX-License-Identifier: Apache-2.0
"""Rebuild the read-only source inventory; does not evaluate financial scenarios."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parent.parent


def read(path: str):
    return json.loads((ROOT / path).read_text(encoding="utf-8"))


def write(path: str, value):
    (ROOT / path).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


IDS = {
    ("AGI-Alpha-Agent-v0", "contracts/ascension/AscensionAccess.sol"): "alpha_access",
    ("AGI-Alpha-Agent-v0", "contracts/ascension/NovaSeed.sol"): "alpha_seed",
    ("AGI-Alpha-Agent-v0", "contracts/ascension/AscensionRiskOracle.sol"): "alpha_oracle",
    ("AGI-Alpha-Agent-v0", "contracts/ascension/AscensionJobMarket.sol"): "alpha_market",
    ("AGI-Alpha-Agent-v0", "contracts/ascension/AscensionMark.sol"): "alpha_mark",
    ("AGI-Alpha-Agent-v0", "contracts/ascension/AscensionToken.sol"): "alpha_token",
    ("AGI-Alpha-Agent-v0", "contracts/v2/Constants.sol"): "alpha_constants",
    ("AGI-Alpha-Agent-v0", "docs/agent/SUCCESSOR_ALPHA.md"): "alpha_guide",
    ("AGI-Alpha-Agent-v0", "docs/agent/SUCCESSOR_ALPHA_DEPLOYMENT.md"): "alpha_deployment_guide",
    ("AGI-Alpha-Agent-v0", "examples/successor-alpha/deployment.json"): "alpha_deployment_example",
    ("AGI-Alpha-Agent-v0", "docs/agent/CURRENT_MAINNET_DEPLOYMENT.md"): "alpha_current_deployment_guide",
    ("AGI-Alpha-Agent-v0", "docs/deployments/2026-10-18/manifest.json"): "alpha_historical",
    ("AGI-Alpha-Agent-v0", "tests/contracts/README.md"): "alpha_tests_guide",
    ("AGI-Alpha-Agent-v0", "tests/contracts/test/ascension/settlement.test.js"): "alpha_settlement_test",
    ("AGI-Alpha-Agent-v0", "tests/contracts/test/ascension/lifecycle.test.js"): "alpha_lifecycle_test",
    ("AGIJobManager", "contracts/AGIJobManager.sol"): "manager",
    ("AGIJobManager", "contracts/utils/JobSettlement.sol"): "manager_settlement",
    ("AGIJobManager", "README.md"): "manager_readme",
    ("AGIJobsv0", "contracts/v2/FeePool.sol"): "jobs_fee",
    ("AGIJobsv0", "contracts/v2/implementation/StakeManagerBase.sol"): "jobs_stake_base",
    ("AGIJobsv0", "contracts/v2/implementation/JobRegistryBase.sol"): "jobs_registry_base",
    ("AGIJobsv0", "contracts/v2/implementation/StakeManagerEscrow.sol"): "jobs_escrow",
    ("AGIJobsv0", "README.md"): "jobs_readme",
    ("AGI-Fleet-Linux", "README.md"): "fleet_readme",
}


def main():
    records = read("ALPHA_SOURCE_SNAPSHOTS.json") + read("REMOTE_SOURCE_SNAPSHOTS.json") + read("REMOTE_SOURCE_ADDITIONS.json")
    seen, sources = set(), []
    for record in records:
        r = dict(record)
        key = (r["repository"].split("/")[-1], r["path"])
        if key in seen:
            raise ValueError(f"Duplicate source: {key}")
        seen.add(key)
        r["id"] = r.get("id") or IDS[key]
        raw = (WORKSPACE / r["local_path"]).read_bytes()
        git_blob = hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
        if git_blob != r["git_blob_sha"]:
            raise ValueError(f"Git blob mismatch: {key}")
        r.update(sha256=hashlib.sha256(raw).hexdigest(), bytes=len(raw), lines=len(raw.splitlines()), git_blob_verified=True)
        r["snapshot_path"] = str(Path(r["local_path"]).relative_to("reinvestment_amendment_v1/contracts"))
        if "test/" in r["path"] or "tests/" in r["path"]:
            r["evidence_class"] = "TEST_SOURCE_OR_GUIDANCE_NOT_EXECUTED_THIS_AMENDMENT"
        elif r["path"].endswith(".sol"):
            r["evidence_class"] = "SOURCE_IMPLEMENTATION_INSPECTED_NOT_EXECUTED_THIS_AMENDMENT"
        elif r["id"] in {"alpha_historical", "alpha_deployment_example", "manager_historical", "jobs_historical"}:
            r["evidence_class"] = "REPORTED_HISTORICAL_DEPLOYMENT_NOT_INDEPENDENTLY_REVERIFIED"
        elif r["path"].startswith("config/"):
            r["evidence_class"] = "CONFIGURATION_SOURCE_NOT_CURRENT_ONCHAIN_STATE"
        else:
            r["evidence_class"] = "PINNED_PROJECT_DOCUMENTATION"
        sources.append(r)
    sources.sort(key=lambda r: r["id"])
    alpha = {r["path"]: r for r in sources if r["repository"] == "MontrealAI/AGI-Alpha-Agent-v0"}
    prior = read("ALPHA_DEPLOYED_SOURCE_DIRECTORY.json")
    comparison = [{"path": r["path"], "reported_deployed_source_blob": r["git_blob_sha"], "current_source_blob": alpha[r["path"]]["git_blob_sha"], "equal": r["git_blob_sha"] == alpha[r["path"]]["git_blob_sha"]} for r in prior["files"]]
    write("ALPHA_SOURCE_COMPARISON.json", {
        "schema": "agi-alpha-contract-file-identity-comparison-v1",
        "current_commit": "f836f06e8351e64db1da770e16e304b5feb01f28",
        "reported_deployed_source_commit": prior["commit"],
        "retrieved_date": "2026-10-25",
        "scope": "Five named Ascension contracts plus shared token helper, six source files only. Not a compiler/dependency/bytecode comparison, RPC read, security audit or activation approval.",
        "files": comparison,
        "all_six_source_files_equal": all(r["equal"] for r in comparison),
    })
    write("SOURCE_REGISTER.json", {
        "schema": "agi-alpha-reinvestment-contract-source-register-v1",
        "inspection_date": "2026-10-25",
        "repository_pins": read("REPOSITORIES.json"),
        "method": "Read-only public GitHub commit-pinned source/config/documentation inspection. Local copies authenticated against Git blob SHA and SHA-256. Existing Alpha checkout read by exact Git object; other files fetched through the public GitHub connector. No contract execution, RPC, wallet access, signing, provider invocation, deployment or state mutation.",
        "financial_scenario_evaluations": 0,
        "fresh_contract_test_executions": 0,
        "independent_live_chain_validations": 0,
        "source_count": len(sources),
        "sources": sources,
    })
    print(f"Source register: {len(sources)} Git blobs verified; six-file Alpha comparison: {all(r['equal'] for r in comparison)}")


if __name__ == "__main__":
    main()
