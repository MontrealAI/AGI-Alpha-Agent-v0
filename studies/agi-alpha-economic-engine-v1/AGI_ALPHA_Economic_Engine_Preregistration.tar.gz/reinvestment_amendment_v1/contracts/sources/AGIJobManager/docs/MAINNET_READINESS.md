# v1.20.2 Discovery qualification and operating boundaries

The v1.20.0 Discovery candidate adds source-pinned synthetic campaign admission under a new versioned release profile. It retains the published v1.19.6 dependency repairs and historical guards. Final-source hosted qualification and publication remain pending for this candidate; neither authorizes deployment or intake. Candidate building and source authentication require the exact pinned external Alpha checkout. Installed native inspection uses the Alpha source capsule included in the complete Manager archive.

The retained v1.19.5 source adds [free native transformation-campaign inspection](successor/TRANSFORMATIONAL_WORK.md) and a separate finite source policy. The native pilot has zero currency allowances; positive paid proposals remain unsupported. Its [validation record](releases/v1.19.5/VALIDATION.md) distinguishes local checks from pending exact-final-source qualification. This adapter changes no deployed contract, intake setting, Builder code pin, compiler behavior or dependency resolution. It does not establish independent review or live readiness.

Latest deployment: see the [17 October Manager record](deployments/MAINNET_MANAGER_2026-10-17.md) for the reported nine finalized creations, mixed explorer-match results, governor/moderator and paused/unlocked configuration. This dated evidence does not establish current full readiness or paid-intake approval.

Latest retained configuration: the [19 October ENS addendum](deployments/ENS_CONFIGURATION_RETAINED_2026-10-19.md) records helper `0xBaC826CF5f169EA168A23173F3DbBdA7Ed953400`, root `usdc.jobs.agi.eth` and prefix `job-v2-` at block `26,227,598` (`2026-10-19T15:44:23Z`). Its 27 state comparisons pass; its fee-ceiling exception and separate unresolved explorer source-input match remain explicit. The block timestamp is separately established historical metadata, not a new current-state readback or the original checker's unknown observation time.

Version 1.19.4 is a prepared software correction for hidden creator-key input, public-only mission validation, recoverable Computer Use history and separately priced unsigned USDC proposals. Disposable acceptance executes captured native-inspector code; software and Pages publication require exact-source qualification. See the [prepared v1.19.4 release notes](releases/v1.19.4/RELEASE_NOTES.md) and [v1.19.4 preparation snapshot](releases/v1.19.4/START_HERE.md). These guides are not qualification receipts: all eight final-source workflows, external `QUALIFICATION.json` and the publication workflow must bind the final release source. The correction preserves Solidity, compiler behavior and dependency resolutions from the published v1.19.3 wrapper. Existing deployments remain read-only within this work; deployment, signing, funding, activation and authority changes require separate authorization.

The historical [v1.19.3 release](https://github.com/MontrealAI/AGIJobManager/releases/tag/v1.19.3) corrected operator guidance and deployment-evidence presentation around integrated source `8815ed3181778664595f951befd672afbd7a9352`, tree `913e49d65263bc53026916f7fc3b4cbfb93549f8`. That source includes explicit-governor constructors, source-bound creator recovery and the selected compiler optimizer mitigation. Its [historical release notes](releases/v1.19.3/RELEASE_NOTES.md) and [reported mainnet snapshot](releases/v1.19.3/START_HERE.md), the earlier [v1.19.2 release](https://github.com/MontrealAI/AGIJobManager/releases/tag/v1.19.2) and dated deployment evidence retain their original identities. Earlier source workflows cannot qualify the v1.19.4 wrapper.

**v1.17.0 software qualification passed; deployment and activation approval remain separate.** Published [v1.17.0](https://github.com/MontrealAI/AGIJobManager/releases/tag/v1.17.0) binds source `b721819639668f0074c244d516bbbe0cf57329a7` to its `QUALIFICATION.json` and final-source [contract CI](https://github.com/MontrealAI/AGIJobManager/actions/runs/38672184215), [security verification](https://github.com/MontrealAI/AGIJobManager/actions/runs/38672184298) and [native-USDC/ENS fork qualification](https://github.com/MontrealAI/AGIJobManager/actions/runs/38672184202). These results include the [ENS membership correction](qualification/ENS_MEMBERSHIP_REVOCATION.md), which changes linked library bytecode and requires a new deployment. They do not establish an independent final-source audit, an actual-owner Sepolia rehearsal or readiness of a live instance. Complete the [second-deployment release checklist](DEPLOYMENT/SECOND_MAINNET_RELEASE.md), recording executed checks and explicit owner-accepted omissions separately before a deployment decision. Any later contract, dependency, compiler or linking change requires its own exact-source qualification.

For the planned second deployment, the owner selected no external independent review and no Sepolia rehearsal on 15 October 2026. The [scoped qualification decision](DEPLOYMENT/SECOND_MAINNET_QUALIFICATION_DECISION.md) records both as not performed, with owner-accepted omissions and unchanged technical/authorization gates. AI-assisted review is not an external audit.

For the latest reported deployment, start with the [17 October Manager and authority record](deployments/MAINNET_MANAGER_2026-10-17.md). The [historical October 10 inspection and recovery workflow](OPERATIONS/COMMISSIONING.md#historical-manager-and-ens-helper--10-october-2026) selects only that earlier Manager and its ENS helper; its commands do not inspect the October 17 Manager.

Current automated work uses [operator-budget admission without retainers](OPERATIONS/NO_RETAINERS.md), with schema 6 participant and schema 7 employer policies. Existing credits, refunds and journals remain recoverable. See [general computer work and actual adapter coverage](OPERATIONS/GENERAL_COMPUTER_WORK.md).

v1.14.0 is a software release for verified v0.9.6-compatible managers and new Ethereum deployments. It supplies no live manager, recipient wallets, owner-key verification or production signing authority. Automated qualification is evidence about the pinned source and tested scenarios; it is not an independent audit or a guarantee against every failure.

The project already has a legacy mainnet manager with outstanding original-asset obligations. The [USDC cutover qualification](qualification/USDC_CUTOVER.md) records that live state, the ENS resolver correction first included in v0.9.2 and retained in v1.1.0, and a fork rehearsal preserving existing jobs. Software qualification and live-instance approval remain separate.

The retained [qualified admission tools](OPERATIONS/QUALIFIED_ADMISSION.md) add lifecycle modeling, signed attestations and canonical state reads. A result within supplied limits does not establish live admission readiness or guaranteed participant profitability. Canonical settlement reporting from v1.2.1 remains available.

## Settlement

Jobs, escrow, bonds, rewards and refunds use native Circle USDC with six decimal places. On Ethereum the immutable token is `0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48`, checked against [Circle's address registry](https://developers.circle.com/stablecoins/usdc-contract-addresses).

| Successful 100 USDC job | Default amount |
| --- | ---: |
| Validators, first | 8 USDC |
| First wallet, 30% of original cost | 30 USDC |
| Second wallet, 10% of original cost | 10 USDC |
| Agent, remainder | 52 USDC |

The owner may set the validator budget to 1–60% for newly posted jobs. Existing jobs retain their posting-time percentage. Rounding and unused validator allocations go to the agent. Bonds and slashing are accounted separately. Refund outcomes do not pay the two successful-job wallet shares. Read the [complete payout specification](USDC_PAYOUT_SPLIT.md).

## Retained contract safeguards and qualification

- Intake starts paused in the constructor, eliminating the interval between deployment and a separate pause transaction.
- Job duration settings are bounded to 1–365 days in seconds, preventing owner configuration that can overflow lifecycle deadlines.
- Generic token rescue cannot call the manager itself or USDC. This preserves the boundary around internal completion-NFT minting and reserved funds.
- Deployment checks bind the selected network to its chain ID, validate native USDC and issuer restrictions, enforce compiler and bytecode limits, compare linked runtime code, preserve partial deployment receipts, and report incomplete explorer verification as failure.
- A read-only deployment check verifies the actual instance before opening intake. Current creation assigns the explicit governor atomically with zero pending owner; historical handovers and later voluntary Manager transfers retain two-step acceptance.
- Transaction reviews bind the connected account, network and manager through approvals and submission. Changed contexts require a new review. Failed receipts cannot be reported as successful.
- Qualification includes contract regressions, issuer restrictions, bonds/disputes, exact transfer ordering, fuzzing, concurrent-job invariants, deployment rejection scenarios, browser tests and static-analysis triage.

## Preserved contract qualification scope

Version 1.1.0 adds read-only deployment defaults and corrected operator guidance while retaining v1.0.5 privacy notices, public-content review, credential handling and browser storage. It preserves v1.0.3 ABI, creation/runtime bytecode and disabled NFT default. Existing managers keep their settings, jobs and agreements. See [release scope](V1_RELEASE_SCOPE.md), the [internal contract review](qualification/V1_CONTRACT_REVIEW.md), [v1.0.3 default review](qualification/V103_NFT_DEFAULT.md), [v1.0.4 notice review](qualification/V104_OPERATOR_NOTICES.md), [v1.0.5 privacy review](qualification/V105_PRIVACY.md), [acceptance protocol](V1_ACCEPTANCE.md) and [launch checklist](LAUNCH_CHECKLIST.md).

The earlier [v0.9.7 operating review](qualification/OPERATIONS_V097.md) and [v0.9.6 exact-bond review](qualification/BUYER_ECONOMICS_FOLLOWUP.md) remain historical evidence. Full buyer escrow refunds, no-vote dispute escalation, explicit acceptance, full review, credential/controller conflict checks, pause-aware deadlines, neutral timeout and reserved payment claims are preserved. Final source CI and release validation establish the executed qualification scope; independent audit, real-user studies and live-instance readiness are separate evidence.

## Reproduce qualification

Use Node 22.23.2 and the committed lockfiles. Install the root and Hardhat workspaces before running the contract tests; all local tests use disposable accounts. See [dependency scope](DEPENDENCY_SECURITY.md).

```bash
npm ci
npm --prefix hardhat ci
npm test
node scripts/ui/verify-usdc-console.mjs
npx playwright install --with-deps chromium
npm run test:ui:usdc
npm run test:ui
cd hardhat
npm ci
npm run compile
npm run test:preflight
npm run test:deployment
npm run test:mainnet-fork
CUTOVER_REPORT=../build/qualification/mainnet-cutover.json npm run test:cutover
```

The commands above target current source. For the frozen v1.0.0 tag, use its recorded console verifier and qualification commands; it predates the primary-console browser runner. [Release versus source](V1_RELEASE_SCOPE.md#published-download-versus-current-source) identifies the difference. Browser wallet/RPC responses are mocked, with no signing or broadcast.

The qualified fork fixture pins Ethereum block **25,997,388**, hash `0x1495b5decf70b7757b60b8d4ba10d14a7cdb4512f55c4ae5400d8a97b9deedf9`, and checks USDC implementation `0x43506849D7C04F9138D1A2050bbF3A0c054402dd` plus its runtime hash. The v1.17.0 run executes eleven native-USDC cases covering paused launch, exact default-bond settlement, issuer pause/blocklist protected claims and recovery, and reviewer-credit settlement/recovery. Earlier eight-case results remain historical evidence.

The separate cutover fixture pins block **25,998,952**, hash `0xac9075441aff899351bf4ca9abf5be0edc4494b69a1c7543b389fd8cacaa159a`. Its 23 scenarios exercise the actual mainnet ENS contracts, all four participant membership roots and explicit exceptions, separate ownership paths, both NFT modes with unchanged ENS authorization and USDC settlement, further recovery cases, the preserved legacy inventory and the original-asset exit for job 11. See the [source-bound report](qualification/mainnet-cutover.json).

The fork runner exposes only the local Hardhat network. It reads a pinned finalized Ethereum block and executes every transaction on that local fork. It never broadcasts transactions to Ethereum, does not use production private keys and fails if the remote state is unavailable. Fork evidence checks a historical state; USDC implementation and issuer configuration must be rechecked before an actual launch.

```bash
cd ..
FOUNDRY_PROFILE=ci forge build --deny warnings
FOUNDRY_PROFILE=ci forge test
npm run slither
npm run slither:extended
cd ui
npm ci
npm run lint
npm run typecheck
npm test
npm run test:e2e
npm run test:a11y
npm run test:headers
```

Use Foundry 1.7.1 and Slither 0.11.6. The extended static-analysis gate preserves raw findings and verifies a reviewed baseline instead of excluding whole detector classes. Consult the linked CI logs and release validation document for exact source-specific results.

## An actual high-stakes launch

Before committing significant funds, obtain independent review of the final source and operational setup, rehearse with the actual owner/signing arrangement on Sepolia, and provide the real recipient addresses. These activities are not completed by publishing a GitHub release.

Complete applicable legal review for the actual operator, owner powers, fee beneficiaries, service scope and jurisdictions. Publish the [operator notice](LEGAL/OPERATOR_NOTICE_TEMPLATE.md) and meet required terms, privacy and language arrangements. A technical readiness report explicitly leaves these matters unassessed; open-source publication and disclaimers do not guarantee regulatory immunity.

Follow the [Hardhat guide](../hardhat/README.md), complete source verification, confirm the constructor-assigned governor and zero pending owner, and run the read-only readiness command while intake remains paused. No current-creation acceptance is required; historical handovers and later voluntary Manager transfers retain their original two-step semantics. Reconcile USDC, both wallets, linked code, policy settings and all reserve counters against the deployment receipt. Open intake only after these instance-specific checks pass; use a deliberately limited first job before increasing exposure.

## Operational limits

- This is not a proxy. Code changes require a new deployment; supported owner settings remain available under their on-chain guards.
- The owner and moderators remain trusted authorities. A compromised owner can misuse eligibility, pause or dispute powers even though reserved funds cannot be withdrawn as surplus.
- Circle may pause USDC, block addresses or upgrade its implementation. Failed outgoing transfers become protected claims; tests establish reserve conservation and same-beneficiary retries. Claims and existing jobs cannot be redirected by rotating wallets.
- Validators can collude or misjudge off-chain work. The employer and assigned agent cannot vote on their own job; duplicate ENS credentials and recorded controllers are rejected. Distinct addresses or ENS names still do not establish independent people or rule out hidden common control. Configure and monitor eligibility accordingly; bonds and tests do not prove the truth of a deliverable.
- ENS and metadata are external dependencies. Optional job-page failures are bounded; identity availability and correct operational configuration still matter.
- The selected integrated compiler profile produces a 24,477-byte Manager runtime, leaving 99 bytes below Ethereum's 24,576-byte limit; see the [source-bound optimizer measurement](security/sol-2026-7-workaround.md#evidence-obtained). This build measurement is not a fresh observation of any deployed contract. Preserve the exact source and compiler settings and repeat bytecode/deployment checks after a source or compiler change.
- CI audits the complete root, deployment and UI dependency trees and rejects advisories at every severity. Repeat those checks against the current registry before deployment; a clean advisory database result does not prove absence of unknown vulnerabilities.

The [deploy-day runbook](DEPLOY_DAY_RUNBOOK.md), [owner controls](OWNER_CONTROLS.md) and [incident response](OPERATIONS/INCIDENT_RESPONSE.md) describe the operational steps.
