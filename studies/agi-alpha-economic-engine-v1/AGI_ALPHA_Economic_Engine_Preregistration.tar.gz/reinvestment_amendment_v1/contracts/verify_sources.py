# SPDX-License-Identifier: Apache-2.0
"""Verify retained public source bytes and references without running contracts."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    register = json.loads((ROOT / "SOURCE_REGISTER.json").read_text())
    sources = {r["id"]: r for r in register["sources"]}
    assert len(sources) == register["source_count"]
    checks = 1
    for source in sources.values():
        raw = (ROOT / source["snapshot_path"]).read_bytes()
        assert len(raw) == source["bytes"], source["id"]
        assert hashlib.sha256(raw).hexdigest() == source["sha256"], source["id"]
        blob = hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
        assert blob == source["git_blob_sha"], source["id"]
        assert len(raw.splitlines()) == source["lines"], source["id"]
        assert f"/blob/{source['commit']}/" in source["url"], source["id"]
        checks += 5

    def visit(value):
        nonlocal checks
        if isinstance(value, dict):
            if "source" in value and ("start_line" in value or "lines" in value):
                source = sources[value["source"]]
                start, end = value.get("lines", [value.get("start_line"), value.get("end_line")])
                assert 1 <= start <= end <= source["lines"], value
                checks += 1
            for child in value.values():
                visit(child)
        elif isinstance(value, list):
            for child in value:
                visit(child)

    for name in ["FLOW_MATRIX.json", "ROUTE_CONSTANTS.json"]:
        visit(json.loads((ROOT / name).read_text()))
    comparison = json.loads((ROOT / "ALPHA_SOURCE_COMPARISON.json").read_text())
    for row in comparison["files"]:
        assert row["equal"] == (row["reported_deployed_source_blob"] == row["current_source_blob"])
        matching = [s for s in sources.values() if s["repository"] == "MontrealAI/AGI-Alpha-Agent-v0" and s["path"] == row["path"]]
        assert len(matching) == 1 and matching[0]["git_blob_sha"] == row["current_source_blob"]
        checks += 2
    assert comparison["all_six_source_files_equal"] == all(row["equal"] for row in comparison["files"])
    checks += 1
    print(json.dumps({"status": "PASS", "checks": checks, "source_files": len(sources), "scope": "Byte identity and reference ranges only; no contract execution, semantic oracle, fresh chain verification or financial scenario evaluation"}, indent=2))


if __name__ == "__main__":
    main()
