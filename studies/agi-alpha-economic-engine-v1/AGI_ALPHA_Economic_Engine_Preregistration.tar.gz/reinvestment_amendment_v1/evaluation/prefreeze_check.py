# SPDX-License-Identifier: Apache-2.0
"""Static preregistration checks only; never calculate a new financial path."""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WORKSPACE = ROOT.parent
PRIOR_RESULT_SHA = "cba5f2cf284e27f7097fc3f4cebe0bf985952cd64bfcabee78af51ca0c17ac9d"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path: Path):
    return json.loads(path.read_text(), parse_float=Decimal)


def native(value):
    if isinstance(value, Decimal):
        return str(value)
    raise TypeError(type(value).__name__)


def main():
    checks = []

    def check(name, condition, detail=None):
        checks.append({"check": name, "pass": bool(condition), "detail": detail})

    inputs = read(ROOT / "inputs.json")
    anchor = read(ROOT / "prior_model_anchor.json")
    prior_path = WORKSPACE / anchor["source_path"]
    check("prior_result_identity", sha(prior_path) == PRIOR_RESULT_SHA)
    check("anchor_source_identity", anchor["source_sha256"] == PRIOR_RESULT_SHA)
    prior = read(prior_path)
    originals = {
        c["scenario"]: c
        for c in prior["core_scenarios"]
        if c["price_basis"] == "US_office"
    }
    check("scenario_coverage", set(anchor["scenarios"]) == set(inputs["scenarios"]))
    for scenario, copied in anchor["scenarios"].items():
        old = originals[scenario]
        check(
            scenario + ".acceptance_copy",
            copied["acceptance_probability"] == old["expected_acceptance_probability"],
        )
        check(
            scenario + ".path_weights_copy",
            copied["branch_weights"] == old["scenario_inputs"]["branch_weights"],
        )
        check(
            scenario + ".path_weights_sum", sum(copied["branch_weights"].values()) == 1
        )
        check(
            scenario + ".labor_prices_copy",
            copied["labor_prices"] == old["labor_prices"],
        )
        check(
            scenario + ".handoff_copy",
            copied["hybrid_handoff_employer_minutes"]
            == old["scenario_inputs"]["hybrid_handoff_employer_minutes"],
        )
        for account, original in (
            ("variable", old["agent_variable"]["account"]),
            ("initial", old["fixed_agent"]["initial"]),
            ("monthly", old["fixed_agent"]["monthly"]),
        ):
            entry = copied[account]
            expected_customer = {
                k: v for k, v in original["components"].items() if ".employer." in k
            }
            expected_provider = {
                k: v for k, v in original["components"].items() if ".employer." not in k
            }
            check(
                scenario + "." + account + ".customer_partition",
                entry["employer_components_usd"] == expected_customer,
            )
            check(
                scenario + "." + account + ".provider_partition",
                entry["provider_components_usd"] == expected_provider,
            )
            check(
                scenario + "." + account + ".resource_copy",
                entry["resources"] == original["resources"],
            )
            check(
                scenario + "." + account + ".total_copy",
                entry["original_total_usd"] == original["total"],
            )
            check(
                scenario + "." + account + ".partition_disjoint",
                not (
                    set(entry["provider_components_usd"])
                    & set(entry["employer_components_usd"])
                ),
            )
            check(
                scenario + "." + account + ".partition_complete",
                set(entry["provider_components_usd"])
                | set(entry["employer_components_usd"])
                == set(original["components"]),
            )
        traditional = {
            str(int(t["productive_minutes"])): t["traditional"]
            for t in old["traditional_comparisons"]
        }
        for duration, human in copied["traditional"].items():
            old_human = traditional[duration]
            check(
                scenario + ".traditional." + duration + ".variable",
                human["variable"] == old_human["variable"]["account"],
            )
            check(
                scenario + ".traditional." + duration + ".initial",
                human["initial"] == old_human["fixed"]["initial"],
            )
            check(
                scenario + ".traditional." + duration + ".monthly",
                human["monthly"] == old_human["fixed"]["monthly"],
            )

        settings = inputs["scenarios"][scenario]
        for key in (
            "utilization",
            "collected_fraction_of_accepted_invoices",
            "refund_fraction_of_collected",
            "payment_processing_fraction",
            "tax_reserve_fraction_of_positive_cumulative_pre_discretionary_income",
            "warranty_reserve_fraction_of_last_two_months_collected_proceeds",
        ):
            check(scenario + ".bounded." + key, 0 <= settings[key] <= 1)
        check(
            scenario + ".positive_net_collection_percentage",
            settings["refund_fraction_of_collected"]
            + settings["payment_processing_fraction"]
            < 1,
        )
        check(
            scenario + ".demand_is_nonnegative_integer",
            all(
                isinstance(settings[k], int) and settings[k] >= 0
                for k in (
                    "anchor_annual_requested_demand",
                    "hypothesis_annual_requested_demand",
                )
            ),
        )
        # This is an input-consistency check, not a scenario cost calculation:
        # explicitly included labor cannot exceed its own all-in cash allowance.
        rate = copied["labor_prices"]["provider_per_hour_in_reporting_currency"]
        check(
            scenario + ".setup_allowance_covers_included_labor",
            settings["additional_business_setup_usd"]
            >= settings["additional_setup_provider_hours"] * rate,
        )
        check(
            scenario + ".monthly_allowance_covers_included_labor",
            settings["additional_monthly_acquisition_billing_usd"]
            + settings["additional_monthly_business_administration_usd"]
            >= settings["additional_monthly_provider_hours"] * rate,
        )

    check(
        "native_anchor_is_exact_copy",
        anchor["native_observation"] == prior["observed_anchor"],
    )
    check(
        "unknown_full_cost_remains_null",
        anchor["native_observation"]["actual_full_agent_cost"] is None,
    )
    check(
        "unknown_attention_remains_null",
        anchor["native_observation"]["actual_human_attention_minutes"] is None,
    )
    check(
        "unknown_authoring_cost_remains_null",
        anchor["native_observation"]["historical_authoring_cost"] is None,
    )
    check(
        "capital_not_revenue",
        inputs["initial_cash_is_revenue_or_reinvestment_surplus"] is False,
    )
    check("one_month_collection_delay", inputs["collection_delay_months"] == 1)
    check(
        "four_allocation_ceiling_cases",
        inputs["reinvestment_fractions_of_available_surplus"]
        == [0, Decimal("0.25"), Decimal("0.5"), Decimal("0.75")],
    )
    check(
        "both_outcome_worlds",
        set(inputs["capability_outcome_worlds"])
        == {"no_gain", "assumed_diminishing_gain"},
    )
    check("no_live_finance", inputs["live_financial_transactions"] == "NOT RUN")
    check("no_authenticated_executor", inputs["authenticated_executor"] == "NOT RUN")
    check(
        "traditional_worker_capacity_pool_explicit",
        inputs["monthly_resources"]["traditional_worker_minutes_per_day"] == 480,
    )
    rate = anchor["scenarios"]["base"]["labor_prices"][
        "provider_per_hour_in_reporting_currency"
    ]
    ids = []
    for candidate in inputs["candidate_capabilities"]:
        ids.append(candidate["id"])
        prefix = "candidate." + candidate["id"]
        check(
            prefix + ".positive_cost", candidate["construction_and_evaluation_usd"] > 0
        )
        check(
            prefix + ".labor_included",
            candidate["construction_and_evaluation_usd"]
            >= candidate["provider_hours_included_in_cash_cost"] * rate,
        )
        check(
            prefix + ".upkeep_labor_included",
            candidate["monthly_upkeep_usd"]
            >= candidate["monthly_upkeep_provider_hours"] * rate,
        )
        check(
            prefix + ".positive_delay",
            isinstance(candidate["evaluation_delay_months"], int)
            and candidate["evaluation_delay_months"] >= 1,
        )
        for key in (
            "forecast_success_probability",
            "forecast_fractional_nonlabor_saving",
            "forecast_fractional_provider_time_saving",
        ):
            check(prefix + ".bounded." + key, 0 <= candidate[key] <= 1)
    check("unique_candidate_ids", len(ids) == len(set(ids)))

    token = read(ROOT / "token_scenarios.json")
    check(
        "token_routes_separate",
        token["dynamic_cash_model_connection"]
        == "SEPARATE_NOT_EXECUTED_OR_CONSOLIDATED_WITH_ORDINARY_USD_REINVESTMENT",
    )
    check("token_no_transactions", token["actual_transactions"] == "NOT_RUN")
    check(
        "token_no_current_chain_claim",
        token["current_chain_state"] == "NOT_INDEPENDENTLY_VERIFIED",
    )
    check(
        "token_quote_is_hypothesis",
        token["quote_valuation_status"]
        == "ILLUSTRATIVE_ACCOUNTING_RATIO_NOT_OBSERVED_MARKET_PRICE_OR_PREDICTION",
    )
    check(
        "token_quote_positive",
        Decimal(token["hypothetical_usd_per_agialpha_at_quote"]) > 0,
    )
    check(
        "token_atomic_precision", token["asset_decimals"] == {"USDC": 6, "AGIALPHA": 18}
    )
    check(
        "manager_fixed_beneficiaries",
        (token["manager"]["wallet30_percent"], token["manager"]["wallet10_percent"])
        == (30, 10),
    )
    check(
        "manager_all_reviewers_correct",
        token["manager"]["correct_validators"] == token["manager"]["validators"] > 0,
    )
    check(
        "manager_success_no_slash",
        token["manager"]["buyer_acceptance"]
        and token["manager"]["validator_slashes"] == 0,
    )
    check(
        "ascension_source_constants",
        (
            token["ascension"]["validator_pool_bps_source"],
            token["ascension"]["approving_validators"],
            token["ascension"]["payout_burn_percent_source"],
        )
        == (500, 2, 1),
    )
    check(
        "jobs_success_no_boost",
        token["jobs_v0"]["agent_payout_multiplier_percent_assumed"] == 100
        and token["jobs_v0"]["worker_boost_reserve_draw"] == 0,
    )
    check(
        "jobs_failure_not_modeled",
        token["jobs_v0"]["failure_economics"].startswith("NOT_MODELED"),
    )
    for name, settings in token["realization_scenarios"].items():
        for key in (
            "agialpha_value_fraction_at_realization",
            "agialpha_slippage_fraction",
            "agialpha_conversion_fee_fraction",
            "usdc_usd_realization_fraction",
            "usdc_conversion_fee_fraction",
        ):
            check("token." + name + ".bounded." + key, 0 <= settings[key] <= 1)
        for key in (
            "worker_gas_usd_per_settlement_allowance",
            "usd_conversion_liquidity_limit_per_month",
            "collateral_lock_days",
            "annual_imputed_capital_cost_fraction",
        ):
            check("token." + name + ".nonnegative." + key, settings[key] >= 0)

    scope = json.loads((ROOT / "contracts/CONTRACT_FREEZE_FILES.json").read_text())
    identity_paths = [WORKSPACE / n for n in scope]
    identity_paths += [
        ROOT / p
        for p in (
            "PROTOCOL.md",
            "inputs.json",
            "token_scenarios.json",
            "prior_model_anchor.json",
            "evaluation/EVALUATION_PLAN.md",
            "evaluation/CONTRACT_SOURCE_REVIEW.json",
        )
    ]
    for p in identity_paths:
        check("file_exists." + str(p.relative_to(WORKSPACE)), p.is_file())
    output = {
        "schema": "cash-reinvestment-static-preregistration-check/v1",
        "status": "PASS" if all(x["pass"] for x in checks) else "FAIL",
        "checked_utc": datetime.now(timezone.utc).isoformat(),
        "new_financial_scenarios_evaluated": 0,
        "check_count": len(checks),
        "checks": checks,
        "file_identities": [
            {
                "path": str(p.relative_to(ROOT)),
                "bytes": p.stat().st_size,
                "sha256": sha(p),
            }
            for p in identity_paths
            if p.is_file()
        ],
        "limitations": [
            "Static source/input checks only; the manual prospective-method review is separate.",
            "No empirical reliability, demand, prices, cash receipts or capability gains are established.",
        ],
    }
    out = ROOT / "evaluation/STATIC_PREFREEZE_CHECK.json"
    out.write_text(json.dumps(output, indent=2, sort_keys=True, default=native) + "\n")
    print(
        json.dumps(
            {"status": output["status"], "checks": len(checks), "sha256": sha(out)}
        )
    )
    if output["status"] != "PASS":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
