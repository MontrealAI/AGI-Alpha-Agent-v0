# SPDX-License-Identifier: Apache-2.0
"""Frozen, finite ordinary-USD cash simulation. No imports execute scenarios.

Run only after the distinct public FREEZE and recorded GO. All contract routes
are separate; this module never sends a request or transaction to a provider.
"""
from __future__ import annotations

import argparse
import copy
import csv
import hashlib
import json
import platform
import shutil
import traceback
from dataclasses import dataclass
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR, getcontext
from pathlib import Path
from typing import Any

getcontext().prec = 48
ZERO = Decimal(0)
ONE = Decimal(1)
ROOT = Path(__file__).resolve().parents[1]


def D(value: Any) -> Decimal:
    if isinstance(value, Decimal):
        return value
    if value is None:
        raise ValueError("An unknown value cannot be silently priced as zero")
    return Decimal(str(value))


def total(values) -> Decimal:
    return sum((D(x) for x in values), ZERO)


def floor_count(value: Decimal) -> int:
    return int(max(ZERO, value).to_integral_value(rounding=ROUND_FLOOR))


def ceil_count(value: Decimal) -> int:
    return int(max(ZERO, value).to_integral_value(rounding=ROUND_CEILING))


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"), parse_float=Decimal)


def plain(value):
    if isinstance(value, Decimal):
        if not value.is_finite():
            raise ValueError("Nonfinite financial output")
        return float(value)
    if isinstance(value, dict):
        return {k: plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    return value


def save_json(path: Path, value):
    path.write_text(json.dumps(plain(value), indent=2, ensure_ascii=False, allow_nan=False) + "\n", encoding="utf-8")


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


@dataclass(frozen=True)
class Case:
    profile: str
    scenario: str
    price: Decimal
    fraction: Decimal
    world: str
    demand_multiplier: Decimal = ONE
    analysis: str = "primary"

    @property
    def id(self) -> str:
        def slug(x):
            return format(D(x).normalize(), "f").replace(".", "p")
        return "__".join([self.analysis, self.profile, self.scenario, "price" + slug(self.price), "reinvest" + slug(self.fraction), self.world, "demand" + slug(self.demand_multiplier)])


def account_sum(account, party):
    return total(account[f"{party}_components_usd"].values())


def partition_check(anchor):
    records = []
    for name, scenario in anchor["scenarios"].items():
        for stage in ["variable", "initial", "monthly"]:
            acc = scenario[stage]
            provider = account_sum(acc, "provider")
            customer = account_sum(acc, "employer")
            residual = provider + customer - D(acc["original_total_usd"])
            if abs(residual) > Decimal("0.000000001"):
                raise ValueError(f"Prior account partition changed: {name}/{stage}")
            records.append({"scenario": name, "stage": stage, "provider_usd": provider, "customer_usd": customer, "original_total_usd": acc["original_total_usd"], "rounding_residual_usd": residual})
    return records


def build_profile(inputs, anchor, case):
    cfg = inputs["scenarios"][case.scenario]
    old = anchor["scenarios"][case.scenario]
    q = D(old["acceptance_probability"])
    rate = D(old["labor_prices"]["provider_per_hour_in_reporting_currency"]) / 60
    customer_rate = D(old["labor_prices"]["employer_worker_per_hour"]) / 60
    original = old["variable"]["provider_components_usd"]
    if case.profile == "evidence_pack":
        labor = {k: D(v) for k, v in original.items() if ".provider." in k}
        nonlabor = {k: D(v) for k, v in original.items() if ".provider." not in k}
        provider_minutes = D(old["variable"]["resources"]["provider_minutes"])
        customer_minutes = D(old["variable"]["resources"]["employer_minutes"])
        customer_components = {k: D(v) for k, v in old["variable"]["employer_components_usd"].items()}
        annual = D(cfg["anchor_annual_requested_demand"])
        evidence = "BOUNDED_FOUR_PASSAGE_NATIVE_ANCHOR_WITH_ASSUMED_SERVICE_COSTS_AND_FIELD_RELIABILITY"
    elif case.profile == "cost_050_hypothesis":
        base_q = D(anchor["scenarios"]["base"]["acceptance_probability"])
        base_minutes = base_q * D(inputs["hypothesis_base_provider_minutes_per_expected_accepted"])
        provider_minutes = base_minutes if case.scenario == "base" else D(cfg["hypothesis_provider_minutes_per_requested"])
        base_nonlabor = base_q * D(inputs["hypothesis_base_variable_delivery_cost_per_expected_accepted_usd"]) - base_minutes * rate
        if base_nonlabor < ZERO:
            raise ValueError("Hypothesis normalized cost cannot fund the specified provider labor")
        labor = {"hypothesis.delivery.provider.paid_labor": provider_minutes * rate}
        nonlabor = {"hypothesis.delivery.assumed_nonlabor": base_nonlabor * D(cfg["hypothesis_nonlabor_multiplier"])}
        customer_minutes = D(cfg["hypothesis_customer_minutes_per_requested"])
        customer_components = {"hypothesis.delivery.employer.attention": customer_minutes * customer_rate}
        annual = D(cfg["hypothesis_annual_requested_demand"])
        evidence = "UNVALIDATED_OFFERING_HYPOTHESIS_NOT_A_MEASURED_USD200_TASK"
    else:
        raise ValueError(case.profile)
    annual *= case.demand_multiplier
    if annual != annual.to_integral_value():
        raise ValueError("Frozen demand must resolve to integer requested jobs")
    months = int(inputs["operating_months_after_setup"])
    quotient, remainder = divmod(int(annual), months)
    arrivals = [quotient + (i < remainder) for i in range(months)]
    initial = {k: D(v) for k, v in old["initial"]["provider_components_usd"].items()}
    initial["commercial.initial.setup_including_provider_labor"] = D(cfg["additional_business_setup_usd"])
    monthly = {k: D(v) for k, v in old["monthly"]["provider_components_usd"].items()}
    monthly["commercial.monthly.acquisition_billing_including_labor"] = D(cfg["additional_monthly_acquisition_billing_usd"])
    monthly["commercial.monthly.administration_including_labor"] = D(cfg["additional_monthly_business_administration_usd"])
    resources = inputs["monthly_resources"]
    utilization = D(cfg["utilization"])
    return {
        "evidence_class": evidence, "q": q, "provider_rate_per_minute": rate, "customer_rate_per_minute": customer_rate,
        "provider_labor_components": labor, "provider_nonlabor_components": nonlabor,
        "customer_variable_components": customer_components,
        "provider_minutes_per_request": provider_minutes, "customer_minutes_per_request": customer_minutes,
        "executor_seconds_per_request": D(old["variable"]["resources"]["executor_seconds"]),
        "initial_components": initial, "monthly_components": monthly,
        "customer_initial_components": {k: D(v) for k, v in old["initial"]["employer_components_usd"].items()},
        "customer_monthly_components": {k: D(v) for k, v in old["monthly"]["employer_components_usd"].items()},
        "initial_provider_minutes": D(old["initial"]["resources"]["provider_minutes"]) + D(cfg["additional_setup_provider_hours"]) * 60,
        "initial_customer_minutes": D(old["initial"]["resources"]["employer_minutes"]),
        "initial_executor_seconds": D(old["initial"]["resources"]["executor_seconds"]),
        "monthly_provider_minutes": D(old["monthly"]["resources"]["provider_minutes"]) + D(cfg["additional_monthly_provider_hours"]) * 60,
        "monthly_customer_minutes": D(old["monthly"]["resources"]["employer_minutes"]),
        "monthly_executor_seconds": D(old["monthly"]["resources"]["executor_seconds"]),
        "provider_minutes_ceiling": D(resources["workdays"]) * D(resources["provider_minutes_per_day"]) * utilization,
        "customer_minutes_ceiling": D(resources["workdays"]) * D(resources["customer_minutes_per_day"]) * utilization,
        "executor_seconds_per_instance_ceiling": D(resources["workdays"]) * D(resources["executor_hours_per_workday"]) * 3600 * utilization,
        "traditional_worker_minutes_ceiling": D(resources["workdays"]) * D(resources["traditional_worker_minutes_per_day"]) * utilization,
        "provider_minutes_per_setup_day": D(resources["provider_minutes_per_day"]) * utilization,
        "annual_demand": int(annual), "arrivals": arrivals,
        "handoff_minutes": D(old["hybrid_handoff_employer_minutes"]),
    }


def current_variable(profile, nonlabor_factor, provider_factor):
    labor = {k: v * provider_factor for k, v in profile["provider_labor_components"].items()}
    nonlabor = {k: v * nonlabor_factor for k, v in profile["provider_nonlabor_components"].items()}
    return {"components": {**labor, **nonlabor}, "labor_usd": total(labor.values()), "nonlabor_usd": total(nonlabor.values()), "total_usd": total(labor.values()) + total(nonlabor.values()),
            "provider_minutes": profile["provider_minutes_per_request"] * provider_factor,
            "customer_minutes": profile["customer_minutes_per_request"], "executor_seconds": profile["executor_seconds_per_request"]}


def current_fixed(profile, inputs, active_candidates, instances):
    components = dict(profile["monthly_components"])
    minutes = profile["monthly_provider_minutes"]
    for candidate in active_candidates:
        components[f"discretionary.upkeep.{candidate['id']}.including_labor"] = D(candidate["monthly_upkeep_usd"])
        minutes += D(candidate["monthly_upkeep_provider_hours"]) * 60
    additions = instances - int(inputs["monthly_resources"]["executor_instances"])
    if additions:
        capacity = inputs["capacity_purchase"]
        components["capacity.monthly.upkeep_including_labor"] = D(capacity["monthly_upkeep_usd"]) * additions
        minutes += D(capacity["monthly_upkeep_provider_hours_included_in_cost"]) * 60 * additions
    return {"components": components, "total_usd": total(components.values()), "provider_minutes": minutes,
            "customer_minutes": profile["monthly_customer_minutes"], "executor_seconds": profile["monthly_executor_seconds"]}


def resource_limits(profile, variable, fixed, instances):
    remaining = {
        "provider_minutes": profile["provider_minutes_ceiling"] - fixed["provider_minutes"],
        "customer_minutes": profile["customer_minutes_ceiling"] - fixed["customer_minutes"],
        "executor_seconds": profile["executor_seconds_per_instance_ceiling"] * instances - fixed["executor_seconds"],
    }
    limits = {}
    for field, value in remaining.items():
        used = variable[field]
        if used <= ZERO:
            raise ValueError(f"Frozen per-request resource must be positive: {field}")
        limits[field] = floor_count(max(ZERO, value) / used)
    return {"remaining": remaining, "limits": limits, "request_limit": min(limits.values()), "fixed_resource_shortfalls": {k: max(ZERO, -v) for k, v in remaining.items()}}


def project_resources(profile, variable, fixed, instances, start_month, backlog):
    """Current-method recurrence, without cash guarantees or future actions."""
    limits = resource_limits(profile, variable, fixed, instances)
    rows = []
    carry = int(backlog)
    for month in range(start_month, len(profile["arrivals"]) + 1):
        carry += profile["arrivals"][month - 1]
        requests = min(carry, limits["request_limit"])
        carry -= requests
        rows.append({"month": month, "requests": requests, "expected_accepted": D(requests) * profile["q"], "backlog": carry})
    return {"rows": rows, "requests": sum(r["requests"] for r in rows), "end_backlog": carry, "resource_limits": limits, "cash_feasibility_established": False}


def conditional_division(numerator, denominator, unavailable="NO_POSITIVE_DENOMINATOR"):
    if denominator <= ZERO:
        return {"status": unavailable, "value": None}
    return {"status": "AVAILABLE_CONDITIONAL", "value": numerator / denominator}


def customer_comparisons(inputs, anchor, case, profile, summary):
    old = anchor["scenarios"][case.scenario]
    n = D(summary["requests_served"])
    accepted = D(summary["expected_accepted"])
    annual = D(profile["annual_demand"])
    unresolved = n - accepted
    unserved = annual - n
    started = summary["startup_admitted"]
    active_months = summary["customer_fixed_months"]
    customer_fixed = (total(profile["customer_initial_components"].values()) if started else ZERO) + D(active_months) * total(profile["customer_monthly_components"].values())
    customer_variable = n * total(profile["customer_variable_components"].values())
    attention = (profile["initial_customer_minutes"] if started else ZERO) + D(active_months) * profile["monthly_customer_minutes"] + n * profile["customer_minutes_per_request"]
    invoice_cost = accepted * case.price
    agent_customer_total = invoice_cost + customer_fixed + customer_variable
    handoff_unit = profile["handoff_minutes"] * profile["customer_rate_per_minute"]
    common = {"agent_face_price_invoices_usd": invoice_cost, "agent_customer_fixed_usd": customer_fixed, "agent_customer_variable_usd": customer_variable,
              "agent_customer_total_usd": agent_customer_total, "agent_customer_total_per_expected_accepted": conditional_division(agent_customer_total, accepted),
              "agent_customer_attention_minutes": attention, "agent_unresolved_requests": unresolved,
              "annual_unserved_requests": unserved, "employer_handoff_minutes_per_unresolved_admitted": profile["handoff_minutes"]}
    rows = []
    durations = inputs["human_productive_minutes_for_anchor"] if case.profile == "evidence_pack" else [None]
    for duration in durations:
        if duration is None:
            human_unit = D(inputs["hypothesis_human_replacement_cost_usd"])
            human_fixed = ZERO
            human_attention_unit = None
            human_worker_unit = None
            human_fixed_attention = None
            human_fixed_worker = None
        else:
            h = old["traditional"][str(duration)]
            human_unit = D(h["variable"]["total"])
            human_fixed = D(h["initial"]["total"]) + D(inputs["operating_months_after_setup"]) * D(h["monthly"]["total"])
            human_attention_unit = D(h["variable"]["resources"]["employer_minutes"])
            human_worker_unit = D(h["variable"]["resources"]["traditional_worker_minutes"])
            human_fixed_attention = D(h["initial"]["resources"]["employer_minutes"]) + D(inputs["operating_months_after_setup"]) * D(h["monthly"]["resources"]["employer_minutes"])
            human_fixed_worker = D(h["initial"]["resources"]["traditional_worker_minutes"]) + D(inputs["operating_months_after_setup"]) * D(h["monthly"]["resources"]["traditional_worker_minutes"])
        for scope, cohort, fallback in [("served_cohort", n, unresolved), ("annual_demand", annual, unresolved + unserved)]:
            fixed_fallback = human_fixed if fallback > ZERO else ZERO
            traditional = cohort * human_unit + (human_fixed if cohort > ZERO else ZERO)
            handoff = unresolved * handoff_unit
            hybrid = agent_customer_total + fallback * human_unit + fixed_fallback + handoff
            max_price = conditional_division(traditional - customer_fixed - customer_variable - fallback * human_unit - fixed_fallback - handoff, accepted, "NO_ACCEPTED_AGENT_INVOICES")
            if duration is None:
                resource = {"status": "UNKNOWN_HUMAN_DURATION_AND_CAPACITY", "fallback_worker_minutes": None, "total_customer_attention_minutes": None, "customer_pool_feasible": None, "traditional_worker_pool_feasible": None}
            else:
                fallback_worker = fallback * human_worker_unit + (human_fixed_worker if fallback > ZERO else ZERO)
                full_attention = attention + unresolved * profile["handoff_minutes"] + fallback * human_attention_unit + (human_fixed_attention if fallback > ZERO else ZERO)
                customer_pool = profile["customer_minutes_ceiling"] * D(inputs["operating_months_after_setup"])
                worker_pool = profile["traditional_worker_minutes_ceiling"] * D(inputs["operating_months_after_setup"])
                resource = {"status": "AGGREGATE_RESOURCE_REQUIREMENT_NOT_DAILY_SCHEDULE", "fallback_worker_minutes": fallback_worker,
                            "total_customer_attention_minutes": full_attention, "customer_pool_minutes": customer_pool, "traditional_worker_pool_minutes": worker_pool,
                            "customer_pool_feasible": full_attention <= customer_pool, "traditional_worker_pool_feasible": fallback_worker <= worker_pool}
            provider_break_even = summary["zero_reinvestment_break_even_price_usd"] if case.fraction == ZERO else summary["combined_cost_conditional_break_even_price_usd"]
            interval = None if provider_break_even["value"] is None or max_price["value"] is None else provider_break_even["value"] <= max_price["value"]
            rows.append({"scope": scope, "productive_human_minutes_assumed": duration, "cohort_requests": cohort, "fallback_requests": fallback,
                         "traditional_unit_cost_usd": human_unit, "traditional_readiness_usd": human_fixed,
                         "traditional_total_usd": traditional, "hybrid_fallback_variable_usd": fallback * human_unit,
                         "hybrid_fallback_fixed_usd": fixed_fallback, "hybrid_handoff_usd": handoff,
                         "hybrid_total_usd": hybrid, "hybrid_cost_per_completed_request": conditional_division(hybrid, cohort),
                         "customer_savings_usd": traditional - hybrid, "maximum_customer_beneficial_face_price_usd": max_price,
                         "cohort_conditional_viable_price_interval_exists": interval, "fallback_resource_requirements": resource})
    return {"common": common, "comparisons": rows}


def verify_authorization(root):
    freeze_path = root / "FREEZE.json"
    auth_path = root / "AUTHORIZATION.json"
    if not freeze_path.exists() or not auth_path.exists():
        raise RuntimeError("Scenario execution requires this amendment's public FREEZE and separate GO")
    freeze = read_json(freeze_path)
    auth = read_json(auth_path)
    if not str(auth.get("status", "")).startswith("GO_") or auth.get("public_readback_exact") is not True:
        raise RuntimeError("No exact-readback public GO for this amendment")
    if auth.get("freeze_sha256") != sha256(freeze_path):
        raise RuntimeError("GO does not match the frozen specification")
    for record in freeze["files"]:
        path = (root / record["path"]).resolve()
        if not path.is_relative_to(root.resolve()) or sha256(path) != record["sha256"]:
            raise RuntimeError(f"Frozen input changed: {record['path']}")
    return {"freeze_sha256": sha256(freeze_path), "authorization_sha256": sha256(auth_path), "public_source_commit": auth["public_source_commit"], "public_notice": auth["public_notice"], "authorized_utc": auth["authorized_utc"], "frozen_files_verified": len(freeze["files"])}


def run_case(inputs, anchor, case):
    """Evaluate one frozen path after the caller has verified authorization."""
    cfg = inputs["scenarios"][case.scenario]
    profile = build_profile(inputs, anchor, case)
    months = int(inputs["operating_months_after_setup"])
    q = profile["q"]
    initial_cash = D(inputs["initial_virtual_cash_usd"])
    cash = initial_cash
    startup_quote = total(profile["initial_components"].values())
    started = startup_quote <= cash
    startup_shortfall = max(ZERO, startup_quote - cash)
    setup_days = ceil_count(profile["initial_provider_minutes"] / profile["provider_minutes_per_setup_day"])
    ledger, events, monthly = [], [], []
    candidate_records = []
    for source in inputs["candidate_capabilities"]:
        candidate_records.append({"id": source["id"], "status": "NOT_CONSIDERED", "constructed_month": None, "evaluation_month": None,
                                  "simulated_pass": None, "construction_incurred_usd": ZERO, "construction_paid_usd": ZERO,
                                  "provider_construction_minutes": ZERO, "qualified_subsequent_request_uses": 0,
                                  "gross_realized_simulated_savings_usd": ZERO, "upkeep_incurred_usd": ZERO,
                                  "upkeep_paid_usd": ZERO, "promotion_saving_usd_per_request": ZERO})
    active_candidates = []
    pending_candidate = None
    pending_executor = None
    candidate_cursor = 0
    candidate_search_stopped = False
    instances = int(inputs["monthly_resources"]["executor_instances"])
    capacity_purchases = 0
    capacity_records = []
    nonlabor_factor, provider_factor = ONE, ONE
    cash_reserves = {"tax": ZERO, "warranty": ZERO, "working_capital": ZERO, "earmark": ZERO}
    lifetime_allocation = ZERO
    released_allocation = ZERO
    unpaid_shutdown = ZERO
    cumulative_net_collections = ZERO
    cumulative_gross_collections = ZERO
    cumulative_refunds = ZERO
    cumulative_processing = ZERO
    cumulative_invoices = ZERO
    cumulative_collected_invoices = ZERO
    cumulative_bad_debt_face = ZERO
    incurred_ordinary = ZERO
    paid_ordinary = ZERO
    discretionary_spending = ZERO
    delivery_cost_total = ZERO
    mandatory_cost_total = ZERO
    shutdown_cost_incurred = ZERO
    provider_minutes_total = ZERO
    customer_fixed_months = 0
    requests_total = 0
    accepted_total = ZERO
    backlog = 0
    prior_invoice_units = ZERO
    previous_gross_collection = ZERO
    stopped = not started
    stop_month = 0 if not started else None
    ever_reserve_shortfall = False

    def log_cost(month, owner, kind, components, multiplier=ONE, paid_ratio=ONE):
        for component, unit in components.items():
            incurred = D(unit) * D(multiplier)
            if incurred == ZERO:
                continue  # Source-zero items remain explicit in the frozen anchor.
            ledger.append({"case_id": case.id, "month": month, "owner": owner, "kind": kind,
                           "component": component, "multiplier": D(multiplier), "incurred_usd": incurred,
                           "paid_usd": incurred * paid_ratio, "included_labor_not_charged_again": True})

    if started:
        cash -= startup_quote
        incurred_ordinary += startup_quote
        paid_ordinary += startup_quote
        provider_minutes_total += profile["initial_provider_minutes"]
        log_cost(0, "provider", "startup", profile["initial_components"])
        log_cost(0, "customer", "initial_readiness", profile["customer_initial_components"])
        events.append({"month": 0, "event": "START_ADMITTED", "startup_paid_usd": startup_quote, "setup_workdays": setup_days})
    else:
        events.append({"month": 0, "event": "START_INFEASIBLE", "quoted_startup_usd": startup_quote, "shortfall_usd": startup_shortfall,
                       "incurred_startup_usd": ZERO, "historical_study_cost_usd": None})

    for month in range(1, months + 1):
        opening_cash = cash
        opening_earmark = cash_reserves["earmark"]
        opening_tax = cash_reserves["tax"]
        opening_warranty = cash_reserves["warranty"]
        this_events = []
        if pending_candidate is not None and pending_candidate["due_month"] <= month:
            index = pending_candidate["index"]
            source = inputs["candidate_capabilities"][index]
            record = candidate_records[index]
            passed = case.world == "assumed_diminishing_gain" and bool(source["assumed_diminishing_gain_pass"])
            record["evaluation_month"] = month
            record["simulated_pass"] = passed
            if passed:
                before = current_variable(profile, nonlabor_factor, provider_factor)
                nonlabor_factor *= ONE - D(source["forecast_fractional_nonlabor_saving"])
                provider_factor *= ONE - D(source["forecast_fractional_provider_time_saving"])
                after = current_variable(profile, nonlabor_factor, provider_factor)
                record["promotion_saving_usd_per_request"] = before["total_usd"] - after["total_usd"]
                active_candidates.append(source)
                record["status"] = "PROMOTED_SIMULATED_GAIN"
            else:
                record["status"] = "FAILED_SIMULATED_QUALIFICATION"
            this_events.append({"month": month, "event": record["status"], "candidate": source["id"], "evidence_class": "FROZEN_SIMULATED_OUTCOME_NOT_OBSERVED_DISCOVERY"})
            pending_candidate = None
        if pending_executor is not None and pending_executor["due_month"] <= month:
            instances += 1
            capacity_records[pending_executor["index"]]["activated_month"] = month
            this_events.append({"month": month, "event": "EXECUTOR_ADDITION_ACTIVATED_IN_SIMULATION", "instances": instances})
            pending_executor = None

        # Only prior-month accepted invoices collect. Unpaid fractions become
        # modeled bad debt; month12 invoices never finance this horizon.
        collected_units = prior_invoice_units * D(cfg["collected_fraction_of_accepted_invoices"])
        gross_collection = collected_units * case.price
        refunds = gross_collection * D(cfg["refund_fraction_of_collected"])
        percentage_charges = gross_collection * D(cfg["payment_processing_fraction"])
        fixed_charges = collected_units * D(cfg["processing_usd_per_collected_invoice"])
        net_collection = gross_collection - refunds - percentage_charges - fixed_charges
        cash += net_collection
        cumulative_gross_collections += gross_collection
        cumulative_net_collections += net_collection
        cumulative_refunds += refunds
        cumulative_processing += percentage_charges + fixed_charges
        cumulative_collected_invoices += collected_units
        cumulative_bad_debt_face += prior_invoice_units * case.price - gross_collection
        log_cost(month, "provider", "collection_deductions", {
            "collection.refunds": refunds, "collection.percentage_processing": percentage_charges,
            "collection.fixed_processing": fixed_charges})

        variable = current_variable(profile, nonlabor_factor, provider_factor)
        fixed = current_fixed(profile, inputs, active_candidates, instances)
        limits = resource_limits(profile, variable, fixed, instances)
        requested = 0
        accepted = ZERO
        new_invoice = ZERO
        delivery_cost = ZERO
        fixed_incurred = ZERO
        fixed_paid = ZERO
        obligation_payment = ZERO
        investment_paid = ZERO
        new_earmark = ZERO
        released_this_month = ZERO
        this_provider_minutes = ZERO
        capacity_cash_limit = None
        scheduled_arrivals = profile["arrivals"][month - 1]
        admitted_arrivals = 0
        operating_this_month = False
        shutdown_this_month = False
        remaining_provider_minutes = max(ZERO, limits["remaining"]["provider_minutes"])
        binding = []

        if stopped:
            # Pay a previously incurred shutdown obligation from subsequent
            # collections before describing any residual cash as free.
            available_for_debt = max(ZERO, cash - cash_reserves["tax"] - cash_reserves["warranty"])
            obligation_payment = min(unpaid_shutdown, available_for_debt)
            cash -= obligation_payment
            unpaid_shutdown -= obligation_payment
            paid_ordinary += obligation_payment
            if obligation_payment:
                ledger.append({"case_id": case.id, "month": month, "owner": "provider", "kind": "prior_obligation_payment", "component": "shutdown.prior_incurred_obligation",
                               "multiplier": ONE, "incurred_usd": ZERO, "paid_usd": obligation_payment, "included_labor_not_charged_again": True})
        else:
            protected_existing = cash_reserves["tax"] + cash_reserves["warranty"] + cash_reserves["earmark"]
            if cash < protected_existing + 2 * fixed["total_usd"]:
                stopped = True
                stop_month = month
                shutdown_this_month = True
                released_this_month = cash_reserves["earmark"]
                released_allocation += released_this_month
                cash_reserves["earmark"] = ZERO
                available_for_shutdown = max(ZERO, cash - cash_reserves["tax"] - cash_reserves["warranty"])
                fixed_incurred = fixed["total_usd"]
                fixed_paid = min(fixed_incurred, available_for_shutdown)
                unpaid_shutdown += fixed_incurred - fixed_paid
                cash -= fixed_paid
                incurred_ordinary += fixed_incurred
                paid_ordinary += fixed_paid
                shutdown_cost_incurred += fixed_incurred
                this_provider_minutes = fixed["provider_minutes"]
                customer_fixed_months += 1
                log_cost(month, "provider", "shutdown_support", fixed["components"], paid_ratio=(fixed_paid / fixed_incurred if fixed_incurred > ZERO else ONE))
                log_cost(month, "customer", "shutdown_governance", profile["customer_monthly_components"])
                this_events.append({"month": month, "event": "STOP_OPERATIONS", "reason": "CANNOT_PAY_MANDATORY_COST_AND_RETAIN_PROTECTED_SHUTDOWN_RESERVE",
                                    "shutdown_incurred_usd": fixed_incurred, "shutdown_paid_usd": fixed_paid, "unpaid_obligation_usd": unpaid_shutdown,
                                    "released_unused_earmark_usd": released_this_month})
            else:
                operating_this_month = True
                fixed_incurred = fixed_paid = fixed["total_usd"]
                cash -= fixed_paid
                incurred_ordinary += fixed_incurred
                paid_ordinary += fixed_paid
                mandatory_cost_total += fixed_incurred
                customer_fixed_months += 1
                log_cost(month, "provider", "mandatory_monthly", fixed["components"])
                log_cost(month, "customer", "monthly_governance", profile["customer_monthly_components"])
                admitted_arrivals = scheduled_arrivals
                backlog += admitted_arrivals
                available_request_cash = max(ZERO, cash - protected_existing - fixed["total_usd"])
                capacity_cash_limit = floor_count(available_request_cash / variable["total_usd"])
                requested = min(backlog, limits["request_limit"], capacity_cash_limit)
                all_limits = {**limits["limits"], "demand": backlog, "cash": capacity_cash_limit}
                binding = [k for k, v in all_limits.items() if v == requested]
                backlog -= requested
                accepted = D(requested) * q
                delivery_cost = D(requested) * variable["total_usd"]
                cash -= delivery_cost
                incurred_ordinary += delivery_cost
                paid_ordinary += delivery_cost
                delivery_cost_total += delivery_cost
                requests_total += requested
                accepted_total += accepted
                new_invoice = accepted * case.price
                cumulative_invoices += new_invoice
                this_provider_minutes = fixed["provider_minutes"] + D(requested) * variable["provider_minutes"]
                remaining_provider_minutes = max(ZERO, profile["provider_minutes_ceiling"] - this_provider_minutes)
                log_cost(month, "provider", "delivery_all_attempts_and_failures", variable["components"], D(requested))
                log_cost(month, "customer", "delivery_attention", profile["customer_variable_components"], D(requested))

        # All promoted upkeep remains incurred even in the one shutdown month.
        if operating_this_month or shutdown_this_month:
            ratio = fixed_paid / fixed_incurred if fixed_incurred > ZERO else ONE
            for source in active_candidates:
                record = next(r for r in candidate_records if r["id"] == source["id"])
                record["upkeep_incurred_usd"] += D(source["monthly_upkeep_usd"])
                record["upkeep_paid_usd"] += D(source["monthly_upkeep_usd"]) * ratio
                record["qualified_subsequent_request_uses"] += requested
                record["gross_realized_simulated_savings_usd"] += D(requested) * record["promotion_saving_usd_per_request"]
            for purchase in capacity_records:
                if purchase["activated_month"] is not None and purchase["activated_month"] <= month:
                    purchase["upkeep_incurred_usd"] += D(inputs["capacity_purchase"]["monthly_upkeep_usd"])
                    purchase["upkeep_paid_usd"] += D(inputs["capacity_purchase"]["monthly_upkeep_usd"]) * ratio

        ordinary_income = cumulative_net_collections - incurred_ordinary
        cash_reserves["tax"] = max(cash_reserves["tax"], max(ZERO, ordinary_income) * D(cfg["tax_reserve_fraction_of_positive_cumulative_pre_discretionary_income"]))
        cash_reserves["warranty"] = (gross_collection + previous_gross_collection) * D(cfg["warranty_reserve_fraction_of_last_two_months_collected_proceeds"])
        forecast = project_resources(profile, variable, fixed, instances, month + 1, backlog)
        next_requests = forecast["rows"][0]["requests"] if forecast["rows"] else 0
        cash_reserves["working_capital"] = (D(cfg["working_capital_months"]) * (fixed["total_usd"] + variable["total_usd"] * next_requests)) if operating_this_month else ZERO
        reserve_target = cash_reserves["tax"] + cash_reserves["warranty"] + cash_reserves["working_capital"] + cash_reserves["earmark"]
        reserve_shortfall = max(ZERO, reserve_target - cash)
        ever_reserve_shortfall = ever_reserve_shortfall or reserve_shortfall > ZERO
        recovered_surplus = max(ZERO, ordinary_income - cash_reserves["tax"])
        allocation_ceiling = case.fraction * recovered_surplus
        allocation_room = max(ZERO, allocation_ceiling - lifetime_allocation)
        allocatable_cash = max(ZERO, cash - reserve_target)
        if operating_this_month and unpaid_shutdown == ZERO:
            new_earmark = min(allocation_room, allocatable_cash)
            lifetime_allocation += new_earmark
            cash_reserves["earmark"] += new_earmark
        action = {"kind": "NONE", "reason": "OPERATION_STOPPED" if stopped else "NO_ELIGIBLE_FUNDED_ACTION"}
        action_forecasts = []

        # At most one funded action, from previously collected, recovered cash.
        future_months = months - month
        capacity = inputs["capacity_purchase"]
        action_allowed = operating_this_month and reserve_shortfall == ZERO and future_months >= 2
        capacity_eligible = action_allowed and capacity_purchases < int(capacity["max_purchases"]) and pending_executor is None
        physical = limits["limits"]
        execution_binds = ("executor_seconds" in binding and physical["provider_minutes"] > physical["executor_seconds"] and physical["customer_minutes"] > physical["executor_seconds"])
        if capacity_eligible and execution_binds:
            plus_fixed = current_fixed(profile, inputs, active_candidates, instances + 1)
            plus = project_resources(profile, variable, plus_fixed, instances + 1, month + 1, backlog)
            delta_requests = []
            for before, after in zip(forecast["rows"], plus["rows"]):
                delta_requests.append({"month": before["month"], "requests": after["requests"] - before["requests"]})
            net_per_collected_invoice = case.price * (ONE - D(cfg["refund_fraction_of_collected"]) - D(cfg["payment_processing_fraction"])) - D(cfg["processing_usd_per_collected_invoice"])
            collected_increment = total(D(r["requests"]) * q * D(cfg["collected_fraction_of_accepted_invoices"]) * net_per_collected_invoice for r in delta_requests if r["month"] < months)
            delivery_increment = total(D(r["requests"]) * variable["total_usd"] for r in delta_requests)
            forecast_upkeep = D(future_months) * D(capacity["monthly_upkeep_usd"])
            predicted_net = collected_increment - delivery_increment - forecast_upkeep - D(capacity["setup_usd"])
            details = {"kind": "EXECUTOR", "remaining_resource_baseline_requests": forecast["requests"], "remaining_resource_extra_requests": plus["requests"],
                       "incremental_requests_by_month": delta_requests, "incremental_net_collections_usd": collected_increment,
                       "incremental_delivery_cost_usd": delivery_increment, "remaining_upkeep_usd": forecast_upkeep,
                       "setup_usd": D(capacity["setup_usd"]), "forecast_net_contribution_usd": predicted_net, "forecast_cash_feasibility_established": False}
            action_forecasts.append(details)
            cost = D(capacity["setup_usd"])
            minutes = D(capacity["setup_provider_hours_included_in_cost"]) * 60
            if predicted_net > ZERO and cash_reserves["earmark"] >= cost and remaining_provider_minutes >= minutes:
                capacity_purchases += 1
                investment_paid = cost
                this_provider_minutes += minutes
                remaining_provider_minutes -= minutes
                record = {"id": f"executor_{capacity_purchases}", "funded_month": month, "activated_month": None, "setup_incurred_usd": cost,
                          "upkeep_incurred_usd": ZERO, "upkeep_paid_usd": ZERO, "forecast": details}
                capacity_records.append(record)
                pending_executor = {"due_month": month + 1, "index": len(capacity_records) - 1}
                action = {"kind": "EXECUTOR_PURCHASE", "id": record["id"], "amount_usd": cost, "included_provider_minutes": minutes}
                log_cost(month, "provider", "discretionary_capacity", {"capacity.setup_including_labor": cost})

        if action["kind"] == "NONE" and action_allowed and not candidate_search_stopped and pending_candidate is None and candidate_cursor < len(candidate_records):
            source = inputs["candidate_capabilities"][candidate_cursor]
            record = candidate_records[candidate_cursor]
            savings_per_request = variable["nonlabor_usd"] * D(source["forecast_fractional_nonlabor_saving"]) + variable["labor_usd"] * D(source["forecast_fractional_provider_time_saving"])
            probability_weighted_saving = D(source["forecast_success_probability"]) * savings_per_request
            future_uses = forecast["requests"]
            upkeep = D(future_months) * D(source["monthly_upkeep_usd"])
            cost = D(source["construction_and_evaluation_usd"])
            predicted_net = D(future_uses) * probability_weighted_saving - upkeep - cost
            payback = conditional_division(cost + upkeep, probability_weighted_saving, "NO_POSITIVE_FORECAST_SAVING")
            details = {"kind": "CANDIDATE", "id": source["id"], "remaining_resource_feasible_request_uses": future_uses,
                       "saving_usd_per_request_if_passed": savings_per_request, "forecast_success_probability": source["forecast_success_probability"],
                       "probability_weighted_saving_usd_per_request": probability_weighted_saving, "remaining_possible_upkeep_usd": upkeep,
                       "construction_and_evaluation_usd": cost, "forecast_net_savings_usd": predicted_net,
                       "continuous_payback_request_uses": payback,
                       "integer_payback_request_uses": None if payback["value"] is None else ceil_count(payback["value"]),
                       "forecast_cash_feasibility_established": False}
            action_forecasts.append(details)
            record["last_forecast"] = details
            minutes = D(source["provider_hours_included_in_cash_cost"]) * 60
            if predicted_net <= ZERO:
                candidate_search_stopped = True
                record["status"] = "STOPPED_NONPOSITIVE_REMAINING_HORIZON_PAYBACK"
                action["reason"] = record["status"]
            elif cash_reserves["earmark"] < cost:
                record["status"] = "WAIT_EARNED_EARMARKED_CASH"
                action["reason"] = record["status"]
            elif remaining_provider_minutes < minutes:
                record["status"] = "WAIT_PROVIDER_CONSTRUCTION_TIME"
                action["reason"] = record["status"]
            else:
                investment_paid = cost
                this_provider_minutes += minutes
                remaining_provider_minutes -= minutes
                record.update(status="CONSTRUCTED_AWAITING_SIMULATED_EVALUATION", constructed_month=month, construction_incurred_usd=cost,
                              construction_paid_usd=cost, provider_construction_minutes=minutes, construction_forecast=details)
                pending_candidate = {"index": candidate_cursor, "due_month": month + int(source["evaluation_delay_months"])}
                candidate_cursor += 1
                action = {"kind": "CANDIDATE_CONSTRUCTION", "id": source["id"], "amount_usd": cost, "included_provider_minutes": minutes,
                          "evaluation_due_month": pending_candidate["due_month"]}
                log_cost(month, "provider", "discretionary_capability", {f"candidate.{source['id']}.construction_evaluation_including_labor": cost})
        elif action["kind"] == "NONE" and operating_this_month and future_months < 2:
            action["reason"] = "FEWER_THAN_TWO_FUTURE_OPERATING_MONTHS"
        elif action["kind"] == "NONE" and reserve_shortfall > ZERO:
            action["reason"] = "RESERVE_TARGET_SHORTFALL"

        if investment_paid > ZERO:
            cash -= investment_paid
            cash_reserves["earmark"] -= investment_paid
            discretionary_spending += investment_paid
            this_events.append({"month": month, "event": action["kind"], **action})
        provider_minutes_total += this_provider_minutes
        protected_end = cash_reserves["tax"] + cash_reserves["warranty"] + cash_reserves["working_capital"] + cash_reserves["earmark"] + unpaid_shutdown
        reserve_shortfall_end = max(ZERO, protected_end - cash)
        cash_identity = opening_cash + net_collection - fixed_paid - delivery_cost - investment_paid - obligation_payment - cash
        if abs(cash_identity) > Decimal("0.0000000000000000000001") or cash < -Decimal("0.0000000000000000000001"):
            raise ArithmeticError(f"Cash reconciliation failed: {case.id} month {month}")
        if abs(lifetime_allocation - discretionary_spending - cash_reserves["earmark"] - released_allocation) > Decimal("0.0000000000000000000001"):
            raise ArithmeticError("Allocation counted twice")
        row = {"month": month, "status": "OPERATING" if operating_this_month else ("SHUTDOWN_SUPPORT" if shutdown_this_month else ("START_INFEASIBLE" if not started else "STOPPED")),
               "opening_cash_usd": opening_cash, "prior_accepted_invoice_units_due": prior_invoice_units, "collected_invoice_units": collected_units,
               "gross_collections_usd": gross_collection, "refunds_usd": refunds, "percentage_processing_usd": percentage_charges, "fixed_processing_usd": fixed_charges,
               "net_collections_usd": net_collection, "scheduled_requested_demand": scheduled_arrivals, "admitted_new_demand": admitted_arrivals,
               "requests_served": requested, "expected_accepted": accepted, "expected_unresolved_served": D(requested) - accepted,
               "backlog_arrived_unserved": backlog, "new_invoice_face_usd": new_invoice,
               "provider_variable_cash_per_request_usd": variable["total_usd"], "provider_variable_labor_per_request_usd": variable["labor_usd"],
               "provider_variable_nonlabor_per_request_usd": variable["nonlabor_usd"], "provider_variable_minutes_per_request": variable["provider_minutes"],
               "provider_delivery_incurred_paid_usd": delivery_cost, "mandatory_or_shutdown_incurred_usd": fixed_incurred,
               "mandatory_or_shutdown_paid_usd": fixed_paid, "prior_shutdown_obligation_payment_usd": obligation_payment,
               "unpaid_shutdown_obligation_usd": unpaid_shutdown, "provider_minutes_used": this_provider_minutes,
               "customer_delivery_and_fixed_minutes": (fixed["customer_minutes"] if operating_this_month or shutdown_this_month else ZERO) + D(requested) * variable["customer_minutes"],
               "executor_seconds_used": (fixed["executor_seconds"] if operating_this_month or shutdown_this_month else ZERO) + D(requested) * variable["executor_seconds"],
               "executor_instances": instances, "resource_limits": limits, "cash_request_limit": capacity_cash_limit, "binding_admission_limits": binding,
               "ordinary_cumulative_income_before_discretionary_usd": ordinary_income, "recovered_after_tax_operating_surplus_usd": recovered_surplus,
               "opening_tax_reserve_usd": opening_tax, "opening_warranty_reserve_usd": opening_warranty, "opening_earmark_usd": opening_earmark,
               "tax_reserve_usd": cash_reserves["tax"], "warranty_reserve_usd": cash_reserves["warranty"],
               "next_month_resource_feasible_requests": next_requests, "working_capital_reserve_target_usd": cash_reserves["working_capital"],
               "reserve_target_shortfall_before_action_usd": reserve_shortfall, "reserve_and_obligation_shortfall_end_usd": reserve_shortfall_end,
               "cumulative_allocation_ceiling_usd": allocation_ceiling, "new_earmark_usd": new_earmark,
               "lifetime_allocation_usd": lifetime_allocation, "released_unused_earmark_usd": released_this_month, "idle_earmark_usd": cash_reserves["earmark"],
               "discretionary_spending_usd": investment_paid, "cumulative_discretionary_spending_usd": discretionary_spending,
               "closing_cash_usd": cash, "liquid_free_cash_after_targets_usd": max(ZERO, cash - protected_end),
               "cash_reconciliation_residual_usd": cash_identity, "method_nonlabor_factor": nonlabor_factor, "method_provider_time_factor": provider_factor,
               "remaining_resource_forecast": forecast, "action_forecasts": action_forecasts, "action": action, "events": this_events}
        monthly.append(row)
        events.extend(this_events)
        prior_invoice_units = accepted
        previous_gross_collection = gross_collection

    for record in candidate_records:
        record["net_realized_simulated_return_usd"] = record["gross_realized_simulated_savings_usd"] - record["construction_incurred_usd"] - record["upkeep_incurred_usd"]
        reuse = conditional_division(record["construction_incurred_usd"] + record["upkeep_incurred_usd"], record["promotion_saving_usd_per_request"], "NO_PROMOTED_POSITIVE_GAIN")
        record["realized_horizon_payback_request_uses"] = reuse
        record["integer_realized_horizon_payback_request_uses"] = None if reuse["value"] is None else ceil_count(reuse["value"])
        record["realized_horizon_payback_reached"] = None if reuse["value"] is None else D(record["qualified_subsequent_request_uses"]) >= reuse["value"]

    ordinary_income = cumulative_net_collections - incurred_ordinary
    final_receivable = prior_invoice_units * case.price
    collection_slope = ONE - D(cfg["refund_fraction_of_collected"]) - D(cfg["payment_processing_fraction"])
    diagnostic = {"status": "ONLY_DEFINED_FOR_ZERO_REINVESTMENT_POLICY", "value": None}
    if case.fraction == ZERO:
        if cumulative_collected_invoices > ZERO and collection_slope > ZERO:
            diagnostic = {"status": "COHORT_CONDITIONAL_NOT_A_REPRICED_CASH_PATH", "value": (incurred_ordinary / cumulative_collected_invoices + D(cfg["processing_usd_per_collected_invoice"])) / collection_slope}
        else:
            diagnostic = {"status": "NO_POSITIVE_COLLECTED_INVOICE_SLOPE", "value": None}
    combined_diagnostic = {"status": "NO_POSITIVE_COLLECTED_INVOICE_SLOPE", "value": None}
    if cumulative_collected_invoices > ZERO and collection_slope > ZERO:
        combined_diagnostic = {"status": "COHORT_CONDITIONAL_ALL_INCURRED_COSTS_BEFORE_TAX_RESERVE_NOT_REPRICED_PATH",
                               "value": ((incurred_ordinary + discretionary_spending) / cumulative_collected_invoices + D(cfg["processing_usd_per_collected_invoice"])) / collection_slope}
    status = "START_INFEASIBLE" if not started else ("FAILED_SHUTDOWN_OBLIGATION" if unpaid_shutdown > ZERO else ("STOPPED_WITHOUT_RESTART" if stopped else "OPERATED_FULL_HORIZON"))
    summary = {
        "status": status, "startup_admitted": started, "quoted_startup_usd": startup_quote, "startup_shortfall_usd": startup_shortfall,
        "setup_workdays_before_operating_horizon": setup_days, "initial_virtual_cash_usd": initial_cash,
        "annual_requested_demand": profile["annual_demand"], "requests_served": requests_total, "expected_accepted": accepted_total,
        "expected_unresolved_served": D(requests_total) - accepted_total, "unserved_annual_demand": profile["annual_demand"] - requests_total,
        "acceptance_probability_assumed": q, "operating_months": sum(r["status"] == "OPERATING" for r in monthly),
        "customer_fixed_months": customer_fixed_months, "stop_month": stop_month,
        "accepted_invoice_face_usd": cumulative_invoices, "gross_collections_usd": cumulative_gross_collections,
        "expected_collected_invoice_units": cumulative_collected_invoices, "refunds_usd": cumulative_refunds,
        "payment_processing_usd": cumulative_processing, "net_cash_collections_usd": cumulative_net_collections,
        "uncollected_final_month_receivable_face_usd": final_receivable,
        "expected_collectible_final_receivable_gross_usd": final_receivable * D(cfg["collected_fraction_of_accepted_invoices"]),
        "modeled_past_due_bad_debt_face_usd": cumulative_bad_debt_face,
        "provider_startup_incurred_paid_usd": startup_quote if started else ZERO,
        "provider_mandatory_operating_incurred_usd": mandatory_cost_total, "provider_shutdown_incurred_usd": shutdown_cost_incurred,
        "provider_delivery_incurred_paid_usd": delivery_cost_total, "ordinary_provider_cost_incurred_usd": incurred_ordinary,
        "ordinary_provider_cost_paid_usd": paid_ordinary, "discretionary_construction_and_capacity_paid_usd": discretionary_spending,
        "combined_provider_cost_incurred_usd": incurred_ordinary + discretionary_spending,
        "provider_cost_per_expected_accepted": conditional_division(incurred_ordinary + discretionary_spending, accepted_total),
        "ordinary_income_before_discretionary_usd": ordinary_income,
        "combined_income_before_tax_reserve_usd": ordinary_income - discretionary_spending,
        "combined_income_after_tax_reserve_usd": ordinary_income - discretionary_spending - cash_reserves["tax"],
        "closing_cash_usd": cash, "tax_reserve_usd": cash_reserves["tax"], "warranty_reserve_usd": cash_reserves["warranty"],
        "working_capital_reserve_target_usd": cash_reserves["working_capital"], "idle_earmark_usd": cash_reserves["earmark"],
        "lifetime_allocation_usd": lifetime_allocation, "released_unused_earmarks_usd": released_allocation,
        "unpaid_shutdown_obligation_usd": unpaid_shutdown, "ever_reserve_target_shortfall": ever_reserve_shortfall,
        "closing_reserve_and_obligation_shortfall_usd": monthly[-1]["reserve_and_obligation_shortfall_end_usd"],
        "closing_liquid_free_cash_after_targets_usd": monthly[-1]["liquid_free_cash_after_targets_usd"],
        "provider_minutes_required_including_setup_delivery_improvement": provider_minutes_total,
        "candidate_constructions": sum(r["constructed_month"] is not None for r in candidate_records),
        "simulated_candidates_failed": sum(r["simulated_pass"] is False for r in candidate_records),
        "simulated_candidates_promoted": sum(r["simulated_pass"] is True for r in candidate_records),
        "executor_purchases": capacity_purchases, "final_executor_instances": instances,
        "final_nonlabor_factor": nonlabor_factor, "final_provider_time_factor": provider_factor,
        "zero_reinvestment_break_even_price_usd": diagnostic,
        "combined_cost_conditional_break_even_price_usd": combined_diagnostic,
        "cash_identity_residual_usd": initial_cash + cumulative_net_collections - paid_ordinary - discretionary_spending - cash,
        "invoice_identity_residual_usd": cumulative_invoices - cumulative_gross_collections - cumulative_bad_debt_face - final_receivable,
        "historical_authoring_cost_usd": None, "observed_collected_revenue_usd": None,
        "actual_incremental_capability_gain": None, "cash_flow_evidence_class": "SIMULATED_NOT_COLLECTED_OR_SPENT",
    }
    comparison = customer_comparisons(inputs, anchor, case, profile, summary)
    return {"case_id": case.id, "analysis": case.analysis, "profile": case.profile, "scenario": case.scenario,
            "price_usd_per_accepted": case.price, "reinvestment_fraction": case.fraction, "outcome_world": case.world,
            "demand_multiplier": case.demand_multiplier, "evidence_class": profile["evidence_class"],
            "profile_accounts": profile, "summary": summary, "customer_comparison": comparison,
            "monthly": monthly, "candidates": candidate_records, "capacity_purchases": capacity_records, "events": events,
            "ledger": ledger}


def case_matrix(inputs):
    primary = []
    sensitivity = []
    for profile in ["evidence_pack", "cost_050_hypothesis"]:
        for scenario in inputs["scenarios"]:
            for price in inputs["prices_usd_per_accepted_delivery"]:
                for fraction in inputs["reinvestment_fractions_of_available_surplus"]:
                    for world in inputs["capability_outcome_worlds"]:
                        primary.append(Case(profile, scenario, D(price), D(fraction), world))
        for multiplier in inputs["scenarios"]["base"]["demand_multiplier_sensitivity"]:
            if D(multiplier) == ONE:
                continue
            for fraction in inputs["reinvestment_fractions_of_available_surplus"]:
                for world in inputs["capability_outcome_worlds"]:
                    sensitivity.append(Case(profile, "base", D(20), D(fraction), world, D(multiplier), "demand_sensitivity"))
    if len(primary) != 144 or len(sensitivity) != 32:
        raise ValueError("Frozen scenario cardinality changed")
    return primary, sensitivity


def write_csv(path, rows):
    rows = list(rows)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    columns = list(dict.fromkeys(k for row in rows for k in row))
    with path.open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=columns)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: (json.dumps(plain(v), sort_keys=True) if isinstance(v, (dict, list)) else str(v) if isinstance(v, Decimal) else v) for k, v in row.items()})


def export_results(output, result, all_ledger):
    all_cases = result["primary_cases"] + result["demand_sensitivity_cases"]
    summary_rows = []
    monthly_rows = []
    comparison_rows = []
    event_rows = []
    for case in all_cases:
        identity = {k: case[k] for k in ["case_id", "analysis", "profile", "scenario", "price_usd_per_accepted", "reinvestment_fraction", "outcome_world", "demand_multiplier"]}
        summary_rows.append({**identity, **case["summary"]})
        monthly_rows.extend({**identity, **month} for month in case["monthly"])
        comparison_rows.extend({**identity, **case["customer_comparison"]["common"], **comparison} for comparison in case["customer_comparison"]["comparisons"])
        event_rows.extend({**identity, **event} for event in case["events"])
    write_csv(output / "results_summary.csv", summary_rows)
    write_csv(output / "monthly_cash_ledger.csv", monthly_rows)
    write_csv(output / "customer_comparisons.csv", comparison_rows)
    write_csv(output / "event_ledger.csv", event_rows)
    write_csv(output / "cost_ledger.csv", all_ledger)
    result["derivative_files"] = {name: {"sha256": sha256(output / name), "bytes": (output / name).stat().st_size} for name in ["results_summary.csv", "monthly_cash_ledger.csv", "customer_comparisons.csv", "event_ledger.csv", "cost_ledger.csv"]}
    save_json(output / "results.json", result)
    save_json(output / "RUN_MANIFEST.json", {"schema": "cash-reinvestment-run-manifest/v1", "results_sha256": sha256(output / "results.json"),
                                           "model_sha256": sha256(Path(__file__)), "identities": result["identities"],
                                           "primary_cases": len(result["primary_cases"]), "sensitivity_cases": len(result["demand_sensitivity_cases"]),
                                           "monthly_rows": len(monthly_rows), "cost_ledger_rows": len(all_ledger),
                                           "financial_transactions": "NOT_RUN", "actual_collected_revenue": None})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--out", type=Path, required=True, help="New absent output directory; previous attempts are never overwritten")
    args = parser.parse_args()
    root = args.root.resolve()
    authorization = verify_authorization(root)
    output = args.out.resolve()
    if output.exists():
        raise RuntimeError("Refusing to overwrite a prior attempt")
    if not output.is_relative_to(root):
        raise RuntimeError("Output must remain in this separate amendment")
    output.mkdir(parents=True)
    shutil.copyfile(__file__, output / "MODEL_ATTEMPT.py")
    try:
        inputs = read_json(root / "inputs.json")
        anchor = read_json(root / "prior_model_anchor.json")
        partitions = partition_check(anchor)
        primary, sensitivity = case_matrix(inputs)
        identity_files = ["PROTOCOL.md", "inputs.json", "prior_model_anchor.json", "token_scenarios.json", "contracts/SOURCE_REGISTER.json", "contracts/FLOW_MATRIX.json", "contracts/ROUTE_CONSTANTS.json"]
        identities = {name: sha256(root / name) for name in identity_files}
        identities.update(model_sha256=sha256(Path(__file__)), **authorization)
        result = {"schema": "agi-alpha-cash-reinvestment-results/v1", "evidence_class": "FROZEN_FORWARD_SIMULATION_NOT_OBSERVED_COMMERCIAL_OPERATION",
                  "identities": identities, "python": platform.python_version(), "arithmetic": "Decimal precision48 internally; JSON numbers serialize to finite IEEE754 values",
                  "provider_account_partition": partitions, "primary_cases": [], "demand_sensitivity_cases": [],
                  "boundaries": {"actual_transactions": "NOT_RUN", "observed_collected_revenue": None, "dynamic_asset": "ordinary USD proposed invoicing only",
                                 "token_waterfalls": "separate source-mechanism scenarios, not consolidated or executed",
                                 "live_authenticated_executor": "NOT_RUN", "unvalidated_capacity_constraints": inputs["unvalidated_capacity_constraints"],
                                 "native_anchor": anchor["native_observation"], "unknowns_not_zero": inputs["unknowns_not_zero"],
                                 "failed_jobs": "All prior expected path costs included per requested job; only expected accepted jobs invoice",
                                 "human_baseline": "Traditional ordinary non-AI work; productive duration sensitivity, not a matched human trial",
                                 "hypothesis": "USD0.50 base variable delivery and USD200 traditional replacement are unvalidated assumptions",
                                 "improvement_outcomes": "Frozen simulated worlds; no observed capability gain or self-acceleration claim"}}
        ledger = []
        for index, case in enumerate(primary + sensitivity, 1):
            value = run_case(inputs, anchor, case)
            ledger.extend(value.pop("ledger"))
            target = "primary_cases" if case.analysis == "primary" else "demand_sensitivity_cases"
            result[target].append(value)
            if index % 24 == 0:
                print(f"Completed {index}/{len(primary) + len(sensitivity)} frozen simulated paths", flush=True)
        export_results(output, result, ledger)
        print(json.dumps({"status": "COMPLETE_PENDING_INDEPENDENT_AUDIT", "results": str(output / "results.json"), "primary_cases": len(primary), "sensitivity_cases": len(sensitivity), "result_sha256": sha256(output / "results.json")}, indent=2))
    except Exception:
        save_json(output / "FAILURE.json", {"status": "FAILED_IMPLEMENTATION_ATTEMPT", "model_sha256": sha256(Path(__file__)), "authorization": authorization, "traceback": traceback.format_exc(), "frozen_inputs_edited": False})
        raise


if __name__ == "__main__":
    main()
