# SPDX-License-Identifier: Apache-2.0
"""Separate source-mechanism waterfalls, with hypothetical USD realization.

No wallets, chain calls, transactions, quotations, exchanges or provider calls.
Contract arithmetic uses integer atomic units; realization is a continuous
valuation simulation governed by the separately frozen token_scenarios.json.
"""
from __future__ import annotations

import argparse
import shutil
import traceback
from pathlib import Path

from financial_model import D, ZERO, ONE, ROOT, ceil_count, read_json, save_json, sha256, verify_authorization, write_csv


def atomic(amount, decimals):
    value = D(amount) * (10 ** decimals)
    if value != value.to_integral_value():
        raise ValueError("Frozen quoted amount does not resolve to atomic units")
    return int(value)


def quantities(mapping):
    """Atomic units remain strings to avoid JavaScript integer precision loss."""
    return {name: str(value) for name, value in mapping.items()}


def units(value, decimals):
    return D(value) / D(10 ** decimals)


def manager_bonds(payout, cfg):
    basis = max(payout * int(cfg["agent_bond_bps"]) // 10000, int(cfg["agent_bond_min_atomic"]))
    limit = int(cfg["job_duration_limit_seconds_assumed"])
    premium = basis * int(cfg["job_duration_seconds_assumed"]) // limit if limit else 0
    worker = basis + premium
    maximum = int(cfg["agent_bond_max_atomic"])
    if maximum:
        worker = min(worker, maximum)
    worker = min(worker, payout)
    validator = min(payout, int(cfg["validator_bond_max_atomic"]), max(payout * int(cfg["validator_bond_bps"]) // 10000, int(cfg["validator_bond_min_atomic"])))
    return worker, validator, basis, premium


def contract_successes(inputs):
    rows = []
    failures = []
    quote = D(inputs["hypothetical_usd_per_agialpha_at_quote"])
    for price_source in inputs["quoted_job_amounts_usd"]:
        price = D(price_source)
        # Manager: all three configured reviewers are correct; unallocated
        # micro-USDC validation dust goes to the worker, not treasury.
        cfg = inputs["manager"]
        payout = atomic(price, 6)
        n, k = int(cfg["validators"]), int(cfg["correct_validators"])
        if n != k or int(cfg["validator_slashes"]) != 0:
            raise ValueError("Frozen Manager example requires all correct reviewers and no slashes")
        budget = payout * int(cfg["validator_budget_percent"]) // 100 if n else 0
        each = budget // k if k else 0
        residue = budget - each * k
        share30 = payout * int(cfg["wallet30_percent"]) // 100
        share10 = payout * int(cfg["wallet10_percent"]) // 100
        worker = payout - budget - share30 - share10 + residue
        worker_bond, validator_bond, bond_basis, premium = manager_bonds(payout, cfg)
        assert worker + each * k + share30 + share10 == payout
        rows.append({"route": "manager_usdc", "quoted_job_amount_usd": price,
                     "quoted_amount_meaning": inputs["quoted_amount_meaning"]["manager_usdc"],
                     "asset": "USDC", "decimals": 6, "quote_usd_per_asset_unit": ONE,
                     "atomic": quantities({"customer_escrow": payout, "worker_customer_funded_award": worker,
                                           "validator_budget": budget, "each_correct_validator_award": each,
                                           "total_validator_awards": each * k, "validator_dust_to_worker": residue,
                                           "wallet30": share30, "wallet10": share10, "burn": 0,
                                           "worker_bond": worker_bond, "worker_bond_before_duration_premium": bond_basis,
                                           "worker_bond_duration_premium": premium, "each_validator_bond": validator_bond,
                                           "all_validator_bonds": validator_bond * n,
                                           "returned_worker_bond_separate_from_income": worker_bond,
                                           "returned_validator_bonds_separate_from_income": validator_bond * n,
                                           "customer_refund": 0, "worker_admission_floor": 0,
                                           "customer_escrow_conservation_residual": 0}),
                     "enterprise_role": cfg["enterprise_role"],
                     "source_refs": ["manager_settlement:L111-L133", "manager_bond_math:L6-L41"],
                     "conditions": "Configured native USDC, three correct reviewers, buyer acceptance, named unrelated fee wallets; defined claims, no observed payments or issuer-state qualification."})
        failures.append({"route": "manager_usdc", "quoted_job_amount_usd": price, "outcome": "ASSIGNED_EXPIRY_BEFORE_COMPLETION",
                         "asset": "USDC", "atomic": quantities({"customer_initial_escrow": payout, "worker_initial_bond": worker_bond,
                         "employer_escrow_refund": payout, "worker_bond_to_employer": worker_bond,
                         "total_employer_award_or_claim": payout + worker_bond, "worker_income": 0,
                         "worker_bond_lost": worker_bond, "burn": 0, "wallet30": 0, "wallet10": 0,
                         "conservation_residual": payout + worker_bond - (payout + worker_bond)}),
                         "scope": "Assigned expiry has no submitted-completion reviewer bonds; no gas or enterprise failure cost scenario is specified.",
                         "failure_gas_usd": None, "source_refs": ["manager:L1186-L1201"]})

        cfg = inputs["ascension"]
        bid = atomic(price / quote, 18)
        bounty = bid
        each = (bid * int(cfg["validator_pool_bps_source"]) // 10000) // int(cfg["approving_validators"])
        gross_worker = bid - each * int(cfg["approving_validators"])
        worker_burn = gross_worker // 100
        each_burn = each // 100
        worker = gross_worker - worker_burn
        validator_net = each - each_burn
        validators = int(cfg["approving_validators"])
        burn = worker_burn + validators * each_burn
        floor = atomic(cfg["chosen_market_minimum_stake_tokens"], 18)
        bond = max(bounty // 10, floor)
        assert worker + validators * validator_net + burn == bid
        rows.append({"route": "ascension_agialpha", "quoted_job_amount_usd": price,
                     "quoted_amount_meaning": inputs["quoted_amount_meaning"]["ascension_agialpha"],
                     "asset": "AGIALPHA", "decimals": 18, "quote_usd_per_asset_unit": quote,
                     "atomic": quantities({"customer_escrow": bounty, "winning_bid": bid,
                                           "worker_gross_award": gross_worker, "worker_customer_funded_award": worker,
                                           "each_validator_gross_award": each, "each_validator_net_award": validator_net,
                                           "total_validator_awards": validators * validator_net, "worker_burn": worker_burn,
                                           "each_validator_burn": each_burn, "burn": burn, "worker_bond": bond,
                                           "worker_market_minimum": floor, "worker_admission_floor": floor,
                                           "worker_bond_unlocked_not_new_income": bond, "customer_refund": bounty - bid,
                                           "customer_escrow_conservation_residual": 0}),
                     "enterprise_role": cfg["enterprise_role"],
                     "source_refs": ["alpha_market:L105-L140", "alpha_market:L183-L249"],
                     "conditions": "Admitted worker, two eligible approvers, B=P; ten-token minimum explicitly chosen from a historical example, not current-chain state."})
        bond_burn = bond // 100
        failures.append({"route": "ascension_agialpha", "quoted_job_amount_usd": price, "outcome": "ASSIGNED_DEFAULT_OR_TWO_ELIGIBLE_REJECTIONS",
                         "asset": "AGIALPHA", "atomic": quantities({"customer_initial_escrow": bounty, "worker_initial_bond": bond,
                         "client_full_bounty_refund": bounty, "worker_bond_added_to_client_refund": bond - bond_burn,
                         "total_client_claimable_refund": bounty + bond - bond_burn, "worker_income": 0,
                         "worker_bond_lost": bond, "burn": bond_burn, "conservation_residual": 0}),
                         "scope": "Refund is source-defined and claimable by original client; no transaction or withdrawal performed.",
                         "failure_gas_usd": None, "source_refs": ["alpha_market:L221-L249"]})
        failures.append({"route": "ascension_agialpha", "quoted_job_amount_usd": price, "outcome": "SUBMITTED_WITHOUT_REVIEW_QUORUM",
                         "asset": "AGIALPHA", "atomic": quantities({"customer_initial_escrow": bounty, "worker_initial_bond": bond,
                         "client_claimable_refund": bounty, "worker_stake_unlocked_and_preserved": bond,
                         "worker_income": 0, "worker_bond_lost": 0, "burn": 0, "conservation_residual": 0}),
                         "scope": "Stake unlock is not a withdrawal or revenue; all original principal is separately preserved.",
                         "failure_gas_usd": None, "source_refs": ["alpha_market:L234-L249"]})

        cfg = inputs["jobs_v0"]
        reward = atomic(price / quote, 18)
        fee = reward * int(cfg["fee_percent_config_example"]) // 100
        escrow = reward + fee
        validators_gross = reward * int(cfg["validator_reward_percent_config_example"]) // 100
        reward_after = reward - validators_gross
        modified = reward_after * int(cfg["agent_payout_multiplier_percent_assumed"]) // 100
        reserve_draw = max(0, modified - reward_after)
        if reserve_draw != int(cfg["worker_boost_reserve_draw"]):
            raise ValueError("Frozen worker boost reserve draw differs from payout multiplier")
        worker_burn = modified * int(cfg["worker_burn_percent_config_example"]) // 100
        worker = modified - worker_burn
        fee_burn = fee * int(cfg["fee_pool_burn_percent_config_example"]) // 100
        pending_fees = fee - fee_burn
        bond = (reward * int(cfg["job_stake_bps_config_example"]) + 9999) // 10000
        admission_floor = atomic(cfg["agent_admission_minimum_tokens_config_example"], 18)
        assert worker + validators_gross + worker_burn + fee_burn + pending_fees == escrow + reserve_draw
        rows.append({"route": "jobs_v0_agialpha_success_only", "quoted_job_amount_usd": price,
                     "quoted_amount_meaning": inputs["quoted_amount_meaning"]["jobs_v0_agialpha_success_only"],
                     "asset": "AGIALPHA", "decimals": 18, "quote_usd_per_asset_unit": quote,
                     "atomic": quantities({"quoted_reward": reward, "additional_customer_fee": fee, "customer_escrow": escrow,
                                           "validator_allocation_total": validators_gross, "worker_gross_modified_award": modified,
                                           "worker_customer_funded_award": worker, "worker_burn": worker_burn, "fee_pool_burn": fee_burn,
                                           "burn": worker_burn + fee_burn, "fee_pool_pending_claims_increment": pending_fees,
                                           "prefunded_operator_pool_draw": reserve_draw, "worker_bond": bond,
                                           "worker_admission_floor": admission_floor, "worker_bond_released_not_new_income": bond,
                                           "customer_refund": 0, "customer_escrow_conservation_residual": 0}),
                     "enterprise_role": cfg["enterprise_role"], "failure_economics": cfg["failure_economics"],
                     "source_refs": ["jobs_registry_base:L1481-L1562", "jobs_registry_base:L2040-L2136", "jobs_stake_base:L2327-L2484", "jobs_fee:L239-L365"],
                     "conditions": "Explicit config example; sufficient escrow; FeePool enabled; eligible boosted Platform stake; m=100; subsequent individual FeePool claims/dust not modeled without stake weights."})
    return rows, failures


def realization(inputs, source_row, scenario_name, cfg):
    decimals = source_row["decimals"]
    award_atomic = int(source_row["atomic"]["worker_customer_funded_award"])
    bond_atomic = int(source_row["atomic"]["worker_bond"])
    admission_atomic = int(source_row["atomic"]["worker_admission_floor"])
    count = int(inputs["accepted_settlements_in_example_month"])
    days = int(inputs["calendar_days_in_example_month"])
    quote = D(source_row["quote_usd_per_asset_unit"])
    monthly_units = units(award_atomic * count, decimals)
    if source_row["asset"] == "AGIALPHA":
        value_ratio = D(cfg["agialpha_value_fraction_at_realization"])
        slippage = D(cfg["agialpha_slippage_fraction"])
        fee = D(cfg["agialpha_conversion_fee_fraction"])
        net_unit_conversion = quote * value_ratio * (ONE - slippage) * (ONE - fee)
    else:
        value_ratio = D(cfg["usdc_usd_realization_fraction"])
        slippage = ZERO  # Explicit USDC rule has realization and fee, no slippage term.
        fee = D(cfg["usdc_conversion_fee_fraction"])
        net_unit_conversion = value_ratio * (ONE - fee)
    potential = monthly_units * net_unit_conversion
    liquid = min(max(ZERO, potential), D(cfg["usd_conversion_liquidity_limit_per_month"]))
    converted_units = liquid / net_unit_conversion if net_unit_conversion > ZERO else ZERO
    inventory = monthly_units - converted_units
    gas = D(count) * D(cfg["worker_gas_usd_per_settlement_allowance"])
    net_cash = liquid - gas
    open_positions = ceil_count(D(count) * D(cfg["collateral_lock_days"]) / D(days))
    bonded_atomic = bond_atomic * open_positions
    required_atomic = max(bonded_atomic, admission_atomic)
    collateral_quote_usd = units(required_atomic, decimals) * quote
    imputed_cost = collateral_quote_usd * D(cfg["annual_imputed_capital_cost_fraction"]) * D(days) / D(365)
    escrow_quote_usd = units(int(source_row["atomic"]["customer_escrow"]), decimals) * quote
    return {
        "case_id": source_row["route"] + "__quote" + format(D(source_row["quoted_job_amount_usd"]), "f") + "__" + scenario_name,
        "route": source_row["route"], "realization_scenario": scenario_name, "quoted_job_amount_usd": source_row["quoted_job_amount_usd"],
        "quoted_amount_meaning": source_row["quoted_amount_meaning"], "asset": source_row["asset"], "asset_decimals": decimals,
        "customer_total_escrow_quote_usd_per_job": escrow_quote_usd,
        "worker_award_asset_units_per_job": format(units(award_atomic, decimals), "f"),
        "worker_award_quote_usd_per_job_before_realization": units(award_atomic, decimals) * quote,
        "worker_award_fraction_of_gross_customer_escrow": D(award_atomic) / D(int(source_row["atomic"]["customer_escrow"])),
        "monthly_accepted_settlements_assumed": count, "monthly_worker_award_atomic": str(award_atomic * count),
        "monthly_worker_award_asset_units": format(monthly_units, "f"),
        "quote_usd_per_asset_unit_assumed": quote, "realization_value_fraction_assumed": value_ratio,
        "slippage_fraction_assumed": slippage, "conversion_fee_fraction_assumed": fee,
        "net_conversion_usd_per_asset_unit_assumed": net_unit_conversion,
        "potential_monthly_conversion_value_usd": potential,
        "monthly_conversion_liquidity_limit_usd": cfg["usd_conversion_liquidity_limit_per_month"],
        "monthly_cash_realized_in_simulation_usd": liquid,
        "converted_asset_units_continuous_valuation_estimate": format(converted_units, "f"),
        "unconverted_asset_units_continuous_valuation_estimate": format(inventory, "f"),
        "unconverted_inventory_quote_value_usd_not_cash": inventory * quote,
        "unconverted_net_conversion_value_usd_not_cash": potential - liquid,
        "worker_settlement_gas_allowance_usd": gas,
        "monthly_realized_cash_after_worker_gas_usd": net_cash,
        "cash_funding_gap_for_gas_usd": max(ZERO, -net_cash),
        "collateral_lock_days_assumed": cfg["collateral_lock_days"], "required_open_positions": open_positions,
        "worker_bond_per_job_atomic": str(bond_atomic), "concurrent_worker_bond_stock_atomic": str(bonded_atomic),
        "separate_worker_admission_floor_atomic": str(admission_atomic), "required_worker_collateral_stock_atomic": str(required_atomic),
        "required_collateral_stock_quote_usd": collateral_quote_usd,
        "monthly_imputed_capital_cost_usd_not_cash_loan": imputed_cost,
        "cash_after_gas_minus_imputed_capital_cost_usd": net_cash - imputed_cost,
        "enterprise_delivery_setup_review_overhead_tax_reserves_deducted": False,
        "profit_or_reinvestment_surplus_established": False,
        "evidence_class": "SOURCE_ARITHMETIC_PLUS_FROZEN_REALIZATION_ASSUMPTIONS_NO_TRANSACTIONS",
        "source_success_case": source_row,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    root, output = args.root.resolve(), args.out.resolve()
    authorization = verify_authorization(root)
    if output.exists() or not output.is_relative_to(root):
        raise RuntimeError("Use a new absent output directory within this amendment")
    output.mkdir(parents=True)
    shutil.copyfile(__file__, output / "MODEL_ATTEMPT.py")
    try:
        inputs = read_json(root / "token_scenarios.json")
        source_rows, failures = contract_successes(inputs)
        rows = [realization(inputs, source, name, scenario) for source in source_rows for name, scenario in inputs["realization_scenarios"].items()]
        if len(rows) != 27 or len(failures) != 9:
            raise ValueError("Frozen token example cardinality changed")
        result = {"schema": "agi-alpha-source-settlement-waterfalls/v1", "identities": {**authorization,
                  "token_inputs_sha256": sha256(root / "token_scenarios.json"), "source_register_sha256": sha256(root / "contracts/SOURCE_REGISTER.json"),
                  "source_constants_sha256": sha256(root / "contracts/ROUTE_CONSTANTS.json"), "model_sha256": sha256(Path(__file__)),
                  "shared_io_authorization_module_sha256": sha256(Path(__file__).with_name("financial_model.py"))},
                  "source_success_waterfalls": source_rows, "realization_cases": rows, "failure_examples": failures,
                  "not_modeled": {"jobs_v0_failed_or_no_quorum_numeric_economics": inputs["jobs_v0"]["failure_economics"],
                                  "actual_transactions": "NOT_RUN", "current_chain_state": "NOT_INDEPENDENTLY_VERIFIED",
                                  "enterprise_net_profit_or_reinvestment": "NOT_ESTABLISHED_BY_SETTLEMENT_PROCEEDS",
                                  "automatic_tokenholder_dividend_buyback_or_50pct_policy": "NOT_IMPLEMENTED_BY_INSPECTED_SOURCE",
                                  "failure_gas_and_full_enterprise_failure_cost": None},
                  "precision": "Contract amounts use integer atomic units stored as decimal strings. Hypothetical fiat realization follows the frozen continuous min(value,liquidity) rule; fractional continuous inventory estimates are not executable transfer quantities.",
                  "cash_bridge_to_dynamic_model": "NONE; dynamic ordinary-USD and token settlement scenarios are separate"}
        flat_rows = [{k: v for k, v in row.items() if k != "source_success_case"} for row in rows]
        write_csv(output / "token_waterfalls.csv", flat_rows)
        write_csv(output / "failure_examples.csv", failures)
        save_json(output / "token_waterfalls.json", result)
        save_json(output / "RUN_MANIFEST.json", {"results_sha256": sha256(output / "token_waterfalls.json"), "model_sha256": sha256(Path(__file__)), "success_realization_cases": len(rows), "failure_examples": len(failures), "transactions": "NOT_RUN"})
        print({"status": "COMPLETE_PENDING_INDEPENDENT_AUDIT", "results": str(output / "token_waterfalls.json"), "cases": len(rows), "failure_examples": len(failures), "sha256": sha256(output / "token_waterfalls.json")})
    except Exception:
        save_json(output / "FAILURE.json", {"status": "FAILED_IMPLEMENTATION_ATTEMPT", "model_sha256": sha256(Path(__file__)), "traceback": traceback.format_exc(), "frozen_inputs_edited": False})
        raise


if __name__ == "__main__":
    main()
