# Reinvestment amendment figures

Three final figures are available as editable SVG, publication PDF and PNG:

- `economic_engine_flow`: recorded useful work, external source inputs, assumed customer value, collected cash, complete expenses and reserves, allocation, and actual simulated investment.
- `cash_and_investment`: selected audited ordinary-USD cash paths, failed and promoted candidates, actual spending, and idle allocation. The USD 0.50 profile and 4× demand are explicitly hypothetical; closing cash includes initial capital.
- `settlement_routes`: distinct source-linked USDC and AGIALPHA waterfalls, exact asset units and separately assumed realizable cash. Worker receipts are not enterprise profit; source inspection is not current-chain verification or actual transaction execution.

From `reinvestment_amendment_v1/`, rebuild with:

```sh
python figures/build_figures.py \
  --results outputs/run-002/results.json \
  --token-results outputs/token-run-002/token_waterfalls.json \
  --cash-audit evaluation/INDEPENDENT_AUDIT.json \
  --token-audit evaluation/TOKEN_AUDIT.json
```

The generator reads the audited rows and verifies their bindings; it does not run financial scenarios. `figure_data.json` exposes every selected quantity and pointer. `evaluation/FIGURE_DATA_AUDIT.json` independently checks all 91 quantities. `BUILD_MANIFEST.json` gives output hashes, and `VISUAL_QA.json` records inspection of all three rendered PDFs. Internal `*_pdf_render.png` images document layout QA; ordinary PNG exports are shareable figures.

`cash_and_asset_flow.svg` and `FLOW_BUILD_MANIFEST.json` preserve the earlier nonnumeric development stage. They are not the final paper figures. No original study or figure was modified, and no automatic token-to-reinvestment cash conversion is claimed.
