# SPDX-License-Identifier: Apache-2.0
"""Editable publication figures. Source rows are never financial model execution."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path

os.environ.setdefault("MPLCONFIGDIR", "/tmp/agi-alpha-reinvestment-mpl")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch
from matplotlib.ticker import FuncFormatter

ROOT = Path(__file__).resolve().parents[1]
HERE = ROOT / "figures"
FREEZE_SHA = "4c7bac19106f946920d64ad39b01cb2cc844eed78c5cdb4d79140904a10cc9ba"
INK = "#17344d"
MUTED = "#536d81"
BLUE = "#185fa7"
TEAL = "#087e73"
AMBER = "#9e681f"
RED = "#a34535"
PALE = "#f0f5f9"
STAMP = datetime(2026, 10, 25, tzinfo=timezone.utc)
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "svg.fonttype": "none", "svg.hashsalt": "agi-alpha-reinvestment-v1", "pdf.fonttype": 42, "axes.labelcolor": INK, "text.color": INK, "axes.edgecolor": "#c7d5df", "xtick.color": MUTED, "ytick.color": MUTED})


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(fig, name: str):
    files = []
    for suffix in ("pdf", "svg", "png"):
        path = HERE / f"{name}.{suffix}"
        metadata = {"Creator": "AGI ALPHA reproducible research figure", "CreationDate": STAMP, "ModDate": STAMP} if suffix == "pdf" else {"Date": STAMP.isoformat()} if suffix == "svg" else {"Software": "AGI ALPHA research figure"}
        fig.savefig(path, dpi=180, bbox_inches="tight", pad_inches=.08, metadata=metadata, facecolor="white")
        files.append({"path": path.name, "bytes": path.stat().st_size, "sha256": digest(path)})
    plt.close(fig)
    return files


def node(ax, x, y, w, h, title, detail, color=PALE, edge="#c8d8e3", title_size=9.5):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.009,rounding_size=0.015", facecolor=color, edgecolor=edge, linewidth=.9))
    ax.text(x+.018, y+h-.027, title, va="top", fontsize=title_size, weight="bold")
    ax.text(x+.018, y+h-.074, detail, va="top", fontsize=7.8, linespacing=1.45, color=MUTED)


def arrow(ax, start, end, dashed=False, connection="arc3,rad=0"):
    ax.add_patch(FancyArrowPatch(start, end, arrowstyle="-|>", mutation_scale=10, linewidth=1.1, color="#6a8395", linestyle="--" if dashed else "-", connectionstyle=connection))


def economic_engine_flow():
    fig = plt.figure(figsize=(7.2, 5.7))
    ax = fig.add_axes([.02,.02,.96,.96])
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
    ax.text(.01, .985, "Useful delivery and the separate financial hypothesis", fontsize=13, weight="bold", va="top")
    ax.text(.01, .929, "OBSERVED NATIVE COMPONENT", fontsize=8, weight="bold", color=TEAL)
    node(ax, .01, .755, .45, .15, "A finished source-backed brief", "Four passages, provenance and slides\nFrozen fidelity/coverage checks\nFull Agent cost remains unknown", "#eaf5f0", "#abd0bd")
    node(ax, .52, .755, .46, .15, "A method can be retained", "Executable procedure and source identities\nOriginal local successor invocation\nAvailable in the preserved companion", "#eaf5f0", "#abd0bd")
    arrow(ax, (.47,.835),(.51,.835))
    ax.text(.01, .719, "ASSUMED BUSINESS + FINANCIAL SIMULATION", fontsize=8, weight="bold", color=AMBER)
    node(ax,.01,.535,.29,.15,"Accepted-work invoices","Full invoice price owed\nNot yet collected cash")
    node(ax,.355,.535,.29,.15,"Net collected cash","Delay, refunds and fees\nInitial capital excluded")
    node(ax,.70,.535,.28,.15,"Complete paid costs","Delivery, people and setup\nSupport and failed requests")
    arrow(ax,(.305,.619),(.348,.619)); arrow(ax,(.652,.619),(.692,.619))
    node(ax,.70,.320,.28,.15,"Protected balances","Tax, warranty and runway\nUnpaid obligations retained")
    node(ax,.355,.320,.29,.15,"Available surplus","Earned, collected and free\nAllocation limits spending", "#fff3e0", "#e0c69f")
    node(ax,.01,.320,.29,.15,"Funded next method","Cash, time and payback gates\nFailed construction is a cost")
    arrow(ax,(.84,.539),(.84,.470));arrow(ax,(.692,.391),(.652,.391));arrow(ax,(.348,.391),(.305,.391))
    arrow(ax,(.155,.470),(.155,.539),True)
    ax.text(.01,.263,"Next-month outcomes and diminishing gains are assumptions, not new discoveries.",fontsize=8,color=AMBER)
    ax.axhline(.227, xmin=.01, xmax=.98, color="#d4e0e8", linewidth=.8)
    ax.text(.01,.190,"SOURCE INSPECTION: SEPARATE ASSET ROUTES",fontsize=8,weight="bold",color=BLUE)
    ax.text(.01,.139,"USDC / AGIALPHA escrow",fontsize=8.5,weight="bold")
    ax.text(.37,.139,"Identified worker receipt",fontsize=8.5,weight="bold")
    ax.text(.73,.139,"Assumed conversion",fontsize=8.5,weight="bold")
    arrow(ax,(.315,.146),(.355,.146));arrow(ax,(.675,.146),(.717,.146))
    ax.text(.01,.090,"Fees, burns, refunds and collateral stay separate. No automatic cash bridge or profit right.",fontsize=7.7,color=MUTED)
    ax.text(.01,.027,"Actual collections, financial transactions and authenticated executor: NOT RUN.",fontsize=8,weight="bold",color=RED)
    return save(fig,"economic_engine_flow")


def item(document, pointer):
    value=document
    for part in pointer.strip("/").split("/"):
        value=value[int(part)] if isinstance(value,list) else value[part]
    return value


def cash_and_investment(cash, register):
    specs=[
        ("primary_cases","evidence_pack",1,"no_gain","Evidence pack",BLUE),
        ("primary_cases","cost_050_hypothesis",1,"no_gain","Unvalidated offering",TEAL),
        ("demand_sensitivity_cases","cost_050_hypothesis",4,"no_gain","4x demand: no gain",RED),
        ("demand_sensitivity_cases","cost_050_hypothesis",4,"assumed_diminishing_gain","4x: assumed gains",TEAL),
    ]
    selected=[]
    for group,profile,demand,world,label,color in specs:
        matches=[(i,c) for i,c in enumerate(cash[group]) if c["profile"]==profile and c["scenario"]=="base" and c["price_usd_per_accepted"]==20 and c["reinvestment_fraction"]==.5 and c["demand_multiplier"]==demand and c["outcome_world"]==world]
        assert len(matches)==1
        index,row=matches[0];selected.append((row,f"/{group}/{index}",label,color))
    fig=plt.figure(figsize=(7.2,5.4))
    grid=fig.add_gridspec(2,2,left=.085,right=.98,bottom=.20,top=.79,hspace=.56,height_ratios=[1.4,1])
    ax1=fig.add_subplot(grid[0,0]);ax2=fig.add_subplot(grid[0,1]);table_ax=fig.add_subplot(grid[1,:]);table_ax.axis("off")
    fig.text(.02,.965,"Simulated cash can remain idle",fontsize=14,weight="bold")
    fig.text(.02,.925,"Base assumptions · USD 20 accepted-job price · 50% maximum surplus allocation",fontsize=8.5,color=MUTED)
    fig.text(.02,.883,"ALL FINANCIAL VALUES ARE SIMULATED. The USD 0.50 / USD 200 offering is unvalidated.",fontsize=8,color=AMBER,weight="bold")
    for n,(row,pointer,label,color) in enumerate(selected):
        ax=ax1 if n<2 else ax2
        months=[0]+[m["month"] for m in row["monthly"]]
        opening=register("cash",pointer+"/monthly/0/opening_cash_usd","cash_and_investment")
        values=[opening]+[register("cash",pointer+f"/monthly/{i}/closing_cash_usd","cash_and_investment") for i in range(len(row["monthly"]))]
        ax.plot(months,values,color=color,linewidth=1.8,linestyle="--" if n==3 else "-",label=label)
    ax1.set_title("Primary demand: distinct profiles",fontsize=9,loc="left",pad=10,weight="bold")
    ax2.set_title("4x demand sensitivity: hypothesis only",fontsize=9,loc="left",pad=10,weight="bold")
    for ax in (ax1,ax2):
        ax.set_xlabel("Operating month after setup",fontsize=8)
        ax.set_xticks([0,3,6,9,12]);ax.tick_params(labelsize=7.5)
        ax.yaxis.set_major_formatter(FuncFormatter(lambda v,_:f"{v/1000:,.0f}k"))
        ax.grid(axis="y",color="#e3eaf0",linewidth=.6);ax.spines[["top","right"]].set_visible(False)
        ax.legend(fontsize=7,loc="upper left",frameon=False)
    ax1.set_ylabel("Closing cash (USD)",fontsize=8)
    columns=["Case","Spent (USD)","Failed","Promoted*","Idle allocation (USD)"]
    rows=[]
    for row,pointer,label,color in selected:
        s=pointer+"/summary/"
        values=[register("cash",s+k,"cash_and_investment") for k in ["discretionary_construction_and_capacity_paid_usd","simulated_candidates_failed","simulated_candidates_promoted","idle_earmark_usd"]]
        rows.append([label,f"{values[0]:,.0f}",str(values[1]),str(values[2]),f"{values[3]:,.0f}"])
    table=table_ax.table(cellText=rows,colLabels=columns,cellLoc="right",colLoc="right",colWidths=[.34,.15,.10,.13,.28],bbox=[0,.05,1,.94])
    table.auto_set_font_size(False);table.set_fontsize(8)
    for (r,c),cell in table.get_celld().items():
        cell.set_edgecolor("#d6e1e9");cell.set_linewidth(.5)
        if r==0:cell.set_facecolor("#eaf1f7");cell.set_text_props(weight="bold",color=INK)
        if c==0:cell.set_text_props(ha="left")
        if r>0 and r%2==0:cell.set_facecolor("#f7fafc")
    fig.text(.02,.133,"Spent includes failed construction. Idle allocations are restricted cash, not additional investment.",fontsize=8,color=MUTED)
    fig.text(.02,.094,"* Promotions are assumed outcome-world results. The predeclared 4x demand is not observed demand.",fontsize=8,color=MUTED)
    fig.text(.02,.055,"Closing cash includes remaining initial capital. Cash, profit, customer savings and capability gain differ.",fontsize=8,color=RED)
    return save(fig,"cash_and_investment")


def exact_units(value,decimals):
    n=Decimal(value)/(Decimal(10)**decimals)
    return format(n,",f").rstrip("0").rstrip(".") if "." in format(n,",f") else format(n,",f")


def settlement_routes(token,source_register,register):
    fig=plt.figure(figsize=(7.2,6.45));top=fig.add_axes([.025,.48,.95,.40]);top.axis("off")
    fig.text(.02,.965,"Three settlement routes, distinct receipts",fontsize=14,weight="bold")
    fig.text(.02,.927,"USD 20 quoted job amount · source rules + chosen configuration, not current-chain state",fontsize=8.4,color=MUTED)
    source_by_id={x["id"]:x for x in source_register["sources"]}
    routes=[("manager_usdc","Manager · USDC","manager_settlement"),("ascension_agialpha","Five Alpha · AGIALPHA","alpha_market"),("jobs_v0_agialpha_success_only","AGI Jobs · AGIALPHA","jobs_stake_base")]
    for n,(route,title,reference) in enumerate(routes):
        index=next(i for i,c in enumerate(token["realization_cases"]) if c["route"]==route and c["quoted_job_amount_usd"]==20 and c["realization_scenario"]=="base")
        row=token["realization_cases"][index];base=f"/realization_cases/{index}/source_success_case/atomic/";decimals=row["asset_decimals"]
        x=n*.338;top.add_patch(FancyBboxPatch((x,.12),.315,.85,boxstyle="round,pad=.008,rounding_size=.02",facecolor=PALE,edgecolor="#c8d8e3",linewidth=.8))
        top.text(x+.015,.90,title,fontsize=9.3,weight="bold",va="top")
        atomic=row["source_success_case"]["atomic"]
        fields=[("Escrow","customer_escrow"),("Worker","worker_customer_funded_award"),("Validators","validator_allocation_total" if route.startswith("jobs_") else "total_validator_awards")]
        y=.74
        for label,key in fields:
            value=register("token",base+key,"settlement_routes")
            top.text(x+.015,y,label,fontsize=7.5,color=MUTED,va="top")
            top.text(x+.015,y-.075,exact_units(value,decimals),fontsize=9.4,weight="bold" if label=="Worker" else "normal",color=TEAL if label=="Worker" else INK,va="top")
            y-=.18
        if route=="manager_usdc":
            a=exact_units(register("token",base+"wallet30","settlement_routes"),decimals);b=exact_units(register("token",base+"wallet10","settlement_routes"),decimals)
            detail=f"Wallets: {a} + {b} USDC\nNo AGIALPHA conversion"
        elif route=="ascension_agialpha":
            burn=exact_units(register("token",base+"burn","settlement_routes"),decimals);detail=f"Burn: {burn} AGIALPHA\nBid = bounty in this example"
        else:
            fee=exact_units(register("token",base+"fee_pool_pending_claims_increment","settlement_routes"),decimals);burn=exact_units(register("token",base+"burn","settlement_routes"),decimals);detail=f"FeePool: {fee}; burn: {burn}\nEscrow adds fee to reward"
        top.text(x+.015,.205,detail,fontsize=7.1,color=MUTED,va="top",linespacing=1.5)
        ref=source_by_id.get(reference)
        if ref is None:
            refs=row["source_success_case"]["source_refs"];ref=source_by_id[refs[0].split(":")[0]]
        t=top.text(x+.015,.065,"Pinned implementation source",fontsize=7.3,color=BLUE,va="top");t.set_url(ref["url"])
    ax=fig.add_axes([.10,.18,.86,.245])
    colors=[TEAL,AMBER,RED];labels=["Base realization","Conservative","Stress: no liquidity"]
    for scenario_index,scenario in enumerate(["base","conservative","stress"]):
        ys=[]
        for route,title,_ in routes:
            index=next(i for i,c in enumerate(token["realization_cases"]) if c["route"]==route and c["quoted_job_amount_usd"]==20 and c["realization_scenario"]==scenario)
            ys.append(register("token",f"/realization_cases/{index}/monthly_realized_cash_after_worker_gas_usd","settlement_routes"))
        ax.bar([n+(scenario_index-1)*.22 for n in range(3)],ys,width=.20,color=colors[scenario_index],label=labels[scenario_index])
    ax.axhline(0,color="#8aa0b0",linewidth=.7);ax.spines[["top","right"]].set_visible(False);ax.grid(axis="y",color="#e5edf2",linewidth=.5);ax.set_axisbelow(True)
    ax.set_xticks([0,1,2],["Manager / USDC","Five Alpha / AGIALPHA","Jobs / AGIALPHA"],fontsize=7.7)
    ax.set_ylabel("USD after worker gas",fontsize=8);ax.tick_params(axis="y",labelsize=8)
    ax.set_title("100 successful settlements assumed; hypothetical monthly cash realization",fontsize=8.8,loc="left",pad=12,weight="bold")
    ax.legend(fontsize=7,ncols=3,frameon=False,loc="upper center",bbox_to_anchor=(.5,-.19))
    fig.text(.02,.065,"Enterprise delivery, setup, labor, tax and reserves remain undeducted. These receipts are not profit.",fontsize=8,color=RED)
    fig.text(.02,.027,"Token quote USD 0.00002 is illustrative. Collateral is capital; burns are not cash. No transaction executed.",fontsize=7.8,color=MUTED)
    return save(fig,"settlement_routes")


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--flow-only",action="store_true")
    parser.add_argument("--results",type=Path)
    parser.add_argument("--token-results",type=Path)
    parser.add_argument("--cash-audit",type=Path)
    parser.add_argument("--token-audit",type=Path)
    args=parser.parse_args()
    if digest(ROOT/"FREEZE.json")!=FREEZE_SHA:
        raise ValueError("Frozen specification identity mismatch")
    files=economic_engine_flow()
    manifest={"schema":"reinvestment-figure-build/v1","phase":"CONCEPTUAL_FLOW_ONLY_NO_NUMERIC_SCENARIOS","freeze_sha256":FREEZE_SHA,"files":files,"financial_model_executed":False,"numeric_plots":"AWAITING_AUDIT_BINDING"}
    if args.flow_only:
        (HERE/"FLOW_BUILD_MANIFEST.json").write_text(json.dumps(manifest,indent=2)+"\n")
    else:
        if any(x is None for x in [args.results,args.token_results,args.cash_audit,args.token_audit]):
            raise ValueError("All exact result and audit paths are required")
        documents={"cash":json.loads(args.results.read_text()),"token":json.loads(args.token_results.read_text())}
        for result_path,audit_path in [(args.results,args.cash_audit),(args.token_results,args.token_audit)]:
            audit=json.loads(audit_path.read_text())
            if audit["status"]!="PASS" or audit["producer_results_sha256"]!=digest(result_path):
                raise ValueError("Independent audit/result binding mismatch")
        for doc in documents.values():
            if doc["identities"]["freeze_sha256"]!=FREEZE_SHA:raise ValueError("Frozen result mismatch")
        values=[]
        def register(document,pointer,figure):
            value=item(documents[document],pointer);values.append({"document":document,"pointer":pointer,"figure":figure,"value":value});return value
        files+=cash_and_investment(documents["cash"],register)
        files+=settlement_routes(documents["token"],json.loads((ROOT/"contracts/SOURCE_REGISTER.json").read_text()),register)
        data={"schema":"reinvestment-figure-data/v1","cash_results_path":args.results.resolve().relative_to(ROOT).as_posix(),"cash_results_sha256":digest(args.results),"token_results_path":args.token_results.resolve().relative_to(ROOT).as_posix(),"token_results_sha256":digest(args.token_results),"cash_audit_sha256":digest(args.cash_audit),"token_audit_sha256":digest(args.token_audit),"values":values,"selection":"Illustrative base USD20,50% cases: evidence-pack and unvalidated profile at primary demand; unvalidated profile at predeclared4x demand in both outcome worlds. Settlement quoteUSD20 uses all3routes and3realization scenarios. Full144+32financialpaths and27settlementrealizations remain in raw outputs/browser."}
        (HERE/"figure_data.json").write_text(json.dumps(data,indent=2)+"\n")
        manifest.update({"phase":"AUDITED_RESULT_PRESENTATION","numeric_plots":"BOUND_TO_INDEPENDENT_PASS","files":files,"figure_data_sha256":digest(HERE/"figure_data.json"),"data_values":len(values),"cash_results_sha256":digest(args.results),"token_results_sha256":digest(args.token_results)})
        (HERE/"BUILD_MANIFEST.json").write_text(json.dumps(manifest,indent=2)+"\n")
    print(json.dumps(manifest,indent=2))


if __name__=="__main__":
    main()
