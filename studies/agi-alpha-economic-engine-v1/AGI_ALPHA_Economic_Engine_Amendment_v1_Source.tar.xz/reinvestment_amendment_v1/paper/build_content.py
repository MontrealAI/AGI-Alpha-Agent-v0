# SPDX-License-Identifier: Apache-2.0
"""Format audited financial outputs for LaTeX; never evaluate new scenarios."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'paper/generated'
OUT.mkdir(exist_ok=True)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text())
audit = read(ROOT / 'evaluation/INDEPENDENT_AUDIT.json')
assert audit['status'] == 'PASS' and audit['differences_remaining'] == 0
assert sha(ROOT / audit['producer_results_path']) == audit['producer_results_sha256']
assert sha(ROOT / audit['producer_model_path']) == audit['producer_model_sha256']
assert sha(ROOT / audit['token_results_path']) == audit['token_results_sha256']
assert sha(ROOT / 'FREEZE.json') == audit['freeze_sha256']
freeze = read(ROOT / 'FREEZE.json')
for item in freeze['files']:
    assert sha(ROOT / item['path']) == item['sha256'], item['path']
data = read(ROOT / audit['producer_results_path'])
token = read(ROOT / audit['token_results_path'])
inputs = read(ROOT / 'inputs.json')
anchor = read(ROOT / 'prior_model_anchor.json')
rows = data['primary_cases'] + data['demand_sensitivity_cases']
written = []

def n(value, digits=2):
    if isinstance(value, dict):
        value = value.get('value')
    return 'N/A' if value is None else f'{float(value):,.{digits}f}'

def case(profile, scenario='base', price=20, rho=0, world='no_gain', demand=1):
    found = [c for c in rows if c['profile'] == profile and c['scenario'] == scenario
             and c['price_usd_per_accepted'] == price and c['reinvestment_fraction'] == rho
             and c['outcome_world'] == world and c['demand_multiplier'] == demand]
    assert len(found) == 1
    return found[0]

def customer(c, minutes=None):
    return next(r for r in c['customer_comparison']['comparisons']
                if r['scope'] == 'annual_demand'
                and r['productive_human_minutes_assumed'] == minutes)

def put(name, text):
    p = OUT / name
    p.write_text(text.strip() + '\n')
    written.append({'path': name, 'sha256': sha(p), 'bytes': p.stat().st_size})

e = case('evidence_pack'); es = e['summary']
h = case('cost_050_hypothesis'); hs = h['summary']; hc = customer(h)
h50 = case('cost_050_hypothesis', rho=.5)['summary']
gain = case('cost_050_hypothesis', rho=.5, world='assumed_diminishing_gain', demand=4)
loss = case('cost_050_hypothesis', rho=.5, world='no_gain', demand=4)
reference = case('cost_050_hypothesis', rho=0, world='no_gain', demand=4)

put('abstract_results.tex', rf"""
At USD20 per accepted output, the evidence-pack base incurs a modeled
USD\,{n(-es['combined_income_after_tax_reserve_usd'])} provider loss over the operating
horizon. The separate fifty-cent hypothesis generates USD\,{n(hs['combined_income_after_tax_reserve_usd'])}
after the tax reserve before discretionary investment, while its complete
provider expense is USD\,{n(hs['complete_provider_expense_including_payment_processing_per_expected_accepted'])}
per expected accepted output. Its 50\% policy earmarks USD\,{n(h50['lifetime_allocation_usd'])}
but spends zero because the frozen investment gate rejects the remaining-horizon
payback. At fourfold assumed demand, a stipulated successful candidate can
produce a positive simulated return after one failed construction; the
all-failed world loses the construction budget.
""")

put('freeze.tex', r"""
The 68-file specification was frozen on 25 October 2026 at 14:23:55.892155 UTC,
after earlier native/operating results were known and before these financial
calculations. Its public commit is
\artifact{76ba78492da893b235b071cb0a61cf3608f9db37}; exact public readback and a
coordination notice preceded the 14:25:47.798846 UTC GO. Independent prospective
validation passed 282 static checks. Freeze SHA-256:
\begin{center}\scriptsize\texttt{4c7bac19106f946920d64ad39b01cb2cc844eed78c5cdb4d79140904a10cc9ba}\end{center}
""")

sr = [inputs['scenarios'][s] for s in ['base','conservative','stress']]
input_rows = [
 ('Evidence-pack requested jobs/year', [s['anchor_annual_requested_demand'] for s in sr], 0),
 ('Hypothesis requested jobs/year', [s['hypothesis_annual_requested_demand'] for s in sr], 0),
 ('Acceptance probability', [anchor['scenarios'][s]['acceptance_probability'] for s in ['base','conservative','stress']], 2),
 ('Collected fraction', [s['collected_fraction_of_accepted_invoices'] for s in sr], 2),
 ('Refund fraction of collections', [s['refund_fraction_of_collected'] for s in sr], 2),
 ('Processing fraction', [s['payment_processing_fraction'] for s in sr], 2),
 ('Processing USD per collected invoice', [s['processing_usd_per_collected_invoice'] for s in sr], 2),
 ('Additional business setup, USD', [s['additional_business_setup_usd'] for s in sr], 0),
 ('Additional monthly business cost, USD', [s['additional_monthly_acquisition_billing_usd']+s['additional_monthly_business_administration_usd'] for s in sr], 0),
 ('Tax-reserve fraction', [s['tax_reserve_fraction_of_positive_cumulative_pre_discretionary_income'] for s in sr], 2),
 ('Warranty-reserve fraction', [s['warranty_reserve_fraction_of_last_two_months_collected_proceeds'] for s in sr], 2),
 ('Working-capital months', [s['working_capital_months'] for s in sr], 0),
 ('Resource utilization', [s['utilization'] for s in sr], 2),
]
put('inputs.tex', r"""
\begin{table}[htbp]\centering\small
\caption{Joint planning assumptions. These are not observed field rates or
probabilities. Additional business costs supplement the imported complete
service/improvement accounts; their stated labor is already included.}
\begin{tabularx}{\linewidth}{@{}Yrrr@{}}\toprule
Parameter & Base & Conservative & Stress \\\midrule
""" + '\n'.join(label+' & '+' & '.join(n(v,d) for v in vals)+r' \\'
                 for label, vals, d in input_rows) + r"""
\bottomrule\end{tabularx}\end{table}
""")

financial_rows=[]
for profile, label in [('evidence_pack','Evidence pack'),('cost_050_hypothesis','Fifty-cent hypothesis')]:
    for scenario in ['base','conservative','stress']:
        c=case(profile,scenario); s=c['summary']
        unit=n(s['complete_provider_expense_including_payment_processing_per_expected_accepted'])
        financial_rows.append(label+' & '+scenario.capitalize()+' & '+n(s['requests_served'],0)+' & '
            +n(s['expected_accepted'])+' & '+unit+' & '+n(s['combined_income_after_tax_reserve_usd'])+r' \\')
interval_rows=[]
for t in [5,15,30,60,120]:
    c=customer(e,t); mx=c['maximum_customer_beneficial_face_price_usd']['value']; be=es['zero_reinvestment_break_even_price_usd']['value']
    interval=(n(be)+'--'+n(mx)) if mx is not None and be<=mx else 'None'
    interval_rows.append(n(t,0)+' & '+n(c['traditional_total_usd']/c['cohort_requests'])+' & '+n(mx)+' & '+interval+r' \\')
c30=customer(e,30); c60=customer(e,60)
put('operating_results.tex', rf"""
The evidence-pack base serves {n(es['requests_served'],0)} requests, with
{n(es['expected_accepted'],0)} expected accepted outputs and
{n(es['expected_unresolved_served'],0)} unresolved requests. At a USD20 accepted-job
price, gross invoices are USD\,{n(es['accepted_invoice_face_usd'])}, but only
USD\,{n(es['gross_collections_usd'])} is collected within the horizon. Refunds and
payment charges reduce that to USD\,{n(es['net_cash_collections_usd'])}.
Provider startup, mandatory operations and all delivery attempts cost
USD\,{n(es['combined_provider_cost_before_collection_charges_usd'])} before collection
charges. Complete provider expense including processing is
USD\,{n(es['complete_provider_expense_including_payment_processing_usd'])}, or
USD\,{n(es['complete_provider_expense_including_payment_processing_per_expected_accepted'])}
per expected accepted output. Refunds remain a reduction in revenue.

The resulting provider income is negative USD\,{n(-es['combined_income_after_tax_reserve_usd'])};
no earned surplus is allocated to new construction. Starting cash is a capital
buffer, not profit. This USD25,000 account belongs to the provider and excludes
customer outlays; it differs from the preceding paper's USD25,000 combined
resource ceiling. The two admission quantities therefore must not be compared
as an unexplained productivity improvement.

\begin{{table}}[htbp]\centering\scriptsize
\caption{{USD20, zero new reinvestment, twelve operating months. Expense per
accepted output includes payment processing and all incurred provider costs;
income is after the modeled tax reserve. Zero-service plans have unavailable
unit costs. All entries are simulations.}}
\begin{{tabularx}}{{\linewidth}}{{@{{}}Ylrrrr@{{}}}}\toprule
Profile & Case & Served & Accepted & USD/unit & Income USD \\\midrule
""" + '\n'.join(financial_rows) + rf"""
\bottomrule\end{{tabularx}}\end{{table}}

For the assumed thirty-minute traditional production task, the full-demand
customer cost is USD\,{n(c30['hybrid_cost_per_completed_request'])} per completed
request including conventional rescue, against USD\,{n(c30['traditional_total_usd']/c30['cohort_requests'])}
for traditional work. The customer and provider both lose in this example.
At an assumed sixty-minute traditional production duration, the customer instead
compares USD\,{n(c60['hybrid_cost_per_completed_request'])} with
USD\,{n(c60['traditional_total_usd']/c60['cohort_requests'])}; the provider still loses
at the USD20 selling price.

The cohort-conditional provider break-even price is USD\,{n(es['zero_reinvestment_break_even_price_usd'])}.
At sixty assumed human minutes, the customer's upper price is
USD\,{n(c60['maximum_customer_beneficial_face_price_usd'])}. A price between those
bounds can satisfy both modeled inequalities for the fixed cohort. It is a
testable pricing interval, not observed willingness to pay or a rerun proving
the same demand/admission path after repricing.

\begin{{table}}[htbp]\centering\small
\caption{{Primary human-work sensitivities for the evidence-pack base cohort.
Human durations are assumptions. The last column is a conditional interval
between supplier break-even and customer indifference; endpoints are not
commercial quotes.}}
\begin{{tabularx}}{{\linewidth}}{{@{{}}rYrr@{{}}}}\toprule
Human minutes & Traditional USD/job & Customer price cap & Joint interval USD \\\midrule
""" + '\n'.join(interval_rows) + r"""
\bottomrule\end{tabularx}\end{table}
Changing the human duration while holding the Agent case fixed does not establish
that a more difficult job can be automated at the same cost. The actual
four-passage brief has no matched human timing or customer-acceptance observation.
All five duration values and all three selling prices remain in the raw outputs.
""")

accounts=[('Accepted invoice face value',hs['accepted_invoice_face_usd']),
          ('Gross cash collected',hs['gross_collections_usd']),
          ('Refunds (contra-revenue)',hs['refunds_usd']),
          ('Payment processing',hs['payment_processing_usd']),
          ('Startup, operations and delivery before processing',hs['combined_provider_cost_before_collection_charges_usd']),
          ('Ordinary income before tax reserve',hs['ordinary_income_before_discretionary_usd']),
          ('Tax reserve',hs['tax_reserve_usd']),
          ('Recovered income after tax reserve',hs['combined_income_after_tax_reserve_usd']),
          ('Final uncollected invoice face value',hs['uncollected_final_month_receivable_face_usd'])]
put('hypothesis_results.tex',rf"""
The base hypothesis requests {n(hs['annual_requested_demand'],0)} jobs, serves them
within the declared aggregate model limits, and yields {n(hs['expected_accepted'],0)}
expected accepted outputs. Setup is {n(hs['setup_workdays_before_operating_horizon'],0)}
modeled workdays before the operating year, with USD\,{n(hs['quoted_startup_usd'])}
provider/business startup cost. All of this is assumed operational behavior.

\begin{{table}}[htbp]\centering\small
\caption{{Base fifty-cent hypothesis at USD20 and zero new investment. Collected
money, costs and reservations are separate. Initial USD25,000 capital is
excluded from income. These are not actual company receipts or expenses.}}
\begin{{tabularx}}{{\linewidth}}{{@{{}}Yr@{{}}}}\toprule
Account & USD \\\midrule
"""+'\n'.join(label+' & '+n(value)+r' \\'for label,value in accounts)+rf"""
\bottomrule\end{{tabularx}}\end{{table}}

Fifty cents is only variable delivery cost in this hypothetical offering. Full
provider expense is USD\,{n(hs['complete_provider_expense_including_payment_processing_per_expected_accepted'])}
per expected accepted output after startup, service/improvement upkeep, business
overhead and processing. The customer pays USD\,{n(h['customer_comparison']['common']['agent_customer_total_per_expected_accepted'])}
including its own modeled attention per Agent-accepted output. Completing all
requests, including {n(hs['expected_unresolved_served'],0)} conventional rescues,
costs the customer USD\,{n(hc['hybrid_cost_per_completed_request'])} per requested
completion against the assumed USD200 alternative. That is a conditional
{n(200/hc['hybrid_cost_per_completed_request']['value'])}-fold customer cost ratio,
with no observed USD200 task, willingness-to-pay record or human fallback
capacity. Its large modeled savings are not the provider's revenue.

The income after the tax reserve is USD\,{n(hs['combined_income_after_tax_reserve_usd'])}.
Warranty and terminal working-capital targets additionally restrict
USD\,{n(hs['warranty_reserve_usd'])} and USD\,{n(hs['working_capital_reserve_target_usd'])}
of cash. Remaining free cash includes the original capital and must not all be
called newly earned surplus. This favorable scenario establishes a conditional
financial possibility; actual quality, attention, demand, collection and
delivery cost would have to be measured for an offering with equivalent work.
""")

allocation_rows=[]
for rho in [0,.25,.5,.75]:
    s=case('cost_050_hypothesis',rho=rho)['summary']
    allocation_rows.append(n(rho*100,0)+r'\% & '+n(s['lifetime_allocation_usd'])+' & '+n(s['discretionary_construction_and_capacity_paid_usd'])+' & '+n(s['idle_earmark_usd'])+r' \\')
high_rows=[]
for label,c in [('Zero new investment',reference),('Half allocation; all candidates fail',loss),('Half allocation; stipulated diminishing gains',gain)]:
    s=c['summary'];high_rows.append(label+' & '+n(s['expected_accepted'],0)+' & '+n(s['discretionary_construction_and_capacity_paid_usd'])+' & '+n(s['combined_income_after_tax_reserve_usd'])+r' \\')
gcs=gain['candidates']; second=gcs[1]; third=gcs[2]
assert all(c['summary']['candidate_constructions']==0 and c['summary']['executor_purchases']==0 for c in data['primary_cases'])
put('reinvestment_results.tex',r"""
All 144 primary financial paths make zero new candidate or executor purchases.
This is an operating result of the declared policy, not a claim that all future
R\&D is uneconomic. In the base hypothesis, the first candidate has a positive
remaining-horizon forecast before any earned cash has arrived. By the time
earned earmarks exist, its remaining reuse volume is below the frozen payback
threshold. The twelve-month horizon deliberately provides no terminal credit
for possible later benefits.

\begin{table}[htbp]\centering\small
\caption{Primary fifty-cent hypothesis: a percentage ceiling does not mandate
spending. All four policies have the same operating income and accepted output.}
\begin{tabularx}{\linewidth}{@{}rYrr@{}}\toprule
Ceiling & Lifetime allocation USD & Actual new spending USD & Idle earmark USD \\\midrule
"""+'\n'.join(allocation_rows)+rf"""
\bottomrule\end{{tabularx}}\end{{table}}

The fourfold-demand sensitivity demonstrates the conditional construction path.
It serves {n(gain['summary']['requests_served'],0)} of
{n(gain['summary']['annual_requested_demand'],0)} requested jobs; customer attention
binds. At a 50\% ceiling, USD500 is spent in month two on a candidate that fails
its stipulated month-three qualification. A distinct USD750 candidate is built
in month three and receives its assumed passing evaluation in month four. In
the diminishing-gain world it is then used {n(second['qualified_subsequent_request_uses'],0)}
times, saving USD\,{n(second['gross_realized_simulated_savings_usd'])} before its
USD\,{n(second['upkeep_incurred_usd'])} upkeep and construction cost. The two
candidates together yield USD\,{n(second['net_realized_simulated_return_usd']+gcs[0]['net_realized_simulated_return_usd'])}
net simulated return before the tax-reserve treatment. Its gain is an input
assumption, not a newly observed invention.

\begin{{table}}[htbp]\centering\small
\caption{{Fourfold-demand sensitivity, fifty-cent profile and USD20 price.
The accepted count is identical: the stipulated method improvement reduces
cost but does not remove the binding customer-attention limit. All figures
remain conditional simulations.}}
\begin{{tabularx}}{{\linewidth}}{{@{{}}Yrrr@{{}}}}\toprule
Policy/outcome world & Accepted & Spending USD & Income after reserve USD \\\midrule
"""+'\n'.join(high_rows)+rf"""
\bottomrule\end{{tabularx}}\end{{table}}

The successful candidate's realized-horizon payback requires
{n(second['integer_realized_horizon_payback_request_uses'],0)} request uses,
including its full horizon upkeep. Its probability-weighted forecast required
{n(second['construction_forecast']['integer_payback_request_uses'],0)} uses.
The third candidate would require
{n(third['last_forecast']['integer_payback_request_uses'],0)} forecast uses against
{n(third['last_forecast']['remaining_resource_feasible_request_uses'],0)} remaining
resource-feasible uses, so construction stops. In the all-failed world the same
funded attempts lose their full USD1,250. Neither positive demand nor abundant
earmarked funds guarantees a useful next method. No executor is purchased in
any reported path.
""")

route_labels={'manager_usdc':'Manager USDC','ascension_agialpha':'Ascension AGIALPHA','jobs_v0_agialpha_success_only':'Jobs v0 AGIALPHA'}
token_rows=[]
for route,label in route_labels.items():
    r=next(t for t in token['realization_cases'] if t['route']==route and float(t['quoted_job_amount_usd'])==20 and t['realization_scenario']=='base')
    token_rows.append(label+' & '+n(r['customer_total_escrow_quote_usd_per_job'])+' & '+n(r['worker_award_quote_usd_per_job_before_realization'])+' & '+n(r['monthly_realized_cash_after_worker_gas_usd'])+r' \\')
put('token_results.tex',r"""
\begin{table}[htbp]\centering\small
\caption{Separate source-mechanism examples at quoted USD20, using the frozen
illustrative valuation. The last column assumes 100 successful settlements,
declared conversion charges/liquidity and gas allowances; it precedes all
enterprise delivery/business costs, taxes and reserves. Jobs v0's USD20 is
reward, so its customer escrow is USD21. None of these receipts is profit.}
\begin{tabularx}{\linewidth}{@{}Yrrr@{}}\toprule
Route & Buyer escrow/job & Worker award/job & Monthly cash after gas \\\midrule
"""+'\n'.join(token_rows)+r"""
\bottomrule\end{tabularx}\end{table}

The conservative realization example caps converted cash at USD1,000 and pays
USD200 gas allowance, leaving USD800 before business costs in each quoted-USD20
route. The stress example assumes zero conversion liquidity and USD1,000 gas
allowance; cash after gas is negative USD1,000 despite token-denominated awards.
These deliberately joint assumptions are not forecasts of token price or
liquidity. Unconverted units remain inventory; collateral principal is not
income; capital carrying cost is separately imputed.

Connecting a token settlement to an actual enterprise budget would require
authorized recipient control, verified configuration, collection/conversion,
collateral and refund accounting, and an approved appropriation. The dynamic
ordinary-USD study does not claim that connection has been implemented. The
source modules expose its distinct payment boundaries without creating a new
treasury or changing a deployed contract.
""")

put('validation.tex',rf"""
The independent audit passes {n(audit['total_comparison_checks'],0)} arithmetic,
ledger, identity and export comparisons, with zero remaining discrepancies.
These counts are not independent observations or reliability trials. The scope
includes all 176 paths, {n(audit['monthly_rows'],0)} monthly rows, 82,191 cost-ledger
rows, 27 token realization cases and nine failure examples. A separate Decimal
implementation reproduces the cash paths; token waterfalls use exact atomic
integers. The 68 frozen files remain unchanged.

The first producer run is preserved. Independent review found 424 disagreements
in two reporting boundaries, while all actual cash, delivery, cost and investment
paths agreed. A documented \emph{{post-result reporting revision}} makes stopped
operational forecasts zero, labels optional counterfactual capacity separately,
marks empty served-cohort comparisons unavailable and exposes complete provider
expense including processing. All earlier values and attempts remain available;
the revision changes no frozen assumption or actual financial path. Independent
invariance checks and corrected export adapters are recorded rather than erased.

The model and result identities are bound in
\artifact{{evaluation/INDEPENDENT_AUDIT.json}}. Cash results:
\begin{{center}}\scriptsize\texttt{{{audit['producer_results_sha256']}}}\end{{center}}
Token results:
\begin{{center}}\scriptsize\texttt{{{audit['token_results_sha256']}}}\end{{center}}
\artifact{{MODEL_GUIDE.md}} gives exact producer and safe independent-reproduction
commands. The separate model never imports the producer's arithmetic. The source
archive includes the monthly, cost, event and customer ledgers; prospective
protocol; source snapshots; failed/declined candidates; and development records.
No frozen destination is overwritten to reproduce the study.
""")

(OUT/'MANIFEST.json').write_text(json.dumps({'source_results_sha256':audit['producer_results_sha256'],
    'source_token_results_sha256':audit['token_results_sha256'],
    'independent_audit_sha256':sha(ROOT/'evaluation/INDEPENDENT_AUDIT.json'),
    'generator_sha256':sha(Path(__file__)), 'files':written},indent=2)+'\n')
print(json.dumps({'generated_sections':len(written),'audit_status':audit['status'],
                  'cash_result_sha256':audit['producer_results_sha256']}))
