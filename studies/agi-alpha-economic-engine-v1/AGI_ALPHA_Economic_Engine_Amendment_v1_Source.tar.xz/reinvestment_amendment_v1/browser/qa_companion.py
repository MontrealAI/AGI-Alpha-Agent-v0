# SPDX-License-Identifier: Apache-2.0
"""Offline browser presentation QA, separate from scientific and financial claims."""
from __future__ import annotations

import hashlib
import json
import re
import zipfile
from decimal import Decimal
from datetime import datetime, timezone
from pathlib import Path
from playwright.sync_api import sync_playwright

HERE=Path(__file__).resolve().parent
QA=HERE/"qa"


def main():
    QA.mkdir(exist_ok=True)
    manifest=json.loads((HERE/"BUILD_MANIFEST.json").read_text())
    source=HERE/manifest["path"]
    assert hashlib.sha256(source.read_bytes()).hexdigest()==manifest["sha256"]
    checks=[]; errors=[]; requests=[]
    def check(name,passed,detail=None):
        checks.append({"name":name,"passed":bool(passed),"detail":detail})
        if not passed: raise AssertionError(name+": "+str(detail))
    result={"schema":"reinvestment-browser-qa/v1","started_utc":datetime.now(timezone.utc).isoformat(),"html_sha256":manifest["sha256"],"phase":manifest["phase"]}
    final=manifest["financial_numbers_displayed"]
    documents={}
    if final:
        documents={"cash":json.loads((HERE.parent/manifest["identity"]["cashResultsPath"]).read_text()),"token":json.loads((HERE.parent/manifest["identity"]["tokenResultsPath"]).read_text())}
    numeric_count=0;monthly_views=0;customer_views=0
    def lookup(document,pointer):
        value=documents[document]
        for part in pointer.strip('/').split('/'):
            key=part.replace('~1','/').replace('~0','~')
            value=value[int(key)] if isinstance(value,list) else value[key]
        return value
    def validate(records):
        nonlocal numeric_count
        for row in records:
            value=lookup(row["doc"],row["path"])
            if value is None:
                assert row["text"]=="Unavailable" and row["null"]=="true",row
            else:
                parsed=float(re.sub(r'[^0-9.\-]','',row["text"]))
                tolerance=.5*10**(-int(row["decimals"]))+abs(value)*1e-12
                assert abs(parsed-value)<=tolerance,(row,value)
            numeric_count+=1
    try:
        with sync_playwright() as p:
            browser=p.chromium.launch(headless=True,executable_path="/tmp/successor-chrome/chrome-headless-shell-linux64/chrome-headless-shell",args=["--no-sandbox"])
            context=browser.new_context(viewport={"width":1440,"height":1080},offline=True,accept_downloads=True)
            page=context.new_page()
            page.on("pageerror",lambda e:errors.append(str(e)))
            page.on("request",lambda r:requests.append(r.url) if r.url.startswith(("http:","https:")) else None)
            page.goto(source.as_uri())
            page.wait_for_function("(window.REINVESTMENT_DEMO?.ready || window.REINVESTMENT_DEMO?.error) && window.CAPABILITY_DEMO?.ready === true",timeout=60000)
            check("Companion initializes",page.evaluate("REINVESTMENT_DEMO.ready"),page.evaluate("REINVESTMENT_DEMO.error || null"))
            check("Recorded artifact visible",page.locator("#riArtifact").is_visible())
            check("Default financial tab",page.locator("#economics").is_visible() and not page.locator("#live").is_visible())
            if final:
                check("Both audited output bundles bound",page.evaluate("REINVESTMENT_DEMO.financialResultsBound && REINVESTMENT_DEMO.tokenResultsBound"))
                cases=documents["cash"]["primary_cases"]+documents["cash"]["demand_sensitivity_cases"]
                capture="els=>els.map(e=>({doc:e.dataset.modelDoc,path:e.dataset.modelPath,decimals:e.dataset.decimals,null:e.dataset.null,text:e.textContent}))"
                for offset in range(0,len(cases),8):
                    ids=[c["case_id"] for c in cases[offset:offset+8]]
                    batches=page.evaluate("""ids=>{
                      const read=scope=>Array.from(document.querySelectorAll(scope+' [data-model-path]'),e=>({doc:e.dataset.modelDoc,path:e.dataset.modelPath,decimals:e.dataset.decimals,null:e.dataset.null,text:e.textContent}));
                      const answer=[];
                      for(const id of ids){
                        REINVESTMENT_DEMO.selectCase(id);
                        const selected=REINVESTMENT_DEMO.getCase();
                        const record={id,selected:selected.case_id,pointer:REINVESTMENT_DEMO.getCasePointer(),initial:read('#economics'),months:[],customers:[]};
                        for(let m=1;m<=12;m++){const el=document.getElementById('riMonth');el.value=String(m);el.dispatchEvent(new Event('change'));record.months.push([...read('#riCashRows'),...read('#riConstraints')]);}
                        for(const scope of ['served_cohort','annual_demand']){
                          document.getElementById('riCustomerScope').value=scope;
                          for(const minutes of selected.profile==='evidence_pack'?[5,15,30,60,120]:[30]){
                            document.getElementById('riHumanMinutes').value=String(minutes);document.getElementById('riCustomerScope').dispatchEvent(new Event('change'));record.customers.push(read('#riCustomerResults'));
                          }
                        }
                        answer.push(record);
                      }return answer;
                    }""",ids)
                    for batch in batches:
                        assert batch["id"]==batch["selected"]
                        validate(batch["initial"])
                        for fields in batch["months"]:validate(fields);monthly_views+=1
                        for fields in batch["customers"]:validate(fields);customer_views+=1
                    print(json.dumps({"case_views_checked":min(offset+8,len(cases)),"total":len(cases),"numeric_bindings":numeric_count}),flush=True)
                check("All prespecified financial case selectors",len(cases)==176)
                check("Every monthly view bound",monthly_views==2112)
                check("Every customer scope/duration view bound",customer_views==1056)
                for i,row in enumerate(documents["token"]["realization_cases"]):
                    page.select_option('#riRoute',row['route']);page.select_option('#riTokenQuote',str(int(row['quoted_job_amount_usd'])));page.select_option('#riRealization',row['realization_scenario'])
                    validate(page.locator('#riTokenResults [data-model-path]').evaluate_all(capture))
                    atomic=page.locator('#riTokenResults [data-atomic-path]').evaluate_all("els=>els.map(e=>({path:e.dataset.atomicPath,decimals:Number(e.dataset.decimals),asset:e.dataset.asset,text:e.textContent}))")
                    for field in atomic:
                        value=Decimal(lookup('token',field['path']))/(Decimal(10)**field['decimals'])
                        wanted=format(value,',f')
                        if '.' in wanted:wanted=wanted.rstrip('0').rstrip('.')
                        assert field['text']==wanted+' '+field['asset'],(field,wanted)
                check("All27source settlement realizations",len(documents['token']['realization_cases'])==27)
                check("No token atomic Number conversion",'Number(atomic)' not in (HERE/'reinvestment_ui.mjs').read_text())
                base=next(c for c in cases if c['profile']=='evidence_pack' and c['scenario']=='base' and c['price_usd_per_accepted']==20 and c['reinvestment_fraction']==.5 and c['outcome_world']=='no_gain' and c['demand_multiplier']==1)
                page.evaluate('id=>REINVESTMENT_DEMO.selectCase(id)',base['case_id'])
                page.select_option('#riHumanMinutes','30');page.select_option('#riCustomerScope','annual_demand');page.select_option('#riMonth','12')
                page.select_option('#riRoute','manager_usdc');page.select_option('#riTokenQuote','20');page.select_option('#riRealization','base')
                check("Provider cash and customer account distinction explicit",'provider cash' in page.locator('#economics').inner_text() and 'combined-resource' in page.locator('#economics').inner_text())
                for button,key in [('riDownloadResults','cashResultsSha256'),('riDownloadTokens','tokenResultsSha256')]:
                    with page.expect_download() as d:page.locator('#'+button).click()
                    saved=QA/(button+'.json');d.value.save_as(saved)
                    check('Exact download '+button,hashlib.sha256(saved.read_bytes()).hexdigest()==manifest['identity'][key])
                for button,key in [('riDownloadBundle','evidence_bundle_sha256'),('riDownloadAudit','audit_bundle_sha256'),('riDownloadModel','model_bundle_sha256')]:
                    with page.expect_download() as d:page.locator('#'+button).click()
                    saved=QA/(button+'.zip');d.value.save_as(saved)
                    check('Exact ZIP '+button,hashlib.sha256(saved.read_bytes()).hexdigest()==manifest[key])
                    if button=='riDownloadBundle':
                        with zipfile.ZipFile(saved) as archive:
                            members=json.loads(archive.read('BROWSER_BUNDLE_MANIFEST.json'))
                            for member in members:
                                raw=archive.read(member['path']);assert len(raw)==member['bytes'] and hashlib.sha256(raw).hexdigest()==member['sha256']
                            check('Every embedded evidence member exact',True,len(members))
            else:
                check("No unaudited financial result",page.locator("#riAccepted").inner_text()=="—")
                check("Explicit unbound financial state",not page.evaluate("REINVESTMENT_DEMO.financialResultsBound"))
            check("No script errors",not errors,errors)
            check("No external runtime requests",not requests,requests)
            with page.expect_download() as d:page.locator("#riBriefDownload").click()
            dest=QA/"downloaded-recorded-brief.html";d.value.save_as(dest)
            check("Exact recorded brief download",hashlib.sha256(dest.read_bytes()).hexdigest()=="dbc9a1447e01e567fe3aee5efa160ec5414e04874904f8603d97773030fc0435")
            for route in ["manager_usdc","ascension_agialpha","jobs_v0_agialpha_success_only","ordinary_offchain"]:
                page.select_option("#riRoute",route)
                check("Source route "+route,page.locator("#riRouteSources").inner_text().strip()!="")
            page.select_option("#riRoute","manager_usdc")
            if final:
                page.locator('[data-tab=live]').click();page.locator('#first').click()
                page.wait_for_function('CAPABILITY_DEMO.state().history.length===1 && !CAPABILITY_DEMO.state().busy')
                state=page.evaluate('CAPABILITY_DEMO.state()')
                check('Original local first delivery accepted',state['history'][0]['checks']['exact_contract'])
                page.locator('#changed').click();page.wait_for_function('CAPABILITY_DEMO.state().history.length===2 && !CAPABILITY_DEMO.state().busy')
                state=page.evaluate('CAPABILITY_DEMO.state()');lineage=json.loads(next(x['content'] for x in state['history'][1]['pack']['result']['artifacts'] if x['name']=='lineage.json'))
                check('Actual inherited module invoked',state['retainedInvocations']==1 and bool(lineage['changed_source_ids']) and bool(lineage['reused_claim_ids']))
                page.locator('#transfer').click();page.wait_for_function('CAPABILITY_DEMO.state().history.length===3 && !CAPABILITY_DEMO.state().busy')
                state=page.evaluate('CAPABILITY_DEMO.state()');lineage=json.loads(next(x['content'] for x in state['history'][2]['pack']['result']['artifacts'] if x['name']=='lineage.json'))
                check('Fresh transfer uses original retained module',state['retainedInvocations']==2 and lineage['cross_family'])
                with page.expect_download() as d:page.get_by_role('button',name='repair-tool.mjs',exact=True).click()
                dest=QA/'repair-tool.mjs';d.value.save_as(dest)
                check('Retained module byte exact',hashlib.sha256(dest.read_bytes()).hexdigest()==hashlib.sha256((HERE.parent.parent/'capability_study/src/evidence.mjs').read_bytes()).hexdigest())
                workspace=page.evaluate('CAPABILITY_DEMO.exportWorkspace()')
                page.locator('#rollback').click();state=page.evaluate('CAPABILITY_DEMO.state()')
                check('Rollback retains successors',state['selected']==1 and len(state['history'])==3)
                page.locator('#stopNext').check();page.locator('#first').click();page.wait_for_function('!CAPABILITY_DEMO.state().busy')
                state=page.evaluate('CAPABILITY_DEMO.state()')
                check('STOP prevents local publication',len(state['history'])==3 and any(e['kind']=='failed-or-stopped' and e['detail']['error']=='CANCELLED' for e in state['events']))
                page.evaluate('raw=>CAPABILITY_DEMO.restore(raw)',workspace)
                check('Recovery restores all three artifacts',page.evaluate('CAPABILITY_DEMO.state().history.length')==3)
                corrupt=json.loads(workspace);corrupt['history'][0]['pack']['result']['summary']['claims']=999
                error=page.evaluate('async raw=>{try{await CAPABILITY_DEMO.restore(raw);return null;}catch(e){return e.message}}',json.dumps(corrupt))
                check('Tampered recovery refused',error=='PACK_INTEGRITY' and page.evaluate('CAPABILITY_DEMO.state().history.length')==3)
            for width,height,label in [(1440,1080,'desktop'),(390,844,'mobile')]:
                page.set_viewport_size({'width':width,'height':height})
                for tab in ['economics','live','recorded','executor']:
                    page.locator('[data-tab='+tab+']').click();page.evaluate('window.scrollTo(0,0)')
                    check(label+' containment '+tab,page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'))
                    page.screenshot(path=str(QA/(label+'-'+tab+'.png')),full_page=False)
                page.locator('[data-tab=economics]').click()
                for section in ['riArtifact','riLoadStatus','riCashRows','riCustomerResults','riTokenResults']:
                    page.locator('#'+section).scroll_into_view_if_needed();page.screenshot(path=str(QA/(label+'-'+section+'.png')),full_page=False)
                for kind in ['riShowBrief','riShowSlides']:
                    page.locator('#'+kind).click();page.frame_locator('#riArtifact').locator('h1').wait_for()
                    check(label+' recorded iframe '+kind,page.frame_locator('#riArtifact').locator('body').evaluate('e=>e.scrollWidth<=e.ownerDocument.documentElement.clientWidth+1'))
            check('No final script errors',not errors,errors);check('No final external requests',not requests,requests)
            result["status"]="PASS"
            browser.close()
    except Exception as error:
        result["status"]="FAIL";result["error"]=str(error)
        raise
    finally:
        result.update({"checks":checks,"checks_total":len(checks),"numeric_bindings_checked":numeric_count,"monthly_views":monthly_views,"customer_views":customer_views,"external_requests":requests,"script_errors":errors,"finished_utc":datetime.now(timezone.utc).isoformat()})
        (HERE/"QA_REPORT.json").write_text(json.dumps(result,indent=2)+"\n")
        with (HERE/"QA_ATTEMPTS.jsonl").open("a") as stream:stream.write(json.dumps(result)+"\n")
        print(json.dumps({k:v for k,v in result.items() if k!="checks"},indent=2))


if __name__=="__main__":
    main()
