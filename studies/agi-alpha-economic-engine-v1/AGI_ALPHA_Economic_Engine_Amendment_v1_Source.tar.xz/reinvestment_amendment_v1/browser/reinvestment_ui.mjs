// SPDX-License-Identifier: Apache-2.0
// Presentation selects recorded/audited rows; no financial scenario arithmetic lives here.
const payload = JSON.parse(document.getElementById('reinvestment-payload').textContent);
const $ = id => document.getElementById(id);
const text = (id, value) => { $(id).textContent = String(value); };
const escape = value => String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const sourceById = new Map(payload.sourceRegister.sources.map(s => [s.id, s]));
const cashSelectors = ['riProfile','riScenario','riPrice','riReinvest','riWorld','riDemand'];
let cashData = null, tokenData = null, selectedCase = null, selectedPointer = null;
const numberFormat = new Intl.NumberFormat('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});
const wholeFormat = new Intl.NumberFormat('en-US',{maximumFractionDigits:0});

function at(document, pointer) {
  return pointer.split('/').filter(Boolean).reduce((v,k) => v?.[k.replaceAll('~1','/').replaceAll('~0','~')],document);
}

function amount(pointer, kind='money', document='cash') {
  const value=at(document==='cash'?cashData:tokenData,pointer);
  if(value===undefined)throw new Error('Missing audited field: '+pointer);
  if(value!==null&&(typeof value!=='number'||!Number.isFinite(value)))throw new Error('Non-numeric audited field: '+pointer);
  const decimals=kind==='integer'?0:kind==='rate'?8:2;
  const shown=value===null||value===undefined?'Unavailable':kind==='money'?'USD '+numberFormat.format(value):kind==='rate'?'USD '+value.toFixed(8):kind==='integer'?wholeFormat.format(value):numberFormat.format(value);
  return '<span data-model-doc="'+document+'" data-model-path="'+escape(pointer)+'" data-format="'+kind+'" data-decimals="'+decimals+'" data-null="'+String(value===null||value===undefined)+'">'+escape(shown)+'</span>';
}

function valueCell(id,pointer,kind='money',document='cash') {
  $(id).innerHTML=amount(pointer,kind,document);
  const v=at(document==='cash'?cashData:tokenData,pointer);
  $(id).classList.toggle('ri-negative',typeof v==='number'&&v<0);
}

function tableRow(label,pointer,notes='',kind='money',document='cash',extra='') {
  return '<tr class="'+extra+'"><td>'+escape(label)+'</td><td>'+amount(pointer,kind,document)+'</td><td>'+escape(notes)+'</td></tr>';
}

function humanize(value) { return String(value??'Unavailable').replaceAll('_',' ').toLowerCase(); }

function assetUnits(atomic,decimals) {
  // Decimal point placement only. Never convert a token atomic integer to Number.
  const raw=String(atomic), negative=raw.startsWith('-'), digits=(negative?raw.slice(1):raw).padStart(decimals+1,'0');
  const integer=digits.slice(0,-decimals)||'0', tail=digits.slice(-decimals).replace(/0+$/,'');
  return (negative?'-':'')+integer.replace(/\B(?=(\d{3})+(?!\d))/g,',')+(tail?'.'+tail:'');
}

function atomicCell(pointer,decimals,asset) {
  const raw=at(tokenData,pointer);
  return '<span data-atomic-path="'+escape(pointer)+'" data-decimals="'+decimals+'" data-asset="'+escape(asset)+'">'+escape(assetUnits(raw,decimals)+' '+asset)+'</span>';
}

function compactTable(rows) { return '<div class="ri-table-wrap"><table class="ri-table"><thead><tr><th>Account</th><th>Value</th><th>Scope</th></tr></thead><tbody>'+rows.join('')+'</tbody></table></div>'; }

function save(filename, bytes, type='application/octet-stream') {
  const blob = new Blob([bytes], {type});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href=url; a.download=filename; a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function showArtifact(kind) {
  const brief = kind === 'brief';
  const original=payload.nativeArtifacts[brief ? 'observed/output/brief.html' : 'observed/output/slides.html'];
  $('riArtifact').srcdoc = original.replace('</head>','<style>body{overflow-wrap:anywhere}table{max-width:100%;display:block;overflow:auto}@media(max-width:500px){main{padding:20px 12px!important}body{padding:12px!important}h1{font-size:27px!important;overflow-wrap:anywhere}h2{font-size:21px!important}article{padding:12px!important}blockquote{font-size:16px!important}}</style></head>');
  $('riArtifact').title = brief ? 'Exact recorded publication brief' : 'Exact recorded handover slides';
  $('riShowBrief').setAttribute('aria-pressed', String(brief));
  $('riShowSlides').setAttribute('aria-pressed', String(!brief));
}

function cashSelection() {
  const isSensitivityCase = $('riScenario').value === 'base' && $('riPrice').value === '20';
  if (!isSensitivityCase) $('riDemand').value = '1';
  $('riDemand').disabled = !isSensitivityCase;
  $('riHumanMinutes').disabled = $('riProfile').value === 'cost_050_hypothesis';
  return {
    profile:$('riProfile').value, scenario:$('riScenario').value,
    price_usd_per_accepted:Number($('riPrice').value),
    reinvestment_fraction:Number($('riReinvest').value),
    outcome_world:$('riWorld').value, demand_multiplier:Number($('riDemand').value)
  };
}

function renderSourceRoute() {
  const route = $('riRoute').value;
  const ids = route === 'manager_usdc' ? ['manager_escrow','manager_success','manager_failure']
    : route === 'ascension_agialpha' ? ['alpha_access_and_seed','alpha_oracle_stake','alpha_market_success','alpha_market_failure','alpha_mark_funding','alpha_mark_spend_and_close']
    : route === 'jobs_v0_agialpha_success_only' ? ['jobs_success','jobs_failure_and_nonreveal','jobs_fee_pool'] : ['ordinary_invoice'];
  const rows = payload.flowMatrix.flows.filter(f => ids.includes(f.id));
  $('riRouteSources').innerHTML = rows.map(f => {
    const links = f.references.map(ref => {
      const source = sourceById.get(ref.source);
      if (!source) return '';
      const url = source.url + '#L' + ref.start_line + '-L' + ref.end_line;
      return '<a target="_blank" rel="noopener" href="' + escape(url) + '">' + escape(ref.symbol) + '</a>';
    }).join('');
    return '<div class="ri-source-flow"><h4>' + escape(f.id.replaceAll('_',' ')) + '</h4><p><strong>' + escape(f.asset) + '</strong> · ' + escape(f.status) + '</p><p>' + escape(f.mechanism) + '</p><p>' + escape(f.reinvestment_meaning) + '</p><details><summary>Authority, fees and retained obligations</summary><p>' + escape(f.authority) + '</p><p>' + escape(f.fees_burns_collateral) + '</p></details><div class="ri-source-links">' + links + '</div></div>';
  }).join('');
}

function renderCash() {
  const selection=cashSelection();
  if(!cashData){renderSkeleton();return;}
  const group=selection.demand_multiplier===1?'primary_cases':'demand_sensitivity_cases';
  const index=cashData[group].findIndex(row=>Object.entries(selection).every(([k,v])=>row[k]===v));
  if(index<0)throw new Error('No prespecified result matches the selected case.');
  selectedCase=cashData[group][index];selectedPointer='/'+group+'/'+index;
  const p=selectedPointer+'/summary', s=selectedCase.summary;
  const status=humanize(s.status);
  const load=$('riLoadStatus');load.classList.toggle('ri-error',s.status!=='OPERATED_FULL_HORIZON');
  load.innerHTML='<strong>SIMULATION · '+escape(status)+'.</strong> Case '+escape(selectedCase.case_id)+'. Quoted startup '+amount(p+'/quoted_startup_usd')+'; modeled setup '+amount(p+'/setup_workdays_before_operating_horizon','integer')+' workdays before the operating horizon. '+(s.startup_admitted?'Field performance and daily scheduling remain unvalidated.':'Startup was declined; zero incurred service is not zero historical research cost. Capital shortfall: '+amount(p+'/startup_shortfall_usd')+'.');
  valueCell('riAccepted',p+'/expected_accepted','number');
  valueCell('riCollections',p+'/net_cash_collections_usd');
  valueCell('riNetResult',p+'/combined_income_after_tax_reserve_usd');
  valueCell('riInvested',p+'/discretionary_construction_and_capacity_paid_usd');
  $('riAcceptedNote').innerHTML=amount(p+'/expected_unresolved_served','number')+' unresolved served requests; '+amount(p+'/unserved_annual_demand','integer')+' annual requests not served.';
  renderMonth();renderCustomer();renderActions();
}

function renderMonth() {
  if(!selectedCase)return;
  const month=Number($('riMonth').value), index=selectedCase.monthly.findIndex(m=>m.month===month);
  if(index<0){$('riCashRows').innerHTML='<tr><td colspan="3">No operating row exists for this case.</td></tr>';return;}
  const p=selectedPointer+'/monthly/'+index, m=selectedCase.monthly[index];
  const rows=[
    ['Opening cash','opening_cash_usd','Includes retained initial capital; not all revenue'],
    ['Gross collections','gross_collections_usd','Prior accepted invoices, after collection assumptions'],
    ['Refunds','refunds_usd','Contra-revenue; never reinvestable receipts'],
    ['Percentage payment charges','percentage_processing_usd','Provider expense'],
    ['Fixed payment charges','fixed_processing_usd','Provider expense'],
    ['Net cash collections','net_collections_usd','After refunds and both payment charges'],
    ['Mandatory / shutdown cash paid','mandatory_or_shutdown_paid_usd','Incurred obligations remain separate from actual payment'],
    ['Delivery costs paid','provider_delivery_incurred_paid_usd','Includes rejected, retried and refused paths'],
    ['Previous shutdown debt paid','prior_shutdown_obligation_payment_usd','Payment of a previously incurred obligation'],
    ['Discretionary construction / capacity','discretionary_spending_usd','Actual spending within the simulation'],
    ['Closing cash','closing_cash_usd','Remaining cash balance'],
    ['Tax reserve','tax_reserve_usd','Restricted balance; not a second expense'],
    ['Warranty reserve','warranty_reserve_usd','Assumed planning buffer'],
    ['Working-capital target','working_capital_reserve_target_usd','Target is not a guarantee of funded coverage'],
    ['Idle research earmark','idle_earmark_usd','Allocated but unspent'],
    ['Unpaid shutdown obligation','unpaid_shutdown_obligation_usd','Liability remains visible'],
    ['Liquid free cash after targets','liquid_free_cash_after_targets_usd','May include unspent initial capital; not automatically surplus'],
    ['Recovered after-tax operating surplus','recovered_after_tax_operating_surplus_usd','The earned base for an optional allocation'],
  ];
  $('riCashRows').innerHTML=rows.map(([label,key,note])=>tableRow(label,p+'/'+key,note,'money','cash',key==='closing_cash_usd'?'ri-total':'')).join('');
  const constraints=[
    tableRow('Requests served',p+'/requests_served','Whole requests within this monthly planning model','integer'),
    tableRow('Expected accepted',p+'/expected_accepted','Fractional expectations are not extra observed jobs','number'),
    tableRow('Arrived backlog',p+'/backlog_arrived_unserved','Work still waiting','integer'),
    tableRow('Provider minutes used',p+'/provider_minutes_used','Paid service, support and funded construction','number'),
    tableRow('Customer minutes',p+'/customer_delivery_and_fixed_minutes','Customer attention remains a separate constraint','number'),
    tableRow('Executor occupied seconds',p+'/executor_seconds_used','Expected occupancy, not measured live concurrency','number'),
    tableRow('Reserve / obligation shortfall',p+'/reserve_and_obligation_shortfall_end_usd','A shortfall is a failed financial constraint'),
  ];
  $('riConstraints').classList.remove('ri-empty');
  $('riConstraints').innerHTML='<p><strong>Month '+month+': '+escape(humanize(m.status))+'.</strong> Binding admission limits: '+escape((m.binding_admission_limits??[]).join(', ')||'not applicable')+'.</p>'+compactTable(constraints)+'<div class="ri-data-note">Action: '+escape(humanize(m.action?.kind))+' · '+escape(humanize(m.action?.reason??m.action?.id??'No further detail'))+'</div>';
}

function renderActions() {
  if(!selectedCase)return;
  const cards=selectedCase.candidates.map((c,i)=>{
    const p=selectedPointer+'/candidates/'+i;
    let lines='<div class="ri-action"><strong>'+escape(c.id)+' · '+escape(humanize(c.status))+'</strong><span>Construction paid: '+amount(p+'/construction_paid_usd')+'; upkeep paid: '+amount(p+'/upkeep_paid_usd')+'; net simulated return: '+amount(p+'/net_realized_simulated_return_usd')+'.</span>';
    if(c.last_forecast)lines+='<p class="ri-fine">Last predicted net saving '+amount(p+'/last_forecast/forecast_net_savings_usd')+'; conditional payback needs '+amount(p+'/last_forecast/integer_payback_request_uses','integer')+' requests. Forecast resources do not establish future cash feasibility.</p>';
    return lines+'</div>';
  });
  const p=selectedPointer+'/summary';
  $('riActions').classList.remove('ri-empty');
  $('riActions').innerHTML='<p>Complete provider expense, including processing charges: '+amount(p+'/complete_provider_expense_including_payment_processing_usd')+'; per expected accepted output: '+amount(p+'/complete_provider_expense_including_payment_processing_per_expected_accepted/value')+'. Refunds are contra-revenue.</p><p>Lifetime allocated: '+amount(p+'/lifetime_allocation_usd')+'. Idle earmark: '+amount(p+'/idle_earmark_usd')+'. Executor purchases: '+amount(p+'/executor_purchases','integer')+'.</p>'+cards.join('')+'<p class="ri-data-note">Simulated failed candidates: '+amount(p+'/simulated_candidates_failed','integer')+'; simulated promotions: '+amount(p+'/simulated_candidates_promoted','integer')+'. These are assumed financial-path outcomes, not empirical capabilities.</p>';
}

function renderCustomer() {
  if(!selectedCase)return;
  const scope=$('riCustomerScope').value, minutes=selectedCase.profile==='cost_050_hypothesis'?null:Number($('riHumanMinutes').value);
  const index=selectedCase.customer_comparison.comparisons.findIndex(c=>c.scope===scope&&c.productive_human_minutes_assumed===minutes);
  if(index<0){$('riCustomerResults').innerHTML='No matching comparator exists.';return;}
  const c=selectedCase.customer_comparison.comparisons[index], p=selectedPointer+'/customer_comparison/comparisons/'+index, common=selectedPointer+'/customer_comparison/common';
  const rows=[
    tableRow('Compared request cohort',p+'/cohort_requests','Same served cohort or the entire stated annual demand','number'),
    tableRow('Traditional total cost',p+'/traditional_total_usd','Full traditional workflow and applicable readiness'),
    tableRow('Customer total with Agent + fallback',p+'/hybrid_total_usd','Face invoices + customer effort + every fallback + readiness'),
    tableRow('Estimated customer savings',p+'/customer_savings_usd','Released capacity or modeled cost; not realized cash savings'),
    tableRow('Hybrid cost per completed request',p+'/hybrid_cost_per_completed_request/value','Traditional final acceptance is an assumption'),
    tableRow('Fallback requests',p+'/fallback_requests','Unaccepted served work plus unserved demand in the full-demand view','number'),
    tableRow('Agent-customer attention',common+'/agent_customer_attention_minutes','Preparation, review and fixed governance minutes','number'),
    tableRow('Total customer attention with fallback',p+'/fallback_resource_requirements/total_customer_attention_minutes','Unknown where the hypothetical task duration is unspecified','number'),
    tableRow('Fallback traditional worker minutes',p+'/fallback_resource_requirements/fallback_worker_minutes','Additional labor requirement, when known','number'),
    tableRow('Maximum customer-beneficial face price',p+'/maximum_customer_beneficial_face_price_usd/value','Cohort-conditional, not a demand forecast'),
    tableRow('Provider combined-cost break-even price',selectedPointer+'/summary/combined_cost_conditional_break_even_price_usd/value','Fixed simulated cohort; no repricing or demand response'),
  ];
  $('riCustomerResults').classList.remove('ri-empty');
  $('riCustomerResults').innerHTML=(c.comparison_status==='NO_SERVED_COHORT'?'<p><strong>No served cohort.</strong> Cost comparisons for an empty cohort are unavailable. Select annual demand to inspect complete traditional fallback.</p>':'')+compactTable(rows)+'<p class="ri-data-note">Conditional viable price interval: '+escape(c.cohort_conditional_viable_price_interval_exists==null?'Unavailable':c.cohort_conditional_viable_price_interval_exists?'Yes under these assumptions':'No under these assumptions')+'. Fallback resources: '+escape(humanize(c.fallback_resource_requirements?.status))+'. An aggregate fit is not demonstrated daily staffing.</p>';
}

function renderTokens() {
  renderSourceRoute();
  if(!tokenData)return;
  const route=$('riRoute').value;
  if(route==='ordinary_offchain'){$('riTokenResults').innerHTML='<p>The ordinary-USD cash policy above is proposed off-chain enterprise accounting. No inspected contract automatically implements it.</p>';return;}
  const i=tokenData.realization_cases.findIndex(c=>c.route===route&&c.quoted_job_amount_usd===Number($('riTokenQuote').value)&&c.realization_scenario===$('riRealization').value);
  if(i<0)throw new Error('No prespecified settlement case matches.');
  const c=tokenData.realization_cases[i], p='/realization_cases/'+i, success=c.source_success_case, ap=p+'/source_success_case/atomic';
  const fields=[['Customer escrow','customer_escrow'],['Worker customer-funded award','worker_customer_funded_award'],['Validator awards / allocation',route==='jobs_v0_agialpha_success_only'?'validator_allocation_total':'total_validator_awards'],['wallet30','wallet30'],['wallet10','wallet10'],['FeePool pending claims','fee_pool_pending_claims_increment'],['Burn','burn'],['Worker bond, separately committed','worker_bond']].filter(([,key])=>success.atomic[key]!==undefined);
  let body='<p><strong>'+escape(c.asset)+' · source integer-unit settlement with chosen configuration.</strong> '+escape(c.quoted_amount_meaning)+'. '+escape(success.conditions??'Configured source-success conditions; no transaction executed.')+'</p><div class="ri-table-wrap"><table class="ri-table"><thead><tr><th>Per successful job</th><th>Exact asset units</th><th>Economic treatment</th></tr></thead><tbody>';
  body+=fields.map(([label,key])=>'<tr><td>'+escape(label)+'</td><td>'+atomicCell(ap+'/'+key,c.asset_decimals,c.asset)+'</td><td>'+escape(key==='worker_customer_funded_award'?'Identified worker receipt before business costs':key==='worker_bond'?'Committed capital; returned principal is not revenue':key==='burn'?'Destroyed units; no cash proceeds':'Separate beneficiary or escrow account')+'</td></tr>').join('')+'</tbody></table></div>';
  body+='<h4>Hypothetical monthly realization</h4>'+compactTable([
    tableRow('Assumed accepted settlements',p+'/monthly_accepted_settlements_assumed','An example month, not observed demand','integer','token'),
    tableRow('Assumed quote USD per asset unit',p+'/quote_usd_per_asset_unit_assumed','Illustrative accounting ratio; not a market quote','rate','token'),
    tableRow('Cash realized in the simulation',p+'/monthly_cash_realized_in_simulation_usd','After value/slippage/conversion and liquidity limit','money','token'),
    tableRow('Worker gas allowance',p+'/worker_settlement_gas_allowance_usd','Charged even when conversion liquidity is zero','money','token'),
    tableRow('Cash after worker gas',p+'/monthly_realized_cash_after_worker_gas_usd','Before enterprise delivery, setup, labor, tax and reserves','money','token'),
    tableRow('Funding gap for gas',p+'/cash_funding_gap_for_gas_usd','Negative proceeds require external funding','money','token'),
    tableRow('Unconverted inventory at quote',p+'/unconverted_inventory_quote_value_usd_not_cash','Asset inventory, not spendable USD','money','token'),
    tableRow('Required collateral at quote',p+'/required_collateral_stock_quote_usd','Working-capital stock, separate from earnings','money','token'),
    tableRow('Imputed monthly capital cost',p+'/monthly_imputed_capital_cost_usd_not_cash_loan','Opportunity-cost assumption; no cash loan','money','token'),
  ]);
  const failures=tokenData.failure_examples.map((f,j)=>({f,j})).filter(({f})=>f.route===route&&f.quoted_job_amount_usd===Number($('riTokenQuote').value));
  body+='<details><summary>Failure routes and source limitations</summary>'+(failures.length?failures.map(({f,j})=>'<p><strong>'+escape(humanize(f.outcome))+'</strong></p><p>'+escape(f.scope??'Source failure arithmetic; no field transaction or enterprise loss model.')+'</p><pre>'+escape(JSON.stringify(f.atomic,null,2))+'</pre>').join(''):'<p>Jobs-v0 failed/no-quorum numerical economics are NOT MODELED because the complete verified live penalty configuration is unavailable. No full-buyer-refund assumption is made.</p>')+'</details><p class="ri-data-note"><strong>Worker receipts are not profit or automatically reinvestable surplus.</strong> These settlement scenarios are separate from the ordinary-USD enterprise model. Actual transactions and current-chain configuration validation are NOT RUN.</p>';
  $('riTokenResults').classList.remove('ri-empty');$('riTokenResults').innerHTML=body;
}

async function unpack(encoded,expected) {
  const raw=Uint8Array.from(atob(encoded),c=>c.charCodeAt(0));
  const bytes=new Uint8Array(await new Response(new Blob([raw]).stream().pipeThrough(new DecompressionStream('gzip'))).arrayBuffer());
  const actual=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),b=>b.toString(16).padStart(2,'0')).join('');
  if(actual!==expected)throw new Error('Embedded audited result checksum mismatch.');
  return {raw:bytes,data:JSON.parse(new TextDecoder().decode(bytes))};
}

function renderSkeleton() {
  cashSelection();
  text('riLoadStatus', 'Frozen specification loaded. The financial result bundle is awaiting independent audit binding; no economic result is displayed.');
  renderSourceRoute();
}

$('riShowBrief').onclick = () => showArtifact('brief');
$('riShowSlides').onclick = () => showArtifact('slides');
$('riBriefDownload').onclick = () => save('recorded-publication-brief.html',payload.nativeArtifacts['observed/output/brief.html'],'text/html');
$('riSlidesDownload').onclick = () => save('recorded-handover-slides.html',payload.nativeArtifacts['observed/output/slides.html'],'text/html');
$('riAcceptanceDownload').onclick = () => save('recorded-acceptance.json',payload.nativeArtifacts['observed/acceptance.json'],'application/json');
$('riDownloadInputs').onclick = () => save('reinvestment-frozen-inputs.json',payload.inputsRaw,'application/json');
cashSelectors.forEach(id => $(id).addEventListener('change', renderCash));
$('riMonth').addEventListener('change',renderMonth);
['riHumanMinutes','riCustomerScope'].forEach(id=>$(id).addEventListener('change',renderCustomer));
['riRoute','riTokenQuote','riRealization'].forEach(id => $(id).addEventListener('change', renderTokens));
text('riNativeTime', payload.native.native_delivery_wall_seconds.toFixed(3) + ' seconds · recorded component boundary');
text('riIdentity', JSON.stringify({phase:payload.phase,...payload.identity,native:payload.native},null,2));
$('riCashDiagram').innerHTML = payload.diagram.replace(/^<\?xml[^>]*>\s*/,'');
showArtifact('brief');
renderSkeleton();
window.REINVESTMENT_DEMO = {phase:payload.phase,identity:payload.identity,getSelection:cashSelection,financialResultsBound:false,tokenResultsBound:false,ready:false};
try {
  if(payload.cashCompressed){
    const loaded=await unpack(payload.cashCompressed,payload.identity.cashResultsSha256);cashData=loaded.data;
    $('riDownloadResults').disabled=false;$('riDownloadResults').onclick=()=>save('financial-results.json',loaded.raw,'application/json');
    REINVESTMENT_DEMO.financialResultsBound=true;renderCash();
  }
  if(payload.tokenCompressed){
    const loaded=await unpack(payload.tokenCompressed,payload.identity.tokenResultsSha256);tokenData=loaded.data;
    $('riDownloadTokens').disabled=false;$('riDownloadTokens').onclick=()=>save('token-waterfalls.json',loaded.raw,'application/json');
    REINVESTMENT_DEMO.tokenResultsBound=true;renderTokens();
  }
  if(payload.bundle){$('riDownloadBundle').disabled=false;$('riDownloadBundle').onclick=()=>save('reinvestment-inputs-model-results-audits.zip',Uint8Array.from(atob(payload.bundle.base64),c=>c.charCodeAt(0)),'application/zip');}
  if(payload.auditBundle){$('riDownloadAudit').disabled=false;$('riDownloadAudit').onclick=()=>save('independent-financial-audits.zip',Uint8Array.from(atob(payload.auditBundle),c=>c.charCodeAt(0)),'application/zip');}
  if(payload.modelBundle){$('riDownloadModel').disabled=false;$('riDownloadModel').onclick=()=>save('executable-financial-models.zip',Uint8Array.from(atob(payload.modelBundle),c=>c.charCodeAt(0)),'application/zip');}
  REINVESTMENT_DEMO.ready=true;
  REINVESTMENT_DEMO.getCase=()=>selectedCase;
  REINVESTMENT_DEMO.getCasePointer=()=>selectedPointer;
  REINVESTMENT_DEMO.selectCase=(id)=>{
    const row=[...(cashData?.primary_cases??[]),...(cashData?.demand_sensitivity_cases??[])].find(c=>c.case_id===id);
    if(!row)throw Error('Unknown prespecified case');
    const map={riProfile:'profile',riScenario:'scenario',riPrice:'price_usd_per_accepted',riReinvest:'reinvestment_fraction',riWorld:'outcome_world',riDemand:'demand_multiplier'};
    for(const [id,key]of Object.entries(map))$(id).value=String(row[key]);renderCash();
  };
} catch(error) { text('riLoadStatus','Result bundle refused: '+error.message);$('riLoadStatus').classList.add('ri-error');REINVESTMENT_DEMO.error=error.message; }
