# SPDX-License-Identifier: Apache-2.0
"""Build an additive offline companion; never execute a financial scenario."""
from __future__ import annotations

import argparse
import base64
import gzip
import hashlib
import io
import json
import re
import zipfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
HERE = ROOT / "browser"
SEALED = ROOT.parent / "capability_study/browser/AGI_ALPHA_Capability_Construction_Demo.html"
SEALED_SHA = "e5a0ddd0f34199952b532a9eac7ea336186818fa6b922da98f0db08cfede65cd"
FREEZE_SHA = "4c7bac19106f946920d64ad39b01cb2cc844eed78c5cdb4d79140904a10cc9ba"


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def read(path: Path):
    return json.loads(path.read_text())


def live_functions(text: str) -> dict[str, str]:
    boundaries = [
        ("run", "async function run(spec,parentIndex=null)", "function loadAndRun(index)"),
        ("successor", "function loadAndRun(index)", "async function restore(raw)"),
        ("recovery", "async function restore(raw)", "for(const tab of document.querySelectorAll"),
        ("module_resolution", "function normalize(path)", "function status(text,error=false)"),
    ]
    return {name: sha(text.split(start, 1)[1].split(end, 1)[0].encode()) for name, start, end in boundaries}


def zipped(files: dict[str, bytes]) -> bytes:
    output=io.BytesIO()
    with zipfile.ZipFile(output,"w",zipfile.ZIP_DEFLATED) as archive:
        for name,raw in sorted(files.items()):
            info=zipfile.ZipInfo(name,(2026,10,25,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
            archive.writestr(info,raw)
    return output.getvalue()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--skeleton", action="store_true", help="Show recorded work and source mechanisms only; no financial result.")
    parser.add_argument("--results",type=Path)
    parser.add_argument("--token-results",type=Path)
    parser.add_argument("--cash-audit",type=Path)
    parser.add_argument("--token-audit",type=Path)
    args = parser.parse_args()
    if not args.skeleton and any(p is None for p in [args.results,args.token_results,args.cash_audit,args.token_audit]):
        raise ValueError("Final builds require both exact output files and their independent audit paths")
    original_bytes = SEALED.read_bytes()
    if sha(original_bytes) != SEALED_SHA:
        raise ValueError("Preserved companion identity changed")
    freeze_bytes = (ROOT / "FREEZE.json").read_bytes()
    if sha(freeze_bytes) != FREEZE_SHA:
        raise ValueError("Prospective financial freeze identity changed")
    freeze = json.loads(freeze_bytes)
    for row in freeze["files"]:
        raw = (ROOT / row["path"]).read_bytes()
        if sha(raw) != row["sha256"] or len(raw) != row["bytes"]:
            raise ValueError("Frozen input mismatch: " + row["path"])
    auth = read(ROOT / "AUTHORIZATION.json")
    if auth["freeze_sha256"] != FREEZE_SHA or not auth["public_readback_exact"]:
        raise ValueError("Authorization does not bind the public freeze")
    native = read(ROOT / "prior_model_anchor.json")["native_observation"]
    originals = {}
    for row in native["identities"]:
        path = ROOT.parent / row["original_path"]
        raw = path.read_bytes()
        if len(raw) != row["bytes"] or sha(raw) != row["sha256"]:
            raise ValueError("Preserved native artifact mismatch: " + row["original_path"])
        originals[row["copy_path"]] = raw.decode()
    payload = {
        "schema": "reinvestment-browser/v1",
        "phase": "FROZEN_SKELETON_AWAITING_AUDITED_RESULT_BINDING",
        "inputs": read(ROOT / "inputs.json"),
        "tokenInputs": read(ROOT / "token_scenarios.json"),
        "inputsRaw": (ROOT / "inputs.json").read_text(),
        "tokenInputsRaw": (ROOT / "token_scenarios.json").read_text(),
        "protocolRaw": (ROOT / "PROTOCOL.md").read_text(),
        "native": native,
        "nativeArtifacts": originals,
        "flowMatrix": read(ROOT / "contracts/FLOW_MATRIX.json"),
        "sourceRegister": read(ROOT / "contracts/SOURCE_REGISTER.json"),
        "diagram": (ROOT / "figures/economic_engine_flow.svg").read_text(),
        "identity": {
            "freezeSha256": FREEZE_SHA,
            "originalCompanionSha256": SEALED_SHA,
            "publicFreezeCommit": auth["public_source_commit"],
            "publicNotice": auth["public_notice"],
            "financialResults": "NOT_BOUND",
            "independentAudit": "NOT_BOUND",
            "authenticatedExecutor": "NOT_RUN",
            "actualFinancialTransactions": "NOT_RUN",
            "runtimeNetworkRequests": [],
        },
    }
    bundle_manifest=[]
    if not args.skeleton:
        paths=[p.resolve() for p in [args.results,args.token_results,args.cash_audit,args.token_audit]]
        for p in paths:p.relative_to(ROOT)
        cash_path,token_path,cash_audit_path,token_audit_path=paths
        cash=read(cash_path);token=read(token_path);cash_audit=read(cash_audit_path);token_audit=read(token_audit_path)
        for result,path,audit in [(cash,cash_path,cash_audit),(token,token_path,token_audit)]:
            if result["identities"]["freeze_sha256"]!=FREEZE_SHA:
                raise ValueError("Result freeze mismatch")
            if audit["status"]!="PASS" or audit["producer_results_sha256"]!=sha(path.read_bytes()):
                raise ValueError("Independent audit must bind the exact result")
        cash_model=ROOT/"src/financial_model.py";token_model=ROOT/"src/token_waterfalls.py"
        if cash["identities"]["model_sha256"]!=sha(cash_model.read_bytes()) or token["identities"]["model_sha256"]!=sha(token_model.read_bytes()):
            raise ValueError("Exact executable model identity mismatch")
        if token["identities"]["shared_io_authorization_module_sha256"]!=sha(cash_model.read_bytes()):
            raise ValueError("Token model shared source identity mismatch")
        if cash_audit.get("producer_model_sha256")!=sha(cash_model.read_bytes()):
            raise ValueError("Cash audit source identity mismatch")
        revision=ROOT/"REPORTING_REVISION.json"
        if cash["reporting_revision"]["sha256"]!=sha(revision.read_bytes()):
            raise ValueError("Preserved reporting adjudication mismatch")
        payload["phase"]="AUDITED_FROZEN_FINANCIAL_SIMULATION_WITH_RECORDED_NATIVE_WORK"
        payload["identity"].update({
            "financialResults":"BOUND_TO_INDEPENDENT_PASS",
            "independentAudit":"PASS_NUMERICAL_CONSISTENCY_NOT_EMPIRICAL_SERVICE",
            "cashResultsPath":cash_path.relative_to(ROOT).as_posix(),"cashResultsSha256":sha(cash_path.read_bytes()),
            "tokenResultsPath":token_path.relative_to(ROOT).as_posix(),"tokenResultsSha256":sha(token_path.read_bytes()),
            "cashAuditPath":cash_audit_path.relative_to(ROOT).as_posix(),"cashAuditSha256":sha(cash_audit_path.read_bytes()),
            "tokenAuditPath":token_audit_path.relative_to(ROOT).as_posix(),"tokenAuditSha256":sha(token_audit_path.read_bytes()),
            "cashModelSha256":sha(cash_model.read_bytes()),"tokenModelSha256":sha(token_model.read_bytes()),
            "reportingRevisionSha256":sha(revision.read_bytes()),
        })
        payload["cashCompressed"]=base64.b64encode(gzip.compress(cash_path.read_bytes(),mtime=0)).decode()
        payload["tokenCompressed"]=base64.b64encode(gzip.compress(token_path.read_bytes(),mtime=0)).decode()
        files={row["path"]:(ROOT/row["path"]).read_bytes() for row in freeze["files"]}
        extra=[ROOT/"FREEZE.json",ROOT/"AUTHORIZATION.json",revision,cash_model,token_model,*paths]
        for directory in [cash_path.parent,token_path.parent]:extra.extend(p for p in directory.iterdir() if p.is_file())
        extra.extend(p for p in (ROOT/"evaluation").glob("*.py"))
        extra.extend(p for p in (ROOT/"evaluation").glob("*AUDIT*.json"))
        for p in extra:files[p.relative_to(ROOT).as_posix()]=p.read_bytes()
        for name,raw in originals.items():files["native/"+name]=raw.encode()
        for name,raw in sorted(files.items()):bundle_manifest.append({"path":name,"bytes":len(raw),"sha256":sha(raw)})
        files["BROWSER_BUNDLE_MANIFEST.json"]=(json.dumps(bundle_manifest,indent=2)+"\n").encode()
        files["BROWSER_BUNDLE_README.txt"]=(
            "Financial simulation and source-inspected settlement scenarios, not actual enterprise revenue.\n"
            "The original native artifacts are under native/observed. Model result/audit identities are in the HTML build manifest.\n"
            "Reproduce after extraction using new absent directories; never overwrite recorded results:\n"
            "python src/financial_model.py --root . --out outputs/reproduction-cash-001\n"
            "python src/token_waterfalls.py --root . --out outputs/reproduction-token-001\n"
            "The two financial routes remain separate; no transaction, provider call or new authority is granted.\n"
            "Exactly 144 primary plus 32 additional demand financial paths and 27 settlement realizations are recorded.\n"
            "The complete research package preserves earlier development attempts and further source material separately.\n"
        ).encode()
        bundle=zipped(files);payload["bundle"]={"base64":base64.b64encode(bundle).decode(),"bytes":len(bundle),"sha256":sha(bundle)}
        model_zip=zipped({"src/financial_model.py":cash_model.read_bytes(),"src/token_waterfalls.py":token_model.read_bytes(),"README.txt":b"Source-only download. Use the complete evidence bundle for frozen inputs, authorization, output directories and reproduction.\n"})
        payload["modelBundle"]=base64.b64encode(model_zip).decode();payload["modelBundleSha256"]=sha(model_zip)
        audit_zip=zipped({p.relative_to(ROOT).as_posix():p.read_bytes() for p in [cash_audit_path,token_audit_path,ROOT/"evaluation/REPORTING_REVISION_AUDIT.json"]})
        payload["auditBundle"]=base64.b64encode(audit_zip).decode();payload["auditBundleSha256"]=sha(audit_zip)
    original = original_bytes.decode()
    html = original.replace("Build the capability<br>that builds what comes next.", "Useful work.<br>What can its proceeds fund?")
    html = html.replace("Receive useful work. Keep the method. See exactly what the next mission inherits—and whether that inheritance earns its cost.", "Start with the finished brief. Follow a proposed business from invoices to collected cash, protected reserves and the next funded method. Inspect every assumption and every failed path.")
    html = html.replace("Research companion, 25 October 2026", "Reinvestment amendment · recorded work + financial simulation · 25 October 2026")
    nav = '<nav class="tabs" aria-label="Demonstration modes"><div class="wrap"><button role="tab" aria-selected="true" data-tab="economics">Work, cash &amp; next methods</button><button role="tab" aria-selected="false" data-tab="live">Successive missions · live local</button><button role="tab" aria-selected="false" data-tab="recorded">Original study · recorded</button><button role="tab" aria-selected="false" data-tab="executor">Executor &amp; boundaries</button></div></nav>'
    html, count = re.subn(r'<nav class="tabs".*?</nav>', lambda _: nav, html, count=1, flags=re.S)
    if count != 1:
        raise ValueError("Original navigation marker missing")
    panel = (HERE / "reinvestment_panel.html").read_text()
    html, count = re.subn(r'<section class="panel" id="economics" hidden>.*?</section>', lambda _: panel, html, count=1, flags=re.S)
    if count != 1:
        raise ValueError("Original economics panel marker missing")
    html = html.replace('<section class="panel" id="live">', '<section class="panel" id="live" hidden>')
    start = html.index("function model(){")
    end = html.index("window.CAPABILITY_DEMO=", start)
    html = html[:start] + "// Original illustrative calculator replaced by the separately frozen financial amendment.\n" + html[end:]
    html = html.replace("</head>", "<style>" + (HERE / "reinvestment_style.css").read_text() + "</style></head>", 1)
    encoded = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).replace("<", "\\u003c")
    extra = '<script id="reinvestment-payload" type="application/json">' + encoded + '</script>\n<script type="module">\n' + (HERE / "reinvestment_ui.mjs").read_text() + "\n</script>\n"
    html = html.replace("</body>", extra + "</body>", 1)
    if live_functions(original) != live_functions(html):
        raise ValueError("Preserved local invocation or recovery code changed")
    destination = HERE / "AGI_ALPHA_Reinvestment_Policy_Demo.html"
    destination.write_text(html)
    manifest = {
        "schema": "reinvestment-browser-build/v1", "phase": payload["phase"],
        "path": destination.name, "bytes": destination.stat().st_size,
        "sha256": sha(destination.read_bytes()), "identity": payload["identity"],
        "live_function_hashes": live_functions(html), "frozen_files_checked": len(freeze["files"]),
        "original_companion_unchanged": sha(SEALED.read_bytes()) == SEALED_SHA,
        "scenario_calculations_performed_by_builder": 0,
        "financial_numbers_displayed": not args.skeleton, "external_runtime_requests": [],
        "publication": "PREPARED_OFFLINE_NOT_DEPLOYED",
    }
    if not args.skeleton:
        manifest.update({"evidence_bundle_sha256":payload["bundle"]["sha256"],"evidence_bundle_bytes":payload["bundle"]["bytes"],"evidence_files":bundle_manifest,"audit_bundle_sha256":payload["auditBundleSha256"],"model_bundle_sha256":payload["modelBundleSha256"]})
    (HERE / "BUILD_MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n")
    with (HERE / "BUILD_ATTEMPTS.jsonl").open("a") as stream:
        stream.write(json.dumps({"created_utc": datetime.now(timezone.utc).isoformat(), **manifest}) + "\n")
    print(json.dumps({k: v for k, v in manifest.items() if k not in ["live_function_hashes","evidence_files"]}, indent=2))


if __name__ == "__main__":
    main()
