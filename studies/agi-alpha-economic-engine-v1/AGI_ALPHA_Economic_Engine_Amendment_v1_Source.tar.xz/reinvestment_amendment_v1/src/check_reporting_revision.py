# SPDX-License-Identifier: Apache-2.0
"""Read-only reproduction of the preserved report-only path comparison."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    before_path = ROOT / "outputs/run-001/results.json"
    after_path = ROOT / "outputs/run-002/results.json"
    before = json.loads(before_path.read_text())
    after = json.loads(after_path.read_text())
    checks, errors = 0, []
    old = before["primary_cases"] + before["demand_sensitivity_cases"]
    new = after["primary_cases"] + after["demand_sensitivity_cases"]
    if len(old) != len(new):
        raise AssertionError("Case count changed")
    for first, second in zip(old, new):
        for key, value in first["summary"].items():
            checks += 1
            if value != second["summary"][key]:
                errors.append([first["case_id"], "summary", key])
        for month, (left, right) in enumerate(zip(first["monthly"], second["monthly"]), 1):
            for key, value in left.items():
                if key == "next_month_resource_feasible_requests":
                    continue  # This is the specifically adjudicated reporting field.
                checks += 1
                if value != right[key]:
                    errors.append([first["case_id"], month, key])
        for key in ["candidates", "capacity_purchases", "events", "profile_accounts"]:
            checks += 1
            if first[key] != second[key]:
                errors.append([first["case_id"], key])
        for left, right in zip(first["customer_comparison"]["comparisons"], second["customer_comparison"]["comparisons"]):
            if left["scope"] != "annual_demand":
                continue
            for key, value in left.items():
                checks += 1
                if value != right[key]:
                    errors.append([first["case_id"], "annual_demand", key])
    for name in ["cost_ledger.csv", "event_ledger.csv"]:
        checks += 1
        if (ROOT / "outputs/run-001" / name).read_bytes() != (ROOT / "outputs/run-002" / name).read_bytes():
            errors.append(["ledger identity", name])
    first_token = json.loads((ROOT / "outputs/token-run-001/token_waterfalls.json").read_text())
    second_token = json.loads((ROOT / "outputs/token-run-002/token_waterfalls.json").read_text())
    for key in ["source_success_waterfalls", "realization_cases", "failure_examples", "not_modeled", "precision", "cash_bridge_to_dynamic_model"]:
        checks += 1
        if first_token[key] != second_token[key]:
            errors.append(["token numerical content", key])
    print(json.dumps({"status": "PASS" if not errors else "FAIL", "checks": checks, "errors": errors,
                      "earlier_results_sha256": hashlib.sha256(before_path.read_bytes()).hexdigest(),
                      "revised_results_sha256": hashlib.sha256(after_path.read_bytes()).hexdigest()}, indent=2))
    if errors:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
