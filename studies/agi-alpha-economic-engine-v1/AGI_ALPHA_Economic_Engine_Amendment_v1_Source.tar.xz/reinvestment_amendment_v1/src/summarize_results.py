# SPDX-License-Identifier: Apache-2.0
"""Describe already audited cases; this file does not evaluate financial scenarios."""
from __future__ import annotations

import hashlib
import json
from collections import Counter
from pathlib import Path
from statistics import median

ROOT = Path(__file__).resolve().parents[1]


def read(relative):
    return json.loads((ROOT / relative).read_text())


def sha(relative):
    return hashlib.sha256((ROOT / relative).read_bytes()).hexdigest()


def money(value):
    return "unavailable" if value is None else f"{value:,.2f}"


def number(value):
    return f"{value:,.2f}".rstrip("0").rstrip(".")


def selected(cases, **criteria):
    matches = [c for c in cases if all(c[k] == v for k, v in criteria.items())]
    assert len(matches) == 1, (criteria, len(matches))
    return matches[0]


def interval(values):
    values = [v for v in values if v is not None]
    return None if not values else {"minimum": min(values), "median": median(values), "maximum": max(values)}


def provider_distribution(cases):
    active = [c for c in cases if c["summary"]["startup_admitted"]]
    income = [c["summary"]["combined_income_after_tax_reserve_usd"] for c in active]
    return {
        "case_count": len(cases),
        "status_counts": dict(Counter(c["summary"]["status"] for c in cases)),
        "startup_admitted_count": len(active),
        "after_tax_reserve_combined_income_positive": sum(v > 0 for v in income),
        "after_tax_reserve_combined_income_zero": sum(v == 0 for v in income),
        "after_tax_reserve_combined_income_negative": sum(v < 0 for v in income),
        "income_usd_distribution_startup_admitted": interval(income),
        "complete_provider_expense_per_expected_accepted_distribution": interval([
            c["summary"]["complete_provider_expense_including_payment_processing_per_expected_accepted"]["value"]
            for c in active]),
        "cases_constructing_candidates": sum(c["summary"]["candidate_constructions"] > 0 for c in cases),
        "cases_buying_executor_capacity": sum(c["summary"]["executor_purchases"] > 0 for c in cases),
        "case_ids": [c["case_id"] for c in cases],
    }


def customer_distribution(cases, scope, duration):
    rows = [(c, next(r for r in c["customer_comparison"]["comparisons"]
                    if r["scope"] == scope and r["productive_human_minutes_assumed"] == duration))
            for c in cases]
    meaningful = [(c, r) for c, r in rows if r["customer_savings_usd"] is not None]
    return {
        "scope": scope,
        "productive_human_minutes_assumed": duration,
        "case_count": len(rows),
        "meaningful_comparison_count": len(meaningful),
        "no_served_cohort_count": sum(r["comparison_status"] == "NO_SERVED_COHORT" for _, r in rows),
        "no_agent_service_count": sum(c["summary"]["requests_served"] == 0 for c, _ in rows),
        "positive_customer_savings_count": sum(r["customer_savings_usd"] > 0 for _, r in meaningful),
        "zero_customer_savings_count": sum(r["customer_savings_usd"] == 0 for _, r in meaningful),
        "negative_customer_savings_count": sum(r["customer_savings_usd"] < 0 for _, r in meaningful),
        "positive_customer_savings_and_positive_provider_income_count": sum(
            r["customer_savings_usd"] > 0 and c["summary"]["combined_income_after_tax_reserve_usd"] > 0
            for c, r in meaningful),
        "customer_savings_usd_distribution": interval([r["customer_savings_usd"] for _, r in meaningful]),
        "aggregate_fallback_resource_status_counts": dict(Counter(
            r["fallback_resource_requirements"]["status"] for _, r in rows)),
        "aggregate_customer_pool_infeasible_count": sum(
            r["fallback_resource_requirements"].get("customer_pool_feasible") is False for _, r in rows),
        "aggregate_worker_pool_infeasible_count": sum(
            r["fallback_resource_requirements"].get("traditional_worker_pool_feasible") is False for _, r in rows),
        "case_ids": [c["case_id"] for c, _ in rows],
    }


def summary_row(case):
    s = case["summary"]
    return {
        "case_id": case["case_id"], "profile": case["profile"], "scenario": case["scenario"],
        "price_usd_per_accepted": case["price_usd_per_accepted"],
        "reinvestment_fraction": case["reinvestment_fraction"], "outcome_world": case["outcome_world"],
        "demand_multiplier": case["demand_multiplier"],
        "collected_revenue_after_refunds_before_processing_usd": s["gross_collections_usd"] - s["refunds_usd"],
        **{k: s[k] for k in ["status", "annual_requested_demand", "requests_served", "expected_accepted",
            "expected_unresolved_served", "unserved_annual_demand", "setup_workdays_before_operating_horizon",
            "quoted_startup_usd", "stop_month", "complete_provider_expense_including_payment_processing_usd",
            "complete_provider_expense_including_payment_processing_per_expected_accepted",
            "combined_income_before_tax_reserve_usd", "combined_income_after_tax_reserve_usd",
            "closing_cash_usd", "closing_liquid_free_cash_after_targets_usd", "tax_reserve_usd",
            "warranty_reserve_usd", "working_capital_reserve_target_usd", "lifetime_allocation_usd",
            "discretionary_construction_and_capacity_paid_usd", "idle_earmark_usd", "released_unused_earmarks_usd",
            "candidate_constructions", "simulated_candidates_failed", "simulated_candidates_promoted",
            "executor_purchases", "final_nonlabor_factor", "final_provider_time_factor",
            "zero_reinvestment_break_even_price_usd", "combined_cost_conditional_break_even_price_usd"]},
    }


def main():
    data = read("outputs/run-002/results.json")
    tokens = read("outputs/token-run-002/token_waterfalls.json")
    audit = read("evaluation/INDEPENDENT_AUDIT.json")
    assert audit["status"] == "PASS" and audit["differences_remaining"] == 0
    assert sha("outputs/run-002/results.json") == audit["producer_results_sha256"]
    assert sha("outputs/token-run-002/token_waterfalls.json") == audit["token_results_sha256"]
    assert sha("src/financial_model.py") == audit["producer_model_sha256"]
    assert sha("src/token_waterfalls.py") == audit["token_model_sha256"]
    primary, sensitivities = data["primary_cases"], data["demand_sensitivity_cases"]
    assert len(primary) == 144 and len(sensitivities) == 32
    cases = primary + sensitivities
    profiles = ["evidence_pack", "cost_050_hypothesis"]
    six = [summary_row(selected(primary, profile=p, scenario=s, price_usd_per_accepted=20,
                               reinvestment_fraction=0, outcome_world="no_gain"))
           for p in profiles for s in ["base", "conservative", "stress"]]
    distributions = {}
    for label, group in [("primary", primary), ("demand_sensitivity", sensitivities)]:
        distributions[label] = {}
        for profile in profiles:
            family = [c for c in group if c["profile"] == profile]
            distributions[label][profile] = {
                "provider": provider_distribution(family),
                "customer": [customer_distribution(family, scope, duration)
                             for scope in ["served_cohort", "annual_demand"]
                             for duration in ([5, 15, 30, 60, 120] if profile == "evidence_pack" else [None])],
            }
    policy_rows = [summary_row(c) for c in cases if c["scenario"] == "base"
                   and c["price_usd_per_accepted"] == 20
                   and (c["demand_multiplier"] == 1 or c["demand_multiplier"] == 4)]
    at_one = selected(primary, profile="cost_050_hypothesis", scenario="base", price_usd_per_accepted=20,
                      reinvestment_fraction=.5, outcome_world="no_gain")
    candidate_cases = [selected(sensitivities, profile="cost_050_hypothesis", scenario="base",
                               price_usd_per_accepted=20, demand_multiplier=4,
                               reinvestment_fraction=.5, outcome_world=world)
                       for world in ["no_gain", "assumed_diminishing_gain"]]
    candidate_records = []
    for c in candidate_cases:
        baseline = selected(sensitivities, profile=c["profile"], scenario=c["scenario"],
                            price_usd_per_accepted=20, demand_multiplier=4,
                            reinvestment_fraction=0, outcome_world=c["outcome_world"])
        candidate_records.append({"case_id": c["case_id"], "outcome_world": c["outcome_world"],
                                  "candidates": c["candidates"], "events": c["events"],
                                  "monthly_binding_admission_limits": [
                                      {"month": m["month"], "limits": m["binding_admission_limits"]}
                                      for m in c["monthly"]],
                                  "before_tax_income_difference_vs_zero_allocation_usd":
                                      c["summary"]["combined_income_before_tax_reserve_usd"] - baseline["summary"]["combined_income_before_tax_reserve_usd"],
                                  "after_tax_reserve_income_difference_vs_zero_allocation_usd":
                                      c["summary"]["combined_income_after_tax_reserve_usd"] - baseline["summary"]["combined_income_after_tax_reserve_usd"],
                                  "expected_accepted_difference_vs_zero_allocation":
                                      c["summary"]["expected_accepted"] - baseline["summary"]["expected_accepted"]})
    source_register = read("contracts/SOURCE_REGISTER.json")
    source_urls = {r["id"]: r["url"] for r in source_register["sources"]}
    score = {
        "schema": "reinvestment-results-scorecard/v1",
        "evidence_class": "POST_RESULT_DESCRIPTIVE_EXTRACTION_OF_AUDITED_FROZEN_CASES_NO_NEW_SCENARIOS",
        "identities": {p: sha(p) for p in ["FREEZE.json", "PROTOCOL.md", "inputs.json", "prior_model_anchor.json",
            "token_scenarios.json", "outputs/run-002/results.json", "outputs/token-run-002/token_waterfalls.json",
            "evaluation/INDEPENDENT_AUDIT.json", "src/financial_model.py", "src/token_waterfalls.py", "src/summarize_results.py"]},
        "source_commit": "76ba78492da893b235b071cb0a61cf3608f9db37",
        "coverage": {"primary_cash_paths": 144, "demand_sensitivity_paths": 32, "monthly_rows": 2112,
                     "source_success_waterfalls": 9, "realization_cases": 27, "failure_examples": 9},
        "audit": {k: audit[k] for k in ["status", "total_comparison_checks", "differences_remaining", "checks_by_scope"]},
        "six_profile_scenario_rows_at_price20_zero_reinvestment": six,
        "case_distributions": distributions,
        "allocation_and_spending_rows": policy_rows,
        "one_x_funding_and_payback_timing": {
            "case_id": at_one["case_id"],
            "months": [{k: m[k] for k in ["month", "new_earmark_usd", "idle_earmark_usd", "action", "action_forecasts"]}
                       for m in at_one["monthly"][:2]],
        },
        "four_x_candidate_studies_at_50_percent_allocation": candidate_records,
        "token_source_waterfalls_at_quote20": [r for r in tokens["source_success_waterfalls"] if r["quoted_job_amount_usd"] == 20],
        "token_realization_rows_at_quote20": [r for r in tokens["realization_cases"] if r["quoted_job_amount_usd"] == 20],
        "token_source_urls": source_urls,
        "observed_revenue_usd": None,
        "observed_reinvestment_spending_usd": None,
        "observed_improvement_or_acceleration": None,
        "boundaries": [
            "All amounts are forward simulations; arithmetic audit is not empirical validation.",
            "Case counts are parameter rows, not independent jobs, experiments, probabilities or market weights.",
            "The provider's USD25000 starting cash is not the earlier combined provider/customer USD25000 resource budget.",
            "Twelve operating months follow paid setup; this is not a twelve-calendar-month launch promise.",
            "Complete provider expense includes processing; refunds are contra-revenue; tax reserves are retained cash restrictions.",
            "Evidence-pack human productive durations are assumptions; the USD200 alternative is a separate hypothesis with unknown human duration.",
            "Annual-demand comparisons charge full fallback for failed and unserved requests, subject to explicit staffing limits or unknowns.",
            "Earmarked balances are not construction spending. All primary cases spend zero on candidate construction and executor additions.",
            "Four-times-demand simulated gains are frozen assumptions and do not establish observed capability, extra accepted capacity or self-acceleration.",
            "Token valuations, liquidity and gas are scenarios. No token proceeds enter the ordinary-USD cash model.",
            "Historical authoring and material downstream liability remain unknown, not zero.",
        ],
    }
    (ROOT / "SCORECARD.json").write_text(json.dumps(score, indent=2, ensure_ascii=False) + "\n")

    lines = [
        "# Results interpretation: cash, reinvestment and source-specific settlement",
        "",
        "**Status: audited simulation, not observed business operation.** The [frozen protocol](PROTOCOL.md) was publicly fixed at "
        "[commit 76ba784](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/commit/76ba78492da893b235b071cb0a61cf3608f9db37) before execution. "
        "The 144 primary cash paths, 32 predeclared demand sensitivities, 27 token-realization rows and nine failure examples now have "
        "[independent arithmetic review](evaluation/INDEPENDENT_AUDIT.json): " + f"{audit['total_comparison_checks']:,} comparisons, zero remaining discrepancies. "
        "Those checks are repeated equation, field and ledger comparisons, not independent experiments or acceptance trials. "
        "This report only describes existing audited rows; it adds no scenario, parameter or new performance result.",
        "",
        "The [cash results](outputs/run-002/results.json), [token results](outputs/token-run-002/token_waterfalls.json), "
        "[scorecard](SCORECARD.json) and [CSV ledgers](outputs/run-002/results_summary.csv) expose every case. "
        "The preserved first run and [reporting revision](REPORTING_REVISION.json) show that the revision changed reporting boundaries without changing financial paths.",
        "",
        "## 1. Provider viability is separate from customer savings",
        "",
        "Each row below quotes USD20 per expected accepted output with zero reinvestment. "
        "Revenue is modeled collections after refunds but **before** payment processing; complete expense includes processing, setup, delivery, support, "
        "maintenance and any incurred construction. Income then subtracts the model's retained tax reserve; it is not audited company profit. "
        "Showing revenue before processing avoids subtracting processing twice. Expected accepted counts may be fractional.",
        "",
        "| Profile / scenario | Status | Requests served / expected accepted | Revenue after refunds (USD) | Complete expense (USD) | Income after tax reserve (USD) |",
        "|---|---|---:|---:|---:|---:|",
    ]
    for r in six:
        status = {"OPERATED_FULL_HORIZON": "12 operating months", "STOPPED_WITHOUT_RESTART": f"stopped month {r['stop_month']}", "START_INFEASIBLE": "startup refused"}[r["status"]]
        lines.append(f"| {'Evidence pack' if r['profile']=='evidence_pack' else 'USD0.50 hypothesis'} / {r['scenario']} | {status} | "
                     f"{number(r['requests_served'])} / {number(r['expected_accepted'])} | "
                     f"{money(r['collected_revenue_after_refunds_before_processing_usd'])} | "
                     f"{money(r['complete_provider_expense_including_payment_processing_usd'])} | {money(r['combined_income_after_tax_reserve_usd'])} |")
    lines += ["", "These six rows have distinct assumptions and are not six observed services. The evidence pack remains a bounded brief assembled from four "
              "preselected exact passages; its measured native execution component does not establish end-to-end source discovery, synthesis, cost or field reliability. "
              "The USD0.50 variable-cost / USD200 traditional-replacement profile is a separate, unvalidated offering hypothesis. Its positive base result follows "
              "from those strong assumptions; the conservative and stress results remain visible.", "",
              "The model begins with **USD25,000 of provider cash**. Customer wages, review and fallback costs sit in a separate customer account. "
              "This is not the earlier operating amendment's USD25,000 combined resource budget: it permits collections to finance later service and does not "
              "charge customer labor against provider cash. The horizons also differ. Here twelve operating months follow setup of 48, 164 or 520 modeled workdays "
              "in the base, conservative and stress arrangements. Stress startup requires USD32,323.08, exceeds cash, and is refused; the zero incurred expense "
              "in that row records refusal, not a free deployable service. Setup scheduling, demand, field quality and prices are unvalidated.", "",
              "## 2. Complete-demand customer comparison and duration sensitivity", "",
              "For the base evidence pack at USD20, all 1,000 requests are admitted but only 950 are expected to meet the assumed standard; "
              "the complete-demand comparison therefore buys 50 full traditional fallbacks plus handoff and readiness. A pure Agent cost per accepted output "
              "does not establish completion of every requested job. The following durations change the traditional assumption while holding the Agent scenario fixed; "
              "they do not demonstrate increasingly difficult work at unchanged Agent cost.", "",
              "| Assumed productive human minutes | Traditional total (USD) | Agent plus complete fallback (USD) | Customer savings (USD) | Maximum beneficial Agent face price (USD) |",
              "|---:|---:|---:|---:|---:|"]
    evidence_base = selected(primary, profile="evidence_pack", scenario="base", price_usd_per_accepted=20,
                             reinvestment_fraction=0, outcome_world="no_gain")
    for r in evidence_base["customer_comparison"]["comparisons"]:
        if r["scope"] == "annual_demand":
            lines.append(f"| {r['productive_human_minutes_assumed']} | {money(r['traditional_total_usd'])} | {money(r['hybrid_total_usd'])} | "
                         f"{money(r['customer_savings_usd'])} | {money(r['maximum_customer_beneficial_face_price_usd']['value'])} |")
    lines += ["", "The base evidence-pack zero-reinvestment provider break-even is USD23.21 per accepted-output invoice, with collection loss and lag included, under the fixed-cohort algebra. "
              "At a 30-minute human assumption the customer's maximum beneficial face price is USD15.95, so those conditional bounds do not overlap. "
              "At 60 minutes they do overlap, USD23.21–33.93, but neither the 60-minute duration nor demand at the changed price was measured. "
              "Longer assumptions cannot convert the four-passage fixture into empirical evidence of a USD200 human job. "
              "The separate USD0.50 hypothesis assumes that USD200 all-in comparator and leaves human duration and fallback staffing unknown.", "",
              "Across the **72 primary parameter rows per profile**, results below use full annual-demand fallback. Startup-refused rows remain in the case count "
              "but have no Agent service and zero modeled customer saving; empty served-only cohorts are separately null. Both outcome worlds and allocation "
              "settings can produce identical paths, so these counts are neither frequencies of independent outcomes nor probabilities of commercial success.", "",
              "| Profile / human assumption | Customer saving positive | Negative | Zero | No Agent service | Positive customer saving and positive provider income |",
              "|---|---:|---:|---:|---:|---:|"]
    for profile in profiles:
        for r in distributions["primary"][profile]["customer"]:
            if r["scope"] != "annual_demand":
                continue
            label = f"Evidence pack / {r['productive_human_minutes_assumed']} min" if profile == "evidence_pack" else "USD0.50 / USD200 all-in, duration unknown"
            lines.append(f"| {label} | {r['positive_customer_savings_count']} | {r['negative_customer_savings_count']} | "
                         f"{r['zero_customer_savings_count']} | {r['no_agent_service_count']} | {r['positive_customer_savings_and_positive_provider_income_count']} |")
    lines += ["", "Provider income after the modeled tax reserve is positive in " +
              str(distributions["primary"]["evidence_pack"]["provider"]["after_tax_reserve_combined_income_positive"]) +
              " of 72 evidence-pack rows and " + str(distributions["primary"]["cost_050_hypothesis"]["provider"]["after_tax_reserve_combined_income_positive"]) +
              " of 72 hypothesis rows. Each profile has 24 startup-refused rows, excluded from positive/negative operating-income counts. "
              "The scorecard separately reports primary and sensitivity distributions, ranges, medians, scope, resource infeasibility and unknown staffing. "
              "No duration assumptions or task profiles are pooled into an overall customer-win percentage.", "",
              "## 3. Allocation authority does not imply useful expenditure", "",
              "**All 144 primary paths make zero candidate constructions and zero executor purchases.** "
              "At base hypothesis demand, the first candidate has a positive remaining-horizon forecast of USD48.02 in month 1 but no earned earmark. "
              "By month 2 the 50% policy has USD3,297.77 earmarked, yet the shortened-horizon forecast is negative USD1.80. "
              "The frozen policy stops rather than treating accumulated funds as proof of a good investment. The next eligible candidate never satisfies funding and "
              "the remaining-horizon payback test at the same decision time; stopping that candidate ends the frozen construction sequence.", "",
              "The table shows the USD20 hypothesis profile. Allocation is the cumulative amount earmarked from recovered after-tax operating surplus; "
              "spending is actual modeled construction outlay. Idle earmarks remain cash restrictions. All amounts are simulated, and 50% is one tested policy, "
              "not a contract requirement or privileged result.", "",
              "| Demand / outcome world | Allocation policy | Lifetime earmark (USD) | Construction/capacity spent (USD) | Idle earmark (USD) | Income after tax reserve (USD) |",
              "|---|---:|---:|---:|---:|---:|"]
    for mult, world in [(1, "no_gain"), (4, "no_gain"), (4, "assumed_diminishing_gain")]:
        group = primary if mult == 1 else sensitivities
        for frac in [0, .25, .5, .75]:
            c = selected(group, profile="cost_050_hypothesis", scenario="base", price_usd_per_accepted=20,
                         demand_multiplier=mult, reinvestment_fraction=frac, outcome_world=world)
            s = c["summary"]
            lines.append(f"| {mult}× / {'no gain' if world=='no_gain' else 'assumed gain'} | {int(frac*100)}% | {money(s['lifetime_allocation_usd'])} | "
                         f"{money(s['discretionary_construction_and_capacity_paid_usd'])} | {money(s['idle_earmark_usd'])} | {money(s['combined_income_after_tax_reserve_usd'])} |")
    lines += ["", "The 1× assumed-gain world has the same path because nothing is constructed. At 4× demand, every positive allocation policy funds the same "
              "USD1,250 of construction; larger percentages mostly immobilize more cash in idle earmarks. No case buys an executor. "
              "All 4× hypothesis policies serve 44,640 requests with 42,408 expected acceptances, leaving 3,360 unserved and 2,232 unresolved admitted requests. "
              "The annual-demand comparison charges 5,592 full fallbacks; their worker duration is unknown. Increasing retained-method efficiency does not "
              "increase accepted output in these cases because the unchanged customer-attention pool binds at 3,720 requests per month.", "",
              "## 4. The positive transfer is conditional, and failed search is charged", "",
              "The 4×, 50% policy provides the representative event history. Month 2 spends USD500 on candidate 1; month 3 rejects it in both simulated worlds "
              "and spends USD750 on candidate 2. Month 4 either rejects candidate 2 (no-gain world) or promotes its frozen assumed gain. "
              "In that gain world the promoted method is subsequently applied 33,480 times, saves USD3,325.20 gross, incurs USD135 of upkeep and returns "
              "USD2,440.20 after its own construction and upkeep. Charging the earlier failed candidate reduces the combined before-tax gain to USD1,940.20 "
              "relative to zero investment. The no-gain world loses the full USD1,250 construction cost. These are model arithmetic, not observed inventions.", "",
              "Candidate 2's probability-weighted construction forecast required 17,822 subsequent request uses to cover construction and horizon upkeep; "
              "once a positive outcome is assumed, its realized-horizon algebra requires 8,911 uses. Those are different questions. Candidate 3 is stopped "
              "with negative remaining-horizon forecasts in both worlds (USD−1,087.15 without prior gain; USD−1,170.92 after it). "
              "The gain world reduces nonlabor variable cost to 75% and provider-time cost to 92% of baseline, but leaves quality, customer effort, fixed costs "
              "and executor occupancy unchanged. A single assumed promotion and diminishing returns do not establish acceleration of capability discovery.", "",
              "## 5. Source-specific token proceeds stay outside the USD business loop", "",
              "The following success settlement flows use the frozen chosen configurations and a USD20 quoted job amount. AGIALPHA valuation is an illustrative "
              "USD0.00002 per token, not an observed market quote. Exact atomic transfers, integer floors, collateral and failure branches remain in the "
              "[source formula register](contracts/ROUTE_FORMULAS.md) and [token results](outputs/token-run-002/token_waterfalls.json).", "",
              "| Source route | Customer escrow at illustrative quote (USD) | Worker award before conversion and enterprise costs (USD-equivalent) | Base 100-settlement cash after gas (USD) |",
              "|---|---:|---:|---:|"]
    for r in tokens["realization_cases"]:
        if r["quoted_job_amount_usd"] == 20 and r["realization_scenario"] == "base":
            lines.append(f"| {r['route']} | {money(r['customer_total_escrow_quote_usd_per_job'])} | "
                         f"{r['worker_award_quote_usd_per_job_before_realization']:.6f} | {money(r['monthly_realized_cash_after_worker_gas_usd'])} |")
    lines += ["", "Manager's chosen 30% and 10% wallet allocations plus 8% validator pool leave approximately 52% for the worker, with validator division "
              f"dust returned to it ([settlement source]({source_urls['manager_settlement']}#L111-L133)). "
              "Ascension deducts a 5% validator pool and burns 1% of each payout, giving a 94.05% worker net at these amounts "
              f"([market source]({source_urls['alpha_market']}#L183-L249)). "
              "The Jobs-v0 chosen configuration adds a 5% customer fee to a USD20-equivalent reward, then a 10% validator allocation and 1% worker burn; "
              "the worker receives USD17.82-equivalent from USD21-equivalent total customer escrow "
              f"([registry source]({source_urls['jobs_registry_base']}#L2040-L2136), [stake source]({source_urls['jobs_stake_base']}#L2327-L2484)). "
              "The fee-pool burn and eligible Platform stake claims form a separate distribution "
              f"([FeePool source]({source_urls['jobs_fee']}#L239-L365)). Wallet receipts are not automatically the worker enterprise's income.", "",
              "At the same USD20 quote, all three conservative realization cases hit the USD1,000 monthly liquidity ceiling and retain USD800 after "
              "the assumed USD200 gas cost. In all stress realization cases liquidity is zero, the entire award remains unconverted inventory, and USD1,000 "
              "of gas requires outside cash. Collateral locks and imputed capital costs are separately charged; returned bonds are not revenue. "
              "Even base cash after gas is before delivery, review, setup, support, overhead, tax and reserves, so it is not reinvestable profit. "
              "The model executes no contracts, verifies no current deployment state and creates no bridge from these assets into the ordinary-USD simulation. "
              "Jobs-v0 failed-route numerical economics remain NOT MODELED; historical deployment reports remain attestations. "
              "No universal tokenholder dividend, automatic buyback, automatic treasury appropriation or 50% reinvestment right is inferred.", "",
              "## 6. Commercial interpretation and limits", "",
              "The evidence supports a concrete conditional decision: price, complete delivery cost, customer effort, failed delivery, collections and "
              "remaining useful demand must jointly justify investment. Cash generation can be large under an inexpensive high-value offering hypothesis, "
              "yet does not guarantee a worthwhile candidate or broader productive capacity. The demonstrated brief's modeled economics are less favorable "
              "and remain dependent on hypothetical human duration. The next empirical step is to measure full service cost and field acceptance for a clearly "
              "priced useful offering, then test a frozen candidate's transfer on fresh work; these simulations do not replace that evidence.", "",
              "Historical authoring cost, material downstream liability, real provider contracts, actual customer revenue and observed improvement remain "
              "unknown. They are not zero. High-consequence applications, live custody, daily staffing, stochastic budget protection, token quotas and market "
              "liquidity are outside this validated arithmetic boundary. The completed operational and capability editions remain independent of this "
              "financial amendment.", "",
              "## Exact evidence identities", "",
              f"- Cash results SHA256: `{sha('outputs/run-002/results.json')}`.",
              f"- Token results SHA256: `{sha('outputs/token-run-002/token_waterfalls.json')}`.",
              f"- Independent audit SHA256: `{sha('evaluation/INDEPENDENT_AUDIT.json')}`.",
              f"- Scorecard SHA256: `{sha('SCORECARD.json')}`.",
              "- Reproduce this descriptive extraction with `python reinvestment_amendment_v1/src/summarize_results.py`; it reads the audited outputs and never calls the scenario evaluator.", ""]
    (ROOT / "RESULTS_INTERPRETATION.md").write_text("\n".join(lines))
    print(json.dumps({"status": "WRITTEN_FROM_EXISTING_AUDITED_OUTPUTS", "files": {
        p: {"sha256": sha(p), "bytes": (ROOT / p).stat().st_size}
        for p in ["SCORECARD.json", "RESULTS_INTERPRETATION.md", "src/summarize_results.py"]}}, indent=2))


if __name__ == "__main__":
    main()
