# SPDX-License-Identifier: Apache-2.0
"""Bind independent arithmetic audits to final producer files; no new scenarios."""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(relative):
    return json.loads((ROOT / relative).read_text())


def main():
    freeze = read("FREEZE.json")
    authorization = read("AUTHORIZATION.json")
    assert authorization["status"] == "GO_OFFLINE_FINANCIAL_SIMULATION_ONLY"
    assert digest(ROOT / "FREEZE.json") == authorization["freeze_sha256"]
    for item in freeze["files"]:
        path = ROOT / item["path"]
        assert len(path.read_bytes()) == item["bytes"], item["path"]
        assert digest(path) == item["sha256"], item["path"]

    cash_path = "outputs/run-002/results.json"
    token_path = "outputs/token-run-002/token_waterfalls.json"
    cash_hash, token_hash = digest(ROOT / cash_path), digest(ROOT / token_path)
    cash, token = read(cash_path), read(token_path)
    model_hash = digest(ROOT / "src/financial_model.py")
    token_model_hash = digest(ROOT / "src/token_waterfalls.py")
    assert model_hash == cash["identities"]["model_sha256"]
    assert model_hash == digest(ROOT / "outputs/run-002/MODEL_ATTEMPT.py")
    assert token_model_hash == token["identities"]["model_sha256"]
    assert token["identities"]["shared_io_authorization_module_sha256"] == model_hash
    for result in (cash, token):
        assert result["identities"]["freeze_sha256"] == digest(ROOT / "FREEZE.json")
        assert result["identities"]["authorization_sha256"] == digest(
            ROOT / "AUTHORIZATION.json"
        )

    paths = {
        "cash_core": "evaluation/audit_attempts/attempt-002.json",
        "cash_components_and_exports": "evaluation/DETAIL_AUDIT.json",
        "reporting_revision_invariance": "evaluation/REPORTING_REVISION_AUDIT.json",
        "token_arithmetic": "evaluation/TOKEN_AUDIT.json",
    }
    reports = {key: read(path) for key, path in paths.items()}
    for key, report in reports.items():
        assert report["status"] == "PASS", key
        assert not report.get("differences", []), key
        assert not report.get("unexpected_differences", []), key
    for key in ("cash_core", "cash_components_and_exports"):
        assert reports[key]["producer_results_sha256"] == cash_hash
    assert reports["cash_core"]["producer_model_sha256"] == model_hash
    assert reports["token_arithmetic"]["producer_results_sha256"] == token_hash
    assert reports["token_arithmetic"]["producer_model_sha256"] == token_model_hash
    assert reports["token_arithmetic"]["shared_io_module_sha256"] == model_hash
    revision = reports["reporting_revision_invariance"]
    assert revision["new_cash_results_sha256"] == cash_hash
    assert revision["new_token_results_sha256"] == token_hash
    assert reports["token_arithmetic"]["reporting_revision_invariance_sha256"] == digest(
        ROOT / paths["reporting_revision_invariance"]
    )

    source_bindings = {
        "cash_core": "evaluation/audit_results.py",
        "cash_components_and_exports": "evaluation/audit_details.py",
        "reporting_revision_invariance": "evaluation/audit_reporting_revision.py",
        "token_arithmetic": "evaluation/audit_tokens.py",
    }
    for key, source in source_bindings.items():
        assert reports[key]["auditor_sha256"] == digest(ROOT / source), source
    assert reports["cash_core"]["oracle_sha256"] == digest(ROOT / "evaluation/oracle.py")
    assert reports["token_arithmetic"]["oracle_sha256"] == digest(
        ROOT / "evaluation/token_oracle.py"
    )
    assert reports["cash_core"]["independent_results_sha256"] == digest(
        ROOT / "evaluation/INDEPENDENT_RESULTS.json"
    )
    assert reports["token_arithmetic"]["independent_results_sha256"] == digest(
        ROOT / "evaluation/INDEPENDENT_TOKEN_RESULTS.json"
    )
    for record in reports["cash_components_and_exports"]["csv_identities"]:
        assert digest(ROOT / "outputs/run-002" / Path(record["path"]).name) == record[
            "sha256"
        ]

    counts = {
        key: report.get("checks", report.get("checked_leaves_and_lengths"))
        for key, report in reports.items()
    }
    output = {
        "schema": "agi-alpha-reinvestment-independent-audit/v1",
        "status": "PASS",
        "audited_utc": datetime.now(timezone.utc).isoformat(),
        "scope": "Independent arithmetic and frozen-definition consistency, not empirical validation of demand, gain, prices, acceptance probabilities or financial operations.",
        "producer_results_path": cash_path,
        "producer_results_sha256": cash_hash,
        "producer_model_path": "src/financial_model.py",
        "producer_model_sha256": model_hash,
        "token_results_path": token_path,
        "token_results_sha256": token_hash,
        "token_model_path": "src/token_waterfalls.py",
        "token_model_sha256": token_model_hash,
        "token_audit_sha256": digest(ROOT / paths["token_arithmetic"]),
        "freeze_sha256": digest(ROOT / "FREEZE.json"),
        "authorization_sha256": digest(ROOT / "AUTHORIZATION.json"),
        "frozen_files_verified": len(freeze["files"]),
        "primary_cash_paths": len(cash["primary_cases"]),
        "sensitivity_cash_paths": len(cash["demand_sensitivity_cases"]),
        "monthly_rows": sum(
            len(case["monthly"])
            for case in cash["primary_cases"] + cash["demand_sensitivity_cases"]
        ),
        "token_source_waterfalls": len(token["source_success_waterfalls"]),
        "token_realization_cases": len(token["realization_cases"]),
        "token_failure_examples": len(token["failure_examples"]),
        "checks_by_scope": counts,
        "total_comparison_checks": sum(counts.values()),
        "check_count_interpretation": "Counts include repeated field, ledger, identity and export consistency comparisons. They are not independent experiments, observations, acceptance trials or a reliability sample size.",
        "differences_remaining": 0,
        "reports": [
            {
                "scope": key,
                "path": path,
                "sha256": digest(ROOT / path),
                "checks": counts[key],
            }
            for key, path in paths.items()
        ],
        "reporting_revision": {
            "prospectively_frozen": False,
            "initial_disagreements_preserved": 424,
            "initial_report": "evaluation/audit_attempts/attempt-001.json",
            "actual_financial_paths_changed": False,
            "frozen_inputs_changed": False,
            "definition": "Stopped operational forecasts are zero, with restart resource counterfactuals separately labeled; empty served-cohort comparisons are unavailable with readiness assumptions retained; complete provider expense includes processing and refunds remain contra-revenue.",
            "explicit_field_dispositions": len(revision["explicit_reporting_dispositions"]),
        },
        "auditor_adapter_corrections": [
            "An initial revision checker flagged 48 empty-cohort ratio status labels; the explicit post-result NO_SERVED_COHORT disposition was added without changing numbers. Initial checker and report are preserved.",
            "Detail attempt 001 stopped at a mismatched hypothesis customer component key; the documented producer field was mapped to the independently calculated attention amount.",
            "Detail attempt 002 stopped at the recurring candidate-upkeep key; its documented label was mapped. Delivery export multiplicity was also mapped as request count with the same independently computed saving factor in the unit amount. No inputs, economic equations or producer outcomes changed.",
        ],
        "limitations": [
            "All financial paths are forward expected-use simulations. No revenue, cash transfer, provider invoice, paid API job or contract execution was observed.",
            "The evidence-pack native execution observation is a small component of a modeled service. The $.50 variable-cost and $200 human-replacement offering is an explicitly unvalidated hypothesis; its full fixed and improvement accounts remain charged.",
            "Demand, prices, collection, refunds, rejection probabilities, construction success, savings and human workflow times are assumptions. Arithmetic agreement does not establish their likelihood.",
            "Capacity and payback forecasts are aggregate expected-use resource ceilings, not validated daily schedules, stochastic budget guarantees, token quotas or cash-feasible future production guarantees.",
            "Every paid construction attempt, failed candidate and incurred upkeep is charged. Simulated promotions and assumed diminishing gains are not observed invention or self-acceleration.",
            "Customer savings, invoices, collected revenue, accounting income, taxes, reserves, idle earmarks, actual cash and usable reinvestment resources remain distinct. Final receivables do not fund spending.",
            "Unknown historical authoring, material downstream liability and high-consequence work remain outside validated scope; they have not been silently assigned zero.",
            "Source-based token arithmetic does not verify deployment state, contract behavior on-chain, legal rights, liquidity or market price. Fee-wallet receipts and returned collateral are not worker enterprise profits; Jobs-v0 failure economics and failure-route gas remain unmodeled.",
        ],
        "consolidator_sha256": digest(Path(__file__)),
    }
    destination = ROOT / "evaluation/INDEPENDENT_AUDIT.json"
    destination.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"status": "PASS", "checks": sum(counts.values()), "sha256": digest(destination)}))


if __name__ == "__main__":
    main()
