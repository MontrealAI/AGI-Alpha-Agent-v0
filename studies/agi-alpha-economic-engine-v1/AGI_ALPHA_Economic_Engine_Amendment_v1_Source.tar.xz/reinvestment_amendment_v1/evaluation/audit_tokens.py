# SPDX-License-Identifier: Apache-2.0
"""Audit exact source arithmetic and all frozen token realization examples."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from oracle import D, ROOT, authorize, positive, read, serial, sha


def main():
    authorize()
    ppath = ROOT / "outputs/token-run-002/token_waterfalls.json"
    opath = ROOT / "evaluation/INDEPENDENT_TOKEN_RESULTS.json"
    p, o = read(ppath), read(opath)
    inputs = read(ROOT / "token_scenarios.json")
    checks, errors = [], []

    def check(path, actual, expected, exact=False):
        if (
            actual is None
            or expected is None
            or isinstance(actual, bool)
            or isinstance(expected, bool)
        ):
            ok = actual == expected
        else:
            actual, expected = D(actual), D(expected)
            ok = (
                actual == expected
                if exact
                else abs(actual - expected) <= D("1e-8") + D("1e-11") * abs(expected)
            )
        checks.append(path)
        if not ok:
            errors.append({"path": path, "actual": actual, "expected": expected})

    original = {
        (r["route"], D(r["quoted_usd"])): r for r in o["source_success_waterfalls"]
    }
    mapping = {
        "customer_escrow": "customer_escrow_atomic",
        "worker_customer_funded_award": "worker_net_atomic",
        "total_validator_awards": "validator_net_atomic",
        "each_correct_validator_award": "validator_each_atomic",
        "validator_dust_to_worker": "rounding_residue_to_worker_atomic",
        "wallet30": "wallet30_atomic",
        "wallet10": "wallet10_atomic",
        "burn": "burn_atomic",
        "worker_bond": "worker_bond_atomic",
        "each_validator_bond": "validator_bond_each_atomic",
        "winning_bid": "quoted_reward_atomic",
        "worker_gross_award": "worker_gross_atomic",
        "each_validator_gross_award": "validator_each_gross_atomic",
        "each_validator_net_award": "validator_each_atomic",
        "worker_burn": "worker_burn_atomic",
        "each_validator_burn": "validator_each_burn_atomic",
        "worker_market_minimum": "market_minimum_atomic",
        "quoted_reward": "quoted_reward_atomic",
        "additional_customer_fee": "additional_fee_atomic",
        "validator_allocation_total": "validator_net_atomic",
        "fee_pool_burn": "fee_burn_atomic",
        "fee_pool_pending_claims_increment": "fee_pool_net_atomic",
    }
    for source in p["source_success_waterfalls"]:
        key = (source["route"], D(source["quoted_job_amount_usd"]))
        expected = original[key]
        prefix = str(key)
        atomic = source["atomic"]
        for field, value in atomic.items():
            if field in mapping:
                check(prefix + "." + field, value, expected[mapping[field]], exact=True)
            elif field == "validator_budget":
                check(
                    prefix + "." + field,
                    value,
                    expected["validator_net_atomic"]
                    + expected["rounding_residue_to_worker_atomic"],
                    exact=True,
                )
            elif field == "worker_bond_before_duration_premium":
                m = inputs["manager"]
                expected_base = max(
                    expected["customer_escrow_atomic"] * m["agent_bond_bps"] // 10000,
                    m["agent_bond_min_atomic"],
                )
                check(prefix + "." + field, value, expected_base, exact=True)
            elif field == "worker_bond_duration_premium":
                m = inputs["manager"]
                base = max(
                    expected["customer_escrow_atomic"] * m["agent_bond_bps"] // 10000,
                    m["agent_bond_min_atomic"],
                )
                check(
                    prefix + "." + field,
                    value,
                    base
                    * m["job_duration_seconds_assumed"]
                    // m["job_duration_limit_seconds_assumed"],
                    exact=True,
                )
            elif field in (
                "all_validator_bonds",
                "returned_validator_bonds_separate_from_income",
            ):
                check(
                    prefix + "." + field,
                    value,
                    expected["validator_bond_each_atomic"]
                    * inputs["manager"]["validators"],
                    exact=True,
                )
            elif field in (
                "returned_worker_bond_separate_from_income",
                "worker_bond_unlocked_not_new_income",
                "worker_bond_released_not_new_income",
            ):
                check(
                    prefix + "." + field,
                    value,
                    expected["worker_bond_atomic"],
                    exact=True,
                )
            elif field == "worker_admission_floor":
                # Ascension has a chosen market bond minimum, not a separate
                # fee. Producer reports it as a floor and uses max, not addition.
                floor = expected.get(
                    "market_minimum_atomic", expected["admission_floor_atomic"]
                )
                check(prefix + "." + field, value, floor, exact=True)
            elif field == "worker_gross_modified_award":
                check(
                    prefix + "." + field,
                    value,
                    expected["worker_net_atomic"] + expected["worker_burn_atomic"],
                    exact=True,
                )
            elif field in (
                "customer_refund",
                "customer_escrow_conservation_residual",
                "prefunded_operator_pool_draw",
            ):
                check(prefix + "." + field, value, 0, exact=True)
            else:
                raise AssertionError("Unreviewed atomic field: " + field)
        check(
            prefix + ".decimals", source["decimals"], expected["decimals"], exact=True
        )
        check(
            prefix + ".quote",
            source["quote_usd_per_asset_unit"],
            expected["quote_asset_usd"],
        )
    expected_rows = {
        (r["route"], D(r["quoted_usd"]), r["scenario"]): r
        for r in o["realization_cases"]
    }
    fields = {
        "net_conversion_usd_per_asset_unit_assumed": "cash_per_asset_unit_after_realization_cost",
        "potential_monthly_conversion_value_usd": "unconstrained_conversion_cash",
        "monthly_cash_realized_in_simulation_usd": "realized_cash",
        "converted_asset_units_continuous_valuation_estimate": "converted_asset_units",
        "unconverted_asset_units_continuous_valuation_estimate": "unconverted_asset_units",
        "worker_settlement_gas_allowance_usd": "gas_allowance",
        "monthly_realized_cash_after_worker_gas_usd": "cash_after_gas",
        "required_open_positions": "required_open_positions",
        "required_collateral_stock_quote_usd": "quoted_bond_stock_usd",
        "monthly_imputed_capital_cost_usd_not_cash_loan": "imputed_capital_cost",
        "cash_after_gas_minus_imputed_capital_cost_usd": "settlement_contribution_after_gas_and_imputed_capital",
    }
    for row in p["realization_cases"]:
        key = (
            row["route"],
            D(row["quoted_job_amount_usd"]),
            row["realization_scenario"],
        )
        expected = expected_rows[key]
        prefix = row["case_id"]
        for field, mapped in fields.items():
            check(prefix + "." + field, row[field], expected[mapped])
        scale = D(10 ** expected["decimals"])
        settings = inputs["realization_scenarios"][expected["scenario"]]
        check(
            prefix + ".escrow_usd",
            row["customer_total_escrow_quote_usd_per_job"],
            D(expected["customer_escrow_atomic"])
            / scale
            * D(expected["quote_asset_usd"]),
        )
        check(
            prefix + ".worker_units",
            row["worker_award_asset_units_per_job"],
            D(expected["worker_net_atomic"]) / scale,
        )
        check(
            prefix + ".worker_quote_value",
            row["worker_award_quote_usd_per_job_before_realization"],
            D(expected["worker_net_atomic"]) / scale * D(expected["quote_asset_usd"]),
        )
        check(
            prefix + ".worker_share",
            row["worker_award_fraction_of_gross_customer_escrow"],
            D(expected["worker_net_atomic"]) / D(expected["customer_escrow_atomic"]),
        )
        check(
            prefix + ".monthly_atomic",
            row["monthly_worker_award_atomic"],
            expected["worker_net_atomic"]
            * inputs["accepted_settlements_in_example_month"],
            exact=True,
        )
        check(
            prefix + ".monthly_units",
            row["monthly_worker_award_asset_units"],
            expected["monthly_worker_award_units"],
        )
        check(
            prefix + ".quote",
            row["quote_usd_per_asset_unit_assumed"],
            expected["quote_asset_usd"],
        )
        check(
            prefix + ".count",
            row["monthly_accepted_settlements_assumed"],
            inputs["accepted_settlements_in_example_month"],
            exact=True,
        )
        check(
            prefix + ".liquidity_limit",
            row["monthly_conversion_liquidity_limit_usd"],
            settings["usd_conversion_liquidity_limit_per_month"],
        )
        check(
            prefix + ".inventory_quote",
            row["unconverted_inventory_quote_value_usd_not_cash"],
            D(expected["unconverted_asset_units"]) * D(expected["quote_asset_usd"]),
        )
        check(
            prefix + ".inventory_conversion_value",
            row["unconverted_net_conversion_value_usd_not_cash"],
            D(expected["unconverted_asset_units"])
            * D(expected["cash_per_asset_unit_after_realization_cost"]),
        )
        check(
            prefix + ".funding_gap",
            row["cash_funding_gap_for_gas_usd"],
            positive(-D(expected["cash_after_gas"])),
        )
        check(
            prefix + ".lockdays",
            row["collateral_lock_days_assumed"],
            settings["collateral_lock_days"],
            exact=True,
        )
        check(
            prefix + ".job_bond",
            row["worker_bond_per_job_atomic"],
            expected["worker_bond_atomic"],
            exact=True,
        )
        check(
            prefix + ".bond_stock",
            row["concurrent_worker_bond_stock_atomic"],
            expected["worker_bond_stock_atomic"],
            exact=True,
        )
        admission = expected.get(
            "market_minimum_atomic", expected["admission_floor_atomic"]
        )
        check(
            prefix + ".admission_floor",
            row["separate_worker_admission_floor_atomic"],
            admission,
            exact=True,
        )
        check(
            prefix + ".required_stock",
            row["required_worker_collateral_stock_atomic"],
            max(expected["worker_bond_stock_atomic"], admission),
            exact=True,
        )
        check(
            prefix + ".profit_unknown",
            row["profit_or_reinvestment_surplus_established"],
            False,
        )
        check(
            prefix + ".not_full_enterprise_cost",
            row["enterprise_delivery_setup_review_overhead_tax_reserves_deducted"],
            False,
        )
    failure_names = {
        "ASSIGNED_EXPIRY_BEFORE_COMPLETION": "assigned_expiry",
        "ASSIGNED_DEFAULT_OR_TWO_ELIGIBLE_REJECTIONS": "slashable_failure",
        "SUBMITTED_WITHOUT_REVIEW_QUORUM": "missing_review_quorum",
    }
    expected_failures = {
        (r["route"], D(r["quoted_usd"]), r["failure_kind"]): r
        for r in o["failure_examples"]
    }
    for row in p["failure_examples"]:
        key = (
            row["route"],
            D(row["quoted_job_amount_usd"]),
            failure_names[row["outcome"]],
        )
        expected = expected_failures[key]
        prefix = str(key)
        mapping = {
            "customer_initial_escrow": "customer_escrow_atomic",
            "worker_initial_bond": "worker_bond_atomic",
            "total_employer_award_or_claim": "customer_refund_atomic",
            "total_client_claimable_refund": "customer_refund_atomic",
            "client_claimable_refund": "customer_refund_atomic",
            "worker_bond_lost": "worker_bond_loss_atomic",
            "burn": "burn_atomic",
            "worker_stake_unlocked_and_preserved": "worker_bond_return_atomic",
        }
        for field, value in row["atomic"].items():
            if field in mapping:
                target = expected[mapping[field]]
            elif field in ("employer_escrow_refund", "client_full_bounty_refund"):
                target = expected["customer_escrow_atomic"]
            elif field in (
                "worker_bond_to_employer",
                "worker_bond_added_to_client_refund",
            ):
                target = expected["worker_bond_loss_atomic"] - expected["burn_atomic"]
            elif field in (
                "worker_income",
                "wallet30",
                "wallet10",
                "conservation_residual",
            ):
                target = 0
            else:
                raise AssertionError("Unreviewed failure field: " + field)
            check(prefix + "." + field, value, target, exact=True)
        check(prefix + ".gas_unknown", row["failure_gas_usd"], None)
    for group, expected_count in (
        ("source_success_waterfalls", 9),
        ("realization_cases", 27),
        ("failure_examples", 9),
    ):
        check(group + ".count", len(p[group]), expected_count, exact=True)
    report = {
        "schema": "cash-reinvestment-token-independent-audit/v1",
        "status": "PASS" if not errors else "FAIL",
        "audited_utc": datetime.now(timezone.utc).isoformat(),
        "checks": len(checks),
        "differences": errors,
        "producer_results_sha256": sha(ppath),
        "independent_results_sha256": sha(opath),
        "oracle_sha256": sha(ROOT / "evaluation/token_oracle.py"),
        "auditor_sha256": sha(Path(__file__)),
        "frozen_inputs_sha256": sha(ROOT / "token_scenarios.json"),
        "producer_model_sha256": p["identities"]["model_sha256"],
        "shared_io_module_sha256": p["identities"][
            "shared_io_authorization_module_sha256"
        ],
        "prior_token_audit_preserved": "evaluation/audit_attempts/token-001.json",
        "reporting_revision_invariance_sha256": sha(
            ROOT / "evaluation/REPORTING_REVISION_AUDIT.json"
        ),
        "interpretation": "All atomic source quantities are checked exactly; continuous realization is a valuation assumption, not a transaction. Ascension's reported admission floor means its chosen market bond minimum and is not added twice.",
        "limitations": [
            "No contract execution, chain-state verification or financial transaction.",
            "Settlements precede enterprise delivery, setup, support, tax and reserves; no profit is established.",
            "Jobs-v0 failure economics and failure-route gas remain unmodeled.",
        ],
    }
    out = ROOT / "evaluation/TOKEN_AUDIT.json"
    out.write_text(json.dumps(report, indent=2, sort_keys=True, default=serial) + "\n")
    print(
        json.dumps(
            {
                "status": report["status"],
                "checks": len(checks),
                "differences": errors[:10],
                "sha256": sha(out),
            },
            default=serial,
        )
    )


if __name__ == "__main__":
    main()
