# SPDX-License-Identifier: Apache-2.0
"""Independent components, resource forecasts, investment and CSV checks."""

from __future__ import annotations

import csv
import json
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

from audit_results import case_key
from oracle import (
    D,
    ROOT,
    ZERO,
    authorize,
    ceil,
    floor,
    forecast,
    positive,
    read,
    serial,
    sha,
)


def main():
    authorize()
    run = ROOT / "outputs/run-002"
    producer = read(run / "results.json")
    independent = read(ROOT / "evaluation/INDEPENDENT_RESULTS.json")
    inputs = read(ROOT / "inputs.json")
    anchor = read(ROOT / "prior_model_anchor.json")
    p_cases = producer["primary_cases"] + producer["demand_sensitivity_cases"]
    o_cases = independent["primary_cases"] + independent["demand_sensitivity_cases"]
    by_key = {case_key(c, True): c for c in o_cases}
    by_id = {c["case_id"]: c for c in p_cases}
    count = 0
    errors = []

    def equal(path, actual, expected):
        nonlocal count
        if isinstance(expected, dict):
            count += 1
            if not isinstance(actual, dict) or set(actual) != set(expected):
                errors.append(
                    {
                        "path": path,
                        "actual_keys": (
                            sorted(actual) if isinstance(actual, dict) else None
                        ),
                        "expected_keys": sorted(expected),
                    }
                )
                return
            for key in expected:
                equal(path + "." + key, actual[key], expected[key])
        elif isinstance(expected, list):
            count += 1
            if not isinstance(actual, list) or len(actual) != len(expected):
                errors.append({"path": path, "reason": "LENGTH"})
                return
            for i, (a, b) in enumerate(zip(actual, expected)):
                equal(path + f"[{i}]", a, b)
        elif expected is None or isinstance(expected, bool):
            count += 1
            if actual != expected:
                errors.append({"path": path, "actual": actual, "expected": expected})
        else:
            count += 1
            try:
                a, b = D(actual), D(expected)
                ok = abs(a - b) <= D("1e-7") + D("1e-11") * abs(b)
            except Exception:
                ok = actual == expected
            if not ok:
                errors.append({"path": path, "actual": actual, "expected": expected})

    components = {}
    resource_checks = forecast_checks = candidate_checks = 0
    for case in p_cases:
        before = count
        cid = case["case_id"]
        own = by_key[case_key(case)]
        a = {k: D(v) if isinstance(v, str) else v for k, v in own["accounts"].items()}
        scenario = case["scenario"]
        settings = inputs["scenarios"][scenario]
        original = anchor["scenarios"][scenario]
        profile = case["profile"]
        if profile == "evidence_pack":
            labor = {
                k: v
                for k, v in original["variable"]["provider_components_usd"].items()
                if ".provider." in k
            }
            nonlabor = {
                k: v
                for k, v in original["variable"]["provider_components_usd"].items()
                if ".provider." not in k
            }
            customer = original["variable"]["employer_components_usd"]
        else:
            labor = {
                "hypothesis.delivery.provider.paid_labor": a[
                    "variable_provider_minutes"
                ]
                * a["provider_rate_per_minute"]
            }
            nonlabor = {
                "hypothesis.delivery.assumed_nonlabor": a["variable_nonlabor_cash"]
            }
            customer = {"hypothesis.delivery.employer.attention": a["variable_customer_cash"]}
        initial = dict(original["initial"]["provider_components_usd"])
        initial["commercial.initial.setup_including_provider_labor"] = D(
            settings["additional_business_setup_usd"]
        )
        recurring = dict(original["monthly"]["provider_components_usd"])
        recurring["commercial.monthly.acquisition_billing_including_labor"] = D(
            settings["additional_monthly_acquisition_billing_usd"]
        )
        recurring["commercial.monthly.administration_including_labor"] = D(
            settings["additional_monthly_business_administration_usd"]
        )
        account_maps = {
            "provider_labor_components": labor,
            "provider_nonlabor_components": nonlabor,
            "customer_variable_components": customer,
            "initial_components": initial,
            "monthly_components": recurring,
            "customer_initial_components": original["initial"][
                "employer_components_usd"
            ],
            "customer_monthly_components": original["monthly"][
                "employer_components_usd"
            ],
        }
        for key, expected in account_maps.items():
            equal(cid + ".accounts." + key, case["profile_accounts"][key], expected)
        components[cid] = account_maps
        summary = own["summary"]
        demand = summary["annual_demand"]
        arrivals = [demand // 12 + int(m < demand % 12) for m in range(12)]
        equal(
            cid + ".accounts.arrivals", case["profile_accounts"]["arrivals"], arrivals
        )
        expected_accounts = {
            "q": a["q"],
            "provider_rate_per_minute": a["provider_rate_per_minute"],
            "customer_rate_per_minute": a["customer_rate_per_minute"],
            "provider_minutes_per_request": a["variable_provider_minutes"],
            "customer_minutes_per_request": a["variable_customer_minutes"],
            "executor_seconds_per_request": a["variable_executor_seconds"],
            "initial_provider_minutes": a["initial_provider_minutes"],
            "initial_customer_minutes": a["initial_customer_minutes"],
            "initial_executor_seconds": original["initial"]["resources"][
                "executor_seconds"
            ],
            "monthly_provider_minutes": a["fixed_provider_minutes"],
            "monthly_customer_minutes": a["fixed_customer_minutes"],
            "monthly_executor_seconds": a["fixed_executor_seconds"],
            "provider_minutes_ceiling": a["provider_monthly_minutes"],
            "customer_minutes_ceiling": a["customer_monthly_minutes"],
            "executor_seconds_per_instance_ceiling": a[
                "executor_monthly_seconds_per_instance"
            ],
            "traditional_worker_minutes_ceiling": a["traditional_monthly_minutes"],
            "provider_minutes_per_setup_day": D(
                inputs["monthly_resources"]["provider_minutes_per_day"]
            )
            * settings["utilization"],
            "annual_demand": demand,
            "handoff_minutes": a["handoff_minutes"],
        }
        for key, expected in expected_accounts.items():
            equal(cid + ".accounts." + key, case["profile_accounts"][key], expected)
        previous = None
        for pm, om in zip(case["monthly"], own["monthly"]):
            mp = cid + ".month" + str(pm["month"])
            m = pm["month"]
            current_minutes = D(om["current_variable_provider_minutes"])
            fixed_minutes = D(om["current_fixed_provider_minutes"])
            instances = om["instances"]
            available = {
                "provider_minutes": a["provider_monthly_minutes"] - fixed_minutes,
                "customer_minutes": a["customer_monthly_minutes"]
                - a["fixed_customer_minutes"],
                "executor_seconds": a["executor_monthly_seconds_per_instance"]
                * instances
                - a["fixed_executor_seconds"],
            }
            divisors = {
                "provider_minutes": current_minutes,
                "customer_minutes": a["variable_customer_minutes"],
                "executor_seconds": a["variable_executor_seconds"],
            }
            limits = {
                key: max(0, floor(value / divisors[key]))
                for key, value in available.items()
            }
            expected_resources = {
                "remaining": available,
                "limits": limits,
                "request_limit": min(limits.values()),
                "fixed_resource_shortfalls": {
                    key: positive(-value) for key, value in available.items()
                },
            }
            equal(mp + ".resources", pm["resource_limits"], expected_resources)
            equal(
                mp + ".scheduled_arrival",
                pm["scheduled_requested_demand"],
                arrivals[m - 1],
            )
            equal(
                mp + ".prior_invoice_units",
                pm["prior_accepted_invoice_units_due"],
                0 if previous is None else previous["accepted"],
            )
            equal(
                mp + ".new_face_invoice",
                pm["new_invoice_face_usd"],
                D(om["accepted"]) * case["price_usd_per_accepted"],
            )
            equal(
                mp + ".processing_percentage",
                pm["percentage_processing_usd"],
                D(om["gross_collection"]) * settings["payment_processing_fraction"],
            )
            equal(
                mp + ".processing_fixed",
                pm["fixed_processing_usd"],
                D(om["invoice_count_collected"])
                * settings["processing_usd_per_collected_invoice"],
            )
            equal(
                mp + ".labor_variable",
                pm["provider_variable_labor_per_request_usd"],
                current_minutes * a["provider_rate_per_minute"],
            )
            for field, expected_key in (
                ("opening_tax_reserve_usd", "tax_reserve"),
                ("opening_warranty_reserve_usd", "warranty_reserve"),
                ("opening_earmark_usd", "closing_earmark"),
            ):
                equal(
                    mp + "." + field,
                    pm[field],
                    0 if previous is None else previous[expected_key],
                )
            equal(
                mp + ".nonlabor_factor",
                pm["method_nonlabor_factor"],
                D(om["current_variable_nonlabor"]) / a["variable_nonlabor_cash"],
            )
            equal(
                mp + ".time_factor",
                pm["method_provider_time_factor"],
                current_minutes / a["variable_provider_minutes"],
            )
            incurred = D(om["mandatory_cost_incurred"]) > 0
            construction_minutes = ZERO
            action = om["action"]
            if action is not None:
                if action["kind"] == "candidate":
                    spec = next(
                        x
                        for x in inputs["candidate_capabilities"]
                        if x["id"] == action["id"]
                    )
                    construction_minutes = (
                        D(60) * spec["provider_hours_included_in_cash_cost"]
                    )
                else:
                    construction_minutes = (
                        D(60)
                        * inputs["capacity_purchase"][
                            "setup_provider_hours_included_in_cost"
                        ]
                    )
            equal(
                mp + ".provider_minutes_used",
                pm["provider_minutes_used"],
                (fixed_minutes if incurred else ZERO)
                + D(om["requests"]) * current_minutes
                + construction_minutes,
            )
            equal(
                mp + ".customer_minutes_used",
                pm["customer_delivery_and_fixed_minutes"],
                (a["fixed_customer_minutes"] if incurred else ZERO)
                + D(om["requests"]) * a["variable_customer_minutes"],
            )
            equal(
                mp + ".executor_seconds_used",
                pm["executor_seconds_used"],
                (a["fixed_executor_seconds"] if incurred else ZERO)
                + D(om["requests"]) * a["variable_executor_seconds"],
            )
            raw_future = forecast(
                arrivals,
                m + 1,
                om["backlog"],
                a,
                current_minutes,
                fixed_minutes - a["fixed_provider_minutes"],
                instances,
            )
            expected_future = [
                {
                    "month": row["month"],
                    "requests": row["requests"],
                    "expected_accepted": D(row["requests"]) * a["q"],
                    "backlog": row["backlog_after"],
                }
                for row in raw_future
            ]
            f = pm["remaining_resource_forecast"]
            equal(mp + ".future.rows", f["rows"], expected_future)
            equal(
                mp + ".future.count",
                f["requests"],
                sum(row["requests"] for row in raw_future),
            )
            equal(
                mp + ".future.end_backlog",
                f["end_backlog"],
                raw_future[-1]["backlog_after"] if raw_future else om["backlog"],
            )
            equal(mp + ".future.resources", f["resource_limits"], expected_resources)
            equal(
                mp + ".future.cash_not_proved", f["cash_feasibility_established"], False
            )
            if not om["operating"]:
                equal(
                    mp + ".counterfactual_next",
                    pm[
                        "counterfactual_next_month_resource_feasible_requests_if_restarted"
                    ],
                    raw_future[0]["requests"] if raw_future else 0,
                )
            forecast_checks += len(raw_future)
            for prediction in pm["action_forecasts"]:
                assert (
                    prediction["kind"] == "CANDIDATE"
                ), "No capacity purchase forecast occurred in this frozen portfolio"
                spec = next(
                    x
                    for x in inputs["candidate_capabilities"]
                    if x["id"] == prediction["id"]
                )
                saving = (
                    D(om["current_variable_nonlabor"])
                    * spec["forecast_fractional_nonlabor_saving"]
                    + current_minutes
                    * a["provider_rate_per_minute"]
                    * spec["forecast_fractional_provider_time_saving"]
                )
                weighted = saving * spec["forecast_success_probability"]
                uses = sum(row["requests"] for row in raw_future)
                upkeep = D(12 - m) * spec["monthly_upkeep_usd"]
                construction = D(spec["construction_and_evaluation_usd"])
                expected_prediction = {
                    "kind": "CANDIDATE",
                    "id": spec["id"],
                    "remaining_resource_feasible_request_uses": uses,
                    "saving_usd_per_request_if_passed": saving,
                    "forecast_success_probability": spec[
                        "forecast_success_probability"
                    ],
                    "probability_weighted_saving_usd_per_request": weighted,
                    "remaining_possible_upkeep_usd": upkeep,
                    "construction_and_evaluation_usd": construction,
                    "forecast_net_savings_usd": weighted * uses - upkeep - construction,
                    "continuous_payback_request_uses": {
                        "status": "AVAILABLE_CONDITIONAL",
                        "value": (upkeep + construction) / weighted,
                    },
                    "integer_payback_request_uses": ceil(
                        (upkeep + construction) / weighted
                    ),
                    "forecast_cash_feasibility_established": False,
                }
                equal(mp + ".prediction." + spec["id"], prediction, expected_prediction)
            previous = om
        resource_checks += count - before
        own_candidates = {row["id"]: row for row in own["candidates"]}
        for candidate in case["candidates"]:
            cidp = cid + ".candidate." + candidate["id"]
            expected = own_candidates.get(candidate["id"])
            spec = next(
                x
                for x in inputs["candidate_capabilities"]
                if x["id"] == candidate["id"]
            )
            for field, key in (
                ("constructed_month", "constructed_month"),
                ("evaluation_month", "evaluation_month"),
                ("simulated_pass", "passed"),
                ("construction_incurred_usd", "cost"),
                ("construction_paid_usd", "cost"),
                ("qualified_subsequent_request_uses", "subsequent_requested_uses"),
                ("gross_realized_simulated_savings_usd", "gross_savings"),
                ("upkeep_incurred_usd", "upkeep_paid"),
                ("upkeep_paid_usd", "upkeep_paid"),
                ("promotion_saving_usd_per_request", "saving_per_requested_job"),
                ("net_realized_simulated_return_usd", "net_return"),
                (
                    "integer_realized_horizon_payback_request_uses",
                    "actual_horizon_payback_requests",
                ),
            ):
                default = (
                    None
                    if field
                    in (
                        "constructed_month",
                        "evaluation_month",
                        "simulated_pass",
                        "integer_realized_horizon_payback_request_uses",
                    )
                    else 0
                )
                equal(
                    cidp + "." + field,
                    candidate[field],
                    expected[key] if expected is not None else default,
                )
            equal(
                cidp + ".construction_minutes",
                candidate["provider_construction_minutes"],
                (
                    D(60) * spec["provider_hours_included_in_cash_cost"]
                    if expected is not None
                    else 0
                ),
            )
            if expected is not None and D(expected["saving_per_requested_job"]) > 0:
                continuous = (D(expected["cost"]) + D(expected["upkeep_paid"])) / D(
                    expected["saving_per_requested_job"]
                )
                equal(
                    cidp + ".actual_continuous_payback",
                    candidate["realized_horizon_payback_request_uses"]["value"],
                    continuous,
                )
                equal(
                    cidp + ".payback_reached",
                    candidate["realized_horizon_payback_reached"],
                    expected["subsequent_requested_uses"] >= ceil(continuous),
                )
            else:
                equal(
                    cidp + ".actual_continuous_payback",
                    candidate["realized_horizon_payback_request_uses"]["value"],
                    None,
                )
            candidate_checks += 1

    # Every material cost-ledger amount is rebuilt from frozen components and
    # independently calculated usage; aggregate completeness is checked too.
    ledger_sums = defaultdict(lambda: defaultdict(lambda: ZERO))
    seen = set()
    ledger_rows = 0
    with (run / "cost_ledger.csv").open() as stream:
        for row in csv.DictReader(stream):
            ledger_rows += 1
            cid = row["case_id"]
            p = by_id[cid]
            own = by_key[case_key(p)]
            maps = components[cid]
            month = int(row["month"])
            owner, kind, component = row["owner"], row["kind"], row["component"]
            key = (cid, month, owner, kind, component)
            assert key not in seen, key
            seen.add(key)
            om = own["monthly"][month - 1] if month else None
            unit = multiplier = paid_fraction = None
            if kind == "startup":
                unit, multiplier, paid_fraction = (
                    maps["initial_components"][component],
                    D(1),
                    D(1),
                )
                assert own["summary"]["started"] and month == 0
            elif kind == "initial_readiness":
                unit, multiplier, paid_fraction = (
                    maps["customer_initial_components"][component],
                    D(1),
                    D(1),
                )
            elif kind in ("mandatory_monthly", "shutdown_support"):
                if component in maps["monthly_components"]:
                    unit = maps["monthly_components"][component]
                elif component.startswith("candidate."):
                    ident = component.split(".")[1]
                    unit = next(
                        x["monthly_upkeep_usd"]
                        for x in inputs["candidate_capabilities"]
                        if x["id"] == ident
                    )
                else:
                    raise AssertionError("Unexpected monthly component " + component)
                multiplier = D(1)
                paid_fraction = D(om["mandatory_cost_paid"]) / D(
                    om["mandatory_cost_incurred"]
                )
            elif kind in ("monthly_governance", "shutdown_governance"):
                unit, multiplier, paid_fraction = (
                    maps["customer_monthly_components"][component],
                    D(1),
                    D(1),
                )
            elif kind == "delivery_all_attempts_and_failures":
                if component in maps["provider_labor_components"]:
                    unit = maps["provider_labor_components"][component]
                    factor = D(om["current_variable_provider_minutes"]) / D(
                        own["accounts"]["variable_provider_minutes"]
                    )
                else:
                    unit = maps["provider_nonlabor_components"][component]
                    factor = D(om["current_variable_nonlabor"]) / D(
                        own["accounts"]["variable_nonlabor_cash"]
                    )
                multiplier, paid_fraction = D(om["requests"]) * factor, D(1)
            elif kind == "delivery_attention":
                unit, multiplier, paid_fraction = (
                    maps["customer_variable_components"][component],
                    D(om["requests"]),
                    D(1),
                )
            elif kind == "collection_deductions":
                settings = inputs["scenarios"][p["scenario"]]
                if component == "collection.refunds":
                    unit = D(om["refund"])
                elif component == "collection.percentage_processing":
                    unit = (
                        D(om["gross_collection"])
                        * settings["payment_processing_fraction"]
                    )
                elif component == "collection.fixed_processing":
                    unit = (
                        D(om["invoice_count_collected"])
                        * settings["processing_usd_per_collected_invoice"]
                    )
                else:
                    raise AssertionError("Unknown collection component " + component)
                multiplier, paid_fraction = D(1), D(1)
            elif kind == "discretionary_capability":
                ident = component.split(".")[1]
                spec = next(
                    x for x in inputs["candidate_capabilities"] if x["id"] == ident
                )
                assert om["action"] is not None and om["action"]["id"] == ident
                unit, multiplier, paid_fraction = (
                    D(spec["construction_and_evaluation_usd"]),
                    D(1),
                    D(1),
                )
            else:
                raise AssertionError("Unreviewed ledger kind " + kind)
            lp = "cost_ledger." + str(ledger_rows)
            equal(lp + ".multiplier", row["multiplier"], multiplier)
            expected = D(unit) * multiplier
            equal(lp + ".incurred", row["incurred_usd"], expected)
            equal(lp + ".paid", row["paid_usd"], expected * paid_fraction)
            equal(
                lp + ".labor_not_double_counted",
                row["included_labor_not_charged_again"],
                "True",
            )
            bucket = (
                "customer"
                if owner == "customer"
                else (
                    "refund"
                    if component == "collection.refunds"
                    else (
                        "processing"
                        if component.startswith("collection.")
                        else "provider_cost"
                    )
                )
            )
            ledger_sums[cid][bucket] += D(row["incurred_usd"])
    for case in p_cases:
        cid = case["case_id"]
        own = by_key[case_key(case)]
        for bucket, expected in (
            ("provider_cost", own["summary"]["provider_cost_before_payment_charges"]),
            ("refund", own["summary"]["refunds"]),
            ("processing", own["summary"]["processing"]),
            ("customer", own["customer"]["own_customer_cash"]),
        ):
            equal(
                cid + ".ledger_complete." + bucket, ledger_sums[cid][bucket], expected
            )

    # Derivative CSVs must retain every bound JSON field and case. This is an
    # export-consistency check; independent arithmetic checks occur above.
    base_keys = (
        "case_id",
        "analysis",
        "profile",
        "scenario",
        "price_usd_per_accepted",
        "reinvestment_fraction",
        "outcome_world",
        "demand_multiplier",
    )
    expected_exports = {
        "results_summary.csv": [
            {**{k: c[k] for k in base_keys}, **c["summary"]} for c in p_cases
        ],
        "monthly_cash_ledger.csv": [
            {**{k: c[k] for k in base_keys}, **row}
            for c in p_cases
            for row in c["monthly"]
        ],
        "customer_comparisons.csv": [
            {
                **{k: c[k] for k in base_keys},
                **c["customer_comparison"]["common"],
                **row,
            }
            for c in p_cases
            for row in c["customer_comparison"]["comparisons"]
        ],
        "event_ledger.csv": [
            {**{k: c[k] for k in base_keys}, **row}
            for c in p_cases
            for row in c["events"]
        ],
    }
    export_counts = {}
    for name, expected_rows in expected_exports.items():
        with (run / name).open() as stream:
            reader = csv.DictReader(stream)
            actual_rows = list(reader)
        equal(name + ".row_count", len(actual_rows), len(expected_rows))
        export_counts[name] = len(actual_rows)
        for ordinal, (actual, expected) in enumerate(
            zip(actual_rows, expected_rows), 1
        ):
            for field, cell in actual.items():
                ref = expected.get(field)
                if ref is None:
                    parsed = None if cell == "" else cell
                elif isinstance(ref, (dict, list)):
                    parsed = json.loads(cell, parse_float=D)
                elif isinstance(ref, bool):
                    parsed = {"True": True, "False": False}[cell]
                else:
                    parsed = cell
                equal(name + "." + str(ordinal) + "." + field, parsed, ref)
    report = {
        "schema": "cash-reinvestment-independent-detail-audit/v1",
        "status": "PASS" if not errors else "FAIL",
        "audited_utc": datetime.now(timezone.utc).isoformat(),
        "checks": count,
        "differences": errors,
        "ledger_rows": ledger_rows,
        "case_resource_component_checks": resource_checks,
        "forecast_month_rows": forecast_checks,
        "candidate_records": candidate_checks,
        "csv_row_counts": export_counts,
        "producer_results_sha256": sha(run / "results.json"),
        "independent_results_sha256": sha(ROOT / "evaluation/INDEPENDENT_RESULTS.json"),
        "auditor_sha256": sha(Path(__file__)),
        "csv_identities": [
            {"path": str(run / n), "sha256": sha(run / n)}
            for n in [*expected_exports, "cost_ledger.csv"]
        ],
        "scope": "Frozen account components, every monthly resource forecast, candidate gain/payback arithmetic, every material ledger row and aggregate completeness, plus all CSV cells. Export bindings do not independently validate input assumptions.",
    }
    out = ROOT / "evaluation/DETAIL_AUDIT.json"
    out.write_text(json.dumps(report, indent=2, sort_keys=True, default=serial) + "\n")
    print(
        json.dumps(
            {
                "status": report["status"],
                "checks": count,
                "differences": len(errors),
                "first": errors[:8],
                "sha256": sha(out),
            },
            default=serial,
        )
    )


if __name__ == "__main__":
    main()
