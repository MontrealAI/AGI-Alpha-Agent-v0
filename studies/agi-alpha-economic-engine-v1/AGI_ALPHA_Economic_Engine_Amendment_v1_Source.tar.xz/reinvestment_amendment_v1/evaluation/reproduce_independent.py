# SPDX-License-Identifier: Apache-2.0
"""Recompute independent audits in a new copy; never overwrite released evidence."""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--destination", required=True, type=Path)
    args = parser.parse_args()
    destination = args.destination.resolve()
    assert not destination.exists(), "Use a new, empty destination path."
    assert ROOT not in destination.parents, "Reproduction must be outside the released amendment."
    destination.mkdir(parents=True)
    copied = destination / "reinvestment_amendment_v1"
    copied.mkdir()
    freeze = read(ROOT / "FREEZE.json")
    original_hashes = {item["path"]: sha(ROOT / item["path"]) for item in freeze["files"]}
    for item in freeze["files"]:
        assert original_hashes[item["path"]] == item["sha256"]
        target = copied / item["path"]
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / item["path"], target)
    for relative in ("FREEZE.json", "AUTHORIZATION.json", "REPORTING_REVISION.json"):
        shutil.copyfile(ROOT / relative, copied / relative)
    for relative in (
        "src",
        "evaluation",
        "outputs/run-001",
        "outputs/run-002",
        "outputs/token-run-001",
        "outputs/token-run-002",
    ):
        shutil.copytree(
            ROOT / relative,
            copied / relative,
            dirs_exist_ok=True,
            ignore=shutil.ignore_patterns("__pycache__", "*.pyc"),
        )
    original_independent = read(ROOT / "evaluation/INDEPENDENT_RESULTS.json")
    original_token = read(ROOT / "evaluation/INDEPENDENT_TOKEN_RESULTS.json")
    steps = []
    commands = [
        ["evaluation/oracle.py"],
        ["evaluation/token_oracle.py"],
        ["evaluation/audit_results.py", "--run", "run-002"],
        ["evaluation/audit_reporting_revision.py"],
        ["evaluation/audit_tokens.py"],
        ["evaluation/audit_details.py"],
    ]
    log_dir = destination / "logs"
    log_dir.mkdir()
    report = {
        "schema": "independent-reinvestment-reproduction/v1",
        "status": "RUNNING",
        "started_utc": datetime.now(timezone.utc).isoformat(),
        "source_release_audit_sha256": sha(ROOT / "evaluation/INDEPENDENT_AUDIT.json"),
        "source_cash_results_sha256": sha(ROOT / "outputs/run-002/results.json"),
        "source_token_results_sha256": sha(ROOT / "outputs/token-run-002/token_waterfalls.json"),
        "source_freeze_sha256": sha(ROOT / "FREEZE.json"),
        "reproducer_sha256": sha(Path(__file__)),
        "original_release_modified": False,
        "new_scenarios": False,
        "steps": steps,
    }
    try:
        for index, command in enumerate(commands, 1):
            argv = [sys.executable, str(copied / command[0]), *command[1:]]
            process = subprocess.run(argv, cwd=destination, capture_output=True, text=True)
            (log_dir / f"{index:02d}-stdout.txt").write_text(process.stdout)
            (log_dir / f"{index:02d}-stderr.txt").write_text(process.stderr)
            steps.append({"command": command, "returncode": process.returncode})
            assert process.returncode == 0, f"Step {index} failed; see preserved logs."
        new_independent = read(copied / "evaluation/INDEPENDENT_RESULTS.json")
        for key in ("primary_cases", "demand_sensitivity_cases"):
            assert new_independent[key] == original_independent[key], key
        new_token = read(copied / "evaluation/INDEPENDENT_TOKEN_RESULTS.json")
        for key in ("source_success_waterfalls", "realization_cases", "failure_examples"):
            assert new_token[key] == original_token[key], key
        # A new core audit appends an attempt in the copy; no old report is replaced.
        core = sorted((copied / "evaluation/audit_attempts").glob("attempt-*.json"))[-1]
        checks = {}
        for name, path in (
            ("core", core),
            ("details", copied / "evaluation/DETAIL_AUDIT.json"),
            ("revision", copied / "evaluation/REPORTING_REVISION_AUDIT.json"),
            ("tokens", copied / "evaluation/TOKEN_AUDIT.json"),
        ):
            audit = read(path)
            assert audit["status"] == "PASS", name
            checks[name] = audit.get("checks", audit.get("checked_leaves_and_lengths"))
        for item in freeze["files"]:
            assert sha(copied / item["path"]) == item["sha256"]
            assert sha(ROOT / item["path"]) == original_hashes[item["path"]]
        report.update(
            status="PASS",
            independent_cash_paths_exact=True,
            independent_token_quantities_exact=True,
            frozen_files_verified=len(freeze["files"]),
            checks_by_scope=checks,
            core_audit_path=str(core.relative_to(destination)),
            interpretation="Timestamps and copied report hashes change. Scenario arrays and arithmetic reproduce exactly; comparison counts are not observational sample sizes.",
        )
    except Exception as error:
        report.update(status="FAIL", error=repr(error))
        raise
    finally:
        report["finished_utc"] = datetime.now(timezone.utc).isoformat()
        (destination / "REPRODUCTION.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
        print(json.dumps({"status": report["status"], "report": str(destination / "REPRODUCTION.json")}))


if __name__ == "__main__":
    main()
