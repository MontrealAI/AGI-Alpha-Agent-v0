# SPDX-License-Identifier: Apache-2.0
"""Check exact plotted-source bindings after the independent model audits."""

import hashlib
import json
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads((ROOT / path).read_text(), parse_float=Decimal)


def pointer(document, path):
    for part in path.strip("/").split("/"):
        key = part.replace("~1", "/").replace("~0", "~")
        document = document[int(key)] if isinstance(document, list) else document[key]
    return document


def main():
    data = read("figures/figure_data.json")
    audit = read("evaluation/INDEPENDENT_AUDIT.json")
    assert audit["status"] == "PASS"
    documents = {
        "cash": read(data["cash_results_path"]),
        "token": read(data["token_results_path"]),
    }
    assert data["cash_results_sha256"] == audit["producer_results_sha256"]
    assert data["token_results_sha256"] == audit["token_results_sha256"]
    assert data["cash_audit_sha256"] == sha(ROOT / "evaluation/INDEPENDENT_AUDIT.json")
    assert data["token_audit_sha256"] == sha(ROOT / "evaluation/TOKEN_AUDIT.json")
    for kind in ("cash", "token"):
        assert data[kind + "_results_sha256"] == sha(ROOT / data[kind + "_results_path"])
    failures = []
    for i, record in enumerate(data["values"]):
        source = pointer(documents[record["document"]], record["pointer"])
        if source != record["value"]:
            failures.append({"index": i, "pointer": record["pointer"]})
    # The four cash curves are explicitly selected examples, not a new sweep.
    curves = [
        documents["cash"]["primary_cases"][12],
        documents["cash"]["primary_cases"][84],
        documents["cash"]["demand_sensitivity_cases"][28],
        documents["cash"]["demand_sensitivity_cases"][29],
    ]
    assert all(c["scenario"] == "base" and c["price_usd_per_accepted"] == 20 for c in curves)
    assert all(c["reinvestment_fraction"] == Decimal("0.5") for c in curves)
    assert [c["demand_multiplier"] for c in curves] == [1, 1, 4, 4]
    assert [c["profile"] for c in curves] == ["evidence_pack"] + ["cost_050_hypothesis"] * 3
    assert [c["outcome_world"] for c in curves] == ["no_gain"] * 3 + ["assumed_diminishing_gain"]
    report = {
        "schema": "reinvestment-independent-figure-data-audit/v1",
        "status": "PASS" if not failures else "FAIL",
        "audited_utc": datetime.now(timezone.utc).isoformat(),
        "exact_quantity_bindings": len(data["values"]),
        "failures": failures,
        "cash_results_sha256": data["cash_results_sha256"],
        "token_results_sha256": data["token_results_sha256"],
        "aggregate_audit_sha256": data["cash_audit_sha256"],
        "figure_data_sha256": sha(ROOT / "figures/figure_data.json"),
        "figure_builder_sha256": sha(ROOT / "figures/build_figures.py"),
        "auditor_sha256": sha(Path(__file__)),
        "selection": "Four explicitly selected base USD20/50% cash cases; all three settlement routes and realization assumptions at the USD20 illustrative quote. No new financial scenario was evaluated.",
        "manual_scope_review": [
            "Cash includes initial capital; labels distinguish cash, income, savings, earmarks and observed capability gain.",
            "Hypothesis and 4x demand curves are explicitly unvalidated simulations.",
            "Settlement atomic quantities use the declared asset decimals; Jobs escrow includes its added fee, while Manager uses gross escrow.",
            "Settlement bars are cash after worker gas but before enterprise delivery, setup, labor, taxes and reserves; the figure explicitly says receipts are not profit.",
            "The hypothetical token price and missing on-chain execution are prominent. Source hyperlinks point to pinned implementation sources.",
        ],
        "visual_qa": "Separate from this exact-source and semantic check; assigned to publication/paper review.",
    }
    destination = ROOT / "evaluation/FIGURE_DATA_AUDIT.json"
    destination.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"status": report["status"], "quantities": len(data["values"]), "sha256": sha(destination)}))


if __name__ == "__main__":
    main()
