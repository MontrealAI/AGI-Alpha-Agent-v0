# SPDX-License-Identifier: Apache-2.0
"""Prove the post-result report revision leaves actual paths unchanged."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from oracle import ROOT, authorize, read, serial, sha


def main():
    authorize()
    old_path = ROOT / "outputs/run-001/results.json"
    new_path = ROOT / "outputs/run-002/results.json"
    old, new = read(old_path), read(new_path)
    checked, errors, excluded, additions = [], [], [], []

    def equal(path, before, after):
        if isinstance(before, dict):
            if not isinstance(after, dict):
                errors.append({"path": path, "before": before, "after": after})
                return
            for key, value in before.items():
                if key not in after:
                    errors.append({"path": path + "." + key, "reason": "MISSING"})
                else:
                    equal(path + "." + key, value, after[key])
            additions.extend(path + "." + key for key in after if key not in before)
        elif isinstance(before, list):
            checked.append(path + ".length")
            if len(before) != len(after):
                errors.append({"path": path, "reason": "LENGTH"})
            else:
                for i, (left, right) in enumerate(zip(before, after)):
                    equal(path + f"[{i}]", left, right)
        else:
            checked.append(path)
            if before != after:
                errors.append({"path": path, "before": before, "after": after})

    empty_allowed = {
        "traditional_unit_cost_usd",
        "traditional_readiness_usd",
        "traditional_total_usd",
        "hybrid_total_usd",
        "hybrid_cost_per_completed_request",
        "customer_savings_usd",
        "maximum_customer_beneficial_face_price_usd",
        "cohort_conditional_viable_price_interval_exists",
        "fallback_resource_requirements",
    }
    for group in ("primary_cases", "demand_sensitivity_cases"):
        equal(group + ".count", len(old[group]), len(new[group]))
        for a, b in zip(old[group], new[group]):
            prefix = a["case_id"]
            for key in a:
                if key not in ("monthly", "customer_comparison"):
                    equal(prefix + "." + key, a[key], b[key])
            equal(prefix + ".monthly.count", len(a["monthly"]), len(b["monthly"]))
            for x, y in zip(a["monthly"], b["monthly"]):
                mp = prefix + ".month" + str(x["month"])
                for key in x:
                    if (
                        key == "next_month_resource_feasible_requests"
                        and x["status"] != "OPERATING"
                    ):
                        equal(mp + ".stopped_operational_next", y[key], 0)
                        equal(
                            mp + ".counterfactual_rebound",
                            y[
                                "counterfactual_next_month_resource_feasible_requests_if_restarted"
                            ],
                            x[key],
                        )
                        if x[key] != y[key]:
                            excluded.append(
                                {
                                    "path": mp + "." + key,
                                    "old": x[key],
                                    "new": y[key],
                                    "reason": "Operational field zeroed; unchanged resource-only forecast separately labeled.",
                                }
                            )
                    else:
                        equal(mp + "." + key, x[key], y[key])
                additions.extend(mp + "." + key for key in y if key not in x)
            for key, value in a["customer_comparison"]["common"].items():
                revised = b["customer_comparison"]["common"][key]
                if (
                    a["summary"]["requests_served"] == 0
                    and key == "agent_customer_total_per_expected_accepted"
                ):
                    equal(
                        prefix + ".customer.common.empty_value",
                        value["value"],
                        revised["value"],
                    )
                    equal(
                        prefix + ".customer.common.empty_status",
                        revised["status"],
                        "NO_SERVED_COHORT",
                    )
                    excluded.append(
                        {
                            "path": prefix + ".customer.common." + key + ".status",
                            "old": value["status"],
                            "new": revised["status"],
                            "reason": "Equivalent unavailable ratio gets the explicit empty-cohort status; null value unchanged.",
                        }
                    )
                else:
                    equal(prefix + ".customer.common." + key, value, revised)
            for x, y in zip(
                a["customer_comparison"]["comparisons"],
                b["customer_comparison"]["comparisons"],
            ):
                cp = (
                    prefix
                    + ".customer."
                    + str(x["productive_human_minutes_assumed"])
                    + "."
                    + x["scope"]
                )
                empty = x["scope"] == "served_cohort" and x["cohort_requests"] == 0
                if empty:
                    equal(cp + ".status", y["comparison_status"], "NO_SERVED_COHORT")
                    equal(
                        cp + ".readiness_plan_preserved",
                        y["traditional_plan_readiness_commitment_usd"],
                        x["traditional_readiness_usd"],
                    )
                    equal(
                        cp + ".unit_assumption_preserved",
                        y["traditional_unit_cost_assumption_usd"],
                        x["traditional_unit_cost_usd"],
                    )
                for key in x:
                    if empty and key in empty_allowed:
                        excluded.append(
                            {
                                "path": cp + "." + key,
                                "old": x[key],
                                "new": y[key],
                                "reason": "Empty served-subset comparison unavailable; full annual-demand comparison unchanged.",
                            }
                        )
                    else:
                        equal(cp + "." + key, x[key], y[key])
                additions.extend(cp + "." + key for key in y if key not in x)
    for name in ("cost_ledger.csv", "event_ledger.csv"):
        equal(
            name + ".byte_identity",
            (old_path.parent / name).read_bytes(),
            (new_path.parent / name).read_bytes(),
        )
    old_token = ROOT / "outputs/token-run-001/token_waterfalls.json"
    new_token = ROOT / "outputs/token-run-002/token_waterfalls.json"
    left, right = read(old_token), read(new_token)
    for key in left:
        if key != "identities":
            equal("token." + key, left[key], right[key])
    report = {
        "schema": "cash-reinvestment-independent-reporting-revision-audit/v1",
        "status": "PASS" if not errors else "FAIL",
        "audited_utc": datetime.now(timezone.utc).isoformat(),
        "checked_leaves_and_lengths": len(checked),
        "unexpected_differences": errors,
        "explicit_reporting_dispositions": excluded,
        "added_report_fields": additions,
        "old_cash_results_sha256": sha(old_path),
        "new_cash_results_sha256": sha(new_path),
        "old_token_results_sha256": sha(old_token),
        "new_token_results_sha256": sha(new_token),
        "auditor_sha256": sha(Path(__file__)),
        "initial_independent_difference_report_sha256": sha(
            ROOT / "evaluation/audit_attempts/attempt-001.json"
        ),
        "disposition": "Post-result reporting adjudication, not a prospective endpoint change. Actual admissions, cash, incurred/paid costs, reserves, construction, candidates, actions, annual-demand comparisons and token arithmetic remain exact. Complete-expense fields add already-paid processing and keep refunds as contra-revenue.",
        "frozen_input_changes": 0,
    }
    out = ROOT / "evaluation/REPORTING_REVISION_AUDIT.json"
    out.write_text(json.dumps(report, indent=2, sort_keys=True, default=serial) + "\n")
    print(
        json.dumps(
            {
                "status": report["status"],
                "checks": len(checked),
                "unexpected": len(errors),
                "explicit_reporting_dispositions": len(excluded),
                "sha256": sha(out),
            }
        )
    )


if __name__ == "__main__":
    main()
