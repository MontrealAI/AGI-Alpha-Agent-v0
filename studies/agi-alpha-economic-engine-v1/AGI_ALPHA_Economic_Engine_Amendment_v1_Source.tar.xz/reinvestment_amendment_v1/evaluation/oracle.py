# SPDX-License-Identifier: Apache-2.0
"""Independent Decimal simulation from the frozen prospective financial protocol.

No producer implementation is imported. The input anchor contains earlier
modeled accounts, explicitly distinct from observed native execution.
"""

from __future__ import annotations

import hashlib
import json
import traceback
from datetime import datetime, timezone
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR, getcontext
from itertools import product
from pathlib import Path

getcontext().prec = 50
ROOT = Path(__file__).resolve().parents[1]
FREEZE_SHA = "4c7bac19106f946920d64ad39b01cb2cc844eed78c5cdb4d79140904a10cc9ba"
ZERO = Decimal(0)
ONE = Decimal(1)


def D(value):
    return value if isinstance(value, Decimal) else Decimal(str(value))


def floor(value):
    return int(D(value).to_integral_value(rounding=ROUND_FLOOR))


def ceil(value):
    return int(D(value).to_integral_value(rounding=ROUND_CEILING))


def positive(value):
    return max(ZERO, value)


def total(values):
    return sum(values, ZERO)


def read(path):
    return json.loads(path.read_text(), parse_float=Decimal)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def serial(value):
    if isinstance(value, Decimal):
        return str(value)
    raise TypeError(type(value).__name__)


def authorize():
    authorization = read(ROOT / "AUTHORIZATION.json")
    assert authorization["status"] == "GO_OFFLINE_FINANCIAL_SIMULATION_ONLY"
    assert authorization["public_readback_exact"] is True
    assert authorization["freeze_sha256"] == FREEZE_SHA
    assert sha(ROOT / "FREEZE.json") == FREEZE_SHA
    freeze = read(ROOT / "FREEZE.json")
    assert len(freeze["files"]) == 68
    for item in freeze["files"]:
        assert sha(ROOT / item["path"]) == item["sha256"], item["path"]
    return authorization


def profile_accounts(inputs, anchor, profile, scenario):
    a = anchor["scenarios"][scenario]
    s = inputs["scenarios"][scenario]
    r = a["labor_prices"]
    rate = r["provider_per_hour_in_reporting_currency"] / D(60)
    customer_rate = r["employer_worker_per_hour"] / D(60)
    initial = a["initial"]
    recurring = a["monthly"]
    variable = a["variable"]
    initial_cash = total(initial["provider_components_usd"].values()) + D(
        s["additional_business_setup_usd"]
    )
    fixed_cash = (
        total(recurring["provider_components_usd"].values())
        + D(s["additional_monthly_acquisition_billing_usd"])
        + D(s["additional_monthly_business_administration_usd"])
    )
    fixed_minutes = (
        recurring["resources"]["provider_minutes"]
        + D(60) * s["additional_monthly_provider_hours"]
    )
    initial_minutes = (
        initial["resources"]["provider_minutes"]
        + D(60) * s["additional_setup_provider_hours"]
    )
    if profile == "evidence_pack":
        provider_minutes = variable["resources"]["provider_minutes"]
        nonlabor = total(
            v
            for k, v in variable["provider_components_usd"].items()
            if ".provider." not in k
        )
        customer_cash = total(variable["employer_components_usd"].values())
        customer_minutes = variable["resources"]["employer_minutes"]
    else:
        q0 = anchor["scenarios"]["base"]["acceptance_probability"]
        nonlabor0 = q0 * (
            D(
                inputs[
                    "hypothesis_base_variable_delivery_cost_per_expected_accepted_usd"
                ]
            )
            - D(inputs["hypothesis_base_provider_minutes_per_expected_accepted"]) * rate
        )
        nonlabor = nonlabor0 * s["hypothesis_nonlabor_multiplier"]
        provider_minutes = (
            q0 * D(inputs["hypothesis_base_provider_minutes_per_expected_accepted"])
            if scenario == "base"
            else D(s["hypothesis_provider_minutes_per_requested"])
        )
        customer_minutes = D(s["hypothesis_customer_minutes_per_requested"])
        customer_cash = customer_minutes * customer_rate
    assert nonlabor >= 0 and provider_minutes > 0
    resource = inputs["monthly_resources"]
    utilization = D(s["utilization"])
    return {
        "initial_cash": initial_cash,
        "initial_provider_minutes": initial_minutes,
        "fixed_cash": fixed_cash,
        "fixed_provider_minutes": fixed_minutes,
        "fixed_executor_seconds": recurring["resources"]["executor_seconds"],
        "initial_customer_cash": total(initial["employer_components_usd"].values()),
        "initial_customer_minutes": initial["resources"]["employer_minutes"],
        "fixed_customer_cash": total(recurring["employer_components_usd"].values()),
        "fixed_customer_minutes": recurring["resources"]["employer_minutes"],
        "variable_nonlabor_cash": nonlabor,
        "variable_provider_minutes": provider_minutes,
        "variable_provider_cash": provider_minutes * rate + nonlabor,
        "variable_executor_seconds": variable["resources"]["executor_seconds"],
        "variable_customer_cash": customer_cash,
        "variable_customer_minutes": customer_minutes,
        "provider_rate_per_minute": rate,
        "customer_rate_per_minute": customer_rate,
        "provider_monthly_minutes": D(resource["provider_minutes_per_day"])
        * resource["workdays"]
        * utilization,
        "customer_monthly_minutes": D(resource["customer_minutes_per_day"])
        * resource["workdays"]
        * utilization,
        "traditional_monthly_minutes": D(resource["traditional_worker_minutes_per_day"])
        * resource["workdays"]
        * utilization,
        "executor_monthly_seconds_per_instance": D(
            resource["executor_hours_per_workday"]
        )
        * resource["workdays"]
        * D(3600)
        * utilization,
        "setup_workdays": ceil(
            initial_minutes / (D(resource["provider_minutes_per_day"]) * utilization)
        ),
        "q": D(a["acceptance_probability"]),
        "handoff_minutes": D(a["hybrid_handoff_employer_minutes"]),
    }


def resource_limits(accounts, method_minutes, extra_fixed_minutes, instances):
    p = (
        accounts["provider_monthly_minutes"]
        - accounts["fixed_provider_minutes"]
        - extra_fixed_minutes
    )
    c = accounts["customer_monthly_minutes"] - accounts["fixed_customer_minutes"]
    e = (
        accounts["executor_monthly_seconds_per_instance"] * instances
        - accounts["fixed_executor_seconds"]
    )
    return {
        "provider": max(0, floor(p / method_minutes)),
        "customer": max(0, floor(c / accounts["variable_customer_minutes"])),
        "executor": max(0, floor(e / accounts["variable_executor_seconds"])),
        "provider_minutes_available": positive(p),
        "customer_minutes_available": positive(c),
        "executor_seconds_available": positive(e),
    }


def forecast(
    arrivals,
    first_month,
    backlog,
    accounts,
    method_minutes,
    extra_fixed_minutes,
    instances,
):
    limits = resource_limits(accounts, method_minutes, extra_fixed_minutes, instances)
    ceiling = min(limits[k] for k in ("provider", "customer", "executor"))
    rows = []
    for m in range(first_month, len(arrivals) + 1):
        backlog += arrivals[m - 1]
        count = min(backlog, ceiling)
        backlog -= count
        rows.append({"month": m, "requests": count, "backlog_after": backlog})
    return rows


def customer_comparison(inputs, anchor, profile, scenario, price, accounts, summary):
    n = summary["served_requests"]
    accepted = summary["expected_accepted"]
    demand = summary["annual_demand"]
    failed = D(n) - accepted
    fixed_customer = (
        accounts["initial_customer_cash"] * int(summary["started"])
        + accounts["fixed_customer_cash"] * summary["customer_fixed_months"]
    )
    own_cash = fixed_customer + D(n) * accounts["variable_customer_cash"]
    own_minutes = (
        accounts["initial_customer_minutes"] * int(summary["started"])
        + accounts["fixed_customer_minutes"] * summary["customer_fixed_months"]
        + D(n) * accounts["variable_customer_minutes"]
    )
    handoff_minutes = failed * accounts["handoff_minutes"]
    handoff_cash = handoff_minutes * accounts["customer_rate_per_minute"]
    face = accepted * price
    comparisons = []
    durations = (
        inputs["human_productive_minutes_for_anchor"]
        if profile == "evidence_pack"
        else [None]
    )
    for duration in durations:
        if duration is None:
            human_variable = D(inputs["hypothesis_human_replacement_cost_usd"])
            human_fixed = ZERO
            human_customer_variable_minutes = human_worker_variable_minutes = None
            human_customer_fixed_minutes = human_worker_fixed_minutes = None
        else:
            h = anchor["scenarios"][scenario]["traditional"][str(duration)]
            human_variable = D(h["variable"]["total"])
            human_fixed = (
                D(h["initial"]["total"])
                + D(inputs["operating_months_after_setup"]) * h["monthly"]["total"]
            )
            human_customer_variable_minutes = h["variable"]["resources"][
                "employer_minutes"
            ]
            human_worker_variable_minutes = h["variable"]["resources"][
                "traditional_worker_minutes"
            ]
            human_customer_fixed_minutes = (
                h["initial"]["resources"]["employer_minutes"]
                + D(inputs["operating_months_after_setup"])
                * h["monthly"]["resources"]["employer_minutes"]
            )
            human_worker_fixed_minutes = (
                h["initial"]["resources"]["traditional_worker_minutes"]
                + D(inputs["operating_months_after_setup"])
                * h["monthly"]["resources"]["traditional_worker_minutes"]
            )
        row = {
            "human_productive_minutes": duration,
            "human_variable_cost": human_variable,
            "human_fixed_cost": human_fixed,
        }
        for label, cohort in (("served", n), ("annual", demand)):
            fallback = D(cohort) - accepted
            baseline = human_fixed + D(cohort) * human_variable
            nonface = (
                own_cash
                + handoff_cash
                + fallback * human_variable
                + (human_fixed if fallback > 0 else ZERO)
            )
            full_cost = nonface + face
            price_ceiling = (baseline - nonface) / accepted if accepted > 0 else None
            details = {
                "cohort_requests": cohort,
                "fallback_jobs": fallback,
                "traditional_cost": baseline,
                "customer_complete_cost": full_cost,
                "customer_savings": baseline - full_cost,
                "customer_maximum_beneficial_price": price_ceiling,
                "traditional_cost_per_completed": (
                    baseline / D(cohort) if cohort > 0 else None
                ),
                "customer_complete_cost_per_completed": (
                    full_cost / D(cohort) if cohort > 0 else None
                ),
            }
            if duration is None:
                details.update(
                    {
                        "fallback_worker_minutes": None,
                        "total_customer_minutes": None,
                        "fallback_capacity_feasible": None,
                    }
                )
            else:
                fallback_worker = fallback * human_worker_variable_minutes + (
                    human_worker_fixed_minutes if fallback > 0 else ZERO
                )
                customer_minutes = (
                    own_minutes
                    + handoff_minutes
                    + fallback * human_customer_variable_minutes
                    + (human_customer_fixed_minutes if fallback > 0 else ZERO)
                )
                baseline_worker = (
                    D(cohort) * human_worker_variable_minutes
                    + human_worker_fixed_minutes
                )
                baseline_customer = (
                    D(cohort) * human_customer_variable_minutes
                    + human_customer_fixed_minutes
                )
                details.update(
                    {
                        "fallback_worker_minutes": fallback_worker,
                        "total_customer_minutes": customer_minutes,
                        "traditional_worker_minutes": baseline_worker,
                        "traditional_customer_minutes": baseline_customer,
                        "fallback_capacity_feasible": fallback_worker
                        <= accounts["traditional_monthly_minutes"]
                        * inputs["operating_months_after_setup"]
                        and customer_minutes
                        <= accounts["customer_monthly_minutes"]
                        * inputs["operating_months_after_setup"],
                        "traditional_capacity_feasible": baseline_worker
                        <= accounts["traditional_monthly_minutes"]
                        * inputs["operating_months_after_setup"]
                        and baseline_customer
                        <= accounts["customer_monthly_minutes"]
                        * inputs["operating_months_after_setup"],
                    }
                )
            row[label] = details
        comparisons.append(row)
    return {
        "own_customer_cash": own_cash,
        "own_customer_minutes": own_minutes,
        "handoff_cash": handoff_cash,
        "handoff_minutes": handoff_minutes,
        "accepted_face_invoices": face,
        "agent_customer_cost_per_expected_accepted": (
            (own_cash + face) / accepted if accepted > 0 else None
        ),
        "comparisons": comparisons,
    }


def one_path(inputs, anchor, profile, scenario, price, fraction, world, multiplier):
    price, fraction, multiplier = D(price), D(fraction), D(multiplier)
    s = inputs["scenarios"][scenario]
    a = profile_accounts(inputs, anchor, profile, scenario)
    months = inputs["operating_months_after_setup"]
    demand_key = (
        "anchor_annual_requested_demand"
        if profile == "evidence_pack"
        else "hypothesis_annual_requested_demand"
    )
    demand = int(D(s[demand_key]) * multiplier)
    arrivals = [demand // months + int(m < demand % months) for m in range(months)]
    initial_capital = D(inputs["initial_virtual_cash_usd"])
    started = a["initial_cash"] <= initial_capital
    cash = initial_capital - (a["initial_cash"] if started else ZERO)
    operating_income = -a["initial_cash"] if started else ZERO
    tax = warranty = earmark = lifetime_allocation = ZERO
    unpaid = cumulative_unpaid_repaid = ZERO
    mandatory_paid = mandatory_incurred = delivery_cost = investment = ZERO
    collected_gross = refunds = processing = collected_count = ZERO
    provider_minutes_total = a["initial_provider_minutes"] if started else ZERO
    construction_minutes_total = ZERO
    method_nonlabor = a["variable_nonlabor_cash"]
    method_minutes = a["variable_provider_minutes"]
    fixed_extra_cash = fixed_extra_minutes = ZERO
    instances = inputs["monthly_resources"]["executor_instances"]
    capacity_count = 0
    pending = None
    next_candidate = 0
    search_stopped = False
    active = started
    backlog = served = 0
    previous_accepted = previous_gross = ZERO
    customer_fixed_months = 0
    rows, candidates, capacity_purchases, events = [], [], [], []
    capacity = inputs["capacity_purchase"]
    cumulative_earmark_released = ZERO
    for month in range(1, months + 1):
        opening = cash
        action = None
        promotion = None
        if pending is not None and pending["due_month"] == month:
            if pending["kind"] == "capacity":
                instances += 1
                capacity_count += 1
                fixed_extra_cash += D(capacity["monthly_upkeep_usd"])
                fixed_extra_minutes += (
                    D(60) * capacity["monthly_upkeep_provider_hours_included_in_cost"]
                )
                promotion = {"kind": "capacity", "instances": instances}
            else:
                record = candidates[pending["record_index"]]
                spec = inputs["candidate_capabilities"][record["index"]]
                passed = (
                    world == "assumed_diminishing_gain"
                    and spec["assumed_diminishing_gain_pass"]
                )
                record["passed"] = passed
                record["evaluation_month"] = month
                if passed:
                    old_cost = (
                        method_nonlabor + method_minutes * a["provider_rate_per_minute"]
                    )
                    method_nonlabor *= ONE - D(
                        spec["forecast_fractional_nonlabor_saving"]
                    )
                    method_minutes *= ONE - D(
                        spec["forecast_fractional_provider_time_saving"]
                    )
                    new_cost = (
                        method_nonlabor + method_minutes * a["provider_rate_per_minute"]
                    )
                    record["saving_per_requested_job"] = old_cost - new_cost
                    fixed_extra_cash += D(spec["monthly_upkeep_usd"])
                    fixed_extra_minutes += D(60) * spec["monthly_upkeep_provider_hours"]
                promotion = {"kind": "candidate", "id": spec["id"], "passed": passed}
            pending = None
        fixed = a["fixed_cash"] + fixed_extra_cash
        fixed_minutes = a["fixed_provider_minutes"] + fixed_extra_minutes
        variable = method_nonlabor + method_minutes * a["provider_rate_per_minute"]
        invoice_count_collected = previous_accepted * D(
            s["collected_fraction_of_accepted_invoices"]
        )
        gross = invoice_count_collected * price
        refund = gross * D(s["refund_fraction_of_collected"])
        fee = gross * D(s["payment_processing_fraction"]) + invoice_count_collected * D(
            s["processing_usd_per_collected_invoice"]
        )
        net_collection = gross - refund - fee
        cash += net_collection
        operating_income += net_collection
        collected_gross += gross
        refunds += refund
        processing += fee
        collected_count += invoice_count_collected
        debt_repaid = min(unpaid, positive(cash - tax - warranty))
        cash -= debt_repaid
        unpaid -= debt_repaid
        cumulative_unpaid_repaid += debt_repaid
        mandatory_paid += debt_repaid
        paid_fixed = incurred_fixed = request_cost = ZERO
        allocation = released = discretionary = ZERO
        n = 0
        limits = None
        forecasts = None
        stopped_this_month = False
        request_arrival = 0
        if active:
            if cash - tax - warranty - earmark < D(2) * fixed:
                active = False
                stopped_this_month = True
                released = earmark
                cumulative_earmark_released += released
                earmark = ZERO
                incurred_fixed = fixed
                paid_fixed = min(fixed, positive(cash - tax - warranty))
                unpaid += fixed - paid_fixed
                cash -= paid_fixed
                operating_income -= fixed
                mandatory_paid += paid_fixed
                mandatory_incurred += fixed
                provider_minutes_total += fixed_minutes
                customer_fixed_months += 1
                events.append(
                    {
                        "month": month,
                        "kind": "SHUTDOWN",
                        "incurred": fixed,
                        "paid": paid_fixed,
                        "unpaid": unpaid,
                    }
                )
            else:
                paid_fixed = incurred_fixed = fixed
                cash -= fixed
                operating_income -= fixed
                mandatory_paid += fixed
                mandatory_incurred += fixed
                provider_minutes_total += fixed_minutes
                customer_fixed_months += 1
                request_arrival = arrivals[month - 1]
                backlog += request_arrival
                limits = resource_limits(
                    a, method_minutes, fixed_extra_minutes, instances
                )
                limits["cash"] = max(
                    0,
                    floor(positive(cash - tax - warranty - earmark - fixed) / variable),
                )
                n = min(
                    backlog,
                    *(limits[k] for k in ("provider", "customer", "executor", "cash")),
                )
                backlog -= n
                served += n
                request_cost = D(n) * variable
                cash -= request_cost
                delivery_cost += request_cost
                operating_income -= request_cost
                provider_minutes_total += D(n) * method_minutes
                for record in candidates:
                    if record["passed"]:
                        record["subsequent_requested_uses"] += n
                        record["gross_savings"] += (
                            D(n) * record["saving_per_requested_job"]
                        )
                        record["upkeep_paid"] += D(
                            inputs["candidate_capabilities"][record["index"]][
                                "monthly_upkeep_usd"
                            ]
                        )
        accepted = D(n) * a["q"]
        tax = max(
            tax,
            D(s["tax_reserve_fraction_of_positive_cumulative_pre_discretionary_income"])
            * positive(operating_income),
        )
        warranty = D(
            s["warranty_reserve_fraction_of_last_two_months_collected_proceeds"]
        ) * (gross + previous_gross)
        future = (
            forecast(
                arrivals,
                month + 1,
                backlog,
                a,
                method_minutes,
                fixed_extra_minutes,
                instances,
            )
            if active
            else []
        )
        next_count = future[0]["requests"] if future else 0
        working_capital = (
            D(s["working_capital_months"]) * (fixed + variable * next_count)
            if active
            else ZERO
        )
        reserve_shortfall = positive(tax + warranty + working_capital + earmark - cash)
        recovered_surplus = positive(operating_income - tax)
        ceiling = fraction * recovered_surplus
        if active:
            allocation = min(
                positive(ceiling - lifetime_allocation),
                positive(cash - tax - warranty - working_capital - earmark),
            )
            earmark += allocation
            lifetime_allocation += allocation
        remaining = months - month
        unused_provider_minutes = (
            positive(
                a["provider_monthly_minutes"] - fixed_minutes - D(n) * method_minutes
            )
            if active
            else ZERO
        )
        if active and remaining >= 2 and reserve_shortfall == 0 and fraction > 0:
            forecasts = {
                "remaining_requests": sum(x["requests"] for x in future),
                "baseline": future,
            }
            purchased = False
            if capacity_count < capacity["max_purchases"]:
                extra_minutes = (
                    fixed_extra_minutes
                    + D(60) * capacity["monthly_upkeep_provider_hours_included_in_cost"]
                )
                expanded = forecast(
                    arrivals,
                    month + 1,
                    backlog,
                    a,
                    method_minutes,
                    extra_minutes,
                    instances + 1,
                )
                delta = [
                    x["requests"] - y["requests"] for x, y in zip(expanded, future)
                ]
                extra_requests = sum(delta)
                receipts_per_requested = (
                    a["q"]
                    * D(s["collected_fraction_of_accepted_invoices"])
                    * (
                        price
                        * (
                            ONE
                            - D(s["refund_fraction_of_collected"])
                            - D(s["payment_processing_fraction"])
                        )
                        - D(s["processing_usd_per_collected_invoice"])
                    )
                )
                credit = total(
                    D(count) * receipts_per_requested
                    for count, f in zip(delta, future)
                    if f["month"] < months
                )
                predicted = (
                    credit
                    - D(extra_requests) * variable
                    - D(capacity["setup_usd"])
                    - D(remaining) * capacity["monthly_upkeep_usd"]
                )
                forecasts["capacity"] = {
                    "additional_requests": extra_requests,
                    "predicted_net_cash_gain": predicted,
                    "expanded": expanded,
                }
                if (
                    extra_requests > 0
                    and predicted > 0
                    and earmark >= D(capacity["setup_usd"])
                    and unused_provider_minutes
                    >= D(60) * capacity["setup_provider_hours_included_in_cost"]
                ):
                    discretionary = D(capacity["setup_usd"])
                    construction_minutes = (
                        D(60) * capacity["setup_provider_hours_included_in_cost"]
                    )
                    pending = {"kind": "capacity", "due_month": month + 1}
                    capacity_purchases.append(
                        {
                            "month": month,
                            "cost": discretionary,
                            "predicted_net_cash_gain": predicted,
                            "forecast_additional_requests": extra_requests,
                        }
                    )
                    action = {"kind": "capacity", "cost": discretionary}
                    purchased = True
            if (
                not purchased
                and next_candidate < len(inputs["candidate_capabilities"])
                and not search_stopped
            ):
                spec = inputs["candidate_capabilities"][next_candidate]
                saving = method_nonlabor * D(
                    spec["forecast_fractional_nonlabor_saving"]
                ) + method_minutes * a["provider_rate_per_minute"] * D(
                    spec["forecast_fractional_provider_time_saving"]
                )
                forecast_count = sum(x["requests"] for x in future)
                forecast_gross = (
                    D(spec["forecast_success_probability"]) * saving * forecast_count
                )
                required = (
                    D(spec["construction_and_evaluation_usd"])
                    + D(remaining) * spec["monthly_upkeep_usd"]
                )
                predicted = forecast_gross - required
                forecasts["candidate"] = {
                    "id": spec["id"],
                    "predicted_gross_savings": forecast_gross,
                    "construction_and_upkeep": required,
                    "predicted_net_gain": predicted,
                    "saving_per_requested_job_if_passed": saving,
                }
                if predicted <= 0:
                    search_stopped = True
                    events.append(
                        {
                            "month": month,
                            "kind": "SEARCH_STOP_PAYBACK",
                            "id": spec["id"],
                            "predicted_net_gain": predicted,
                        }
                    )
                elif (
                    earmark >= D(spec["construction_and_evaluation_usd"])
                    and unused_provider_minutes
                    >= D(60) * spec["provider_hours_included_in_cash_cost"]
                ):
                    discretionary = D(spec["construction_and_evaluation_usd"])
                    construction_minutes = (
                        D(60) * spec["provider_hours_included_in_cash_cost"]
                    )
                    record = {
                        "index": next_candidate,
                        "id": spec["id"],
                        "constructed_month": month,
                        "cost": discretionary,
                        "passed": False,
                        "evaluation_month": None,
                        "subsequent_requested_uses": 0,
                        "saving_per_requested_job": ZERO,
                        "gross_savings": ZERO,
                        "upkeep_paid": ZERO,
                        "predicted_net_gain": predicted,
                    }
                    candidates.append(record)
                    pending = {
                        "kind": "candidate",
                        "record_index": len(candidates) - 1,
                        "due_month": month + spec["evaluation_delay_months"],
                    }
                    next_candidate += 1
                    action = {
                        "kind": "candidate",
                        "id": spec["id"],
                        "cost": discretionary,
                    }
            if discretionary:
                cash -= discretionary
                earmark -= discretionary
                investment += discretionary
                provider_minutes_total += construction_minutes
                construction_minutes_total += construction_minutes
        assert cash >= 0 and earmark >= 0
        residual = cash - (
            opening
            + net_collection
            - debt_repaid
            - paid_fixed
            - request_cost
            - discretionary
        )
        assert abs(residual) < D("1e-40"), residual
        rows.append(
            {
                "month": month,
                "opening_cash": opening,
                "promotion": promotion,
                "invoice_count_collected": invoice_count_collected,
                "gross_collection": gross,
                "refund": refund,
                "processing": fee,
                "net_collection": net_collection,
                "mandatory_cost_incurred": incurred_fixed,
                "mandatory_cost_paid": paid_fixed,
                "debt_repaid": debt_repaid,
                "unpaid_obligation": unpaid,
                "arrival": request_arrival,
                "requests": n,
                "accepted": accepted,
                "rejected_or_refused": D(n) - accepted,
                "backlog": backlog,
                "delivery_cost": request_cost,
                "current_variable_cost": variable,
                "current_variable_nonlabor": method_nonlabor,
                "current_variable_provider_minutes": method_minutes,
                "current_fixed_cost": fixed,
                "current_fixed_provider_minutes": fixed_minutes,
                "instances": instances,
                "limits": limits,
                "unused_provider_minutes": unused_provider_minutes,
                "ordinary_operating_income": operating_income,
                "tax_reserve": tax,
                "warranty_reserve": warranty,
                "next_resource_requests": next_count,
                "working_capital_reserve": working_capital,
                "reserve_shortfall": reserve_shortfall,
                "recovered_surplus": recovered_surplus,
                "allocation_ceiling": ceiling,
                "new_allocation": allocation,
                "released_earmark": released,
                "lifetime_allocation": lifetime_allocation,
                "closing_earmark": earmark,
                "discretionary_spend": discretionary,
                "action": action,
                "forecasts": forecasts,
                "closing_cash": cash,
                "cash_residual": residual,
                "stopped_this_month": stopped_this_month,
                "operating": active,
                "customer_fixed_months_to_date": customer_fixed_months,
            }
        )
        previous_accepted = accepted
        previous_gross = gross
    accepted = D(served) * a["q"]
    all_cost = (
        (a["initial_cash"] if started else ZERO)
        + mandatory_incurred
        + delivery_cost
        + investment
    )
    break_even = (
        (all_cost / collected_count + D(s["processing_usd_per_collected_invoice"]))
        / (
            ONE
            - D(s["refund_fraction_of_collected"])
            - D(s["payment_processing_fraction"])
        )
        if collected_count > 0
        else None
    )
    for record in candidates:
        record["net_return"] = (
            record["gross_savings"] - record["cost"] - record["upkeep_paid"]
        )
        record["actual_horizon_payback_requests"] = (
            ceil(
                (record["cost"] + record["upkeep_paid"])
                / record["saving_per_requested_job"]
            )
            if record["saving_per_requested_job"] > 0
            else None
        )
    summary = {
        "started": started,
        "start_infeasible": not started,
        "quoted_startup_requirement": a["initial_cash"],
        "startup_capital_shortfall": positive(a["initial_cash"] - initial_capital),
        "setup_workdays": a["setup_workdays"],
        "annual_demand": demand,
        "served_requests": served,
        "expected_accepted": accepted,
        "served_failures": D(served) - accepted,
        "never_served_requests": demand - served,
        "full_demand_human_fallback": D(demand) - accepted,
        "startup_incurred": a["initial_cash"] if started else ZERO,
        "mandatory_cost_incurred": mandatory_incurred,
        "mandatory_cost_paid": mandatory_paid,
        "delivery_cost": delivery_cost,
        "discretionary_spend": investment,
        "provider_cost_before_payment_charges": all_cost,
        "gross_collections": collected_gross,
        "refunds": refunds,
        "processing": processing,
        "net_collections": collected_gross - refunds - processing,
        "collected_invoice_count": collected_count,
        "face_invoices": accepted * price,
        "uncollected_final_invoices": previous_accepted * price,
        "expected_bad_debt_on_due_invoices": (accepted - previous_accepted)
        * price
        * (ONE - D(s["collected_fraction_of_accepted_invoices"])),
        "ordinary_operating_income": operating_income,
        "combined_pre_tax_income": operating_income - investment,
        "combined_after_tax_reserve_income": operating_income - investment - tax,
        "closing_cash": cash,
        "tax_reserve": tax,
        "warranty_reserve": warranty,
        "working_capital_reserve": rows[-1]["working_capital_reserve"],
        "idle_earmark": earmark,
        "lifetime_allocation": lifetime_allocation,
        "released_earmarks": cumulative_earmark_released,
        "unpaid_obligation": unpaid,
        "free_cash": cash
        - tax
        - warranty
        - rows[-1]["working_capital_reserve"]
        - earmark
        - unpaid,
        "conditional_break_even_price": break_even,
        "zero_policy_break_even_price": break_even if fraction == 0 else None,
        "investing_combined_cost_break_even_price": (
            break_even if fraction > 0 else None
        ),
        "customer_fixed_months": customer_fixed_months,
        "provider_minutes": provider_minutes_total,
        "discretionary_construction_minutes": construction_minutes_total,
        "provider_cost_per_expected_accepted_before_payment_charges": (
            all_cost / accepted if accepted > 0 else None
        ),
        "provider_cost_per_expected_accepted_with_payment_charges": (
            (all_cost + processing + refunds) / accepted if accepted > 0 else None
        ),
        "constructed_candidates": len(candidates),
        "promoted_candidates": sum(int(x["passed"]) for x in candidates),
        "failed_candidates": sum(
            int(x["evaluation_month"] is not None and not x["passed"])
            for x in candidates
        ),
        "capacity_purchases": len(capacity_purchases),
        "stopped": started and not active,
    }
    assert abs(
        summary["combined_pre_tax_income"] - (cash - initial_capital - unpaid)
    ) < D("1e-38")
    assert abs(
        lifetime_allocation - investment - earmark - cumulative_earmark_released
    ) < D("1e-38")
    return {
        "identity": {
            "profile": profile,
            "scenario": scenario,
            "price": price,
            "fraction": fraction,
            "world": world,
            "demand_multiplier": multiplier,
        },
        "accounts": a,
        "summary": summary,
        "monthly": rows,
        "candidates": candidates,
        "capacity_purchases": capacity_purchases,
        "customer": customer_comparison(
            inputs, anchor, profile, scenario, price, a, summary
        ),
        "events": events,
    }


def main():
    authorized = authorize()
    started = datetime.now(timezone.utc).isoformat()
    attempt = {"started_utc": started, "oracle_sha256": sha(Path(__file__))}
    try:
        inputs = read(ROOT / "inputs.json")
        anchor = read(ROOT / "prior_model_anchor.json")
        primary = [
            one_path(inputs, anchor, p, s, price, f, w, 1)
            for p, s, price, f, w in product(
                ("evidence_pack", "cost_050_hypothesis"),
                inputs["scenarios"],
                inputs["prices_usd_per_accepted_delivery"],
                inputs["reinvestment_fractions_of_available_surplus"],
                inputs["capability_outcome_worlds"],
            )
        ]
        sensitivity = [
            one_path(inputs, anchor, p, "base", 20, f, w, mult)
            for p, mult, f, w in product(
                ("evidence_pack", "cost_050_hypothesis"),
                (D("0.25"), D(4)),
                inputs["reinvestment_fractions_of_available_surplus"],
                inputs["capability_outcome_worlds"],
            )
        ]
        assert len(primary) == 144 and len(sensitivity) == 32
        result = {
            "schema": "cash-reinvestment-independent-decimal-results/v1",
            "status": "INDEPENDENT_CALCULATION_COMPLETE_NOT_YET_COMPARISON",
            "freeze_sha256": FREEZE_SHA,
            "authorized_utc": authorized["authorized_utc"],
            "oracle_sha256": sha(Path(__file__)),
            "started_utc": started,
            "finished_utc": datetime.now(timezone.utc).isoformat(),
            "primary_cases": primary,
            "demand_sensitivity_cases": sensitivity,
        }
        destination = ROOT / "evaluation/INDEPENDENT_RESULTS.json"
        destination.write_text(
            json.dumps(result, indent=2, sort_keys=True, default=serial) + "\n"
        )
        attempt.update(
            {
                "status": "PASS_INTERNAL_IDENTITIES",
                "result_sha256": sha(destination),
                "primary_cases": len(primary),
                "sensitivity_cases": len(sensitivity),
            }
        )
        print(json.dumps(attempt))
    except Exception as exc:
        attempt.update(
            {"status": "FAIL", "error": repr(exc), "traceback": traceback.format_exc()}
        )
        raise
    finally:
        attempt["finished_utc"] = datetime.now(timezone.utc).isoformat()
        with (ROOT / "evaluation/ORACLE_ATTEMPTS.jsonl").open("a") as stream:
            stream.write(json.dumps(attempt) + "\n")


if __name__ == "__main__":
    main()
