# SPDX-License-Identifier: Apache-2.0
"""Compare independent financial arithmetic to every reported path."""

from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path

from oracle import D, ROOT, authorize, read, sha, serial, positive


def case_key(case, independent=False):
    if independent:
        c = case["identity"]
        return (
            c["profile"],
            c["scenario"],
            D(c["price"]),
            D(c["fraction"]),
            c["world"],
            D(c["demand_multiplier"]),
        )
    return (
        case["profile"],
        case["scenario"],
        D(case["price_usd_per_accepted"]),
        D(case["reinvestment_fraction"]),
        case["outcome_world"],
        D(case["demand_multiplier"]),
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", default="run-002")
    args = parser.parse_args()
    authorize()
    producer_path = ROOT / "outputs" / args.run / "results.json"
    independent_path = ROOT / "evaluation/INDEPENDENT_RESULTS.json"
    producer = read(producer_path)
    independent = read(independent_path)
    checks, differences = [], []

    def compare(label, actual, expected):
        if isinstance(actual, dict) and "value" in actual:
            actual = actual["value"]
        if (
            expected is None
            or actual is None
            or isinstance(expected, bool)
            or isinstance(actual, bool)
        ):
            equal = actual == expected
        else:
            actual, expected = D(actual), D(expected)
            equal = abs(actual - expected) <= D("1e-7") + D("1e-11") * abs(expected)
        checks.append(label)
        if not equal:
            differences.append({"path": label, "actual": actual, "expected": expected})

    summary_map = {
        "startup_admitted": "started",
        "quoted_startup_usd": "quoted_startup_requirement",
        "startup_shortfall_usd": "startup_capital_shortfall",
        "setup_workdays_before_operating_horizon": "setup_workdays",
        "annual_requested_demand": "annual_demand",
        "requests_served": "served_requests",
        "expected_accepted": "expected_accepted",
        "expected_unresolved_served": "served_failures",
        "unserved_annual_demand": "never_served_requests",
        "customer_fixed_months": "customer_fixed_months",
        "accepted_invoice_face_usd": "face_invoices",
        "gross_collections_usd": "gross_collections",
        "expected_collected_invoice_units": "collected_invoice_count",
        "refunds_usd": "refunds",
        "payment_processing_usd": "processing",
        "net_cash_collections_usd": "net_collections",
        "uncollected_final_month_receivable_face_usd": "uncollected_final_invoices",
        "modeled_past_due_bad_debt_face_usd": "expected_bad_debt_on_due_invoices",
        "provider_startup_incurred_paid_usd": "startup_incurred",
        "provider_delivery_incurred_paid_usd": "delivery_cost",
        "discretionary_construction_and_capacity_paid_usd": "discretionary_spend",
        "combined_provider_cost_incurred_usd": "provider_cost_before_payment_charges",
        "provider_cost_per_expected_accepted": "provider_cost_per_expected_accepted_before_payment_charges",
        "ordinary_income_before_discretionary_usd": "ordinary_operating_income",
        "combined_income_before_tax_reserve_usd": "combined_pre_tax_income",
        "combined_income_after_tax_reserve_usd": "combined_after_tax_reserve_income",
        "closing_cash_usd": "closing_cash",
        "tax_reserve_usd": "tax_reserve",
        "warranty_reserve_usd": "warranty_reserve",
        "working_capital_reserve_target_usd": "working_capital_reserve",
        "idle_earmark_usd": "idle_earmark",
        "lifetime_allocation_usd": "lifetime_allocation",
        "released_unused_earmarks_usd": "released_earmarks",
        "unpaid_shutdown_obligation_usd": "unpaid_obligation",
        "provider_minutes_required_including_setup_delivery_improvement": "provider_minutes",
        "candidate_constructions": "constructed_candidates",
        "simulated_candidates_failed": "failed_candidates",
        "simulated_candidates_promoted": "promoted_candidates",
        "executor_purchases": "capacity_purchases",
        "zero_reinvestment_break_even_price_usd": "zero_policy_break_even_price",
        "combined_cost_conditional_break_even_price_usd": "conditional_break_even_price",
    }
    month_map = {
        "opening_cash_usd": "opening_cash",
        "collected_invoice_units": "invoice_count_collected",
        "gross_collections_usd": "gross_collection",
        "refunds_usd": "refund",
        "net_collections_usd": "net_collection",
        "admitted_new_demand": "arrival",
        "requests_served": "requests",
        "expected_accepted": "accepted",
        "expected_unresolved_served": "rejected_or_refused",
        "backlog_arrived_unserved": "backlog",
        "provider_variable_cash_per_request_usd": "current_variable_cost",
        "provider_variable_nonlabor_per_request_usd": "current_variable_nonlabor",
        "provider_variable_minutes_per_request": "current_variable_provider_minutes",
        "provider_delivery_incurred_paid_usd": "delivery_cost",
        "mandatory_or_shutdown_incurred_usd": "mandatory_cost_incurred",
        "mandatory_or_shutdown_paid_usd": "mandatory_cost_paid",
        "prior_shutdown_obligation_payment_usd": "debt_repaid",
        "unpaid_shutdown_obligation_usd": "unpaid_obligation",
        "executor_instances": "instances",
        "ordinary_cumulative_income_before_discretionary_usd": "ordinary_operating_income",
        "recovered_after_tax_operating_surplus_usd": "recovered_surplus",
        "tax_reserve_usd": "tax_reserve",
        "warranty_reserve_usd": "warranty_reserve",
        "next_month_resource_feasible_requests": "next_resource_requests",
        "working_capital_reserve_target_usd": "working_capital_reserve",
        "reserve_target_shortfall_before_action_usd": "reserve_shortfall",
        "cumulative_allocation_ceiling_usd": "allocation_ceiling",
        "new_earmark_usd": "new_allocation",
        "lifetime_allocation_usd": "lifetime_allocation",
        "released_unused_earmark_usd": "released_earmark",
        "idle_earmark_usd": "closing_earmark",
        "discretionary_spending_usd": "discretionary_spend",
        "closing_cash_usd": "closing_cash",
        "cash_reconciliation_residual_usd": "cash_residual",
    }
    by_key = {
        case_key(c, True): c
        for collection in ("primary_cases", "demand_sensitivity_cases")
        for c in independent[collection]
    }
    for collection in ("primary_cases", "demand_sensitivity_cases"):
        compare(
            collection + ".count",
            len(producer[collection]),
            len(independent[collection]),
        )
        for p in producer[collection]:
            o = by_key[case_key(p)]
            prefix = p["case_id"]
            ps, os = p["summary"], o["summary"]
            for pk, ok in summary_map.items():
                compare(prefix + ".summary." + pk, ps[pk], os[ok])
            compare(
                prefix + ".summary.all_mandatory",
                D(ps["provider_mandatory_operating_incurred_usd"])
                + D(ps["provider_shutdown_incurred_usd"]),
                os["mandatory_cost_incurred"],
            )
            compare(
                prefix + ".summary.free_cash",
                ps["closing_liquid_free_cash_after_targets_usd"],
                positive(D(os["free_cash"])),
            )
            complete_expense = D(os["provider_cost_before_payment_charges"]) + D(
                os["processing"]
            )
            compare(
                prefix + ".summary.complete_expense",
                ps["complete_provider_expense_including_payment_processing_usd"],
                complete_expense,
            )
            compare(
                prefix + ".summary.complete_expense_per_accepted",
                ps[
                    "complete_provider_expense_including_payment_processing_per_expected_accepted"
                ],
                (
                    complete_expense / D(os["expected_accepted"])
                    if D(os["expected_accepted"]) > 0
                    else None
                ),
            )
            compare(
                prefix + ".summary.refund_contra_revenue",
                ps["refunds_contra_revenue_usd"],
                os["refunds"],
            )
            for unknown in (
                "historical_authoring_cost_usd",
                "observed_collected_revenue_usd",
                "actual_incremental_capability_gain",
            ):
                compare(prefix + ".summary." + unknown, ps[unknown], None)
            compare(prefix + ".monthly.count", len(p["monthly"]), 12)
            for pm, om in zip(p["monthly"], o["monthly"]):
                mp = prefix + ".month" + str(pm["month"])
                for pk, ok in month_map.items():
                    compare(mp + "." + pk, pm[pk], om[ok])
                compare(
                    mp + ".processing_total",
                    D(pm["percentage_processing_usd"]) + D(pm["fixed_processing_usd"]),
                    om["processing"],
                )
                if om["limits"] is not None:
                    for pk, ok in (
                        ("provider_minutes", "provider"),
                        ("customer_minutes", "customer"),
                        ("executor_seconds", "executor"),
                    ):
                        compare(
                            mp + ".resource_limits." + pk,
                            pm["resource_limits"]["limits"][pk],
                            om["limits"][ok],
                        )
                    compare(
                        mp + ".cash_request_limit",
                        pm["cash_request_limit"],
                        om["limits"]["cash"],
                    )
            pc = p["customer_comparison"]["common"]
            oc = o["customer"]
            for pk, ok in (
                ("agent_face_price_invoices_usd", "accepted_face_invoices"),
                (
                    "agent_customer_total_per_expected_accepted",
                    "agent_customer_cost_per_expected_accepted",
                ),
                ("agent_customer_attention_minutes", "own_customer_minutes"),
            ):
                compare(prefix + ".customer.common." + pk, pc[pk], oc[ok])
            compare(
                prefix + ".customer.common.total",
                pc["agent_customer_total_usd"],
                D(oc["own_customer_cash"]) + D(oc["accepted_face_invoices"]),
            )
            human_rows = {
                row["human_productive_minutes"]: row for row in oc["comparisons"]
            }
            for row in p["customer_comparison"]["comparisons"]:
                source = human_rows[row["productive_human_minutes_assumed"]]
                scope = "served" if row["scope"] == "served_cohort" else "annual"
                expected = source[scope]
                cp = (
                    prefix
                    + ".customer."
                    + str(row["productive_human_minutes_assumed"])
                    + "."
                    + scope
                )
                empty = scope == "served" and expected["cohort_requests"] == 0
                # Explicit post-result reporting adjudication: there is no
                # meaningful comparison for an empty served subset. The full
                # annual-demand endpoint and readiness plan remain unchanged.
                if empty:
                    for pk in (
                        "traditional_unit_cost_usd",
                        "traditional_readiness_usd",
                        "traditional_total_usd",
                        "hybrid_total_usd",
                        "customer_savings_usd",
                        "cohort_conditional_viable_price_interval_exists",
                    ):
                        compare(cp + "." + pk, row[pk], None)
                    for pk in (
                        "hybrid_cost_per_completed_request",
                        "maximum_customer_beneficial_face_price_usd",
                    ):
                        compare(cp + "." + pk, row[pk], None)
                    compare(
                        cp + ".unit_assumption",
                        row["traditional_unit_cost_assumption_usd"],
                        source["human_variable_cost"],
                    )
                    compare(
                        cp + ".readiness_plan",
                        row["traditional_plan_readiness_commitment_usd"],
                        source["human_fixed_cost"],
                    )
                    for pk in (
                        "fallback_worker_minutes",
                        "total_customer_attention_minutes",
                        "customer_pool_feasible",
                        "traditional_worker_pool_feasible",
                    ):
                        compare(
                            cp + "." + pk,
                            row["fallback_resource_requirements"][pk],
                            None,
                        )
                    continue
                for pk, ok in (
                    ("cohort_requests", "cohort_requests"),
                    ("fallback_requests", "fallback_jobs"),
                    ("traditional_total_usd", "traditional_cost"),
                    ("hybrid_total_usd", "customer_complete_cost"),
                    ("customer_savings_usd", "customer_savings"),
                    (
                        "maximum_customer_beneficial_face_price_usd",
                        "customer_maximum_beneficial_price",
                    ),
                    (
                        "hybrid_cost_per_completed_request",
                        "customer_complete_cost_per_completed",
                    ),
                ):
                    compare(cp + "." + pk, row[pk], expected[ok])
                compare(
                    cp + ".human_variable",
                    row["traditional_unit_cost_usd"],
                    source["human_variable_cost"],
                )
                compare(
                    cp + ".human_fixed",
                    row["traditional_readiness_usd"],
                    source["human_fixed_cost"],
                )
                resources = row["fallback_resource_requirements"]
                for pk, ok in (
                    ("fallback_worker_minutes", "fallback_worker_minutes"),
                    ("total_customer_attention_minutes", "total_customer_minutes"),
                ):
                    if pk in resources:
                        compare(cp + "." + pk, resources[pk], expected[ok])
    outdir = ROOT / "evaluation/audit_attempts"
    outdir.mkdir(exist_ok=True)
    attempt = len(list(outdir.glob("attempt-*.json"))) + 1
    report = {
        "schema": "cash-reinvestment-independent-audit/v1",
        "status": "PASS" if not differences else "FAIL",
        "audited_utc": datetime.now(timezone.utc).isoformat(),
        "checks": len(checks),
        "differences": differences,
        "producer_results_sha256": sha(producer_path),
        "producer_model_sha256": sha(producer_path.parent / "MODEL_ATTEMPT.py"),
        "independent_results_sha256": sha(independent_path),
        "oracle_sha256": sha(ROOT / "evaluation/oracle.py"),
        "auditor_sha256": sha(Path(__file__)),
        "tolerance": {"absolute": "1e-7", "relative": "1e-11"},
        "scope": "Core summary, monthly transitions/resources and customer comparisons; further component/forecast/token/derivative checks reported separately.",
        "post_result_reporting_adjudication": "Stopped operational Nnext is zero; any restart resource forecast is separate. Empty served-cohort comparisons are unavailable while full readiness assumptions and annual-demand comparisons remain. Company expenses include processing, with refunds as contra-revenue. Initial424 differences remain preserved.",
    }
    output = outdir / f"attempt-{attempt:03d}.json"
    output.write_text(
        json.dumps(report, indent=2, sort_keys=True, default=serial) + "\n"
    )
    print(
        json.dumps(
            {
                "status": report["status"],
                "checks": report["checks"],
                "difference_count": len(differences),
                "output": str(output),
                "first_differences": differences[:12],
            },
            default=serial,
        )
    )


if __name__ == "__main__":
    main()
