# SPDX-License-Identifier: Apache-2.0
"""Independent integer settlement and Decimal realization arithmetic."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from oracle import D, ROOT, ZERO, ONE, authorize, ceil, read, sha, serial


def main():
    authorize()
    data = read(ROOT / "token_scenarios.json")
    token_quote = D(data["hypothetical_usd_per_agialpha_at_quote"])
    rows, successes, failures = [], [], []
    count = data["accepted_settlements_in_example_month"]
    days = data["calendar_days_in_example_month"]
    for amount in data["quoted_job_amounts_usd"]:
        for route in (
            "manager_usdc",
            "ascension_agialpha",
            "jobs_v0_agialpha_success_only",
        ):
            decimals = 6 if route == "manager_usdc" else 18
            scale = 10**decimals
            quote = ONE if route == "manager_usdc" else token_quote
            nominal = int(D(amount) / quote * scale)
            base = {
                "route": route,
                "quoted_usd": D(amount),
                "decimals": decimals,
                "quote_asset_usd": quote,
            }
            if route == "manager_usdc":
                params = data["manager"]
                escrow = nominal
                budget = escrow * params["validator_budget_percent"] // 100
                wallet30 = escrow * params["wallet30_percent"] // 100
                wallet10 = escrow * params["wallet10_percent"] // 100
                each = budget // params["correct_validators"]
                residue = budget - each * params["correct_validators"]
                worker = escrow - budget - wallet30 - wallet10 + residue
                bond0 = max(
                    escrow * params["agent_bond_bps"] // 10000,
                    params["agent_bond_min_atomic"],
                )
                limit = params["job_duration_limit_seconds_assumed"]
                bond = bond0 + (
                    bond0 * params["job_duration_seconds_assumed"] // limit
                    if limit
                    else 0
                )
                if params["agent_bond_max_atomic"]:
                    bond = min(bond, params["agent_bond_max_atomic"])
                bond = min(bond, escrow)
                validator_bond = min(
                    escrow,
                    params["validator_bond_max_atomic"],
                    max(
                        escrow * params["validator_bond_bps"] // 10000,
                        params["validator_bond_min_atomic"],
                    ),
                )
                detail = {
                    "customer_escrow_atomic": escrow,
                    "worker_net_atomic": worker,
                    "validator_net_atomic": each * params["correct_validators"],
                    "validator_each_atomic": each,
                    "wallet30_atomic": wallet30,
                    "wallet10_atomic": wallet10,
                    "rounding_residue_to_worker_atomic": residue,
                    "burn_atomic": 0,
                    "fee_pool_net_atomic": 0,
                    "worker_bond_atomic": bond,
                    "validator_bond_each_atomic": validator_bond,
                    "admission_floor_atomic": 0,
                    "quoted_reward_atomic": escrow,
                }
                assert (
                    escrow
                    == worker
                    + each * params["correct_validators"]
                    + wallet30
                    + wallet10
                )
                failures.append(
                    {
                        **base,
                        "failure_kind": "assigned_expiry",
                        "customer_escrow_atomic": escrow,
                        "worker_bond_atomic": bond,
                        "customer_refund_atomic": escrow + bond,
                        "worker_bond_return_atomic": 0,
                        "worker_bond_loss_atomic": bond,
                        "burn_atomic": 0,
                    }
                )
            elif route == "ascension_agialpha":
                params = data["ascension"]
                escrow = nominal
                each_gross = (
                    nominal * params["validator_pool_bps_source"] // 10000
                ) // 2
                worker_gross = nominal - 2 * each_gross
                worker_burn = worker_gross // 100
                each_burn = each_gross // 100
                worker = worker_gross - worker_burn
                each = each_gross - each_burn
                burn = worker_burn + 2 * each_burn
                minimum = int(D(params["chosen_market_minimum_stake_tokens"]) * scale)
                bond = max(escrow // 10, minimum)
                detail = {
                    "customer_escrow_atomic": escrow,
                    "worker_net_atomic": worker,
                    "worker_gross_atomic": worker_gross,
                    "validator_net_atomic": 2 * each,
                    "validator_each_atomic": each,
                    "validator_each_gross_atomic": each_gross,
                    "worker_burn_atomic": worker_burn,
                    "validator_each_burn_atomic": each_burn,
                    "wallet30_atomic": 0,
                    "wallet10_atomic": 0,
                    "burn_atomic": burn,
                    "fee_pool_net_atomic": 0,
                    "worker_bond_atomic": bond,
                    "admission_floor_atomic": 0,
                    "market_minimum_atomic": minimum,
                    "quoted_reward_atomic": nominal,
                }
                assert escrow == worker + 2 * each + burn
                bond_burn = bond // 100
                failures.append(
                    {
                        **base,
                        "failure_kind": "slashable_failure",
                        "customer_escrow_atomic": escrow,
                        "worker_bond_atomic": bond,
                        "customer_refund_atomic": escrow + bond - bond_burn,
                        "worker_bond_return_atomic": 0,
                        "worker_bond_loss_atomic": bond,
                        "burn_atomic": bond_burn,
                    }
                )
                failures.append(
                    {
                        **base,
                        "failure_kind": "missing_review_quorum",
                        "customer_escrow_atomic": escrow,
                        "worker_bond_atomic": bond,
                        "customer_refund_atomic": escrow,
                        "worker_bond_return_atomic": bond,
                        "worker_bond_loss_atomic": 0,
                        "burn_atomic": 0,
                    }
                )
            else:
                params = data["jobs_v0"]
                reward = nominal
                fee = reward * params["fee_percent_config_example"] // 100
                escrow = reward + fee
                validator = (
                    reward * params["validator_reward_percent_config_example"] // 100
                )
                modified = (
                    (reward - validator)
                    * params["agent_payout_multiplier_percent_assumed"]
                    // 100
                )
                worker_burn = (
                    modified * params["worker_burn_percent_config_example"] // 100
                )
                worker = modified - worker_burn
                fee_burn = fee * params["fee_pool_burn_percent_config_example"] // 100
                fee_net = fee - fee_burn
                bond = (reward * params["job_stake_bps_config_example"] + 9999) // 10000
                admission = int(
                    D(params["agent_admission_minimum_tokens_config_example"]) * scale
                )
                detail = {
                    "customer_escrow_atomic": escrow,
                    "quoted_reward_atomic": reward,
                    "additional_fee_atomic": fee,
                    "worker_net_atomic": worker,
                    "validator_net_atomic": validator,
                    "worker_burn_atomic": worker_burn,
                    "fee_burn_atomic": fee_burn,
                    "wallet30_atomic": 0,
                    "wallet10_atomic": 0,
                    "burn_atomic": worker_burn + fee_burn,
                    "fee_pool_net_atomic": fee_net,
                    "worker_bond_atomic": bond,
                    "admission_floor_atomic": admission,
                }
                assert escrow == worker + validator + worker_burn + fee_burn + fee_net
            success = {**base, **detail}
            successes.append(success)
            monthly_units = D(worker) / D(scale) * count
            for scenario, s in data["realization_scenarios"].items():
                if route == "manager_usdc":
                    value_fraction = D(s["usdc_usd_realization_fraction"])
                    slippage = ZERO
                    conversion_fee = D(s["usdc_conversion_fee_fraction"])
                else:
                    value_fraction = D(s["agialpha_value_fraction_at_realization"])
                    slippage = D(s["agialpha_slippage_fraction"])
                    conversion_fee = D(s["agialpha_conversion_fee_fraction"])
                cash_per_unit = (
                    quote * value_fraction * (ONE - slippage) * (ONE - conversion_fee)
                )
                potential_cash = monthly_units * cash_per_unit
                realized = min(
                    potential_cash, D(s["usd_conversion_liquidity_limit_per_month"])
                )
                converted_units = (
                    realized / cash_per_unit if cash_per_unit > 0 else ZERO
                )
                inventory = monthly_units - converted_units
                positions = ceil(D(count) * s["collateral_lock_days"] / D(days))
                bond_stock_atomic = bond * positions
                quoted_bond_stock = D(bond_stock_atomic) / D(scale) * quote
                capital_cost = (
                    quoted_bond_stock
                    * D(s["annual_imputed_capital_cost_fraction"])
                    * D(days)
                    / D(365)
                )
                gas = D(count) * D(s["worker_gas_usd_per_settlement_allowance"])
                rows.append(
                    {
                        **success,
                        "scenario": scenario,
                        "monthly_worker_award_units": monthly_units,
                        "cash_per_asset_unit_after_realization_cost": cash_per_unit,
                        "unconstrained_conversion_cash": potential_cash,
                        "realized_cash": realized,
                        "converted_asset_units": converted_units,
                        "unconverted_asset_units": inventory,
                        "gas_allowance": gas,
                        "cash_after_gas": realized - gas,
                        "required_open_positions": positions,
                        "worker_bond_stock_atomic": bond_stock_atomic,
                        "quoted_bond_stock_usd": quoted_bond_stock,
                        "imputed_capital_cost": capital_cost,
                        "settlement_contribution_after_gas_and_imputed_capital": realized
                        - gas
                        - capital_cost,
                    }
                )
    assert len(successes) == 9 and len(rows) == 27 and len(failures) == 9
    for f in failures:
        assert (
            f["customer_escrow_atomic"] + f["worker_bond_atomic"]
            == f["customer_refund_atomic"]
            + f["worker_bond_return_atomic"]
            + f["burn_atomic"]
        )
    result = {
        "schema": "cash-reinvestment-independent-token-results/v1",
        "status": "INDEPENDENT_SOURCE_ARITHMETIC_NOT_CONTRACT_EXECUTION",
        "calculated_utc": datetime.now(timezone.utc).isoformat(),
        "oracle_sha256": sha(Path(__file__)),
        "input_sha256": sha(ROOT / "token_scenarios.json"),
        "source_success_waterfalls": successes,
        "realization_cases": rows,
        "failure_examples": failures,
        "live_transactions": "NOT_RUN",
        "jobs_failure": "NOT_MODELED",
    }
    destination = ROOT / "evaluation/INDEPENDENT_TOKEN_RESULTS.json"
    destination.write_text(
        json.dumps(result, indent=2, sort_keys=True, default=serial) + "\n"
    )
    print(
        json.dumps(
            {
                "status": result["status"],
                "success_rows": len(successes),
                "realization_rows": len(rows),
                "failure_rows": len(failures),
                "sha256": sha(destination),
            }
        )
    )


if __name__ == "__main__":
    main()
