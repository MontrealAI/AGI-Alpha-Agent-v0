"""Reviewer controls of the producer oracle, excluded from confirmation."""
import copy, hashlib, importlib.util, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('producer_oracle',ROOT/'companion/check.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
out=ROOT/'review/boundary-probes'
reports=[]
for p in sorted(out.glob('*.json')):
    row=json.loads(p.read_text())
    if 'result' not in row:continue
    try:
        r=module.check(row['project'],row['result'],row['previous'])
        reports.append({'case':row['case'],'oracle_accepted':r['accepted'],'failures':r['failures'],'checks':r['checks']})
    except Exception as e:
        reports.append({'case':row['case'],'oracle_exception':type(e).__name__+': '+str(e)})
base=ROOT/'outputs/development-final/missions/DEV01-c0-flywheel'
project=json.loads((base/'input.json').read_text())
result=json.loads((base/'execution.json').read_text())['result']
tampered=copy.deepcopy(result)
tampered['consistency']['assurance_digest']='0'*64
for artifact in tampered['pack']['result']['artifacts']:
    if artifact['name']=='consistency.json':artifact['content']=json.dumps(tampered['consistency'],indent=2)+'\n'
r=module.check(project,tampered,None)
reports.append({'case':'tampered-assurance-digest','oracle_accepted':r['accepted'],'failures':r['failures'],'checks':r['checks']})
tampered=copy.deepcopy(result)
tampered['assurance']['components'][0]['spdx']='SPDX-License-Identifier: INVENTED-FOR-REVIEW'
tampered['assurance']['components'][0]['declared_names']=['NOT_IN_SOURCE']
for artifact in tampered['pack']['result']['artifacts']:
    if artifact['name']=='release-assurance.json':artifact['content']=json.dumps(tampered['assurance'],indent=2)+'\n'
r=module.check(project,tampered,None)
reports.append({'case':'tampered-literal-inventory','oracle_accepted':r['accepted'],'failures':r['failures'],'checks':r['checks']})
payload={'scope':'Reviewer-authored development controls of original producer oracle. Not confirmation, not independent validation of outputs.','reviewed_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'companion/capability.mjs',ROOT/'companion/check.py']},'cases':reports}
(out/'oracle-scope.json').write_text(json.dumps(payload,indent=2)+'\n')
print(json.dumps(payload,indent=2))
