# Source review and corrective-edition gate

**Study:** Productive Capital Engine, 25 October 2026.  
**Reviewer role:** separate architecture/evidence agent in the same commission and session.  
**Status:** the finite primary records pass an additional independent implementation check; original boundary defects are preserved; a corrected edition passed the reviewer's focused development controls before its separate qualification freeze.

## Timing and independence

This filename was requested as `PREFREEZE_REVIEW.md`. The review was commissioned before freeze, but its concrete findings reached the implementation owner **after** primary freeze and while primary confirmation was executing. It is therefore a **during-confirmation source review**, not a completed pre-freeze approval of version 1. No original experiment source or original record was edited by this reviewer. The owner preserved the original 38-file commitment and prepared an additive `companion_v1_1/` corrective edition. Its engineering qualification is separate from the primary timing experiment.

The original freeze was created at `2026-10-25T14:14:23.632179+00:00`. Its file SHA-256 is `67bde22d8f654030bc3120d22eaf26a5f84c80e725ba5e2f9444955fd8569352`; the entries digest is `7f3c0c40781e73418357c88908297a4bba9bbfbf72684ca0ea9cad2c845dfb73`. The reviewed original compiler has SHA-256 `def67ae961e766e56cf1f1a550c418143927a49c1f8824f6b5086513796c4814`; the original Python oracle is `17b19f8088a16f271077ccbf4b15a3bbb0bb998ad8f0bcdaccf852ac4923f4f8`.

This is implementation and role separation, with common commission, model family, session, task framing, source access and host. It is neither a blinded experiment nor an external audit. Source inspection was read-only. Boundary controls use development inputs, not the six primary confirmation projects. No live authenticated executor, new transaction, historical producer execution or broad repository test suite was run.

## Findings and concrete disposition

| ID | Finding in original version 1 | Reproduced consequence | Disposition |
|---|---|---|---|
| E01 | Component path was emitted in the evidence/dossier but absent from semantic keys, direct-change roots and oracle comparisons. | Renaming `C01` alone retained its old path; `changed=[]`, eight records reused, and the original oracle accepted. | Version 1.1 puts the path in both key implementations and both change predicates; its oracle compares paths. Reviewer control passes with the renamed path and transitive descendants invalidated. |
| E02 | Deletion semantics differed across arms. Flywheel included absent IDs in `invalidated`; ordinary caching always emitted an empty `removed` list. | Removing leaf `C08` produced `removed=[C08], invalidated=[C08]` for flywheel and failed the original oracle. Cache produced `removed=[]` and passed, despite the omission. | Version 1.1 records removed IDs separately and restricts invalidation to surviving components. Both arms pass the leaf-removal control. Parent deletion and dependency cleanup are also specified in the owner's separate corrective qualifier. |
| E03 | State integrity was checked without requiring the predecessor's project identity to equal the requested project. | A `DEV01` state was reused by `DIFFERENT_PROJECT`; eight evidence items were reused and the original oracle accepted. | Version 1.1 rejects with `PARENT_PROJECT_BINDING`. This isolates declared projects; hashes remain identity checks rather than authentication or human acceptance. |
| E04 | Child descriptors recorded a construction-parent digest but did not validate its relationship at use. | A descriptor constructed for `UNRELATED_CONSTRUCTION` was accepted on `DEV01`. The actual finite experiment was not shown to have this mismatch. | Version 1.1 retains the origin parent, checks its digest and project, requires the exact actual parent on first use, and retains the child/origin pair in predecessor state for subsequent use. Reviewer controls reject foreign and wrong first-parent origins and accept legitimate later reuse. |
| E05 | The original oracle compared artifact objects but did not independently recompute semantic keys, state/assurance/planning/impact digests, literal SPDX/import/name fields, or pack/trace digests. | Deliberately false assurance digest and invented literal-inventory metadata passed the original oracle when their exported objects were changed consistently. | Version 1.1 strengthens key and core-digest checking. The separate reviewer auditor additionally checks literal metadata and pack/stage/artifact digests across all original records. The finite pass does not establish completeness of either oracle for arbitrary malformed inputs. |
| E06 | The inherited workbench compilation retains generic aggregation incumbents and grouped-count hard gates from its upstream template. | Its graph is not a semantic acceptance specification for source assurance and rollout planning. | Version 1.1 explicitly labels the graph as generic scaffolding and identifies the workflow-specific checks as the acceptance basis. No complete Harness qualification, operational admission or deployed-contract integration is inferred. |
| E07 | Seven checkpoints are emitted after the source/plan/artifact computation has occurred. | Stage names and their artifact digests do not establish separately timed or budget-enforced execution stages. | Version 1.1 records this limitation explicitly. The stages are inspectable provenance records, not new timing measurements. |

Two other issues were caught by the root before the reviewed primary freeze: source-URL/original-source-hash changes were absent from direct-change roots, and native-candidate validation failures were silently swallowed. The inspected frozen code includes those fixes. It preserves rejected native candidates with their error messages and separately records native status. Their earlier existence is retained in the development history; this review does not claim to have discovered or independently timed their correction.

## Focused controls and preserved receipts

`review/boundary_probes.mjs` reproduces original behavior. `review/check_boundary_probes.py` deliberately calls the original oracle to document its coverage limits; that invocation is **not** counted as an independent output verification. Receipts are retained under `review/boundary-probes/`, including `summary.json` and `oracle-scope.json`.

`review/boundary_probes_v1_1.mjs` checks the corrected implementation with reviewer-authored development controls. Seven controls passed on the final pre-qualification compiler:

1. Path-only changes update the emitted inventory and invalidate dependent records.
2. Flywheel deletion reports a removed leaf without treating it as a current output.
3. Ordinary-cache deletion follows the same semantics.
4. Cross-project predecessor reuse is refused.
5. A foreign child construction origin is refused.
6. A wrong first construction parent within the same project is refused.
7. A legitimately registered child is reusable on a later change while retaining its original construction identity.

The final reviewed version 1.1 compiler SHA-256 was `6fc67c553d7f709ab93bde93e73174ca5330363dd67f84d4c2a150c89aba82ea`; checker SHA-256 was `d32c69e9877aeb5f5a71a987ac2024897d34e6b425232ef68a0723faf38bcea7`; corrective qualifier SHA-256 was `d28ad19076b20b47679217245ee3c3d65a603ed1209f030cb7e98b67f6ee5b0c`. The owner's later corrective freeze must match these or disclose any further change. These reviewer controls are development evidence and are not called held-out confirmation.

**Subsequent corrective qualification:** the owner froze the corrected source at `2026-10-25T14:19:54.113314+00:00` and generated the separate fresh cases from seed `202610252919`. `review/independent_correction_audit.py` then checked the saved results with the reviewer implementation. All **28 cases passed 3,885 additional assertions**: 25 delivered outputs and three expected refusals. All 36 corrective frozen files match, including the three reviewed hashes above. The check covers recomputed path-aware keys, literal fields, source/state/artifact/pack/stage digests, construction origins, first-use registry and a legitimate later use. Receipt: `review/INDEPENDENT_CORRECTION_AUDIT.json`. This is a finite corrective engineering qualification, not a replacement or replay of the original timing study.

The original six confirmation inputs contain content changes, a dependency addition and calendar/repair changes. They do not contain path-only changes, removed components, unrelated project state or substituted child origins. The defects therefore limit coverage and robustness claims; they do not by themselves falsify the finite original output counts. A broad claim that all arbitrary revisions are accepted would be unsupported.

## Independent recorded-evidence check

The separate `review/independent_evidence_audit.py` imports no producer, original oracle or solver module. It reads the stored inputs, records, delivered files and commitments, then reconstructs source content hashes, Git blob identities, dependency closure and semantic keys. It checks exact path/provenance/literal inventory fields, schedules, locks, capacity, movement, deadline, state identity, all stage/artifact/pack digests, actual construction origins and later child invocation links. It also reconciles original receipt counts and numerical summary aggregation. Two deliberate negative controls confirm that false digest and path records are rejected by this auditor.

The audit reports **PASS: 15,127 assertions, 72 of 72 joint recorded missions, 38 unchanged frozen files, 14 pinned source blobs, six construction origins and the associated retained child uses**. The producer's 11,268 assertions reconcile with their records. The complete receipt is `review/INDEPENDENT_EVIDENCE_AUDIT.json`. The same joint cost appears in three family rows by design; those rows must never be summed as separate service-execution costs or treated as independent tasks.

For changed cycles, the recorded CPU totals are 4,069.055080 ms for flywheel and 4,032.726595 ms for conventional cache: flywheel is **0.900842% higher** on this finite sample. This is not a population estimate and not a claim of a statistically reliable loss. It rules out describing these records as measured CPU superiority. Source-line reuse is real in both reuse arms; no same-budget frontier expansion or self-acceleration was established.

The auditor verifies the internal arithmetic of resource counters, not their independent measurement. It does not reconstruct metered upstream engineering/model work, human review, customer willingness to pay, licensing conclusions, deployment state, or authenticated execution. The original stage and graph limitations remain in the published history even though the corrected edition states them more clearly.

## Commercial and publication claim boundaries

The three output classes are complementary parts of one bounded workflow. Six synthetic project contexts are not six naturally sampled customer contracts; 216 family checks are not 216 independent jobs. The source inventory is literal extraction, the schedule is a proposed plan, and the bilingual dossier is an inspectable local artifact. None certifies software repair, source security, contract correctness, actual rollout, human acceptance or industrial validation.

The corrected demo should use version 1.1; primary timing charts should continue to cite unchanged version 1. Model-derived prices, revenue, surplus and reinvestment must retain simulated labels. The child's descriptor construction is authored fixed-grammar binding, and its measured binding time excludes authorship. Its economic admission must use the strongest ordinary-cache comparator and estimated lifecycle costs, not the full-rebuild gap alone.

The economic ledger review is a separate deliverable once its implementation and outputs are available. This source review is not a certification of yet-unreviewed financial arithmetic. External publication remains additive through the existing owner process described in `research/strategy_lab_verification.md`; corrective packaging does not authorize a competing software release or bypass an existing security hold.
