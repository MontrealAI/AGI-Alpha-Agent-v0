// Reviewer-owned focused controls. Not confirmation tasks and not production code.
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {runProject,retainedParent,constructChild,childImpact} from '../companion/capability.mjs';
const root=new URL('../',import.meta.url),out=new URL('./boundary-probes/',import.meta.url);
mkdirSync(out,{recursive:true});
const load=p=>JSON.parse(readFileSync(new URL(p,root),'utf8'));
const copy=x=>JSON.parse(JSON.stringify(x));
const project=load('outputs/development-final/missions/DEV01-c0-flywheel/input.json');
const initial=load('outputs/development-final/missions/DEV01-c0-flywheel/execution.json').result;
const previous=initial.state;
const cases=[];
async function runCase(name,p,options={}){
 const record={case:name,project:p,previous,source:'Reviewer-authored development boundary probe; excluded from confirmation and economics.'};
 try{
  const {parent}=await retainedParent(p,previous),child=await constructChild(parent);
  const result=await runProject(p,{arm:'flywheel',previous,child,...options});
  record.executed=true;record.result=result;
 }catch(error){record.executed=false;record.error=error.message;}
 writeFileSync(new URL(name+'.json',out),JSON.stringify(record,null,2)+'\n');
 cases.push({case:name,executed:record.executed,error:record.error??null});
 return record;
}
const path=copy(project);path.cycle=2;path.components[0].path='renamed-for-review/'+path.components[0].path;
const p=await runCase('path-only-change',path);
if(p.executed)Object.assign(cases.at(-1),{expected_path:path.components[0].path,actual_path:p.result.assurance.components[0].path,changed:p.result.impact.changed,reused_items:p.result.metrics.reused_items});
const removed=copy(project);removed.cycle=2;removed.components.pop();
const r=await runCase('removed-leaf-flywheel',removed);
if(r.executed)Object.assign(cases.at(-1),{removed:r.result.impact.removed,invalidated:r.result.impact.invalidated});
const q=await runCase('removed-leaf-conventional',removed,{arm:'conventional_cache'});
if(q.executed)Object.assign(cases.at(-1),{removed:q.result.impact.removed,invalidated:q.result.impact.invalidated});
const cross=copy(project);cross.id='DIFFERENT_PROJECT';cross.cycle=1;cross.task.id='DIFFERENT_PROJECT-c1';
const c=await runCase('cross-project-predecessor',cross);
if(c.executed)Object.assign(cases.at(-1),{previous_project:previous.project_id,current_project:c.result.state.project_id,reused_items:c.result.metrics.reused_items});
const unrelated=copy(project);unrelated.id='UNRELATED_CONSTRUCTION';unrelated.cycle=2;unrelated.components[0].content+='\n// unrelated construction\n';
const origin=await retainedParent(unrelated,previous),foreignChild=await constructChild(origin.parent);
const changed=copy(project);changed.cycle=2;changed.components[1].content+='\n// target change\n';
const target=await retainedParent(changed,previous);
try{
 const impact=await childImpact(changed,target.parent,previous,foreignChild);
 cases.push({case:'foreign-child-construction-origin',executed:true,construction_project:origin.parent.project_id,target_project:target.parent.project_id,construction_parent_digest:foreignChild.parent_digest,use_parent_digest:impact.parent_digest,child_digest:foreignChild.digest});
}catch(error){cases.push({case:'foreign-child-construction-origin',executed:false,error:error.message});}
writeFileSync(new URL('summary.json',out),JSON.stringify({scope:'FOCUSED_DEVELOPMENT_REVIEW_ONLY',cases},null,2)+'\n');
console.log(JSON.stringify(cases,null,2));
