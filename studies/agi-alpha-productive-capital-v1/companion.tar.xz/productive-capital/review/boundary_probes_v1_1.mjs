// Reviewer-authored corrective development controls; not held-out confirmation.
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {runProject,retainedParent,constructChild,childImpact} from '../companion_v1_1/capability.mjs';
const root=new URL('../',import.meta.url),out=new URL('./boundary-probes-v1_1/',import.meta.url);
mkdirSync(out,{recursive:true});
const copy=x=>JSON.parse(JSON.stringify(x));
const project=JSON.parse(readFileSync(new URL('data/development.json',root),'utf8'));
const initial=await runProject(project,{arm:'flywheel'}),previous=initial.state,cases=[];
async function record(name,body){
 let item;
 try{item=await body();}catch(e){item={passed:false,unexpected_error:e.message};}
 cases.push({case:name,...item});return item;
}
async function runChange(name,p,options={}){
 const {parent}=await retainedParent(p,previous),child=await constructChild(parent);
 const result=await runProject(p,{arm:'flywheel',previous,child,...options});
 writeFileSync(new URL(name+'.json',out),JSON.stringify({project:p,previous,result},null,2)+'\n');return result;
}
await record('path-only-change',async()=>{
 const p=copy(project);p.cycle=2;p.components[0].path='renamed-for-review/'+p.components[0].path;
 const r=await runChange('path-only-change',p);
 return {passed:r.assurance.components[0].path===p.components[0].path&&r.impact.changed.includes(p.components[0].id),changed:r.impact.changed,invalidated:r.impact.invalidated};
});
for(const arm of ['flywheel','conventional_cache'])await record('removed-leaf-'+arm,async()=>{
 const p=copy(project);p.cycle=2;const deleted=p.components.pop().id;
 const r=await runChange('removed-leaf-'+arm,p,{arm});
 return {passed:r.impact.removed.includes(deleted)&&!r.impact.invalidated.includes(deleted)&&!r.assurance.components.some(c=>c.id===deleted),removed:r.impact.removed,invalidated:r.impact.invalidated};
});
await record('cross-project-predecessor',async()=>{
 const p=copy(project);p.id='DIFFERENT_PROJECT';p.cycle=1;p.task.id='DIFFERENT_PROJECT-c1';
 try{await runProject(p,{arm:'flywheel',previous});return {passed:false,accepted:true};}catch(e){return {passed:e.message==='PARENT_PROJECT_BINDING',error:e.message};}
});
await record('foreign-child-construction-origin',async()=>{
 const unrelated=copy(project);unrelated.id='UNRELATED_CONSTRUCTION';unrelated.cycle=0;
 const prev=(await runProject(unrelated,{arm:'flywheel'})).state;unrelated.cycle=2;unrelated.components[0].content+='\n// unrelated change\n';
 const origin=await retainedParent(unrelated,prev),child=await constructChild(origin.parent);
 const p=copy(project);p.cycle=2;p.components[1].content+='\n// target change\n';
 const target=await retainedParent(p,previous);
 try{await childImpact(p,target.parent,previous,child);return {passed:false,accepted:true};}catch(e){return {passed:e.message==='CHILD_ORIGIN_BINDING',error:e.message};}
});
await record('same-project-wrong-construction-parent',async()=>{
 const a=copy(project);a.cycle=2;a.components[0].content+='\n// origin changed\n';
 const b=copy(project);b.cycle=2;b.components[1].content+='\n// other changed\n';
 const origin=await retainedParent(a,previous),child=await constructChild(origin.parent),target=await retainedParent(b,previous);
 try{await childImpact(b,target.parent,previous,child);return {passed:false,accepted:true};}catch(e){return {passed:e.message==='CHILD_CONSTRUCTION_PARENT_BINDING',error:e.message};}
});
await record('legitimate-child-second-use',async()=>{
 const p=copy(project);p.cycle=2;p.components[0].content+='\n// first child use\n';
 const origin=await retainedParent(p,previous),child=await constructChild(origin.parent),first=await runProject(p,{arm:'flywheel',previous,child});
 const next=copy(p);next.cycle=3;next.components[1].content+='\n// second child use\n';
 const second=await runProject(next,{arm:'flywheel',previous:first.state,child});
 writeFileSync(new URL('legitimate-child-second-use.json',out),JSON.stringify({project:next,previous:first.state,result:second,construction:{parent:origin.parent,child}},null,2)+'\n');
 return {passed:second.metrics.child_calls===1&&second.impact.child_digest===child.digest&&second.state.child_registry.origin_digest===child.parent_digest,origin_digest:child.parent_digest,use_digest:second.impact.parent_digest};
});
const result={scope:'REVIEWER_CORRECTIVE_DEVELOPMENT_ONLY',passed:cases.every(x=>x.passed),cases};
writeFileSync(new URL('summary.json',out),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
