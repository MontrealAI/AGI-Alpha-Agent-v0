# Source companion contents and exclusions

The complete companion should contain the paper/PDF, bibliography, editable figures and sources, standalone demonstration, current corrected and preserved original implementations, frozen protocols, source-linked assumptions, raw primary and corrective records, economic event ledger, original economic history ZIP, independent checker programs/reports, reproduction wrapper, requirements specification, and license/attribution files.

## Retain

- `companion/` original frozen source and `companion_v1_1/` corrected source, with distinct protocols/freezes.
- Every file named in the two experiment freezes and economic frozen-source records. Preserve exact bytes, line endings and filenames.
- `outputs/missions/`, `outputs/correction-confirmation/`, failed development receipts, run logs and `DEVELOPMENT_RECORD_LIMITS.md`.
- Economic raw `events.jsonl`, class/ledger/scenario outputs and manifest, plus `economics/history/initial_economics_v1.zip` and its manifest. Historical ZIPs are evidence, not redundant build output.
- Public predecessor records and available prior-paper source, with their original availability limits.
- Purpose-created scientific figures, including useful vector formats and figure PNGs.
- `LICENSES/`, `NOTICE.md`, top-level README, commercial scorecard and reproduction instructions.

## Exclude from the user-facing source archive

- Browser QA screenshots such as `demo/desktop*.png` and `demo/mobile*.png`. They are internal verification aids, not requested screenshot deliverables.
- PDF page render/contact-sheet images produced only for layout QA. Keep the actual scientific figures and finished PDF.
- `__pycache__/`, `.pyc`, `.pyo`, operating-system metadata, caches, temporary package directories and copied dependency binaries.
- LaTeX auxiliary files such as `.aux`, `.bbl`, `.blg`, `.fdb_latexmk`, `.fls`, `.synctex.gz`; retain the bibliography source and meaningful final build-verification record. Do not blanket-delete all `.log` files: raw experiment and failed-run logs are scientific evidence.
- The final complete companion ZIP and LaTeX ZIP from inside themselves. Including generated archives recursively creates an inflated or self-referential package. A final PDF and standalone HTML may be included as user deliverables.
- Git internals, unrelated source-audit checkouts, credentials, private user attachment transport identifiers, model weights and upstream proprietary scanner-rule bodies.

No exclusion may silently remove a file named by an immutable scientific manifest. If an otherwise excluded item is explicitly frozen evidence, resolve its role and record the packaging decision before changing contents. The packaging inventory should independently rehash every archived member and reject duplicate names, absolute paths, traversal paths or symlink entries.

## Provenance and interpretation checks

The inherited Jobs graph is generic scaffolding. Source identity checks do not grant authentication or settle a job. Literal inventories do not certify code safety, a plan does not execute a rollout, and all business demand/collections remain simulated. The standalone browser's vendor notices must accompany that standalone artifact, not only this archive.

Primary and corrected results must remain visibly separate. Replays use copies and never overwrite the historical record. The final economic source may differ from its first frozen engine only through the preserved initial archive and explicit corrective amendments. Source mappings and raw negative outcomes are retained so a reviewer can inspect those changes.
