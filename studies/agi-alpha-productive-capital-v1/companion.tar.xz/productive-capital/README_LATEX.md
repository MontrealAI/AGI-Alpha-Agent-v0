# Editable LaTeX source

The archive root is productive-capital/. Run a locally installed TeX toolchain
from paper/; this package performs no installation or network request.

```sh
cd productive-capital/paper
pdflatex -interaction=nonstopmode -halt-on-error main.tex
bibtex main
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex
```

main.tex, generated/*.tex, references.bib and all figure assets are editable.
The optional main_flattened.tex inlines generated fragments and the built
bibliography, so BibTeX is not needed to compile that frozen text. Figure PDFs
remain external and are included in figures/. It is not a single binary-asset
embedding or evidence that a passive publication importer has been run.

The Python figure/table generators require the complete research companion's
inputs; they are retained for editability, not presented as independently
self-contained in this smaller archive. BUILD_LOG.json and PRESENTATION_INPUTS.json
preserve publication provenance. ZIP timestamps are a fixed reproducibility
constant, not source creation times. LICENSES/ and NOTICE.md retain attribution.
