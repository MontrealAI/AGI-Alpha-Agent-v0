#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Package only the finite local study; no installs, network or publication.

Default: inspect and write a dry-run inventory. Building requires the exact
owner-confirmed final PDF hash. Timestamps are fixed ZIP metadata, not evidence
of source creation time. Identical inputs and Python/zlib yield identical ZIPs.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import tempfile
import zipfile
import zlib

ROOT = Path(__file__).resolve().parents[1]
ARC_ROOT = 'productive-capital/'
PDF = 'deliverables/AGI_ALPHA_Productive_Capital_Engine.pdf'
DEMO = 'deliverables/AGI_ALPHA_Productive_Capital_Demo.html'
NAMES = {
    'companion': 'AGI_ALPHA_Productive_Capital_Companion.zip',
    'latex': 'AGI_ALPHA_Productive_Capital_LaTeX.zip',
}
STAMP = (1980, 1, 1, 0, 0, 0)
GENERATED_REPORTS = {
    'publication/PACKAGING_DRY_RUN.json',
    'publication/PACKAGING_RESULT.json',
    'publication/main_flattened.tex',
}
PRUNED_PARTS = {
    '__pycache__', '.git', '.venv', 'venv', 'node_modules', '.cache',
    '.pytest_cache', 'reruns',
}
TEX_AUX = (
    '.aux', '.bbl', '.blg', '.log', '.out', '.toc', '.lof', '.lot',
    '.fdb_latexmk', '.fls', '.synctex.gz', '.nav', '.snm',
)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + '\n').encode()


def load(path):
    return json.loads((ROOT / path).read_text())


def safe_name(name):
    p = PurePosixPath(name)
    if not name or p.is_absolute() or '..' in p.parts or '\\' in name or '\x00' in name:
        raise ValueError('Unsafe archive name: ' + repr(name))
    return name


def excluded(path):
    parts = PurePosixPath(path).parts
    if any(part in PRUNED_PARTS for part in parts):
        return 'cache, dependency directory or unrelated repository internals'
    if path in GENERATED_REPORTS:
        return 'generated packaging report (prevents self-reference)'
    if path.startswith('publication/') and path != 'publication/package_study.py':
        return 'publication coordination or handoff receipt; deliberately outside this pre-handoff source package'
    if path.startswith('paper/render/'):
        return 'PDF layout QA image'
    if path.startswith('demo/') and path.lower().endswith(('.png', '.jpg', '.jpeg', '.webp', '.gif')):
        return 'browser QA image'
    if path == 'paper/main.pdf':
        return 'intermediate PDF; final approved PDF is included under deliverables/'
    if path.startswith('paper/') and path.endswith(TEX_AUX):
        return 'LaTeX auxiliary; bibliography source and build receipt retained'
    if path.endswith(('.pyc', '.pyo')) or parts[-1] == '.DS_Store':
        return 'runtime or operating-system cache'
    if path.startswith('deliverables/') and path.endswith('.zip'):
        return 'recursive deliverable archive'
    return None


def source_inventory():
    included, omitted = {}, []
    for directory, dirs, files in os.walk(ROOT, followlinks=False):
        base = Path(directory)
        # Symlinks must never be followed or silently placed in the archive.
        for name in list(dirs):
            p = base / name
            rel = p.relative_to(ROOT).as_posix()
            if p.is_symlink():
                raise ValueError('Symlink directory is not packageable: ' + rel)
            if name in PRUNED_PARTS or rel == 'paper/render':
                omitted.append({'path': rel + '/', 'reason': excluded(rel + '/_') or 'excluded directory'})
                dirs.remove(name)
        for name in sorted(files):
            p = base / name
            rel = safe_name(p.relative_to(ROOT).as_posix())
            if p.is_symlink():
                raise ValueError('Symlink file is not packageable: ' + rel)
            reason = excluded(rel)
            if reason:
                omitted.append({'path': rel, 'reason': reason})
                continue
            if not p.is_file():
                raise ValueError('Non-regular source file: ' + rel)
            data = p.read_bytes()
            included[rel] = {'data': data, 'origin': rel, 'sha256': digest(data)}
    return included, sorted(omitted, key=lambda item: item['path'])


def required_frozen_files(inventory):
    required = {}
    for manifest_path in ('protocol/experiment-FREEZE.json', 'protocol/experiment-v11-FREEZE.json'):
        for entry in load(manifest_path)['entries']:
            required[entry['path']] = entry['sha256']
    for manifest_path in ('protocol/economics_freeze.json', 'economics/FINAL_ECONOMICS_FREEZE.json'):
        required.update(load(manifest_path)['files'])
    bridge = load('protocol/economics_bridge_freeze.json')['files']
    original_engine = 'economics/run_economics.py'
    original_archive = 'economics/history/initial_economics_v1.zip'
    with zipfile.ZipFile(io.BytesIO(inventory[original_archive]['data'])) as historical:
        for path, expected in bridge.items():
            if path == original_engine and inventory[path]['sha256'] != expected:
                if digest(historical.read(path)) != expected:
                    raise ValueError('Original economic engine is not intact in its preserved archive')
                required[original_archive] = inventory[original_archive]['sha256']
            else:
                required[path] = expected
    for path, expected in required.items():
        if path not in inventory:
            raise ValueError('Packaging exclusion removed frozen evidence: ' + path)
        if inventory[path]['sha256'] != expected:
            raise ValueError('Frozen source/output hash mismatch: ' + path)
    return len(required)


def flattened_tex(inventory):
    dependencies = []

    def inline(path, stack=()):
        if path in stack:
            raise ValueError('Cyclic LaTeX input: ' + ' -> '.join(stack + (path,)))
        if path not in inventory:
            raise ValueError('Missing LaTeX source: ' + path)
        dependencies.append(path)
        source = inventory[path]['data'].decode('utf-8')

        def insert(match):
            name = match.group(1)
            if not PurePosixPath(name).suffix:
                name += '.tex'
            # TeX resolves these study inputs from the paper working directory.
            target = safe_name('paper/' + name)
            return '\n% BEGIN flattened source: ' + target + '\n' + inline(target, stack + (path,)) + '\n% END flattened source: ' + target + '\n'

        return re.sub(r'\\(?:input|include)\s*\{([^}]+)\}', insert, source)

    text = inline('paper/main.tex')
    bibliography = ROOT / 'paper/main.bbl'
    if not bibliography.is_file():
        raise ValueError('Built bibliography paper/main.bbl is required for flattened source')
    bbl = bibliography.read_text()
    text = re.sub(r'\\bibliographystyle\s*\{[^}]+\}', '% Bibliography rendered below; original .bib is included.', text)
    text, count = re.subn(r'\\bibliography\s*\{references\}', lambda _: '% BEGIN flattened bibliography\n' + bbl + '\n% END flattened bibliography', text)
    if count != 1:
        raise ValueError('Expected exactly one references bibliography')
    header = (
        '% Generated packaging convenience source; original main.tex remains authoritative.\n'
        '% All study input fragments and built bibliography are inlined.\n'
        '% Figure PDFs remain external assets in the accompanying figures/ directory.\n'
        '% Rebuild original bibliography from references.bib when editing references.\n'
    )
    return (header + text).encode(), {'inlined_sources': dependencies, 'bibliography_sha256': digest(bbl.encode()), 'external_assets': 'paper/figures/*'}


def latex_readme():
    return b'''# Editable LaTeX source\n\nThe archive root is productive-capital/. Run a locally installed TeX toolchain\nfrom paper/; this package performs no installation or network request.\n\n```sh\ncd productive-capital/paper\npdflatex -interaction=nonstopmode -halt-on-error main.tex\nbibtex main\npdflatex -interaction=nonstopmode -halt-on-error main.tex\npdflatex -interaction=nonstopmode -halt-on-error main.tex\n```\n\nmain.tex, generated/*.tex, references.bib and all figure assets are editable.\nThe optional main_flattened.tex inlines generated fragments and the built\nbibliography, so BibTeX is not needed to compile that frozen text. Figure PDFs\nremain external and are included in figures/. It is not a single binary-asset\nembedding or evidence that a passive publication importer has been run.\n\nThe Python figure/table generators require the complete research companion's\ninputs; they are retained for editability, not presented as independently\nself-contained in this smaller archive. BUILD_LOG.json and PRESENTATION_INPUTS.json\npreserve publication provenance. ZIP timestamps are a fixed reproducibility\nconstant, not source creation times. LICENSES/ and NOTICE.md retain attribution.\n'''


def member(path, data, origin):
    return {'data': data, 'origin': origin, 'sha256': digest(data)}


def archive_sets(inventory, flatten_data, flatten_provenance):
    companion = dict(inventory)
    companion['paper/main_flattened.tex'] = member('paper/main_flattened.tex', flatten_data, 'generated from existing paper sources and main.bbl')
    companion['README_LATEX.md'] = member('README_LATEX.md', latex_readme(), 'generated packaging instructions')
    latex = {p: entry for p, entry in companion.items() if p.startswith(('paper/', 'LICENSES/')) or p in ('NOTICE.md', 'README_LATEX.md')}
    groups = {'companion': companion, 'latex': latex}
    for kind, entries in groups.items():
        file_rows = [{'path': ARC_ROOT + path, 'bytes': len(entry['data']), 'sha256': entry['sha256'], 'origin': entry['origin']} for path, entry in sorted(entries.items())]
        manifest = {
            'schema': 'productive-capital-source-package/v1',
            'archive': NAMES[kind],
            'scope': kind,
            'fixed_zip_timestamp': list(STAMP),
            'timestamp_meaning': 'Reproducibility constant; not source creation or experiment time.',
            'python_version': sys.version.split()[0],
            'zlib_version': zlib.ZLIB_VERSION,
            'compression': 'ZIP_DEFLATED level 9',
            'publication_boundary': 'Finite package assembled before additive draft publication; later publication/handoff receipts remain separate.',
            'flattened_tex': flatten_provenance,
            'manifest_self_hash': 'Excluded to avoid circularity; external packaging result hashes every member including this manifest.',
            'files': file_rows,
        }
        path = kind.upper() + '_PACKAGE_MANIFEST.json'
        entries[path] = member(path, encoded(manifest), 'generated finite member inventory')
    return groups


def summarize(entries):
    rows = []
    total = 22  # End-of-central-directory record, without an archive comment.
    for path, entry in sorted(entries.items()):
        name = (ARC_ROOT + path).encode('utf-8')
        compressor = zlib.compressobj(9, zlib.DEFLATED, -15)
        compressed = len(compressor.compress(entry['data']) + compressor.flush())
        total += compressed + 30 + len(name) + 46 + len(name)
        rows.append({'path': ARC_ROOT + path, 'bytes': len(entry['data']), 'sha256': entry['sha256'], 'estimated_compressed_bytes': compressed})
    return {'file_count': len(rows), 'uncompressed_bytes': sum(r['bytes'] for r in rows), 'estimated_zip_bytes': total, 'estimate_limits': 'Raw DEFLATE plus ordinary ZIP headers; build verifies actual size and all member bytes. No ZIP is created by dry-run.', 'files': rows}


def write_archive(destination, entries):
    destination.parent.mkdir(parents=True, exist_ok=True)
    handle, temporary = tempfile.mkstemp(prefix=destination.stem + '-', suffix='.tmp', dir=destination.parent)
    os.close(handle)
    temporary = Path(temporary)
    try:
        with zipfile.ZipFile(temporary, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9, allowZip64=False) as archive:
            for path, entry in sorted(entries.items()):
                info = zipfile.ZipInfo(safe_name(ARC_ROOT + path), date_time=STAMP)
                info.create_system = 3
                executable = path.endswith(('.py', '.sh')) and (entry['data'].startswith(b'#!'))
                info.external_attr = (stat.S_IFREG | (0o755 if executable else 0o644)) << 16
                info.compress_type = zipfile.ZIP_DEFLATED
                archive.writestr(info, entry['data'], compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
        with zipfile.ZipFile(temporary) as archive:
            names = archive.namelist()
            if len(names) != len(set(names)) or len(names) != len(entries):
                raise ValueError('Duplicate or missing ZIP members')
            if archive.testzip() is not None:
                raise ValueError('ZIP CRC check failed')
            for info in archive.infolist():
                safe_name(info.filename)
                if stat.S_ISLNK(info.external_attr >> 16):
                    raise ValueError('Symlink ZIP entry')
                source = info.filename.removeprefix(ARC_ROOT)
                if digest(archive.read(info)) != entries[source]['sha256']:
                    raise ValueError('ZIP member hash mismatch: ' + info.filename)
        data_hash = digest(temporary.read_bytes())
        if destination.exists():
            if digest(destination.read_bytes()) != data_hash:
                raise ValueError('Refusing to replace a different archive; use a new --output-dir: ' + str(destination))
            temporary.unlink()
        else:
            temporary.replace(destination)
        return {'path': str(destination.relative_to(ROOT)) if destination.is_relative_to(ROOT) else str(destination), 'bytes': destination.stat().st_size, 'sha256': data_hash, 'verified_members': len(entries)}
    finally:
        if temporary.exists():
            temporary.unlink()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build', action='store_true', help='Create archives only after owner confirms final PDF and supplies its exact hash.')
    parser.add_argument('--final-pdf-sha256', help='Exact owner-confirmed final PDF SHA-256; mandatory for --build.')
    parser.add_argument('--output-dir', type=Path, default=ROOT / 'deliverables')
    args = parser.parse_args()
    inventory, omitted = source_inventory()
    frozen_count = required_frozen_files(inventory)
    if DEMO not in inventory:
        raise ValueError('Standalone demonstration missing')
    pending = []
    if PDF not in inventory:
        if args.build:
            raise ValueError('Final PDF is missing; archive creation is not authorized yet')
        candidate = ROOT / 'paper/main.pdf'
        if candidate.is_file():
            data = candidate.read_bytes()
            inventory[PDF] = member(PDF, data, 'PENDING: estimate from unapproved paper/main.pdf; not a final delivered PDF')
        pending.append({'path': PDF, 'status': 'NOT FINAL: owner confirmation and final copy required', 'size_estimate_source': 'paper/main.pdf' if candidate.is_file() else None})
    if args.build:
        if not args.final_pdf_sha256 or args.final_pdf_sha256 != inventory[PDF]['sha256']:
            raise ValueError('--build requires the exact owner-confirmed final PDF SHA-256')
        if not inventory[PDF]['data'].startswith(b'%PDF-'):
            raise ValueError('Final PDF does not have a PDF header')
    flatten_data, flatten_provenance = flattened_tex(inventory)
    groups = archive_sets(inventory, flatten_data, flatten_provenance)
    report = {
        'mode': 'BUILD' if args.build else 'DRY RUN; no ZIP created',
        'archive_root': ARC_ROOT,
        'required_frozen_file_count': frozen_count,
        'pending': pending,
        'exclusions': omitted,
        'packages': {kind: summarize(entries) for kind, entries in groups.items()},
        'limits': ['Compression reproducibility is scoped to the recorded Python/zlib versions.', 'Archive identity does not establish scientific correctness, paid demand or authority to execute production operations.'],
    }
    if args.build:
        report['final_pdf_sha256'] = args.final_pdf_sha256
        report['archives'] = {kind: write_archive(args.output_dir / NAMES[kind], entries) for kind, entries in groups.items()}
        (ROOT / 'publication/main_flattened.tex').write_bytes(flatten_data)
    target = ROOT / 'publication' / ('PACKAGING_RESULT.json' if args.build else 'PACKAGING_DRY_RUN.json')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(encoded(report))
    print(json.dumps({
        'mode': report['mode'], 'required_frozen_file_count': frozen_count, 'pending': pending,
        'packages': {kind: {key: value for key, value in summary.items() if key != 'files'} for kind, summary in report['packages'].items()},
        'archives': report.get('archives'), 'report': str(target.relative_to(ROOT)),
    }, indent=2))


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        print(json.dumps({'status': 'ERROR', 'type': type(error).__name__, 'message': str(error)}, indent=2), file=sys.stderr)
        raise SystemExit(1)
