import csv, hashlib, json
from pathlib import Path

root = Path(__file__).parent
expected = {
    'results/confirmation-v1/SUMMARY.json': '19c8ecb81dc6e3f0a15340489c5968533b42ad5b88908b411e73e0294daca0fa',
    'results/confirmation-v1/ARM_RESULTS.csv': '5453583e4f409a8390e16f00ae5de4f0da9e55e8467a17d116eaa8334331f9f1',
    'results/confirmation-v1/DIAGNOSTIC_SUMMARY.json': '38546b0a7c9b7d17ccb713ce46e7e5528acdc85f558090791aa625c5fa6a9f27',
    'history/HISTORICAL_VERIFICATION.json': '76d8e7ccb38bda049f6c93ad4008f1355844e996d81d3ff033fcc3bfcf2cc2a0',
    'history/HISTORICAL_EVIDENCE_STATUS.json': '922e2815755547ff12e4c11b11fd24b51f89c3766f2e839dca8cc5d978e4cb54',
    'history/current-exact-replay/EXECUTION.json': '40623f7760ecce9bfac73b4aa9a67602b4f0a4b28f376352a4ad290c3cd6ea66',
    'history/current-exact-replay/replay.log': 'ffcbbf235d09f7d177e75c50a51d58a1a63a6222835d64f31f5287649b1c6df3'
}
checks = []
for name, sha in expected.items():
    actual = hashlib.sha256((root / name).read_bytes()).hexdigest()
    checks.append({'name': name, 'test': 'previously published SHA-256', 'passed': actual == sha, 'actual': actual, 'expected': sha})
manifest = json.loads((root / 'source_manifest.json').read_text())
for r in manifest:
    b = (root / r['local_path']).read_bytes()
    checks.append({'name': r['local_path'], 'test': 'Git blob identity', 'passed': hashlib.sha1(('blob ' + str(len(b)) + '\0').encode() + b).hexdigest() == r['git_blob']})
summary = json.loads((root / 'results/confirmation-v1/SUMMARY.json').read_text())
rows = list(csv.DictReader((root / 'results/confirmation-v1/ARM_RESULTS.csv').open(newline='')))
for r in rows:
    s = next(a for a in summary['arms'] if a['budget'] == int(r['budget']) and a['arm'] == r['arm'])
    fields = ['streams', 'offered', 'attempted', 'valid', 'qualified', 'total_work', 'stopped', 'active_assets']
    for f in fields:
        checks.append({'name': str(s['budget']) + '/' + s['arm'] + '/' + f, 'test': 'CSV agrees with JSON', 'passed': int(r[f]) == s[f]})
    checks.append({'name': str(s['budget']) + '/' + s['arm'], 'test': 'subset counts', 'passed': 0 <= s['qualified'] <= s['valid'] <= s['attempted'] <= s['offered']})
    checks.append({'name': str(s['budget']) + '/' + s['arm'], 'test': 'mean and percentage arithmetic', 'passed': abs(s['mean_qualified'] * s['streams'] - s['qualified']) < 1e-9 and abs(s['coverage_percent'] - 100 * s['qualified'] / s['offered']) < 1e-9})
primary = {a['arm']: a for a in summary['arms'] if a['budget'] == 1000000}
assert {k: primary[k]['qualified'] for k in ['flywheel', 'learner', 'portfolio', 'workflow']} == {'flywheel': 517, 'learner': 517, 'portfolio': 591, 'workflow': 465}
hist = json.loads((root / 'history/HISTORICAL_VERIFICATION.json').read_text())
archive = json.loads((root / 'history/original-manifest-verification.json').read_text())
checks.append({'name': 'historical bundle manifest record', 'test': '62 internally matching reported rows; payload not available', 'passed': len(archive['files']) == 62 and all(x['matches'] and x['expected_sha256'] == x['actual_sha256'] for x in archive['files'])})
decisions = [x['decision'] for x in hist['attempts']]
checks.append({'name': 'historical six-attempt record', 'test': '3 promotions and 3 holds', 'passed': decisions.count('PROMOTED') == 3 and len(decisions) == 6 and hist['totals']['holds'] == 3})
checks.append({'name': 'historical sample arithmetic', 'test': '6*(3072+1536)=27648; times7=193536', 'passed': 6 * (3072 + 1536) == hist['totals']['committed_tasks_regenerated'] and 7 * hist['totals']['committed_tasks_regenerated'] == hist['totals']['stored_artifacts_semantically_checked']})
hi = {a['arm']: a for a in summary['arms'] if a['budget'] == 2000000}
diag = json.loads((root / 'results/confirmation-v1/DIAGNOSTIC_SUMMARY.json').read_text())
d = {g['treatment']: g for g in diag['groups']}
result = {'schema': 'productive-capital-prior-evidence-check/v1', 'source_commit': 'f836f06e8351e64db1da770e16e304b5feb01f28', 'passed': all(x['passed'] for x in checks), 'checks': checks,
    'primary_1m_qualified': {k: primary[k]['qualified'] for k in ['flywheel', 'learner', 'portfolio', 'workflow']}, 'offered_each': 864, 'primary_active_assets': primary['flywheel']['active_assets'],
    'flywheel_minus_workflow_per_stream': (517 - 465) / 12, 'portfolio_minus_flywheel_total': 591 - 517,
    '2m_flywheel_work_over_portfolio_percent': 100 * (hi['flywheel']['total_work'] / hi['portfolio']['total_work'] - 1),
    'diagnostic_inherited_saved_vs_exact_rebuild_percent': 100 * (1 - d['inherited']['mean_work'] / d['rebuild']['mean_work']),
    'diagnostic_inherited_vs_removed': {'qualified': [d['inherited']['qualified'], d['removed']['qualified']], 'work': [d['inherited']['mean_work'], d['removed']['mean_work']]},
    'original_docx_current_access': 'UNAVAILABLE: public tree explicitly excludes original; recorded original identity is not a new byte check',
    'original_62_payload_current_access': 'UNAVAILABLE: checked internal manifest record only, not payload bytes',
    'raw_trials_current_access': 'UNAVAILABLE: source tree says raw shards separately handed off; no public download claimed; direct trials.jsonl path404',
    'independence_limits': 'Same commission separate script; no producer code imported; checked hashes and summary arithmetic, not per-task predicate recomputation or historical execution'}
(root / 'VERIFICATION_CURRENT.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: v for k, v in result.items() if k != 'checks'}, indent=2))
raise SystemExit(0 if result['passed'] else 1)
