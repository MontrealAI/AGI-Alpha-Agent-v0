# SPDX-License-Identifier: Apache-2.0
"""Adverse accounting and counterfactual invariants."""

import unittest
from dataclasses import replace

from market import ARMS, Ledger, Parameters, Policy, run_world, validate_technical

FAMILIES = ["school", "supermarket", "outpatient", "water"]
TECH = {"by_family": {k: [True, False, True] for k in FAMILIES}, "development_forecast": {k: 2 / 3 for k in FAMILIES}}


class MarketTests(unittest.TestCase):
    def test_restricted_advance_is_not_revenue_or_operating_cash(self):
        ledger = Ledger(100)
        ledger.add(0, "deposit", 200, "restricted", mission="a")
        self.assertEqual((ledger.cash, ledger.available, ledger.revenue), (300, 100, 0))
        with self.assertRaises(ValueError):
            ledger.add(0, "expense", 101, "unfunded", "A")
        with self.assertRaises(ValueError):
            ledger.add(0, "deposit_release", 200, "premature", mission="a")

    def test_authorized_advance_stays_unearned_until_performance(self):
        ledger = Ledger(100)
        ledger.add(0, "deposit", 200, "restricted", mission="a")
        ledger.add(0, "deposit_activate", 200, "contract", mission="a")
        self.assertEqual((ledger.available, ledger.revenue, ledger.advances), (300, 0, 200))
        ledger.add(1, "expense", 150, "partial work", "A", "a")
        ledger.add(1, "deposit_release", 100, "accepted half", mission="a")
        ledger.add(1, "deposit_return", 100, "unperformed half", mission="a")
        self.assertEqual((ledger.cash, ledger.revenue, ledger.expenses, ledger.advances), (50, 100, 150, 0))

    def test_foundational_success_expected_and_prefunding_differ(self):
        self.assertEqual(4 * 300000 - 600000 - 4 * 75000, 300000)
        self.assertEqual(0.8 * (4 * 300000 - 4 * 75000) - 600000, 120000)
        self.assertEqual(600000 + 4 * 75000, 900000)

    def test_missing_technical_coverage_fails_closed(self):
        with self.assertRaises(ValueError):
            validate_technical({"by_family": {}, "development_forecast": {}})

    def test_unknown_forecast_is_explicit_prior_not_missing_success(self):
        tech = {"by_family": TECH["by_family"], "development_forecast": {k: None for k in FAMILIES}}
        validate_technical(tech)
        low = run_world(78, ARMS[3], Policy(0.8, 0.6, 4), replace(Parameters(), unmeasured_family_prior=0.01), tech)
        high = run_world(78, ARMS[3], Policy(0.8, 0.6, 4), replace(Parameters(), unmeasured_family_prior=0.9), tech)
        self.assertLessEqual(low["participation"], high["participation"])

    def test_library_and_network_have_identical_contents_and_trajectories(self):
        args = (Policy(0.8, 0.6, 4), Parameters(), TECH)
        a = run_world(19, ARMS[-1], *args)
        b = run_world(19, ARMS[-2], *args)
        a.pop("arm")
        b.pop("arm")
        self.assertEqual(a, b)

    def test_common_failure_has_no_outcome_collections(self):
        p = replace(Parameters(), common_failure_probability=1.0)
        row = run_world(34, ARMS[3], Policy(0.5, 0.6, 4), p, TECH)
        self.assertEqual(row["accepted"], 0)
        self.assertFalse(any(e["kind"] == "collection" for e in row["events"]))

    def test_full_settlement_and_capital_identity(self):
        for seed in range(10):
            for arm in ARMS:
                row = run_world(seed, arm, Policy(0.8, 0.6, 4), Parameters(), TECH)
                self.assertAlmostEqual(row["cash_cad"] - row["seed_capital_cad"], row["profit_cad"], places=2)
                self.assertEqual(row["obligations_cad"], 0)
                self.assertEqual(row["reserve_cad"], 0)
                self.assertTrue(all(e["cash_cad"] >= 0 for e in row["events"]))

    def test_seed_is_not_profit_and_zero_cash_stops(self):
        row = run_world(35, ARMS[3], Policy(0.8, 0.6, 4), replace(Parameters(), seed_capital=0), TECH)
        self.assertEqual((row["profit_cad"], row["accepted"], row["cash_cad"]), (0, 0, 0))

    def test_partial_delivery_refunds_unperformed_advances(self):
        p = replace(Parameters(), partial_development_probability=1.0, seed_capital=12000)
        row = run_world(2, ARMS[2], Policy(0.35, 0.6, 4), p, TECH)
        self.assertEqual(row["accepted"], 0)
        self.assertEqual(row["obligations_cad"], 0)
        self.assertTrue(all(e["kind"] != "collection" for e in row["events"]))


if __name__ == "__main__":
    unittest.main()
