# SPDX-License-Identifier: Apache-2.0
"""Prospective synthetic contract and cash experiment; no observed sales."""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import math
import random
import statistics
from dataclasses import asdict, dataclass, replace
from pathlib import Path
from typing import Any

HERE = Path(__file__).resolve().parent


def draw(seed: int, *parts: Any) -> random.Random:
    key = json.dumps([seed, *parts], sort_keys=True).encode()
    return random.Random(int.from_bytes(hashlib.sha256(key).digest()[:16], "big"))


def dollars(value: float) -> float:
    return round(value, 2)


@dataclass(frozen=True)
class Parameters:
    currency: str = "CAD"
    seed_capital: float = 1500.0
    cycles: int = 8
    prospects_per_cycle: int = 7
    common_build: float = 1800.0
    independent_build: float = 720.0
    water_adapter: float = 600.0
    adaptation: float = 150.0
    verification: float = 45.0
    support: float = 35.0
    retention: float = 120.0
    sharing_assessment: float = 80.0
    transfer: float = 25.0
    maintenance: float = 90.0
    exploration: float = 60.0
    quote_cost: float = 3.0
    common_failure_probability: float = 0.08
    local_failure_probability: float = 0.04
    default_probability: float = 0.035
    withdrawal_probability: float = 0.08
    partial_development_probability: float = 0.05
    collection_delay: int = 1
    capacity_per_cycle: int = 4
    buyer_value_multiplier: float = 1.0
    demand_multiplier: float = 1.0
    frontier_reconstruction_multiplier: float = 1.0
    rate_cad_per_hour: float = 135.0
    free_assistance_share: float = 0.24
    self_service_share: float = 0.35
    start_preexisting_capability: bool = False
    obsolescence_cycle: int = 5
    unmeasured_family_prior: float = 0.50


@dataclass(frozen=True)
class Policy:
    price_ratio: float
    development_fraction: float
    maximum_cohort: int


@dataclass(frozen=True)
class Arm:
    name: str
    technical: bool
    arrangement: bool
    retain: bool = False
    share: bool = False


ARMS = [
    Arm("independent_acceptance", False, False),
    Arm("instrument_only", True, False),
    Arm("arrangement_only", False, True),
    Arm("combined_no_retention", True, True),
    Arm("private_retention", True, True, True),
    Arm("selective_sharing", True, True, True, True),
    Arm("identical_library", True, True, True, True),
]


class Ledger:
    def __init__(self, seed_capital: float) -> None:
        self.events: list[dict[str, Any]] = []
        self.cash = dollars(seed_capital)
        self.seed = dollars(seed_capital)
        self.revenue = 0.0
        self.expenses = 0.0
        self.advances = 0.0
        self.restricted = 0.0
        self.reserve = 0.0
        self.receivable = 0.0
        self.add(0, "seed", seed_capital, "Initial capital is not revenue", mutate=False)

    @property
    def available(self) -> float:
        return dollars(self.cash - self.restricted - self.reserve)

    def add(
        self,
        week: int,
        kind: str,
        amount: float,
        reason: str,
        bucket: str | None = None,
        mission: str | None = None,
        mutate: bool = True,
    ) -> None:
        amount = dollars(amount)
        if amount < 0:
            raise ValueError("Negative transaction")
        if kind == "expense" and bucket not in ("A", "B", "C"):
            raise ValueError("Expense requires one disjoint bucket")
        if mutate:
            if kind == "expense":
                if amount > self.available + 0.01:
                    raise ValueError("Expense spends advances or reserves")
                self.cash -= amount
                self.expenses += amount
            elif kind == "deposit":
                self.cash += amount
                self.advances += amount
                self.restricted += amount
            elif kind == "deposit_activate":
                if amount > self.restricted + 0.01:
                    raise ValueError("Activation exceeds restricted advance")
                self.restricted -= amount
            elif kind == "deposit_release":
                if amount > self.advances - self.restricted + 0.01:
                    raise ValueError("Release exceeds activated unearned advance")
                self.advances -= amount
                self.revenue += amount
            elif kind == "deposit_return":
                if amount > self.advances + 0.01:
                    raise ValueError("Refund exceeds unearned advance")
                self.advances -= amount
                self.cash -= amount
                self.restricted = max(0.0, self.restricted - amount)
            elif kind == "collection":
                self.cash += amount
                self.revenue += amount
            elif kind == "refund":
                if amount > self.cash + 0.01:
                    raise ValueError("Unfunded refund")
                self.cash -= amount
                self.revenue -= amount
            elif kind == "reserve":
                if amount > self.cash - self.advances + 0.01:
                    raise ValueError("Reserve exceeds unrestricted cash")
                self.reserve = amount
            elif kind == "receivable":
                self.receivable += amount
            elif kind == "receivable_close":
                self.receivable -= amount
            else:
                raise ValueError(kind)
        for name in ("cash", "revenue", "expenses", "advances", "restricted", "reserve", "receivable"):
            setattr(self, name, dollars(getattr(self, name)))
        if self.cash < -0.01 or self.advances < -0.01 or self.receivable < -0.01:
            raise AssertionError("Invalid balance")
        if abs(self.cash - (self.seed + self.revenue - self.expenses + self.advances)) > 0.02:
            raise AssertionError("Cash identity failed")
        self.events.append(
            {
                "event_id": len(self.events),
                "week": week,
                "kind": kind,
                "amount_cad": amount,
                "bucket": bucket,
                "reason": reason,
                "mission": mission,
                "cash_cad": self.cash,
                "earned_collections_cad": self.revenue,
                "expenses_cad": self.expenses,
                "unearned_advances_cad": self.advances,
                "reserve_cad": self.reserve,
                "restricted_advances_cad": self.restricted,
                "available_cad": self.available,
                "receivable_cad": self.receivable,
            }
        )


def needs(seed: int, cycle: int, p: Parameters, technical: dict[str, Any]) -> list[dict[str, Any]]:
    rows = []
    count = int(p.prospects_per_cycle * p.demand_multiplier)
    for i in range(count):
        rng = draw(seed, "need", cycle, i)
        family = rng.choice(["school", "supermarket", "outpatient", "water", "heat_process"])
        hours = {"school": 7, "supermarket": 9, "outpatient": 10, "water": 12, "heat_process": 14}[family]
        reference = hours * p.rate_cad_per_hour
        value = reference * rng.uniform(1.0, 2.1) * p.buyer_value_multiplier
        deadline = rng.choice([1, 2, 3, 4])
        options = [
            {"name": "consultant_estimated_scope", "cost": reference, "delay": 2, "quality": 0.97, "effort": 2.0}
        ]
        if rng.random() < p.self_service_share:
            options.append(
                {"name": "free_REopt_plus_customer_effort", "cost": 0.0, "delay": 1, "quality": 0.88, "effort": 11.0}
            )
        if rng.random() < p.free_assistance_share:
            options.append(
                {"name": "eligible_CMAP_free_assistance", "cost": 0.0, "delay": 3, "quality": 0.95, "effort": 3.0}
            )
        raw_rate = technical["development_forecast"].get(family)
        technical_rate = p.unmeasured_family_prior if raw_rate is None else raw_rate
        outside = max(
            [0.0]
            + [
                technical_rate * x["quality"] * (value - x["cost"])
                - x["effort"] * 45
                - max(0, x["delay"] - deadline) * value * 0.25
                for x in options
            ]
        )
        rows.append(
            {
                "id": f"c{cycle}-n{i}",
                "family": family,
                "reference_price_cad": reference,
                "reference_estimated_hours": hours,
                "value_cad": dollars(value),
                "deadline": deadline,
                "outside_options": options,
                "outside_utility_cad": dollars(outside),
                "technical_forecast_basis": "assumed_unmeasured_prior"
                if raw_rate is None
                else "development_only_frequency",
                "rights_clear": rng.random() > 0.10,
                "modeling_scope_supported": family != "heat_process",
                "recipient": "origin.agent.agi.eth" if cycle < 3 else "recipient.agent.agi.eth",
            }
        )
    return rows


def participate(need: dict[str, Any], price: float, fraction: float, q: float, p: Parameters) -> tuple[bool, float]:
    delay = 1
    earned_fee_fraction = 1 - 0.5 * p.partial_development_probability
    utility = q * (need["value_cad"] - (1 - fraction) * price) - earned_fee_fraction * fraction * price
    utility -= 45 * 1.0 + max(0, delay - need["deadline"]) * need["value_cad"] * 0.25
    slack = dollars(utility - need["outside_utility_cad"])
    return slack >= 0, slack


def empirical_pass(seed: int, need: dict[str, Any], technical: dict[str, Any]) -> bool:
    records = technical["by_family"][need["family"]]
    return bool(records[draw(seed, "technical", need["id"]).randrange(len(records))])


def forecast(technical: dict[str, Any], family: str, p: Parameters) -> float:
    rate = technical["development_forecast"][family]
    rate = p.unmeasured_family_prior if rate is None else rate
    return (
        (1 - p.partial_development_probability)
        * (1 - p.common_failure_probability)
        * (1 - p.local_failure_probability)
        * rate
    )


def validate_technical(technical: dict[str, Any]) -> None:
    for family in ["school", "supermarket", "outpatient", "water"]:
        rows = technical.get("by_family", {}).get(family)
        rate = technical.get("development_forecast", {}).get(family)
        if not isinstance(rows, list) or not rows or any(type(x) is not bool for x in rows):
            raise ValueError("Missing/invalid actual technical coverage for " + family)
        if family not in technical.get("development_forecast", {}):
            raise ValueError("Missing development forecast field for " + family)
        if rate is not None and (not isinstance(rate, (int, float)) or not 0 <= rate <= 1):
            raise ValueError("Missing/invalid frozen development forecast for " + family)


def run_world(seed: int, arm: Arm, policy: Policy, p: Parameters, technical: dict[str, Any]) -> dict[str, Any]:
    ledger = Ledger(p.seed_capital)
    decisions: list[dict[str, Any]] = []
    retained: dict[str, set[str]] = {}
    pending: list[dict[str, Any]] = []
    accepted = attempted = participation = declined = unfinanceable = 0
    admitted = transfers = failures = defaults = withdrawals = 0
    min_available = ledger.available
    construction_count = 0
    for cycle in range(p.cycles + p.collection_delay + 2):
        week = cycle * 2
        for item in list(pending):
            if item["due"] != cycle:
                continue
            ledger.add(week, "receivable_close", item["amount"], "Resolve due outcome invoice", mission=item["id"])
            if item["default"]:
                defaults += 1
                decisions.append({"cycle": cycle, "kind": "default", "mission": item["id"], "amount": item["amount"]})
            else:
                ledger.add(week, "collection", item["amount"], "Accepted outcome invoice collected", mission=item["id"])
            pending.remove(item)
        if cycle >= p.cycles:
            continue
        batch = needs(seed, cycle, p, technical)
        recipient = batch[0]["recipient"] if batch else "origin.agent.agi.eth"
        if cycle == p.obsolescence_cycle:
            retained.clear()
            decisions.append(
                {"cycle": cycle, "kind": "invalidate", "reason": "Declared dependency/mission shift; requalify"}
            )
        if p.start_preexisting_capability:
            retained[recipient] = {"electric", "water"}
        if arm.retain and retained and cycle % 2 == 0:
            if ledger.available < p.maintenance:
                retained.clear()
            else:
                ledger.add(week, "expense", p.maintenance, "Optional retained capability upkeep", "B")
        offers = []
        for need in batch:
            if ledger.available < p.quote_cost:
                decisions.append({"cycle": cycle, "kind": "preserve_cash", "mission": need["id"]})
                continue
            ledger.add(week, "expense", p.quote_cost, "Scope and outside-option screening", "A", need["id"])
            if not need["modeling_scope_supported"] or (arm.technical and not need["rights_clear"]):
                declined += 1
                decisions.append({"cycle": cycle, "kind": "decline_scope_or_rights", "mission": need["id"]})
                continue
            price = dollars(policy.price_ratio * need["reference_price_cad"])
            fraction = policy.development_fraction if arm.arrangement else 0.0
            q = forecast(technical, need["family"], p)
            okay, slack = participate(need, price, fraction, q, p)
            if okay:
                participation += 1
                offers.append({**need, "price": price, "fraction": fraction, "participation_slack": slack})
            else:
                declined += 1
                decisions.append({"cycle": cycle, "kind": "buyer_declines", "mission": need["id"], "slack": slack})
        offers.sort(key=lambda x: (-x["price"], x["id"]))
        if not offers:
            continue
        survivors = []
        for offer in offers:
            if draw(seed, "withdraw", offer["id"]).random() < p.withdrawal_probability:
                withdrawals += 1
                decisions.append({"cycle": cycle, "kind": "precontract_withdrawal", "mission": offer["id"]})
            else:
                survivors.append(offer)
        offers = survivors
        if not offers:
            continue
        multiplier = p.frontier_reconstruction_multiplier
        choices = []
        for size in range(1, min(policy.maximum_cohort, p.capacity_per_cycle, len(offers)) + 1):
            for proposed in itertools.combinations(offers, size):
                modules = {"electric"} | ({"water"} if any(x["family"] == "water" for x in proposed) else set())
                owned = retained.get(recipient, set())
                missing = modules - owned
                independent = 0.0 if p.start_preexisting_capability else p.independent_build * multiplier * size
                common = p.common_build * multiplier if "electric" in missing else 0.0
                common += p.water_adapter * multiplier if "water" in missing else 0.0
                construction = common if arm.technical else independent
                supplied = set().union(*(v for k, v in retained.items() if k != recipient)) if retained else set()
                inherited = missing & supplied if arm.share else set()
                avoided = sum((p.common_build if m == "electric" else p.water_adapter) * multiplier for m in inherited)
                share_cost = (
                    p.sharing_assessment + p.transfer
                    if inherited and avoided > p.sharing_assessment + p.transfer
                    else 0.0
                )
                if not share_cost:
                    inherited = set()
                construction -= avoided if inherited else 0.0
                delivery = size * (p.adaptation + p.verification + p.support)
                total = dollars(construction + delivery + share_cost)
                fees = dollars(sum(dollars(x["price"] * x["fraction"]) for x in proposed))
                paid_stage = 1 - 0.5 * p.partial_development_probability
                expected = fees * paid_stage + sum(
                    forecast(technical, x["family"], p) * (1 - p.default_probability) * x["price"] * (1 - x["fraction"])
                    for x in proposed
                )
                expected -= (construction + delivery) * paid_stage + share_cost
                financeable = ledger.available + fees >= total and ledger.available >= share_cost
                choices.append(
                    (
                        financeable and expected > 0,
                        expected,
                        size,
                        list(proposed),
                        modules,
                        construction,
                        delivery,
                        fees,
                        financeable,
                        share_cost,
                        inherited,
                    )
                )
        choice = max(choices, key=lambda x: (x[0], x[1], x[2]))
        _, expected, _, offers, modules, construction, delivery, fees, financeable, share_cost, inherited = choice
        total = dollars(construction + delivery + share_cost)
        decision = {
            "cycle": cycle,
            "kind": "cohort",
            "missions": [x["id"] for x in offers],
            "recipient": recipient,
            "modules": sorted(modules),
            "construction_cad": dollars(construction),
            "delivery_cad": dollars(delivery),
            "development_fees_cad": fees,
            "candidate_coalitions_evaluated": len(choices),
            "sharing_cost_cad": share_cost,
            "expected_contribution_cad": dollars(expected),
            "financeable": financeable,
            "minimum_participation_slack_cad": min(x["participation_slack"] for x in offers),
            "source_of_engineering_costs": "explicit scenario assumptions, not observed costs",
        }
        decisions.append(decision)
        if expected <= 0 or not financeable:
            unfinanceable += int(expected > 0 and not financeable)
            decision["action"] = "reject_unprofitable" if expected <= 0 else "hold_liquidity"
            continue
        decision["action"] = "perform"
        if share_cost:
            ledger.add(week, "expense", p.sharing_assessment, "Fresh prospective recipient assessment", "B")
            ledger.add(week, "expense", p.transfer, "Authenticated fixture access and executable transfer", "B")
            retained[recipient] = retained.get(recipient, set()) | inherited
            transfers += 1
        for offer in offers:
            fee = dollars(offer["price"] * offer["fraction"])
            if fee:
                ledger.add(
                    week,
                    "deposit",
                    fee,
                    "Conditional advance; refundable until scope/quorum accepted",
                    mission=offer["id"],
                )
        for offer in offers:
            fee = dollars(offer["price"] * offer["fraction"])
            if fee:
                ledger.add(
                    week,
                    "deposit_activate",
                    fee,
                    "Quorum and signed risk-bearing development contract authorize production use; still unearned",
                    mission=offer["id"],
                )
        partial = draw(seed, "partial_development", cycle).random() < p.partial_development_probability
        stage_fraction = 0.5 if partial else 1.0
        if construction:
            ledger.add(
                week,
                "expense",
                construction * stage_fraction,
                "Construction required by contracted original outcomes",
                "A",
            )
            construction_count += 1
        common_failed = draw(seed, "common_failure", cycle).random() < p.common_failure_probability
        attempted += len(offers)
        successful_modules: set[str] = set()
        for offer in offers:
            mission = offer["id"]
            for cost, reason in [
                (p.adaptation, "Customer-specific adaptation including outcome-required learning"),
                (p.verification, "Fresh original-purpose verification"),
                (p.support, "Failure handling and support cost, paid for every attempt"),
            ]:
                ledger.add(week + 1, "expense", cost * stage_fraction, reason, "A", mission)
            fee = dollars(offer["price"] * offer["fraction"])
            earned_fee = dollars(fee * stage_fraction)
            if fee:
                ledger.add(
                    week + 1,
                    "deposit_release",
                    earned_fee,
                    "Performed development/adaptation service accepted; disclosed downstream qualification risk",
                    mission=mission,
                )
                if partial:
                    ledger.add(
                        week + 1,
                        "deposit_return",
                        fee - earned_fee,
                        "Unperformed half-stage advance returned; no fee for the missing work",
                        mission=mission,
                    )
            local_failed = draw(seed, "local_failure", mission).random() < p.local_failure_probability
            success = not partial and not common_failed and not local_failed and empirical_pass(seed, offer, technical)
            if success:
                accepted += 1
                successful_modules.add("electric")
                if offer["family"] == "water":
                    successful_modules.add("water")
                amount = dollars(offer["price"] - dollars(offer["price"] * offer["fraction"]))
                ledger.add(
                    week + 1, "receivable", amount, "Accepted outcome invoice; not cash or revenue", mission=mission
                )
                pending.append(
                    {
                        "id": mission,
                        "amount": amount,
                        "due": cycle + p.collection_delay,
                        "default": draw(seed, "default", mission).random() < p.default_probability,
                    }
                )
            else:
                failures += 1
            decisions.append(
                {
                    "cycle": cycle,
                    "kind": "delivery",
                    "mission": mission,
                    "accepted": success,
                    "common_failure": common_failed,
                    "local_failure": local_failed,
                    "partial_development": partial,
                    "measured_technical_case_pass": empirical_pass(seed, offer, technical),
                    "invoice_cad": amount if success else 0.0,
                    "price_cad": offer["price"],
                    "reference_cad": offer["reference_price_cad"],
                    "development_fee_at_risk_cad": dollars(offer["price"] * offer["fraction"]),
                }
            )
        if arm.retain and successful_modules - retained.get(recipient, set()):
            # A current-demand heuristic, not a lower bound on unknown future reuse.
            avoidable = p.independent_build * multiplier * max(0, len(offers) - 1)
            if avoidable > p.retention and ledger.available >= p.retention:
                ledger.add(
                    week + 1,
                    "expense",
                    p.retention,
                    "Optional rights-cleared packaging beyond the contracted deliverables",
                    "B",
                )
                retained[recipient] = retained.get(recipient, set()) | successful_modules
                admitted += 1
        reserve = min(ledger.cash - ledger.advances, p.support * len(pending))
        ledger.add(week + 1, "reserve", reserve, "Committed outstanding invoice support reserve")
        min_available = min(min_available, ledger.available)
    ledger.add((p.cycles + p.collection_delay + 2) * 2, "reserve", 0.0, "All modeled support obligations completed")
    if pending or ledger.receivable or ledger.advances:
        raise AssertionError("Settlement horizon incomplete")
    return {
        "seed": seed,
        "arm": arm.name,
        "policy": asdict(policy),
        "profit_cad": dollars(ledger.revenue - ledger.expenses),
        "collections_cad": ledger.revenue,
        "expenses_cad": ledger.expenses,
        "cash_cad": ledger.cash,
        "seed_capital_cad": ledger.seed,
        "reserve_cad": ledger.reserve,
        "available_cad": ledger.available,
        "obligations_cad": ledger.advances,
        "accepted": accepted,
        "attempted": attempted,
        "participation": participation,
        "declined": declined,
        "liquidity_holds": unfinanceable,
        "admissions": admitted,
        "transfers": transfers,
        "failures": failures,
        "defaults": defaults,
        "withdrawals": withdrawals,
        "construction_campaigns": construction_count,
        "min_available_cad": min_available,
        "events": ledger.events,
        "decisions": decisions,
    }


def summarize(rows: list[dict[str, Any]]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for arm in sorted({x["arm"] for x in rows}):
        group = [x for x in rows if x["arm"] == arm]
        profits = [x["profit_cad"] for x in group]
        out[arm] = {
            "n": len(group),
            "mean_profit_cad": dollars(statistics.mean(profits)),
            "median_profit_cad": dollars(statistics.median(profits)),
            "negative_worlds": sum(x < 0 for x in profits),
            "mean_accepted": statistics.mean(x["accepted"] for x in group),
            "mean_collections_cad": dollars(statistics.mean(x["collections_cad"] for x in group)),
            "mean_expenses_cad": dollars(statistics.mean(x["expenses_cad"] for x in group)),
            "mean_end_cash_cad": dollars(statistics.mean(x["cash_cad"] for x in group)),
            "mean_available_cad": dollars(statistics.mean(x["available_cad"] for x in group)),
            "mean_liquidity_holds": statistics.mean(x["liquidity_holds"] for x in group),
            "mean_transfers": statistics.mean(x["transfers"] for x in group),
            "mean_admissions": statistics.mean(x["admissions"] for x in group),
        }
    return out


def paired(rows: list[dict[str, Any]], first: str, second: str) -> dict[str, Any]:
    a = {x["seed"]: x["profit_cad"] for x in rows if x["arm"] == first}
    b = {x["seed"]: x["profit_cad"] for x in rows if x["arm"] == second}
    ds = [a[s] - b[s] for s in sorted(a.keys() & b.keys())]
    mean = statistics.mean(ds)
    se = statistics.stdev(ds) / math.sqrt(len(ds)) if len(ds) > 1 else 0
    return {
        "comparison": first + " minus " + second,
        "n": len(ds),
        "mean_cad": dollars(mean),
        "monte_carlo_95_interval": [dollars(mean - 1.96 * se), dollars(mean + 1.96 * se)],
        "positive_worlds": sum(x > 0.01 for x in ds),
        "negative_worlds": sum(x < -0.01 for x in ds),
        "interpretation": "Simulation sampling uncertainty only; no validation of scenario assumptions",
    }


def write(path: Path, value: Any) -> None:
    path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", choices=["develop", "confirm"])
    parser.add_argument("--technical", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--freeze", type=Path)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    if args.technical is None:
        raise ValueError("Both phases require actual technical coverage and development-only forecasts")
    technical = json.loads(args.technical.read_text())
    validate_technical(technical)
    p = Parameters()
    if args.phase == "develop":
        search = []
        policies = {}
        for arm in ARMS:
            best = None
            for price, fraction, cohort in itertools.product(
                [0.35, 0.50, 0.65, 0.80, 0.95, 1.10], [0.0, 0.2, 0.4, 0.6], [2, 4]
            ):
                if not arm.arrangement and fraction:
                    continue
                policy = Policy(price, fraction, cohort)
                rows = [run_world(s, arm, policy, p, technical) for s in range(1100, 1116)]
                score = statistics.mean(x["profit_cad"] for x in rows)
                search.append(
                    {"arm": arm.name, "policy": asdict(policy), "development_mean_profit_cad": dollars(score)}
                )
                key = (score, -fraction, -cohort, -price)
                if best is None or key > best[0]:
                    best = (key, policy)
            assert best is not None
            policies[arm.name] = asdict(best[1])
        write(args.out / "policy_search.json", search)
        freeze = {
            "schema": "economic-construction-policy/v3",
            "parameters": asdict(p),
            "policies": policies,
            "development_seeds": [1100, 1115],
            "confirmation_seeds": [900100, 900227],
            "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "technical_input_sha256": hashlib.sha256(json.dumps(technical, sort_keys=True).encode()).hexdigest(),
            "source_evidence": "economic parameter values explicitly assumed; H rate sourced separately",
            "stresses": {
                "thin_demand": {"demand_multiplier": 0.45},
                "free_tools_and_assistance": {"self_service_share": 1.0, "free_assistance_share": 0.75},
                "expensive_construction": {"common_build": 7200.0, "independent_build": 2880.0},
                "cheap_frontier_reconstruction": {"frontier_reconstruction_multiplier": 0.10},
                "already_equipped": {"start_preexisting_capability": True},
                "common_failure": {"common_failure_probability": 0.35},
                "slow_defaulting_payments": {"collection_delay": 3, "default_probability": 0.20},
                "no_seed": {"seed_capital": 0.0},
                "ample_seed": {"seed_capital": 12000.0},
                "capacity_one": {"capacity_per_cycle": 1},
                "weak_value": {"buyer_value_multiplier": 0.55},
                "high_withdrawal": {"withdrawal_probability": 0.40},
                "pessimistic_unseen_scope": {"unmeasured_family_prior": 0.10},
                "high_transfer_cost": {"sharing_assessment": 1200.0, "transfer": 600.0},
                "lower_complete_delivery_cost": {
                    "common_build": 500.0,
                    "independent_build": 180.0,
                    "adaptation": 60.0,
                    "verification": 15.0,
                    "support": 20.0,
                    "retention": 40.0,
                    "sharing_assessment": 40.0,
                    "transfer": 10.0,
                },
                "lower_cost_and_thin_cash": {
                    "common_build": 500.0,
                    "independent_build": 180.0,
                    "adaptation": 60.0,
                    "verification": 15.0,
                    "support": 20.0,
                    "retention": 40.0,
                    "sharing_assessment": 40.0,
                    "transfer": 10.0,
                    "seed_capital": 250.0,
                },
            },
        }
        write(args.out / "FREEZE.json", freeze)
        print(json.dumps({"phase": "develop", "policies": policies, "search_rows": len(search)}))
    else:
        if args.freeze is None or args.technical is None:
            raise ValueError("Confirmation requires frozen policy and measured technical input")
        freeze = json.loads(args.freeze.read_text())
        if hashlib.sha256(Path(__file__).read_bytes()).hexdigest() != freeze["source_sha256"]:
            raise ValueError("Source changed after freeze")
        p = Parameters(**freeze["parameters"])
        primary = []
        for arm in ARMS:
            policy = Policy(**freeze["policies"][arm.name])
            primary.extend(run_world(s, arm, policy, p, technical) for s in range(900100, 900228))
        write(args.out / "primary.json", primary)
        write(args.out / "summary.json", summarize(primary))
        contrasts = [
            paired(primary, a, b)
            for a, b in [
                ("selective_sharing", "private_retention"),
                ("combined_no_retention", "independent_acceptance"),
                ("instrument_only", "independent_acceptance"),
                ("arrangement_only", "independent_acceptance"),
                ("identical_library", "selective_sharing"),
            ]
        ]
        write(args.out / "contrasts.json", contrasts)
        stress = {}
        stress_full = []
        for name, changes in freeze["stresses"].items():
            scenario = replace(p, **changes)
            rows = [
                run_world(s, arm, Policy(**freeze["policies"][arm.name]), scenario, technical)
                for arm in ARMS
                for s in range(910100, 910148)
            ]
            stress[name] = {
                "parameters": changes,
                "summary": summarize(rows),
                "sharing_minus_private": paired(rows, "selective_sharing", "private_retention"),
            }
            stress_full.extend({"stress": name, **x} for x in rows)
        write(args.out / "stress_summary.json", stress)
        write(args.out / "stress_full.json", stress_full)
        # Exact same-content library control uses identical world draws and execution.
        controls = []
        for seed in range(900100, 900228):
            pair = [
                {k: v for k, v in x.items() if k != "arm"}
                for x in primary
                if x["seed"] == seed and x["arm"] in {"selective_sharing", "identical_library"}
            ]
            controls.append(pair[0] == pair[1])
        write(
            args.out / "COMPLETE.json",
            {
                "primary_histories": len(primary),
                "stress_histories": len(stress_full),
                "ordinary_library_exact_trajectory_parity": all(controls),
                "actual_customer_revenue": 0,
                "all_economics": "SIMULATED_CAD",
                "technical_input": str(args.technical.name),
                "technical_sha256": hashlib.sha256(args.technical.read_bytes()).hexdigest(),
                "freeze_sha256": hashlib.sha256(args.freeze.read_bytes()).hexdigest(),
            },
        )
        print(
            json.dumps(
                {
                    "phase": "confirm",
                    "primary": len(primary),
                    "stress": len(stress_full),
                    "library_parity": all(controls),
                    "summary": summarize(primary),
                }
            )
        )


if __name__ == "__main__":
    main()
