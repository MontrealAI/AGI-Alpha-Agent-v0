# Historical engineering fixture: purpose-preserving microgrid qualification

**Edition status:** Preserved as a historical fixture after user steering. It is
not the flagship Blue Sky opportunity; no new microgrid tasks or scenarios will
be added to recover a favorable narrative.

This additive study constructs and transfers an inspectable engineering decision
instrument. It does **not** establish a new optimization algorithm, a deployed
microgrid, autonomous market discovery, or an improvement over REopt. The main
learned candidate failed its admission rule. All original results and that failure
are retained.

## What was constructed

`instrument.py` compiles explicit hourly useful-service obligations into a sparse
linear program and solves it using SciPy's established HiGHS interface. A common
capacity design must support every supplied outage scenario. Dispatch can vary by
scenario. `verifier.py` separately recomputes electricity balance, battery state,
water delivery, tank state, equipment limits, fuel use, terminal reserves, capital
cost and the original acceptance decision from the mission and returned plan.

The reusable package consists of executable construction code, the separate
verifier, `mission_schema.json`, a versioned artifact, dependencies and evidence.
It gives a recipient a working interface rather than just a prose description.
The experiment supplies the domain, need classes, physical primitives, candidate
grammar, objective, scenario generator and acceptance distribution. The assistant
constructed their executable realization. Neither the common structure nor the
beneficiaries were autonomously discovered in an open market.

The supplied needs are school/shelter electricity, supermarket critical
electricity, outpatient-facility electrical continuity and hourly water delivery
with a tank reserve. These are independently motivated purpose classes, not
observed buyers. Clinical outcomes, food-temperature compliance and drinking-water
quality are outside the model. Electric load is only a proxy for useful service in
the first three classes; water delivery has an explicit service-state equation.

## Reproduce without overwriting the edition

Run from the repository root with Python 3.11–3.13, NumPy 2.3.2 and SciPy 1.17.0.
The original execution used Python 3.12.14. Choose a fresh result directory; the
runner refuses to overwrite an existing `freeze.json`.

```sh
python3 studies/agi-alpha-economic-construction-v3/technical/run_study.py \
  --out /tmp/agi-alpha-v3-reproduction
python3 -m unittest discover \
  -s studies/agi-alpha-economic-construction-v3/technical \
  -p 'test_*.py' -v
```

Use the exact transferred artifact against a current mission:

```sh
python3 studies/agi-alpha-economic-construction-v3/technical/instrument.py \
  --artifact studies/agi-alpha-economic-construction-v3/technical/results/artifact.json \
  --mission studies/agi-alpha-economic-construction-v3/technical/results/fresh_recipient_mission.json \
  --out /tmp/agi-alpha-fresh-water-receipt.json
```

An unsuccessful plan acceptance is a normal possible output. Inspect
`verification.physical_pass`, `verification.budget_pass`,
`verification.deadline_pass` and `accepted` separately. A successful process exit
does not turn a rejected offering into an accepted one. The CLI's source-hash
check requires the artifact's exact instrument, verifier and schema alongside it.
The integration runner elsewhere in this study transports those bytes into a
fresh process and checks current authorization separately.

`audit_certificates.py --results PATH` adds numerical primal/dual evidence for
the existing confirmation receipts and a `fresh_recipient_reference.json` in
that result directory. Its first edition was added after confirmation; it does
not select a method or new task. To reproduce that audit in a fresh directory,
create the fresh reference using the CLI command above with its `--out` directed
to that directory, then invoke the auditor.

## Frozen experimental design

`protocol.json` and the six source identities in `results/source_freeze.json`
were frozen before confirmation. Twelve development jobs used seeds 31000–31011,
school and supermarket purposes, horizons of 24/48/72 hours and 6/8/10 scenarios.
Three supplied scenario-ordering policies were compared with `all_scenarios`.
The policy with the lowest aggregate processed sparse-matrix nonzero count among
correct, capex-equivalent candidates was selected. Admission required at least a
5% reduction against the established expert. This is a bounded policy search,
not a claim to have learned better open-ended invention.

The selected policy and original acceptance rules were frozen at
`2026-10-27T15:50:56.092034+00:00`. Thirty-six fresh confirmation jobs used seeds
73000–73035 and cycled across all four purposes. A separate water recipient,
seed 992713 with 48 hours and eight scenarios, was excluded from development and
confirmation. No seed or capital ceiling was changed after its result.

The **E** comparator receives the full service-storage formulation and solves
all scenarios together. **E+ candidate** receives the identical information,
constraints, capacity options and acceptance, with the selected ordering policy.
It starts with two scenarios, solves omitted scenarios at fixed common capacity,
and adds failing scenarios until all original scenarios pass. The smaller first
LP is not assumed to save total work. All separation solves are counted.

No H or U result is measured by this technical runner. Human-market comparisons
and ordinary-versus-expert model use require the separate evidence boundaries of
the wider study. The inflexible-pumping diagnostic is never substituted for E.

## Results, including the rejected candidate

| Development policy | Processed matrix nonzeros | Physical/capex parity | Admission |
|---|---:|---|---|
| Established E: all scenarios | 151,296 | Reference | Existing method |
| Energy first | 333,184 | Preserved | Rejected |
| Peak first | 383,936 | Preserved | Rejected |
| Two first | 253,120 | Preserved | Selected for confirmation; rejected for admission |

| Fresh confirmation | E | E+ candidate |
|---|---:|---:|
| Physically verified plans | 36/36 | 36/36 |
| Original full plan acceptance | 15/36 | 15/36 |
| Processed matrix nonzeros | 453,888 | 905,856 |
| Largest individual LP, variables | 5,066 | 2,536 |
| Recorded prepared-computation wall seconds, total | 2.8425 | 3.8630 |

Maximum paired capex difference was CAD 1.17e-10. The candidate therefore retains
quality but increases this workload proxy and the recorded total wall time. A
single local batch is not a robust estimate of customer turnaround, and nonzero
counts are neither total labor nor dollars. The policy remains
`research_admission: false` in the artifact. Its research transport does not grant
production admission or learned Alpha.

Development and confirmation must remain separate in economics:

| Purpose | Development plans accepted | Confirmation plans accepted | Development forecast evidence |
|---|---:|---:|---|
| School/shelter electricity | 6/6 | 7/9 | Small simulated sample only |
| Supermarket electricity | 0/6 | 1/9 | Small simulated sample only |
| Outpatient electrical continuity | No jobs | 3/9 | Unavailable |
| Water delivery | No jobs | 4/9 | Unavailable |

All these plans were physically valid under their supplied models. Original
acceptance additionally required the predeclared capital ceiling and 30-second
prepared-computation deadline. Unseen-family development forecasts are null in
`results/economics_empirical_by_family.json`; confirmation outcomes must not be
read backward into a prospective sales policy. A human or other solver faces the
same physical/capital feasibility restrictions. Engineering execution reliability
cannot make an impossible-within-model budget feasible.

## Transformation witness: service storage changes one feasibility decision

The useful purpose of `water-73003` is to deliver every hourly water obligation
in six 24-hour scenarios while also meeting the original electricity demand,
equipment limits, fuel limit and battery/tank reserve constraints, under a
CAD 120,000 capital ceiling. The alternative may not reduce delivered water or
borrow from the terminal tank.

The restrictive representation requires contemporaneous pumping to equal each
hour's delivery. That restriction is removable when a real storage tank can hold
water produced earlier. The replacement retains hourly water service through

`tank[t+1] = tank[t] + pump_conversion * pump[t] - delivered_water[t]`,

with explicit tank capacity, minimum reserve and initial/terminal state. This is
established engineering modeling, supplied here as a transformation diagnostic.
The executable instrument constructs both representations against the same
original mission digest.

| Evidence for water-73003 | Inflexible pumping | Service storage |
|---|---:|---:|
| Feasible plan capex, CAD | 137,825.040356 | 113,612.177498 |
| Numerically audited lower bound, CAD | 137,825.040256 | 113,612.177398 |
| Original capital ceiling, CAD | 120,000 | 120,000 |
| Original full plan acceptance | False | True |

The inflexible formulation's lower bound exceeds the ceiling; the tank-aware
plan satisfies the original purpose below it. This is one crossing among nine
predeclared water confirmation jobs. Three other water jobs already accepted
both formulations; five accepted neither. E already possesses the tank-aware
formulation, so this crossing is **not additional learned Alpha against E**.

The claim is falsified if any original hourly service or reserve constraint fails,
if the restrictive formulation has a qualifying lower-cost design within the
same model, if the replacement requires an unavailable tank or authority, or if
necessary omitted engineering costs erase the real-world crossing. The executable
witness is bounded to the supplied scenario/capacity/cost model. It is not a
field-construction authorization.

Witness files are the mission under `results/missions/water-73003.json`, the two
confirmation receipts ending `__E.json` and `__inflexible_diagnostic.json`, and
the corresponding files under `results/dual_certificates/`.

## Transfer that preserves a negative result

An accepted donor electricity job is `school-31000`, with modeled capex
CAD 62,187.813511. Its development receipts preserve both E and candidate outputs.
The separate protected recipient is water-992713. The transferred candidate
constructs a physically valid plan at CAD 121,115.510646. The original recipient
ceiling is CAD 70,000, so its plan is rejected. The post-confirmation dual audit
gives a lower bound of CAD 121,115.510546: the budget failure is not merely a
failure to find a cheaper solution of this LP.

The portable capability successfully handles a different purpose and supplies
inspectable evidence, but this recipient does not demonstrate newly feasible
accepted work. A separately contracted infeasibility report could be useful; it
is not silently substituted for the original accepted-plan contract. Runtime
qualification, transport, authority and current-purpose verification are separate
from that commercial acceptance. No real ENS membership or live authentication
is simulated into existence here.

## What the numerical certificate does

The post-confirmation auditor reconstructs the full frozen LP, obtains dual
multipliers, enforces the correct signs and checks the objective against the
original plan. It forms a lower bound using the dual objective plus a conservative
correction for the stationarity residual over finite implied variable bounds,
then subtracts a CAD 0.0001 numerical margin. All 81 confirmation receipts and the
one protected recipient passed; the largest primal–bound gap was
CAD 0.00010000114. The independent physical verifier is also rerun.

This is a floating-point numerical audit with recorded multipliers, not an exact
rational proof. Its matrices come from the frozen compiler, so a shared
formulation omission is still possible. The separate physical verifier checks
the realized original-purpose service; it cannot certify omitted real-world
requirements. Audit work is additional assessment, not part of the original
prepared-computation timings. Its original run was not separately timed; no zero
audit-cost claim is made. See `results/post_confirmation_audit.json` for the
source and evidence identities.

## Data, assumptions and conventional methods

Three exact normalized hourly load-profile files are copied from
[REopt.jl](https://github.com/NatLabRockies/REopt.jl) commit
`4227bf1755280c6febd07a8f2ac575689f611ccb`: Chicago PrimarySchool, Supermarket and
Outpatient. Each has 8,760 values. These are sourced EnergyPlus archetype
simulations, not metered customer demand. `data/upstream_hashes.json` records exact
SHA-256 and Git blob identities. The upstream README, LICENSE and NOTICE are
retained. Windows are scaled and proxied by the researcher. School loads stand in
for shelter electricity; they are not measured shelter occupancy or demand.

PV/weather, water delivery, fuel availability, equipment capacities and capital
ceilings are seeded synthetic assumptions. Capacity unit prices are assumed CAD
1,600/kW PV; 300/kWh battery energy; 220/kW battery inverter; 1,000/kW generator;
500/kW pump; and 40/m³ tank. These are scenario parameters, not sourced quotations
or comprehensive installed costs. They omit many site, engineering, permitting,
replacement and operating costs. Initial and terminal energy/tank storage are
both 50%, with a 10% floor; the 1.6 m³/kWh pump conversion is also assumed.

The model uses scenario-specific perfect foresight, linear conversion and
hourly averaging. It does not establish a nonanticipative control policy,
three-phase or transient behavior, pump-start adequacy, hydraulic pressure,
refrigeration temperatures, clinical adequacy, permits or commissioned reliability.
Real deployment requires site data, additional engineering and the authorized
professional responsibilities of the applicable jurisdiction.

[REopt](https://reopt.nlr.gov/tool) is a strong existing free technical-economic
alternative. Its published capabilities include microgrid sizing and outage
resilience analysis. We did not run REopt, conceal its availability, or claim
superiority to it. Eligible organizations may also have a free outside option:
[DOE's May 2026 microgrid support program](https://www.energy.gov/oe/articles/applications-open-new-microgrid-support-services)
advertises up to 60 hours of assistance. Eligibility and scope must be checked
before pricing a real engagement.

Independent need motivation includes the [EPA power-resilience guide for water
utilities](https://www.epa.gov/waterresilience/power-resilience-guide-water-and-wastewater-utilities),
the [DOE microgrid overview](https://www.energy.gov/sites/default/files/2024-02/46060_DOE_GDO_Microgrid_Overview_Fact_Sheet_RELEASE_508.pdf),
and the [Rincon government-center microgrid project](https://www.energy.gov/sites/default/files/2023-12/Rincon-Government-Center-Microgrid-Project;-Rincon-Solar-Microgrid-Project.pdf).
Those sources motivate useful purposes and practical obligations; they do not
validate this experiment's prices, demand distribution or simulated acceptance.

## Identity, evidence and verification

The artifact file's raw-byte SHA-256 is
`7108a37db885ed9b1092653ce5a555f750ab7034fd2e971c7684e6cd5e526082`.
The technical runner records canonical JSON hashes inside its original receipts;
the CLI records the raw artifact-file hash. These are distinct declared
representations, not interchangeable hash claims. The original files remain
unchanged. Complete identities and source pins are in `results/freeze.json` and
the integration evidence.

Sixteen targeted instrument tests passed before confirmation. They exercise
energy/water creation, mission substitution, reserves, capacity/fuel limits,
nonfinite output, deadline/capital rejection, policy parity and artifact tampering.
Ruff formatting/lint and strict mypy passed on the four implementation modules.
The environment's Black import failed because its `pathspec` dependency was
missing; Ruff formatting was used. The full repository test suite was not run for
this isolated study. Post-confirmation certificate tests exercise the new audit
without altering any original source or result.

Buyer equipment capex is not enterprise delivery expense. Prepared solver time
excludes model usage, developer time, site interpretation, adaptation, customer
effort, assessment, support, maintenance and liability. Cash, opportunity cost,
paid delivery, additional retention/qualification and optional research must be
accounted for separately by the enterprise experiment. No customer collection,
earned profit, live token use, frontier-API experiment or specialist ASI result is
observed in this technical package.
