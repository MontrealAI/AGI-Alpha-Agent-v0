# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

import numpy as np
from scipy.optimize import linprog

from instrument import make_lp
from verifier import CAPACITIES, digest, verify


def certify(mission: dict[str, Any], receipt: dict[str, Any]) -> dict[str, Any]:
    indices = list(range(len(mission["scenarios"])))
    formulation = receipt["formulation"]
    c, a_ub, b_ub, a_eq, b_eq, bounds = make_lp(mission, indices, formulation)
    result = linprog(c, A_ub=a_ub, b_ub=b_ub, A_eq=a_eq, b_eq=b_eq, bounds=bounds, method="highs")
    if not result.success:
        return {"passed": False, "reason": "reconstruction solve did not return optimum"}
    y = np.minimum(0.0, result.ineqlin.marginals)
    z = result.eqlin.marginals
    dl = np.maximum(0.0, result.lower.marginals)
    du = np.minimum(0.0, result.upper.marginals)
    lo = np.array([0.0 if b[0] is None else b[0] for b in bounds])
    upper = [mission["capacity_bounds"][name][1] for name in CAPACITIES]
    h = mission["hours"]
    per_scenario = (
        [upper[0]] * h
        + [upper[3]] * h
        + [upper[2]] * h
        + [upper[2]] * h
        + [upper[4]] * h
        + [upper[1]] * (h + 1)
        + [upper[5]] * (h + 1)
    )
    implied_hi = np.array(upper + per_scenario * len(indices))
    explicit_hi = np.array([0.0 if b[1] is None else b[1] for b in bounds])
    du[np.array([b[1] is None for b in bounds])] = 0.0
    residual = c - a_ub.T @ y - a_eq.T @ z - dl - du
    dual_value = float(b_ub @ y + b_eq @ z + lo @ dl + explicit_hi @ du)
    conservative_bound = (
        dual_value + float(np.minimum(residual, 0) @ implied_hi + np.maximum(residual, 0) @ lo) - 0.0001
    )
    primal = float(c @ result.x)
    verdict = verify(mission, receipt)
    objective_agreement = abs(primal - receipt["capex_cad"]) <= 0.05
    passed = bool(
        verdict["physical_pass"]
        and objective_agreement
        and conservative_bound <= receipt["capex_cad"] + 1e-5
        and receipt["capex_cad"] - conservative_bound <= 0.05
    )
    return {
        "passed": passed,
        "mission_sha256": digest(mission),
        "purpose": mission["purpose"],
        "formulation": formulation,
        "primal_capex": primal,
        "conservative_dual_lower_bound": conservative_bound,
        "duality_gap": receipt["capex_cad"] - conservative_bound,
        "capex_ceiling": mission["acceptance"]["max_capex_cad"],
        "within_model_budget_infeasible": conservative_bound > mission["acceptance"]["max_capex_cad"],
        "stationarity_residual_max": float(max(abs(residual))),
        "multipliers": {"inequality": y.tolist(), "equality": z.tolist(), "lower": dl.tolist(), "upper": du.tolist()},
        "proof_scope": "Numerically audited LP lower bound with residual correction and CAD0.0001 margin; not a field impossibility proof.",
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", type=Path, default=Path(__file__).parent / "results")
    args = parser.parse_args()
    rows = []
    for path in sorted((args.results / "confirmation").glob("*.json")):
        receipt = json.loads(path.read_text())
        mission = json.loads((args.results / "missions" / (receipt["mission_id"] + ".json")).read_text())
        certificate = certify(mission, receipt)
        target = args.results / "dual_certificates" / path.name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(certificate, sort_keys=True, separators=(",", ":")) + "\n")
        rows.append({k: v for k, v in certificate.items() if k != "multipliers"})
    fresh = json.loads((args.results / "fresh_recipient_reference.json").read_text())
    mission = json.loads((args.results / "fresh_recipient_mission.json").read_text())
    certificate = certify(mission, fresh)
    (args.results / "fresh_recipient_dual_certificate.json").write_text(
        json.dumps(certificate, sort_keys=True, separators=(",", ":")) + "\n"
    )
    summary = {
        "confirmation_count": len(rows),
        "passed": sum(r["passed"] for r in rows),
        "max_duality_gap_cad": max(r["duality_gap"] for r in rows),
        "fresh_recipient": {k: v for k, v in certificate.items() if k != "multipliers"},
        "rows": rows,
        "audit_source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "scope": "Post-freeze independent numerical audit of unchanged original tasks; no new confirmation or tuning.",
    }
    (args.results / "certificate_audit_summary.json").write_text(json.dumps(summary, sort_keys=True, indent=2) + "\n")
    print(json.dumps({k: v for k, v in summary.items() if k != "rows"}, indent=2))


if __name__ == "__main__":
    main()
