# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import copy
import json
import tempfile
import unittest
from pathlib import Path

from instrument import run, verify_artifact
from missions import generate_mission
from verifier import digest, verify


class TestPurposeInstrument(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.electric = generate_mission(41001, "food", 24, 3)
        cls.water = generate_mission(41002, "water", 24, 3)
        cls.electric_receipt = run(cls.electric)
        cls.water_receipt = run(cls.water)

    def test_electric_and_water_physics(self):
        self.assertTrue(verify(self.electric, self.electric_receipt)["physical_pass"])
        self.assertTrue(verify(self.water, self.water_receipt)["physical_pass"])

    def test_price_budget_not_physics(self):
        m = copy.deepcopy(self.water)
        m["acceptance"]["max_capex_cad"] = 1
        r = copy.deepcopy(self.water_receipt)
        r["mission_sha256"] = digest(m)
        v = verify(m, r)
        self.assertTrue(v["physical_pass"])
        self.assertFalse(v["accepted"])

    def test_changed_purpose_cannot_reuse_receipt(self):
        m = copy.deepcopy(self.water)
        m["id"] += "-changed"
        self.assertFalse(verify(m, self.water_receipt)["physical_pass"])

    def test_old_electric_receipt_cannot_validate_water(self):
        self.assertFalse(verify(self.water, self.electric_receipt)["physical_pass"])

    def test_missing_scenario(self):
        r = copy.deepcopy(self.water_receipt)
        r["dispatch"].pop(next(iter(r["dispatch"])))
        self.assertFalse(verify(self.water, r)["physical_pass"])

    def test_cannot_borrow_terminal_tank(self):
        r = copy.deepcopy(self.water_receipt)
        r["dispatch"]["scenario-00"]["tank_m3"][-1] = -1
        self.assertFalse(verify(self.water, r)["physical_pass"])

    def test_unserved_water_rejected(self):
        r = copy.deepcopy(self.water_receipt)
        r["dispatch"]["scenario-00"]["pump_kw"][0] += 2
        self.assertFalse(verify(self.water, r)["physical_pass"])

    def test_energy_created_rejected(self):
        r = copy.deepcopy(self.electric_receipt)
        r["dispatch"]["scenario-00"]["discharge_kw"][0] += 3
        self.assertFalse(verify(self.electric, r)["physical_pass"])

    def test_nonfinite_output_rejected(self):
        r = copy.deepcopy(self.water_receipt)
        r["capacities"]["tank_m3"] = float("nan")
        self.assertFalse(verify(self.water, r)["physical_pass"])

    def test_impossible_generator_fuel_rejected(self):
        r = copy.deepcopy(self.electric_receipt)
        r["dispatch"]["scenario-00"]["generator_kw"] = [1000.0] * 24
        self.assertFalse(verify(self.electric, r)["physical_pass"])

    def test_policy_parity(self):
        for policy in ("energy_first", "peak_first", "two_first"):
            r = run(self.water, policy)
            self.assertTrue(r["verification"]["physical_pass"])
            self.assertAlmostEqual(r["capex_cad"], self.water_receipt["capex_cad"], places=2)

    def test_formulation_preserves_service(self):
        r = run(self.water, "all_scenarios", "inflexible_pumping")
        self.assertTrue(r["verification"]["physical_pass"])
        self.assertLessEqual(self.water_receipt["capex_cad"], r["capex_cad"] + 0.01)

    def test_tampered_implementation_refused(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "artifact.json"
            path.write_text(
                json.dumps({"schema": "microgrid-purpose-capability-v1", "source_sha256": {"instrument.py": "0" * 64}})
            )
            with self.assertRaises(ValueError):
                verify_artifact(path)

    def test_unknown_policy_refused(self):
        with self.assertRaises(ValueError):
            run(self.water, "skip_bad_scenarios")

    def test_nonfinite_mission_refused(self):
        m = copy.deepcopy(self.water)
        m["scenarios"][0]["load_kw"][0] = float("nan")
        with self.assertRaises(ValueError):
            run(m)

    def test_deadline_fail_is_not_physics_success(self):
        r = copy.deepcopy(self.water_receipt)
        r["stats"]["wall_seconds"] = 31
        v = verify(self.water, r)
        self.assertTrue(v["physical_pass"])
        self.assertFalse(v["accepted"])


if __name__ == "__main__":
    unittest.main()
