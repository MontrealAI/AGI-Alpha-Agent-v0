# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import copy
import json
import unittest
from pathlib import Path

from audit_certificates import certify

HERE = Path(__file__).parent / "results"


class CertificateTests(unittest.TestCase):
    def setUp(self) -> None:
        self.mission = json.loads((HERE / "missions" / "water-73003.json").read_text())
        self.storage = json.loads((HERE / "confirmation" / "water-73003__E.json").read_text())

    def test_original_crossing_has_lower_and_upper_witnesses(self) -> None:
        rigid = json.loads((HERE / "confirmation" / "water-73003__inflexible_diagnostic.json").read_text())
        lower = certify(self.mission, rigid)
        upper = certify(self.mission, self.storage)
        self.assertTrue(lower["passed"] and upper["passed"])
        self.assertGreater(lower["conservative_dual_lower_bound"], 120000)
        self.assertLess(upper["primal_capex"], 120000)

    def test_cost_tampering_is_rejected(self) -> None:
        changed = copy.deepcopy(self.storage)
        changed["capex_cad"] -= 1000
        self.assertFalse(certify(self.mission, changed)["passed"])

    def test_service_tampering_is_rejected(self) -> None:
        changed = copy.deepcopy(self.storage)
        first = next(iter(changed["dispatch"].values()))
        first["tank_m3"][2] += 1
        self.assertFalse(certify(self.mission, changed)["passed"])


if __name__ == "__main__":
    unittest.main()
