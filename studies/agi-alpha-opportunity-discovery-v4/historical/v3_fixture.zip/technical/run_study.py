# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import argparse
import hashlib
import json
import platform
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import scipy

from instrument import run
from missions import generate_mission
from verifier import digest, verify

HERE = Path(__file__).parent


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + "\n")


def row(mission: dict[str, Any], receipt: dict[str, Any], phase: str, configuration: str) -> dict[str, Any]:
    verdict, stats = receipt.get("verification", {}), receipt["stats"]
    return {
        "phase": phase,
        "mission_id": mission["id"],
        "kind": mission["kind"],
        "hours": mission["hours"],
        "scenarios": len(mission["scenarios"]),
        "configuration": configuration,
        "policy": receipt["policy"],
        "physical_pass": verdict.get("physical_pass", False),
        "budget_pass": verdict.get("budget_pass", False),
        "accepted": verdict.get("accepted", False),
        "capex_cad": receipt.get("capex_cad"),
        "capex_ceiling_cad": mission["acceptance"]["max_capex_cad"],
        "wall_seconds": stats["wall_seconds"],
        "cpu_seconds": stats.get("cpu_seconds"),
        "solves": stats.get("solve_count", len(stats["solves"])),
        "nonzeros_processed": stats.get("nonzeros_processed", sum(s["matrix_nonzeros"] for s in stats["solves"])),
        "max_variables": stats.get("max_variables", max(s["variables"] for s in stats["solves"])),
        "max_residual": verdict.get("max_residual"),
        "mission_sha256": digest(mission),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, default=HERE / "results")
    args = parser.parse_args()
    out = args.out
    protocol = json.loads((HERE / "protocol.json").read_text())
    if (out / "freeze.json").exists():
        raise RuntimeError("refusing to overwrite prior evidence; choose a fresh output path")
    out.mkdir(parents=True, exist_ok=True)
    source_files = {
        name: hashlib.sha256((HERE / name).read_bytes()).hexdigest()
        for name in (
            "instrument.py",
            "verifier.py",
            "mission_schema.json",
            "missions.py",
            "run_study.py",
            "protocol.json",
        )
    }
    write_json(
        out / "source_freeze.json",
        {
            "utc": datetime.now(timezone.utc).isoformat(),
            "files": source_files,
            "python": platform.python_version(),
            "numpy": np.__version__,
            "scipy": scipy.__version__,
        },
    )
    rows = []
    candidates = protocol["candidates"]
    scores = {policy: 0 for policy in ["all_scenarios"] + candidates}
    validity = {policy: True for policy in candidates}
    for i in range(protocol["development"]["count"]):
        p = protocol["development"]
        m = generate_mission(
            p["seed_start"] + i,
            p["kinds"][i % len(p["kinds"])],
            p["hours_cycle"][i % 3],
            p["scenario_count_cycle"][i % 3],
        )
        write_json(out / "missions" / (m["id"] + ".json"), m)
        baseline = None
        for policy in ["all_scenarios"] + candidates:
            receipt = run(m, policy)
            write_json(out / "development" / (m["id"] + "__" + policy + ".json"), receipt)
            r = row(m, receipt, "development", policy)
            rows.append(r)
            scores[policy] += r["nonzeros_processed"]
            if policy == "all_scenarios":
                baseline = receipt
            else:
                assert baseline is not None
                validity[policy] &= (
                    r["physical_pass"] and abs(receipt.get("capex_cad", 1e20) - baseline.get("capex_cad", 0)) < 0.05
                )
        print(json.dumps({"development": i + 1, "mission": m["id"]}), flush=True)
    eligible = [c for c in candidates if validity[c]]
    chosen = min(eligible, key=lambda x: scores[x]) if eligible else "all_scenarios"
    admitted = chosen != "all_scenarios" and scores[chosen] < 0.95 * scores["all_scenarios"]
    freeze = {
        "utc": datetime.now(timezone.utc).isoformat(),
        "source_files": source_files,
        "selected_candidate": chosen,
        "admitted_by_development_rule": admitted,
        "scores": scores,
        "validity": validity,
        "selection_status": "candidate retained for prospective test; not automatically admitted Alpha",
        "protocol_sha256": digest(protocol),
    }
    write_json(out / "freeze.json", freeze)
    artifact = {
        "schema": "microgrid-purpose-capability-v1",
        "version": "1.0.0",
        "policy": chosen,
        "formulation": "service_storage",
        "scope": ["critical_electricity", "water_delivery"],
        "source_sha256": {k: source_files[k] for k in ("instrument.py", "verifier.py", "mission_schema.json")},
        "dependencies": {"python": ">=3.11,<3.14", "numpy": np.__version__, "scipy": scipy.__version__},
        "rights": "Apache-2.0; upstream normalized archetypes retain LICENSE and NOTICE",
        "research_admission": admitted,
        "freeze_sha256": digest(freeze),
        "authority": "none; new mission authority and semantic acceptance are separately required",
    }
    write_json(out / "artifact.json", artifact)
    for i in range(protocol["confirmation"]["count"]):
        p = protocol["confirmation"]
        m = generate_mission(
            p["seed_start"] + i, p["kinds"][i % 4], p["hours_cycle"][i % 3], p["scenario_count_cycle"][i % 3]
        )
        write_json(out / "missions" / (m["id"] + ".json"), m)
        methods = [("E", "all_scenarios", "service_storage"), ("E_plus_candidate", chosen, "service_storage")]
        if i % 2:
            methods.reverse()
        if m["purpose"] == "water_delivery":
            methods.append(("inflexible_diagnostic", "all_scenarios", "inflexible_pumping"))
        for config, policy, formulation in methods:
            receipt = run(m, policy, formulation, digest(artifact))
            write_json(out / "confirmation" / (m["id"] + "__" + config + ".json"), receipt)
            rows.append(row(m, receipt, "confirmation", config))
        print(json.dumps({"confirmation": i + 1, "mission": m["id"]}), flush=True)
    recipient = protocol["fresh_recipient"]
    m = generate_mission(recipient["seed"], recipient["kind"], recipient["hours"], recipient["scenario_count"])
    write_json(out / "fresh_recipient_mission.json", m)
    write_json(out / "rows.json", rows)
    conf = [r for r in rows if r["phase"] == "confirmation"]
    summaries = {}
    for config in ("E", "E_plus_candidate", "inflexible_diagnostic"):
        selected = [r for r in conf if r["configuration"] == config]
        summaries[config] = {
            "n": len(selected),
            "physical_pass": sum(r["physical_pass"] for r in selected),
            "accepted": sum(r["accepted"] for r in selected),
            "total_wall_seconds": sum(r["wall_seconds"] for r in selected),
            "total_nonzeros_processed": sum(r["nonzeros_processed"] for r in selected),
            "max_lp_variables": max(r["max_variables"] for r in selected),
        }
    parity = []
    crossings = []
    for m_id in sorted({r["mission_id"] for r in conf}):
        pair = {r["configuration"]: r for r in conf if r["mission_id"] == m_id}
        parity.append(abs(pair["E"]["capex_cad"] - pair["E_plus_candidate"]["capex_cad"]))
        if "inflexible_diagnostic" in pair:
            a, b = pair["inflexible_diagnostic"], pair["E"]
            crossings.append(
                {
                    "mission_id": m_id,
                    "baseline_capex": a["capex_cad"],
                    "storage_capex": b["capex_cad"],
                    "ceiling": b["capex_ceiling_cad"],
                    "crossing": b["accepted"] and not a["accepted"],
                    "capex_saving": a["capex_cad"] - b["capex_cad"],
                }
            )
    summary = {
        "selection": freeze,
        "confirmation": summaries,
        "max_E_Eplus_capex_difference": max(parity),
        "formulation_diagnostic": crossings,
        "formulation_crossings": sum(x["crossing"] for x in crossings),
        "warning": "Computational and synthetic economic feasibility only; E has the same tank-aware formulation and is not beaten by that diagnostic.",
    }
    write_json(out / "summary.json", summary)
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == "__main__":
    main()
