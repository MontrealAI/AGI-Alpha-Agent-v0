# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np

from verifier import SCHEMA


def generate_mission(seed: int, kind: str = "school", hours: int = 48, scenario_count: int = 8) -> dict[str, Any]:
    if kind not in ("school", "food", "clinic", "water"):
        raise ValueError("unknown purpose fixture")
    rng = np.random.default_rng(seed)
    source = {"school": "PrimarySchool", "food": "Supermarket", "clinic": "Outpatient", "water": "PrimarySchool"}[kind]
    filename = f"crb8760_norm_Chicago_{source}.dat"
    annual = np.loadtxt(Path(__file__).parent / "data" / filename)
    start_hour = int(rng.integers(0, 365)) * 24
    window = annual[(np.arange(hours) + start_hour) % len(annual)]
    peak_kw = {"school": 28.0, "food": 42.0, "clinic": 32.0, "water": 6.0}[kind]
    scale = float(rng.uniform(0.8, 1.2))
    base = window / float(np.max(annual)) * peak_kw * scale
    scenarios = []
    for i in range(scenario_count):
        hour = np.arange(hours) % 24
        common_weather = float(rng.uniform(0.34, 0.90))
        daily_weather = rng.uniform(0.70, 1.08, (hours + 23) // 24)
        solar = np.maximum(0, np.sin((hour - 6) * np.pi / 12)) * common_weather * daily_weather[np.arange(hours) // 24]
        solar *= rng.uniform(0.88, 1.03, hours)
        solar = np.minimum(0.95, solar)
        load = base * float(rng.uniform(0.90, 1.12)) * rng.uniform(0.95, 1.05, hours)
        availability = np.ones(hours)
        if i % 3 == 2:
            begin = int(rng.integers(0, max(1, hours - 5)))
            availability[begin : begin + 5] = 0.4
        if kind == "water":
            water = 5.0 + 14.0 * np.exp(-(((hour - 8) / 2.0) ** 2)) + 16.0 * np.exp(-(((hour - 19) / 2.0) ** 2))
            water *= scale * float(rng.uniform(0.88, 1.15)) * rng.uniform(0.94, 1.06, hours)
        else:
            water = np.zeros(hours)
        scenarios.append(
            {
                "id": f"scenario-{i:02d}",
                "load_kw": load.round(8).tolist(),
                "pv_factor": solar.round(8).tolist(),
                "generator_availability": availability.tolist(),
                "water_demand_m3": water.round(8).tolist(),
                "generator_energy_limit_kwh": float(hours * (2.0 if kind == "water" else 5.0)),
            }
        )
    budget_index = int(rng.integers(0, 3))
    maximum = float([70000, 95000, 120000][budget_index] if kind == "water" else [120000, 180000, 240000][budget_index])
    bounds = {
        "pv_kw": [0, 400],
        "battery_kwh": [0, 4000],
        "battery_kw": [0, 150],
        "generator_kw": [0, 12 if kind == "water" else 25],
        "pump_kw": [0, 35 if kind == "water" else 0],
        "tank_m3": [0, 150 if kind == "water" else 0],
    }
    return {
        "schema": SCHEMA,
        "id": f"{kind}-{seed}",
        "purpose": "water_delivery" if kind == "water" else "critical_electricity",
        "kind": kind,
        "seed": seed,
        "hours": hours,
        "dt_hours": 1.0,
        "scenarios": scenarios,
        "capacity_bounds": bounds,
        "capex_cad": {
            "pv_kw": 1600.0,
            "battery_kwh": 300.0,
            "battery_kw": 220.0,
            "generator_kw": 1000.0,
            "pump_kw": 500.0,
            "tank_m3": 40.0,
        },
        "physics": {
            "eta_charge": 0.94,
            "eta_discharge": 0.94,
            "soc_initial_fraction": 0.50,
            "soc_terminal_fraction": 0.50,
            "soc_min_fraction": 0.10,
            "pump_m3_per_kwh": 1.6,
            "tank_initial_fraction": 0.50,
            "tank_terminal_fraction": 0.50,
            "tank_min_fraction": 0.10,
        },
        "acceptance": {"max_capex_cad": maximum, "max_compute_seconds": 30.0},
        "provenance": {
            "load_archetype": filename,
            "upstream_sha": "4227bf1755280c6febd07a8f2ac575689f611ccb",
            "load_status": "sourced EnergyPlus simulated normalized archetype; scaled/proxied by researcher",
            "scenario_status": "synthetic seeded weather, perturbations, fuel and equipment assumptions",
            "water_status": "synthetic hourly delivery obligation, not observed utility demand",
            "supply_status": "no metered PV series; explicit synthetic weather profile",
            "market_status": "capital ceilings are assumed service-client constraints; no customer or sale",
            "dispatch_status": "scenario-specific perfect-foresight recourse; not an online policy",
        },
    }


def qualification_missions(seed: int = 40400) -> list[dict[str, Any]]:
    return [generate_mission(seed + i, kind, 24, 3) for i, kind in enumerate(("school", "food", "clinic", "water"))]
