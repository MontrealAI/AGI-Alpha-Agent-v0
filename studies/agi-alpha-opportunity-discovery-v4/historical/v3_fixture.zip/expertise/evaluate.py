# SPDX-License-Identifier: Apache-2.0
import argparse
import hashlib
import json
import math
from pathlib import Path


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def evaluate(response: dict, expected: dict) -> dict:
    global_errors = []
    if not isinstance(response, dict) or set(response) != {"schema", "answers"}:
        return {"accepted": 0, "total": len(expected["answers"]), "global_errors": ["invalid_top_level"], "cases": []}
    if response["schema"] != "service-contract-assay/answers-v1":
        global_errors.append("invalid_schema")
    answers = response["answers"]
    if not isinstance(answers, list):
        return {"accepted": 0, "total": len(expected["answers"]), "global_errors": ["answers_not_array"], "cases": []}
    expected_ids = [x["task_id"] for x in expected["answers"]]
    observed_ids = [x.get("task_id") if isinstance(x, dict) else None for x in answers]
    if observed_ids != expected_ids:
        global_errors.append("missing_duplicate_extra_or_reordered_task")
    by_id = {x["task_id"]: x for x in answers if isinstance(x, dict) and isinstance(x.get("task_id"), str)}
    cases = []
    for truth in expected["answers"]:
        task_id = truth["task_id"]
        observed = by_id.get(task_id)
        errors = []
        if observed is None:
            errors.append("missing_answer")
        elif set(observed) != {"task_id", "status", "values", "missing", "feasible"}:
            errors.append("invalid_answer_keys")
        else:
            if observed["status"] != truth["status"]:
                errors.append("status")
            if type(observed["feasible"]) is not type(truth["feasible"]) or observed["feasible"] != truth["feasible"]:
                errors.append("feasible")
            if not isinstance(observed["missing"], list) or observed["missing"] != truth["missing"]:
                errors.append("missing_inputs")
            values = observed["values"]
            if not isinstance(values, dict) or set(values) != set(truth["values"]):
                errors.append("value_keys")
            else:
                for key, wanted in truth["values"].items():
                    got = values[key]
                    if wanted is None:
                        correct = got is None
                    else:
                        correct = (
                            type(got) in (int, float)
                            and math.isfinite(got)
                            and math.isclose(got, wanted, abs_tol=1e-6, rel_tol=1e-9)
                        )
                    if not correct:
                        errors.append("value:" + key)
        cases.append({"task_id": task_id, "accepted": not errors and not global_errors, "errors": errors})
    return {
        "accepted": sum(x["accepted"] for x in cases),
        "total": len(cases),
        "global_errors": global_errors,
        "cases": cases,
        "scope": "Exact semantic acceptance for this researcher-authored finite batch; not an independent customer trial.",
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("response", type=Path)
    parser.add_argument("--split", choices=["development", "confirmation"], required=True)
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    truth_path = Path(__file__).with_name(f"hidden_{args.split}_answers.json")
    expected = json.loads(truth_path.read_text())
    try:
        response = json.loads(args.response.read_text())
    except (ValueError, OSError) as error:
        result = {
            "accepted": 0,
            "total": len(expected["answers"]),
            "global_errors": ["unparseable_response:" + type(error).__name__],
            "cases": [],
        }
    else:
        result = evaluate(response, expected)
    result.update(
        {
            "response_path": str(args.response),
            "response_sha256": digest(args.response),
            "answer_key_sha256": digest(truth_path),
            "evaluator_sha256": digest(Path(__file__)),
            "split": args.split,
        }
    )
    rendered = json.dumps(result, indent=2) + "\n"
    if args.out:
        if args.out.exists():
            raise FileExistsError("Refusing to replace an existing assessment record")
        args.out.write_text(rendered)
    print(rendered)


if __name__ == "__main__":
    main()
