# SPDX-License-Identifier: Apache-2.0
import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--phase", choices=["initial", "confirmation"], required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    names = [
        "development_tasks.json",
        "confirmation_tasks.json",
        "hidden_development_answers.json",
        "hidden_confirmation_answers.json",
        "output_schema.json",
        "evaluate.py",
        "freeze.py",
        "PROTOCOL.md",
        "prompt_U_v1.txt",
        "prompt_E_v1.txt",
        "build_assay.py",
        "prepare_payload.py",
    ]
    if args.phase == "confirmation":
        names += ["prompt_Eplus_v1.txt", "DEVELOPMENT_RECORD.json"]
    names += sorted(path.name for path in root.glob("payload_*.txt"))
    records = []
    for name in names:
        data = (root / name).read_bytes()
        records.append({"path": name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
    result = {
        "schema": "service-contract-assay/freeze-v1",
        "phase": args.phase,
        "recorded_host_utc": datetime.now(timezone.utc).isoformat(),
        "files": records,
        "temporal_limit": "A digest binds bytes. Separate controller records establish exposure and timing.",
    }
    if args.out.exists():
        raise FileExistsError("Refusing to overwrite a freeze")
    args.out.write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            {
                "path": str(args.out),
                "sha256": hashlib.sha256(args.out.read_bytes()).hexdigest(),
                "files": len(records),
                "phase": args.phase,
            }
        )
    )


if __name__ == "__main__":
    main()
