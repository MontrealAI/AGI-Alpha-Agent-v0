# SPDX-License-Identifier: Apache-2.0
import argparse
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--arm", choices=["U", "E", "Eplus"], required=True)
    parser.add_argument("--split", choices=["development", "confirmation"], required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    prompt = (root / f"prompt_{args.arm}_v1.txt").read_text()
    tasks = (root / f"{args.split}_tasks.json").read_text()
    text = (
        "Execute this bounded research assignment independently. Use only the inline task information. "
        "Do not inspect the workspace, search, consult other agents, or open answer files. "
        "One optional self-contained Python computation call and one final JSON reply are permitted. "
        "Do not write or read any files. The computation may use only values provided below. "
        "No feedback or correction turn will be supplied.\n\n" + prompt + "\nTASK BATCH\n" + tasks
    )
    if args.out.exists():
        raise FileExistsError("Refusing to replace a transport payload")
    args.out.write_text(text)
    print(str(args.out))


if __name__ == "__main__":
    main()
