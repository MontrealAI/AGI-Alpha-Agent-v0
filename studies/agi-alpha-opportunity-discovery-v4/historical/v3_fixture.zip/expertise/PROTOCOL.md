# Low-cost operational expertise assay, version 1

## Purpose and boundaries

This sidecar assesses interpretation and validation of a bounded microgrid and service-delivery specification.
It is supporting work for the constructed service-obligation instrument, not a microgrid design certification.
All sixteen briefs are researcher-authored synthetic tasks. None is a real client, contract or customer acceptance.
The arithmetic is modest by design: the putative advantage is preserving useful semantics at low operating cost.
These tasks do not define the ceiling of frontier intelligence or of the main construction experiment.

## Reference configurations

- **H:** a competent human service analyst completing the same normalized specification and review.
  No human participant is run in this assay. Human time and market pricing are unknown here. A sourced external
  scope/rate reference may be reported elsewhere without substituting assumed hours for a measured comparison.
- **U:** competent ordinary use of the same available model: explicit useful assignment, full inputs, exact output
  requirements, permission to calculate and instructions not to invent facts. U is not told to answer hurriedly,
  avoid tools, suppress checking or ignore constraints.
- **E:** the same assignment plus an established concise five-step preparation/calculation/verification checklist.
  Its expertise is pre-existing research-supplied structure, not learned Alpha.
- **E+:** E plus a small new versioned method proposed after an actual development response and its scored feedback.
  The additional method is not supplied in this initial package. It must be frozen before confirmation.
  If development yields no useful change, preserve that outcome rather than invent a learning gain.
- **Recipient E+:** a separate fresh agent with the frozen E+ artifact, no donor conversation or development answers,
  and the same model/tool limits. Successful use establishes transfer of this written operating method, not model
  weight transfer or acquisition of an independent specialist service's intelligence.

## Development and confirmation

There are four development tasks and twelve distinct confirmation tasks. Development spans interval power/energy,
water-service inventory, conditional finance and indispensable missing inputs. Confirmation adds changed numbers,
interval-energy readings, changing critical fractions, terminal reserve, prefix overflow, thermal state with COP,
staged collections, partial failure/refund and unresolved scope. These are unfamiliar instances and surface forms
within closely related mechanisms, not independent industries or a large generalization benchmark.

The controller may run one E development batch. Score its unchanged response and preserve all errors. Construct
at most one concise additional operating method from those observations and the original briefs. Retain the old
and new method, its rationale, developer identity, changes, failed candidates and actual development costs or
unavailable telemetry. Do not inspect confirmation answers while proposing the method. A response that already
passes all four cases permits either no-change or a modest documented operational refinement; it supplies no
observed development quality gain. No tuning is permitted after confirmation.

Each confirmation arm receives the exact same inline task bytes and answer/resource contract. It receives only
its assigned method. Use fresh isolated agent conversations, randomized or alternated order where scheduling
permits, and preserve launch/finish times and raw replies. Do not give arms access to task-construction scripts,
the answer files, another arm's output or feedback. The shared filesystem is an instruction-level boundary, not
a hostile-access sandbox; record any breach and invalidate that run. Publish hidden answers after all frozen
confirmation outputs are collected so anyone can reproduce scoring.

## Fixed acceptance

The output is one valid JSON object under `output_schema.json`. Each task needs its exact requested fields,
correct units through field semantics, correct feasibility and missing-input disposition, and no invented values.
Numbers use absolute tolerance 1e-6 and relative tolerance 1e-9, solely for numerical serialization. Booleans are
not numbers. A task passes only if every semantic field is correct. A malformed top-level schema, missing/extra
task or reordered batch fails the batch; the diagnostic still reports per-task errors. There is no partial-credit
headline, evaluator preference for explanatory prose, new rubric, or easier threshold for E+.

Two confirmation tasks intentionally require bounded clarification. Correct refusal earns acceptance because
certifying an unsupported service would violate the actual useful assignment. Other tasks require a definite
decision; universal abstention fails. Financial financeability and profit are different fields: a loss can be
financeable and a profitable conditional outcome can be unfunded.

## Matched resource envelope and accounting

All arms use the same inherited hosted model configuration, one batch, at most one optional self-contained
computation call and one final reply. No internet, other agents, external files, feedback or correction retry.
The code call may calculate supplied numbers but must not read files. The soft elapsed limit is ten minutes;
exceeding it is reported separately, without silently dropping the result. Record tool calls, elapsed time,
response bytes/words and timeout or integrity events. Exact input/output/billed tokens, internal reasoning tokens,
provider fees and attributable platform cost are unavailable unless separately exposed. A character count is not
a token invoice. A plan subscription is not an API model identifier or zero-cost production.
The method prompt's extra input length is part of the treatment and must be reported; a common tool/turn ceiling
does not establish exact token matching. No proprietary weight access or fine-tuning is assumed.

The matched-budget endpoint is accepted tasks /12 and failed/unsupported decisions. E minus U estimates the
observed operating-method contrast in this finite batch; E+ minus E estimates the observed additional-method
contrast. Equal 12/12 yields ceiling parity, not superiority. The batch is one correlated trial, not twelve
independent discovery campaigns. Do not use a binomial confidence interval to claim broad population performance.

At matched accepted quality, report observed latency and tool use only when useful quality matches. This study
cannot establish complete-dollar cost advantage because billing and full authoring cost are missing. Include
development and assessment work explicitly in the evidence and do not charge it twice as paid-job learning.
The optional method is researcher-developed operational R&D, not customer-paid learning.

## Freezing and reporting

`freeze.py` records hashes of tasks, exact answer keys, schema, evaluator, protocol, and available prompt versions.
Run the initial freeze before development, then a separate final freeze after E+ is chosen and before any
confirmation arm sees tasks. Existing freeze outputs are immutable. Hashes bind bytes; controller process
records establish ordering, and neither creates institutional independence. Do not regenerate the task corpus
after freezing. Retain all raw replies and evaluations. Any repair defines a new version and separate fresh
testing requirement; this small study has no automatic additional evaluation budget.

## Commands

`python expertise/evaluate.py expertise/results/E_development.json --split development --out expertise/results/E_development_score.json`

`python expertise/freeze.py --out expertise/INITIAL_FREEZE.json --phase initial`

`python expertise/freeze.py --out expertise/CONFIRMATION_FREEZE.json --phase confirmation`

`python expertise/evaluate.py expertise/results/U_confirmation.json --split confirmation --out expertise/results/U_confirmation_score.json`

The same assessment command applies to E, E+ and a separate recipient's unchanged raw JSON responses. The
controller must freeze and retain the exact transport payloads and model metadata in addition to these file hashes.

