# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parent


def case(
    task_id: str,
    brief: str,
    fields: dict,
    status: str,
    values: dict,
    feasible: bool | None,
    missing: list[str] | None = None,
) -> tuple[dict, dict]:
    return (
        {"task_id": task_id, "customer_brief": brief, "requested_values": fields},
        {"task_id": task_id, "status": status, "values": values, "missing": missing or [], "feasible": feasible},
    )


def save(name: str, value: object) -> None:
    (ROOT / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


dev = [
    case(
        "D01",
        "A remote clinic has four consecutive 15-minute intervals. Total site average loads are [6,10,8,4] kW; explicitly critical loads are [2,4,3,1] kW. The outage obligation covers only the critical loads, without interruption. A battery supplies up to 3 kWh of AC energy over the outage and up to 4 kW continuously. There is no other supply or charging. Determine whether this source can meet the stated obligation. Report total and critical energy separately.",
        {
            "total_load_energy_kwh": "number, kWh",
            "critical_energy_kwh": "number, kWh",
            "critical_peak_kw": "number, kW",
        },
        "ready",
        {"total_load_energy_kwh": 7, "critical_energy_kwh": 2.5, "critical_peak_kw": 4},
        True,
    ),
    case(
        "D02",
        "A water service has three one-hour slots. End-of-slot withdrawals are [3,2,3] cubic metres. Initial water is 2 m3; tank capacity is 5 m3; required final water is at least 2 m3. A proposed pump plan adds [2,3,3] m3, before each slot's withdrawal. Pump rating is 3 m3/hour; energy is 1 kWh AC per m3. Available solar energy is [2,3,3] kWh in those slots, with sufficient instantaneous power. There is no electric battery and no other demand. Water storage is permitted to shift water service. Validate this exact plan; do not replace it.",
        {
            "pump_energy_kwh": "number, kWh AC",
            "final_water_m3": "number, m3",
            "minimum_post_withdrawal_water_m3": "number, m3",
            "peak_pre_withdrawal_water_m3": "number, m3",
        },
        "ready",
        {
            "pump_energy_kwh": 8,
            "final_water_m3": 2,
            "minimum_post_withdrawal_water_m3": 1,
            "peak_pre_withdrawal_water_m3": 5,
        },
        True,
    ),
    case(
        "D03",
        "A proposed service contract has a total acceptance price of $6,800. Opening unrestricted enterprise cash is $5,000. The buyer has paid a $3,000 deposit, held separately and fully refundable until acceptance; it cannot be spent or pledged. Development costs $4,500 on day 1, and delivery costs $1,200 on day 2. On day 3, if accepted, the deposit becomes earned and the buyer pays the remaining $3,800. No borrowing, advances or other receipts are allowed. There is no reserve requirement. Determine financeability of this sequence and conditional successful contribution. Treat the deposit as part of the price, not extra revenue.",
        {
            "earned_revenue_at_start_usd": "number, USD",
            "unrestricted_cash_before_acceptance_usd": "number, USD; algebraic balance, including a shortfall",
            "success_revenue_usd": "number, USD",
            "success_contribution_usd": "number, USD",
            "refundable_obligation_at_start_usd": "number, USD",
        },
        "ready",
        {
            "earned_revenue_at_start_usd": 0,
            "unrestricted_cash_before_acceptance_usd": -700,
            "success_revenue_usd": 6800,
            "success_contribution_usd": 1100,
            "refundable_obligation_at_start_usd": 3000,
        },
        False,
    ),
    case(
        "D04",
        "The customer requires 21 kWh of critical AC energy over a specified outage. A 40 kWh DC battery starts at 80% state of charge and must end at or above 20%. Inverter power is sufficient; no generation or charging occurs. Discharge efficiency from battery DC to delivered AC is missing. It is strictly positive and at most 1, and no default estimate is authorized. Determine the known DC withdrawal budget and whether the AC obligation can be certified. If a crucial input is missing, use the missing code discharge_efficiency.",
        {"available_dc_energy_kwh": "number, kWh DC", "deliverable_ac_energy_kwh": "number or null, kWh AC"},
        "needs_clarification",
        {"available_dc_energy_kwh": 24, "deliverable_ac_energy_kwh": None},
        None,
        ["discharge_efficiency"],
    ),
]
confirm = [
    case(
        "C01",
        "A shelter needs uninterrupted critical power over six consecutive 10-minute intervals. Average critical loads are [3,6,9,6,3,9] kW, constant within each interval. A 12 kWh DC battery starts at 75% state of charge and must end at or above 25%; discharge efficiency is 90% DC-to-AC. Its inverter can deliver 10 kW continuously. There is no charging or other source. Determine whether the battery can supply the exact critical service.",
        {
            "outage_hours": "number, hours",
            "critical_energy_kwh": "number, kWh AC",
            "critical_peak_kw": "number, kW",
            "deliverable_ac_energy_kwh": "number, kWh AC",
            "energy_shortfall_kwh": "number, kWh AC, max(0, demand minus available)",
        },
        "ready",
        {
            "outage_hours": 1,
            "critical_energy_kwh": 6,
            "critical_peak_kw": 9,
            "deliverable_ac_energy_kwh": 5.4,
            "energy_shortfall_kwh": 0.6,
        },
        False,
    ),
    case(
        "C02",
        "Four consecutive 15-minute meter records are interval energy, not average power: [1.2,0.8,1.4,0.6] kWh of critical load. Within each interval the demand is constant. The proposed source can deliver 4.5 kWh AC in total but has a 5.0 kW continuous power limit. No overload, load shedding or second source is allowed. Validate continuous critical service.",
        {
            "critical_energy_kwh": "number, kWh AC",
            "required_peak_kw": "number, kW",
            "available_ac_energy_kwh": "number, kWh AC",
        },
        "ready",
        {"critical_energy_kwh": 4, "required_peak_kw": 5.6, "available_ac_energy_kwh": 4.5},
        False,
    ),
    case(
        "C03",
        "During three consecutive 30-minute intervals, a facility draws total average powers [12,8,16] kW. Its contract explicitly protects only fractions [0.25,0.50,0.25] of those respective interval loads, with constant load inside each interval. All other demand may be shed. The backup source supplies 6 kWh AC and 4 kW continuously, with no other restrictions or supply. Determine whether the contracted service is feasible.",
        {
            "total_site_energy_kwh": "number, kWh AC",
            "contracted_critical_energy_kwh": "number, kWh AC",
            "contracted_peak_kw": "number, kW",
        },
        "ready",
        {"total_site_energy_kwh": 18, "contracted_critical_energy_kwh": 5.5, "contracted_peak_kw": 4},
        True,
    ),
    case(
        "C04",
        "A radio station must receive 3 kW AC for two hours. Its battery initially contains 7 kWh of usable internal energy, but the contract requires a terminal reserve of at least 2 kWh in that same state variable. Discharge conversion is lossless, inverter power is 4 kW, and no other source or charging is available. The 7 kWh initial figure already accounts for nameplate derating. Do not count the terminal reserve as deliverable energy.",
        {
            "critical_energy_kwh": "number, kWh AC",
            "permitted_withdrawal_kwh": "number, kWh",
            "required_additional_energy_kwh": "number, kWh, max(0, demand minus permitted withdrawal)",
        },
        "ready",
        {"critical_energy_kwh": 6, "permitted_withdrawal_kwh": 5, "required_additional_energy_kwh": 1},
        False,
    ),
    case(
        "C05",
        "An irrigation service must deliver end-of-hour water withdrawals [0,4,0,4] m3. The tank starts empty, capacity is 4 m3, and terminal minimum is zero. The fixed pump plan is [4,0,4,0] m3 in four one-hour slots, completed before each withdrawal. Pump rating is 4 m3/hour and energy intensity is 1.5 kWh AC/m3. Available solar is [6,0,6,0] kWh with sufficient instantaneous power. There is no electrical battery, and the service contract concerns delivered water only. Validate the fixed plan.",
        {
            "total_water_delivered_m3": "number, m3",
            "pump_energy_kwh": "number, kWh AC",
            "final_tank_m3": "number, m3",
            "electrical_storage_used_kwh": "number, kWh",
        },
        "ready",
        {"total_water_delivered_m3": 8, "pump_energy_kwh": 12, "final_tank_m3": 0, "electrical_storage_used_kwh": 0},
        True,
    ),
    case(
        "C06",
        "A municipal water tank initially holds 2 m3 and has a hard 5 m3 capacity. Two one-hour slots each have 4 m3 withdrawal, occurring only at the end of the slot. The fixed proposed pump plan adds 4 m3 before each withdrawal. Pump power and energy are sufficient and all other limits are satisfied. Overflows are forbidden; simultaneous withdrawal cannot be substituted for the stated sequence. Required final volume is 2 m3. Validate this exact plan. Report the algebraic final state even when a prefix violates capacity.",
        {"peak_pre_withdrawal_volume_m3": "number, m3", "algebraic_final_volume_m3": "number, m3"},
        "ready",
        {"peak_pre_withdrawal_volume_m3": 6, "algebraic_final_volume_m3": 2},
        False,
    ),
    case(
        "C07",
        "A cold-room contract requires [3,3] kWh of thermal cooling over two one-hour intervals. A thermal store starts with 5 kWh_th and must end with at least 1 kWh_th; capacity is 5 kWh_th. A compressor has COP 2.5 and consumes exactly [0.4,0.4] kWh AC from solar. Each interval's cooling generation and demand occur uniformly and simultaneously, so the store changes continuously by generated cooling minus thermal demand. Thermal discharge and compressor power are sufficient; there are no losses besides the stated COP, no electric battery and no other load. Validate this plan.",
        {
            "cooling_delivered_kwh_th": "number, kWh thermal",
            "compressor_electricity_kwh": "number, kWh AC",
            "final_thermal_store_kwh_th": "number, kWh thermal",
        },
        "ready",
        {"cooling_delivered_kwh_th": 6, "compressor_electricity_kwh": 0.8, "final_thermal_store_kwh_th": 1},
        True,
    ),
    case(
        "C08",
        "A maintenance offering has total accepted price $4,000. Opening unrestricted cash is $2,500; an additional $2,000 customer deposit is held in a separate refundable account and cannot be used or pledged before acceptance. First spend $1,800 preparing the work, then $900 delivering it. Acceptance subsequently releases the deposit and the buyer pays the remaining $2,000. No borrowing or other cash source is allowed, and no mandatory reserve applies. Report the minimum algebraic unrestricted cash prefix and conditional successful economics; financeability requires every unrestricted prefix to be nonnegative.",
        {
            "required_prefunding_usd": "number, USD",
            "minimum_unrestricted_cash_usd": "number, USD",
            "success_contribution_usd": "number, USD",
            "refundable_obligation_before_acceptance_usd": "number, USD",
        },
        "ready",
        {
            "required_prefunding_usd": 2700,
            "minimum_unrestricted_cash_usd": -200,
            "success_contribution_usd": 1300,
            "refundable_obligation_before_acceptance_usd": 2000,
        },
        False,
    ),
    case(
        "C09",
        "Two separately accepted service stages begin with $1,200 unrestricted enterprise cash. Stage 1 costs $700 and then earns and collects $1,000. Stage 2 subsequently costs $1,100 and then earns and collects $1,400. Collections are irrevocably earned on their respective acceptances, with no deposits, debt, refunds or further costs. Cash must remain at or above a protected $300 reserve throughout. Compute the full cash path and determine whether the stated sequence is financeable.",
        {
            "collections_usd": "number, USD",
            "expenses_usd": "number, USD",
            "operating_profit_usd": "number, USD",
            "minimum_cash_usd": "number, USD",
            "final_cash_usd": "number, USD",
            "final_available_after_reserve_usd": "number, USD",
        },
        "ready",
        {
            "collections_usd": 2400,
            "expenses_usd": 1800,
            "operating_profit_usd": 600,
            "minimum_cash_usd": 400,
            "final_cash_usd": 1800,
            "final_available_after_reserve_usd": 1500,
        },
        True,
    ),
    case(
        "C10",
        "An enterprise starts with $5,000 unrestricted cash. A buyer deposits $2,400 in a separate refundable account, allocated $1,200 each to deliverables A and B. Each deliverable has its own $3,000 price. Common development costs $2,000. A then costs $700, is accepted, releases its $1,200 deposit into earned funds, and collects its $1,800 balance. B costs $400 but fails, so its $1,200 deposit is refunded and no balance is collected. Support then costs $300. No other receipts, costs, liabilities or reserves apply. Deposits cannot be spent before acceptance; the refund comes from B's held deposit. Determine financeability of the actual path and complete terminal accounting. A returned unearned deposit is not both an expense and a reduction in earned revenue.",
        {
            "net_customer_collections_usd": "number, receipts minus refunded deposits, USD",
            "earned_revenue_usd": "number, USD",
            "complete_expenses_usd": "number, USD",
            "operating_profit_usd": "number, USD",
            "refunds_usd": "number, USD",
            "final_unrestricted_cash_usd": "number, USD",
            "outstanding_refund_obligation_usd": "number, USD",
        },
        "ready",
        {
            "net_customer_collections_usd": 3000,
            "earned_revenue_usd": 3000,
            "complete_expenses_usd": 3400,
            "operating_profit_usd": -400,
            "refunds_usd": 1200,
            "final_unrestricted_cash_usd": 4600,
            "outstanding_refund_obligation_usd": 0,
        },
        True,
    ),
    case(
        "C11",
        "Four consecutive records give constant critical powers [3,5,4,6] kW for four equal-length intervals. The interval duration and total outage length are absent; neither may be assumed. The source delivers at most 4 kWh AC and 6 kW continuously, with no other constraint or supply. Can it certify all critical demand? Report known quantities, and use null for energy if it cannot be determined. If a crucial input is missing, use missing code interval_minutes.",
        {
            "critical_peak_kw": "number, kW",
            "critical_energy_kwh": "number or null, kWh AC",
            "available_ac_energy_kwh": "number, kWh AC",
        },
        "needs_clarification",
        {"critical_peak_kw": 6, "critical_energy_kwh": None, "available_ac_energy_kwh": 4},
        None,
        ["interval_minutes"],
    ),
    case(
        "C12",
        "A two-hour outage has constant total facility demand 8 kW and a documented critical subset 3 kW. The backup can supply 5 kW and 10 kWh AC. The proposed contract says only maintain required demand; the customer has not selected whether this means all facility demand or only the critical subset. No default scope is authorized. The supplier may not silently choose the easier requirement. Report both energy requirements and leave feasibility unresolved if the missing scope matters. Use missing code required_load_scope.",
        {
            "total_energy_kwh": "number, kWh AC",
            "critical_energy_kwh": "number, kWh AC",
            "available_energy_kwh": "number, kWh AC",
        },
        "needs_clarification",
        {"total_energy_kwh": 16, "critical_energy_kwh": 6, "available_energy_kwh": 10},
        None,
        ["required_load_scope"],
    ),
]
contract = {
    "schema": "service-contract-assay/tasks-v1",
    "purpose": "Normalize and validate useful service obligations without changing the customer's scope, timeline, units or acceptance requirements.",
    "answer_contract": {
        "top_level_exact_keys": ["schema", "answers"],
        "schema": "service-contract-assay/answers-v1",
        "answer_exact_keys": ["task_id", "status", "values", "missing", "feasible"],
        "status_allowed": ["ready", "needs_clarification"],
        "values": "Exactly the task requested_values keys, numbers in the named units. Use null only for genuinely indeterminate quantities. Do not emit units as strings.",
        "missing": "An array of the supplied missing-input codes, empty when no crucial input is absent.",
        "feasible": "Boolean for whether the exact proposed service/plan meets every stated requirement and cash constraint; null if crucial missing information permits both feasible and infeasible cases.",
        "order": "One answer for every task, in the given order. No extra keys or prose.",
    },
    "resource_contract": {
        "max_computation_tool_calls": 1,
        "max_final_replies": 1,
        "external_network": False,
        "additional_files_or_answers": False,
        "allowed_computation": "One optional self-contained Python computation through exec_command; do not read any other file or contact another agent. Tasks are supplied inline. No task-specific feedback or retries in confirmation.",
        "soft_elapsed_limit_seconds": 600,
        "billed_token_telemetry": "unavailable; no claim of exact token matching or complete monetary cost",
    },
    "provenance": "Researcher-authored, synthetic service briefs motivated by microgrid/service-obligation interpretation. Not observed customers or customer orders.",
}
for name, rows in [("development", dev), ("confirmation", confirm)]:
    save(name + "_tasks.json", {**contract, "split": name, "tasks": [x[0] for x in rows]})
    save(
        "hidden_" + name + "_answers.json",
        {"schema": "service-contract-assay/answers-v1", "answers": [x[1] for x in rows]},
    )
answer_schema = {
    "type": "object",
    "additionalProperties": False,
    "required": ["task_id", "status", "values", "missing", "feasible"],
    "properties": {
        "task_id": {"type": "string"},
        "status": {"enum": ["ready", "needs_clarification"]},
        "values": {"type": "object", "additionalProperties": {"type": ["number", "null"]}},
        "missing": {"type": "array", "items": {"type": "string"}},
        "feasible": {"type": ["boolean", "null"]},
    },
}
save(
    "output_schema.json",
    {
        "type": "object",
        "additionalProperties": False,
        "required": ["schema", "answers"],
        "properties": {
            "schema": {"const": "service-contract-assay/answers-v1"},
            "answers": {"type": "array", "items": answer_schema},
        },
    },
)
