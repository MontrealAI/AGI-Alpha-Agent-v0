# SPDX-License-Identifier: Apache-2.0
"""Adversarial controls for exact reuse, executable transport and fresh authority."""

from __future__ import annotations

import copy
import json
import tempfile
import unittest
import zipfile
from pathlib import Path

from inheritance import LocalMissionAuthority, QualificationCache, file_sha, pack_bundle, unpack_bundle


def identity() -> dict:
    return {"source": "a" * 64, "artifact": "b" * 64, "schema": "instrument/v1",
            "dependencies": {"solver": "fixed"}, "evaluator": "c" * 64,
            "scope": ["critical_electricity", "water_delivery"],
            "policy": {"allow_exact_generic_reuse": True, "version": 1}, "bank": "d" * 64}


class InheritanceTests(unittest.TestCase):
    def setUp(self) -> None:
        self.calls = 0

    def qualified(self) -> dict:
        self.calls += 1
        return {"accepted": True, "cases": 3, "fresh_mission_evaluated": False}

    def test_complete_identity_controls_reuse(self) -> None:
        cache, initial = QualificationCache(), identity()
        first = cache.qualify(initial, self.qualified)
        second = cache.qualify(initial, self.qualified)
        self.assertEqual((first["qualification_cases_executed"], second["qualification_cases_executed"]), (3, 0))
        self.assertIsNone(second["mission_acceptance"])
        self.assertIsNone(second["authority"])
        for field in ["source", "artifact", "schema", "dependencies", "evaluator", "scope", "policy", "bank"]:
            with self.subTest(field=field):
                changed = copy.deepcopy(initial)
                changed[field] = {"allow_exact_generic_reuse": True, "version": 2} if field == "policy" else {
                    "changed": changed[field]}
                self.assertFalse(cache.qualify(changed, self.qualified)["reused"])
        self.assertEqual(self.calls, 9)

    def test_disabled_reuse_and_failed_qualification(self) -> None:
        cache, current = QualificationCache(), identity()
        current["policy"]["allow_exact_generic_reuse"] = False
        cache.qualify(current, self.qualified)
        self.assertFalse(cache.qualify(current, self.qualified)["reused"])
        other = identity()
        with self.assertRaisesRegex(ValueError, "did not pass"):
            cache.qualify(other, lambda: {"accepted": False, "cases": 1})
        self.assertFalse(cache.qualify(other, self.qualified)["reused"])

    def test_returned_receipt_cannot_mutate_cached_evidence(self) -> None:
        cache, current = QualificationCache(), identity()
        receipt = cache.qualify(current, self.qualified)
        receipt["original"]["evidence"]["accepted"] = False
        current["policy"]["version"] = 9
        reused = cache.qualify(identity(), self.qualified)
        self.assertTrue(reused["reused"])
        self.assertTrue(reused["original"]["evidence"]["accepted"])
        self.assertEqual(reused["original"]["identity"]["policy"]["version"], 1)

    def test_incomplete_identity_is_refused(self) -> None:
        current = identity()
        del current["dependencies"]
        with self.assertRaisesRegex(ValueError, "complete declared"):
            QualificationCache().qualify(current, self.qualified)


class ExecutableTransportTests(unittest.TestCase):
    def test_exact_executable_bundle_roundtrip_and_inner_tamper(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            source = root / "instrument.py"
            source.write_text("def verify(mission, receipt):\n    return receipt == mission\n")
            (root / "verifier.py").write_text("def verify(mission, receipt):\n    return receipt == mission\n")
            (root / "mission_schema.json").write_text('{"schema":"fixture/v1"}')
            artifact = root / "artifact.json"
            sources = {name: file_sha(root / name) for name in ("instrument.py", "verifier.py", "mission_schema.json")}
            artifact.write_text(json.dumps({"schema": "fixture/v1", "source_sha256": sources,
                                            "dependencies": {"python": "fixture"}}))
            bundle = root / "bundle.zip"
            pack_bundle(source, artifact, bundle)
            unpack_bundle(bundle, root / "received", file_sha(bundle))
            self.assertEqual((root / "received/instrument.py").read_bytes(), source.read_bytes())
            self.assertEqual((root / "received/artifact.json").read_bytes(), artifact.read_bytes())
            with zipfile.ZipFile(bundle) as archive:
                data = {name: archive.read(name) for name in archive.namelist()}
            data["instrument.py"] += b"\nchanged=True\n"
            changed = root / "changed.zip"
            with zipfile.ZipFile(changed, "w") as archive:
                for name, content in data.items():
                    archive.writestr(name, content)
            with self.assertRaisesRegex(ValueError, "payload identity"):
                unpack_bundle(changed, root / "bad", file_sha(changed))
            self.assertFalse((root / "bad").exists())

    def test_path_traversal_and_changed_outer_identity_refused(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            bundle = root / "bad.zip"
            with zipfile.ZipFile(bundle, "w") as archive:
                archive.writestr("../outside.py", "changed")
            with self.assertRaisesRegex(ValueError, "unexpected"):
                unpack_bundle(bundle, root / "bad", file_sha(bundle))
            with self.assertRaisesRegex(ValueError, "identity mismatch"):
                unpack_bundle(bundle, root / "bad", "0" * 64)
            self.assertFalse((root / "outside.py").exists())


class MissionAuthorityTests(unittest.TestCase):
    def setUp(self) -> None:
        self.authority = LocalMissionAuthority()
        self.identity = identity()
        self.mission = {"scope": "water_delivery", "purpose": "serve water at the outlet",
                        "acceptance": {"unserved_m3": 0}, "demand_m3": [1, 2, 3]}

    def grant(self, nonce: str = "grant-1", **kwargs):
        return self.authority.grant(self.identity, self.mission, nonce=nonce, **kwargs)

    def test_new_mission_meaning_cannot_inherit_authority(self) -> None:
        grant = self.grant()
        for field, value in [("scope", "critical_electricity"), ("purpose", "maximize sales"),
                             ("acceptance", {"unserved_m3": 1}), ("demand_m3", [1, 2, 4])]:
            changed = {**self.mission, field: value}
            with self.subTest(field=field), self.assertRaisesRegex(ValueError, "complete mission"):
                self.authority.consume(grant, self.identity, changed)
        result = self.authority.consume(grant, self.identity, self.mission)
        self.assertEqual(result["mission"], self.mission)

    def test_expired_revoked_and_wrong_recipient_refused(self) -> None:
        with self.assertRaisesRegex(ValueError, "currently valid"):
            self.authority.consume(self.grant(expires=1), self.identity, self.mission, now=1)
        with self.assertRaisesRegex(ValueError, "recipient"):
            self.authority.consume(self.grant(), self.identity, self.mission, recipient="orion.agent.agi.eth")
        grant = self.grant()
        self.authority.registry.revoke("local-controller")
        with self.assertRaisesRegex(ValueError, "currently trusted"):
            self.authority.consume(grant, self.identity, self.mission)

    def test_wrong_right_signature_mutation_and_replay_refused(self) -> None:
        with self.assertRaisesRegex(ValueError, "right not granted"):
            self.authority.consume(self.grant(right="retrieve"), self.identity, self.mission)
        changed = self.grant("changed")
        changed.payload["expires"] = 100
        with self.assertRaisesRegex(ValueError, "signature"):
            self.authority.consume(changed, self.identity, self.mission)
        grant = self.grant("once")
        captured = self.authority.consume(grant, self.identity, self.mission)
        self.mission["demand_m3"].append(99)
        self.assertEqual(captured["mission"]["demand_m3"], [1, 2, 3])
        with self.assertRaisesRegex(ValueError, "already consumed"):
            self.authority.consume(grant, self.identity, captured["mission"])


if __name__ == "__main__":
    unittest.main()
