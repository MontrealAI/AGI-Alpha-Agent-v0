# SPDX-License-Identifier: Apache-2.0
"""Research-only exact qualification reuse and separately signed mission authority."""

from __future__ import annotations

import hashlib
import importlib.util
import json
import sys
import zipfile
from pathlib import Path
from typing import Any, Callable, cast

STUDY = Path(__file__).resolve().parents[1]
PARENT = STUDY.parent / "agi-alpha-capability-opportunity-v1" / "integration"
UPSTREAM = {
    "bridge.py": "6acad454931d3a7b86e254a365a732dba5d0f5866a04f45dbce6c5890de4446a",
    "run_integration.py": "9e553e42a4301d107e487e762525e1941dcb80a44fbec43f64f879bb0a7b1251",
    "source_manifest.json": "3489b4bc2870a1fa17af17566f58d16ef190e8039cc71382dcdb9cfabcbd5ba6",
    "replay.mjs": "21424aca2d4cbd5ed2553875e5f8120de2a51dcdbf21bdedc12b01534cc969c7",
    "crypto_controls.mjs": "7767b56c6938ca4353ce5f99e7ad5fdff8212e7029958283498b9d956924db68",
}


def canonical(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def digest(value: Any) -> str:
    return hashlib.sha256(canonical(value)).hexdigest()


def file_sha(path: Path) -> str:
    if path.is_symlink() or not path.is_file():
        raise ValueError("source must be an ordinary file")
    return hashlib.sha256(path.read_bytes()).hexdigest()


def upstream() -> Any:
    for name, expected in UPSTREAM.items():
        if file_sha(PARENT / name) != expected:
            raise ValueError("pinned parent integration changed: " + name)
    old = sys.modules.get("bridge")
    if old is not None and (old.__file__ is None or Path(old.__file__).resolve() != (PARENT / "bridge.py").resolve()):
        raise ValueError("a different bridge module is already loaded")
    if old is None:
        spec = importlib.util.spec_from_file_location("bridge", PARENT / "bridge.py")
        if spec is None or spec.loader is None:
            raise RuntimeError("cannot load pinned bridge")
        old = importlib.util.module_from_spec(spec)
        sys.modules["bridge"] = old
        spec.loader.exec_module(old)
    old.verify_sources()
    return old


def native_trust() -> Any:
    upstream()
    native = PARENT / "vendor" / "runtime"
    sys.path.insert(0, str(native))
    from alpha_factory_v1.core.runtime.successor import trust

    if not Path(trust.__file__).resolve().is_relative_to(native.resolve()):
        raise ValueError("trust came from outside unchanged parent closure")
    return trust


def pack_bundle(source: Path, artifact: Path, output: Path) -> dict[str, Any]:
    artifact_hash = file_sha(artifact)
    artifact_bytes = artifact.read_bytes()
    policy = json.loads(artifact_bytes)
    required_sources = {"instrument.py", "verifier.py", "mission_schema.json"}
    if set(policy.get("source_sha256", {})) != required_sources or source.name != "instrument.py":
        raise ValueError("artifact does not bind the complete executable source closure")
    if not policy.get("schema") or not isinstance(policy.get("dependencies"), dict):
        raise ValueError("artifact requires schema and declared dependency identities")
    files, contents = {"artifact.json": artifact_hash}, {"artifact.json": artifact_bytes}
    for name in sorted(required_sources):
        path = source.with_name(name)
        actual = file_sha(path)
        if policy["source_sha256"][name] != actual:
            raise ValueError("artifact does not bind exact executable source: " + name)
        files[name], contents[name] = actual, path.read_bytes()
    manifest = {
        "schema": "economic-construction-executable-bundle/v1",
        "files": files,
        "artifact_schema": policy["schema"],
        "dependencies": policy["dependencies"],
        "evaluator": {"path": "verifier.py", "sha256": files["verifier.py"], "entry_point": "verify"},
        "authority": "none inherited; new mission grant required",
        "provenance": "researcher-constructed executable instrument; policy-origin disclosed by technical study",
    }
    with zipfile.ZipFile(output, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for name, data in {**contents, "MANIFEST.json": canonical(manifest)}.items():
            info = zipfile.ZipInfo(name, date_time=(2026, 10, 27, 0, 0, 0))
            info.external_attr = 0o100644 << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, data)
    if output.stat().st_size > 2_000_000:
        raise ValueError("bundle exceeds existing research bridge bound")
    return manifest


def unpack_bundle(bundle: Path, destination: Path, expected_sha: str) -> dict[str, Any]:
    if file_sha(bundle) != expected_sha:
        raise ValueError("transferred executable bundle identity mismatch")
    with zipfile.ZipFile(bundle) as archive:
        infos = archive.infolist()
        names = [info.filename for info in infos]
        required = {"instrument.py", "verifier.py", "mission_schema.json", "artifact.json", "MANIFEST.json"}
        if len(names) != len(set(names)) or set(names) != required:
            raise ValueError("unexpected or duplicated bundle member")
        if any(info.file_size > 1_000_000 or (info.external_attr >> 16) & 0o170000 == 0o120000
               for info in infos) or sum(info.file_size for info in infos) > 2_000_000:
            raise ValueError("nonregular or oversized executable bundle")
        data = {name: archive.read(name) for name in names}
    manifest = json.loads(data["MANIFEST.json"])
    if manifest.get("schema") != "economic-construction-executable-bundle/v1":
        raise ValueError("unsupported executable bundle schema")
    if set(manifest.get("files", {})) != set(data) - {"MANIFEST.json"}:
        raise ValueError("incomplete executable file identity")
    for name, expected in manifest["files"].items():
        if hashlib.sha256(data[name]).hexdigest() != expected:
            raise ValueError("executable payload identity mismatch: " + name)
    artifact = json.loads(data["artifact.json"])
    expected_sources = {name: manifest["files"][name] for name in ("instrument.py", "verifier.py", "mission_schema.json")}
    if artifact.get("source_sha256") != expected_sources:
        raise ValueError("policy/source identity mismatch")
    if artifact.get("schema") != manifest["artifact_schema"] or artifact.get("dependencies") != manifest["dependencies"]:
        raise ValueError("policy/schema/dependency identity mismatch")
    destination.mkdir(parents=True, exist_ok=False)
    for name, value in data.items():
        (destination / name).write_bytes(value)
    return cast(dict[str, Any], manifest)


class QualificationCache:
    """Finite evaluator-owned generic receipts, never mission proofs or authority."""

    def __init__(self) -> None:
        self._receipts: dict[str, bytes] = {}

    def qualify(self, identity: dict[str, Any], evaluate: Callable[[], dict[str, Any]]) -> dict[str, Any]:
        identity_bytes = canonical(identity)
        frozen = json.loads(identity_bytes)
        required = {"source", "artifact", "schema", "dependencies", "evaluator", "scope", "policy", "bank"}
        if set(frozen) != required:
            raise ValueError("complete declared generic qualification identity required")
        key = hashlib.sha256(identity_bytes).hexdigest()
        reusable = frozen["policy"].get("allow_exact_generic_reuse") is True
        if reusable and key in self._receipts:
            return {"identity": frozen, "key": key, "reused": True, "qualification_cases_executed": 0,
                    "original": json.loads(self._receipts[key]), "mission_acceptance": None, "authority": None}
        evidence = evaluate()
        if evidence.get("accepted") is not True or type(evidence.get("cases")) is not int or evidence["cases"] < 1:
            raise ValueError("generic qualification did not pass")
        receipt = {"identity": frozen, "evidence": json.loads(canonical(evidence)),
                   "claim": "finite generic tests only; every mission requires fresh semantic acceptance"}
        self._receipts[key] = canonical(receipt)
        return {"identity": frozen, "key": key, "reused": False,
                "qualification_cases_executed": evidence["cases"], "original": receipt,
                "mission_acceptance": None, "authority": None}


class LocalMissionAuthority:
    """Native signed-role conformance in one research process; no live permissions."""

    DOMAIN = "economic-construction-mission"

    def __init__(self) -> None:
        self.native = native_trust()
        self.registry, self.keys = self.native.local_principals()
        self.consumed: set[str] = set()

    def grant(self, identity: dict[str, Any], mission: dict[str, Any], *, nonce: str,
              recipient: str = "lyra.agent.agi.eth", not_before: int = 0, expires: int = 10,
              right: str = "execute") -> Any:
        payload = {"identity": digest(identity), "mission": digest(mission), "recipient": recipient,
                   "nonce": nonce, "not_before": not_before, "expires": expires, "right": right,
                   "mode": "LOCAL_EPHEMERAL_RESEARCH_AUTHORITY_NOT_LIVE_ENS"}
        return self.native.sign_record(self.keys["local-controller"], "local-controller", self.DOMAIN, payload)

    def consume(self, signed: Any, identity: dict[str, Any], mission: dict[str, Any], *, now: int = 1,
                recipient: str = "lyra.agent.agi.eth") -> dict[str, Any]:
        captured = self.native.SignedEnvelope.model_validate(signed.model_dump())
        payload = self.registry.verify(captured, self.DOMAIN, "controller")
        expected_keys = {"identity", "mission", "recipient", "nonce", "not_before", "expires", "right", "mode"}
        if set(payload) != expected_keys or payload["mode"] != "LOCAL_EPHEMERAL_RESEARCH_AUTHORITY_NOT_LIVE_ENS":
            raise ValueError("mission grant has unsupported terms")
        if payload["identity"] != digest(identity) or payload["mission"] != digest(mission):
            raise ValueError("grant does not bind current capability and complete mission")
        if payload["recipient"] != recipient or payload["right"] != "execute":
            raise ValueError("recipient or execution right not granted")
        if any(type(payload[x]) is not int for x in ["not_before", "expires"]) or type(now) is not int:
            raise ValueError("grant times must be exact integers")
        if not payload["not_before"] <= now < payload["expires"]:
            raise ValueError("mission grant not currently valid")
        nonce = payload["nonce"]
        if not isinstance(nonce, str) or not nonce or nonce in self.consumed:
            raise ValueError("mission grant already consumed or lacks identity")
        self.consumed.add(nonce)
        return {"mission": json.loads(canonical(mission)), "authority": json.loads(canonical(payload)),
                "scope": "single-process local signed-role test; no persistent production authority"}
