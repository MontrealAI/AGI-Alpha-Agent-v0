# SPDX-License-Identifier: Apache-2.0
"""Independent cash-timing defects and native denomination projection controls."""

from __future__ import annotations

import copy
import tempfile
import unittest
from pathlib import Path

from replay_cad import audit_events, replay_world, sign_cad_events, verify_exported_cad


def world() -> dict:
    raw = [(0, "seed", 1500, None), (0, "deposit", 600, None),
           (0, "deposit_activate", 600, None), (0, "expense", 700, "A"),
           (1, "deposit_release", 600, None), (1, "expense", 100, "A"),
           (1, "receivable", 900, None), (2, "receivable_close", 900, None),
           (2, "collection", 900, None), (2, "expense", 60, "B"), (2, "reserve", 0, None)]
    return {"arm": "fixture", "seed": 1, "events": [
        {"event_id": i, "week": week, "kind": kind, "amount_cad": amount,
         "bucket": bucket, "mission": "mission-1", "reason": "synthetic directed control"}
        for i, (week, kind, amount, bucket) in enumerate(raw)],
        "profit_cad": 640, "collections_cad": 1500, "expenses_cad": 860,
        "cash_cad": 2140, "seed_capital_cad": 1500, "available_cad": 2140, "reserve_cad": 0}


class CashTests(unittest.TestCase):
    def test_restricted_advance_cannot_pay_for_construction(self) -> None:
        value = world()
        value["events"][3]["amount_cad"] = 1700
        value["events"] = [row for row in value["events"] if row["kind"] != "deposit_activate"]
        with self.assertRaisesRegex(ValueError, "available cash"):
            audit_events(value)

    def test_unaccepted_restricted_fee_cannot_be_earned(self) -> None:
        value = world()
        value["events"] = [row for row in value["events"] if row["kind"] != "deposit_activate"]
        with self.assertRaisesRegex(ValueError, "activated advance"):
            audit_events(value)

    def test_another_mission_cannot_release_this_advance(self) -> None:
        value = world()
        value["events"][4]["mission"] = "mission-2"
        with self.assertRaisesRegex(ValueError, "this mission"):
            audit_events(value)

    def test_duplicate_revenue_and_changed_balances_are_detected(self) -> None:
        value = world()
        value["events"].append(copy.deepcopy(value["events"][8]))
        with self.assertRaisesRegex(ValueError, "duplicate event"):
            audit_events(value)
        value = world()
        value["events"][8]["cash_cad"] = 1
        with self.assertRaisesRegex(ValueError, "balance disagrees"):
            audit_events(value)

    def test_settled_projection_has_explicit_fx_and_no_advance_revenue(self) -> None:
        value = world()
        audit = audit_events(value)
        self.assertEqual(audit["net_earned_collections_cents"], 150000)
        self.assertEqual(audit["cost_bucket_cents"], {"A": 80000, "B": 6000, "C": 0})
        with tempfile.TemporaryDirectory() as temporary:
            result = replay_world(value, Path(temporary) / "report")
        self.assertEqual(result["passed"], result["total"])
        self.assertEqual(result["native_report"]["currency"], "USD")
        self.assertEqual(result["assumed_usd_per_cad"], "0.72")
        self.assertEqual(result["native_report"]["collected_revenue"], 1080000000)
        self.assertEqual(result["native_report"]["complete_cost_profit"], 460800000)
        self.assertIsNone(result["actual_research_report"]["complete_cost_profit"])
        self.assertEqual(result["actual_customer_collections"], 0)

    def test_exported_event_signatures_and_truncation(self) -> None:
        record = sign_cad_events(world())
        self.assertTrue(verify_exported_cad(record))
        truncated = copy.deepcopy(record)
        truncated["journal_chain"].pop()
        with self.assertRaisesRegex(ValueError, "truncated"):
            verify_exported_cad(truncated)
        changed = copy.deepcopy(record)
        changed["journal_chain"][2]["body"]["document"]["signed"]["payload"]["event"]["amount_cad"] = 0
        with self.assertRaisesRegex(ValueError, "chain changed"):
            verify_exported_cad(changed)


if __name__ == "__main__":
    unittest.main()
