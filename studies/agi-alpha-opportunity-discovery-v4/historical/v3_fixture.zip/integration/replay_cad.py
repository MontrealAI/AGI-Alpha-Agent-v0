# SPDX-License-Identifier: Apache-2.0
"""Audit authoritative CAD timing and project settled totals into native USD accounting."""

from __future__ import annotations

import argparse
import base64
import json
import tempfile
from decimal import Decimal, ROUND_HALF_EVEN
from pathlib import Path
from typing import Any

from inheritance import digest, native_trust, upstream

FX = Decimal("0.72")
CATEGORIES = ["model", "tools", "compute", "storage", "network", "human", "acceptance", "correction", "overhead"]


def cents(value: Any) -> int:
    number = Decimal(str(value))
    if not number.is_finite() or number < 0 or number != number.quantize(Decimal("0.01")):
        raise ValueError("finite nonnegative exact CAD cents required")
    return int(number * 100)


def usd_micro(cad_cents: int) -> int:
    return int((Decimal(cad_cents) * Decimal(10_000) * FX).quantize(Decimal(1), rounding=ROUND_HALF_EVEN))


def audit_events(world: dict[str, Any]) -> dict[str, Any]:
    events = world["events"]
    cash = seed = revenue = expenses = advances = restricted = reserve = receivable = 0
    buckets = {bucket: 0 for bucket in ("A", "B", "C")}
    ids: set[Any] = set()
    missions: dict[str, dict[str, int]] = {}
    prior_week = -1
    verified = []
    for event in events:
        event_id, kind, amount, week = event["event_id"], event["kind"], cents(event["amount_cad"]), event["week"]
        if event_id in ids:
            raise ValueError("duplicate event identity")
        ids.add(event_id)
        if type(week) is not int or week < prior_week:
            raise ValueError("nonchronological CAD cash events")
        prior_week = week
        mission = str(event.get("mission") or "enterprise")
        balance = missions.setdefault(mission, {"unearned": 0, "restricted": 0})
        if kind == "seed":
            if len(ids) != 1:
                raise ValueError("seed cannot masquerade as later collection")
            cash += amount
            seed += amount
        elif kind == "expense":
            if event["bucket"] not in buckets or amount > cash - restricted - reserve:
                raise ValueError("invalid bucket or expenditure exceeds authorized available cash")
            cash -= amount
            expenses += amount
            buckets[event["bucket"]] += amount
        elif kind == "deposit":
            cash += amount
            advances += amount
            restricted += amount
            balance["unearned"] += amount
            balance["restricted"] += amount
        elif kind == "deposit_activate":
            if amount > balance["restricted"]:
                raise ValueError("activation exceeds this mission's restricted advance")
            restricted -= amount
            balance["restricted"] -= amount
        elif kind == "deposit_release":
            if amount > balance["unearned"] - balance["restricted"]:
                raise ValueError("earned release exceeds this mission's activated advance")
            advances -= amount
            revenue += amount
            balance["unearned"] -= amount
        elif kind == "deposit_return":
            if amount > balance["unearned"] or amount > cash:
                raise ValueError("advance return exceeds mission liability or cash")
            returned_restricted = min(amount, balance["restricted"])
            advances -= amount
            cash -= amount
            restricted -= returned_restricted
            balance["unearned"] -= amount
            balance["restricted"] -= returned_restricted
        elif kind == "collection":
            cash += amount
            revenue += amount
        elif kind == "refund":
            if amount > cash:
                raise ValueError("unfunded customer refund")
            cash -= amount
            revenue -= amount
        elif kind == "reserve":
            if amount > cash - advances:
                raise ValueError("reserve exceeds cash net of unearned obligations")
            reserve = amount
        elif kind == "receivable":
            receivable += amount
        elif kind == "receivable_close":
            receivable -= amount
        else:
            raise ValueError("unsupported CAD event kind: " + str(kind))
        if min(cash, advances, restricted, receivable) < 0 or restricted > advances:
            raise ValueError("negative or inconsistent liability balance")
        if cash != seed + revenue - expenses + advances:
            raise ValueError("independent cash identity failed")
        expected = {"cash_cad": cash, "earned_collections_cad": revenue, "expenses_cad": expenses,
                    "refundable_advances_cad": advances, "restricted_advances_cad": restricted,
                    "reserve_cad": reserve, "available_cad": cash - restricted - reserve, "receivable_cad": receivable}
        for name, amount_cents in expected.items():
            if name in event and Decimal(str(event[name])) * 100 != amount_cents:
                raise ValueError("stored CAD balance disagrees with independent replay: " + name)
        verified.append({"event_id": event_id, "kind": kind, "event_sha256": digest(event),
                         "cash_cents": cash, "earned_cents": revenue, "unearned_cents": advances,
                         "restricted_cents": restricted, "available_cents": cash - restricted - reserve})
    if advances or restricted or receivable:
        raise ValueError("native settled-operation replay requires fully settled advances and invoices")
    for field, expected_value in {"collections_cad": revenue, "expenses_cad": expenses, "cash_cad": cash,
                            "seed_capital_cad": seed, "reserve_cad": reserve,
                            "available_cad": cash - reserve}.items():
        if field in world and cents(world[field]) != expected_value:
            raise ValueError("world summary disagrees with independent CAD events: " + field)
    if "profit_cad" in world and Decimal(str(world["profit_cad"])) * 100 != revenue - expenses:
        raise ValueError("world profit disagrees with independent CAD events")
    return {"event_count": len(events), "verified_events": verified, "source_events_sha256": digest(events),
            "seed_cents": seed, "net_earned_collections_cents": revenue, "expense_cents": expenses,
            "cost_bucket_cents": buckets, "cash_cents": cash, "reserve_cents": reserve,
            "profit_cents": revenue - expenses, "available_cents": cash - reserve,
            "all_advances_settled": True, "scope": "independent arithmetic and cash-timing audit, not market validation"}


def commands_for(world: dict[str, Any], audited: dict[str, Any]) -> list[dict[str, Any]]:
    if audited["net_earned_collections_cents"] < 0:
        raise ValueError("native net-collection projection cannot encode net negative customer receipts")
    context = {"world": {key: world.get(key) for key in ("arm", "seed")},
               "events": audited["source_events_sha256"], "assumed_usd_per_cad": str(FX)}
    commands: list[dict[str, Any]] = []
    for action, name, amount in [("capital", "seed", audited["seed_cents"]),
                                 ("collection", "net-settled-collections", audited["net_earned_collections_cents"])]:
        commands.append({"action": action, "record": {"record_id": name, "mission_id": "modeled-enterprise",
                         "amount_micro_usd": usd_micro(amount), "evidence_digest": digest({**context, "kind": name})}})
    for bucket, total in audited["cost_bucket_cents"].items():
        evidence = [row for row in world["events"] if row["kind"] == "expense" and row["bucket"] == bucket]
        for category in CATEGORIES:
            amount = usd_micro(total) if category == "overhead" else 0
            commands.append({"action": "charge", "record": {
                "activity_id": "modeled-" + bucket + "-" + category, "mission_id": "modeled-enterprise",
                "bucket": bucket, "category": category, "accrued_micro_usd": amount, "paid_micro_usd": amount,
                "basis": "attested", "evidence_digest": digest({**context, "bucket": bucket, "category": category,
                                                                    "events": evidence}),
                "note": "SIMULATED all-in CAD expense projection at assumed 0.72 USD/CAD. Inclusive modeled costs "
                        "are aggregated in overhead; other categories have no separately additional amount. "
                        "This is not an observation of zero actual resource cost."}})
        commands.append({"action": {"A": "seal", "B": "seal-retention", "C": "seal-investment"}[bucket],
                         "record": {"mission_id": "modeled-enterprise", "categories": CATEGORIES,
                                    "evidence_digest": digest({**context, "seal": bucket})}})
    commands.append({"action": "reserve", "record": usd_micro(audited["reserve_cents"])})
    return commands


def sign_cad_events(world: dict[str, Any]) -> dict[str, Any]:
    native = native_trust()
    from alpha_factory_v1.core.runtime.store import Journal

    with tempfile.TemporaryDirectory(prefix="economic-cad-journal-") as temporary:
        journal = Journal.initialize(Path(temporary) / "journal")
        registry, keys = native.local_principals()
        signed = []
        for event in world["events"]:
            payload = {"journal_identity": journal.identity, "event": event,
                       "currency": "CAD", "basis": "SIMULATED_RESEARCH", "claim": "not a bank receipt"}
            envelope = native.sign_record(keys["local-controller"], "local-controller", "economic-construction-cad", payload)
            checked = registry.verify(envelope, "economic-construction-cad", "controller")
            with journal.transaction() as cx:
                journal.append(cx, "@economic-construction-cad:" + str(event["event_id"]),
                               {"event_sha256": digest(checked["event"]), "signed": envelope.model_dump()})
            signed.append(envelope.model_dump())
        verification = journal.verify()
        with journal.transaction() as cx:
            chain = [{"sequence": seq, "mission": mission, "body": json.loads(body), "hash": hashed,
                      "signature": signature}
                     for seq, mission, body, hashed, signature in cx.execute("SELECT * FROM events ORDER BY seq")]
        return {"schema": "native-journal-cad-research-events/v1", "signed_events": signed,
                "verification": verification, "journal_chain": chain, "uses_existing_journal": True,
                "public_controller_key": registry.anchor("local-controller", "controller").public_key,
                "local_ephemeral_principals": True, "persistent_or_live_authority": False,
                "source_events_sha256": digest(world["events"])}


def verify_exported_cad(record: dict[str, Any]) -> bool:
    native = native_trust()
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    from alpha_factory_v1.core.runtime.store import digest as journal_digest

    registry = native.TrustRegistry({"local-controller": native.TrustAnchor(
        record["public_controller_key"], frozenset({"controller"}))})
    journal_identity = record["verification"]["identity"]
    public = Ed25519PublicKey.from_public_bytes(bytes.fromhex(journal_identity.removeprefix("urn:agialpha:ed25519:")))
    previous = "0" * 64
    events = []
    for index, row in enumerate(record["journal_chain"], start=1):
        body = row["body"]
        if (row["sequence"] != index or body["sequence"] != index or body["previous"] != previous
                or body["identity"] != journal_identity or body["mission"] != row["mission"]
                or journal_digest(body) != row["hash"]):
            raise ValueError("exported CAD journal chain changed")
        public.verify(base64.b64decode(row["signature"], validate=True), bytes.fromhex(row["hash"]))
        previous = row["hash"]
        if row["mission"] == "@control":
            continue
        payload = registry.verify(native.SignedEnvelope.model_validate(body["document"]["signed"]),
                                  "economic-construction-cad", "controller")
        if payload["journal_identity"] != journal_identity or digest(payload["event"]) != body["document"]["event_sha256"]:
            raise ValueError("exported event has changed identity")
        events.append(payload["event"])
    if (previous != record["verification"]["head"] or len(record["journal_chain"]) != record["verification"]["events"]
            or digest(events) != record["source_events_sha256"]):
        raise ValueError("exported CAD journal is truncated or belongs to another event stream")
    return True


def replay_world(world: dict[str, Any], out: Path) -> dict[str, Any]:
    bridge = upstream()
    audited = audit_events(world)
    commands = commands_for(world, audited)
    native = bridge.replay_native(commands)
    actual = bridge.replay_native([{"action": "charge", "record": {
        "activity_id": "actual-research-unmetered", "mission_id": "actual-research", "bucket": "C",
        "category": "overhead", "accrued_micro_usd": None, "paid_micro_usd": 0, "basis": "unknown",
        "evidence_digest": digest({"world": audited["source_events_sha256"], "actual_cost": "unknown"}),
        "note": "Actual research, model, engineering and evaluation expense is unmetered and unknown; "
                "zero customer collections and absence of a payment receipt do not mean zero cost."}}])
    cad = sign_cad_events(world)
    exported_cad_verified = verify_exported_cad(cad)
    report = native["report"]
    expected = {"collected_revenue": usd_micro(audited["net_earned_collections_cents"]),
                "complete_cost_profit": usd_micro(audited["profit_cents"]), "cash": usd_micro(audited["cash_cents"]),
                "available_funds": usd_micro(audited["available_cents"]), "reserve": usd_micro(audited["reserve_cents"])}
    checks = [{"name": "native-" + key + "-reconciles-to-settled-CAD", "passed": report[key] == value}
              for key, value in expected.items()]
    checks += [
        {"name": "disjoint-A-B-C-projection", "passed": report["costs"] ==
         {bucket: usd_micro(value) for bucket, value in audited["cost_bucket_cents"].items()}},
        {"name": "actual-research-cost-remains-unknown", "passed": actual["report"]["complete_cost_profit"] is None
         and actual["report"]["available_funds"] is None and actual["report"]["collected_revenue"] == 0},
        {"name": "native-signed-CAD-journal-valid", "passed": cad["verification"]["valid"] is True and exported_cad_verified},
    ]
    summary = {"schema": "CAD-native-USD-settled-interface/v1", "world": {key: world.get(key) for key in ("arm", "seed")},
               "checks": checks, "passed": sum(row["passed"] for row in checks), "total": len(checks),
               "authoritative_currency": "CAD", "native_currency": "USD", "assumed_usd_per_cad": str(FX),
               "fx_basis": "fixed research-interface scenario assumption; not a current market rate",
               "native_scope": "settled totals only; raw advances, activation, returns and cash timing stay in CAD Journal",
               "unearned_advances_counted_as_revenue": False, "seed_counted_as_revenue": False,
               "native_report": report, "actual_research_report": actual["report"],
               "source_events_sha256": audited["source_events_sha256"], "actual_customer_collections": 0}
    out.mkdir(parents=True, exist_ok=False)
    for name, data in {"cad-audit": audited, "cad-signed-journal": cad, "native-settled-replay": native,
                       "actual-research-unknown": actual, "summary": summary}.items():
        (out / (name + ".json")).write_text(json.dumps(data, sort_keys=True, indent=2, allow_nan=False) + "\n")
    return summary


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--arm")
    parser.add_argument("--seed", type=int)
    args = parser.parse_args()
    content = json.loads(args.input.read_text())
    if isinstance(content, list):
        selected = [row for row in content if row.get("arm") == args.arm and row.get("seed") == args.seed]
        if len(selected) != 1:
            raise ValueError("choose exactly one declared arm and seed")
        content = selected[0]
    result = replay_world(content, args.out)
    print(json.dumps({key: result[key] for key in ("passed", "total", "world", "native_currency", "assumed_usd_per_cad")}))
    raise SystemExit(0 if result["passed"] == result["total"] else 1)
