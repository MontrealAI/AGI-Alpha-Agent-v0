# SPDX-License-Identifier: Apache-2.0
"""Transfer executable construction and test fresh meaning, qualification and authority."""

from __future__ import annotations

import argparse
import copy
import hashlib
import importlib.metadata
import importlib.util
import json
import platform
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

from inheritance import (PARENT, STUDY, UPSTREAM, LocalMissionAuthority, QualificationCache,
                         canonical, digest, file_sha, pack_bundle, unpack_bundle, upstream)


def save(path: Path, value: Any) -> None:
    if path.exists():
        raise FileExistsError("preserve earlier evidence: " + str(path))
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + "\n")


def load_module(name: str, path: Path) -> Any:
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load declared module")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def dependencies() -> dict[str, Any]:
    packages = {}
    for name in ["numpy", "scipy"]:
        distribution = importlib.metadata.distribution(name)
        rows = []
        for relative in distribution.files or []:
            if str(relative).endswith(".pyc") or "__pycache__" in str(relative):
                continue
            actual = Path(str(distribution.locate_file(relative)))
            if not actual.is_file():
                raise ValueError("installed dependency file missing: " + str(relative))
            data = actual.read_bytes()
            rows.append({"path": str(relative), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
        packages[name] = {"version": distribution.version, "files": rows,
                          "inventory_sha256": digest(rows), "count": len(rows)}
    return {"python": platform.python_version(), "implementation": platform.python_implementation(),
            "executable_sha256": file_sha(Path(sys.executable).resolve()),
            "platform": platform.platform(), "machine": platform.machine(), "packages": packages,
            "scope": "installed numerical dependency files and interpreter; not independent machine attestation"}


def execute(directory: Path, mission: dict[str, Any], output: Path, label: str) -> dict[str, Any]:
    mission_path, receipt_path = output / (label + "-mission.json"), output / (label + "-receipt.json")
    save(mission_path, mission)
    if receipt_path.exists():
        raise FileExistsError(receipt_path)
    start = time.perf_counter()
    result = subprocess.run([sys.executable, str(directory / "instrument.py"), "--artifact",
                             str(directory / "artifact.json"), "--mission", str(mission_path),
                             "--out", str(receipt_path)], capture_output=True, text=True, timeout=180, check=False)
    elapsed = time.perf_counter() - start
    save(output / (label + "-process.json"), {"returncode": result.returncode, "stdout": result.stdout,
         "stderr": result.stderr, "wall_seconds_including_process_start": elapsed,
         "frontier_model_calls": 0, "researcher_process_independence_only": True})
    if result.returncode or not receipt_path.is_file():
        raise RuntimeError("recipient executable failed; preserved process record: " + label)
    receipt = json.loads(receipt_path.read_text())
    verifier = load_module("economic_fresh_verifier_" + label.replace("-", "_"), directory / "verifier.py")
    fresh = verifier.verify(mission, receipt)
    save(output / (label + "-fresh-verification.json"), fresh)
    return {"receipt": receipt, "verification": fresh, "wall_seconds": elapsed,
            "receipt_path": str(receipt_path.relative_to(output))}


def scientific_projection(receipt: dict[str, Any]) -> dict[str, Any]:
    return {key: value for key, value in receipt.items()
            if key not in {"stats", "verification", "accepted"}}


def run(artifact_path: Path, mission_path: Path, qualification_path: Path, out: Path) -> dict[str, Any]:
    bridge = upstream()
    parent_controls = load_module("economic_parent_conformance", PARENT / "run_integration.py")
    source = STUDY / "technical" / "instrument.py"
    source_before = {name: file_sha(source.with_name(name))
                     for name in ["instrument.py", "verifier.py", "mission_schema.json"]}
    artifact, mission = json.loads(artifact_path.read_text()), json.loads(mission_path.read_text())
    qualification = json.loads(qualification_path.read_text())
    bank = qualification["missions"] if isinstance(qualification, dict) else qualification
    if not isinstance(bank, list) or not bank or any(not isinstance(row, dict) for row in bank):
        raise ValueError("separate finite generic qualification mission bank required")
    if any(digest(row) == digest(mission) or row.get("id") == mission.get("id") for row in bank):
        raise ValueError("fresh transfer mission must be excluded from generic qualification")
    out.mkdir(parents=True, exist_ok=False)
    bundle = out / "capability-bundle.zip"
    manifest = pack_bundle(source, artifact_path, bundle)
    bundle_sha = file_sha(bundle)
    save(out / "source-bindings.json", {"parent_commit": "231834269599d85e49cfe1ca9917a1a874522d44",
         "runtime_commit": "80b345828f34fd8a6e592977dd17ef37141305f4", "parent_adapter": UPSTREAM,
         "instrument": source_before, "artifact_sha256": file_sha(artifact_path), "bundle_sha256": bundle_sha,
         "qualification_sha256": file_sha(qualification_path), "fresh_mission_sha256": digest(mission),
         "research_only": True})
    transport = parent_controls.run(bundle, out / "transport")
    received = out / "transport" / "received-v2.zip"
    unpack_bundle(received, out / "recipient", bundle_sha)
    unpack_bundle(bundle, out / "ordinary-library", bundle_sha)
    checks = list(transport["checks"])
    candidate = parent_controls.fixture_candidate(bundle)
    key = "artifact-conformance@2"
    controls = [
        {"action": "retrieve", "key": key, "mission": {"scopeDigest": "f" * 64}},
        {"action": "retrieve", "key": key, "mission": {"environmentDigest": "f" * 64}},
        {"action": "retrieve", "key": key, "mission": {"betaVersion": "unqualified-new-baseline"}},
        {"action": "retrieve", "key": key, "week": 101},
    ]
    scoped = bridge.run_lifecycle([candidate], controls)
    save(out / "current-scope-controls.json", scoped)
    for name, row in zip(["changed-scope-refused", "changed-environment-refused", "changed-baseline-refused",
                          "expired-capability-refused"], scoped["operations"]):
        checks.append({"name": name, "passed": row["result"].get("ok") is False})
    available = bridge.run_lifecycle([{**candidate, "already_available": True}])
    save(out / "already-available-control.json", available)
    checks.append({"name": "readily-available-identical-method-is-not-new-alpha",
                   "passed": available["candidates"][0]["assessment"]["verdict"] == "reject"})
    environment = dependencies()
    save(out / "dependency-inventory.json", environment)
    dependency_id = {**{name: {"version": row["version"], "inventory_sha256": row["inventory_sha256"]}
                       for name, row in environment["packages"].items()},
                     "python": environment["python"], "interpreter": environment["executable_sha256"],
                     "platform": environment["platform"]}
    identity = {"source": source_before, "artifact": file_sha(artifact_path),
                "schema": {"artifact": artifact["schema"], "mission": source_before["mission_schema.json"]},
                "dependencies": {"declared": artifact["dependencies"], "installed": dependency_id},
                "evaluator": {"source": source_before["verifier.py"], "tolerance": 1e-5,
                              "wrapper": file_sha(Path(__file__).with_name("inheritance.py"))},
                "scope": artifact["scope"], "bank": digest(bank),
                "policy": {"version": "complete-identity-fresh-mission-v1", "allow_exact_generic_reuse": True,
                           "current_mission_acceptance": "always", "authority": "separate current signed grant"}}
    save(out / "complete-identity.json", identity)
    cache, counter = QualificationCache(), 0

    def generic() -> dict[str, Any]:
        nonlocal counter
        counter += 1
        outputs = [execute(out / "recipient", row, out / "generic", f"q{counter}-case{i}")
                   for i, row in enumerate(bank)]
        return {"accepted": all(row["verification"].get("physical_pass") is True
                                and row["receipt"].get("accepted") == row["verification"].get("accepted")
                                for row in outputs),
                "cases": len(outputs), "receipts": [row["receipt_path"] for row in outputs],
                "per_case_offering_accepted": [row["verification"].get("accepted") for row in outputs],
                "qualification_rule": "physical correctness and correct acceptance verdict, including budget refusal",
                "numerical_acceptance_only": True, "generation": counter}

    first = cache.qualify(identity, generic)
    inherited = cache.qualify(identity, generic)
    checks.append({"name": "exact-generic-identity-reused-without-mission-proof",
                   "passed": first["qualification_cases_executed"] == len(bank)
                   and inherited["qualification_cases_executed"] == 0
                   and inherited["mission_acceptance"] is None and inherited["authority"] is None})
    changed = copy.deepcopy(identity)
    changed["policy"]["version"] = "complete-identity-fresh-mission-v2-control"
    requalified = cache.qualify(changed, generic)
    checks.append({"name": "changed-evaluator-policy-reruns-generic-checks",
                   "passed": requalified["qualification_cases_executed"] == len(bank) and not requalified["reused"]})
    save(out / "generic-qualification.json", {"first": first, "inherited": inherited, "policy_drift": requalified,
         "claim": "generic cases only; executable loading, source hashing, fresh acceptance and authority still required"})
    authority = LocalMissionAuthority()
    grant = authority.grant(identity, mission, nonce="fresh-recipient-1")
    authorized = authority.consume(grant, identity, mission)
    save(out / "fresh-mission-grant.json", {"signed": grant.model_dump(), "consumed": authorized,
         "scope": "real local Ed25519 verification; fictional member, no live ENS or production grant"})
    recipient = execute(out / "recipient", authorized["mission"], out / "fresh", "recipient")
    ordinary = execute(out / "ordinary-library", mission, out / "fresh", "ordinary-library")
    checks.append({"name": "fresh-recipient-current-purpose-bound-and-independently-evaluated",
                   "passed": recipient["receipt"].get("mission_sha256") == digest(mission)
                   and recipient["receipt"].get("purpose") == mission["purpose"]
                   and recipient["receipt"].get("accepted") == recipient["verification"].get("accepted"),
                   "useful_outcome_accepted": recipient["verification"].get("accepted")})
    checks.append({"name": "identical-authorized-library-content-parity",
                   "passed": ordinary["verification"].get("accepted") == recipient["verification"].get("accepted")
                   and canonical(scientific_projection(recipient["receipt"])) == canonical(scientific_projection(ordinary["receipt"]))})
    verifier = load_module("economic_semantic_controls", out / "recipient/verifier.py")
    changed_mission = copy.deepcopy(mission)
    changed_mission["purpose"] = "critical_electricity" if mission["purpose"] == "water_delivery" else "water_delivery"
    changed_input = copy.deepcopy(mission)
    changed_input["scenarios"][0]["load_kw"][0] += 1.0
    changed_acceptance = copy.deepcopy(mission)
    changed_acceptance["acceptance"]["max_capex_cad"] = 0.0
    semantic = []
    for name, altered in [("different-purpose", changed_mission), ("changed-input", changed_input),
                           ("new-acceptance", changed_acceptance)]:
        verdict = verifier.verify(altered, recipient["receipt"])
        semantic.append({"mutation": name, "verdict": verdict})
        checks.append({"name": "old-receipt-refused-for-" + name, "passed": verdict.get("accepted") is False})
    save(out / "fresh-semantics-controls.json", semantic)
    for name, altered in [("different-purpose", changed_mission), ("changed-input", changed_input),
                           ("new-acceptance", changed_acceptance)]:
        try:
            authority.consume(authority.grant(identity, mission, nonce="wrong-" + name), identity, altered)
            passed = False
        except ValueError:
            passed = True
        checks.append({"name": "old-authority-refused-for-" + name, "passed": passed})
    authority_cases: list[tuple[str, dict[str, Any], int]] = [
        ("expired-authority", {"expires": 1}, 1), ("retrieval-is-not-execution", {"right": "retrieve"}, 1)]
    for name, terms, moment in authority_cases:
        try:
            authority.consume(authority.grant(identity, mission, nonce=name, **terms), identity, mission, now=moment)
            passed = False
        except ValueError:
            passed = True
        checks.append({"name": name + "-refused", "passed": passed})
    authority.registry.revoke("local-controller")
    try:
        authority.consume(authority.grant(identity, mission, nonce="revoked"), identity, mission)
        passed = False
    except ValueError:
        passed = True
    checks.append({"name": "current-native-authority-revocation-refused", "passed": passed})
    checks.append({"name": "technical-source-unchanged-during-transfer",
                   "passed": source_before == {name: file_sha(source.with_name(name)) for name in source_before}})
    summary = {"schema": "economic-construction-inheritance-result/v1", "artifact": manifest,
               "bundle_sha256": bundle_sha, "checks": checks, "passed": sum(row["passed"] for row in checks),
               "total": len(checks), "fresh_recipient": recipient["verification"],
               "ordinary_library": ordinary["verification"], "generic_cases_first": len(bank),
               "generic_cases_exact_reuse": 0, "fresh_mission_check_executed": True,
               "actual_frontier_calls": 0, "actual_customer_collections": 0, "actual_complete_research_cost": None,
               "production_admission": "NOT_QUALIFIED_UNSUPPORTED_SCIENTIFIC_SCOPE",
               "alpha_admission": "NOT_ESTABLISHED; positive monetary fixture only exercises transport",
               "authority": "local ephemeral configured roles; simulated agent names; no ENS RPC",
               "graph_specific_value": "not established; same-content ordinary library is the parity control",
               "unmeasured": ["live operation", "field resilience", "customer acceptance", "total cost reduction",
                              "autonomous source invention", "frontier-model quality", "independent organizational review"]}
    save(out / "summary.json", summary)
    return summary


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--artifact", type=Path, required=True)
    parser.add_argument("--mission", type=Path, required=True)
    parser.add_argument("--qualification", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    result = run(args.artifact.resolve(), args.mission.resolve(), args.qualification.resolve(), args.out.resolve())
    print(json.dumps({key: result[key] for key in ["passed", "total", "bundle_sha256", "production_admission"]}))
    raise SystemExit(0 if result["passed"] == result["total"] else 1)
