# Executable inheritance, fresh meaning and accounting

This study reuses the unchanged parent research lifecycle and native Journal, TrustRegistry and CostLedger. It does not create a registry, extend production scientific scope, change Jobs roles, or grant live ENS authority.

## What is actually transferred

`run_integration.py` binds and packages **instrument.py, verifier.py, mission_schema.json and the frozen artifact policy**, plus a hash manifest. The five-file ZIP passes through the parent's AES-GCM fixture lifecycle and is recovered byte for byte. The recipient extracts only the closed ordinary-file allowlist and invokes the recovered executable in a separate Python process. NumPy, SciPy and Python are already installed; their exact local file inventories and interpreter identity are recorded. Those dependencies are required compatible infrastructure, not newly transferred intelligence.

The artifact is researcher-engineered executable construction, not a prose summary. Its selected development policy is transferred for experimental inspection, even though that policy is **not admitted learned Alpha**. Artificial positive monetary pairs reach transport/access branches only. They do not overturn the primary negative admission decision or authorize production.

The current local result is `results/source-qualified-replay-v2/summary.json`: **48/48 control checks**. This name denotes a local source-bound replay, not full repository or release qualification. The earlier `results/confirmation-v1/` is retained. The second run follows strict-typing corrections to the integration wrapper; it repeats the same previously declared recipient case and is not another independent fresh scientific sample.

The executable bundle is SHA-256 `09635678c16703655f4888fac2386c7504c85ad884c9c603e6d36f0e3b6d2d0e` in both runs.

## Inheritance does not inherit acceptance

The evaluator-owned, process-local generic test cache binds executable source, artifact, schema, installed numerical dependencies, evaluator, supported scopes, qualification bank and reuse policy. It stores finite generic qualification receipts only. Four generic cases execute initially, zero repeat under the exact identity, and all four execute again after a policy change. Generic correctness includes correctly refusing a capital-budget criterion; it does not demand that every test offering be economically feasible.

Every new mission still receives a fresh input/purpose/schema/output check. Generic-case reuse is not a reduction in total work: source hashing, process startup, numerical execution, fresh verification and permission checking remain. No customer cost saving is inferred from the 4-to-0 count.

The originally declared fresh recipient is water-delivery mission seed 992713. Its independently checked dispatch satisfies the modeled physical equations, but its capital requirement is **CAD 121,115.51**, above its unchanged **CAD 70,000** ceiling. Acceptance remains **false**. The separate dual certificate in the technical results confirms within-model budget infeasibility. The ordinary library with identical executable contents and permissions returns identical scientific output and the same refusal. No graph premium or new feasible offering follows from this transfer case.

Changed purpose, changed inputs and changed acceptance reject the old receipt and old authority. The newly signed local mission grant binds the complete current mission, capability identity, recipient, right, time interval and single-use nonce. It uses the unchanged native Ed25519 trust implementation. Expiry, revocation, retrieval-only rights, signature mutation and replay controls refuse. These are ephemeral configured roles in one research process, with fictional agent names. They are neither live ENS membership nor durable production authorization. Revocation prevents new mediated access; it cannot erase an already received copy.

## Reproduce in a new output directory

From the repository root:

```sh
python studies/agi-alpha-economic-construction-v3/integration/run_integration.py \
  --artifact studies/agi-alpha-economic-construction-v3/technical/results/artifact.json \
  --mission studies/agi-alpha-economic-construction-v3/technical/results/fresh_recipient_mission.json \
  --qualification studies/agi-alpha-economic-construction-v3/technical/results/qualification_missions.json \
  --out /absolute/new/inheritance-replay
python -m unittest discover -s studies/agi-alpha-economic-construction-v3/integration -p 'test_*.py' -v
```

The output directory must be new. Existing attempts and receipts are never overwritten. The scripts require the unchanged parent study at `studies/agi-alpha-capability-opportunity-v1/integration/`; its five adapter sources and 29 vendored upstream files are verified before use. Runtime source is pinned to `80b345828f34fd8a6e592977dd17ef37141305f4`, research parent to `231834269599d85e49cfe1ca9917a1a874522d44`.

## CAD timing and native USD accounting

`replay_cad.py` independently reconstructs the authoritative economic event stream in exact CAD cents. A deposit is restricted and unearned; contractual activation changes permitted use without creating revenue. Release cannot exceed that specific mission's activated unearned balance. Expenses, stage releases, returns, collections, receivables, refunds and reserves remain individually visible. Duplicate IDs, incorrect balances, premature releases and expenditure beyond authorized available cash refuse.

The existing native CostLedger has a literal USD denomination and does not represent customer-advance liabilities. Its scope therefore remains **settled totals**, with an explicit assumed conversion of **0.72 USD per CAD**. This fixed interface assumption is not a current foreign-exchange quote. Every original CAD event is separately signed and preserved using the existing native Journal; that record, not the USD projection, describes cash timing. Projection requires advances and invoices to have settled.

Modeled all-in expenses are disjoint by A/B/C and grouped in the native overhead category. Other categories attest that no additional separated amount exists in this aggregate scenario; they do not assert that actual models, people or tools are free. Seed capital is separate from earned collections. Net customer refunds reduce settled collections. The native totals reconcile to the CAD ledger after conversion. A separate actual-research replay retains an unknown C expense, zero observed customer collections, unknown complete-cost profit and unknown available funds.

```sh
python studies/agi-alpha-economic-construction-v3/integration/replay_cad.py \
  --input /absolute/final/primary.json --arm selective_sharing --seed 900100 \
  --out /absolute/new/settled-accounting-replay
```

The fifteen targeted tests exercise transport tampering/path traversal, all declared generic identity dimensions, mutable receipt isolation, fresh meaning/authority, expired and revoked grants, advances, cross-mission fee release, duplicates, explicit FX, unknown actual research cost, and independent verification of the exported signed CAD journal. Ruff passes and the three integration runtime modules pass strict mypy with imports skipped. Those local checks do not establish full repository CI, production deployment, organizational independence, field resilience, customer acceptance, actual profitability or current-frontier superiority.
