# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import hashlib
import json
import math
from typing import Any

CAPACITIES = ("pv_kw", "battery_kwh", "battery_kw", "generator_kw", "pump_kw", "tank_m3")
SCHEMA = "microgrid-purpose-mission-v1"


def digest(value: Any) -> str:
    return hashlib.sha256(
        json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
    ).hexdigest()


def validate_mission(mission: dict[str, Any]) -> None:
    if mission.get("schema") != SCHEMA or mission.get("purpose") not in ("critical_electricity", "water_delivery"):
        raise ValueError("unsupported current mission schema or purpose")
    h = mission["hours"]
    if type(h) is not int or not 1 <= h <= 168 or not 1 <= len(mission["scenarios"]) <= 64:
        raise ValueError("mission dimensions outside bounded instrument scope")
    if mission.get("dt_hours") != 1.0:
        raise ValueError("instrument supports one-hour intervals only")
    for name in CAPACITIES:
        bounds = mission["capacity_bounds"][name]
        if len(bounds) != 2 or not 0 <= bounds[0] <= bounds[1] <= 10000:
            raise ValueError("invalid finite capacity bounds")
        if not 0 < mission["capex_cad"][name] < 100000:
            raise ValueError("invalid positive capacity price")
    p = mission["physics"]
    for name in ("eta_charge", "eta_discharge"):
        if not 0 < p[name] <= 1:
            raise ValueError("invalid conversion efficiency")
    for name in (
        "soc_initial_fraction",
        "soc_terminal_fraction",
        "soc_min_fraction",
        "tank_initial_fraction",
        "tank_terminal_fraction",
        "tank_min_fraction",
    ):
        if not 0 <= p[name] <= 1:
            raise ValueError("invalid storage fraction")
    if not 0 < p["pump_m3_per_kwh"] <= 100:
        raise ValueError("invalid pump conversion")
    names = []
    for s in mission["scenarios"]:
        names.append(s["id"])
        for name in ("load_kw", "pv_factor", "generator_availability", "water_demand_m3"):
            xs = s[name]
            if len(xs) != h or any(not isinstance(x, (float, int)) or not math.isfinite(x) or x < 0 for x in xs):
                raise ValueError("invalid finite nonnegative scenario series")
        if max(s["pv_factor"]) > 1 or max(s["generator_availability"]) > 1:
            raise ValueError("availability exceeds unity")
        if not math.isfinite(s["generator_energy_limit_kwh"]) or s["generator_energy_limit_kwh"] < 0:
            raise ValueError("invalid fuel-energy budget")
    if len(set(names)) != len(names):
        raise ValueError("scenario IDs must be unique")
    if mission["purpose"] == "critical_electricity":
        if any(any(s["water_demand_m3"]) for s in mission["scenarios"]):
            raise ValueError("water requirements require fresh water mission semantics")
    digest(mission)


def verify(mission: dict[str, Any], receipt: dict[str, Any], tolerance: float = 1e-5) -> dict[str, Any]:
    errors: list[str] = []
    residuals: dict[str, float] = {}
    try:
        validate_mission(mission)
        if receipt.get("mission_sha256") != digest(mission):
            errors.append("mission identity mismatch")
        if receipt.get("purpose") != mission["purpose"] or receipt.get("mission_schema") != SCHEMA:
            errors.append("fresh purpose/schema mismatch")
        caps = receipt["capacities"]
        h, p = mission["hours"], mission["physics"]
        for name in CAPACITIES:
            lo, hi = mission["capacity_bounds"][name]
            value = float(caps[name])
            if not math.isfinite(value) or value < lo - tolerance or value > hi + tolerance:
                errors.append("capacity bound: " + name)
        capex = sum(float(caps[k]) * mission["capex_cad"][k] for k in CAPACITIES)
        if abs(capex - receipt["capex_cad"]) > tolerance * max(1, capex):
            errors.append("capex recomputation mismatch")
        outputs = receipt["dispatch"]
        if set(outputs) != {s["id"] for s in mission["scenarios"]}:
            errors.append("missing or extra scenarios")

        def record(name: str, value: float) -> None:
            residuals[name] = max(residuals.get(name, 0.0), abs(float(value)))

        def exceed(name: str, value: float) -> None:
            residuals[name] = max(residuals.get(name, 0.0), max(0.0, float(value)))

        for s in mission["scenarios"]:
            d = outputs[s["id"]]
            for name in ("pv_used_kw", "generator_kw", "charge_kw", "discharge_kw", "pump_kw"):
                if len(d[name]) != h:
                    raise ValueError("dispatch horizon mismatch")
            for name in ("soc_kwh", "tank_m3"):
                if len(d[name]) != h + 1:
                    raise ValueError("storage horizon mismatch")
            for xs in d.values():
                if not isinstance(xs, list) or any(not math.isfinite(float(x)) for x in xs):
                    raise ValueError("nonfinite dispatch")
                for x in xs:
                    exceed("nonnegative", -x)
            record("initial_soc", d["soc_kwh"][0] - p["soc_initial_fraction"] * caps["battery_kwh"])
            exceed("terminal_soc", p["soc_terminal_fraction"] * caps["battery_kwh"] - d["soc_kwh"][-1])
            record("initial_tank", d["tank_m3"][0] - p["tank_initial_fraction"] * caps["tank_m3"])
            exceed("terminal_tank", p["tank_terminal_fraction"] * caps["tank_m3"] - d["tank_m3"][-1])
            exceed("fuel_energy", sum(d["generator_kw"]) - s["generator_energy_limit_kwh"])
            for t in range(h):
                pv, gen, ch, dis, pump = (
                    d[k][t] for k in ("pv_used_kw", "generator_kw", "charge_kw", "discharge_kw", "pump_kw")
                )
                record("electric_balance", pv + gen + dis - ch - pump - s["load_kw"][t])
                record(
                    "battery_balance",
                    d["soc_kwh"][t + 1] - d["soc_kwh"][t] - p["eta_charge"] * ch + dis / p["eta_discharge"],
                )
                record(
                    "water_balance",
                    d["tank_m3"][t + 1] - d["tank_m3"][t] - p["pump_m3_per_kwh"] * pump + s["water_demand_m3"][t],
                )
                exceed("pv_capacity", pv - caps["pv_kw"] * s["pv_factor"][t])
                exceed("generator_capacity", gen - caps["generator_kw"] * s["generator_availability"][t])
                exceed("inverter_capacity", ch + dis - caps["battery_kw"])
                exceed("pump_capacity", pump - caps["pump_kw"])
            for value in d["soc_kwh"]:
                exceed("soc_capacity", value - caps["battery_kwh"])
                exceed("soc_floor", p["soc_min_fraction"] * caps["battery_kwh"] - value)
            for value in d["tank_m3"]:
                exceed("tank_capacity", value - caps["tank_m3"])
                exceed("tank_floor", p["tank_min_fraction"] * caps["tank_m3"] - value)
        errors += ["constraint residual: " + name for name, value in residuals.items() if value > tolerance]
        physical = not errors
        budget = capex <= mission["acceptance"]["max_capex_cad"] + tolerance
        elapsed = receipt.get("stats", {}).get("wall_seconds", math.inf)
        deadline = math.isfinite(elapsed) and 0 <= elapsed <= mission["acceptance"]["max_compute_seconds"]
        return {
            "physical_pass": physical,
            "budget_pass": budget,
            "deadline_pass": deadline,
            "accepted": physical and budget and deadline,
            "max_residual": max(residuals.values(), default=0.0),
            "residuals": residuals,
            "errors": errors,
            "recomputed_capex_cad": capex,
            "meaning": "all original hourly electric and water service constraints over supplied scenarios only",
        }
    except (KeyError, TypeError, ValueError, OverflowError) as error:
        return {"physical_pass": False, "accepted": False, "errors": errors + [str(error)], "max_residual": None}
