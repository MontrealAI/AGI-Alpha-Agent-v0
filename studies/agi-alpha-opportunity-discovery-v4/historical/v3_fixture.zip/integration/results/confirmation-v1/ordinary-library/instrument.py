# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import argparse
import hashlib
import json
import time
from pathlib import Path
from typing import Any

import numpy as np
from scipy.optimize import linprog
from scipy.sparse import coo_matrix

from verifier import CAPACITIES, SCHEMA, digest, validate_mission, verify


def make_lp(
    mission: dict[str, Any], indices: list[int], formulation: str, fixed: dict[str, float] | None = None
) -> tuple[Any, ...]:
    h, p = mission["hours"], mission["physics"]
    stride = 7 * h + 2
    n = 6 + len(indices) * stride
    c = np.zeros(n)
    bounds = [tuple(mission["capacity_bounds"][name]) for name in CAPACITIES] + [(0.0, None)] * (n - 6)
    for j, name in enumerate(CAPACITIES):
        c[j] = mission["capex_cad"][name] if fixed is None else 0.0
        if fixed is not None:
            bounds[j] = (fixed[name], fixed[name])
    eq_r: list[int] = []
    eq_c: list[int] = []
    eq_v: list[float] = []
    eq_b: list[float] = []
    ub_r: list[int] = []
    ub_c: list[int] = []
    ub_v: list[float] = []
    ub_b: list[float] = []

    def eq(items: list[tuple[int, float]], rhs: float) -> None:
        for col, value in items:
            eq_r.append(len(eq_b))
            eq_c.append(col)
            eq_v.append(value)
        eq_b.append(rhs)

    def ub(items: list[tuple[int, float]], rhs: float = 0.0) -> None:
        for col, value in items:
            ub_r.append(len(ub_b))
            ub_c.append(col)
            ub_v.append(value)
        ub_b.append(rhs)

    for k, index in enumerate(indices):
        s = mission["scenarios"][index]
        start = 6 + k * stride
        pv, gen, ch, dis, pump, soc, tank = (
            start,
            start + h,
            start + 2 * h,
            start + 3 * h,
            start + 4 * h,
            start + 5 * h,
            start + 6 * h + 1,
        )
        eq([(soc, 1), (1, -p["soc_initial_fraction"])], 0)
        eq([(tank, 1), (5, -p["tank_initial_fraction"])], 0)
        ub([(soc + h, -1), (1, p["soc_terminal_fraction"])])
        ub([(tank + h, -1), (5, p["tank_terminal_fraction"])])
        ub([(gen + t, 1) for t in range(h)], s["generator_energy_limit_kwh"])
        for t in range(h):
            eq([(pv + t, 1), (gen + t, 1), (ch + t, -1), (dis + t, 1), (pump + t, -1)], s["load_kw"][t])
            eq([(soc + t + 1, 1), (soc + t, -1), (ch + t, -p["eta_charge"]), (dis + t, 1 / p["eta_discharge"])], 0)
            eq([(tank + t + 1, 1), (tank + t, -1), (pump + t, -p["pump_m3_per_kwh"])], -s["water_demand_m3"][t])
            ub([(pv + t, 1), (0, -s["pv_factor"][t])])
            ub([(gen + t, 1), (3, -s["generator_availability"][t])])
            ub([(ch + t, 1), (dis + t, 1), (2, -1)])
            ub([(pump + t, 1), (4, -1)])
            if formulation == "inflexible_pumping":
                eq([(pump + t, p["pump_m3_per_kwh"])], s["water_demand_m3"][t])
        for t in range(h + 1):
            ub([(soc + t, 1), (1, -1)])
            ub([(soc + t, -1), (1, p["soc_min_fraction"])])
            ub([(tank + t, 1), (5, -1)])
            ub([(tank + t, -1), (5, p["tank_min_fraction"])])
    a_eq = coo_matrix((eq_v, (eq_r, eq_c)), shape=(len(eq_b), n)).tocsr()
    a_ub = coo_matrix((ub_v, (ub_r, ub_c)), shape=(len(ub_b), n)).tocsr()
    return c, a_ub, np.array(ub_b), a_eq, np.array(eq_b), bounds


def solve_lp(
    mission: dict[str, Any],
    indices: list[int],
    formulation: str,
    fixed: dict[str, float] | None,
    records: list[dict[str, Any]],
) -> Any:
    start = time.perf_counter()
    cpu = time.process_time()
    c, a_ub, b_ub, a_eq, b_eq, bounds = make_lp(mission, indices, formulation, fixed)
    result = linprog(
        c,
        A_ub=a_ub,
        b_ub=b_ub,
        A_eq=a_eq,
        b_eq=b_eq,
        bounds=bounds,
        method="highs",
        options={"time_limit": 30.0, "dual_feasibility_tolerance": 1e-7, "primal_feasibility_tolerance": 1e-7},
    )
    records.append(
        {
            "kind": "design" if fixed is None else "separation",
            "scenario_indices": indices,
            "status": int(result.status),
            "success": bool(result.success),
            "variables": len(c),
            "equalities": len(b_eq),
            "inequalities": len(b_ub),
            "matrix_nonzeros": int(a_eq.nnz + a_ub.nnz),
            "iterations": int(result.nit),
            "wall_seconds": time.perf_counter() - start,
            "cpu_seconds": time.process_time() - cpu,
            "objective": float(result.fun) if result.success else None,
        }
    )
    return result


def unpack(mission: dict[str, Any], indices: list[int], values: Any) -> dict[str, Any]:
    h, stride = mission["hours"], 7 * mission["hours"] + 2
    outputs = {}
    for k, index in enumerate(indices):
        start = 6 + k * stride
        output = {}
        for offset, name in enumerate(("pv_used_kw", "generator_kw", "charge_kw", "discharge_kw", "pump_kw")):
            output[name] = values[start + offset * h : start + (offset + 1) * h].tolist()
        output["soc_kwh"] = values[start + 5 * h : start + 6 * h + 1].tolist()
        output["tank_m3"] = values[start + 6 * h + 1 : start + 7 * h + 2].tolist()
        outputs[mission["scenarios"][index]["id"]] = output
    return outputs


def rank_scenarios(mission: dict[str, Any], rule: str) -> list[int]:
    p = mission["physics"]
    scores = []
    for i, s in enumerate(mission["scenarios"]):
        demand = np.array(s["load_kw"]) + np.array(s["water_demand_m3"]) / p["pump_m3_per_kwh"]
        score = max(demand) if rule == "peak_first" else sum(demand) / (0.5 + sum(s["pv_factor"]))
        scores.append((float(score), i))
    return [i for _, i in sorted(scores, reverse=True)]


def run(
    mission: dict[str, Any],
    policy: str = "all_scenarios",
    formulation: str = "service_storage",
    artifact_sha256: str | None = None,
) -> dict[str, Any]:
    validate_mission(mission)
    if policy not in ("all_scenarios", "energy_first", "peak_first", "two_first"):
        raise ValueError("unknown frozen policy")
    if formulation not in ("service_storage", "inflexible_pumping"):
        raise ValueError("unsupported supplied formulation")
    start, cpu = time.perf_counter(), time.process_time()
    records: list[dict[str, Any]] = []
    n = len(mission["scenarios"])
    order = rank_scenarios(mission, policy)
    selected = list(range(n)) if policy == "all_scenarios" else order[: 2 if policy == "two_first" else 1]
    outputs = {}
    for _ in range(n + 1):
        result = solve_lp(mission, selected, formulation, None, records)
        if not result.success:
            return {
                "mission_sha256": digest(mission),
                "purpose": mission["purpose"],
                "policy": policy,
                "status": "infeasible_or_solver_failure",
                "solver_status": int(result.status),
                "accepted": False,
                "stats": {"wall_seconds": time.perf_counter() - start, "solves": records},
            }
        capacities = {name: float(result.x[j]) for j, name in enumerate(CAPACITIES)}
        outputs = unpack(mission, selected, result.x)
        failed = []
        for i in order:
            if i in selected:
                continue
            check = solve_lp(mission, [i], formulation, capacities, records)
            if check.success:
                outputs.update(unpack(mission, [i], check.x))
            else:
                failed.append(i)
        if not failed:
            break
        selected.append(failed[0])
    receipt = {
        "schema": "microgrid-purpose-receipt-v1",
        "mission_schema": SCHEMA,
        "mission_sha256": digest(mission),
        "mission_id": mission["id"],
        "purpose": mission["purpose"],
        "artifact_sha256": artifact_sha256,
        "policy": policy,
        "formulation": formulation,
        "capacities": capacities,
        "capex_cad": sum(capacities[k] * mission["capex_cad"][k] for k in CAPACITIES),
        "dispatch": outputs,
        "status": "constructed",
        "active_scenarios": selected,
        "optimality_basis": "subset optimum plus feasibility on every supplied scenario; common capex objective",
        "stats": {
            "wall_seconds": time.perf_counter() - start,
            "cpu_seconds": time.process_time() - cpu,
            "solve_count": len(records),
            "design_solve_count": sum(r["kind"] == "design" for r in records),
            "separation_solve_count": sum(r["kind"] == "separation" for r in records),
            "variables_processed": sum(r["variables"] for r in records),
            "nonzeros_processed": sum(r["matrix_nonzeros"] for r in records),
            "max_variables": max(r["variables"] for r in records),
            "solves": records,
        },
        "scope": "bounded synthetic outage prefeasibility; no live control, customer sale, field certification, or novel LP",
    }
    receipt["verification"] = verify(mission, receipt)
    receipt["accepted"] = receipt["verification"]["accepted"]
    return receipt


def verify_artifact(path: Path) -> dict[str, Any]:
    artifact: dict[str, Any] = json.loads(path.read_text())
    if artifact.get("schema") != "microgrid-purpose-capability-v1":
        raise ValueError("unknown artifact schema")
    for name, expected in artifact["source_sha256"].items():
        if name not in ("instrument.py", "verifier.py", "mission_schema.json"):
            raise ValueError("unsupported artifact dependency")
        if hashlib.sha256(Path(__file__).with_name(name).read_bytes()).hexdigest() != expected:
            raise ValueError("capability implementation identity changed: " + name)
    if set(artifact["source_sha256"]) != {"instrument.py", "verifier.py", "mission_schema.json"}:
        raise ValueError("incomplete capability identity")
    return artifact


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--artifact", type=Path, required=True)
    parser.add_argument("--mission", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    artifact = verify_artifact(args.artifact)
    mission = json.loads(args.mission.read_text())
    if mission["purpose"] not in artifact["scope"]:
        raise ValueError("capability out of scope for current mission")
    receipt = run(
        mission, artifact["policy"], artifact["formulation"], hashlib.sha256(args.artifact.read_bytes()).hexdigest()
    )
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(receipt, sort_keys=True, indent=2, allow_nan=False) + "\n")
    print(json.dumps({"out": str(args.out), "accepted": receipt["accepted"], "status": receipt["status"]}))


if __name__ == "__main__":
    main()
