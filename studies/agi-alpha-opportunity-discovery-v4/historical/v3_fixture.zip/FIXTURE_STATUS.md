# Preserved fixture: direction changed before flagship selection

The author explicitly rejected community microgrid planning and the familiar storage-tank substitution as this edition's flagship. This directory preserves completed engineering work and a failed additional-Alpha candidate. It is historical fixture evidence, not the selected new opportunity.

The controller had chosen a numerical domain before completing an opportunity dossier. The new study corrects that process openly; it does not rename this result as a Blue Sky discovery.

## Executed boundaries

- Twelve development tasks and thirty-six frozen technical confirmation tasks. The conventional tank-aware expert solves the original purpose. The proposed scenario policy does not improve acceptance and increases counted matrix work.
- One of nine water cases crosses the predeclared capital threshold relative to an inflexible-pumping diagnostic. The expert already has the correct formulation; this is not E+ superiority.
- Independent physical residual checks and eighty-two post-confirmation numerical primal/dual certificate checks. The latter certify the compiled LP, not field infrastructure.
- Forty-eight executable inheritance controls, encrypted fixture transfer, separate signed local authority, fresh water mission refusal, and identical-content library parity. No production scope or live ENS admission.
- Fresh hosted U, E and E+ respondents each accept twelve of twelve small service-contract tasks. No quality difference is established. All used zero computation calls; tokens, elapsed time and complete attributable cost are unknown. The batch has a ceiling, not a frontier-model capability limit.
- Economic development prototypes v0 and v1 are retained, including corrected advance/fee accounting. No primary economic confirmation was run. No simulated-profit finding from these prototypes is promoted into the flagship.

The latest user instructions require an opportunity dossier, primary-source prior-art and market investigation, then a consequential testable selection before further flagship coding or publication. The new path is `../agi-alpha-opportunity-discovery-v4/`.

Actual customer collections: zero. Actual attributable research cost: unknown. Author attribution remains Vincent Boucher, President of MONTREAL.AI. Existing studies and release owners are preserved.
