AGI ALPHA FLYWHEEL — When Capability Creates Opportunity
Additive research edition v4 — Vincent Boucher, President of MONTREAL.AI

This archive contains the new study only. Preserve or clone the parent
repository commit 231834269599d85e49cfe1ca9917a1a874522d44, then overlay
the studies/ directory without replacing different existing files.
Read studies/agi-alpha-opportunity-discovery-v4/README.md and
REPRODUCIBILITY.md. Run prepare_reproduction.py to restore exact historical
and compressed evidence before numerical reproduction.

Compiled PDFs, figures and standalone HTML are separate downloads
in the same repository publication directory. This ZIP preserves
their manuscript/build sources and all implementation/data evidence.
Those reading editions need no experiment dependencies. Publication
reveals the former protected evaluation; future claims need fresh tests.
Actual earned customer revenue is zero. Markets and finance are modeled.
