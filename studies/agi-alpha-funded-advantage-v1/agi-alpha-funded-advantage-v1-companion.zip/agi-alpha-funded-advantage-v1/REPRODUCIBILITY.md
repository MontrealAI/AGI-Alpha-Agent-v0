# Offline reproduction

From the extracted study directory, use an existing Node.js and Python installation:

```sh
python3 reproduce.py --output /absolute/path/to/a-new-output-directory
```

The reference runtime is **Node.js 24.22.1 and Python 3.12.14**. The runner permits
Node.js 22.17.1 or later and Python 3.11–3.13, and records the actual versions; the
reference run does not qualify other runtime combinations. The experiment and
audits use only their standard libraries and the 13 unchanged vendored files in
`protocol/DEPENDENCIES.json`. There is no package installation, model invocation,
credential requirement, source download, financial transaction or installed
operator profile in this replay.

The output directory must be new, absolute and outside the extracted study. The
runner refuses an existing directory. `--node /path/to/node` selects a particular
Node binary; `--timeout 600` sets a per-command time limit in seconds. The study
files and original outcomes are hashed before execution and checked again after
execution. Python bytecode writes are disabled in subprocesses.

## What runs

1. Verify every file in a root `FILE_MANIFEST.json`, `COMPANION_MANIFEST.json` or
   `MANIFEST.json`, if one is supplied. The runner always verifies the prospective
   freezes, candidate sources, dependency record, generation receipt and archived
   confirmation data, even without a complete archive manifest.
2. Run both frozen builders' development tests, retaining stdout and stderr.
3. Recreate the four confirmation datasets and their manifest from the archived
   public source bytes. Require byte-for-byte equality with the supplied data.
4. Execute the ordinary, Alpha and conventional arms through the actual vendored
   Alpha guide and Workbench. Write 192 fresh packs to the new output directory.
5. Run the four separately labeled wrapper-scope diagnostics, including empty
   input delivery and three downstream service-limit refusals.
6. Independently audit the fresh packs, exact comparison rows, CSV downloads,
   source identities and artifact hashes. This audit also checks the original
   preserved wrapper-diagnostic records; the new diagnostic replay is separately
   recorded and required to pass by the reproduction runner.
7. Recompute the finite economic scenarios from the new timing summary, then run
   the independent integer/Fraction economic audit.
8. Run the EN/FR demo's DOM-shim handler checks. These test interface behavior with
   a mock runtime and are separate from actual execution checks.
9. If `demo/build.py` and `demo/runtime-smoke.cjs` are supplied, rebuild the
   self-contained demo into `demo-build/` under the new output directory. Execute
   its actual statically bundled Alpha Workbench in Node, writing four complete
   packs and their artifacts to `demo-runtime-smoke/`. The smoke repeats J05 with
   both frozen candidates in English and French. It is one already evaluated
   example, four demonstration repetitions and **zero new confirmatory jobs**.
   A partial build/smoke pair fails; if both are absent in an earlier source
   snapshot, the receipt explicitly records `NOT_PRESENT`.

The three-arm experiment tests the unbundled actual runtime. The separate demo
smoke tests the rebuilt bundle and actual report languages. The UI shim tests
the handlers with a mock. None is browser rendering or installed-operator
acceptance. The demo rebuild uses the preserved primary result and economic
records so its narrative remains tied to the published evidence; the economic
replay separately uses the new execution timing summary.

The output contains a machine-readable `REPRODUCTION.json`, per-command logs,
input-file identities, regenerated datasets, result packs, pack audit, wrapper
diagnostics, economics, UI-shim receipt, and the rebuilt demo/runtime-smoke outputs
when those tools are present. On a failed step, the runner retains
its logs and writes a failed receipt; it does not report unexecuted later checks
as passes. The receipt hashes its output files, excluding itself to avoid a
self-referential digest.

## What is expected to reproduce

There are **16 underlying source-comparison jobs**, four representations per job
and three methods. Replaying them creates repeated evaluations of the same
archived evidence, not new customer jobs or fresh demand. Each arm should accept
all 64 representation evaluations, correctly refuse the same 24 prohibited
inputs and accept all eight secondary valid-boundary probes. The primary data
have two changed identities within J05; the remaining sampled subsets are
unchanged. Exact source identities, normalized rows, comparison semantics,
artifact digests and admission decisions are reproducible. The financial audit
checks conservation and source binding; observed collections remain unknown and
economic admission remains HOLD.

Wall time and subprocess timing vary across machines. They can change the
descriptive modeled compute costs, so the complete result files are not expected
to have identical byte hashes to the first timing run. The regeneration step,
by contrast, must reproduce all four input files and `DATA_MANIFEST.json` exactly.
The standalone demonstration is rebuilt from the preserved original evidence and
the three navigation links in `demo/BUILD_MANIFEST.json`; all four listed generated
artifact hashes must match. Those links are configuration, not network requests.

This is a replay of frozen software. It does not reproduce model-assisted
construction, authoring effort, model token consumption or unavailable bills. It
does not establish production security or clear any existing execution hold.

The preserved check under `evidence/reproduction-check/` predates addition of the
two demo-build/runtime-smoke steps. Its recorded `reproduce.py` hash and ten-step
logs identify the earlier tested version; they are intentionally unchanged and
do not claim that the extension ran in that check. A later replay's own receipt
records the final runner, included steps and outcomes.

## Manuscript and figures

The supplied PDF is a separate publication artifact. Rebuilding it requires a
local XeLaTeX installation with the packages declared in `publication/paper.tex`
and DejaVu fonts; rebuilding figures additionally requires Matplotlib. Those
tools are not required by `reproduce.py` and are not installed by it. To retain
the original publication files, copy `publication/` and `figures/` together into
a separate working directory before rebuilding, and run XeLaTeX there twice:

```sh
xelatex -interaction=nonstopmode -halt-on-error paper.tex
xelatex -interaction=nonstopmode -halt-on-error paper.tex
```

The scientific replay deliberately does not run the full repository test suite,
isolated CI, an installed Harness, approved-operator profiles or production.
