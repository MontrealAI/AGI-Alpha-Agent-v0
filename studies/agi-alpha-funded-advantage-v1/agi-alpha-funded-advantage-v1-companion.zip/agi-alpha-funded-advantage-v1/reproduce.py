#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Replay the archived finite study without a network or package installation.

Every subprocess uses the extracted study itself as its working directory. All
new reports, packs and command logs go to a new directory outside that study.
This replays frozen programs; it does not repeat model-assisted construction.
"""

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import platform
import re
import shutil
import subprocess
import sys
import time


class ReproductionError(RuntimeError):
    """A required reproduction check or command did not succeed."""


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def sha256(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def read_json(path):
    return json.loads(path.read_text(encoding='utf-8'))


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def require(condition, message):
    if not condition:
        raise ReproductionError(message)


def inventory(directory):
    """Hash every supplied regular file, including preserved original evidence."""
    files = {}
    for path in sorted(directory.rglob('*')):
        require(not path.is_symlink(), f'Symlink not supported in companion: {path}')
        if path.is_file():
            files[path.relative_to(directory).as_posix()] = {
                'sha256': sha256(path), 'bytes': path.stat().st_size,
            }
    return files


def relative_file(root, name):
    require(isinstance(name, str), 'Manifest filename must be a string')
    relative = PurePosixPath(name)
    require(name and not relative.is_absolute() and '..' not in relative.parts
            and '\\' not in name, f'Invalid manifest filename: {name!r}')
    path = root.joinpath(*relative.parts)
    require(path.is_file() and not path.is_symlink(), f'Missing regular file: {name}')
    require(path.resolve().is_relative_to(root), f'File leaves companion: {name}')
    return path


def verify_entries(root, entries, label):
    if isinstance(entries, dict):
        rows = [(name, value) for name, value in entries.items()]
    elif isinstance(entries, list):
        rows = [(entry['path'], entry) for entry in entries]
    else:
        raise ReproductionError(f'Unsupported {label} entries')
    for name, item in rows:
        expected = item if isinstance(item, str) else item['sha256']
        require(isinstance(expected, str) and re.fullmatch(r'[0-9a-f]{64}', expected),
                f'Invalid digest in {label}: {name}')
        path = relative_file(root, name)
        require(sha256(path) == expected, f'Hash mismatch in {label}: {name}')
        if isinstance(item, dict) and 'bytes' in item:
            require(path.stat().st_size == item['bytes'], f'Length mismatch in {label}: {name}')
    return {'record': label, 'verifiedFiles': len(rows)}


def verify_sources(root):
    records = []
    for name in ('protocol/FREEZE.json', 'protocol/CANDIDATE_FREEZE.json'):
        records.append(verify_entries(root, read_json(root / name)['files'], name))
    boundary = read_json(root / 'protocol/BOUNDARY_FREEZE.json')
    records.append(verify_entries(root, {boundary['file']: boundary['sha256']},
                                  'protocol/BOUNDARY_FREEZE.json'))
    records.append(verify_entries(root, read_json(root / 'protocol/DEPENDENCIES.json'),
                                  'protocol/DEPENDENCIES.json'))
    data = root / 'evidence/confirmation'
    manifest = read_json(data / 'DATA_MANIFEST.json')
    records.append(verify_entries(data, manifest['files'], 'confirmation/DATA_MANIFEST.json'))
    records.append(verify_entries(data, {'source-records.json': manifest['source_record_sha256']},
                                  'confirmation/source-records.json'))
    generation = read_json(data / 'GENERATION_RECEIPT.json')
    records.append(verify_entries(root / 'evaluation', generation['generation_programs'],
                                  'confirmation/GENERATION_RECEIPT.json:programs'))
    records.append(verify_entries(data, {'DATA_MANIFEST.json': generation['data_manifest_sha256']},
                                  'confirmation/GENERATION_RECEIPT.json:data'))
    for arm, expected in generation['candidate_freeze_observed'].items():
        records.append(verify_entries(root, {f'candidates/{arm}/normalize.mjs': expected},
                                      f'confirmation/GENERATION_RECEIPT.json:{arm}'))
    return records


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True,
                        help='New absolute output directory, outside the extracted study')
    parser.add_argument('--node', default='node', help='Node executable (default: node on PATH)')
    parser.add_argument('--timeout', type=int, default=600, help='Maximum seconds per command')
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    require(args.output.is_absolute(), '--output must be an absolute path')
    output = args.output.resolve()
    require(not output.exists(), f'Output already exists; choose a new directory: {output}')
    require(not output.is_relative_to(root), '--output must be outside the study directory')
    require(args.timeout > 0, '--timeout must be positive')
    output.mkdir(parents=True)
    logs = output / 'logs'
    logs.mkdir()
    started = time.perf_counter_ns()
    report = {
        'schema': 'funded-advantage-offline-reproduction/v1',
        'startedAtUtc': utc_now(), 'status': 'RUNNING',
        'studyRoot': str(root), 'output': str(output),
        'scope': 'LOCAL_FROZEN_PROGRAM_REPLAY',
        'networkCallsRequested': 0, 'packageInstallationsRequested': 0,
        'runtime': {'python': platform.python_version(), 'pythonExecutable': sys.executable},
        'steps': [], 'fileVerification': [],
        'limitations': [
            'Replays the same archived 16 unique source-comparison jobs; repetitions are not new jobs or demand.',
            'Does not repeat model-assisted construction, its model calls, unmetered authoring, or billed inference.',
            'Timing values vary by runtime and host; modeled economic cost can change accordingly.',
            'UI checks use a DOM shim and mock runtime, not a browser or a production installation.',
            'Bundled-runtime checks, when included, repeat the existing J05 example in Node; they add no confirmatory jobs.',
            'The deep audit also checks preserved wrapper diagnostics; fresh wrapper diagnostics are separately rerun and verified here.',
            'No PDF rebuild, full repository test suite, installed Harness, isolated CI, approved operator, production, or financial transaction is executed.',
        ],
    }
    before = None
    env = dict(os.environ)
    # Select this interpreter for the ordinary-arm child and keep the archive immutable.
    env['PYTHON'] = sys.executable
    env['PYTHONDONTWRITEBYTECODE'] = '1'

    def run_step(name, command):
        number = len(report['steps']) + 1
        stdout = logs / f'{number:02d}-{name}.stdout.txt'
        stderr = logs / f'{number:02d}-{name}.stderr.txt'
        step = {'name': name, 'command': [str(arg) for arg in command],
                'startedAtUtc': utc_now(), 'stdout': stdout.relative_to(output).as_posix(),
                'stderr': stderr.relative_to(output).as_posix()}
        report['steps'].append(step)
        began = time.perf_counter_ns()
        print(f'[{number:02d}] {name}', flush=True)
        try:
            with stdout.open('wb') as out_stream, stderr.open('wb') as err_stream:
                completed = subprocess.run(step['command'], cwd=root, env=env,
                                           stdout=out_stream, stderr=err_stream,
                                           timeout=args.timeout, check=False)
            step['returnCode'] = completed.returncode
            require(completed.returncode == 0, f'{name} failed; inspect {stderr} and {stdout}')
        except subprocess.TimeoutExpired as error:
            step['timedOut'] = True
            raise ReproductionError(f'{name} exceeded {args.timeout} seconds') from error
        finally:
            step['endedAtUtc'] = utc_now()
            step['elapsedNanoseconds'] = time.perf_counter_ns() - began
        return stdout

    try:
        require((3, 11) <= sys.version_info[:2] < (3, 14), 'Python 3.11–3.13 required; reference is 3.12')
        node = shutil.which(args.node)
        require(node is not None, f'Node executable not found: {args.node}')
        version_log = run_step('node-version', [node, '--version'])
        version = version_log.read_text(encoding='utf-8').strip()
        match = re.fullmatch(r'v(\d+)\.(\d+)\.(\d+)', version)
        require(match is not None and tuple(map(int, match.groups())) >= (22, 17, 1),
                'Node.js 22.17.1 or later required; reference is 24.22.1')
        report['runtime'].update({'node': version, 'nodeExecutable': node,
                                 'referenceRuntimeFamily': sys.version_info[:2] == (3, 12)
                                 and int(match.group(1)) == 24})
        before = inventory(root)
        write_json(output / 'input-files.json', before)
        for name in ('FILE_MANIFEST.json', 'COMPANION_MANIFEST.json', 'MANIFEST.json'):
            path = root / name
            if path.exists():
                full = read_json(path)
                entries = full.get('files', full) if isinstance(full, dict) else full
                report['fileVerification'].append(verify_entries(root, entries, name))
        report['fullFileManifestPresent'] = bool(report['fileVerification'])
        report['fileVerification'].extend(verify_sources(root))
        write_json(output / 'source-verification.json', report['fileVerification'])
        run_step('alpha-development', [node, 'candidates/alpha/development-tests.mjs'])
        run_step('conventional-development', [node, 'candidates/conventional/development-tests.mjs'])
        run_step('regenerate-confirmation', [sys.executable, 'evaluation/generate.py',
                 '--sources', root / 'evidence/confirmation/source-records.json',
                 '--output', output / 'confirmation'])
        data_manifest = read_json(root / 'evidence/confirmation/DATA_MANIFEST.json')
        for name in (*data_manifest['files'], 'DATA_MANIFEST.json'):
            require((root / 'evidence/confirmation' / name).read_bytes()
                    == (output / 'confirmation' / name).read_bytes(),
                    f'Regenerated confirmation differs: {name}')
        report['regeneratedFilesByteIdentical'] = list(data_manifest['files']) + ['DATA_MANIFEST.json']
        run_step('three-arm-experiment', [node, 'implementation/run_experiment.mjs', output / 'results'])
        run_step('wrapper-scope-diagnostics', [node, 'evaluation/scope-probes.mjs',
                 '--output', output / 'WRAPPER_SCOPE_DIAGNOSTICS.json',
                 '--results', output / 'results/summary.json'])
        scope = read_json(output / 'WRAPPER_SCOPE_DIAGNOSTICS.json')
        require(scope['passed'] == scope['total'] == 4, 'Fresh wrapper diagnostics did not all pass')
        run_step('independent-pack-audit', [sys.executable, 'evaluation/audit.py',
                 '--results', output / 'results', '--output', output / 'AUDIT.json'])
        run_step('economic-scenarios', [node, 'economics/analyze.mjs',
                 '--out', output / 'economics', '--results', output / 'results/summary.json'])
        run_step('independent-economic-audit', [sys.executable, 'economics/audit.py',
                 output / 'economics', '--report', output / 'economics/audit.json'])
        ui_log = run_step('demo-ui-shim', [node, 'demo/ui-test.cjs'])
        ui = read_json(ui_log)
        require(ui['failed'] == 0 and ui['passed'] == ui['checks'], 'UI shim checks did not all pass')
        write_json(output / 'UI_SHIM.json', ui)
        demo_build = root / 'demo/build.py'
        demo_smoke = root / 'demo/runtime-smoke.cjs'
        bundled_demo = {'status': 'NOT_PRESENT', 'newConfirmatoryJobs': 0}
        if demo_build.exists() or demo_smoke.exists():
            require(demo_build.is_file() and demo_smoke.is_file(),
                    'Demo build and bundled-runtime smoke files must both be present')
            demo_command = [sys.executable, 'demo/build.py', '--output', output / 'demo-build']
            saved_demo_manifest = root / 'demo/BUILD_MANIFEST.json'
            if saved_demo_manifest.is_file():
                links = read_json(saved_demo_manifest)['links']
                for name in ('paper', 'source', 'companion'):
                    demo_command.extend([f'--{name}-link', links[name]])
            run_step('demo-build', demo_command)
            if saved_demo_manifest.is_file():
                for artifact in read_json(saved_demo_manifest)['artifacts']:
                    require(sha256(output / 'demo-build' / artifact['path']) == artifact['sha256'],
                            f"Rebuilt demo bytes differ: {artifact['path']}")
            run_step('demo-bundled-runtime', [node, 'demo/runtime-smoke.cjs',
                     '--bundle', output / 'demo-build/runtime_bundle.js',
                     '--data', output / 'demo-build/DEMO_DATA.json',
                     '--output', output / 'demo-runtime-smoke'])
            bundled_demo = read_json(output / 'demo-runtime-smoke/runtime-smoke.json')
            require(bundled_demo['passed'] is True, 'Actual bundled runtime checks did not pass')
            require(bundled_demo['newConfirmatoryJobs'] == 0
                    and bundled_demo['uniqueJobs'] == 1
                    and bundled_demo['repeatedDemonstrationEvaluations'] == 4,
                    'Bundled demo must retain the existing one-job/four-repetition accounting')
        summary = read_json(output / 'results/summary.json')
        pack_audit = read_json(output / 'AUDIT.json')
        economic_audit = read_json(output / 'economics/audit.json')
        require(pack_audit['passed'], 'Pack audit did not pass')
        require(economic_audit['status'] == 'PASS', 'Economic audit did not pass')
        report['results'] = {
            'uniqueJobsReplayed': summary['uniqueJobs'],
            'arms': summary['arms'], 'packAudit': pack_audit,
            'freshWrapperDiagnosticCount': scope['total'],
            'economicAudit': economic_audit,
            'uiShimChecks': ui['checks'], 'browser': 'NOT_RUN',
            'bundledDemo': bundled_demo,
        }
        report['status'] = 'PASS'
    except Exception as error:
        report['status'] = 'FAIL'
        report['error'] = {'type': type(error).__name__, 'message': str(error)}
    finally:
        if before is not None:
            try:
                after = inventory(root)
                changed = sorted(name for name in set(before) | set(after) if before.get(name) != after.get(name))
                report['inputFilesUnchanged'] = not changed
                report['changedInputFiles'] = changed
                if changed:
                    report['status'] = 'FAIL'
                    report['immutabilityError'] = 'Supplied study files changed during reproduction'
            except Exception as error:
                report['status'] = 'FAIL'
                report['immutabilityError'] = str(error)
        report['endedAtUtc'] = utc_now()
        report['elapsedNanoseconds'] = time.perf_counter_ns() - started
        report['outputFiles'] = inventory(output)
        write_json(output / 'REPRODUCTION.json', report)
    print(json.dumps({'status': report['status'], 'report': str(output / 'REPRODUCTION.json'),
                      'error': report.get('error')}, indent=2))
    return 0 if report['status'] == 'PASS' else 1


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except ReproductionError as error:
        print(f'Reproduction refused: {error}', file=sys.stderr)
        raise SystemExit(2)
