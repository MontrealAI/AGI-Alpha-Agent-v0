#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Create the complete deliverable set without changing supplied study files."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

ROOT = Path(__file__).resolve().parent
STEM = 'agi-alpha-funded-advantage-v1'
TITLE = 'AGI_ALPHA_The_Advantage_That_Funds_the_Next'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def selected_files():
    for path in sorted(ROOT.rglob('*')):
        if not path.is_file() or path.is_symlink():
            continue
        rel = path.relative_to(ROOT)
        if '__pycache__' in rel.parts or any(p.startswith('.') for p in rel.parts):
            continue
        if str(rel) == 'FILE_MANIFEST.json' or path.suffix == '.zip':
            continue
        if rel.parts[0] == 'publication' and (path.suffix in {'.aux', '.log', '.out', '.toc', '.synctex'} or path.name == 'compile.log'):
            continue
        yield rel, path


def zip_bytes(archive, name, data):
    info = zipfile.ZipInfo(name, (2026, 10, 25, 0, 0, 0))
    info.compress_type = zipfile.ZIP_DEFLATED
    info.external_attr = 0o100644 << 16
    archive.writestr(info, data, compresslevel=9)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    out = args.output.resolve()
    if out.exists() or out.is_relative_to(ROOT):
        raise ValueError('Output must be a new directory outside the study')
    out.mkdir(parents=True)
    files = list(selected_files())
    manifest = {'schema': 'funded-advantage-files/v1',
                'scope': 'Complete packaged study files; excludes this manifest, generated ZIPs, local TeX auxiliary logs and Python caches.',
                'files': {str(rel): {'sha256': digest(path.read_bytes()), 'bytes': path.stat().st_size}
                          for rel, path in files}}
    encoded = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode()
    (out / 'FILE_MANIFEST.json').write_bytes(encoded)
    with zipfile.ZipFile(out / f'{STEM}-companion.zip', 'w') as archive:
        for rel, path in files:
            zip_bytes(archive, f'{STEM}/{rel}', path.read_bytes())
        zip_bytes(archive, f'{STEM}/FILE_MANIFEST.json', encoded)
    latex_files = [(rel, path) for rel, path in files if
                   (rel.parts[0] == 'publication' and path.suffix in {'.tex', '.py', '.json', '.md'})
                   or rel.parts[0] == 'figures']
    with zipfile.ZipFile(out / f'{STEM}-latex.zip', 'w') as archive:
        for rel, path in latex_files:
            zip_bytes(archive, f'{STEM}/{rel}', path.read_bytes())
        instruction = ('Compile publication/paper.tex with XeLaTeX twice, keeping figures/ next to publication/.\n'
                       'The three TeX files and both PDF figures form the complete manuscript source.\n'
                       'Figure rebuilding additionally requires Matplotlib and NumPy; replay is in the companion.\n')
        zip_bytes(archive, f'{STEM}/BUILD.txt', instruction.encode())
    shutil.copyfile(ROOT / 'publication/paper.pdf', out / f'{TITLE}.pdf')
    shutil.copyfile(ROOT / 'publication/paper.tex', out / f'{TITLE}.tex')
    shutil.copyfile(ROOT / 'demo' / f'{TITLE}.html', out / f'{TITLE}.html')
    with zipfile.ZipFile(out / 'AGI_ALPHA_Fleet_Inventory_Example_EN_FR.zip', 'w') as archive:
        for language in ('en', 'fr'):
            for path in sorted((ROOT / 'demo/runtime-smoke-v1' / f'conventional-{language}').rglob('*')):
                if path.is_file():
                    rel = path.relative_to(ROOT / 'demo/runtime-smoke-v1' / f'conventional-{language}')
                    zip_bytes(archive, f'{language}/{rel}', path.read_bytes())
        zip_bytes(archive, 'README.txt', (
            'Actual conventional implementation through the Alpha Workbench, J05-V1, EN/FR.\n'
            'Eight paths per inventory; two changed SHA-256 identities; complete reports and packs.\n'
            'Repeated demonstration execution, not new unique work or commercial revenue.\n'
            'No source execution, automatic correction, transaction or production admission.\n').encode())
    delivery = {'schema': 'funded-advantage-delivery/v1',
                'createdAtUtc': datetime.now(timezone.utc).isoformat(),
                'studyFiles': len(files),
                'files': {p.name: {'sha256': digest(p.read_bytes()), 'bytes': p.stat().st_size}
                          for p in sorted(out.iterdir()) if p.is_file()}}
    (out / 'DELIVERY.json').write_text(json.dumps(delivery, indent=2) + '\n')
    (out / 'SHA256SUMS').write_text(''.join(f"{v['sha256']}  {n}\n" for n, v in delivery['files'].items()))
    print(json.dumps(delivery, indent=2))


if __name__ == '__main__':
    main()
