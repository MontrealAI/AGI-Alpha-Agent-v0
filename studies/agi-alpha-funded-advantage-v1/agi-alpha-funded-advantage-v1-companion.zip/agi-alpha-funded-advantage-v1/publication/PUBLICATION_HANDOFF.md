# Publication owner handoff — The Advantage That Funds the Next

Prepared from local source inspection on 26 October 2026 UTC. This document is an
assembly handoff, not an authorization to merge, release, deploy, transact or
override existing execution restrictions. Coordination remains in
[issue #4850](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/issues/4850), through
the existing research publication and software release owners.

## Identity and result

The edition ID is `agi-alpha-funded-advantage-v1`. Its exact PDF metadata title is
**AGI ALPHA FLYWHEEL: The Advantage That Funds the Next**. The author is **AGI
ALPHA research engineering study**, matching `publication/paper.tex`; the edition
date is 25 October 2026 in America/Toronto. The attached import metadata contains
English and French descriptions and uses only fields accepted by the existing
`add_paper` function in `scripts/research_papers.py`.

The paper reports a useful inventory preparation capability, 16 fresh comparison
requests and 64 representations per method, and equal technical acceptance across
the ordinary, Alpha and conventional arms. It does not establish material
incremental value, measured attention savings, complete monetary costs, realized
collections, production admission or sustained acceleration. Actual economic
admission remains **HOLD**. Positive financing cases depend on an expressly
unobserved benefit assumption and fund the same candidate that was tested.

`catalog-metadata.json` is **import metadata**, not a complete catalogue record.
The existing importer forbids `pdf` and `tex` fields in its metadata input and
computes those paths and SHA256 hashes from the final source bytes. No placeholder
hash, predicted final PDF hash or invented release URL is included. Keep this
metadata and this handoff in the companion; do not add them to the passive paper
PR's changed paths.

## Preserve the current publication history

The inspected base is `origin/main` at
`95d1e97d4d1c0aaebd592767fc5e5d2da56f6aa7`. Its
`docs/research-papers.json` has **22 records**, schema
`agialpha.research-papers.v2`, and SHA256
`fcef892bc3e2878b2ce9eccd9fcea77df9df7074802bb88f8a69c48c6dd3a531`.
This is a recorded snapshot, not permission to restore an old catalogue over a
newer one. Re-read the publication owner's actual base before assembly. Append
the new record to that catalogue and preserve every existing record, original
file identity, resource identity and featured-paper choice. An unchanged base
would have 23 records after this addition; intervening additions must also remain.

The existing split-lane precedent was inspected locally:

| Existing lane | Exact inspected commit | Scope |
| --- | --- | --- |
| [Paper draft #4913](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/pull/4913) | `ae37ea705b0df5e806b0553ada27c4cedba58c94` | New PDF/TeX, additive catalogue, generated paper surfaces |
| [Companion draft #4914](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/pull/4914) | `f1ea6bdb389c8f8952de66ef0934c69d63ef5820` | Versioned companion/source archives, source demonstration and execution receipts |

Preserve The Autonomous Work Economy, The Productive Capital Engine, The Economic
Engine and Build the Next Advantage, including their adverse results, URLs and
pending publication lanes. This new edition does not supersede or delay them.
Do not use a forced push, overwrite an original, rewrite earlier editions or
replace the catalogue with the 22-record snapshot.

## Lane A — additive passive paper draft

Use a clean owner-selected paper branch based on the appropriate current main.
Keep the study implementation, HTML, scripts, dependencies, archives and this
handoff out of its introduced history. The existing pre-change policy inspects
every introduced commit, not only the final diff.

With both PDF and TeX originals, the complete expected path list is eight files:

```text
README.md
docs/index.html
docs/research-papers.json
docs/papers/agi-alpha-funded-advantage-v1.pdf
docs/papers/agi-alpha-funded-advantage-v1.tex
docs/service-worker.js
docs/assets/service-worker.js
docs/alpha_factory_v1/demos/alpha_agi_insight_v1/service-worker.js
```

The existing pipeline also permits a PDF-only import, giving seven files. This
edition supplies the TeX original as well as the complete compilable source in
the companion, so the eight-file pattern is preferred. The TeX file references
`results-macros.tex`, `finance-results.tex` and two figures; copying the main TeX
alone does not produce a self-contained compilation. Do not give it the optional
`tex_source` resource label “standalone TeX.” The full LaTeX archive supplies all
dependencies. The paper importer stores TeX as opaque UTF-8 and does not execute
or compile it.

Use the existing commands from the paper checkout, with absolute paths to the
reviewed, final manuscript files in the separate study workspace:

```sh
python -m pip install --require-hashes --only-binary=:all: -r requirements-papers.lock
python -m scripts.research_papers add --pdf /absolute/study/publication/paper.pdf --tex /absolute/study/publication/paper.tex --metadata /absolute/study/publication/catalog-metadata.json
python -m scripts.research_papers check
git diff --stat
git diff --name-only
```

The importer appends the record, preserves exact original bytes, checks the PDF's
title and passive structure, and regenerates the README paper block, bilingual
homepage and three existing service workers. Do not hand-edit those generated
surfaces. If regeneration is needed, use `python -m scripts.research_papers
render`, then repeat `check`. A duplicate destination is an error, not permission
to overwrite an original. A revised publication after this edition is published
requires a new versioned identity.

Commit the complete reviewed eight-file change together. For a local history
proof after the commit, the existing CLI is:

```sh
python scripts/paper_changes.py --root /absolute/paper-checkout --base BASE_SHA --head HEAD_SHA --prove --output /absolute/receipts/paper-scope.json
```

`BASE_SHA` and `HEAD_SHA` must be actual full commit IDs. For an authoritative
pre-change-policy check, use the unchanged policy files extracted from the
trusted base, exactly as `.github/workflows/paper-scope.yml` does. A successful
check has `mode: paper`. CI, review and owner approval still govern merge.
The existing workflow uses squash merge for a complete paper-only transition
when intermediate upload commits would not prove the strict lane. Paper checks
do not provide full software acceptance.

## Lane B — companion and demonstration draft

Use a separate draft source/companion branch, following #4914. Keep the complete
reproducible edition under `studies/agi-alpha-funded-advantage-v1/`; an archive
must include the actual source, frozen candidates, observed failures, input
identities, independent expectations, costs, scenarios, complete ledgers,
dependency records, tests, figures, manuscript, bilingual demonstration and
reproduction entry point. It must preserve unknown authoring/inference costs and
distinguish original measurements from new replay timing.

For the compact archive-based pattern used by #4914, proposed versioned paths are:

```text
studies/agi-alpha-funded-advantage-v1/README.md
studies/agi-alpha-funded-advantage-v1/AGI_ALPHA_Funded_Advantage_Companion.zip
studies/agi-alpha-funded-advantage-v1/AGI_ALPHA_Funded_Advantage_LaTeX.zip
studies/agi-alpha-funded-advantage-v1/SHA256SUMS
studies/agi-alpha-funded-advantage-v1/EXECUTION_STATUS.json
studies/agi-alpha-funded-advantage-v1/ARCHIVE_REPRODUCTION_VALIDATION.json
studies/agi-alpha-funded-advantage-v1/DEMONSTRATION_PROJECTION.json
```

These are assembly destinations, not claims that all final packages already
exist. The source owner may additionally retain the unpacked source tree. If
including a website demonstration source as in #4914, use the new versioned path
`docs/reports/agi-alpha-funded-advantage-v1/index.html`, plus only the regenerated
workers the normal build actually changes. New or changed HTML is a **full
software qualification** change; it is not eligible for the passive paper lane.
A downloadable local demo may remain inside the companion while the public site
is held. Do not add an unqualified local experience to the paper catalogue.

Extract the finished companion into a fresh directory and run its documented
entry point:

```sh
python3 reproduce.py --output /absolute/new-output-directory
```

Record the actual exit status and generated receipts. The economics subcommands
are `node economics/analyze.mjs --out OUTPUT/economics --results
OUTPUT/results/summary.json` and `python3 economics/audit.py OUTPUT/economics
--report OUTPUT/economics/audit.json`. Do not substitute a replay for model
construction, a DOM handler check for a browser run, or source availability for
deployment. Re-run the archive extraction check after final archive contents
change and calculate checksums from the final bytes.

Do not invent a GitHub release asset URL. The owner may later add a canonical
resource only after verifying it exists and recording its exact hash/size and
source evidence. An `experimental_source` link, if used, must name the actual
immutable companion commit and versioned study README. A mutable `main` link
cannot replace that provenance. Any existing resource identity remains immutable.

## Remaining publication conditions

At handoff, `paper.pdf` is still an intermediate build while `paper.tex` is being
edited; the final reviewed PDF/TeX pair and final archive hashes have not been
sealed. The companion commit, PR numbers and release downloads are also not yet
known. Finalize those artifacts first; the importer will calculate honest hashes
without any placeholder metadata.

The locally available `pypdf` reports version **6.10.0**, while the inspected
`requirements-papers.lock` pins **6.21.2** with its exact wheel hash. Therefore a
check under the currently available package cannot be called validation with the
locked publisher dependency. Use the existing locked environment/CI for the
final passive PDF check; do not edit the lock to accommodate the local package.

The current paper metadata is suitable for the existing importer. Actual PDF
acceptance, the whole-history paper proof, full qualification of executable/demo
source, merge approval and served-byte publication are distinct remaining
conditions. The existing publication overlay defers while its software baseline
is not public or the required identities do not match. A draft PR or immutable
GitHub blob is not evidence that a PDF or demo is served on the public website.

All original Harness, Fleet, security, browser, approved-operator and production
restrictions remain unchanged. The manuscript's token language keeps Manager's
USDC route distinct from applicable AGIALPHA utility and claims no new holder
rights, distributions, buybacks or guaranteed returns. This study performs no
financial transaction; emissions, appreciation and customer savings are not
operating cash. No new review of a held execution path is requested by this
handoff.

## Source of this handoff

The governing local sources are `scripts/research_papers.py`,
`scripts/paper_changes.py`, `.github/workflows/paper-scope.yml`,
`docs/agent/PAPER_UPLOADS.md`, `requirements-papers.lock`, the original catalogue,
and the two exact prior branch commits above. This handoff proposes no new
publication mechanism and changes none of those sources.

## Publication base refresh — 26 October 2026 UTC

After the initial inspection above, the publication owner observed and fetched
new main commit `3b040e68adae8196f7bda4c65f92af92ee6f7335`, with tree
`f094ab019d0776b908168b8ec909fc3252b5501c`. The isolated passive-paper worktree
was moved to this exact commit before any new manuscript import. **Use this
24-record publication base, or a subsequently verified newer base, for the new
paper. Do not publish from the historical 22-record snapshot.**

The new catalogue SHA256 is
`ac92b33c74d25d56e24af1c5df43f4923ecef35b179bd263ca526c5ffd8fb595`.
Local comparison confirms all 22 historical records are exactly preserved; the
two additions are `agi-alpha-next-advantage-v1` and
`agi-alpha-autonomous-work-economy-v1`. Appending only this new edition to that
base produces 25 records. This preserves the newly published earlier papers and
does not change their original files or identities.

The publication helper, history classifier, paper-scope workflow, upload guide
and locked validator dependency are unchanged between the two inspected bases.
The new worktree is clean and its baseline `research_papers check` passes using
the available `pypdf 6.10.0`; the locked-environment qualification limitation
above still applies. No network request, dependency installation or remote write
was made by this preparation step. The owner performed the read-only fetch.

The technical study's original source pin remains
`95d1e97d4d1c0aaebd592767fc5e5d2da56f6aa7`. Updating the publication assembly
base does not revise the frozen scientific inputs, candidates, outcomes or
earlier 22-record inspection receipt.

## Provisional passive assembly completed

The final source-based manuscript repair was imported successfully into the
isolated 24-record publication base. The resulting catalogue has 25 records,
preserves all 24 predecessors exactly and contains no optional resource for the
new edition yet. Exactly eight passive files are staged. The unchanged catalogue,
PDF and render check passes with the available dependency; the unchanged trusted
tree-transition policy also passes. These are the provisional checks described
above, not locked-dependency or whole-history publication acceptance.

The complete file manifest, final manuscript hashes, staged tree identity and
check scope are in `publication/PUBLICATION_PRECHECK.json`. That receipt also
preserves two earlier import rejections: bare-hash URI links, repaired by changing
the TeX display to `nolinkurl`, and Type3 figure glyph dictionaries, repaired by
regenerating the figures with TrueType embedding. The owner corrected source and
recompiled; the validator was unchanged and no PDF was rewritten. If optional
immutable companion metadata is added later, regenerate the existing presentation
surfaces and record a new check snapshot rather than representing this
resource-free manifest as the final publication tree.
