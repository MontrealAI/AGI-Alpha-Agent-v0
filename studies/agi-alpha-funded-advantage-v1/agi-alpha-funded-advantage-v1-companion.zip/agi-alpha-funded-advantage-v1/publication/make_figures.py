# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import json, os
os.environ.setdefault('MPLCONFIGDIR', '/tmp/agi-alpha-funded-advantage-matplotlib')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'figures'
OUT.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'pdf.fonttype':42,'axes.spines.top':False,
                     'axes.spines.right':False,'axes.labelcolor':'#291941','text.color':'#291941',
                     'axes.titleweight':'bold','savefig.bbox':'tight','figure.facecolor':'white'})
summary = json.loads((ROOT/'evidence/results/summary.json').read_text())
names = ['ordinary','alpha','conventional']
labels = ['Ordinary recipes','Alpha asset','Conventional asset']
fig, axes = plt.subplots(1,2,figsize=(9.3,3.3),gridspec_kw={'width_ratios':[1,1.3]})
axes[0].barh(labels,[summary['arms'][n]['acceptedUniqueJobs'] for n in names],color=['#9F8CB6','#6734A8','#C7A96D'])
axes[0].set_xlim(0,18);axes[0].set_xticks([0,4,8,12,16]);axes[0].set_xlabel('Accepted unique source requests')
axes[0].set_title('Same useful outcomes',loc='left',fontsize=11)
for i in range(3):axes[0].text(16.3,i,'16/16',va='center',fontsize=9)
values=[summary['arms'][n]['medianEndToEndMicros']/1000 for n in names]
axes[1].barh(labels,values,color=['#9F8CB6','#6734A8','#C7A96D'])
axes[1].set_xlim(0,29);axes[1].set_xlabel('Median complete pack time (milliseconds)')
axes[1].set_title('No material timing advantage',loc='left',fontsize=11)
for i,v in enumerate(values):axes[1].text(v+.35,i,f'{v:.3f}',va='center',fontsize=9)
for ax in axes:ax.invert_yaxis();ax.grid(axis='x',alpha=.16);ax.set_axisbelow(True)
fig.tight_layout(w_pad=2)
fig.savefig(OUT/'confirmation.pdf');fig.savefig(OUT/'confirmation.png',dpi=200);plt.close(fig)

fig,ax=plt.subplots(figsize=(8.6,3.6))
jobs=np.array([16,52,104,208]);wage=36.73
for cost,color in [(20,'#9F8CB6'),(100,'#6734A8'),(500,'#AA7F31')]:
 seconds=cost/jobs/wage*3600
 ax.plot(jobs,seconds,'o-',lw=2,color=color,label=f'Complete upfront envelope: ${cost}')
ax.set_xscale('log',base=2);ax.set_yscale('log');ax.set_xticks(jobs,labels=[str(n) for n in jobs])
ax.set_xlabel('Finite number of subsequent jobs');ax.set_ylabel('Required avoided seconds per job')
ax.grid(alpha=.17);ax.legend(frameon=False,loc='upper right',fontsize=9)
ax.set_title('An admission threshold, not measured attention savings',loc='left',fontsize=12)
fig.text(.13,-.01,'At $36.73/hour; zero incremental upkeep and compute advantage. More costs raise the threshold.',fontsize=9,color='#5E5570')
fig.tight_layout();fig.savefig(OUT/'attention-threshold.pdf');fig.savefig(OUT/'attention-threshold.png',dpi=200);plt.close(fig)

records={n:summary['arms'][n] for n in names}
(OUT/'figure-data.json').write_text(json.dumps({'confirmation':records,'attention_frontier':{
 'wage_usd_per_hour':wage,'horizons':jobs.tolist(),'complete_upfront_envelopes_usd':[20,100,500],
 'incremental_upkeep_usd':0,'measured_attention_saving':None,'status':'COUNTERFACTUAL_THRESHOLD'}},indent=2)+'\n')
print(json.dumps({'figures':['confirmation.pdf','attention-threshold.pdf'],'status':'derived from preserved data and explicit threshold assumptions'}))
