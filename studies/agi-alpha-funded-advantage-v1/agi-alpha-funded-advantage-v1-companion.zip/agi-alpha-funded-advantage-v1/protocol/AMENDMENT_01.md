# Prospective boundary clarification

Sent identically to both builders and the independent evaluator before candidate
freeze and before confirmation generation. The original protocol hash is retained.

- Returned `format` is the family `json`, `csv`, or `sha256sum`.
- Root JSON value has depth zero; every child value increments depth by one.
- Path controls include C0, DEL and C1. Unpaired Unicode surrogates are refused.
- Scalar byte limits apply to decoded keys and string values, and numeric literals.
- Numeric JSON metadata must be finite.
- Empty source text is permitted only for explicit `sha256sum`; auto-empty refuses.
- Header-only CSV is an accepted empty inventory.

No outcome-informed method or acceptance change was made.
