# Prospective sampling and cache clarification

Recorded before independent confirmation generation and without outcome access.

The fixed sampling rule takes the first 32 lexicographic ordinary UTF-8 text
paths, excluding NUL-containing blobs and individual blobs above 100 kB. The
collector records exclusions. Four disjoint eight-file subsets per repository
form 16 source-comparison requests. Inventories are evaluator-derived from
committed bytes in the observed native shapes; they are not themselves historic
release manifests. Source data and identities are archived for offline replay.

All three arms receive the same bounded exact-input memoization wrapper, including
previous successful preparations, with at most 64 entries and 8 MB of input text.
This permits ordinary reuse. Cache hits, misses and parser work are distinct from
unique jobs. The conventional Python specialist runs in one persistent research
child process; its startup is measured separately. This process is ephemeral and
uses no credentials/network/installed operator access. Cross-language IPC and
startup are not treated as evidence of algorithmic or model superiority.

The ordinary specialist is a newly assembled evaluation implementation of
standard-library recipes, not falsely described as a previously installed Alpha
asset. Its assembly cost remains unknown/chargeable; it is a strong capability
control. The experiment cannot establish a historical no-investment comparison
without actual historical preparation/intervention evidence.
