# The Advantage That Funds the Next — prospective contract

Registration: 25 October 2026 (America/Toronto). Source: Alpha main
95d1e97d4d1c0aaebd592767fc5e5d2da56f6aa7. Additive research only.

## Selection before confirmation

Construct a reusable release-inventory intake asset and deliver exact source
discrepancy packs through the unchanged Alpha Workbench and TI catalogue engine.
Observed development evidence consists of four existing public inventory files.
This is adoption/integration of conventional parsing, not algorithmic invention.

Rejected discovery opportunities: a 1,500 by 1,500 unchanged catalogue comparison
took 123.717 ms in one local discovery run, making pure join speed an implausible
finite dollar investment; Git already has batch access and ordinary caches;
planning-service changes cross outstanding installed-profile restrictions;
the finite documentation and numerical examples have no identified material
recurring cost. All discovery work is charged in economic scenarios.

## Fixed artifact and acceptance contract

Each builder exports `normalize(text, format = 'auto')` from one JavaScript ES
module, returning `{format, rows}` with rows exactly `{path, sha256}`. No eval,
filesystem, network, subprocess, dynamic import or installed runtime change.
The source is a reviewed research candidate, never automatically trusted code.

Supported JSON has exactly one of these inventory roots (other metadata is inert):
`sources: {path: sha256}`, `files: {path: {sha256, ...}}`,
`files: [{path, sha256, ...}]`, or
`authoritativeArtifacts: [{path, sha256, ...}]`.
An optional top-level `pathBase` is explicitly prepended to every path.
Multiple recognized roots are ambiguous and must refuse. `gitBlob` is not SHA-256.
JSON must reject duplicate keys anywhere, including metadata. Metadata may contain
ordinary JSON numbers. Maximum depth 16, input 1,000,000 UTF-8 bytes, 128 rows,
64,000 UTF-8 bytes per scalar. Empty inventories are allowed.

Also support strict two-column CSV `path,sha256` with RFC4180 quoting/newlines and
SHA256SUMS lines `64hex  path` or `64hex *path`. No GNU escaped filename syntax.
Input format can be explicit `json`, `csv`, `sha256sum`, or `auto`; auto must refuse
unrecognized or ambiguous input. A final line terminator is permitted.

Paths remain exact case-sensitive Unicode strings; no Unicode normalization,
case folding, whitespace trimming, percent decoding, or silent deduplication.
Refuse absolute paths, backslashes, control characters, empty segments, `.` or
`..` segments, URL/drive prefixes, and duplicate final paths. An empty `pathBase`
means the root; one trailing slash on a nonempty base may be removed. No source
is read or executed. Hashes are exactly 64 hex digits, normalized to lowercase.
Rows sort by Unicode code points. Limits are fail-closed; nothing is truncated.

For each accepted pair, the unchanged TI guide produces complete differences,
corrective actions and exact input identities. An independent Python checker
recomputes normalization and all semantic differences. Inspectable Workbench
packs preserve its existing local-only/authority-none/settlement-disconnected
status. The output audits declared identities, not source behavior or security.

## Controls, resources and withholding

Three arms: strongest ordinary delivery with existing saved per-format recipes,
normal tools and caches; Alpha retained intake asset; equally resourced
conventional retained asset. Ordinary reuse is allowed. Never charge fictitious
per-job staffed preparation or remove an existing tool to manufacture an effect.
The ordinary arm will directly use a compact generic checked interpreter and
explicit per-format recipes; it is an adopted specialist and its integration is
reported. If it ties or dominates the new assets, preserve that result.

Each model-assisted builder receives the same public contract and four development
inputs, at most two candidate attempts and 20 elapsed minutes of construction.
Source and development tests freeze before independent confirmation is generated.
No builder sees confirmation inputs or the other builder's output before freeze.
Same-session role separation is not external institutional independence.

Confirm 16 unique source-comparison jobs, four disjoint file subsets in each of
the four requested public repositories. Use independently pinned historical and
current source bytes. Four representations per job are robustness repetitions,
not 64 customers. Add 24 independent refusal probes. Preserve every outcome.
No confirmation-based repair is permitted in the primary study. A second candidate
requires unused budget and fresh independent jobs; otherwise report the failure.

## Economics and admission

Use unchanged alpha-automated-costs/v1 and alpha-shadow-ledger/v1 from integration
e2503611666ee170266cbce51dc250492285f2e8. No competing ledger. Cash timing is a
derived scenario view, never recorded as observed collections.

Report measured execution, construction elapsed time, tool/artifact counts;
authoring tokens/bills, model cost, human effort and actual market price remain
unknown unless metered. Full observed cost must propagate unknowns. Separate
marginal, recurring and fully loaded costs and customer attention.

Finite modeled horizons: 16, 52, 104, 208 jobs. These are internal workload
scenarios, not observed demand. Grids: avoided provider attention 0, 5, 15, 30,
60, 120, 300 seconds/job; uncertain incremental investment 0, 5, 20, 50, 100,
250, 500 USD; price 1, 5, 10, 25 USD; compute 0.1, 1, 10 USD/hour; customer
attention 0, 15, 60, 300 seconds. None is an observed bill or duration.
Use sourced BLS wages separately from explicit assumptions: developer 65.38/hour,
QA 50.14/hour (May 2025), office/admin total compensation 36.73/hour (June 2026).

Charge discovery, both construction attempts, integration, qualification, delivery,
maintenance and failures. Show equal-price incremental value: price cancels when
acceptance is equal. Publish the maximum additional unknown investment cost and
the minimum avoided attention/demand/price needed to repay. Include lower demand,
maintenance shocks, failed jobs, delayed collections and depleted cash.

Every scenario funds exactly the SHA256-identified asset tested, never a fictional
future capability. Declare initial cash separately from earned contribution;
pay obligations, reserve the next job and maintenance exposure; invest only after
modeled collected contribution and available cash can cover the whole investment.
No silent replenishment. Stop at the finite horizon or resource exhaustion.

Economic admission requires technical acceptance, strictly positive complete
incremental value within the chosen horizon, and affordable upfront cash.
Unbounded unknown authoring/inference cost means observed economic HOLD.
Positive conditional scenarios may be labeled modeled admission only. No actual
revenue, production admission, distinctive builder superiority or acceleration
is inferred. This asset does not improve the builder; meta-improvement is not run.

## Delivery and authority

Preserve all four prior editions, their negative findings and pending publication.
Existing #4850/#4899/#4907 and research owners retain integration, security and
publication decisions. No browser/Fleet/Harness hold is retried. Local research,
isolated CI, approved operator and production remain separate. No spending,
credentials, persistent access, contract change or financial transaction.
