# Release inventory — result

Declared files: 8 / 8.
Field differences: 2.
Missing entries: 0.
Proposed actions: 2.

The downloads preserve every difference. No automatic correction.
This check compares declared identities; it certifies neither source behavior nor source security.

Retained asset: ad0b0adc9baa78de5b76cb7cf583fa8179fb977469ab5da47b75455953bf9fda

Local execution. Observed economic admission: HOLD. Actual collections: unknown.
