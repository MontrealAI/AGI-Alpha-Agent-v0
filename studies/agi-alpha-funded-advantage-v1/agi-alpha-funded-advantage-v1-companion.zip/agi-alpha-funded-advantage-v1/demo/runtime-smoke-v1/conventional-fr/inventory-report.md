# Inventaire de livraison — résultat

Fichiers déclarés: 8 / 8.
Différences de champs: 2.
Entrées absentes: 0.
Actions proposées: 2.

Les fichiers téléchargés conservent toutes les différences. Aucune correction automatique.
Ce contrôle compare des identités déclarées; il ne certifie ni le comportement ni la sécurité des sources.

Capacité utilisée: ce44d675dc840b3bfd68e2bdb13d1aa5a5be230ff6a0318d430835a16826cb72

Exécution locale. Admission économique réelle : EN ATTENTE. Encaissements réels : inconnus.
