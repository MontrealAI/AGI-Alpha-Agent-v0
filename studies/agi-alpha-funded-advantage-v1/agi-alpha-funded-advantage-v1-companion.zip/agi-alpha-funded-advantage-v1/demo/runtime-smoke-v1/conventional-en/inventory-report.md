# Release inventory — result

Declared files: 8 / 8.
Field differences: 2.
Missing entries: 0.
Proposed actions: 2.

The downloads preserve every difference. No automatic correction.
This check compares declared identities; it certifies neither source behavior nor source security.

Retained asset: ce44d675dc840b3bfd68e2bdb13d1aa5a5be230ff6a0318d430835a16826cb72

Local execution. Observed economic admission: HOLD. Actual collections: unknown.
