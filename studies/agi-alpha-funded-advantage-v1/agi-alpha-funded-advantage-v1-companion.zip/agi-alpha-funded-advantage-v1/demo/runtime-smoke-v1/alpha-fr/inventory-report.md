# Inventaire de livraison — résultat

Fichiers déclarés: 8 / 8.
Différences de champs: 2.
Entrées absentes: 0.
Actions proposées: 2.

Les fichiers téléchargés conservent toutes les différences. Aucune correction automatique.
Ce contrôle compare des identités déclarées; il ne certifie ni le comportement ni la sécurité des sources.

Capacité utilisée: ad0b0adc9baa78de5b76cb7cf583fa8179fb977469ab5da47b75455953bf9fda

Exécution locale. Admission économique réelle : EN ATTENTE. Encaissements réels : inconnus.
