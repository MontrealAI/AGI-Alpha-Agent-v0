# SPDX-License-Identifier: Apache-2.0
"""Offline static IIFE bundle and self-contained bilingual demonstration.

Adapts the AWE / Next Advantage static bundler. No code evaluation, network,
package installation, original-evidence overwrite or browser operation.
"""

import argparse
import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DEMO = ROOT / "demo"
HTML_NAME = "AGI_ALPHA_The_Advantage_That_Funds_the_Next.html"
IMPORT = re.compile(r"^import\s+([\s\S]*?)\s+from\s+['\"]([^'\"]+)['\"]\s*;", re.M)
DECLARATION = re.compile(r"^export\s+(?:async\s+)?(?:function|class|const|let|var)\s+(\w+)", re.M)
EXPORT_LIST = re.compile(r"^export\s*\{([^}]+)\}\s*;", re.M)


def digest(content):
    return hashlib.sha256(content).hexdigest()


def encode(value, *, compact=False):
    if compact:
        return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return json.dumps(value, ensure_ascii=False, indent=2) + "\n"


def identity(path):
    content = path.read_bytes()
    try:
        name = str(path.resolve().relative_to(ROOT))
    except ValueError:
        name = str(path.resolve())
    return {"path": name, "bytes": len(content), "sha256": digest(content)}


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def bundle_runtime(asset_hashes):
    modules, order, active = {}, [], set()

    def visit(path):
        path = path.resolve()
        if not path.is_relative_to(ROOT):
            raise ValueError("A runtime import left the study source closure")
        if path in active:
            raise ValueError("Cyclic imports are outside the static bundler contract")
        if path in modules:
            return
        if len(modules) >= 64:
            raise ValueError("Runtime source closure exceeds 64 modules")
        text = path.read_text(encoding="utf-8")
        imports = list(IMPORT.finditer(text))
        modules[path] = {"text": text, "imports": imports}
        active.add(path)
        for match in imports:
            if not match[2].startswith(("./", "../")):
                raise ValueError("Only explicit relative static imports are supported")
            visit(path.parent / match[2])
        active.remove(path)
        order.append(path)

    visit(DEMO / "runtime_entry.mjs")
    manifest = {
        "schema": "funded-advantage-runtime-bundle/v1",
        "method": "Static ES-module to IIFE adaptation; no eval, dynamic imports or network.",
        "lineage": "Next Advantage demonstration/bundle_runtime.py; inherited AWE static bundler.",
        "bundler": identity(Path(__file__)),
        "files": [identity(path) for path in order],
        "assetHashes": asset_hashes,
    }
    source_hash = digest(encode(manifest, compact=True).encode("utf-8"))
    chunks = [
        '"use strict";\nconst __modules=Object.create(null);',
        "globalThis.FUNDED_ADVANTAGE_SOURCE=" + json.dumps(source_hash) + ";",
        "globalThis.FUNDED_ADVANTAGE_ASSETS=Object.freeze(" + encode(asset_hashes, compact=True) + ");",
    ]
    for path in order:
        text = modules[path]["text"]

        def replace_import(match):
            dependency = str((path.parent / match[2]).resolve().relative_to(ROOT))
            spec = match[1].strip()
            if spec.startswith("{") and spec.endswith("}"):
                bindings = re.sub(r"\b(\w+)\s+as\s+(\w+)\b", r"\1: \2", spec[1:-1])
                return "const {" + bindings + "}=__modules[" + json.dumps(dependency) + "];"
            namespace = re.fullmatch(r"\*\s+as\s+(\w+)", spec)
            if namespace:
                return "const " + namespace[1] + "=__modules[" + json.dumps(dependency) + "];"
            raise ValueError("Unsupported static import: " + spec)

        text = IMPORT.sub(replace_import, text)
        names = DECLARATION.findall(text)
        exports = [name for name in names]

        def replace_exports(match):
            for binding in match[1].split(","):
                item = re.fullmatch(r"\s*(\w+)(?:\s+as\s+(\w+))?\s*", binding)
                if not item:
                    raise ValueError("Unsupported named export")
                exports.append(item[1] if not item[2] else item[2] + ":" + item[1])
            return ""

        text = EXPORT_LIST.sub(replace_exports, text)
        text = re.sub(r"^export\s+(?=(?:async\s+)?(?:function|class|const|let|var)\b)", "", text, flags=re.M)
        if re.search(r"^\s*(?:import|export)\s", text, re.M) or re.search(r"\bimport\s*\(|\beval\s*\(|\bnew\s+Function\s*\(", text):
            raise ValueError("Unhandled or dynamic module operation: " + str(path))
        chunks.append("__modules[" + json.dumps(str(path.relative_to(ROOT))) + "]=(()=>{\n" + text + "\nreturn {" + ",".join(exports) + "};\n})();")
    bundle = "\n".join(chunks) + "\n"
    manifest.update(sourceHash=source_hash, bundleSha256=digest(bundle.encode("utf-8")))
    return bundle, manifest


def scenario_for(trace, label, explanation):
    row = trace["row"]
    budget = row.get("budgetAtInvestment")
    available = None
    if budget is not None:
        available = max(0, min(budget["earnedContributionCents"], budget["cashCents"] - budget["protectedReserveCents"])) / 100
    admitted = row["modeledInvestmentOccurred"] and row["terminalIncrementalBenefitCents"] > 0
    return {
        "label": label,
        "method": row["arm"],
        "assetHash": row["assetHash"],
        "status": "MODELED_ADMISSION" if admitted else "HOLD",
        "evidenceStatus": row["evidenceStatus"],
        "horizonJobs": row["horizon"],
        "avoidedAttentionSecondsPerJob": row["avoidedAttentionSeconds"],
        "investmentUsd": row["investmentUsd"],
        "priceUsd": row["priceUsd"],
        "collectionDelayJobs": row["delayJobs"],
        "seedCapitalUsd": row["initialCashCents"] / 100,
        "availableSurplusUsd": available,
        "availableSurplusDefinition": "At the recorded investment point: minimum of recovered earned contribution and cash after the protected reserve. Null when no investment point exists.",
        "investmentAtJob": row["investmentAtJob"],
        "paybackJob": row["firstStrictPaybackJob"],
        "endingCashUsd": row["endingCashCents"] / 100,
        "cumulativeIncrementalValueUsd": row["terminalIncrementalBenefitCents"] / 100,
        "explanation": explanation,
        "completeRecordedTrace": trace,
    }


def study_data(economics_dir, links):
    results_path = ROOT / "evidence/results/summary.json"
    cases_path = ROOT / "evidence/confirmation/cases.json"
    results = read_json(results_path)
    economic_summary_path = economics_dir / "economics-summary.json"
    economic_inputs_path = economics_dir / "economic-inputs.json"
    traces_path = economics_dir / "cash-traces.json"
    economic_summary = read_json(economic_summary_path)
    economic_inputs = read_json(economic_inputs_path)
    if economic_summary["inputResultsSha256"] != digest(results_path.read_bytes()):
        raise ValueError("Economic results do not bind the selected primary result bytes")
    cases = read_json(cases_path)
    sample = next(case for case in cases if case["id"] == "J05-V1")
    assets = {}
    for method in ["alpha", "conventional"]:
        candidate_path = ROOT / "candidates" / method / "normalize.mjs"
        assets[method] = digest(candidate_path.read_bytes())
        if assets[method] != results["arms"][method]["assetHash"]:
            raise ValueError("Frozen candidate differs from confirmed source: " + method)
    observations = economic_summary["buildObservations"]
    qualified = [method for method in assets if results["arms"][method]["technicalAdmission"] == "PASS_FINITE_CONTRACT"]
    if not qualified:
        raise ValueError("No technically qualified retained implementation")
    default = min(qualified, key=lambda method: observations[method]["elapsedSeconds"] if observations[method]["elapsedSeconds"] is not None else float("inf"))
    traces = read_json(traces_path)

    def select(attention, profile):
        choices = [trace for trace in traces if all(trace["row"].get(key) == value for key, value in {
            "arm": "alpha", "horizon": 52, "investmentUsd": 20, "priceUsd": 5, "delayJobs": 2,
            "avoidedAttentionSeconds": attention, "profile": profile,
        }.items())]
        if len(choices) != 1 or choices[0]["row"]["assetHash"] != assets["alpha"]:
            raise ValueError("Required exact-asset financing trace is absent or ambiguous")
        return choices[0]

    selected = [
        scenario_for(select(0, "base"),
            {"en": "Alpha · zero assumed attention benefit", "fr": "Alpha · aucun gain d’attention supposé"},
            {"en": "The primary zero-attention-benefit case does not invest. Cash can accumulate from modeled delivery while the extra capability still fails incremental admission. No investment-point surplus is reported because no purchase occurs.",
             "fr": "Le cas principal sans gain d’attention n’investit pas. La livraison modélisée peut accumuler de la trésorerie alors que la capacité supplémentaire échoue au test incrémental. Aucun surplus au moment de l’investissement n’est indiqué, car aucun achat n’a lieu."}),
        scenario_for(select(60, "base"),
            {"en": "Alpha · counterfactual 60 seconds saved per job", "fr": "Alpha · hypothèse de 60 secondes économisées par mission"},
            {"en": "This conditional case assumes one minute of recurring provider attention is avoided. It finances the tested Alpha asset under a complete $20 incremental cost bound, $5 selling price and two-job collection delay. The attention benefit was not demonstrated. This is not superiority over the equally capable conventional builder.",
             "fr": "Ce cas conditionnel suppose une minute d’attention récurrente du prestataire économisée. Il finance la capacité Alpha testée avec une borne complète de 20 $ US de coût incrémental, un prix de 5 $ US et un délai d’encaissement de deux missions. Ce gain d’attention n’a pas été démontré. Il ne s’agit pas d’une supériorité sur le constructeur conventionnel tout aussi capable."}),
        scenario_for(select(60, "maintenance-shock"),
            {"en": "Alpha · same assumption plus a $10 maintenance shock", "fr": "Alpha · même hypothèse et choc de maintenance de 10 $ US"},
            {"en": "The declared $10 maintenance exposure removes the positive remaining-horizon case, so this modeled gate holds the investment. The shock is not paid because the asset is never purchased. The attention benefit remains an unmeasured counterfactual.",
             "fr": "L’exposition déclarée de 10 $ US à la maintenance supprime le cas positif dans l’horizon restant ; le modèle suspend donc l’investissement. Le choc n’est pas payé puisque la capacité n’est jamais achetée. Le gain d’attention reste une hypothèse non mesurée."}),
    ]
    arm_count = len(results["arms"])
    total_evaluations = sum(arm["caseEvaluations"] for arm in results["arms"].values())
    accepted = sum(arm["acceptedEvaluations"] for arm in results["arms"].values())
    refusal_total = sum(arm["refusalProbes"] for arm in results["arms"].values())
    refusal_passed = refusal_total - sum(arm["refusalFailures"] for arm in results["arms"].values())
    all_pass = all(arm["technicalAdmission"] == "PASS_FINITE_CONTRACT" for arm in results["arms"].values())
    conclusion = {
        "en": f"{arm_count} methods; {results['uniqueJobs']} unique public source-comparison jobs; {accepted} accepted evaluations out of {total_evaluations}. Ordinary delivery retains its normal recipes and caches. No recurring provider/customer attention reduction or full-cost payback was established. The ordinary control was assembled for this study, and its setup is not free.",
        "fr": f"{arm_count} méthodes ; {results['uniqueJobs']} missions uniques de comparaison de sources publiques ; {accepted} évaluations acceptées sur {total_evaluations}. La méthode ordinaire conserve ses recettes et caches habituels. Aucun gain récurrent d’attention ni remboursement du coût complet n’a été établi. Le contrôle ordinaire a été assemblé pour cette étude ; sa préparation n’est pas gratuite.",
    }
    reason = {
        "en": "The default uses the technically qualified construction with the shorter recorded elapsed build. This does not establish complete monetary superiority; authoring bills and active human effort remain unknown.",
        "fr": "Le choix par défaut est la construction techniquement qualifiée dont la durée enregistrée est la plus courte. Cela ne prouve pas une supériorité monétaire complète : les factures de conception et l’effort humain actif restent inconnus.",
    }
    dependencies = [identity(path) for path in [results_path, cases_path, economic_summary_path, economic_inputs_path, traces_path]]
    value = {
        "schema": "funded-advantage-demo-data/v1", "defaultMethod": default,
        "sample": {"caseId": sample["id"], "jobId": sample["job_id"],
                   "left": {**sample["left"], "label": {"en": "AGI-Fleet-Linux · earlier pinned bytes", "fr": "AGI-Fleet-Linux · octets antérieurs figés"}},
                   "right": {**sample["right"], "label": {"en": "AGI-Fleet-Linux · later pinned bytes", "fr": "AGI-Fleet-Linux · octets ultérieurs figés"}},
                   "scope": "Evaluator-derived declared inventories; named sources remain inert and are not executed."},
        "assetHashes": assets,
        "summary": {"uniqueJobs": results["uniqueJobs"], "evaluations": total_evaluations,
                    "acceptedEvaluations": accepted, "refusalProbes": refusal_total, "refusalPassed": refusal_passed,
                    "conclusion": conclusion, "defaultMethodReason": reason,
                    "construction": observations, "allTechnicalArmsPass": all_pass,
                    "execution": {"ci": {"en": results["execution"]["isolatedCI"], "fr": "NON EXÉCUTÉ" if results["execution"]["isolatedCI"] == "NOT_RUN" else results["execution"]["isolatedCI"]}},
                    "completePrimaryResults": results},
        "economics": {"scenarios": selected, "observedCompleteCostUsd": None,
                      "observedEconomicAdmission": "HOLD", "actualCollections": None,
                      "actualFinancialTransactions": 0, "analysis": economic_summary, "inputs": economic_inputs,
                      "displayScope": "Three selected recorded paths; all cash scenarios remain in the companion. All displayed paths fund the tested Alpha candidate, independently of the selected interactive implementation."},
        "downloadLinks": links, "evidenceInputs": dependencies,
        "executionScope": {"local": "PUBLIC_LOCAL_EXECUTION", "browser": "NOT_RUN", "approvedOperator": "NOT_RUN", "production": "NOT_RUN"},
    }
    return value, assets, dependencies


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=DEMO, help="Generated files directory; nondefault destinations must be empty or new")
    parser.add_argument("--economics", type=Path, default=ROOT / "evidence/economics")
    parser.add_argument("--paper-link", default="../publication/paper.pdf")
    parser.add_argument("--source-link", default="../README.md")
    parser.add_argument("--companion-link", default="", help="Owner-supplied companion archive URL or relative path; empty leaves the link unavailable")
    args = parser.parse_args()
    output = args.output.resolve()
    if output != DEMO.resolve() and output.exists() and any(output.iterdir()):
        raise ValueError("Reproduction output must be new or empty")
    output.mkdir(parents=True, exist_ok=True)
    links = {"paper": args.paper_link, "source": args.source_link, "companion": args.companion_link}
    data, asset_hashes, dependencies = study_data(args.economics.resolve(), links)
    bundle, manifest = bundle_runtime(asset_hashes)
    template = (DEMO / "index.template.html").read_text(encoding="utf-8")
    style = (DEMO / "style.css").read_text(encoding="utf-8")
    app = (DEMO / "app.js").read_text(encoding="utf-8")
    replacements = {
        "/*__STYLE__*/": style,
        "/*__DATA__*/": "globalThis.DATA=" + encode(data, compact=True).replace("<", "\\u003c") + ";",
        "/*__RUNTIME__*/": bundle.replace("</script", "<\\/script"),
        "/*__APP__*/": app.replace("</script", "<\\/script"),
    }
    for marker, replacement in replacements.items():
        if template.count(marker) != 1:
            raise ValueError("Expected exactly one template marker: " + marker)
        template = template.replace(marker, replacement)
    for name, content in [("runtime_bundle.js", bundle), ("RUNTIME_BUNDLE_MANIFEST.json", encode(manifest)),
                          ("DEMO_DATA.json", encode(data)), (HTML_NAME, template)]:
        (output / name).write_text(content, encoding="utf-8")
    generated = [{"path": name, "bytes": (output / name).stat().st_size, "sha256": digest((output / name).read_bytes())}
                 for name in ["runtime_bundle.js", "RUNTIME_BUNDLE_MANIFEST.json", "DEMO_DATA.json", HTML_NAME]]
    build_manifest = {
        "schema": "funded-advantage-demo-build/v1", "sourceHash": manifest["sourceHash"],
        "inputs": dependencies + [identity(DEMO / name) for name in ["build.py", "runtime_entry.mjs", "index.template.html", "style.css", "app.js"]],
        "artifacts": generated, "links": links, "sampleCase": data["sample"]["caseId"],
        "runtimeModules": len(manifest["files"]), "browserExecution": "NOT_RUN", "networkRequired": False,
    }
    (output / "BUILD_MANIFEST.json").write_text(encode(build_manifest), encoding="utf-8")
    print(encode({"output": str(output), "html": HTML_NAME, "sourceHash": manifest["sourceHash"],
                  "modules": len(manifest["files"]), "artifacts": generated}))


if __name__ == "__main__":
    main()
