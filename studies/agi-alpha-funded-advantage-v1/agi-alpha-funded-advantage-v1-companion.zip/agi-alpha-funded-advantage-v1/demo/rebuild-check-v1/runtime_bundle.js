"use strict";
const __modules=Object.create(null);
globalThis.FUNDED_ADVANTAGE_SOURCE="37e2c9b519555d7f6ab85c1451c2d6e28c98805d39ada5c96808b03b68a723ec";
globalThis.FUNDED_ADVANTAGE_ASSETS=Object.freeze({"alpha":"ad0b0adc9baa78de5b76cb7cf583fa8179fb977469ab5da47b75455953bf9fda","conventional":"ce44d675dc840b3bfd68e2bdb13d1aa5a5be230ff6a0318d430835a16826cb72"});
__modules["candidates/alpha/normalize.mjs"]=(()=>{
// SPDX-License-Identifier: Apache-2.0
// Version 1.0.0. Conventional bounded parsing; no source acquisition or execution.

const INPUT_LIMIT = 1_000_000;
const SCALAR_LIMIT = 64_000;
const ROW_LIMIT = 128;
const DEPTH_LIMIT = 16;
const encoder = new TextEncoder();
const own = (object, key) => Object.prototype.hasOwnProperty.call(object, key);
const record = (value) => value !== null && typeof value === 'object' && !Array.isArray(value);

function refuse(code, detail = '') {
  const error = new Error(detail ? `${code}: ${detail}` : code);
  error.name = 'InventoryInputError';
  error.code = code;
  throw error;
}

function unicode(value) {
  for (let i = 0; i < value.length; i += 1) {
    const code = value.charCodeAt(i);
    if (code >= 0xd800 && code <= 0xdbff) {
      const next = value.charCodeAt(i + 1);
      if (!(next >= 0xdc00 && next <= 0xdfff)) refuse('UNPAIRED_SURROGATE');
      i += 1;
    } else if (code >= 0xdc00 && code <= 0xdfff) {
      refuse('UNPAIRED_SURROGATE');
    }
  }
}

function scalar(value) {
  unicode(value);
  if (value.length > SCALAR_LIMIT || encoder.encode(value).length > SCALAR_LIMIT) {
    refuse('SCALAR_LIMIT');
  }
  return value;
}

// Every JSON value has a depth; the root is depth zero. A separate object-key
// set catches both literal and escape-equivalent duplicates before assignment.
function parseJson(text) {
  let position = 0;
  const space = () => {
    while (position < text.length && /[\x20\x09\x0a\x0d]/u.test(text[position])) position += 1;
  };
  function string() {
    const start = position;
    if (text[position] !== '"') refuse('JSON_STRING');
    position += 1;
    while (position < text.length) {
      const char = text[position];
      if (char === '"') {
        position += 1;
        let decoded;
        try { decoded = JSON.parse(text.slice(start, position)); }
        catch { refuse('JSON_STRING'); }
        return scalar(decoded);
      }
      if (char.charCodeAt(0) < 0x20) refuse('JSON_STRING_CONTROL');
      position += char === '\\' ? 2 : 1;
    }
    refuse('JSON_UNTERMINATED_STRING');
  }
  function value(depth) {
    if (depth > DEPTH_LIMIT) refuse('JSON_DEPTH_LIMIT');
    space();
    const char = text[position];
    if (char === '"') return string();
    if (char === '{') {
      position += 1;
      const result = Object.create(null);
      const keys = new Set();
      space();
      if (text[position] === '}') { position += 1; return result; }
      while (true) {
        space();
        const key = string();
        if (keys.has(key)) refuse('JSON_DUPLICATE_KEY');
        keys.add(key);
        space();
        if (text[position] !== ':') refuse('JSON_COLON');
        position += 1;
        result[key] = value(depth + 1);
        space();
        if (text[position] === '}') { position += 1; return result; }
        if (text[position] !== ',') refuse('JSON_OBJECT_SEPARATOR');
        position += 1;
      }
    }
    if (char === '[') {
      position += 1;
      const result = [];
      space();
      if (text[position] === ']') { position += 1; return result; }
      while (true) {
        result.push(value(depth + 1));
        space();
        if (text[position] === ']') { position += 1; return result; }
        if (text[position] !== ',') refuse('JSON_ARRAY_SEPARATOR');
        position += 1;
      }
    }
    for (const [token, result] of [['true', true], ['false', false], ['null', null]]) {
      if (text.startsWith(token, position)) { position += token.length; return result; }
    }
    const number = text.slice(position).match(/^-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?/u);
    if (!number) refuse('JSON_VALUE');
    if (number[0].length > SCALAR_LIMIT) refuse('SCALAR_LIMIT');
    position += number[0].length;
    const parsed = Number(number[0]);
    if (!Number.isFinite(parsed)) refuse('JSON_NONFINITE_NUMBER');
    return parsed;
  }
  const result = value(0);
  space();
  if (position !== text.length) refuse('JSON_TRAILING_CONTENT');
  return result;
}

function path(value) {
  if (typeof value !== 'string') refuse('PATH_TYPE');
  scalar(value);
  if (!value || value.startsWith('/') || value.includes('\\')) refuse('PATH_SYNTAX');
  if (/[\u0000-\u001f\u007f-\u009f]/u.test(value)) refuse('PATH_CONTROL');
  if (/^[a-z][a-z0-9+.-]*:/iu.test(value)) refuse('PATH_PREFIX');
  if (value.split('/').some((part) => !part || part === '.' || part === '..')) refuse('PATH_SEGMENT');
  return value;
}

function codePointOrder(left, right) {
  let i = 0;
  let j = 0;
  while (i < left.length && j < right.length) {
    const a = left.codePointAt(i);
    const b = right.codePointAt(j);
    if (a !== b) return a - b;
    i += a > 0xffff ? 2 : 1;
    j += b > 0xffff ? 2 : 1;
  }
  return i === left.length ? (j === right.length ? 0 : -1) : 1;
}

function finish(entries, base = '') {
  if (typeof base !== 'string') refuse('PATH_BASE_TYPE');
  if (base !== '') {
    if (base.startsWith('/')) refuse('PATH_BASE_ABSOLUTE');
    if (base.endsWith('/')) base = base.slice(0, -1);
    path(base);
  }
  if (entries.length > ROW_LIMIT) refuse('ROW_LIMIT');
  const seen = new Set();
  const rows = entries.map(([original, hash]) => {
    path(original);
    const final = path(base ? `${base}/${original}` : original);
    if (seen.has(final)) refuse('DUPLICATE_PATH');
    seen.add(final);
    if (typeof hash !== 'string' || !/^[0-9a-f]{64}$/iu.test(hash)) refuse('SHA256');
    return { path: final, sha256: hash.toLowerCase() };
  });
  rows.sort((a, b) => codePointOrder(a.path, b.path));
  return rows;
}

function json(text) {
  const root = parseJson(text);
  if (!record(root)) refuse('JSON_ROOT');
  const roots = ['sources', 'files', 'authoritativeArtifacts'].filter((key) => own(root, key));
  if (roots.length !== 1) refuse('JSON_INVENTORY_ROOT');
  const kind = roots[0];
  const inventory = root[kind];
  let entries;
  if (kind === 'sources') {
    if (!record(inventory)) refuse('SOURCES_TYPE');
    entries = Object.entries(inventory);
  } else if (Array.isArray(inventory)) {
    entries = inventory.map((entry) => {
      if (!record(entry) || !own(entry, 'path') || !own(entry, 'sha256')) refuse('FILE_ENTRY');
      return [entry.path, entry.sha256];
    });
  } else if (kind === 'files' && record(inventory)) {
    entries = Object.entries(inventory).map(([name, entry]) => {
      if (!record(entry) || !own(entry, 'sha256')) refuse('FILE_ENTRY');
      return [name, entry.sha256];
    });
  } else {
    refuse('INVENTORY_TYPE');
  }
  return finish(entries, own(root, 'pathBase') ? root.pathBase : '');
}

function csv(text) {
  const records = [];
  let position = 0;
  function field() {
    let decoded = '';
    if (text[position] === '"') {
      position += 1;
      let closed = false;
      while (position < text.length) {
        const char = text[position++];
        if (char !== '"') { decoded += char; continue; }
        if (text[position] === '"') { decoded += '"'; position += 1; continue; }
        closed = true;
        break;
      }
      if (!closed) refuse('CSV_UNTERMINATED_QUOTE');
    } else {
      const start = position;
      while (position < text.length && !',\r\n'.includes(text[position])) {
        if (text[position] === '"') refuse('CSV_UNQUOTED_QUOTE');
        position += 1;
      }
      decoded = text.slice(start, position);
    }
    return scalar(decoded);
  }
  while (position < text.length) {
    const row = [];
    while (true) {
      row.push(field());
      if (row.length > 2) refuse('CSV_COLUMNS');
      if (text[position] === ',') { position += 1; continue; }
      if (position === text.length) break;
      if (text[position] === '\n') { position += 1; break; }
      if (text[position] === '\r' && text[position + 1] === '\n') { position += 2; break; }
      refuse('CSV_SEPARATOR');
    }
    if (row.length !== 2) refuse('CSV_COLUMNS');
    records.push(row);
    if (records.length > ROW_LIMIT + 1) refuse('ROW_LIMIT');
  }
  if (records.length === 0 || records[0][0] !== 'path' || records[0][1] !== 'sha256') refuse('CSV_HEADER');
  return finish(records.slice(1));
}

function sha256sum(text) {
  if (text === '') return [];
  const lines = text.split(/\r?\n/u);
  if (lines[lines.length - 1] === '') lines.pop();
  if (lines.length > ROW_LIMIT) refuse('ROW_LIMIT');
  const entries = lines.map((line) => {
    const match = /^([0-9a-f]{64}) (?: |\*)(.*)$/iu.exec(line);
    if (!match) refuse('SHA256SUM_LINE');
    return [match[2], match[1]];
  });
  return finish(entries);
}

/** Normalize a bounded inventory without reading any named source. */
function normalize(text, format = 'auto') {
  if (typeof text !== 'string') refuse('INPUT_TYPE');
  if (!['auto', 'json', 'csv', 'sha256sum'].includes(format)) refuse('FORMAT');
  unicode(text);
  if (text.length > INPUT_LIMIT || encoder.encode(text).length > INPUT_LIMIT) refuse('INPUT_LIMIT');
  const parsers = { json, csv, sha256sum };
  if (format !== 'auto') return { format, rows: parsers[format](text) };
  if (text === '') refuse('AUTO_EMPTY');
  const accepted = [];
  for (const [family, parser] of Object.entries(parsers)) {
    try { accepted.push({ format: family, rows: parser(text) }); }
    catch (error) { if (error.name !== 'InventoryInputError') throw error; }
  }
  if (accepted.length !== 1) refuse(accepted.length > 1 ? 'AUTO_AMBIGUOUS' : 'AUTO_UNRECOGNIZED');
  return accepted[0];
}

return {normalize};
})();
__modules["candidates/conventional/normalize.mjs"]=(()=>{
// SPDX-License-Identifier: Apache-2.0
const encoder = new TextEncoder();
const byteLength = text => encoder.encode(text).length;
const fail = message => { throw new Error(message); };
const own = (object, key) => Object.hasOwn(object, key);
const record = object => object !== null && typeof object === 'object' && !Array.isArray(object);

function scalar(text) {
  for (let i = 0; i < text.length; i++) {
    const code = text.charCodeAt(i);
    if (code >= 0xd800 && code <= 0xdbff) {
      const following = text.charCodeAt(++i);
      if (!(following >= 0xdc00 && following <= 0xdfff)) fail('Unpaired Unicode surrogate');
    } else if (code >= 0xdc00 && code <= 0xdfff) fail('Unpaired Unicode surrogate');
  }
  if (byteLength(text) > 64000) fail('Scalar exceeds 64000 UTF-8 bytes');
  return text;
}

function parseJSON(text) {
  let offset = 0;
  const whitespace = () => { while (/[\x20\t\r\n]/.test(text[offset] ?? '') && offset < text.length) offset++; };
  const string = () => {
    const begin = offset++;
    while (offset < text.length) {
      const character = text[offset++];
      if (character === '\\') offset++;
      else if (character === '"') return scalar(JSON.parse(text.slice(begin, offset)));
    }
    return fail('Unterminated JSON string');
  };
  const value = depth => {
    if (depth > 16) fail('JSON depth exceeds 16');
    whitespace();
    const character = text[offset];
    if (character === '"') return string();
    if (character === '{') {
      offset++;
      const output = Object.create(null), keys = new Set();
      whitespace();
      if (text[offset] === '}') { offset++; return output; }
      for (;;) {
        whitespace();
        if (text[offset] !== '"') fail('Expected JSON object key');
        const key = string();
        if (keys.has(key)) fail('Duplicate JSON key');
        keys.add(key);
        whitespace();
        if (text[offset++] !== ':') fail('Expected JSON colon');
        output[key] = value(depth + 1);
        whitespace();
        const separator = text[offset++];
        if (separator === '}') return output;
        if (separator !== ',') fail('Expected JSON object separator');
      }
    }
    if (character === '[') {
      offset++;
      const output = [];
      whitespace();
      if (text[offset] === ']') { offset++; return output; }
      for (;;) {
        output.push(value(depth + 1));
        whitespace();
        const separator = text[offset++];
        if (separator === ']') return output;
        if (separator !== ',') fail('Expected JSON array separator');
      }
    }
    for (const [literal, primitive] of [['true', true], ['false', false], ['null', null]]) {
      if (text.startsWith(literal, offset)) { offset += literal.length; return primitive; }
    }
    const number = /^-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?/.exec(text.slice(offset));
    if (!number) fail('Invalid JSON value');
    scalar(number[0]);
    offset += number[0].length;
    const parsed = Number(number[0]);
    if (!Number.isFinite(parsed)) fail('Nonfinite JSON number');
    return parsed;
  };
  const output = value(0);
  whitespace();
  if (offset !== text.length) fail('Trailing JSON input');
  return output;
}

function pathValue(path) {
  if (typeof path !== 'string') fail('Path must be a string');
  scalar(path);
  if (!path || path.startsWith('/') || /[\\\u0000-\u001f\u007f-\u009f]/u.test(path) ||
      /^[A-Za-z][A-Za-z0-9+.-]*:/.test(path) || path.split('/').some(part => !part || part === '.' || part === '..'))
    fail('Unsupported relative path');
  return path;
}

function jsonRows(text) {
  const root = parseJSON(text);
  if (!record(root)) fail('JSON inventory root must be an object');
  const roots = ['sources', 'files', 'authoritativeArtifacts'].filter(key => own(root, key));
  if (roots.length !== 1) fail('Expected exactly one inventory root');
  let base = own(root, 'pathBase') ? root.pathBase : '';
  if (typeof base !== 'string') fail('pathBase must be a string');
  if (base.endsWith('/')) base = base.slice(0, -1);
  if (base) pathValue(base);
  else if (own(root, 'pathBase') && root.pathBase !== '') fail('Invalid pathBase');
  const name = roots[0], inventory = root[name];
  let rows;
  if (name === 'sources') {
    if (!record(inventory)) fail('sources must be a map');
    rows = Object.entries(inventory).map(([path, sha256]) => ({path, sha256}));
  } else if (Array.isArray(inventory)) {
    rows = inventory.map(row => {
      if (!record(row) || !own(row, 'path') || !own(row, 'sha256')) fail('Invalid array inventory row');
      return {path: row.path, sha256: row.sha256};
    });
  } else if (name === 'files' && record(inventory)) {
    rows = Object.entries(inventory).map(([path, row]) => {
      if (!record(row) || !own(row, 'sha256')) fail('Invalid files inventory row');
      return {path, sha256: row.sha256};
    });
  } else fail('Unsupported inventory shape');
  return rows.map(({path, sha256}) => ({path: base ? `${base}/${pathValue(path)}` : path, sha256}));
}

function csvRows(text) {
  let offset = 0;
  const rows = [];
  if (!text) fail('Missing CSV header');
  while (offset < text.length) {
    const row = [];
    for (;;) {
      let field = '';
      if (text[offset] === '"') {
        offset++;
        let closed = false;
        while (offset < text.length) {
          const character = text[offset++];
          if (character !== '"') field += character;
          else if (text[offset] === '"') { field += '"'; offset++; }
          else { closed = true; break; }
        }
        if (!closed) fail('Unclosed CSV quote');
      } else {
        while (offset < text.length && !',\r\n'.includes(text[offset])) {
          if (text[offset] === '"') fail('Quote inside unquoted CSV field');
          field += text[offset++];
        }
      }
      row.push(scalar(field));
      if (text[offset] === ',') { offset++; continue; }
      if (offset < text.length && text[offset] !== '\r' && text[offset] !== '\n') fail('Data after CSV quote');
      if (text[offset] === '\r') {
        if (text[offset + 1] !== '\n') fail('Lone CSV carriage return');
        offset += 2;
      } else if (text[offset] === '\n') offset++;
      break;
    }
    if (row.length !== 2) fail('CSV requires exactly two columns');
    rows.push(row);
    if (rows.length > 129) fail('Too many CSV rows');
  }
  if (rows[0][0] !== 'path' || rows[0][1] !== 'sha256') fail('CSV header must be path,sha256');
  return rows.slice(1).map(([path, sha256]) => ({path, sha256}));
}

function checksumRows(text) {
  if (!text) return [];
  const lines = text.split(/\r?\n/);
  if (lines.at(-1) === '') lines.pop();
  if (lines.length > 128) fail('Too many checksum rows');
  return lines.map(line => {
    const match = /^([0-9a-fA-F]{64}) (?: |\*)([\s\S]*)$/u.exec(line);
    if (!match) fail('Invalid SHA256SUMS line');
    return {path: match[2], sha256: match[1]};
  });
}

function codePointOrder(left, right) {
  const a = Array.from(left.path, character => character.codePointAt(0));
  const b = Array.from(right.path, character => character.codePointAt(0));
  for (let i = 0; i < Math.min(a.length, b.length); i++) if (a[i] !== b[i]) return a[i] - b[i];
  return a.length - b.length;
}

function checkedRows(rows) {
  if (rows.length > 128) fail('Inventory exceeds 128 rows');
  const seen = new Set();
  const output = rows.map(({path, sha256}) => {
    pathValue(path);
    if (seen.has(path)) fail('Duplicate final path');
    seen.add(path);
    if (typeof sha256 !== 'string' || !/^[0-9a-fA-F]{64}$/.test(sha256)) fail('Invalid SHA-256');
    return {path, sha256: sha256.toLowerCase()};
  });
  return output.sort(codePointOrder);
}

function normalize(text, format = 'auto') {
  if (typeof text !== 'string' || !['auto', 'json', 'csv', 'sha256sum'].includes(format)) fail('Invalid normalize input');
  if (byteLength(text) > 1000000) fail('Input exceeds 1000000 UTF-8 bytes');
  const parsers = {json: jsonRows, csv: csvRows, sha256sum: checksumRows};
  if (format !== 'auto') return {format, rows: checkedRows(parsers[format](text))};
  if (!text.trim()) fail('Cannot infer empty input format');
  const candidates = [];
  for (const [name, parser] of Object.entries(parsers)) {
    try { candidates.push({format: name, rows: checkedRows(parser(text))}); } catch { /* Invalid format candidate. */ }
  }
  if (candidates.length !== 1) fail('Unrecognized or ambiguous input format');
  return candidates[0];
}

return {normalize};
})();
__modules["vendor/alpha/docs/assets/successor/engine.mjs"]=(()=>{
// SPDX-License-Identifier: Apache-2.0
/** Fixed, bounded aggregation engines. No generated JavaScript is executed. */
const VERSION = 'successor-browser-v1';
const exact = (value, keys) => value && typeof value === 'object' && !Array.isArray(value) && Object.keys(value).sort().join('|') === [...keys].sort().join('|');
const integer = (value, low, high) => Number.isSafeInteger(value) && value >= low && value <= high;
function scalar(value) {
    if (typeof value !== 'string') return false;
    for (let i = 0; i < value.length; i++) {
        const c = value.charCodeAt(i);
        if (c >= 0xd800 && c <= 0xdbff) {
            const next = value.charCodeAt(++i);
            if (!(next >= 0xdc00 && next <= 0xdfff)) return false;
        } else if (c >= 0xdc00 && c <= 0xdfff) return false;
    }
    return true;
}
function canonical(value) {
    let nodes = 0;
    function encode(item, depth = 0) {
        if (++nodes > 100000 || depth > 32) throw Error('JSON complexity exceeds limit');
        if (item === null || typeof item === 'boolean') return JSON.stringify(item);
        if (typeof item === 'string' && scalar(item)) return JSON.stringify(item);
        if (typeof item === 'number' && Number.isSafeInteger(item) && !Object.is(item, -0)) return String(item);
        if (Array.isArray(item)) {
            for (let i = 0; i < item.length; i++) if (!Object.hasOwn(item, i)) throw Error('Sparse arrays are not JSON');
            return '[' + item.map(v => encode(v, depth + 1)).join(',') + ']';
        }
        if (item && typeof item === 'object' && [Object.prototype, null].includes(Object.getPrototypeOf(item))) {
            return '{' + Object.keys(item).sort().map(key => {
                if (!/^[\x20-\x7e]+$/.test(key)) throw Error('Object keys must be printable ASCII');
                return JSON.stringify(key) + ':' + encode(item[key], depth + 1);
            }).join(',') + '}';
        }
        throw Error('Unsupported JSON value; integers and Unicode scalars required');
    }
    const result = encode(value);
    if (new TextEncoder().encode(result).length > 2000000) throw Error('Canonical JSON exceeds 2 MB');
    return result;
}
async function digest(domain, value) {
    if (!/^[a-z][a-z0-9-]{0,63}$/.test(domain)) throw Error('Invalid digest domain');
    const bytes = new TextEncoder().encode('successor-omega/v1:' + domain + '\0' + canonical(value));
    return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', bytes)), n => n.toString(16).padStart(2, '0')).join('');
}
/** Parse untrusted imports before they can allocate large or deeply nested objects. */
function parseBounded(text) {
    if (typeof text !== 'string' || new TextEncoder().encode(text).length > 2_000_000) throw Error('Import exceeds 2 MB');
    let pos = 0, nodes = 0;
    const ws = () => { while (/[\x20\t\n\r]/.test(text[pos] || '\u0000')) pos++; };
    const string = () => {
        const start = pos++;
        while (pos < text.length) {
            if (text[pos] === '\\') { pos += 2; continue; }
            if (text[pos++] === '"') {
                const value = JSON.parse(text.slice(start, pos));
                if (!scalar(value)) throw Error('Malformed Unicode');
                return value;
            }
        }
        throw Error('Unterminated string');
    };
    function read(depth = 0) {
        if (++nodes > 100000 || depth > 32) throw Error('Import complexity exceeds limit');
        ws();
        if (text[pos] === '"') return string();
        if (text[pos] === '[' || text[pos] === '{') {
            const object = text[pos++] === '{', end = object ? '}' : ']';
            const value = object ? Object.create(null) : [];
            ws(); if (text[pos] === end) { pos++; return value; }
            while (true) {
                ws();
                if (object) {
                    if (text[pos] !== '"') throw Error('Expected object key');
                    const key = string(); ws();
                    if (Object.hasOwn(value, key)) throw Error('Duplicate JSON key');
                    if (text[pos++] !== ':') throw Error('Expected colon');
                    value[key] = read(depth + 1);
                } else value.push(read(depth + 1));
                ws(); const next = text[pos++];
                if (next === end) break;
                if (next !== ',') throw Error('Expected comma');
            }
            return value;
        }
        for (const [token, value] of [['true', true], ['false', false], ['null', null]]) {
            if (text.startsWith(token, pos)) { pos += token.length; return value; }
        }
        const match = /^-?(?:0|[1-9]\d*)(?![\d.eE+-])/.exec(text.slice(pos));
        if (!match) throw Error('Expected integer JSON value');
        pos += match[0].length; const value = Number(match[0]);
        if (!Number.isSafeInteger(value) || Object.is(value, -0)) throw Error('Unsafe integer');
        return value;
    }
    const value = read(); ws();
    if (pos !== text.length) throw Error('Trailing JSON content');
    canonical(value);
    return value;
}
function validateRequest(request) {
    const keys = ['schema_version', 'kind', 'request_id', 'mission', 'seed', 'max_candidates', 'formation_trials', 'max_events', 'language'];
    if (!request || typeof request !== 'object' || Array.isArray(request) || !Object.hasOwn(request, 'request_id') || Object.keys(request).some(key => !keys.includes(key))) throw Error('Invalid versioned rehearsal request');
    request = {schema_version: 1, kind: 'successor-rehearsal', mission: 'streaming-metrics-v1', seed: 42, max_candidates: 4, formation_trials: 2, max_events: 1000, language: 'en', ...request};
    if (!exact(request, keys) || request.schema_version !== 1 || request.kind !== 'successor-rehearsal' || request.mission !== 'streaming-metrics-v1' || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(request.request_id) || !integer(request.seed, 0, 4294967295) || !integer(request.max_candidates, 2, 12) || !integer(request.formation_trials, 1, 6) || !integer(request.max_events, 64, 20000) || !['en', 'fr'].includes(request.language)) throw Error('Invalid versioned rehearsal request');
    return structuredClone(request);
}
function newRequest(options = {}) {
    return validateRequest({schema_version: 1, kind: 'successor-rehearsal', request_id: crypto.randomUUID(), mission: 'streaming-metrics-v1', seed: 42, max_candidates: 4, formation_trials: 2, max_events: 1000, language: 'en', ...options});
}
function order(a, b) {
    const aa = Array.from(a, c => c.codePointAt(0)), bb = Array.from(b, c => c.codePointAt(0));
    for (let i = 0; i < Math.min(aa.length, bb.length); i++) if (aa[i] !== bb[i]) return aa[i] - bb[i];
    return aa.length - bb.length;
}
const rowOrder = (a, b) => order(a.day, b.day) || order(a.service, b.service);
function validateEvents(events) {
    if (!Array.isArray(events) || events.length > 20000) throw Error('Event count exceeds mission bound');
    for (const e of events) {
        if (!exact(e, ['day', 'service', 'duration_us', 'ok']) || !scalar(e.day) || !scalar(e.service) || !integer(Array.from(e.day).length, 1, 64) || !integer(Array.from(e.service).length, 1, 64) || !integer(e.duration_us, 0, 1000000000) || typeof e.ok !== 'boolean') throw Error('Malformed aggregation event');
    }
}
const makeRow = e => ({day: e.day, service: e.service, count: 0, total_duration_us: 0, max_duration_us: 0, error_count: 0});
function update(row, e, kind = 'builtin') {
    row.count++; row.total_duration_us += e.duration_us; row.error_count += Number(!e.ok);
    if (kind === 'builtin') row.max_duration_us = Math.max(row.max_duration_us, e.duration_us);
    else if (e.duration_us > row.max_duration_us) row.max_duration_us = e.duration_us;
}
function current(events) {
    validateEvents(events); const groups = new Map();
    for (const e of events) {
        const key = JSON.stringify([e.day, e.service]);
        if (!groups.has(key)) groups.set(key, makeRow(e));
        update(groups.get(key), e);
    }
    return [...groups.values()].sort(rowOrder);
}
function beta(events) {
    validateEvents(events); const sorted = [...events].sort(rowOrder), rows = [];
    for (const e of sorted) {
        let row = rows[rows.length - 1];
        if (!row || row.day !== e.day || row.service !== e.service) { row = makeRow(e); rows.push(row); }
        row.count += 1; row.total_duration_us += e.duration_us;
        row.error_count += e.ok ? 0 : 1;
        row.max_duration_us = row.max_duration_us >= e.duration_us ? row.max_duration_us : e.duration_us;
    }
    return rows;
}
function validateCandidate(c) {
    if (!exact(c, ['version', 'layout', 'cache_last', 'update']) || c.version !== 1 || !['nested', 'tuple'].includes(c.layout) || typeof c.cache_last !== 'boolean' || !['branch', 'builtin'].includes(c.update)) throw Error('Candidate is outside the fixed grammar');
    return c;
}
function candidate(events, config) {
    validateEvents(events); validateCandidate(config);
    const groups = new Map(), rows = []; let last = null;
    for (const e of events) {
        let row;
        if (config.cache_last && last && e.day === last.day && e.service === last.service) row = last;
        else if (config.layout === 'nested') {
            if (!groups.has(e.day)) groups.set(e.day, new Map());
            const services = groups.get(e.day);
            row = services.get(e.service);
            if (!row) { row = makeRow(e); services.set(e.service, row); rows.push(row); }
        } else {
            const key = JSON.stringify([e.day, e.service]); row = groups.get(key);
            if (!row) { row = makeRow(e); groups.set(key, row); rows.push(row); }
        }
        update(row, e, config.update); last = row;
    }
    return rows.sort(rowOrder);
}
function generateCandidates(seed, count) {
    if (!integer(count, 2, 12)) throw Error('Candidate count outside bound');
    const out = [];
    // Eight complete compositions; repeated configuration is never represented as a new challenger.
    for (let i = 0; i < Math.min(count, 8); i++) {
        const bits = (i + (seed % 8)) % 8;
        out.push({version: 1, layout: bits & 1 ? 'nested' : 'tuple', cache_last: Boolean(bits & 2), update: bits & 4 ? 'branch' : 'builtin'});
    }
    return out;
}
function workload(seed, count, mode = 'mixed') {
    let state = seed >>> 0;
    const next = () => (state = (Math.imul(state, 1664525) + 1013904223) >>> 0);
    const names = ['api', 'résumé', '東京', '🙂', '__proto__', '\ue000', '𝄞'];
    return Array.from({length: count}, (_, i) => ({day: 'day-' + (next() % (mode === 'high' ? 97 : 3)), service: mode === 'high' ? names[next() % names.length] + i : names[next() % names.length], duration_us: next() % 1000000001, ok: next() % 5 !== 0}));
}
const pause = () => new Promise(resolve => setTimeout(resolve, 0));
function measured(fn, events) {
    const start = performance.now(); const result = fn(events);
    return {elapsed_ns: Math.max(1, Math.round((performance.now() - start) * 1000000)), rows: result.length, result};
}
function correct(fn) {
    const valid = [[], [{day: '🙂', service: '__proto__', duration_us: 1000000000, ok: false}], workload(12, 64, 'high'), workload(98, 120)];
    if (!valid.every(events => canonical(fn(events)) === canonical(beta(events)))) return false;
    const bad = [[{day: '', service: 'x', duration_us: 1, ok: true}], [{day: 'd', service: 'x', duration_us: true, ok: true}], [{day: 'd', service: 'x', duration_us: 1, ok: 'true'}], [{day: 'd', service: '\ud800', duration_us: 1, ok: true}], [{day: 'd', service: 'x', duration_us: -1, ok: true}]];
    return bad.every(events => { try { fn(events); return false; } catch { return true; } });
}
function abort(signal) { if (signal?.aborted) throw new DOMException('Cancelled', 'AbortError'); }
async function discover(request, {signal, onProgress = () => {}, preferred = null} = {}) {
    request = validateRequest(request); const configurations = generateCandidates(request.seed, request.max_candidates);
    configurations.sort((a, b) => Number(b.layout === 'nested') - Number(a.layout === 'nested'));
    if (preferred) { validateCandidate(preferred); configurations.sort((a, b) => Number(canonical(b) === canonical(preferred)) - Number(canonical(a) === canonical(preferred))); }
    const events = workload(request.seed, request.max_events), attempts = [];
    const world = {version: 1, prediction: 'nested map reduces tuple-key serialization', uncertainty: 'allocation and sorting may dominate', experiment: 'prioritize nested-map compositions, then test tuple-map alternatives within the same budget', selection_rule: 'minimum measured development elapsed_ns among correct candidates; not final proof'};
    for (const config of configurations) {
        abort(signal); await pause(); abort(signal);
        const fn = values => candidate(values, config), pass = correct(fn), measurement = measured(fn, events);
        const attempt = {config, construction: {operator: 'bounded-grammar-composition', seed: request.seed, parent: VERSION}, artifact_hash: await digest('candidate', config), correctness: pass, elapsed_ns: measurement.elapsed_ns, rows: measurement.rows};
        attempts.push(attempt); onProgress(attempts.length, configurations.length);
    }
    const nested = attempts.filter(a => a.config.layout === 'nested'), tuples = attempts.filter(a => a.config.layout === 'tuple');
    world.observation = {nested_mean_ns: Math.round(nested.reduce((sum, a) => sum + a.elapsed_ns, 0) / (nested.length || 1)), tuple_mean_ns: Math.round(tuples.reduce((sum, a) => sum + a.elapsed_ns, 0) / (tuples.length || 1)), interpretation: 'development observation only; confounded by composition and browser timing'};
    world.falsified_in_this_run = world.observation.nested_mean_ns >= world.observation.tuple_mean_ns;
    const feasible = attempts.filter(a => a.correctness).sort((a, b) => a.elapsed_ns - b.elapsed_ns);
    if (!feasible.length) throw Error('No correct candidate; retain Current');
    return {world, attempts, selected: feasible[0], generation_budget: request.max_candidates, actual_candidates: configurations.length, source: VERSION};
}
async function freeze(request, discovery, sourceHash) {
    if (!/^[0-9a-f]{64}$/.test(sourceHash)) throw Error('Exact engine source digest required');
    const manifest = {schema_version: 1, request_hash: await digest('request', validateRequest(request)), grammar: discovery.selected.config, candidate_hash: discovery.selected.artifact_hash, engine: VERSION, engine_source_hash: sourceHash, comparators: ['current-one-pass-map-v1', 'beta-sorted-reduction-v1'], protocol: 'browser-local-aggregation-v1', correctness_required: true, minimum_speedup_ppm: 50000, costs: {money: null, review: null, memory: null}, authority: []};
    return {manifest, release_hash: await digest('release', manifest)};
}
async function evaluate(request, frozen, {signal} = {}) {
    request = validateRequest(request);
    if (frozen.manifest.request_hash !== await digest('request', request) || frozen.release_hash !== await digest('release', frozen.manifest)) throw Error('Frozen release or request changed');
    if (frozen.manifest.candidate_hash !== await digest('candidate', frozen.manifest.grammar) || frozen.manifest.protocol !== 'browser-local-aggregation-v1' || frozen.manifest.minimum_speedup_ppm !== 50000 || frozen.manifest.correctness_required !== true || canonical(frozen.manifest.comparators) !== canonical(['current-one-pass-map-v1', 'beta-sorted-reduction-v1'])) throw Error('Candidate or protocol binding mismatch');
    const config = validateCandidate(frozen.manifest.grammar), fn = e => candidate(e, config), cases = [];
    const correctness = correct(fn);
    for (let i = 0; i < 6; i++) {
        abort(signal); await pause(); abort(signal);
        const events = workload((request.seed + 100003 + i * 907) >>> 0, i < 2 ? 64 : request.max_events, i % 2 ? 'high' : 'mixed');
        const samples = [measured(current, events), measured(beta, events), measured(fn, events)];
        const exact_output = canonical(samples[0].result) === canonical(samples[1].result) && canonical(samples[1].result) === canonical(samples[2].result);
        cases.push({case_index: i, events: events.length, current_ns: samples[0].elapsed_ns, beta_ns: samples[1].elapsed_ns, candidate_ns: samples[2].elapsed_ns, exact_output});
    }
    const totals = {current: 0, beta: 0, candidate: 0};
    for (const c of cases) { totals.current += c.current_ns; totals.beta += c.beta_ns; totals.candidate += c.candidate_ns; }
    const best_comparator = totals.current <= totals.beta ? 'current' : 'beta';
    const hard_gate = correctness && cases.every(c => c.exact_output);
    return {schema_version: 1, scope: 'browser-rehearsal', release_hash: frozen.release_hash, cases, correctness: hard_gate, totals_ns: totals, best_comparator, local_verdict: !hard_gate ? 'FAIL' : totals.candidate >= totals[best_comparator] ? (best_comparator === 'beta' ? 'RETAIN_ALTERNATIVE' : 'RETAIN_INCUMBENT') : totals.candidate / totals[best_comparator] > 0.95 ? 'INSUFFICIENT_MARGIN' : 'LOCAL_SPEEDUP_OBSERVED', institutional_verdict: 'HOLD', missing: ['independent-verifier', 'frontier-comparator', 'measured-peak-memory', 'accepted-realized-economics', 'principal-issued-authority'], authority: [], timing_limitations: 'Single browser process; timer resolution, order, JIT and device load confound timings. Descriptive measurements only.'};
}
async function renew(request, discovery, {signal, onProgress = () => {}, engineSourceHash = null} = {}) {
    request = validateRequest(request);
    const trials = [];
    for (let i = 0; i < request.formation_trials; i++) {
        abort(signal);
        const next = {...request, seed: (request.seed + 200003 + i * 997) >>> 0};
        const control = await discover(next, {signal}), treatment = await discover(next, {signal, preferred: discovery.selected.config});
        const controlFreeze = await freeze(next, control, engineSourceHash), treatmentFreeze = await freeze(next, treatment, engineSourceHash);
        const controlEvaluation = await evaluate(next, controlFreeze, {signal}), treatmentEvaluation = await evaluate(next, treatmentFreeze, {signal});
        trials.push({trial: i, seed: next.seed, control_attempts: control.attempts.length, treatment_attempts: treatment.attempts.length, control, treatment, control_release: controlFreeze, treatment_release: treatmentFreeze, control_evaluation: controlEvaluation, treatment_evaluation: treatmentEvaluation});
        onProgress(i + 1, request.formation_trials);
    }
    return {generation: 2, active_proof: [], authority: [], memory: {permitted: ['configuration-order-hint'], excluded: ['final-cases', 'proof', 'grants']}, primary_metric: 'construction_attempts', interpretation: 'Descriptive matched trials; equal construction counts do not establish compounding.', trials};
}
// Canonical encoding and low-order rejection supplement WebCrypto verification.
// Mathematical torsion encodings: @noble/curves 1.2.0 src/ed25519.ts ED25519_TORSION_SUBGROUP.
const lowOrderY = new Set([
    '0000000000000000000000000000000000000000000000000000000000000000',
    '0100000000000000000000000000000000000000000000000000000000000000',
    'ecffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff7f',
    '26e8958fc2b227b045c3f489f2ef98f0d5dfac05d3c63339b13802886d53fc05',
    'c7176a703d4dd84fba3c0b760d10670f2a2053fa2c39ccc64ec7fd7792ac037a',
]);
const littleEndian = bytes => BigInt('0x' + [...bytes].reverse().map(v => v.toString(16).padStart(2, '0')).join(''));
function validatePointEncoding(bytes) {
    const y = bytes.slice(); y[31] &= 0x7f;
    const hex = [...y].map(v => v.toString(16).padStart(2, '0')).join('');
    if (littleEndian(y) >= (1n << 255n) - 19n || lowOrderY.has(hex)) throw Error('Non-canonical or low-order Ed25519 point');
}
function validateSignatureEncoding(key, signature) {
    validatePointEncoding(key); validatePointEncoding(signature.slice(0, 32));
    if (littleEndian(signature.slice(32)) >= (1n << 252n) + 27742317777372353535851937790883648493n) throw Error('Non-canonical Ed25519 scalar');
}
async function verifyNative(request, envelope) {
    request = validateRequest(request);
    if (!exact(envelope, ['schema_version', 'kind', 'request_hash', 'evidence', 'evidence_hash', 'scope', 'signature']) || envelope.schema_version !== 1 || envelope.kind !== 'successor-result' || envelope.scope !== 'local-native-rehearsal') throw Error('Unsupported native evidence envelope');
    if (envelope.request_hash !== await digest('request', request)) throw Error('Native result belongs to a different request');
    if (!envelope.evidence || envelope.evidence.scope !== envelope.scope || envelope.evidence.request_hash !== envelope.request_hash || !exact(envelope.evidence.request, Object.keys(request)) || canonical(envelope.evidence.request) !== canonical(request)) throw Error('Authenticated evidence request or scope mismatch');
    if (envelope.evidence_hash !== await digest('evidence', envelope.evidence)) throw Error('Native evidence digest mismatch');
    if (envelope.signature !== null) {
        const signature = envelope.signature;
        if (!exact(signature, ['public_key', 'signature']) || !/^[0-9a-f]{64}$/.test(signature.public_key) || !/^[A-Za-z0-9+/]{86}==$/.test(signature.signature)) throw Error('Malformed native signature');
        const publicBytes = Uint8Array.from(signature.public_key.match(/../g), x => parseInt(x, 16));
        const bytes = Uint8Array.from(atob(signature.signature), c => c.charCodeAt(0));
        validateSignatureEncoding(publicBytes, bytes);
        const key = await crypto.subtle.importKey('raw', publicBytes, {name: 'Ed25519'}, false, ['verify']);
        const data = Uint8Array.from(envelope.evidence_hash.match(/../g), x => parseInt(x, 16));
        if (!await crypto.subtle.verify('Ed25519', key, bytes, data)) throw Error('Invalid native signature');
    }
    return {scope: envelope.scope, integrity: 'request-and-evidence-digests-match', authenticity: 'unverified', authority: [], evidence: envelope.evidence};
}

return {VERSION,canonical,digest,parseBounded,validateRequest,newRequest,validateEvents,current,beta,validateCandidate,candidate,generateCandidates,workload,discover,freeze,evaluate,renew,verifyNative};
})();
__modules["vendor/alpha/examples/build-successor/vendor/agijobs/integrity.mjs"]=(()=>{
const FORBIDDEN_KEYS = new Set(['__proto__', 'prototype', 'constructor']);

/** Deterministic JSON encoding. Ambiguous or non-JSON values are refused. */
function canonicalize(value) {
  const active = new Set();
  let count = 0;
  const encode = (item, depth) => {
    if (++count > 100000 || depth > 64)
      throw new TypeError('JSON_LIMIT_EXCEEDED');
    if (item === null) return 'null';
    if (typeof item === 'string') {
      if (
        item !== item.normalize('NFC') ||
        /[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?<![\uD800-\uDBFF])[\uDC00-\uDFFF]/u.test(
          item
        )
      )
        throw new TypeError('NON_CANONICAL_UNICODE');
      return JSON.stringify(item);
    }
    if (typeof item === 'boolean') return item ? 'true' : 'false';
    if (typeof item === 'number') {
      if (
        !Number.isFinite(item) ||
        Object.is(item, -0) ||
        (Number.isInteger(item) && !Number.isSafeInteger(item))
      )
        throw new TypeError('UNSAFE_NUMBER');
      return JSON.stringify(item);
    }
    if (typeof item !== 'object' || active.has(item))
      throw new TypeError('NON_JSON_VALUE');
    const proto = Object.getPrototypeOf(item);
    if (
      (Array.isArray(item) && proto !== Array.prototype) ||
      (!Array.isArray(item) && proto !== Object.prototype && proto !== null)
    )
      throw new TypeError('NON_JSON_OBJECT');
    active.add(item);
    let encoded;
    if (Object.getOwnPropertySymbols(item).length)
      throw new TypeError('NON_JSON_SYMBOL');
    if (Array.isArray(item)) {
      const names = Object.getOwnPropertyNames(item);
      if (
        names.length !== item.length + 1 ||
        Object.keys(item).length !== item.length
      )
        throw new TypeError('SPARSE_OR_EXTENDED_ARRAY');
      for (let index = 0; index < item.length; index += 1) {
        const descriptor = Object.getOwnPropertyDescriptor(item, String(index));
        if (
          !descriptor ||
          descriptor.get ||
          descriptor.set ||
          !descriptor.enumerable
        )
          throw new TypeError('ACCESSOR_OR_SPARSE_ARRAY');
      }
      encoded = `[${Array.prototype.map
        .call(item, (part) => encode(part, depth + 1))
        .join(',')}]`;
    } else {
      const keys = Object.keys(item).sort();
      for (const key of keys) {
        if (FORBIDDEN_KEYS.has(key) || key !== key.normalize('NFC'))
          throw new TypeError('UNSAFE_OBJECT_KEY');
        if (
          Object.getOwnPropertyDescriptor(item, key)?.get ||
          Object.getOwnPropertyDescriptor(item, key)?.set
        )
          throw new TypeError('ACCESSOR_NOT_ALLOWED');
      }
      encoded = `{${keys
        .map(
          (key) => `${encode(key, depth + 1)}:${encode(item[key], depth + 1)}`
        )
        .join(',')}}`;
    }
    active.delete(item);
    return encoded;
  };
  return encode(value, 0);
}

async function digestBytes(value) {
  const bytes =
    typeof value === 'string' ? new TextEncoder().encode(value) : value;
  if (!(bytes instanceof Uint8Array)) throw new TypeError('BYTES_REQUIRED');
  if (!globalThis.crypto?.subtle) throw new Error('WEBCRYPTO_UNAVAILABLE');
  const digest = new Uint8Array(
    await globalThis.crypto.subtle.digest('SHA-256', bytes)
  );
  return `sha256:${Array.from(digest, (byte) =>
    byte.toString(16).padStart(2, '0')
  ).join('')}`;
}

async function digestObject(domain, object) {
  if (
    typeof domain !== 'string' ||
    !/^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,127}$/.test(domain)
  )
    throw new TypeError('INVALID_HASH_DOMAIN');
  return digestBytes(
    canonicalize({ hashFormat: 'successor-canonical-json-v1', domain, object })
  );
}

function cloneJson(value) {
  return JSON.parse(canonicalize(value));
}

return {canonicalize,digestBytes,digestObject,cloneJson};
})();
__modules["vendor/alpha/examples/build-successor/vendor/agijobs/domain.mjs"]=(()=>{
const { canonicalize, cloneJson }=__modules["vendor/alpha/examples/build-successor/vendor/agijobs/integrity.mjs"];

const SCHEMA_VERSION = '1.0.0';
const JOB_FAMILIES = Object.freeze([
  'constitution',
  'evidence',
  'formation',
  'challenge',
  'verification',
  'admission',
  'renewal',
]);
const EDGE_KINDS = Object.freeze([
  'evidence',
  'control',
  'challenge',
  'rollback',
  'invalidation',
]);
const JOB_STATES = Object.freeze([
  'DRAFT',
  'UNDERWRITTEN',
  'AUTHORIZED',
  'EXECUTING',
  'VERIFIED',
  'ACCEPTED',
  'CHRONICLE_ELIGIBLE',
  'REFUSED',
  'FAILED',
  'TIMED_OUT',
  'REPAIR_REQUIRED',
  'ROLLED_BACK',
]);
class SuccessorError extends Error {
  constructor(code, message, { details = {}, retryable = false } = {}) {
    super(message);
    this.name = 'SuccessorError';
    this.code = code;
    this.details = details;
    this.retryable = retryable;
  }
  toJSON() {
    return {
      code: this.code,
      message: this.message,
      details: this.details,
      retryable: this.retryable,
    };
  }
}
function requireCondition(condition, code, message, details = {}) {
  if (!condition) throw new SuccessorError(code, message, { details });
}
const fail = (path, message) => {
  throw new SuccessorError('SCHEMA_INVALID', `${path}: ${message}`, {
    details: { path },
  });
};
function object(value, keys, required, path) {
  if (!value || typeof value !== 'object' || Array.isArray(value))
    fail(path, 'expected object');
  for (const key of Object.keys(value))
    if (!keys.includes(key)) fail(`${path}.${key}`, 'unknown field');
  for (const key of required)
    if (!Object.hasOwn(value, key)) fail(`${path}.${key}`, 'required field');
}
const text = (value, path) => {
  if (typeof value !== 'string' || !value.trim() || value.length > 16000)
    fail(path, 'expected nonempty bounded string');
};
const id = (value, path) => {
  text(value, path);
  if (!/^[A-Za-z0-9][A-Za-z0-9._:/-]{0,159}$/.test(value))
    fail(path, 'invalid identifier');
};
const list = (value, path, check = text, minimum = 0, maximum = 256) => {
  if (!Array.isArray(value) || value.length < minimum || value.length > maximum)
    fail(path, 'invalid list size');
  value.forEach((entry, i) => check(entry, `${path}[${i}]`));
};
const integer = (value, path, min = 0, max = 1000000000) => {
  if (!Number.isSafeInteger(value) || value < min || value > max)
    fail(path, 'expected bounded integer');
};
const date = (value, path) => {
  if (
    typeof value !== 'string' ||
    !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d{3})?Z$/.test(value) ||
    !Number.isFinite(Date.parse(value))
  )
    fail(path, 'expected UTC ISO timestamp');
  const normalized = new Date(value).toISOString();
  if (value !== normalized && value !== normalized.replace('.000Z', 'Z'))
    fail(path, 'invalid calendar timestamp');
};
const choice = (value, values, path) => {
  if (!values.includes(value))
    fail(path, `expected one of ${values.join(', ')}`);
};
const unique = (values, path) => {
  if (new Set(values).size !== values.length) fail(path, 'duplicate values');
};
const bool = (value, path) => {
  if (typeof value !== 'boolean') fail(path, 'expected boolean');
};
function json(value) {
  try {
    canonicalize(value);
  } catch (error) {
    throw new SuccessorError('SCHEMA_INVALID', error.message);
  }
}
function validateBudget(value, path = 'budget', mission = false) {
  const fields = [
    'unit',
    'limitBaseUnits',
    'maxDurationMs',
    'maxRetries',
    ...(mission ? ['maxJobs'] : []),
  ];
  object(value, fields, fields, path);
  id(value.unit, `${path}.unit`);
  if (
    typeof value.limitBaseUnits !== 'string' ||
    !/^(0|[1-9][0-9]{0,29})$/.test(value.limitBaseUnits)
  )
    fail(
      `${path}.limitBaseUnits`,
      'expected canonical unsigned integer string'
    );
  integer(value.maxDurationMs, `${path}.maxDurationMs`, 1, 86400000);
  integer(value.maxRetries, `${path}.maxRetries`, 0, 100);
  if (mission) integer(value.maxJobs, `${path}.maxJobs`, 1, 256);
}
function rollback(value, path) {
  object(
    value,
    ['target', 'available', 'reason'],
    ['target', 'available', 'reason'],
    path
  );
  id(value.target, `${path}.target`);
  bool(value.available, `${path}.available`);
  text(value.reason, `${path}.reason`);
}
function reference(value, path) {
  object(
    value,
    ['id', 'version', 'description'],
    ['id', 'version', 'description'],
    path
  );
  id(value.id, `${path}.id`);
  id(value.version, `${path}.version`);
  text(value.description, `${path}.description`);
}
function validateMission(input) {
  json(input);
  const fields = [
    'schemaVersion',
    'kind',
    'missionId',
    'institutionId',
    'version',
    'title',
    'principal',
    'beneficiary',
    'objective',
    'incumbent',
    'alternatives',
    'rights',
    'hardGates',
    'criticalFunctions',
    'roles',
    'budget',
    'expiresAt',
    'authorityCeiling',
    'allowedTools',
    'allowedActions',
    'rollback',
    'proofProtocol',
  ];
  object(input, fields, fields, 'mission');
  requireCondition(
    input.schemaVersion === SCHEMA_VERSION,
    'SCHEMA_VERSION_UNSUPPORTED',
    'Unsupported mission schema version'
  );
  choice(input.kind, ['MissionConstitution'], 'mission.kind');
  for (const key of ['missionId', 'institutionId', 'version', 'principal'])
    id(input[key], `mission.${key}`);
  for (const key of ['title', 'beneficiary', 'objective'])
    text(input[key], `mission.${key}`);
  reference(input.incumbent, 'mission.incumbent');
  list(input.alternatives, 'mission.alternatives', reference, 1, 32);
  unique(
    input.alternatives.map((alternative) => alternative.id),
    'mission.alternatives'
  );
  list(
    input.rights,
    'mission.rights',
    (right, path) => {
      object(
        right,
        ['sourceId', 'license', 'dataClass', 'permittedUses', 'expiresAt'],
        ['sourceId', 'license', 'dataClass', 'permittedUses', 'expiresAt'],
        path
      );
      id(right.sourceId, `${path}.sourceId`);
      text(right.license, `${path}.license`);
      choice(
        right.dataClass,
        ['synthetic', 'public-licensed-nonpersonal'],
        `${path}.dataClass`
      );
      list(right.permittedUses, `${path}.permittedUses`, id, 1, 20);
      date(right.expiresAt, `${path}.expiresAt`);
    },
    1,
    256
  );
  unique(
    input.rights.map((right) => right.sourceId),
    'mission.rights'
  );
  list(
    input.hardGates,
    'mission.hardGates',
    (gate, path) => {
      object(
        gate,
        ['id', 'description', 'maxViolations'],
        ['id', 'description', 'maxViolations'],
        path
      );
      id(gate.id, `${path}.id`);
      text(gate.description, `${path}.description`);
      integer(gate.maxViolations, `${path}.maxViolations`, 0, 100);
    },
    1,
    64
  );
  unique(
    input.hardGates.map((gate) => gate.id),
    'mission.hardGates'
  );
  list(input.criticalFunctions, 'mission.criticalFunctions', id, 1, 64);
  unique(input.criticalFunctions, 'mission.criticalFunctions');
  object(
    input.roles,
    ['producer', 'verifier', 'acceptor', 'admitter'],
    ['producer', 'verifier', 'acceptor', 'admitter'],
    'mission.roles'
  );
  for (const [key, value] of Object.entries(input.roles))
    id(value, `mission.roles.${key}`);
  validateBudget(input.budget, 'mission.budget', true);
  date(input.expiresAt, 'mission.expiresAt');
  object(
    input.authorityCeiling,
    ['level', 'permittedActions', 'prohibitedActions', 'externalEffects'],
    ['level', 'permittedActions', 'prohibitedActions', 'externalEffects'],
    'mission.authorityCeiling'
  );
  choice(
    input.authorityCeiling.level,
    ['A0', 'A1', 'A2', 'A3', 'A4'],
    'mission.authorityCeiling.level'
  );
  list(
    input.authorityCeiling.permittedActions,
    'mission.authorityCeiling.permittedActions',
    id,
    1
  );
  list(
    input.authorityCeiling.prohibitedActions,
    'mission.authorityCeiling.prohibitedActions',
    id,
    1
  );
  bool(
    input.authorityCeiling.externalEffects,
    'mission.authorityCeiling.externalEffects'
  );
  list(input.allowedTools, 'mission.allowedTools', id, 1);
  list(input.allowedActions, 'mission.allowedActions', id, 1);
  rollback(input.rollback, 'mission.rollback');
  object(
    input.proofProtocol,
    [
      'id',
      'version',
      'mode',
      'formationOwner',
      'custodian',
      'requiredIndependence',
      'minimumMargin',
      'criticalErrorCeiling',
      'scope',
    ],
    [
      'id',
      'version',
      'mode',
      'formationOwner',
      'custodian',
      'requiredIndependence',
      'minimumMargin',
      'criticalErrorCeiling',
      'scope',
    ],
    'mission.proofProtocol'
  );
  for (const key of ['id', 'version', 'formationOwner', 'custodian'])
    id(input.proofProtocol[key], `mission.proofProtocol.${key}`);
  choice(
    input.proofProtocol.mode,
    ['SYNTHETIC_REHEARSAL', 'INDEPENDENT_REQUEST'],
    'mission.proofProtocol.mode'
  );
  choice(
    input.proofProtocol.requiredIndependence,
    ['I0', 'I1', 'I2', 'I3', 'I4'],
    'mission.proofProtocol.requiredIndependence'
  );
  if (
    !Number.isFinite(input.proofProtocol.minimumMargin) ||
    input.proofProtocol.minimumMargin < 0
  )
    fail('mission.proofProtocol.minimumMargin', 'expected nonnegative number');
  integer(
    input.proofProtocol.criticalErrorCeiling,
    'mission.proofProtocol.criticalErrorCeiling',
    0,
    100
  );
  text(input.proofProtocol.scope, 'mission.proofProtocol.scope');
  return cloneJson(input);
}

function validateWorkOrder(input) {
  json(input);
  const required = [
    'schemaVersion',
    'kind',
    'jobId',
    'missionId',
    'version',
    'family',
    'objective',
    'principal',
    'actor',
    'authorizedInputs',
    'evidenceObligation',
    'permittedTools',
    'permittedActions',
    'prohibitedActions',
    'budget',
    'expiresAt',
    'outputSchema',
    'verifier',
    'acceptance',
    'rollback',
    'chronicle',
    'covers',
    'state',
  ];
  object(
    input,
    [...required, 'digest', 'sealed', 'signatureStatus'],
    required,
    'job'
  );
  requireCondition(
    input.schemaVersion === SCHEMA_VERSION,
    'SCHEMA_VERSION_UNSUPPORTED',
    'Unsupported work-order schema version'
  );
  choice(input.kind, ['SealedWorkOrder'], 'job.kind');
  for (const key of ['jobId', 'missionId', 'version', 'principal', 'actor'])
    id(input[key], `job.${key}`);
  choice(input.family, JOB_FAMILIES, 'job.family');
  choice(input.state, JOB_STATES, 'job.state');
  text(input.objective, 'job.objective');
  for (const key of [
    'authorizedInputs',
    'evidenceObligation',
    'permittedTools',
    'permittedActions',
    'prohibitedActions',
    'covers',
  ]) {
    list(input[key], `job.${key}`, id, key === 'covers' ? 0 : 1);
    unique(input[key], `job.${key}`);
  }
  validateBudget(input.budget, 'job.budget');
  date(input.expiresAt, 'job.expiresAt');
  object(
    input.outputSchema,
    ['type', 'required'],
    ['type', 'required'],
    'job.outputSchema'
  );
  choice(input.outputSchema.type, ['object'], 'job.outputSchema.type');
  list(input.outputSchema.required, 'job.outputSchema.required', id, 1);
  object(
    input.verifier,
    ['identity', 'method', 'independence'],
    ['identity', 'method', 'independence'],
    'job.verifier'
  );
  id(input.verifier.identity, 'job.verifier.identity');
  text(input.verifier.method, 'job.verifier.method');
  choice(
    input.verifier.independence,
    ['I0', 'I1', 'I2', 'I3', 'I4'],
    'job.verifier.independence'
  );
  object(
    input.acceptance,
    ['owner', 'predicate', 'evidenceSources'],
    ['owner', 'predicate', 'evidenceSources'],
    'job.acceptance'
  );
  id(input.acceptance.owner, 'job.acceptance.owner');
  text(input.acceptance.predicate, 'job.acceptance.predicate');
  list(
    input.acceptance.evidenceSources,
    'job.acceptance.evidenceSources',
    id,
    1
  );
  rollback(input.rollback, 'job.rollback');
  object(
    input.chronicle,
    ['eligible', 'rights', 'scope', 'expiresAt'],
    ['eligible', 'rights', 'scope', 'expiresAt'],
    'job.chronicle'
  );
  bool(input.chronicle.eligible, 'job.chronicle.eligible');
  text(input.chronicle.rights, 'job.chronicle.rights');
  text(input.chronicle.scope, 'job.chronicle.scope');
  date(input.chronicle.expiresAt, 'job.chronicle.expiresAt');
  if ('sealed' in input) bool(input.sealed, 'job.sealed');
  if ('digest' in input && !/^sha256:[a-f0-9]{64}$/.test(input.digest))
    fail('job.digest', 'expected SHA-256 digest');
  if ('signatureStatus' in input)
    choice(
      input.signatureStatus,
      ['UNSIGNED_COMMITMENT', 'FIXTURE_SIGNED', 'AUTHORIZED_SIGNATURE'],
      'job.signatureStatus'
    );
  return cloneJson(input);
}

function validateGraph(input) {
  json(input);
  object(
    input,
    [
      'schemaVersion',
      'kind',
      'graphId',
      'missionId',
      'version',
      'nodes',
      'edges',
      'authorityCreated',
      'digest',
    ],
    [
      'schemaVersion',
      'kind',
      'graphId',
      'missionId',
      'version',
      'nodes',
      'edges',
      'authorityCreated',
    ],
    'graph'
  );
  requireCondition(
    input.schemaVersion === SCHEMA_VERSION,
    'SCHEMA_VERSION_UNSUPPORTED',
    'Unsupported graph schema version'
  );
  choice(input.kind, ['JobGraph'], 'graph.kind');
  for (const key of ['graphId', 'missionId', 'version'])
    id(input[key], `graph.${key}`);
  list(input.nodes, 'graph.nodes', validateWorkOrder, 1, 256);
  unique(
    input.nodes.map((node) => node.jobId),
    'graph.nodes'
  );
  list(
    input.edges,
    'graph.edges',
    (edge, path) => {
      object(edge, ['from', 'to', 'kind'], ['from', 'to', 'kind'], path);
      id(edge.from, `${path}.from`);
      id(edge.to, `${path}.to`);
      choice(edge.kind, EDGE_KINDS, `${path}.kind`);
    },
    0,
    2048
  );
  choice(input.authorityCreated, ['NONE'], 'graph.authorityCreated');
  return cloneJson(input);
}

const FORWARD = {
  DRAFT: 'UNDERWRITTEN',
  UNDERWRITTEN: 'AUTHORIZED',
  AUTHORIZED: 'EXECUTING',
  EXECUTING: 'VERIFIED',
  VERIFIED: 'ACCEPTED',
  ACCEPTED: 'CHRONICLE_ELIGIBLE',
};
// Pure reducer: context must originate in a trusted runtime, never request JSON.
function transitionJob(current, event, context = {}) {
  const job = validateWorkOrder(current);
  json(event);
  object(
    event,
    [
      'eventId',
      'expectedState',
      'to',
      'actor',
      'timestamp',
      'evidence',
      'reason',
    ],
    [
      'eventId',
      'expectedState',
      'to',
      'actor',
      'timestamp',
      'evidence',
      'reason',
    ],
    'event'
  );
  id(event.eventId, 'event.eventId');
  id(event.actor, 'event.actor');
  date(event.timestamp, 'event.timestamp');
  text(event.reason, 'event.reason');
  list(event.evidence, 'event.evidence', id, 1);
  requireCondition(
    event.expectedState === job.state,
    'STATE_CONFLICT',
    'The job changed; reload before retrying'
  );
  const exceptional = [
    'REFUSED',
    'FAILED',
    'TIMED_OUT',
    'REPAIR_REQUIRED',
    'ROLLED_BACK',
  ];
  requireCondition(
    FORWARD[job.state] === event.to ||
      (exceptional.includes(event.to) &&
        !['CHRONICLE_ELIGIBLE', ...exceptional].includes(job.state)),
    'TRANSITION_FORBIDDEN',
    'This job transition is not permitted'
  );
  const owner =
    event.to === 'VERIFIED'
      ? job.verifier.identity
      : ['ACCEPTED', 'CHRONICLE_ELIGIBLE'].includes(event.to)
      ? job.acceptance.owner
      : event.to === 'EXECUTING'
      ? job.actor
      : job.principal;
  requireCondition(
    event.actor === owner,
    'ROLE_CONFLICT',
    'The actor cannot authorize this transition'
  );
  if (['AUTHORIZED', 'EXECUTING'].includes(event.to)) {
    requireCondition(
      job.sealed === true && !!job.digest,
      'JOB_UNSEALED',
      'Seal the exact work order before authorization'
    );
    requireCondition(
      context.sealValid === true,
      'JOB_SEAL_UNVERIFIED',
      'The runtime must cryptographically verify the immutable work-order seal'
    );
    requireCondition(
      Date.parse(event.timestamp) < Date.parse(job.expiresAt),
      'JOB_EXPIRED',
      'The work order has expired'
    );
    requireCondition(
      context.preconditionsValid === true,
      'PRECONDITION_UNAVAILABLE',
      'Rights, dependencies and budget must be validated by the runtime'
    );
  }
  if (event.to === 'VERIFIED')
    requireCondition(
      context.verifierVerdict === 'PASS' && context.receiptValid === true,
      'VERIFICATION_REQUIRED',
      'A valid receipt and passing independent verdict are required'
    );
  if (event.to === 'ACCEPTED')
    requireCondition(
      context.acceptanceSatisfied === true,
      'ACCEPTANCE_CRITERIA_UNMET',
      'The runtime must verify the frozen deliverable acceptance predicate'
    );
  if (event.to === 'CHRONICLE_ELIGIBLE')
    requireCondition(
      job.chronicle.eligible && context.rightsCurrent === true,
      'CHRONICLE_INELIGIBLE',
      'Current reuse rights are required'
    );
  return { ...job, state: event.to };
}

return {SCHEMA_VERSION,JOB_FAMILIES,EDGE_KINDS,JOB_STATES,SuccessorError,requireCondition,validateBudget,validateMission,validateWorkOrder,validateGraph,transitionJob};
})();
__modules["vendor/alpha/examples/build-successor/vendor/agijobs/templates.mjs"]=(()=>{
const { SCHEMA_VERSION, validateMission }=__modules["vendor/alpha/examples/build-successor/vendor/agijobs/domain.mjs"];

const JOB_TEMPLATES = Object.freeze(
  [
    [
      'mission-constitution',
      'constitution',
      'Mission Constitution',
      'Freeze objective, beneficiary, accountable principal, hard constraints and prohibitions.',
    ],
    [
      'incumbent-baseline',
      'evidence',
      'Incumbent Baseline',
      'Measure accepted quality, complete cost, risk, time, human burden and authority.',
    ],
    [
      'alternative-set',
      'constitution',
      'Alternative Set',
      'Document the strongest credible frontier, specialist, human, hybrid, software and no-action alternatives.',
    ],
    [
      'rights-data',
      'constitution',
      'Rights and Data Constitution',
      'Establish source provenance, licenses, retention, exclusions and permitted reuse.',
    ],
    [
      'mission-gym',
      'formation',
      'Mission Gym and Benchmark Constitution',
      'Specify states, observations, actions, transitions, rewards, constraints, partitions, verifier and basis risk; freeze representative distribution, protected custody, critical failures and thresholds.',
    ],
    [
      'oracle-teacher',
      'evidence',
      'Oracle and Teacher Study',
      'Declare external teaching signals, hidden-call prohibition and transfer hypothesis.',
    ],
    [
      'failure-taxonomy',
      'challenge',
      'Failure Taxonomy',
      'Classify errors, severity, causes, abstention, adversarial cases and stop conditions.',
    ],
    [
      'architecture-frontier',
      'formation',
      'Architecture Frontier',
      'Form diverse complete candidates and retain non-dominated reserve options.',
    ],
    [
      'experience-formation',
      'formation',
      'Data and Experience Formation',
      'Build rights-cleared examples and simulation experience with explicit quality controls.',
    ],
    [
      'specialist-formation',
      'formation',
      'Specialist Model Formation',
      'Construct or adapt candidate components with exact immutable release identities.',
    ],
    [
      'tools-retrieval',
      'formation',
      'Tool and Retrieval Formation',
      'Build bounded deterministic checks, retrieval, planners, sandboxes and interfaces.',
    ],
    [
      'verifier-formation',
      'verification',
      'Verifier Formation',
      'Calibrate independent evaluation, replay, attacks, hidden ground truth and scoring.',
    ],
    [
      'security-privacy',
      'verification',
      'Security and Privacy Proof',
      'Test credential controls, isolation, threat model, incidents and provider risks.',
    ],
    [
      'complete-economics',
      'evidence',
      'Complete Economics',
      'Count construction, operation, human rescue, maintenance, requalification and unwind.',
    ],
    [
      'human-agency',
      'constitution',
      'Human Burden and Agency',
      'Define reviewer capacity, escalation, contestability and accountable decision rights.',
    ],
    [
      'resilience-rollback',
      'verification',
      'Resilience and Rollback',
      'Prove graceful degradation, kill switch, portability and known-good restoration.',
    ],
    [
      'fresh-evaluation',
      'verification',
      'Protected Fresh Evaluation',
      'Evaluate one frozen challenger on unseen representative work with full intervention costs.',
    ],
    [
      'independent-validation',
      'verification',
      'Independent Validation',
      'Independently examine evidence, limitations, critical errors, basis risk and fit for stated purpose.',
    ],
    [
      'accountable-acceptance',
      'admission',
      'Accountable Acceptance',
      'Record the attributable purpose-specific acceptance decision separately from independent validation and authority admission.',
    ],
    [
      'chronicle-authority',
      'admission',
      'Chronicle and Authority Admission',
      'Record separate knowledge and authority decisions, scope, expiry, monitoring and revocation.',
    ],
    [
      'capital-requalification',
      'renewal',
      'Capital-to-Capacity and Requalification',
      'Allocate verified available value and define next-successor and fresh-transfer triggers.',
    ],
  ].map(([id, family, title, objective]) =>
    Object.freeze({ id, family, title, objective, coverageKey: id })
  )
);

function createPortfolioJobs(input) {
  const mission = validateMission(input);
  return JOB_TEMPLATES.map((template) => ({
    schemaVersion: SCHEMA_VERSION,
    kind: 'SealedWorkOrder',
    jobId: `${mission.missionId}:${template.id}`,
    missionId: mission.missionId,
    version: '1',
    family: template.family,
    objective: template.objective,
    principal: mission.principal,
    actor: mission.roles.producer,
    authorizedInputs: mission.rights.map((right) => right.sourceId),
    evidenceObligation: ['source-lineage', 'complete-cost', 'failure-record'],
    permittedTools: [...mission.allowedTools],
    permittedActions: [...mission.allowedActions],
    prohibitedActions: [...mission.authorityCeiling.prohibitedActions],
    budget: {
      unit: mission.budget.unit,
      limitBaseUnits: (BigInt(mission.budget.limitBaseUnits) / 21n).toString(),
      maxDurationMs: mission.budget.maxDurationMs,
      maxRetries: mission.budget.maxRetries,
    },
    expiresAt: mission.expiresAt,
    outputSchema: {
      type: 'object',
      required: ['evidence', 'findings', 'cost'],
    },
    verifier: {
      identity: mission.roles.verifier,
      method:
        'Independent examination against frozen purpose-specific criteria; template is not executed proof.',
      independence: 'I0',
    },
    acceptance: {
      owner: mission.roles.acceptor,
      predicate: `All ${template.title} obligations have valid traceable evidence and no failed hard gate.`,
      evidenceSources: mission.rights.map((right) => right.sourceId),
    },
    rollback: { ...mission.rollback },
    chronicle: {
      eligible: false,
      rights: 'Requires a separate rights and admission review.',
      scope: mission.objective,
      expiresAt: mission.expiresAt,
    },
    covers: mission.criticalFunctions.includes(template.coverageKey)
      ? [template.coverageKey]
      : [],
    state: 'DRAFT',
  }));
}

return {JOB_TEMPLATES,createPortfolioJobs};
})();
__modules["vendor/alpha/examples/build-successor/vendor/agijobs/compiler.mjs"]=(()=>{
const {
  SCHEMA_VERSION,
  SuccessorError,
  requireCondition,
  validateMission,
  validateWorkOrder,
  validateGraph,
  transitionJob,
}=__modules["vendor/alpha/examples/build-successor/vendor/agijobs/domain.mjs"];
const { cloneJson, digestObject }=__modules["vendor/alpha/examples/build-successor/vendor/agijobs/integrity.mjs"];
const { createPortfolioJobs }=__modules["vendor/alpha/examples/build-successor/vendor/agijobs/templates.mjs"];

const EXECUTION_EDGES = new Set(['evidence', 'control', 'challenge']);
function workOrderPayload(input) {
  const job = validateWorkOrder(input);
  const { digest, sealed, signatureStatus, state, ...immutable } = job;
  return immutable;
}
async function sealWorkOrder(input) {
  const job = validateWorkOrder(input);
  requireCondition(
    job.state === 'DRAFT',
    'SEAL_STATE_FORBIDDEN',
    'Only a draft may be sealed; material changes require a new draft version'
  );
  return {
    ...job,
    sealed: true,
    signatureStatus: 'UNSIGNED_COMMITMENT',
    digest: await digestObject(
      'successor.work-order.v1',
      workOrderPayload(job)
    ),
  };
}
async function verifyWorkOrderSeal(input) {
  const job = validateWorkOrder(input);
  return (
    job.sealed === true &&
    job.digest ===
      (await digestObject('successor.work-order.v1', workOrderPayload(job)))
  );
}
async function transitionSealedJob(current, event, trustedContext = {}) {
  requireCondition(
    await verifyWorkOrderSeal(current),
    'JOB_SEAL_INVALID',
    'The immutable work-order seal is invalid'
  );
  return transitionJob(current, event, { ...trustedContext, sealValid: true });
}
function topologicalOrder(nodes, edges) {
  const indegree = new Map(nodes.map((node) => [node.jobId, 0]));
  const outgoing = new Map(nodes.map((node) => [node.jobId, []]));
  for (const edge of edges.filter((edge) => EXECUTION_EDGES.has(edge.kind))) {
    outgoing.get(edge.from).push(edge.to);
    indegree.set(edge.to, indegree.get(edge.to) + 1);
  }
  const queue = [...indegree]
    .filter(([, count]) => count === 0)
    .map(([key]) => key)
    .sort();
  const order = [];
  const depth = new Map(nodes.map((node) => [node.jobId, 1]));
  while (queue.length) {
    const key = queue.shift();
    order.push(key);
    for (const target of outgoing.get(key)) {
      depth.set(target, Math.max(depth.get(target), depth.get(key) + 1));
      indegree.set(target, indegree.get(target) - 1);
      if (!indegree.get(target)) {
        queue.push(target);
        queue.sort();
      }
    }
  }
  requireCondition(
    order.length === nodes.length,
    'GRAPH_CYCLE',
    'Execution, acceptance and challenge dependencies must be acyclic; use bounded version-producing discovery loops'
  );
  requireCondition(
    Math.max(...depth.values()) <= 64,
    'GRAPH_DEPTH_EXCEEDED',
    'Graph exceeds the supported execution depth'
  );
  return order;
}

async function compileJobs(
  input,
  { jobs: proposedJobs, edges = [], now = new Date().toISOString() } = {}
) {
  const mission = validateMission(input);
  const instant = Date.parse(now);
  requireCondition(
    Number.isFinite(instant),
    'CLOCK_INVALID',
    'A valid compiler clock is required'
  );
  requireCondition(
    instant < Date.parse(mission.expiresAt),
    'MISSION_EXPIRED',
    'The mission constitution has expired'
  );
  requireCondition(
    new Set([
      mission.roles.producer,
      mission.roles.verifier,
      mission.roles.admitter,
    ]).size === 3,
    'ROLE_CONFLICT',
    'Producer, verifier and admitter must have distinct identities'
  );
  requireCondition(
    mission.roles.producer !== mission.roles.acceptor,
    'ROLE_CONFLICT',
    'A producer cannot accept its own delivered work'
  );
  requireCondition(
    mission.proofProtocol.formationOwner !== mission.proofProtocol.custodian,
    'PROOF_CUSTODY_CONFLICT',
    'Formation and protected proof custody must be separately attributed'
  );
  requireCondition(
    mission.rollback.available,
    'ROLLBACK_UNAVAILABLE',
    'An available rollback or containment route is required'
  );
  if (mission.proofProtocol.mode === 'INDEPENDENT_REQUEST')
    requireCondition(
      ['I3', 'I4'].includes(mission.proofProtocol.requiredIndependence),
      'INDEPENDENCE_INSUFFICIENT',
      'An independently proven request requires I3 or I4 custody; internal rehearsal remains available'
    );
  for (const action of mission.allowedActions)
    requireCondition(
      !mission.authorityCeiling.prohibitedActions.includes(action),
      'ACTION_PROHIBITED',
      'A permitted formation action conflicts with a prohibition',
      { action }
    );
  requireCondition(
    proposedJobs === undefined || Array.isArray(proposedJobs),
    'SCHEMA_INVALID',
    'Jobs must be a bounded array'
  );
  const jobs = (proposedJobs ?? createPortfolioJobs(mission)).map(
    validateWorkOrder
  );
  requireCondition(
    jobs.length <= mission.budget.maxJobs,
    'JOB_LIMIT_EXCEEDED',
    'The graph exceeds its authorized work count'
  );
  const graph = validateGraph({
    schemaVersion: SCHEMA_VERSION,
    kind: 'JobGraph',
    graphId: `${mission.missionId}:graph`,
    missionId: mission.missionId,
    version: mission.version,
    nodes: jobs,
    edges,
    authorityCreated: 'NONE',
  });
  const ids = new Set(jobs.map((job) => job.jobId));
  const rights = new Map(
    mission.rights.map((right) => [right.sourceId, right])
  );
  const edgeKeys = new Set();
  for (const edge of graph.edges) {
    requireCondition(
      ids.has(edge.from) && ids.has(edge.to),
      'REFERENCE_UNRESOLVED',
      'A graph edge references an unknown job',
      edge
    );
    requireCondition(
      edge.from !== edge.to,
      'GRAPH_CYCLE',
      'Self-dependent jobs are not admissible',
      edge
    );
    const key = `${edge.from}|${edge.to}|${edge.kind}`;
    requireCondition(
      !edgeKeys.has(key),
      'EDGE_DUPLICATE',
      'Duplicate graph edge',
      edge
    );
    edgeKeys.add(key);
  }
  const executionOrder = topologicalOrder(jobs, graph.edges);
  let reservation = 0n;
  for (const job of jobs) {
    requireCondition(
      job.missionId === mission.missionId &&
        job.principal === mission.principal,
      'MISSION_BINDING_MISMATCH',
      'Job mission and accountable principal must match the constitution',
      { jobId: job.jobId }
    );
    requireCondition(
      job.state === 'DRAFT',
      'COMPILER_REQUIRES_DRAFT',
      'Compilation cannot grant or replay an existing job lifecycle state'
    );
    requireCondition(
      job.actor !== job.verifier.identity &&
        job.actor !== mission.roles.admitter,
      'ROLE_CONFLICT',
      'A producer cannot verify its own work or hold admission identity',
      { jobId: job.jobId }
    );
    requireCondition(
      job.actor !== job.acceptance.owner,
      'ROLE_CONFLICT',
      'A producing actor cannot accept its own delivered work',
      { jobId: job.jobId }
    );
    requireCondition(
      job.verifier.identity === mission.roles.verifier,
      'VERIFIER_UNAUTHORIZED',
      'Job verifier must be the constituted verifier identity',
      { jobId: job.jobId }
    );
    requireCondition(
      job.acceptance.owner === mission.roles.acceptor,
      'ACCEPTANCE_OWNER_MISMATCH',
      'Acceptance must belong to the constituted owner',
      { jobId: job.jobId }
    );
    requireCondition(
      job.rollback.available,
      'ROLLBACK_UNAVAILABLE',
      'Job has no available rollback or containment route',
      { jobId: job.jobId }
    );
    requireCondition(
      Date.parse(job.expiresAt) > instant &&
        Date.parse(job.expiresAt) <= Date.parse(mission.expiresAt),
      'JOB_EXPIRED',
      'Job expiry must be current and within the mission expiry',
      { jobId: job.jobId }
    );
    requireCondition(
      job.budget.unit === mission.budget.unit,
      'BUDGET_UNIT_MISMATCH',
      'Job and mission budget units differ',
      { jobId: job.jobId }
    );
    requireCondition(
      job.budget.maxRetries <= mission.budget.maxRetries &&
        job.budget.maxDurationMs <= mission.budget.maxDurationMs,
      'BUDGET_LIMIT_EXCEEDED',
      'Job resource limits exceed the mission ceiling',
      { jobId: job.jobId }
    );
    reservation += BigInt(job.budget.limitBaseUnits);
    for (const tool of job.permittedTools)
      requireCondition(
        mission.allowedTools.includes(tool),
        'TOOL_UNSUPPORTED',
        'The mission has not admitted this tool',
        { jobId: job.jobId, tool }
      );
    for (const action of job.permittedActions)
      requireCondition(
        mission.allowedActions.includes(action) &&
          !job.prohibitedActions.includes(action) &&
          !mission.authorityCeiling.prohibitedActions.includes(action),
        'ACTION_PROHIBITED',
        'Action is not within the mission capability mask',
        { jobId: job.jobId, action }
      );
    for (const prohibited of mission.authorityCeiling.prohibitedActions)
      requireCondition(
        job.prohibitedActions.includes(prohibited),
        'PROHIBITION_WEAKENED',
        'Job removes a constitutional prohibition',
        { jobId: job.jobId, prohibited }
      );
    for (const source of job.authorizedInputs) {
      if (rights.has(source)) {
        const right = rights.get(source);
        requireCondition(
          Date.parse(right.expiresAt) > instant &&
            Date.parse(right.expiresAt) >= Date.parse(job.expiresAt),
          'RIGHTS_EXPIRED',
          'Source rights do not cover the job duration',
          { jobId: job.jobId, source }
        );
        requireCondition(
          right.permittedUses.includes('mission-evaluation'),
          'RIGHTS_SCOPE_MISMATCH',
          'Source does not permit mission evaluation',
          { jobId: job.jobId, source }
        );
      } else {
        requireCondition(
          ids.has(source) &&
            graph.edges.some(
              (edge) =>
                edge.from === source &&
                edge.to === job.jobId &&
                edge.kind === 'evidence'
            ),
          'EVIDENCE_PATH_MISSING',
          'Every derived input requires an upstream evidence edge',
          { jobId: job.jobId, source }
        );
      }
    }
    for (const source of job.acceptance.evidenceSources)
      requireCondition(
        job.authorizedInputs.includes(source),
        'ACCEPTANCE_EVIDENCE_UNAVAILABLE',
        'Acceptance cannot depend on an unauthorized or producer-only source',
        { jobId: job.jobId, source }
      );
  }
  requireCondition(
    reservation <= BigInt(mission.budget.limitBaseUnits),
    'BUDGET_EXCEEDED',
    'Aggregate cumulative job budgets exceed the mission budget',
    {
      reservedBaseUnits: reservation.toString(),
      limitBaseUnits: mission.budget.limitBaseUnits,
    }
  );
  const coverage = mission.criticalFunctions.map((functionId) => ({
    functionId,
    jobIds: jobs
      .filter((job) => job.covers.includes(functionId))
      .map((job) => job.jobId),
    status: 'PLANNED_NOT_ACCEPTED',
  }));
  for (const obligation of coverage)
    requireCondition(
      obligation.jobIds.length > 0,
      'CRITICAL_COVERAGE_MISSING',
      'A non-negotiable mission function has no job path',
      { functionId: obligation.functionId }
    );
  const sealedJobs = await Promise.all(jobs.map(sealWorkOrder));
  const sealedGraph = { ...graph, nodes: sealedJobs };
  sealedGraph.digest = await digestObject(
    'successor.job-graph.v1',
    sealedGraph
  );
  const dependencyMap = Object.fromEntries(
    jobs.map((job) => [
      job.jobId,
      graph.edges
        .filter(
          (edge) => edge.to === job.jobId && EXECUTION_EDGES.has(edge.kind)
        )
        .map((edge) => ({ jobId: edge.from, kind: edge.kind })),
    ])
  );
  const invalidationMap = Object.fromEntries(
    [...rights.keys(), ...ids].map((key) => [
      key,
      jobs
        .filter((job) => job.authorizedInputs.includes(key))
        .map((job) => job.jobId),
    ])
  );
  for (const edge of graph.edges.filter((edge) =>
    ['evidence', 'invalidation', 'challenge', 'control'].includes(edge.kind)
  ))
    if (!invalidationMap[edge.from].includes(edge.to))
      invalidationMap[edge.from].push(edge.to);
  return {
    schemaVersion: SCHEMA_VERSION,
    status: 'SEALED',
    mode: mission.proofProtocol.mode,
    constitution: mission,
    graph: sealedGraph,
    executionOrder,
    coverage,
    criticalEvidenceCuts: coverage.map(({ functionId, jobIds }) => ({
      functionId,
      removeJobIds: jobIds,
      exhaustive: false,
    })),
    budgetReservations: {
      unit: mission.budget.unit,
      reservedBaseUnits: reservation.toString(),
      limitBaseUnits: mission.budget.limitBaseUnits,
      includesRetries: true,
    },
    dependencyMap,
    invalidationMap,
    capabilityRequests: jobs.map((job) => ({
      jobId: job.jobId,
      actor: job.actor,
      tools: job.permittedTools,
      actions: job.permittedActions,
      status: 'REQUESTED_NOT_GRANTED',
    })),
    evaluationPlan: cloneJson(mission.proofProtocol),
    authorityCreated: 'NONE',
    signatureStatus: 'UNSIGNED_COMMITMENT',
    digest: await digestObject('successor.constitution.v1', mission),
  };
}

function invalidationClosure(compilation, sourceIds) {
  const pending = [...sourceIds];
  const seen = new Set();
  while (pending.length) {
    const source = pending.shift();
    if (seen.has(source)) continue;
    seen.add(source);
    pending.push(...(compilation.invalidationMap[source] ?? []));
  }
  return [...seen].sort();
}

async function diagnoseMission(mission, options) {
  try {
    return await compileJobs(mission, options);
  } catch (error) {
    if (!(error instanceof SuccessorError)) throw error;
    return {
      status: 'REJECTED',
      diagnostics: [error.toJSON()],
      authorityCreated: 'NONE',
    };
  }
}

return {workOrderPayload,sealWorkOrder,verifyWorkOrderSeal,transitionSealedJob,compileJobs,invalidationClosure,diagnoseMission};
})();
__modules["vendor/alpha/examples/build-successor/model.mjs"]=(()=>{
// SPDX-License-Identifier: Apache-2.0
const alpha=__modules["vendor/alpha/docs/assets/successor/engine.mjs"];
const { compileJobs }=__modules["vendor/alpha/examples/build-successor/vendor/agijobs/compiler.mjs"];
const { JOB_TEMPLATES, createPortfolioJobs }=__modules["vendor/alpha/examples/build-successor/vendor/agijobs/templates.mjs"];
const { digestObject }=__modules["vendor/alpha/examples/build-successor/vendor/agijobs/integrity.mjs"];

const TOKEN = '0xA61a3B3a130a9c20768EEBF97E21515A6046a1fA';
const DELIVERABLES = [
  'mission.json: count, sum, maximum duration and error count by day and service; zero incorrect totals.',
  'incumbent.json: exact outputs and observed timings for the existing one-pass Map implementation.',
  'alternatives.json: compare the deterministic sort-and-reduce baseline; record that a frontier comparison is missing.',
  'rights.json: synthetic nonpersonal events only; list code licenses and permitted reuse.',
  'gym.json: version the event generator, malformed-input cases, public partitions and zero-error gate.',
  'teacher.json: disclose that this example uses fixed code and no external model or teaching calls.',
  'failures.json: test empty data, invalid numbers, malformed Unicode and unusual service keys.',
  'candidates.json: preserve all four bounded aggregation configurations and rejected attempts.',
  'experience.json: record seeds, workload sizes and generator version; no protected claims.',
  'candidate.json: freeze the selected grammar and engine SHA-256 before comparative evaluation.',
  'tools.json: allow only the fixed aggregation engine; no arbitrary code, browsing or money movement.',
  'verifier.json: reproduce exact outputs and reject invalid inputs; identify missing independent custody.',
  'security.json: confirm no external requests, keys, personal data or wallet approvals are required.',
  'economics.json: record all observed costs; mark compute price, human review and maintenance unmeasured.',
  'roles.json: separate producer, verifier, acceptance owner and admitter; labels are unauthenticated.',
  'rollback.json: retain the baseline and demonstrate clearing the active candidate without external effects.',
  'evaluation.json: compare the frozen candidate with both baselines on six further public workloads.',
  'review.json: obtain a separately attributable review; this browser leaves independent proof absent.',
  'acceptance.json: require evidence against the frozen terms; all work orders remain DRAFT here.',
  'authority.json: retain HOLD with zero grants until separate, scoped, expiring, revocable admission.',
  'renewal.json: propose the next test and preserve lessons; a successor inherits no proof or authority.',
];
const FRENCH_TITLES = [
  'Constitution de mission', 'Référence actuelle', 'Ensemble des alternatives', 'Droits et données',
  'Environnement d’entraînement et protocole comparatif', 'Étude des oracles et des enseignants',
  'Classification des échecs', 'Comparaison des architectures', 'Formation des données et de l’expérience',
  'Formation du modèle spécialisé', 'Outils et recherche documentaire', 'Construction du vérificateur',
  'Sécurité et confidentialité', 'Économie complète', 'Charge humaine et pouvoir de décision',
  'Résilience et retour arrière', 'Évaluation protégée sur données nouvelles', 'Validation indépendante',
  'Acceptation responsable', 'Chronique et admission de l’autorité', 'Capacité financée et requalification',
];
const FRENCH_DELIVERABLES = [
  'mission.json : compter les événements, les erreurs, la durée totale et maximale par jour et service; aucun total incorrect.',
  'incumbent.json : conserver les sorties exactes et les durées de la référence Map en un seul passage.',
  'alternatives.json : comparer la référence déterministe par tri et réduction; signaler l’absence de comparaison avec les meilleures IA.',
  'rights.json : utiliser uniquement des événements fictifs non personnels; préciser les licences et réutilisations permises.',
  'gym.json : versionner le générateur, les entrées mal formées, les jeux publics et le seuil de zéro erreur.',
  'teacher.json : déclarer le code fixe utilisé et l’absence de modèle externe ou d’appel d’enseignement.',
  'failures.json : tester les données vides, nombres invalides, caractères Unicode mal formés et clés de service inhabituelles.',
  'candidates.json : conserver les quatre configurations délimitées et les tentatives rejetées.',
  'experience.json : noter les graines aléatoires, tailles de jeux et version du générateur; aucune preuve protégée.',
  'candidate.json : figer la grammaire retenue et l’empreinte SHA-256 du moteur avant la comparaison.',
  'tools.json : autoriser uniquement le moteur fixe; aucun code arbitraire, navigation ou mouvement de fonds.',
  'verifier.json : reproduire les sorties exactes et rejeter les entrées invalides; signaler l’absence de garde indépendante.',
  'security.json : vérifier l’absence de requêtes externes, clés, données personnelles et autorisations de portefeuille.',
  'economics.json : noter les coûts observés; laisser le prix du calcul, la revue humaine et la maintenance non mesurés.',
  'roles.json : distinguer producteur, vérificateur, responsable de l’acceptation et décideur d’admission; identités non authentifiées.',
  'rollback.json : garder la référence et démontrer l’abandon du candidat actif sans effet externe.',
  'evaluation.json : comparer le candidat figé aux deux références sur six nouveaux jeux publics.',
  'review.json : obtenir une revue attribuable séparément; aucune preuve indépendante n’est créée dans le navigateur.',
  'acceptance.json : exiger des preuves conformes aux termes figés; toutes les tâches restent des brouillons DRAFT.',
  'authority.json : maintenir HOLD et zéro autorisation jusqu’à une admission distincte, limitée, temporaire et révocable.',
  'renewal.json : proposer le prochain test et garder les enseignements; aucun héritage automatique de preuve ou d’autorité.',
];

function missionFor({ name = 'Atlas Ω', budget = '2100', now = new Date().toISOString() } = {}) {
  if (typeof name !== 'string' || !name.trim() || name.length > 48) throw Error('Use a name of 1–48 characters.');
  if (typeof budget !== 'string' || !/^[1-9][0-9]{0,6}$/.test(budget) || BigInt(budget) > 1000000n) {
    throw Error('Use a whole planning allowance from 1 to 1,000,000 AGIALPHA.');
  }
  if (!Number.isFinite(Date.parse(now))) throw Error('A valid clock is required.');
  const expiresAt = new Date(Date.parse(now) + 7 * 86400000).toISOString();
  return {
    schemaVersion: '1.0.0', kind: 'MissionConstitution', missionId: 'streaming-metrics-builder-v1',
    institutionId: 'local-successor-workshop', version: '1', title: name.trim().normalize('NFC'),
    principal: 'example-human-principal', beneficiary: 'Owner of this local synthetic mission',
    objective: 'Produce exact daily service metrics, compare bounded implementations, and prepare reviewable work orders.',
    incumbent: { id: 'alpha-current', version: alpha.VERSION, description: 'Measured one-pass Map baseline.' },
    alternatives: [{ id: 'alpha-beta', version: alpha.VERSION, description: 'Measured deterministic sort-and-reduce baseline; not a frontier AI comparator.' }],
    rights: [{ sourceId: 'synthetic-events', license: 'Apache-2.0 generator; synthetic nonpersonal outputs', dataClass: 'synthetic', permittedUses: ['mission-evaluation', 'fixture-export'], expiresAt }],
    hardGates: [
      { id: 'exact-output', description: 'All grouped counts and durations agree exactly.', maxViolations: 0 },
      { id: 'invalid-input', description: 'Malformed and unsupported records are rejected.', maxViolations: 0 },
      { id: 'no-external-effect', description: 'No network request, live job, payment or authority grant.', maxViolations: 0 },
    ],
    criticalFunctions: JOB_TEMPLATES.map(t => t.coverageKey),
    roles: { producer: 'example-producer', verifier: 'example-verifier', acceptor: 'example-acceptor', admitter: 'example-admitter' },
    budget: { unit: 'AGIALPHA', limitBaseUnits: (BigInt(budget) * 10n ** 18n).toString(), maxDurationMs: 60000, maxRetries: 0, maxJobs: 21 },
    expiresAt,
    authorityCeiling: { level: 'A0', permittedActions: ['inspect-local'], prohibitedActions: ['send-payment', 'post-live-job', 'access-private-data', 'self-admit'], externalEffects: false },
    allowedTools: ['fixed-aggregation-engine'], allowedActions: ['inspect-local'],
    rollback: { target: 'alpha-current', available: true, reason: 'Discard the local candidate and return to the retained fixed baseline.' },
    proofProtocol: { id: 'public-local-rehearsal', version: '1', mode: 'SYNTHETIC_REHEARSAL', formationOwner: 'example-producer', custodian: 'example-verifier', requiredIndependence: 'I0', minimumMargin: 0.05, criticalErrorCeiling: 0, scope: 'Public synthetic cases in one process; no independent proof, mission alpha or operational admission.' },
  };
}

async function compilePlan(options = {}) {
  const mission = missionFor(options);
  const jobs = createPortfolioJobs(mission).map((job, i) => ({
    ...job,
    objective: `${job.objective} Streaming-metrics deliverable: ${DELIVERABLES[i]}`,
    acceptance: { ...job.acceptance, predicate: `${DELIVERABLES[i]} Preserve failures and missing evidence. Separate review is required.` },
  }));
  const dependencies = [[], [0], [0], [0], [1, 2, 3], [4], [4], [1, 2, 5, 6], [3, 4], [7, 8], [9], [4, 6, 10], [10, 11], [1, 2, 9], [0, 13], [10, 12], [9, 11, 12, 13, 14, 15], [16], [17], [18], [19]];
  const edges = dependencies.flatMap((parents, i) => parents.map(j => ({ from: jobs[j].jobId, to: jobs[i].jobId, kind: 'evidence' })));
  for (const edge of edges) jobs.find(job => job.jobId === edge.to).authorizedInputs.push(edge.from);
  return compileJobs(mission, { jobs, edges, now: options.now });
}

async function buildPack(options = {}, { signal, onProgress = () => {} } = {}) {
  const now = options.now || new Date().toISOString();
  const request = alpha.newRequest({ max_events: options.events ?? 1000, seed: options.seed ?? 42, max_candidates: 4, language: options.language ?? 'en' });
  if (!/^[0-9a-f]{64}$/.test(options.engineSourceHash || '')) throw Error('Engine source identity is required.');
  onProgress('compile');
  const compilation = await compilePlan({ ...options, now });
  if (signal?.aborted) throw new DOMException('Cancelled', 'AbortError');
  onProgress('discover');
  const discovery = await alpha.discover(request, { signal });
  const frozen = await alpha.freeze(request, discovery, options.engineSourceHash);
  onProgress('evaluate');
  const evaluation = await alpha.evaluate(request, frozen, { signal });
  const record = {
    schema: 'successor-build-example/v1', createdAt: now, title: compilation.constitution.title,
    scope: 'LOCAL_REHEARSAL', request, compilation, discovery, frozen, evaluation,
    token: { symbol: 'AGIALPHA', chainId: 1, address: TOKEN, decimals: 18 },
    settlement: { status: 'NOT_CONNECTED', transactions: [], spentBaseUnits: '0', allowanceIs: 'ILLUSTRATIVE_NOT_FUNDED' },
    admission: { decision: 'HOLD', independentProof: false, authority: [], specialistASI: false },
    chronicle: [{ kind: 'local-observation', candidateRelease: frozen.release_hash, reusable: 'Configuration hypothesis only; rerun tests.', inheritedProof: false, inheritedAuthority: false }],
  };
  return { ...record, integrityDigest: await digestObject('successor-build-example.v1', record) };
}

function jobBriefs(pack) {
  if(pack.request.language==='fr')return `# ${pack.title} — Fiches de construction SUCCESSOR Ω\n\nRÉPÉTITION LOCALE. Brouillons DRAFT, empreintes non signées, zéro dépense.\nPreuve indépendante absente. Admission HOLD. Aucune autorité accordée.\n\nJeton commun sur Ethereum mainnet : ${TOKEN} (AGIALPHA, 18 décimales).\nBudget de planification seulement; frais, mises et gaz à estimer séparément.\n\n` +
    pack.compilation.graph.nodes.map((job,i)=>`## ${i+1}. ${FRENCH_TITLES[i]}\n\n${FRENCH_DELIVERABLES[i]}\n\nTermes canoniques du compilateur (anglais) : ${job.objective}\n\nCritère d’acceptation canonique (anglais) : ${job.acceptance.predicate}\n\nLimite de planification (unités de base AGIALPHA) : ${job.budget.limitBaseUnits}\nExpiration : ${job.expiresAt}\nProducteur : ${job.actor}\nVérificateur : ${job.verifier.identity}\nResponsable de l’acceptation : ${job.acceptance.owner}\nRetour arrière : ${job.rollback.target}\nEmpreinte non signée : ${job.digest}\n`).join('\n') +
    '\nSuite : organiser une évaluation protégée indépendante, mesurer tous les coûts, mettre en service l’intégration puis demander une décision humaine d’admission distincte. Le jeton commun ne relie pas automatiquement les marchés.\n';
  return `# ${pack.title} — SUCCESSOR Ω build briefs\n\nLOCAL REHEARSAL. DRAFT work, unsigned commitments, zero funds spent.\nIndependent proof absent. Admission HOLD. No authority is granted.\n\nShared Ethereum mainnet token: ${TOKEN} (AGIALPHA, 18 decimals).\nPlanning allowance only; fees, stakes and gas require separate estimates before commissioning.\n\n` +
    pack.compilation.graph.nodes.map((job, i) => `## ${i + 1}. ${JOB_TEMPLATES[i].title}\n\n${job.objective}\n\nAcceptance: ${job.acceptance.predicate}\n\nPlanning limit (AGIALPHA base units): ${job.budget.limitBaseUnits}\nExpiry: ${job.expiresAt}\nProducer: ${job.actor}\nVerifier: ${job.verifier.identity}\nAcceptance owner: ${job.acceptance.owner}\nRollback: ${job.rollback.target}\nUnsigned commitment: ${job.digest}\n`).join('\n') +
    '\nNext: arrange independent protected evaluation, measure full costs, resolve commissioning, then request a separate human admission decision. Sharing the token does not bridge the two markets.\n';
}

return {TOKEN,DELIVERABLES,FRENCH_TITLES,FRENCH_DELIVERABLES,missionFor,compilePlan,buildPack,jobBriefs};
})();
__modules["vendor/alpha/examples/successor-workbench/engine.mjs"]=(()=>{
// SPDX-License-Identifier: Apache-2.0
const { canonical, digest, parseBounded }=__modules["vendor/alpha/docs/assets/successor/engine.mjs"];
const { missionFor }=__modules["vendor/alpha/examples/build-successor/model.mjs"];
const { compileJobs }=__modules["vendor/alpha/examples/build-successor/vendor/agijobs/compiler.mjs"];
const { createPortfolioJobs }=__modules["vendor/alpha/examples/build-successor/vendor/agijobs/templates.mjs"];

const VERSION = 'successor-workbench/v1';
const REGISTRY = Object.freeze([
  { id: 'reliability', en: 'Repair a range utility', fr: 'Réparer un utilitaire', artifact: 'repair.patch', scope: 'Closed interval utilities in the documented finite source grammar.' },
  { id: 'performance', en: 'Compare real algorithms', fr: 'Comparer des algorithmes', artifact: 'benchmark.json', scope: 'Exact sorted unique integer values; sort/reduce versus Set/sort.' },
  { id: 'documentation', en: 'Check executable examples', fr: 'Vérifier des exemples exécutables', artifact: 'checked-examples.md', scope: 'Named URI and UTF-8 SDK operations in bounded JSON examples.' },
  { id: 'public-data', en: 'Turn data into a report', fr: 'Transformer des données en rapport', artifact: 'report.html', scope: 'Public or synthetic two-column CSV with exact integer amounts.' },
  { id: 'numerical', en: 'Reproduce a calculation', fr: 'Reproduire un calcul', artifact: 'numerical.json', scope: 'Polynomial integration using exact rational arithmetic and two quadrature rules.' },
]);

const clone = value => parseBounded(canonical(value));
function fields(value, keys, label) {
  if (!value || typeof value !== 'object' || Array.isArray(value) ||
      Object.keys(value).sort().join('|') !== [...keys].sort().join('|')) throw Error(`SCHEMA: ${label}`);
}
function integer(value, low, high, label) {
  if (!Number.isSafeInteger(value) || value < low || value > high) throw Error(`BOUNDS: ${label}`);
}
function text(value, maximum, label) {
  if (typeof value !== 'string' || !value.trim() || value.length > maximum) throw Error(`TEXT: ${label}`);
}
function html(value) { return String(value).replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char])); }
function file(name, type, content) { return { name, type, content }; }
function jsonFile(name, object) { return file(name, 'application/json', JSON.stringify(object, null, 2) + '\n'); }

function example(family = 'reliability') {
  const inputs = {
    reliability: { source: 'export function contains(value, low, high) { return low < value && value < high; }', low: 0, high: 10, cases: [-1, 0, 1, 5, 9, 10, 11] },
    performance: { values: [8, 3, 8, 1, 0, -3, 3, 12, 0, 7], repetitions: 7, repeats: 100 },
    documentation: { markdown: '# URI helper examples\n\n```successor-example\n{"operation":"url-encode","input":"hello world","expected":"hello+world"}\n```\n\n```successor-example\n{"operation":"url-decode","input":"hello%20world","expected":"hello world"}\n```\n' },
    'public-data': { csv: 'group,amount\nResearch,120\nSoftware,85\nResearch,35\nDocumentation,60\nSoftware,-5\n', unit: 'synthetic units' },
    numerical: { coefficients: [0, 0, 1], lower: 0, upper: 3, steps: 12, tolerancePpm: 1 },
  };
  if (!Object.hasOwn(inputs, family)) throw Error('UNSUPPORTED_FAMILY');
  return { schema: VERSION, family, name: 'My SUCCESSOR Ω', language: 'en', owner: 'local-owner',
    rights: { dataClass: 'synthetic', source: 'Included public example', license: 'Apache-2.0' },
    reviewMinutes: 10, inputs: clone(inputs[family]) };
}

function validate(spec, adapter = null) {
  fields(spec, ['schema','family','name','language','owner','rights','reviewMinutes','inputs'], 'mission');
  if (spec.schema !== VERSION || !(REGISTRY.some(item => item.id === spec.family) || adapter?.manifest.id === spec.family)) throw Error('UNSUPPORTED_VERSION_OR_FAMILY');
  text(spec.name, 64, 'name'); text(spec.owner, 128, 'owner');
  if (!['en','fr'].includes(spec.language)) throw Error('LANGUAGE');
  fields(spec.rights, ['dataClass','source','license'], 'rights');
  if (!['public','licensed-nonpersonal','synthetic'].includes(spec.rights.dataClass)) throw Error('INPUT_RIGHTS');
  text(spec.rights.source, 1000, 'source'); text(spec.rights.license, 1000, 'license');
  integer(spec.reviewMinutes, 1, 120, 'review capacity');
  const value = spec.inputs;
  if (adapter) {
    adapter.validate(clone(value));
  } else if (spec.family === 'reliability') {
    fields(value, ['source','low','high','cases'], 'reliability input');
    text(value.source, 2000, 'source'); rangeProgram(value.source);
    integer(value.low, -1000000, 1000000, 'low'); integer(value.high, value.low, 1000000, 'high');
    if (!Array.isArray(value.cases) || value.cases.length < 1 || value.cases.length > 2000) throw Error('CASES');
    value.cases.forEach(n => integer(n, -1000001, 1000001, 'case'));
  } else if (spec.family === 'performance') {
    fields(value, ['values','repetitions','repeats'], 'performance input');
    if (!Array.isArray(value.values) || value.values.length < 1 || value.values.length > 2000) throw Error('VALUES');
    value.values.forEach(n => integer(n, -1000000, 1000000, 'value'));
    integer(value.repetitions, 3, 15, 'repetitions'); integer(value.repeats, 1, 500, 'repeats');
  } else if (spec.family === 'documentation') {
    fields(value, ['markdown'], 'documentation input'); text(value.markdown, 100000, 'markdown');
    const matches = [...value.markdown.matchAll(/```successor-example\s*\n([\s\S]*?)\n```/g)];
    if (!matches.length || matches.length > 40) throw Error('EXAMPLES: use 1–40 successor-example JSON blocks');
    for (const match of matches) validateDocExample(parseBounded(match[1]));
  } else if (spec.family === 'public-data') {
    fields(value, ['csv','unit'], 'data input'); text(value.csv, 100000, 'csv'); text(value.unit, 80, 'unit');
    readRows(value.csv);
  } else {
    fields(value, ['coefficients','lower','upper','steps','tolerancePpm'], 'numerical input');
    if (!Array.isArray(value.coefficients) || !value.coefficients.length || value.coefficients.length > 7) throw Error('COEFFICIENTS');
    value.coefficients.forEach(n => integer(n, -1000, 1000, 'coefficient'));
    integer(value.lower, -100, 99, 'lower'); integer(value.upper, value.lower + 1, 100, 'upper');
    integer(value.steps, 2, 1000, 'steps'); if (value.steps % 2) throw Error('EVEN_STEPS_REQUIRED');
    integer(value.tolerancePpm, 0, 1000000, 'absolute tolerance in millionths');
  }
  canonical(spec);
  return clone(spec);
}

async function semanticIdentity(spec, adapter = null) {
  const { name, language, ...semantic } = validate(spec, adapter);
  return digest('workbench-mission', semantic);
}

function rangeProgram(source) {
  const match = /^\s*export\s+function\s+contains\s*\(\s*value\s*,\s*low\s*,\s*high\s*\)\s*\{\s*return\s+low\s*(<=|<)\s*value\s*&&\s*value\s*(<=|<)\s*high\s*;\s*\}\s*$/.exec(source);
  if (!match) throw Error('SOURCE_GRAMMAR: only the documented bounded contains function is supported');
  return { lower: match[1], upper: match[2], execute: (value, low, high) =>
    (match[1] === '<=' ? low <= value : low < value) && (match[2] === '<=' ? value <= high : value < high) };
}
async function reliability(input, checkpoint) {
  const incumbent = rangeProgram(input.source);
  const cases = [...new Set([...input.cases, input.low - 1, input.low, input.high, input.high + 1])];
  const tests = cases.map(value => ({value, expected: value >= input.low && value <= input.high,
    actual: incumbent.execute(value, input.low, input.high)}));
  const attempts = [];
  for (const lower of ['<','<=']) for (const upper of ['<','<=']) {
    await checkpoint('testing');
    const source = `export function contains(value, low, high) { return low ${lower} value && value ${upper} high; }`;
    const method = rangeProgram(source);
    const failed = cases.filter(value => method.execute(value, input.low, input.high) !== (value >= input.low && value <= input.high));
    attempts.push({source, failed});
  }
  const selected = attempts.find(item => item.failed.length === 0);
  const defects = tests.filter(item => item.expected !== item.actual);
  const candidate = selected.source;
  const originalLines=input.source.trim().split(/\r?\n/);
  const patch = `--- a/contains.mjs\n+++ b/contains.mjs\n@@ -1,${originalLines.length} +1 @@\n${originalLines.map(line=>'-'+line).join('\n')}\n+${candidate}\n`;
  const checks = `// SPDX-License-Identifier: Apache-2.0\nimport assert from 'node:assert/strict';\nimport { contains } from './contains.mjs';\nfor (const c of ${JSON.stringify(tests.map(({value,expected})=>({value,expected})))}) assert.equal(contains(c.value, ${input.low}, ${input.high}), c.expected);\nconsole.log('All ${tests.length} fixed contract checks passed');\n`;
  return { decision: defects.length ? 'REPAIR_PROPOSED' : 'RETAIN_INCUMBENT', summary: {tests: tests.length, defects: defects.length, candidateFailures: 0},
    evidence: {tests, attempts, protectedCases: false, execution: 'Finite source grammar interpreted without eval or arbitrary host execution'},
    artifacts: [file('contains.mjs','text/javascript',candidate+'\n'), file('original.mjs','text/javascript',input.source+'\n'),
      file('check.mjs','text/javascript',checks),file('repair.patch','text/plain',defects.length ? patch : '# No repair needed.\n'),jsonFile('tests.json',tests)],
    limits: ['This adapter supports the declared range utility grammar only; arbitrary repositories need a separately isolated executor.', 'Public contract tests are engineering evidence, not independently protected qualification.'] };
}

async function performanceWork(input, checkpoint) {
  const sortUnique = values => values.slice().sort((a,b)=>a-b).filter((n,i,a)=>i===0 || n!==a[i-1]);
  const setUnique = values => [...new Set(values)].sort((a,b)=>a-b);
  const expected = sortUnique(input.values);
  const samples = { sort: [], set: [] };
  for (let r=0;r<input.repetitions;r++) {
    for (const name of (r%2 ? ['set','sort'] : ['sort','set'])) {
      await checkpoint('benchmarking');
      const fn = name==='sort' ? sortUnique : setUnique;
      const start = globalThis.performance.now(); let actual;
      for (let i=0;i<input.repeats;i++) actual=fn(input.values);
      samples[name].push(Math.max(0,Math.round((globalThis.performance.now()-start)*1000)));
      if (canonical(actual)!==canonical(expected)) throw Error('CRITICAL_CORRECTNESS_FAILURE');
    }
  }
  const median = values => [...values].sort((a,b)=>a-b)[Math.floor(values.length/2)];
  const selected = median(samples.set) < median(samples.sort) ? 'set' : 'sort';
  const report = { samplesMicrosecondsPerBatch: samples, batchRepeats: input.repeats,
    medianMicroseconds: {sort: median(samples.sort),set: median(samples.set)}, selected, output: expected,
    resourceTradeoff: 'Set retains a hash table and a unique-value array; sort copies and sorts all input values. Peak memory is not measured.' };
  return {decision: selected==='sort'?'RETAIN_INCUMBENT':'CANDIDATE_FASTER_IN_THIS_RUN',summary:{inputCount:input.values.length,outputCount:expected.length,correct:true},
    evidence:report,artifacts:[jsonFile('benchmark.json',report),jsonFile('values.json',input.values),
      file('unique.mjs','text/javascript',`// SPDX-License-Identifier: Apache-2.0\nexport const unique = ${selected==='set' ? "values => [...new Set(values)].sort((a,b)=>a-b)" : "values => values.slice().sort((a,b)=>a-b).filter((n,i,a)=>i===0 || n!==a[i-1])"};\n`)],
    limits:['Device/JIT/order effects can dominate small timings. This result does not establish general superiority.', 'Peak memory, monetary cost and human savings are unmeasured.']};
}

function validateDocExample(value) {
  fields(value,['operation','input','expected'],'documentation example');
  if (!['url-encode','url-decode','utf8-bytes'].includes(value.operation)) throw Error('UNSUPPORTED_SDK_OPERATION');
  if (typeof value.input!=='string' || value.input.length>4000 || typeof value.expected!=='string') throw Error('SDK_INPUT');
}
function sdk(value) {
  if(value.operation==='url-encode')return encodeURIComponent(value.input);
  if(value.operation==='url-decode')return decodeURIComponent(value.input);
  return String(new TextEncoder().encode(value.input).length);
}
async function documentation(input, checkpoint) {
  const checks=[]; let offset=0; let repaired='';
  for (const match of input.markdown.matchAll(/```successor-example\s*\n([\s\S]*?)\n```/g)) {
    await checkpoint('checking-examples');
    const value=parseBounded(match[1]); let actual=null,error=null;
    try { actual=sdk(value); } catch { error='INVALID_URI_ENCODING'; }
    checks.push({index:checks.length+1,...value,actual,error,passed:error===null&&actual===value.expected});
    repaired+=input.markdown.slice(offset,match.index)+(error ? match[0] : '```successor-example\n'+JSON.stringify({...value,expected:actual})+'\n```');
    offset=match.index+match[0].length;
  }
  repaired+=input.markdown.slice(offset);
  const failures=checks.filter(c=>!c.passed), errors=checks.filter(c=>c.error);
  return {decision:errors.length?'REPAIR_REQUIRED':failures.length?'DOCUMENTATION_CORRECTION_PROPOSED':'RETAIN_INCUMBENT',
    summary:{examples:checks.length,incorrectExamples:failures.length,invalidInputs:errors.length},evidence:{checks,contract:'URI component encoding/decoding and UTF-8 byte count; actual standard-library execution'},
    artifacts:[file('original-examples.md','text/markdown',input.markdown),file('checked-examples.md','text/markdown',repaired),jsonFile('example-checks.json',checks)],
    limits:['Only the named SDK operations run. Markdown outside the example blocks remains inert.', 'Proposed expected-value corrections require review; original failures remain in the evidence.']};
}

function readRows(csv) {
  const lines=[]; let row=[],cell='',quoted=false,closed=false;
  for(let i=0;i<csv.length;i++) {
    const ch=csv[i];
    if(quoted){if(ch==='"'){if(csv[i+1]==='"'){cell+='"';i++;}else{quoted=false;closed=true;}}else cell+=ch;}
    else if(ch==='"'&&!cell&&!closed)quoted=true;
    else if(ch===','){row.push(cell);cell='';closed=false;}
    else if(ch==='\n'||ch==='\r'){if(ch==='\r'&&csv[i+1]==='\n')i++;row.push(cell);lines.push(row);row=[];cell='';closed=false;}
    else{if(closed||ch==='"')throw Error('CSV_QUOTING');cell+=ch;}
    if(lines.length>2001)throw Error('CSV_ROW_LIMIT');
  }
  if(quoted)throw Error('CSV_UNCLOSED_QUOTE');
  if(row.length||cell||closed){row.push(cell);lines.push(row);}
  if(canonical(lines.shift())!==canonical(['group','amount'])||!lines.length)throw Error('CSV_HEADER: group,amount');
  return lines.map((item,index)=>{
    if(item.length!==2||!item[0].trim()||item[0].length>100||!/^[-]?(0|[1-9][0-9]{0,8})$/.test(item[1]))throw Error(`CSV_ROW: ${index+2}`);
    const amount=Number(item[1]); integer(amount,-1000000,1000000,'amount');
    return {group:item[0],amount};
  });
}
function csvCell(value) { const raw=String(value);return '"'+(/^[=+\-@\t\r]/.test(raw)?"'"+raw:raw).replaceAll('"','""')+'"'; }
async function publicData(input, checkpoint) {
  const rows=readRows(input.csv), groups=new Map();
  for(const row of rows){await checkpoint('analysing');const old=groups.get(row.group)||{group:row.group,count:0,total:0,min:row.amount,max:row.amount};old.count++;old.total+=row.amount;old.min=Math.min(old.min,row.amount);old.max=Math.max(old.max,row.amount);groups.set(row.group,old);}
  const summary=[...groups.values()].sort((a,b)=>a.group<b.group?-1:a.group>b.group?1:0);
  const total=rows.reduce((sum,row)=>sum+row.amount,0);
  if(summary.reduce((sum,row)=>sum+row.total,0)!==total)throw Error('RECONCILIATION_FAILED');
  const report='<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>SUCCESSOR data report</title><style>body{font:18px system-ui;max-width:60rem;margin:3rem auto;padding:1rem}td,th{padding:.6rem;text-align:left;border-bottom:1px solid #aaa}table{border-collapse:collapse}</style><h1>Public-data report</h1><p>'+html(rows.length)+' rows · '+html(input.unit)+' · exact total '+html(total)+'</p><table><thead><tr><th>Group</th><th>Count</th><th>Total</th><th>Minimum</th><th>Maximum</th></tr></thead><tbody>'+summary.map(row=>'<tr>'+[row.group,row.count,row.total,row.min,row.max].map(v=>'<td>'+html(v)+'</td>').join('')+'</tr>').join('')+'</tbody></table><p>Descriptive results for the supplied data only. Coverage and causal interpretation require review.</p></html>';
  return {decision:'REPORT_READY_FOR_REVIEW',summary:{rows:rows.length,groups:summary.length,total,unit:input.unit},evidence:{groups:summary,reconciled:true},
    artifacts:[file('report.html','text/html',report),file('summary.csv','text/csv','group,count,total,min,max\n'+summary.map(row=>[csvCell(row.group),row.count,row.total,row.min,row.max].join(',')).join('\n')+'\n'),jsonFile('analysis.json',{total,groups:summary})],
    limits:['Exact descriptive arithmetic does not establish population coverage or causality.', 'CSV labels are escaped against formula interpretation; the source remains in the mission specification.']};
}

function fraction(n,d=1n){if(d===0n)throw Error('ZERO_DENOMINATOR');if(d<0n){n=-n;d=-d;}let a=n<0n?-n:n,b=d;while(b){const c=a%b;a=b;b=c;}return [n/(a||1n),d/(a||1n)];}
function add(a,b){return fraction(a[0]*b[1]+b[0]*a[1],a[1]*b[1]);}
function mul(a,b){return fraction(a[0]*b[0],a[1]*b[1]);}
function abs(a){return [a[0]<0n?-a[0]:a[0],a[1]];}
function rationalText(a){return `${a[0]}/${a[1]}`;}
function polynomial(coefficients,x){let result=[0n,1n];for(const c of [...coefficients].reverse())result=add(mul(result,x),[BigInt(c),1n]);return result;}
async function numerical(input,checkpoint){
  const h=fraction(BigInt(input.upper-input.lower),BigInt(input.steps));let trap=[0n,1n],simpson=[0n,1n];
  for(let i=0;i<=input.steps;i++){await checkpoint('integrating');const y=polynomial(input.coefficients,add([BigInt(input.lower),1n],mul(h,[BigInt(i),1n])));trap=add(trap,mul(y,[i===0||i===input.steps?1n:2n,1n]));simpson=add(simpson,mul(y,[i===0||i===input.steps?1n:i%2?4n:2n,1n]));}
  trap=mul(trap,mul(h,[1n,2n]));simpson=mul(simpson,mul(h,[1n,3n]));
  let exact=[0n,1n];input.coefficients.forEach((c,i)=>{const n=BigInt(i+1);exact=add(exact,fraction(BigInt(c)*(BigInt(input.upper)**n-BigInt(input.lower)**n),n));});
  const error=value=>abs(add(value,[-exact[0],exact[1]]));const tolerance=fraction(BigInt(input.tolerancePpm),1000000n);
  const passes=value=>{const e=error(value);return e[0]*tolerance[1]<=tolerance[0]*e[1];};
  const evidence={analytic:rationalText(exact),trapezoid:rationalText(trap),simpson:rationalText(simpson),
    absoluteErrors:{trapezoid:rationalText(error(trap)),simpson:rationalText(error(simpson))},absoluteTolerance:rationalText(tolerance),
    passes:{trapezoid:passes(trap),simpson:passes(simpson)},arithmetic:'Exact reduced BigInt rational numbers; coefficients in increasing powers'};
  return {decision:passes(simpson)?'WITHIN_DECLARED_TOLERANCE':'REPAIR_REQUIRED',summary:{steps:input.steps,degree:input.coefficients.length-1,...evidence.passes},
    evidence,artifacts:[jsonFile('numerical.json',evidence),jsonFile('calculation-input.json',input)],
    limits:['This reconstructs polynomial quadrature under stated assumptions, not an arbitrary scientific paper.', 'Input uncertainty, physical-model validity and external replication are unmeasured.']};
}

const HANDLERS = {reliability,performance:performanceWork,documentation,'public-data':publicData,numerical};

async function plan(spec, now = new Date().toISOString(), adapter = null) {
  const checked=validate(spec,adapter), identity=await semanticIdentity(checked,adapter);
  const mission=missionFor({name:checked.name,budget:'1',now});
  mission.missionId='work-'+identity.slice(0,24); mission.title=checked.name;
  mission.objective=(adapter?.manifest || REGISTRY.find(item=>item.id===checked.family)).scope;
  mission.budget.limitBaseUnits='0';mission.budget.maxJobs=7;
  mission.proofProtocol.minimumMargin=0;
  mission.allowedTools=['fixed-workbench-'+checked.family];
  mission.rights[0].dataClass=checked.rights.dataClass==='synthetic'?'synthetic':'public-licensed-nonpersonal';
  mission.rights[0].license=checked.rights.license;mission.rights[0].sourceId='mission-input';
  const proposed=createPortfolioJobs(mission), grouped=new Map();
  for(const job of proposed){if(!grouped.has(job.family))grouped.set(job.family,[]);grouped.get(job.family).push(job);}
  const jobs=[...grouped.entries()].map(([family,items])=>({...items[0],jobId:mission.missionId+':'+family,
    objective:items.map(item=>item.objective).join(' '),covers:items.flatMap(item=>item.covers),
    acceptance:{...items[0].acceptance,predicate:'Review the exact input, delivered artifacts and retained failures for: '+items.map(item=>item.objective).join(' ')}}));
  const order=['constitution','evidence','formation','challenge','verification','admission','renewal'];
  jobs.sort((a,b)=>order.indexOf(a.family)-order.indexOf(b.family));
  const edges=jobs.slice(1).map((job,i)=>({from:jobs[i].jobId,to:job.jobId,kind:'evidence'}));
  for(const edge of edges)jobs.find(job=>job.jobId===edge.to).authorizedInputs.push(edge.from);
  return compileJobs(mission,{jobs,edges,now});
}

async function run(spec, {sourceHash,signal,onProgress=()=>{},onCheckpoint=async()=>{},clock=()=>globalThis.performance.now(),adapter=null}={}) {
  const input=validate(spec,adapter);
  if(!/^[a-f0-9]{64}$/.test(sourceHash||''))throw Error('SOURCE_IDENTITY_REQUIRED');
  const started=clock();let count=0;
  const checkpoint=async phase=>{
    await onCheckpoint();
    if(signal?.aborted)throw Error('CANCELLED');
    if(clock()-started>60000)throw Error('TIME_BUDGET_EXCEEDED');
    if(count++%25===0){onProgress(phase);await new Promise(resolve=>setTimeout(resolve,0));}
  };
  await checkpoint('planning');
  const missionDigest=await semanticIdentity(input,adapter), createdAt=new Date().toISOString();
  const frozen={schema:VERSION,missionDigest,sourceHash,adapter:input.family,adapterVersion:adapter?.manifest.version || 1,
    model:null,provider:null,authority:[],inputPolicy:input.rights,reviewMinutes:input.reviewMinutes};
  const releaseDigest=await digest('workbench-release',frozen);
  const compilation=await plan(input,createdAt,adapter);
  const result=await (adapter?.execute || HANDLERS[input.family])(input.inputs,checkpoint);
  fields(result,['decision','summary','evidence','artifacts','limits'],'adapter output');
  text(result.decision,128,'decision');
  if(!Array.isArray(result.artifacts)||result.artifacts.length<1||result.artifacts.length>12)throw Error('ARTIFACT_COUNT');
  await checkpoint('verifying');
  const artifacts=await Promise.all(result.artifacts.map(async artifact=>({...artifact,digest:await digest('workbench-artifact',artifact)})));
  const body={schema:VERSION,spec:input,createdAt,frozen,releaseDigest,compilation,result:{...result,artifacts},
    economics:{elapsedMilliseconds:Math.max(0,Math.round(clock()-started)),providerSpendBaseUnits:'0',settlementSpendBaseUnits:'0',
      computeCost:null,humanMinutes:null,reviewCapacityMinutes:input.reviewMinutes,allowanceIs:'UNFUNDED'},
    evaluation:{scope:'PUBLIC_LOCAL_EXECUTION',independentProof:false,admission:'HOLD',authority:[],settlement:'NOT_CONNECTED'},
    chronicle:[{kind:'local-result',decision:result.decision,missionDigest,releaseDigest,inheritedProof:false,inheritedAuthority:false}]};
  const pack={...body,integrityDigest:await digest('workbench-pack',body)};
  await inspectPack(pack,adapter);
  return pack;
}

async function inspectPack(value, adapter = null) {
  fields(value,['schema','spec','createdAt','frozen','releaseDigest','compilation','result','economics','evaluation','chronicle','integrityDigest'],'pack');
  validate(value.spec,adapter);
  const {integrityDigest,...body}=value;
  if(integrityDigest!==await digest('workbench-pack',body))throw Error('PACK_INTEGRITY');
  if(value.frozen.missionDigest!==await semanticIdentity(value.spec,adapter)||value.releaseDigest!==await digest('workbench-release',value.frozen))throw Error('PACK_BINDING');
  if(!Array.isArray(value.result.artifacts)||value.result.artifacts.length>12)throw Error('PACK_ARTIFACTS');
  for(const artifact of value.result.artifacts){fields(artifact,['name','type','content','digest'],'artifact');
    if(['mission.json','evidence.json','READ_ME.txt','lifecycle.json','signed-receipt.json','source-key.txt'].includes(artifact.name)||
       /^(con|prn|aux|nul|com[0-9]|lpt[0-9])(\.|$)/i.test(artifact.name)||artifact.name.endsWith('.'))throw Error('RESERVED_ARTIFACT_NAME');
    if(!/^[A-Za-z0-9][A-Za-z0-9_.-]{0,79}$/.test(artifact.name)||!['text/javascript','text/plain','text/csv','text/html','text/markdown','application/json'].includes(artifact.type)||typeof artifact.content!=='string'||artifact.content.length>200000)throw Error('ARTIFACT_POLICY');
    const {digest:hash,...content}=artifact;if(hash!==await digest('workbench-artifact',content))throw Error('ARTIFACT_INTEGRITY');}
  if(new Set(value.result.artifacts.map(item=>item.name)).size!==value.result.artifacts.length)throw Error('DUPLICATE_ARTIFACT');
  if(canonical(value.compilation)!==canonical(await plan(value.spec,value.createdAt,adapter)))throw Error('JOB_BINDING');
  return {spec:clone(value.spec),history:{missionDigest:value.frozen.missionDigest,releaseDigest:value.releaseDigest,decision:value.result.decision},
    authentication:'UNAUTHENTICATED_HISTORICAL_IMPORT',activeProof:[],activeAuthority:[]};
}

function createWorkbench(adapters = []) {
  const installed = new Map();
  for(const adapter of adapters){
    fields(adapter,['manifest','validate','execute'],'installed adapter');
    const manifest=adapter.manifest;
    fields(manifest,['id','version','en','fr','scope','artifact'],'adapter manifest');
    if(!/^[a-z][a-z0-9-]{1,47}$/.test(manifest.id)||REGISTRY.some(item=>item.id===manifest.id)||installed.has(manifest.id))throw Error('ADAPTER_ID');
    integer(manifest.version,1,1000000,'adapter version');
    for(const key of ['en','fr','scope','artifact'])text(manifest[key],1000,key);
    if(typeof adapter.validate!=='function'||typeof adapter.execute!=='function')throw Error('ADAPTER_INTERFACE');
    installed.set(manifest.id,Object.freeze({...adapter,manifest:Object.freeze(clone(manifest))}));
  }
  const resolve=spec=>installed.get(spec.family)||null;
  return Object.freeze({registry:Object.freeze([...REGISTRY,...[...installed.values()].map(item=>item.manifest)]),
    validate:spec=>validate(spec,resolve(spec)),
    run:(spec,options)=>run(spec,{...options,adapter:resolve(spec)}),
    plan:(spec,now)=>plan(spec,now,resolve(spec)),
    inspectPack:pack=>inspectPack(pack,resolve(pack.spec))});
}

return {VERSION,REGISTRY,example,validate,semanticIdentity,plan,run,inspectPack,createWorkbench};
})();
__modules["vendor/alpha/examples/successor-alpha/engine.mjs"]=(()=>{
// SPDX-License-Identifier: Apache-2.0

const DEFAULT_LIMITS = Object.freeze({
    maxCsvBytes: 200000, maxRows: 1500, maxColumns: 32, maxCellChars: 4096,
    maxOutputPairs: 10000, maxOutputBytes: 2000000,
});

const STRATEGIES = Object.freeze([
    Object.freeze({ id: 'nested_scan', label: 'Nested scan · current method' }),
    Object.freeze({ id: 'fixed_right_hash', label: 'Hash the right table · competitive baseline' }),
    Object.freeze({ id: 'smaller_side_hash', label: 'Hash the smaller table · candidate' }),
    Object.freeze({ id: 'sort_merge', label: 'Sort and merge · competitive baseline' }),
]);

const encoder = new TextEncoder();
const byteLength = value => encoder.encode(value).length;
const fail = message => { throw new Error(message); };
const ownKeys = (value, keys) => value && typeof value === 'object' && !Array.isArray(value)
    && Object.keys(value).length === keys.length && keys.every(key => Object.hasOwn(value, key));

function limitsFor(overrides = {}) {
    if (!overrides || typeof overrides !== 'object' || Array.isArray(overrides)) fail('Limits must be an object.');
    if (Object.keys(overrides).some(key => !Object.hasOwn(DEFAULT_LIMITS, key))) fail('Unknown resource limit.');
    const limits = { ...DEFAULT_LIMITS, ...overrides };
    for (const [key, ceiling] of Object.entries(DEFAULT_LIMITS)) {
        if (!Number.isSafeInteger(limits[key]) || limits[key] < 1 || limits[key] > ceiling) {
            fail(`${key} must be an integer from 1 to ${ceiling}.`);
        }
    }
    return limits;
}

function freeze(value) {
    if (value && typeof value === 'object') {
        Object.freeze(value);
        for (const child of Object.values(value)) freeze(child);
    }
    return value;
}

function parseCsv(text, overrides = {}) {
    const limits = limitsFor(overrides);
    if (typeof text !== 'string' || text.length > limits.maxCsvBytes || byteLength(text) > limits.maxCsvBytes) {
        fail(`Each CSV must contain at most ${limits.maxCsvBytes} UTF-8 bytes.`);
    }
    if (text.includes('\0')) fail('CSV cannot contain NUL characters.');
    if (text.startsWith('\uFEFF')) text = text.slice(1);
    if (!text.length) fail('CSV needs a header row.');
    const records = [];
    let record = [], field = '', quoted = false, closed = false, started = false;
    const fieldDone = () => {
        if (field.length > limits.maxCellChars) fail(`CSV cells exceed ${limits.maxCellChars} characters.`);
        record.push(field);
        if (record.length > limits.maxColumns) fail(`CSV exceeds ${limits.maxColumns} columns.`);
        field = ''; closed = false; started = false;
    };
    const recordDone = () => {
        fieldDone(); records.push(record); record = [];
        if (records.length > limits.maxRows + 1) fail(`CSV exceeds ${limits.maxRows} data rows.`);
    };
    for (let index = 0; index < text.length; index += 1) {
        const char = text[index];
        if (quoted) {
            if (char === '"') {
                if (text[index + 1] === '"') { field += '"'; index += 1; }
                else { quoted = false; closed = true; }
            } else field += char;
        } else if (char === ',') fieldDone();
        else if (char === '\r' || char === '\n') {
            if (char === '\r' && text[index + 1] === '\n') index += 1;
            recordDone();
        } else if (char === '"') {
            if (started || closed) fail('Quote inside an unquoted CSV cell.');
            quoted = true; started = true;
        } else {
            if (closed) fail('Unexpected text after a closing CSV quote.');
            field += char; started = true;
        }
        if (field.length > limits.maxCellChars) fail(`CSV cells exceed ${limits.maxCellChars} characters.`);
    }
    if (quoted) fail('Unclosed quoted CSV cell.');
    if (record.length || started || closed || field.length) recordDone();
    if (!records.length) fail('CSV needs a header row.');
    const [headers, ...rows] = records;
    if (headers.some(header => !header.trim()) || new Set(headers).size !== headers.length) {
        fail('CSV headers must be nonempty and unique.');
    }
    if (rows.some(row => row.length !== headers.length)) fail('Every CSV row must have the header column count.');
    return { headers, rows };
}

function createJoinMission(input) {
    if (!input || typeof input !== 'object' || Array.isArray(input)) fail('Mission inputs must be an object.');
    const allowed = ['leftCsv', 'rightCsv', 'leftKey', 'rightKey', 'limits'];
    if (Object.keys(input).some(key => !allowed.includes(key))) fail('Unknown mission input.');
    const limits = limitsFor(input.limits);
    const left = parseCsv(input.leftCsv, limits), right = parseCsv(input.rightCsv, limits);
    for (const [side, key] of [[left, input.leftKey], [right, input.rightKey]]) {
        if (typeof key !== 'string' || !side.headers.includes(key)) fail('Choose a key column present in each CSV.');
        side.key = key; side.keyIndex = side.headers.indexOf(key);
        if (side.rows.some(row => row[side.keyIndex] === '')) fail('Join keys must be nonempty exact strings.');
    }
    const frequencies = new Map();
    for (const row of right.rows) frequencies.set(row[right.keyIndex], (frequencies.get(row[right.keyIndex]) || 0) + 1);
    let outputPairs = 0;
    for (const row of left.rows) {
        outputPairs += frequencies.get(row[left.keyIndex]) || 0;
        if (outputPairs > limits.maxOutputPairs) fail(`Join exceeds ${limits.maxOutputPairs} output pairs.`);
    }
    return freeze({
        schemaVersion: 1, kind: 'catalog_join', left, right, limits,
        workload: { leftRows: left.rows.length, rightRows: right.rows.length,
            referenceComparisons: left.rows.length * right.rows.length, outputPairs },
    });
}

function validateJoinMission(mission) {
    if (!ownKeys(mission, ['schemaVersion', 'kind', 'left', 'right', 'limits', 'workload'])
        || mission.schemaVersion !== 1 || mission.kind !== 'catalog_join') fail('Unsupported join mission.');
    if (!ownKeys(mission.limits, Object.keys(DEFAULT_LIMITS))) fail('Imported missions require all six resource limits.');
    const limits = limitsFor(mission.limits);
    for (const side of [mission.left, mission.right]) {
        if (!ownKeys(side, ['headers', 'rows', 'key', 'keyIndex']) || !Array.isArray(side.headers)
            || !side.headers.length || side.headers.length > limits.maxColumns
            || side.headers.some(header => typeof header !== 'string' || !header.trim()
                || header.length > limits.maxCellChars || header.includes('\0'))
            || new Set(side.headers).size !== side.headers.length || typeof side.key !== 'string'
            || !Number.isSafeInteger(side.keyIndex) || side.headers[side.keyIndex] !== side.key
            || !Array.isArray(side.rows) || side.rows.length > limits.maxRows) fail('Invalid mission table.');
        let bytes = side.headers.reduce((sum, header) => sum + byteLength(header), 0);
        if (bytes > limits.maxCsvBytes) fail('Mission table exceeds input budget.');
        for (const row of side.rows) {
            if (!Array.isArray(row) || row.length !== side.headers.length || row.some(cell => typeof cell !== 'string'
                || cell.length > limits.maxCellChars || cell.includes('\0')) || row[side.keyIndex] === '') {
                fail('Invalid mission row or empty key.');
            }
            bytes += row.reduce((sum, cell) => sum + byteLength(cell), 0);
            if (bytes > limits.maxCsvBytes) fail('Mission table exceeds input budget.');
        }
    }
    if (!ownKeys(mission.workload, ['leftRows', 'rightRows', 'referenceComparisons', 'outputPairs'])
        || mission.workload.leftRows !== mission.left.rows.length
        || mission.workload.rightRows !== mission.right.rows.length
        || mission.workload.referenceComparisons !== mission.left.rows.length * mission.right.rows.length
        || !Number.isSafeInteger(mission.workload.outputPairs) || mission.workload.outputPairs < 0
        || mission.workload.outputPairs > limits.maxOutputPairs) fail('Invalid mission workload.');
    const frequencies = new Map();
    for (const row of mission.right.rows) {
        const key = row[mission.right.keyIndex];
        frequencies.set(key, (frequencies.get(key) || 0) + 1);
    }
    let count = 0;
    for (const row of mission.left.rows) count += frequencies.get(row[mission.left.keyIndex]) || 0;
    if (count !== mission.workload.outputPairs || count > limits.maxOutputPairs) fail('Mission join count is invalid.');
    return true;
}

const validateMission = validateJoinMission;

const pairOrder = (a, b) => a[0] - b[0] || a[1] - b[1];
const clock = () => globalThis.performance?.now() ?? Date.now();

function executeJoin(mission, strategyId) {
    validateJoinMission(mission);
    const definition = STRATEGIES.find(strategy => strategy.id === strategyId);
    if (!definition) fail('Unknown join strategy.');
    const start = clock(), pairs = [];
    const metrics = { keyComparisons: 0, hashInserts: 0, hashProbes: 0,
        indexedRows: 0, sortedRows: 0, outputPairs: 0, logicalOperations: 0, elapsedMicros: 0 };
    const { left, right } = mission;
    let buildSide = null;
    const add = (leftIndex, rightIndex) => {
        if (pairs.length >= mission.limits.maxOutputPairs) fail('Join output budget exhausted.');
        pairs.push([leftIndex, rightIndex]);
    };
    if (strategyId === 'nested_scan') {
        for (let leftIndex = 0; leftIndex < left.rows.length; leftIndex += 1) {
            for (let rightIndex = 0; rightIndex < right.rows.length; rightIndex += 1) {
                metrics.keyComparisons += 1;
                if (left.rows[leftIndex][left.keyIndex] === right.rows[rightIndex][right.keyIndex]) add(leftIndex, rightIndex);
            }
        }
    } else if (strategyId === 'fixed_right_hash' || strategyId === 'smaller_side_hash') {
        buildSide = strategyId === 'smaller_side_hash' && left.rows.length < right.rows.length ? 'left' : 'right';
        const build = buildSide === 'left' ? left : right, probe = buildSide === 'left' ? right : left;
        const index = new Map();
        for (let row = 0; row < build.rows.length; row += 1) {
            const key = build.rows[row][build.keyIndex];
            if (!index.has(key)) index.set(key, []);
            index.get(key).push(row); metrics.hashInserts += 1;
        }
        metrics.indexedRows = build.rows.length;
        for (let row = 0; row < probe.rows.length; row += 1) {
            metrics.hashProbes += 1;
            for (const matched of index.get(probe.rows[row][probe.keyIndex]) || []) {
                if (buildSide === 'left') add(matched, row); else add(row, matched);
            }
        }
    } else {
        const ordered = side => {
            let source = side.rows.map((row, rowIndex) => ({ key: row[side.keyIndex], rowIndex }));
            let target = new Array(source.length);
            for (let width = 1; width < source.length; width *= 2) {
                for (let startIndex = 0; startIndex < source.length; startIndex += width * 2) {
                    const middle = Math.min(startIndex + width, source.length);
                    const end = Math.min(startIndex + width * 2, source.length);
                    let first = startIndex, second = middle;
                    for (let out = startIndex; out < end; out += 1) {
                        if (first >= middle) target[out] = source[second++];
                        else if (second >= end) target[out] = source[first++];
                        else {
                            metrics.keyComparisons += 1;
                            target[out] = source[first].key <= source[second].key ? source[first++] : source[second++];
                        }
                    }
                }
                [source, target] = [target, source];
            }
            return source;
        };
        const first = ordered(left), second = ordered(right);
        metrics.sortedRows = first.length + second.length;
        let a = 0, b = 0;
        while (a < first.length && b < second.length) {
            metrics.keyComparisons += 1;
            if (first[a].key < second[b].key) { a += 1; continue; }
            if (first[a].key > second[b].key) { b += 1; continue; }
            let endA = a + 1, endB = b + 1;
            while (endA < first.length) {
                metrics.keyComparisons += 1;
                if (first[endA].key !== first[a].key) break;
                endA += 1;
            }
            while (endB < second.length) {
                metrics.keyComparisons += 1;
                if (second[endB].key !== second[b].key) break;
                endB += 1;
            }
            for (let i = a; i < endA; i += 1) for (let j = b; j < endB; j += 1) add(first[i].rowIndex, second[j].rowIndex);
            a = endA; b = endB;
        }
    }
    pairs.sort(pairOrder);
    metrics.outputPairs = pairs.length;
    metrics.logicalOperations = metrics.keyComparisons + metrics.hashInserts + metrics.hashProbes + metrics.outputPairs;
    metrics.elapsedMicros = Math.max(0, Math.round((clock() - start) * 1000));
    return { strategyId, label: definition.label, buildSide, pairs, metrics };
}

function independentReference(mission) {
    const expected = [];
    for (let i = 0; i < mission.left.rows.length; i += 1) {
        const key = mission.left.rows[i][mission.left.keyIndex];
        for (let j = 0; j < mission.right.rows.length; j += 1) {
            if (key === mission.right.rows[j][mission.right.keyIndex]) expected.push([i, j]);
        }
    }
    if (expected.length !== mission.workload.outputPairs) fail('Mission output count differs from independent enumeration.');
    return expected;
}

function verifyJoinResult(mission, pairs) {
    validateJoinMission(mission);
    if (!Array.isArray(pairs) || pairs.length > mission.limits.maxOutputPairs) fail('Invalid join output.');
    const expected = independentReference(mission);
    if (pairs.length !== expected.length || pairs.some((pair, index) => !Array.isArray(pair) || pair.length !== 2
        || pair[0] !== expected[index][0] || pair[1] !== expected[index][1])) fail('Join output failed independent exact verification.');
    return true;
}

function reconcile(mission, pairs) {
    const { left, right } = mission;
    const sharedFields = left.headers.flatMap((name, leftColumn) => {
        const rightColumn = right.headers.indexOf(name);
        return leftColumn !== left.keyIndex && rightColumn >= 0 && rightColumn !== right.keyIndex
            ? [{ name, leftColumn, rightColumn }] : [];
    });
    const matchedLeft = new Set(), matchedRight = new Set(), conflicts = [];
    for (const [leftIndex, rightIndex] of pairs) {
        matchedLeft.add(leftIndex); matchedRight.add(rightIndex);
        const fieldIndices = sharedFields.flatMap((field, index) =>
            left.rows[leftIndex][field.leftColumn] !== right.rows[rightIndex][field.rightColumn] ? [index] : []);
        if (fieldIndices.length) conflicts.push({ leftIndex, rightIndex, fieldIndices });
    }
    return { matchedPairs: pairs.length, matchedLeftRows: matchedLeft.size, matchedRightRows: matchedRight.size,
        unmatchedLeft: left.rows.flatMap((_, index) => matchedLeft.has(index) ? [] : [index]),
        unmatchedRight: right.rows.flatMap((_, index) => matchedRight.has(index) ? [] : [index]), sharedFields, conflicts };
}

async function runJoinExperiment(mission, options = {}) {
    validateJoinMission(mission);
    if (!options || typeof options !== 'object' || Array.isArray(options)
        || Object.keys(options).some(key => !['checkpoint', 'signal', 'onProgress'].includes(key))) fail('Invalid experiment options.');
    const checkpoint = async () => {
        if (options.signal?.aborted) fail('Experiment stopped. No result was admitted.');
        if (options.checkpoint) await options.checkpoint();
        if (options.signal?.aborted) fail('Experiment stopped. No result was admitted.');
    };
    await checkpoint();
    const expected = independentReference(mission), strategies = [];
    for (const definition of STRATEGIES) {
        await checkpoint();
        options.onProgress?.({ strategyId: definition.id, completed: strategies.length, total: STRATEGIES.length });
        const result = executeJoin(mission, definition.id);
        if (result.pairs.length !== expected.length || result.pairs.some((pair, index) =>
            pair[0] !== expected[index][0] || pair[1] !== expected[index][1])) fail('A strategy failed independent exact verification.');
        strategies.push({ ...result, verified: true });
    }
    await checkpoint();
    return experimentResult(mission, strategies, expected);
}

function experimentResult(mission, strategies, expected) {
    const candidate = strategies.find(result => result.strategyId === 'smaller_side_hash');
    const comparisons = strategies.filter(result => result !== candidate).map(result => ({
        strategyId: result.strategyId,
        logicalOperationsSaved: result.metrics.logicalOperations - candidate.metrics.logicalOperations,
        indexedRowsSaved: result.metrics.indexedRows - candidate.metrics.indexedRows,
        auxiliaryRowsSaved: result.metrics.indexedRows + 2 * result.metrics.sortedRows - candidate.metrics.indexedRows,
        observedMicrosSaved: result.metrics.elapsedMicros - candidate.metrics.elapsedMicros,
    }));
    return {
        schemaVersion: 1, missionKind: 'catalog_join', candidateStrategyId: 'smaller_side_hash',
        incumbentStrategyId: 'nested_scan', strategies, reconciliation: reconcile(mission, expected),
        assessment: { state: 'local_demonstration', independentReview: 'pending', externalAuthority: false,
            superiorityClaim: false, novelAlgorithm: false, localCorrectness: true, comparisons,
            explanation: 'All four methods returned the same complete join. Smaller-side hashing is a known heuristic. '
                + 'Operation and auxiliary-row counts describe this workload; timings are single local observations. '
                + 'Independent confirmation and economic benefit remain unestablished.' },
        measurementNotes: [
            'Keys are exact, case-sensitive strings; no trimming or numeric conversion. Duplicate keys preserve every matching row pair.',
            'A conflict means unequal exact text in a shared non-key column, not evidence that either catalog is wrong.',
            'Logical operations count key comparisons, indexed-row insertions, hash probes, and emitted pairs. '
                + 'They omit string length, hashing internals, allocation, canonical output sorting, verification, and export costs.',
            'indexedRows/sortedRows count indexed row references or sorted records, not bytes or measured peak memory. '
                + 'Merge sorting also uses a scratch array of the same total row count.',
            'One bounded execution per method; no statistical timing claim, cost saving, model discovery, or external certification.',
            'CSV exports prefix formula-like cells with an apostrophe for spreadsheet safety; exact JSON preserves original strings.',
        ],
    };
}

function sameData(left, right) {
    if (left === right) return true;
    if (Array.isArray(left) || Array.isArray(right)) return Array.isArray(left) && Array.isArray(right)
        && left.length === right.length && left.every((value, index) => sameData(value, right[index]));
    if (left && right && typeof left === 'object' && typeof right === 'object') {
        const keys = Object.keys(left);
        return keys.length === Object.keys(right).length && keys.every(key => Object.hasOwn(right, key) && sameData(left[key], right[key]));
    }
    return false;
}

function verifyExperiment(mission, result) {
    validateJoinMission(mission);
    if (!result || typeof result !== 'object' || !Array.isArray(result.strategies)
        || result.strategies.length !== STRATEGIES.length) fail('Invalid experiment report.');
    const expected = independentReference(mission), checked = [];
    for (let index = 0; index < STRATEGIES.length; index += 1) {
        const actual = result.strategies[index];
        if (!actual || actual.strategyId !== STRATEGIES[index].id || !actual.metrics
            || !Number.isSafeInteger(actual.metrics.elapsedMicros) || actual.metrics.elapsedMicros < 0) {
            fail('Invalid strategy record or historical timing.');
        }
        const recomputed = executeJoin(mission, STRATEGIES[index].id);
        recomputed.metrics.elapsedMicros = actual.metrics.elapsedMicros;
        const verified = { ...recomputed, verified: true };
        if (!sameData(verified, actual) || recomputed.pairs.length !== expected.length
            || recomputed.pairs.some((pair, row) => pair[0] !== expected[row][0] || pair[1] !== expected[row][1])) {
            fail('Experiment record differs from deterministic recomputation.');
        }
        checked.push(verified);
    }
    if (!sameData(experimentResult(mission, checked, expected), result)) {
        fail('Experiment assessment or reconciliation differs from deterministic recomputation.');
    }
    return { valid: true, correctnessRecomputed: true, operationCountsRecomputed: true,
        historicalTimingsVerified: false, externalIndependence: false };
}

function csvText(rows, limits, spreadsheetSafe = true) {
    const lines = [];
    let bytes = 0;
    for (const row of rows) {
        const line = row.map(value => {
            let cell = String(value);
            if (spreadsheetSafe && /^(?:\s*[=+\-@]|[\t\r\n])/.test(cell)) cell = `'${cell}`;
            return /[",\r\n]/.test(cell) ? `"${cell.replaceAll('"', '""')}"` : cell;
        }).join(',') + '\r\n';
        bytes += byteLength(line);
        if (bytes > limits.maxOutputBytes) fail(`CSV artifact exceeds ${limits.maxOutputBytes} bytes.`);
        lines.push(line);
    }
    return lines.join('');
}

function exportJoinedCsv(mission, pairs) {
    verifyJoinResult(mission, pairs);
    const headers = [...mission.left.headers.map(header => `left.${header}`), ...mission.right.headers.map(header => `right.${header}`)];
    function* rows() {
        yield headers;
        for (const [a, b] of pairs) yield [...mission.left.rows[a], ...mission.right.rows[b]];
    }
    return csvText(rows(), mission.limits);
}

function exportReconciliationCsv(mission, reconciliation, type = 'conflicts') {
    validateJoinMission(mission);
    const actual = reconcile(mission, independentReference(mission));
    if (!sameData(actual, reconciliation)) fail('Reconciliation differs from independent source checking.');
    if (type === 'unmatched_left' || type === 'unmatched_right') {
        const side = type === 'unmatched_left' ? mission.left : mission.right;
        const indices = type === 'unmatched_left' ? actual.unmatchedLeft : actual.unmatchedRight;
        return csvText([side.headers, ...indices.map(index => side.rows[index])], mission.limits);
    }
    if (type !== 'conflicts') fail('Unknown reconciliation artifact.');
    function* rows() {
        yield ['key', 'left_data_row', 'right_data_row', 'field', 'left_value', 'right_value'];
        for (const conflict of actual.conflicts) for (const index of conflict.fieldIndices) {
            const field = actual.sharedFields[index];
            yield [mission.left.rows[conflict.leftIndex][mission.left.keyIndex], conflict.leftIndex + 1,
                conflict.rightIndex + 1, field.name, mission.left.rows[conflict.leftIndex][field.leftColumn],
                mission.right.rows[conflict.rightIndex][field.rightColumn]];
        }
    }
    return csvText(rows(), mission.limits);
}

function buildArtifacts(mission, result) {
    verifyExperiment(mission, result);
    const candidate = result.strategies.find(strategy => strategy.strategyId === 'smaller_side_hash');
    if (!candidate) fail('Candidate result is missing.');
    const joinedCsv = exportJoinedCsv(mission, candidate.pairs);
    const unmatchedLeftCsv = exportReconciliationCsv(mission, result.reconciliation, 'unmatched_left');
    const unmatchedRightCsv = exportReconciliationCsv(mission, result.reconciliation, 'unmatched_right');
    const conflictsCsv = exportReconciliationCsv(mission, result.reconciliation, 'conflicts');
    const exactJson = JSON.stringify({ schemaVersion: 1, mission, result }, null, 2) + '\n';
    if (byteLength(exactJson) > mission.limits.maxOutputBytes * 4) fail('Exact JSON artifact exceeds its 8 MB ceiling.');
    return { joinedCsv, unmatchedLeftCsv, unmatchedRightCsv, conflictsCsv, exactJson };
}

function createSampleMission(options = {}) {
    if (!options || typeof options !== 'object' || Array.isArray(options)
        || Object.keys(options).some(key => !['seed', 'leftRows', 'rightRows'].includes(key))) fail('Invalid sample options.');
    const { seed = 41, leftRows = 120, rightRows = 360 } = options;
    if (!Number.isSafeInteger(seed) || seed < 0 || seed > 0xffffffff || !Number.isSafeInteger(leftRows)
        || !Number.isSafeInteger(rightRows) || leftRows < 1 || rightRows < 1
        || leftRows > DEFAULT_LIMITS.maxRows || rightRows > DEFAULT_LIMITS.maxRows) fail('Invalid sample seed or row count.');
    let state = seed >>> 0;
    const random = () => { state = (Math.imul(state, 1664525) + 1013904223) >>> 0; return state; };
    const left = [['sku', 'title', 'revision']];
    for (let index = 0; index < leftRows; index += 1) left.push([`OPEN-${String(index).padStart(5, '0')}`, `Public catalog item ${index}`, `r${random() % 4}`]);
    const right = [['sku', 'title', 'revision', 'license']];
    for (let index = 0; index < rightRows; index += 1) {
        const key = index < Math.min(leftRows, rightRows) ? index : leftRows + index;
        const source = left[key + 1];
        right.push([`OPEN-${String(key).padStart(5, '0')}`, `Public catalog item ${key}`,
            source && index % 7 !== 0 ? source[2] : `r${random() % 4}`, 'CC0 synthetic']);
    }
    const leftCsv = csvText(left, DEFAULT_LIMITS, false), rightCsv = csvText(right, DEFAULT_LIMITS, false);
    return createJoinMission({ leftCsv, rightCsv, leftKey: 'sku', rightKey: 'sku' });
}

return {DEFAULT_LIMITS,STRATEGIES,parseCsv,createJoinMission,validateJoinMission,validateMission,executeJoin,verifyJoinResult,runJoinExperiment,verifyExperiment,exportJoinedCsv,exportReconciliationCsv,buildArtifacts,createSampleMission};
})();
__modules["vendor/alpha/examples/successor-alpha/research.mjs"]=(()=>{
// SPDX-License-Identifier: Apache-2.0
const alpha=__modules["vendor/alpha/examples/successor-alpha/engine.mjs"];

const PLAN = 'successor-join-program/v1';
const STUDY = 'successor-strategy-research/v1';
const RESOLUTION = 'successor-discrepancy-resolution/v1';
const fail = message => { throw Error(message); };
const exact = (value, keys) => value && typeof value === 'object' && !Array.isArray(value)
    && Object.keys(value).length === keys.length && keys.every(key => Object.hasOwn(value, key));
const integer = (value, low, high) => Number.isSafeInteger(value) && !Object.is(value, -0) && value >= low && value <= high;

function canonical(value, state = { nodes: 0 }, depth = 0) {
    if (++state.nodes > 250000 || depth > 24) fail('Research data exceeds its structural budget.');
    if (value === null || typeof value === 'boolean' || typeof value === 'string') return JSON.stringify(value);
    if (typeof value === 'number' && Number.isSafeInteger(value) && !Object.is(value, -0)) return String(value);
    if (Array.isArray(value)) return '[' + value.map(item => canonical(item, state, depth + 1)).join(',') + ']';
    if (!value || typeof value !== 'object' || ![Object.prototype, null].includes(Object.getPrototypeOf(value))) {
        fail('Research data must contain only JSON values and safe integers.');
    }
    const keys = Object.keys(value).sort();
    return '{' + keys.map(key => JSON.stringify(key) + ':' + canonical(value[key], state, depth + 1)).join(',') + '}';
}

async function hash(value) {
    const bytes = new TextEncoder().encode(canonical(value));
    const digest = await crypto.subtle.digest('SHA-256', bytes);
    return [...new Uint8Array(digest)].map(byte => byte.toString(16).padStart(2, '0')).join('');
}

function program({ buckets = 1, uniform = false, threshold = 0, side = 'smaller', blockRows = 64 } = {}) {
    return { schema: PLAN, guard: { op: uniform ? 'uniform_key' : 'none' },
        split: { op: 'stream_partition', buckets },
        leaf: { op: 'small_switch', maxProduct: threshold, small: { op: 'nested' },
            large: { op: 'block_hash', side, rows: blockRows } } };
}

function validatePlan(plan) {
    if (!exact(plan, ['schema', 'guard', 'split', 'leaf']) || plan.schema !== PLAN
        || !exact(plan.guard, ['op']) || !['none', 'uniform_key'].includes(plan.guard.op)
        || !exact(plan.split, ['op', 'buckets']) || plan.split.op !== 'stream_partition'
        || ![1, 2, 4, 8].includes(plan.split.buckets)
        || !exact(plan.leaf, ['op', 'maxProduct', 'small', 'large']) || plan.leaf.op !== 'small_switch'
        || !integer(plan.leaf.maxProduct, 0, 2250000) || !exact(plan.leaf.small, ['op'])
        || plan.leaf.small.op !== 'nested' || !exact(plan.leaf.large, ['op', 'side', 'rows'])
        || plan.leaf.large.op !== 'block_hash' || !['left', 'right', 'smaller'].includes(plan.leaf.large.side)
        || !integer(plan.leaf.large.rows, 1, alpha.DEFAULT_LIMITS.maxRows)) fail('Invalid or unsupported join program.');
    return true;
}

function settings(options = {}) {
    const { maxAuxiliaryRows = 64, auxiliaryWeight = 0 } = options;
    if (!integer(maxAuxiliaryRows, 0, 4500) || !integer(auxiliaryWeight, 0, 1000000)) {
        fail('Use an auxiliary-row budget from 0 to 4500 and a whole objective weight from 0 to 1000000.');
    }
    return { maxAuxiliaryRows, auxiliaryWeight };
}

function constructPlans(options = {}) {
    if (!exact(options, Object.keys(options)) || Object.keys(options).some(key => key !== 'maxAuxiliaryRows')) {
        fail('Unsupported construction options.');
    }
    const { maxAuxiliaryRows } = settings(options), blockRows = Math.max(1, Math.min(1500, maxAuxiliaryRows));
    const plans = [];
    for (const buckets of [1, 2, 4, 8]) for (const uniform of [false, true]) for (const threshold of [0, 16]) {
        plans.push(program({ buckets, uniform, threshold, blockRows }));
    }
    for (const side of ['left', 'right']) for (const uniform of [false, true]) {
        plans.push(program({ side, uniform, blockRows: Math.max(1, Math.floor(blockRows / 2)) }));
    }
    for (const plan of plans) validatePlan(plan);
    return plans;
}

function executePlan(mission, plan) {
    alpha.validateJoinMission(mission); validatePlan(plan);
    const { left, right } = mission, pairs = [];
    const metrics = { keyComparisons: 0, comparedCharacters: 0, hashInsertions: 0, hashProbes: 0,
        hashedCharacters: 0, routingTests: 0, routingCharacters: 0, branchDecisions: 0,
        outputPairs: 0, peakAuxiliaryRows: 0, logicalOperations: 0 };
    const key = (side, index) => side.rows[index][side.keyIndex];
    const equal = (a, b) => {
        metrics.keyComparisons += 1;
        metrics.comparedCharacters += Math.max(a.length, b.length);
        return a === b;
    };
    const emit = (a, b) => {
        if (pairs.length >= mission.limits.maxOutputPairs) fail('Constructed plan exceeded the join output budget.');
        pairs.push([a, b]); metrics.outputPairs += 1;
    };
    let uniform = false;
    if (plan.guard.op === 'uniform_key') {
        metrics.branchDecisions += 1;
        uniform = left.rows.length > 0 && right.rows.length > 0;
        for (const side of [left, right]) {
            const first = side.rows.length ? key(side, 0) : '';
            for (let row = 0; uniform && row < side.rows.length; row += 1) uniform = equal(first, key(side, row));
        }
        if (uniform && equal(key(left, 0), key(right, 0))) {
            for (let a = 0; a < left.rows.length; a += 1) for (let b = 0; b < right.rows.length; b += 1) emit(a, b);
        }
    }
    const bucket = value => {
        let code = 2166136261;
        for (let index = 0; index < value.length; index += 1) {
            code = Math.imul(code ^ value.charCodeAt(index), 16777619) >>> 0;
            metrics.routingCharacters += 1;
        }
        return code % plan.split.buckets;
    };
    const leaf = (leftRows, rightRows, temporaryRows) => {
        const leftCount = leftRows ? leftRows.length : left.rows.length;
        const rightCount = rightRows ? rightRows.length : right.rows.length;
        const aIndex = index => leftRows ? leftRows[index] : index;
        const bIndex = index => rightRows ? rightRows[index] : index;
        metrics.peakAuxiliaryRows = Math.max(metrics.peakAuxiliaryRows, temporaryRows);
        metrics.branchDecisions += 1;
        if (leftCount * rightCount <= plan.leaf.maxProduct) {
            for (let a = 0; a < leftCount; a += 1) for (let b = 0; b < rightCount; b += 1) {
                if (equal(key(left, aIndex(a)), key(right, bIndex(b)))) emit(aIndex(a), bIndex(b));
            }
            return;
        }
        if (leftCount === 0 || rightCount === 0) return;
        const buildLeft = plan.leaf.large.side === 'left'
            || plan.leaf.large.side === 'smaller' && leftCount < rightCount;
        const build = buildLeft ? left : right, probe = buildLeft ? right : left;
        const buildCount = buildLeft ? leftCount : rightCount, probeCount = buildLeft ? rightCount : leftCount;
        const buildIndex = buildLeft ? aIndex : bIndex, probeIndex = buildLeft ? bIndex : aIndex;
        for (let start = 0; start < buildCount; start += plan.leaf.large.rows) {
            const end = Math.min(start + plan.leaf.large.rows, buildCount), index = new Map();
            metrics.peakAuxiliaryRows = Math.max(metrics.peakAuxiliaryRows, temporaryRows + end - start);
            for (let row = start; row < end; row += 1) {
                const value = key(build, buildIndex(row));
                metrics.hashInsertions += 1; metrics.hashedCharacters += value.length;
                if (!index.has(value)) index.set(value, []);
                index.get(value).push(buildIndex(row));
            }
            for (let row = 0; row < probeCount; row += 1) {
                const value = key(probe, probeIndex(row));
                metrics.hashProbes += 1; metrics.hashedCharacters += value.length;
                for (const match of index.get(value) || []) {
                    if (buildLeft) emit(match, probeIndex(row)); else emit(probeIndex(row), match);
                }
            }
        }
    };
    if (!uniform) {
        if (plan.split.buckets === 1) leaf(null, null, 0);
        else for (let partition = 0; partition < plan.split.buckets; partition += 1) {
            const leftRows = [], rightRows = [];
            for (const [side, indices] of [[left, leftRows], [right, rightRows]]) {
                for (let row = 0; row < side.rows.length; row += 1) {
                    metrics.routingTests += 1;
                    if (bucket(key(side, row)) === partition) indices.push(row);
                }
            }
            leaf(leftRows, rightRows, leftRows.length + rightRows.length);
        }
    }
    pairs.sort((a, b) => a[0] - b[0] || a[1] - b[1]);
    alpha.verifyJoinResult(mission, pairs);
    metrics.logicalOperations = Object.entries(metrics).reduce((sum, [name, count]) =>
        !['peakAuxiliaryRows', 'logicalOperations'].includes(name) ? sum + count : sum, 0);
    return { plan, pairs, metrics, correct: true };
}

const baselinePlans = budget => {
    const rows = Math.max(1, Math.min(1500, budget));
    return [
        { id: 'baseline_nested', label: 'Exact nested join', plan: program({ threshold: 2250000 }) },
        ...['left', 'right', 'smaller'].map(side => ({ id: `baseline_full_${side}`,
            label: `Full ${side}-side hash join`, plan: program({ side, blockRows: 1500 }) })),
        ...['left', 'right', 'smaller'].map(side => ({ id: `baseline_block_${side}`,
            label: `Bounded ${side}-side block hash join`, plan: program({ side, blockRows: rows }) })),
    ];
};

async function record(mission, plan, objective, id, label) {
    const execution = executePlan(mission, plan);
    return { id, label, plan, planHash: await hash(plan), pairsHash: await hash(execution.pairs), metrics: execution.metrics,
        correct: true, feasible: execution.metrics.peakAuxiliaryRows <= objective.maxAuxiliaryRows,
        objectiveValue: execution.metrics.logicalOperations + objective.auxiliaryWeight * execution.metrics.peakAuxiliaryRows };
}

const ranking = (a, b) => a.objectiveValue - b.objectiveValue || a.metrics.peakAuxiliaryRows - b.metrics.peakAuxiliaryRows
    || (a.planHash < b.planHash ? -1 : a.planHash > b.planHash ? 1 : 0);

function example(seed = 41, sameKey = false) {
    const leftCount = 65 + seed % 2, rightCount = 65 + (seed >>> 1) % 2;
    const leftId = `PUBLIC-LEFT-${seed}`, rightId = sameKey ? leftId : `PUBLIC-RIGHT-${seed}`;
    const left = ['sku,revision,note'], right = ['sku,revision,note'];
    for (let row = 0; row < leftCount; row += 1) left.push(`${leftId},r${seed % 3},Public edition ${seed}`);
    for (let row = 0; row < rightCount; row += 1) right.push(`${rightId},r${seed % 3},Public edition ${seed}`);
    return alpha.createJoinMission({ leftCsv: left.join('\n'), rightCsv: right.join('\n'), leftKey: 'sku', rightKey: 'sku' });
}

function strategyExampleMission() { return example(); }

function confirmationMission(mission, seed) {
    if (mission.left.rows.length && mission.right.rows.length) {
        const firstLeft = mission.left.rows[0][mission.left.keyIndex], firstRight = mission.right.rows[0][mission.right.keyIndex];
        if (mission.left.rows.every(row => row[mission.left.keyIndex] === firstLeft)
            && mission.right.rows.every(row => row[mission.right.keyIndex] === firstRight)) {
            return example(seed, firstLeft === firstRight);
        }
    }
    return alpha.createSampleMission({ seed, leftRows: Math.max(1, Math.min(300, mission.left.rows.length)),
        rightRows: Math.max(1, Math.min(600, mission.right.rows.length)) });
}

async function discoverStrategy(mission, options = {}) {
    alpha.validateJoinMission(mission);
    const allowed = ['sourceHash', 'maxAuxiliaryRows', 'auxiliaryWeight', 'signal', 'onProgress', 'confirmationSeed'];
    if (!options || typeof options !== 'object' || Array.isArray(options)
        || Object.keys(options).some(key => !allowed.includes(key)) || !/^[a-f0-9]{64}$/.test(options.sourceHash || '')
        || options.confirmationSeed !== undefined && !integer(options.confirmationSeed, 0, 0xffffffff)) {
        fail('Research requires an exact source hash and supported bounded options.');
    }
    const objective = settings(options), sourceHash = options.sourceHash, missionHash = await hash(mission);
    const checkpoint = async (stage, completed, total) => {
        if (options.signal?.aborted) fail('Strategy construction stopped; no candidate was retained.');
        options.onProgress?.({ stage, completed, total });
        await new Promise(resolve => setTimeout(resolve, 0));
        if (options.signal?.aborted) fail('Strategy construction stopped; no candidate was retained.');
    };
    const baselines = [], candidates = [];
    const declaredBaselines = baselinePlans(objective.maxAuxiliaryRows);
    const plans = constructPlans({ maxAuxiliaryRows: objective.maxAuxiliaryRows });
    for (let index = 0; index < declaredBaselines.length; index += 1) {
        await checkpoint('baselines', index, declaredBaselines.length);
        const baseline = declaredBaselines[index];
        baselines.push(await record(mission, baseline.plan, objective, baseline.id, baseline.label));
    }
    const incumbent = [...baselines].filter(item => item.feasible).sort(ranking)[0];
    for (let index = 0; index < plans.length; index += 1) {
        await checkpoint('construction', index, plans.length);
        candidates.push(await record(mission, plans[index], objective, `constructed_${String(index + 1).padStart(2, '0')}`,
            'Composition of declared exact join operators'));
    }
    const nominee = [...candidates].filter(item => item.feasible).sort(ranking)[0] || incumbent;
    const frozenData = { sourceHash, developmentMissionHash: missionHash, plan: nominee.plan, planHash: nominee.planHash,
        incumbentPlanHash: incumbent.planHash, objective };
    const frozen = { ...frozenData, commitment: await hash(frozenData) };
    await checkpoint('frozen', plans.length, plans.length);
    // Sampling happens after the local commitment. This local generator is public, not a protected evaluator.
    let seed = options.confirmationSeed ?? crypto.getRandomValues(new Uint32Array(1))[0];
    let fresh = confirmationMission(mission, seed), freshHash = await hash(fresh);
    for (let retry = 0; freshHash === missionHash && retry < 4; retry += 1) {
        seed = (seed + 1) >>> 0;
        fresh = confirmationMission(mission, seed); freshHash = await hash(fresh);
    }
    if (freshHash === missionHash) fail('Confirmation generator did not produce a distinct fresh input.');
    const candidate = await record(fresh, nominee.plan, objective, nominee.id, nominee.label);
    const freshBaselines = [];
    for (let index = 0; index < declaredBaselines.length; index += 1) {
        await checkpoint('confirmation', index, declaredBaselines.length);
        const baseline = declaredBaselines[index];
        freshBaselines.push(await record(fresh, baseline.plan, objective, baseline.id, baseline.label));
    }
    const confirmedIncumbent = freshBaselines.find(baseline => baseline.id === incumbent.id);
    const strongestFreshBaseline = [...freshBaselines].filter(item => item.feasible).sort(ranking)[0];
    const developmentImproved = nominee.feasible && nominee.objectiveValue < incumbent.objectiveValue;
    const passed = candidate.feasible && candidate.objectiveValue < strongestFreshBaseline.objectiveValue;
    const promoted = developmentImproved && passed;
    const retained = promoted ? nominee : incumbent;
    await checkpoint('complete', plans.length, plans.length);
    const ledger = (records, task) => ({ planExecutions: records.length,
        executionLogicalOperations: records.reduce((sum, item) => sum + item.metrics.logicalOperations, 0),
        independentReferenceComparisons: records.length * task.left.rows.length * task.right.rows.length,
        verifiedOutputPairs: records.reduce((sum, item) => sum + item.metrics.outputPairs, 0) });
    return { schema: STUDY, sourceHash, missionHash, objective, incumbent, baselines, candidates, frozen,
        confirmation: { seed, mission: fresh, missionHash: freshHash, publicSynthetic: true, protected: false,
            candidate, incumbent: confirmedIncumbent, baselines: freshBaselines, strongestBaseline: strongestFreshBaseline,
            passed, developmentImproved },
        evaluationLedger: { development: ledger([...baselines, ...candidates], mission),
            confirmation: ledger([candidate, ...freshBaselines], fresh),
            note: 'Separate execution and exhaustive-oracle counts; excludes enumeration, hashing commitments, '
                + 'serialization, sorting, report and export overhead. No net-benefit claim.' },
        decision: { state: promoted ? 'local_improvement' : 'held', promoted, retainedPlan: retained.plan,
            retainedPlanHash: retained.planHash,
            reason: promoted ? 'Strictly lower registered objective than every feasible declared baseline on development '
                + 'and a fresh local synthetic case.'
                : 'No strict improvement over the strongest feasible declared baseline on both cases; incumbent retained.' },
        qualification: 'local_engineering_only', independentlyQualified: false, protectedHoldout: false,
        externalAuthority: false, modelUsed: false, algorithmNoveltyClaim: false,
        scope: [
            'Programs combine reviewed uniform-key checks, streamed partitions, conditional nested joins, and bounded hash joins.',
            'Search is bounded enumeration of 20 programs in this declared grammar; it does not invent arbitrary operators or code.',
            'The incumbent is the strongest feasible member of the seven declared textbook baselines on this development input.',
            'The objective is logical operations plus the explicit auxiliary-row weight, subject to the explicit row-reference cap.',
            'Every string comparison is charged its maximum UTF-16 input length; hash operations are charged the full key length. '
                + 'These are reproducible proxies; JavaScript engines can short-circuit or reuse string hashes.',
            'Auxiliary rows count indexed and temporary partition row references, excluding shared inputs and returned output. '
                + 'They are not memory bytes or measured process peak memory.',
            'Canonical output sorting, independent oracle execution, search, report generation, and export are excluded from '
                + 'the per-plan objective; execution and oracle search counts are reported separately in evaluationLedger.',
            'Confirmation is a new generated public synthetic input after a local freeze, not a secret or independently administered holdout.',
            'The duplicate-heavy example deliberately uses a different repeated key in each catalog. A known uniform-key '
                + 'shortcut confirms the empty join; grouping retains every missing occurrence in two proposed corrective actions.',
            'No timing, economic return, model improvement, novel algorithm, general intelligence, or external execution claim is made.',
        ] };
}

async function validateResearch(report, mission, options = {}) {
    if (!exact(options, ['sourceHash']) || !/^[a-f0-9]{64}$/.test(options.sourceHash || '')
        || !report || report.schema !== STUDY || report.sourceHash !== options.sourceHash
        || !report.objective || !report.confirmation) fail('Unsupported research record or source identity.');
    const serialized = canonical(report);
    if (new TextEncoder().encode(serialized).length > 8000000) fail('Research record exceeds 8 MB.');
    const recomputed = await discoverStrategy(mission, { sourceHash: options.sourceHash,
        maxAuxiliaryRows: report.objective.maxAuxiliaryRows, auxiliaryWeight: report.objective.auxiliaryWeight,
        confirmationSeed: report.confirmation.seed });
    if (canonical(recomputed) !== serialized) fail('Research record differs from complete deterministic recomputation.');
    return { valid: true, outputsAndObjectiveRecomputed: true, protectedHoldout: false,
        independentlyQualified: false, externalAuthority: false };
}

function resolutionCsv(actions, maximum) {
    const rows = [['action', 'exact_key', 'type', 'left_data_rows', 'right_data_rows', 'original_review_occurrences', 'next_step']];
    for (const action of actions) rows.push([action.id, action.key, action.type,
        action.leftRows.map(row => row + 1).join(';'), action.rightRows.map(row => row + 1).join(';'),
        action.occurrences.join(';'), action.nextStep]);
    let bytes = 0;
    return rows.map(row => {
        const line = row.map(value => {
            let cell = String(value);
            if (/^(?:\s*[=+\-@]|[\t\r\n])/.test(cell)) cell = `'${cell}`;
            return '"' + cell.replaceAll('"', '""') + '"';
        }).join(',') + '\r\n';
        bytes += new TextEncoder().encode(line).length;
        if (bytes > maximum) fail('Corrective-action CSV exceeds its output budget.');
        return line;
    }).join('');
}

function resolveDiscrepancies(mission, result) {
    alpha.validateJoinMission(mission);
    if (result) alpha.verifyExperiment(mission, result);
    const experiment = result;
    const pairs = experiment ? experiment.strategies[0].pairs : alpha.executeJoin(mission, 'nested_scan').pairs;
    alpha.verifyJoinResult(mission, pairs);
    const groups = new Map(), matchedLeft = new Set(), matchedRight = new Set();
    const shared = mission.left.headers.flatMap((name, leftColumn) => {
        const rightColumn = mission.right.headers.indexOf(name);
        return leftColumn !== mission.left.keyIndex && rightColumn >= 0 && rightColumn !== mission.right.keyIndex
            ? [{ name, leftColumn, rightColumn }] : [];
    });
    const group = key => {
        if (!groups.has(key)) groups.set(key, { key, leftRows: new Set(), rightRows: new Set(),
            occurrences: [], conflicts: [], missingLeft: false, missingRight: false });
        return groups.get(key);
    };
    for (const [a, b] of pairs) {
        matchedLeft.add(a); matchedRight.add(b);
        const fields = shared.flatMap((field, index) =>
            mission.left.rows[a][field.leftColumn] !== mission.right.rows[b][field.rightColumn] ? [index] : []);
        if (fields.length) {
            const action = group(mission.left.rows[a][mission.left.keyIndex]);
            action.leftRows.add(a); action.rightRows.add(b); action.occurrences.push(`conflict:${a}:${b}`);
            action.conflicts.push({ leftIndex: a, rightIndex: b, fieldIndices: fields });
        }
    }
    for (const [side, matched, otherMissing, prefix] of [[mission.left, matchedLeft, 'missingRight', 'left'],
        [mission.right, matchedRight, 'missingLeft', 'right']]) {
        for (let row = 0; row < side.rows.length; row += 1) if (!matched.has(row)) {
            const action = group(side.rows[row][side.keyIndex]);
            action[otherMissing] = true;
            action[prefix === 'left' ? 'leftRows' : 'rightRows'].add(row);
            action.occurrences.push(`${prefix}:${row}`);
        }
    }
    const actions = [...groups.values()].sort((a, b) => a.key < b.key ? -1 : a.key > b.key ? 1 : 0).map((action, index) => ({
        id: `action-${String(index + 1).padStart(4, '0')}`, key: action.key,
        type: action.missingLeft ? 'missing_from_left' : action.missingRight ? 'missing_from_right' : 'review_shared_values',
        leftRows: [...action.leftRows].sort((a, b) => a - b), rightRows: [...action.rightRows].sort((a, b) => a - b),
        occurrences: action.occurrences, conflicts: action.conflicts,
        nextStep: action.missingLeft || action.missingRight
            ? 'Check whether this key belongs in the other catalog; retain every referenced occurrence before deciding.'
            : 'Review all referenced differences for this exact key and choose the authoritative values; do not auto-overwrite.',
    }));
    const expectedOccurrences = [];
    for (let row = 0; row < mission.left.rows.length; row += 1) {
        if (!matchedLeft.has(row)) expectedOccurrences.push(`left:${row}`);
    }
    for (let row = 0; row < mission.right.rows.length; row += 1) {
        if (!matchedRight.has(row)) expectedOccurrences.push(`right:${row}`);
    }
    for (const [leftIndex, rightIndex] of pairs) {
        if (shared.some(field => mission.left.rows[leftIndex][field.leftColumn]
            !== mission.right.rows[rightIndex][field.rightColumn])) expectedOccurrences.push(`conflict:${leftIndex}:${rightIndex}`);
    }
    const occurrences = actions.flatMap(action => action.occurrences), pairwiseReviewItems = expectedOccurrences.length;
    if (new Set(occurrences).size !== occurrences.length) fail('Corrective actions duplicated an original review occurrence.');
    if (canonical([...occurrences].sort()) !== canonical(expectedOccurrences.sort())) {
        fail('Corrective actions did not preserve every original review occurrence.');
    }
    const reducesItems = actions.length < pairwiseReviewItems;
    const report = { schema: RESOLUTION, actions, sharedFields: shared,
        burden: { pairwiseReviewItems, groupedActions: actions.length, groupingReduction: pairwiseReviewItems - actions.length,
            timeSavedClaim: false, sameTaskSuperiority: false },
        coverage: { originalOccurrences: pairwiseReviewItems, coveredOccurrences: occurrences.length,
            complete: true, missing: [], duplicates: [] },
        diagnosis: { originalGoal: 'Materialize matching row pairs and inspect each unmatched or conflicting occurrence.',
            proposedGoal: 'Decide which product keys need correction, retaining every source occurrence for review.',
            duplicateExceptionKeys: actions.filter(action => action.occurrences.length > 1).length,
            uniqueExceptionKeys: actions.length, groupingReducesDecisionItems: reducesItems },
        decision: { state: reducesItems ? 'offer_key_queue' : 'retain_original_review',
            recommendedContract: reducesItems ? 'per_key_corrective_actions' : 'original_occurrence_review',
            reason: reducesItems ? 'Several original exceptions concern the same exact key. A key-based queue reduces '
                + 'decision records under a changed output contract while preserving complete underlying evidence.'
                : 'No repeated exception key reduces the number of decision records; retain the original review contract.' },
        contract: { changed: true,
            original: 'One review item per unmatched source row or conflicting matched row pair.',
            reframed: 'One proposed corrective action per exact key, retaining every underlying original occurrence reference.',
            limitation: 'Grouping changes the unit of work. Fewer action records do not establish equal reviewer effort, '
                + 'correct resolution, time savings, or superiority on the original pairwise-output task.' },
        actionsCsv: resolutionCsv(actions, mission.limits.maxOutputBytes), externalAuthority: false,
        automaticallyResolved: false, qualification: 'local_engineering_only' };
    if (new TextEncoder().encode(canonical(report)).length > 8000000) fail('Corrective-action report exceeds 8 MB.');
    return report;
}

function validateResolution(report, mission, result) {
    if (canonical(report) !== canonical(resolveDiscrepancies(mission, result))) {
        fail('Corrective-action report omits, duplicates, or changes source evidence.');
    }
    return { valid: true, completeCoverageRecomputed: true, automaticallyResolved: false, externalAuthority: false };
}

return {validatePlan,constructPlans,executePlan,strategyExampleMission,discoverStrategy,validateResearch,resolveDiscrepancies,validateResolution};
})();
__modules["vendor/alpha/examples/ti-guide/guide.mjs"]=(()=>{
// SPDX-License-Identifier: Apache-2.0
const alpha=__modules["vendor/alpha/examples/successor-alpha/engine.mjs"];
const research=__modules["vendor/alpha/examples/successor-alpha/research.mjs"];

const SAMPLE = Object.freeze({
    leftCsv: 'item,name,price\nMUG,Stoneware mug,12\nMUG,Stoneware mug,14\nTEA,Green tea,8\nTEA,Green tea,9\nBOWL,Blue bowl,18\nLAMP,Desk lamp,35\n',
    rightCsv: 'item,name,price\nMUG,Stoneware mug,13\nTEA,Green tea,10\nBOWL,Blue bowl,18\nVASE,Glass vase,22\n',
    leftKey: 'item', rightKey: 'item',
});
const LIMITATIONS = Object.freeze({
    localOnly: true, authority: 'none', automaticallyResolved: false,
    timeSavedMeasured: false, accuracyImprovementMeasured: false,
    supportedTask: 'Exact string identifiers; compare shared non-identifier column names. No fuzzy matching or automatic correction.',
    sourceRows: 'Data rows are numbered from 1 after the header. Quoted multiline cells are one data row.',
    duplicates: 'Duplicate identifiers retain every matching pair; they are never silently deduplicated.',
    csvSafety: 'CSV cells starting with formula characters receive a leading apostrophe. Workspace retains exact originals.',
});
const fail = message => { throw Error(message); };
const exact = (value, keys) => value && typeof value === 'object' && !Array.isArray(value)
    && Object.keys(value).length === keys.length && keys.every(key => Object.hasOwn(value, key));
function canonical(value) {
    if (Array.isArray(value)) return '[' + value.map(canonical).join(',') + ']';
    if (value && typeof value === 'object') return '{' + Object.keys(value).sort()
        .map(key => JSON.stringify(key) + ':' + canonical(value[key])).join(',') + '}';
    return JSON.stringify(value);
}
function preview(csv) { return alpha.parseCsv(csv); }
function safeCsv(rows) {
    let bytes = 0;
    return rows.map(row => {
        const line = row.map(value => {
            let cell = String(value ?? '');
            if (/^(?:\s*[=+\-@]|[\t\r\n])/.test(cell)) cell = "'" + cell;
            return '"' + cell.replaceAll('"', '""') + '"';
        }).join(',') + '\r\n';
        bytes += new TextEncoder().encode(line).length;
        if (bytes > 2000000) fail('The download exceeds 2 MB. Use smaller lists.');
        return line;
    }).join('');
}
async function digest(text) {
    const bytes = new TextEncoder().encode(text);
    const value = await crypto.subtle.digest('SHA-256', bytes);
    return { sha256: [...new Uint8Array(value)].map(x => x.toString(16).padStart(2, '0')).join(''), bytes: bytes.length };
}
async function compute(input, progress = () => {}) {
    if (!exact(input, ['leftCsv', 'rightCsv', 'leftKey', 'rightKey'])) fail('Unsupported list settings.');
    input = { ...input };
    progress('parse');
    const mission = alpha.createJoinMission(input);
    const leftIdentity = await digest(input.leftCsv), rightIdentity = await digest(input.rightCsv);
    progress('compare');
    const resolution = research.resolveDiscrepancies(mission);
    progress('preserve');
    const differences = [];
    let differenceBytes = 0;
    const keep = difference => {
        differenceBytes += new TextEncoder().encode(JSON.stringify(difference)).length;
        if (differenceBytes > 1500000) fail('Full difference evidence exceeds 1.5 MB. Use smaller lists; nothing was truncated.');
        differences.push(difference);
    };
    for (const action of resolution.actions) {
        for (const occurrence of action.occurrences) {
            const [kind, a, b] = occurrence.split(':'), row = Number(a);
            if (kind === 'conflict') {
                const conflict = action.conflicts.find(x => x.leftIndex === row && x.rightIndex === Number(b));
                for (const f of conflict.fieldIndices) {
                    const field = resolution.sharedFields[f];
                    keep({ id: occurrence + ':' + f, occurrence, action: action.id, key: action.key,
                        kind, leftRow: row + 1, rightRow: Number(b) + 1, field: field.name,
                        leftValue: mission.left.rows[row][field.leftColumn],
                        rightValue: mission.right.rows[Number(b)][field.rightColumn] });
                }
            } else {
                const side = kind === 'left' ? mission.left : mission.right;
                keep({ id: occurrence, occurrence, action: action.id, key: action.key,
                    kind: kind === 'left' ? 'missing_from_right' : 'missing_from_left',
                    leftRow: kind === 'left' ? row + 1 : '', rightRow: kind === 'right' ? row + 1 : '', field: '',
                    leftValue: kind === 'left' ? JSON.stringify(side.rows[row]) : '',
                    rightValue: kind === 'right' ? JSON.stringify(side.rows[row]) : '' });
            }
        }
    }
    const refs = new Set(differences.map(x => x.occurrence));
    if (refs.size !== resolution.coverage.originalOccurrences
        || resolution.actions.some(x => x.occurrences.some(ref => !refs.has(ref)))) fail('Evidence coverage failed.');
    const duplicateInfo = side => {
        const counts = new Map();
        for (const row of side.rows) { const k = row[side.keyIndex]; counts.set(k, (counts.get(k) || 0) + 1); }
        return { keys: [...counts.values()].filter(x => x > 1).length,
            extraRows: [...counts.values()].reduce((n, x) => n + x - 1, 0) };
    };
    const missing = differences.filter(x => x.kind !== 'conflict');
    const result = { schema: 'ti-catalogue-result/v1', leftIdentity, rightIdentity, resolution, differences,
        metrics: { leftRows: mission.left.rows.length, rightRows: mission.right.rows.length,
            matchedPairs: mission.workload.outputPairs, unmatchedRows: missing.length,
            unmatchedKeys: new Set(missing.map(x => x.key)).size,
            conflictingPairs: resolution.actions.reduce((n, x) => n + x.conflicts.length, 0),
            fieldDifferences: differences.filter(x => x.kind === 'conflict').length,
            actionGroups: resolution.actions.length, evidenceReferences: refs.size,
            leftDuplicates: duplicateInfo(mission.left), rightDuplicates: duplicateInfo(mission.right),
            comparedColumns: resolution.sharedFields.map(x => x.name),
            unsharedLeft: mission.left.headers.filter((x, i) => i !== mission.left.keyIndex && !resolution.sharedFields.some(f => f.name === x)),
            unsharedRight: mission.right.headers.filter((x, i) => i !== mission.right.keyIndex && !resolution.sharedFields.some(f => f.name === x)) },
        limitations: LIMITATIONS };
    if (new TextEncoder().encode(JSON.stringify(result)).length > 6000000) fail('The result exceeds 6 MB. Use smaller lists.');
    fullDifferencesCsv(result);
    progress('complete');
    return result;
}
function fullDifferencesCsv(result) {
    const fields = ['id', 'occurrence', 'action', 'key', 'kind', 'leftRow', 'rightRow', 'field', 'leftValue', 'rightValue'];
    return safeCsv([fields, ...result.differences.map(x => fields.map(f => x[f]))]);
}
function actionPlanCsv(result) { return result.resolution.actionsCsv; }
function makeWorkspace(input, result, { approach, sourceHash, runId, createdAt, language }) {
    if (!['grouped', 'original'].includes(approach) || !['en', 'fr'].includes(language)) fail('Unsupported workspace choice.');
    return { schema: 'ti-catalogue-workspace/v1', sourceHash, runId, createdAt, language, approach, input, result,
        limitations: LIMITATIONS, authority: 'none' };
}
async function restoreWorkspace(raw, sourceHash, progress) {
    if (typeof raw !== 'string' || raw.length > 8000000 || new TextEncoder().encode(raw).length > 8000000) {
        fail('Workspaces must be no larger than 8 MB.');
    }
    const saved = JSON.parse(raw);
    if (!exact(saved, ['schema', 'sourceHash', 'runId', 'createdAt', 'language', 'approach', 'input', 'result', 'limitations', 'authority'])
        || saved.schema !== 'ti-catalogue-workspace/v1' || saved.sourceHash !== sourceHash
        || saved.authority !== 'none' || !['grouped', 'original'].includes(saved.approach)
        || !['en', 'fr'].includes(saved.language) || typeof saved.runId !== 'string' || saved.runId.length > 80
        || typeof saved.createdAt !== 'string' || !Number.isFinite(Date.parse(saved.createdAt))) fail('Unsupported workspace or method version. Reopen its original saved HTML.');
    const result = await compute(saved.input, progress);
    if (canonical(result) !== canonical(saved.result) || canonical(saved.limitations) !== canonical(LIMITATIONS)) {
        fail('The saved results differ from recomputation. No result or authority was restored.');
    }
    return saved;
}

return {SAMPLE,LIMITATIONS,canonical,preview,safeCsv,compute,fullDifferencesCsv,actionPlanCsv,makeWorkspace,restoreWorkspace};
})();
__modules["implementation/adapter.mjs"]=(()=>{
// SPDX-License-Identifier: Apache-2.0
const {createWorkbench}=__modules["vendor/alpha/examples/successor-workbench/engine.mjs"];
const guide=__modules["vendor/alpha/examples/ti-guide/guide.mjs"];

const exact = (v, keys) => v && typeof v === 'object' && !Array.isArray(v)
  && Object.keys(v).sort().join('|') === [...keys].sort().join('|');
const json = (name, data) => ({name, type:'application/json', content:JSON.stringify(data,null,2)+'\n'});
const rawCsv = rows => ['path,sha256', ...rows.map(row => [row.path,row.sha256]
  .map(value => '"'+value.replaceAll('"','""')+'"').join(','))].join('\r\n')+'\r\n';
const clock = () => globalThis.performance.now();

function createIntakeAdapter(normalize, assetHash, language = 'en') {
  if (typeof normalize !== 'function' || !/^[0-9a-f]{64}$/.test(assetHash)) throw Error('ASSET_IDENTITY');
  return {
    manifest:{id:'release-inventory-intake',version:1,
      en:'Check release inventories',fr:'Vérifier les inventaires de livraison',
      scope:'Compare exact declared SHA-256 inventories from bounded public or synthetic documents. No source execution or security certification.',
      artifact:'inventory-report.md'},
    validate(input) {
      if (!exact(input,['left','right'])) throw Error('INPUT_FIELDS');
      for (const side of [input.left,input.right]) {
        if (!exact(side,['text','format']) || typeof side.text !== 'string'
          || new TextEncoder().encode(side.text).length > 1000000
          || !['auto','json','csv','sha256sum'].includes(side.format)) throw Error('INPUT_BOUND');
      }
    },
    async execute(input,checkpoint) {
      await checkpoint('preparing inventories');
      const prepStart = clock();
      const left = await normalize(input.left.text,input.left.format);
      const right = await normalize(input.right.text,input.right.format);
      const preparationMicros = Math.round((clock()-prepStart)*1000);
      const normalized = {left:left.rows,right:right.rows};
      const comparisonInput = {leftCsv:rawCsv(left.rows),rightCsv:rawCsv(right.rows),leftKey:'path',rightKey:'path'};
      await checkpoint('comparing exact identities');
      const executionStart = clock();
      const comparison = await guide.compute(comparisonInput);
      const comparisonMicros = Math.round((clock()-executionStart)*1000);
      const fr = language === 'fr';
      const lines = [fr?'# Inventaire de livraison — résultat':'# Release inventory — result',
        '', `${fr?'Fichiers déclarés':'Declared files'}: ${left.rows.length} / ${right.rows.length}.`,
        `${fr?'Différences de champs':'Field differences'}: ${comparison.metrics.fieldDifferences}.`,
        `${fr?'Entrées absentes':'Missing entries'}: ${comparison.metrics.unmatchedRows}.`,
        `${fr?'Actions proposées':'Proposed actions'}: ${comparison.metrics.actionGroups}.`,
        '', fr?'Les fichiers téléchargés conservent toutes les différences. Aucune correction automatique.':'The downloads preserve every difference. No automatic correction.',
        fr?'Ce contrôle compare des identités déclarées; il ne certifie ni le comportement ni la sécurité des sources.':'This check compares declared identities; it certifies neither source behavior nor source security.',
        '', `${fr?'Capacité utilisée':'Retained asset'}: ${assetHash}`, '',
        fr?'Exécution locale. Admission économique réelle : EN ATTENTE. Encaissements réels : inconnus.':'Local execution. Observed economic admission: HOLD. Actual collections: unknown.'];
      await checkpoint('packaging complete evidence');
      return {decision:'DELIVERABLE_READY_FOR_INDEPENDENT_CHECK',
        summary:{leftRows:left.rows.length,rightRows:right.rows.length,fieldDifferences:comparison.metrics.fieldDifferences,
          unmatchedRows:comparison.metrics.unmatchedRows,actionGroups:comparison.metrics.actionGroups},
        evidence:{assetHash,formats:{left:left.format,right:right.format},normalized,comparison,
          measured:{preparationMicros,comparisonMicros},economicAdmission:'HOLD_FULL_COST_AND_DEMAND_UNKNOWN'},
        artifacts:[{name:'inventory-report.md',type:'text/markdown',content:lines.join('\n')+'\n'},
          json('normalized-inventories.json',normalized),json('complete-comparison.json',comparison),
          {name:'differences.csv',type:'text/csv',content:guide.fullDifferencesCsv(comparison)},
          {name:'actions.csv',type:'text/csv',content:guide.actionPlanCsv(comparison)},
          json('asset-identity.json',{sha256:assetHash,scope:'reviewed local research candidate',authority:[],actualCollections:null})],
        limits:['Declared identity comparison only. No file reads or execution.',
          'The unchanged Workbench pack remains local, unapproved for production and unfunded.',
          'Construction was assisted by a current-session model outside the installed runtime; no autonomous invention claim.',
          'No observed full-cost payback or revenue is established.']};
    }
  };
}

async function deliver(normalize,assetHash,input,{sourceHash,language='en',name='Release inventory'}={}) {
  const adapter=createIntakeAdapter(normalize,assetHash,language),workbench=createWorkbench([adapter]);
  const spec={schema:'successor-workbench/v1',family:adapter.manifest.id,name,language,owner:'local-research',
    rights:{dataClass:'public',source:'Pinned public source manifests or explicitly labeled synthetic variations',license:'Apache-2.0'},
    reviewMinutes:1,inputs:input};
  const pack=await workbench.run(spec,{sourceHash});
  await workbench.inspectPack(pack);
  return pack;
}



return {createIntakeAdapter,deliver,rawCsv};
})();
__modules["demo/runtime_entry.mjs"]=(()=>{
// SPDX-License-Identifier: Apache-2.0
const { normalize: alphaNormalize }=__modules["candidates/alpha/normalize.mjs"];
const { normalize: conventionalNormalize }=__modules["candidates/conventional/normalize.mjs"];
const { deliver }=__modules["implementation/adapter.mjs"];

const normalizers = Object.freeze({ alpha: alphaNormalize, conventional: conventionalNormalize });

async function run(input, language = 'en', method = 'conventional') {
  if (!Object.prototype.hasOwnProperty.call(normalizers, method)) throw Error('UNKNOWN_RETAINED_METHOD');
  if (!['en', 'fr'].includes(language)) throw Error('LANGUAGE');
  const assetHash = globalThis.FUNDED_ADVANTAGE_ASSETS?.[method];
  const sourceHash = globalThis.FUNDED_ADVANTAGE_SOURCE;
  if (!/^[0-9a-f]{64}$/.test(assetHash ?? '') || !/^[0-9a-f]{64}$/.test(sourceHash ?? '')) throw Error('BUNDLED_SOURCE_IDENTITY');
  return deliver(normalizers[method], assetHash, input, {
    sourceHash, language,
    name: language === 'fr' ? 'Inventaire de livraison' : 'Release inventory',
  });
}

globalThis.FUNDED_ADVANTAGE = Object.freeze({ run });

return {run};
})();
