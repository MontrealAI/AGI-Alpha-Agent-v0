# Bilingual local demonstration

This source is the self-contained English/French presentation of the actual
release-inventory adapter. It adds a local user interface to the existing Alpha
Workbench and TI catalogue engine. It neither replaces their contracts nor
promotes the retained asset into an approved operator or production profile.

The principal statement is explicit: **useful inventory checks; economic payback
remains unproven**. Recorded technical outcomes come from embedded data. No
favorable acceptance count, timing, price, revenue or payback is invented by the
interface. Unknown values display as unknown. Saved attention in a financing
scenario is labeled an unmeasured assumption, and modeled collections remain
distinct from earned revenue. Selecting the conventional implementation by
default does not assert complete monetary superiority.

## Offline build and actual runtime replay

From the study root, build into a new directory without modifying any supplied
source or original evidence:

```sh
python demo/build.py --output /absolute/path/to/new-demo-build \
  --paper-link ../publication/paper.pdf \
  --source-link ../README.md \
  --companion-link /owner-supplied/path/to/companion.zip

node demo/runtime-smoke.cjs \
  --bundle /absolute/path/to/new-demo-build/runtime_bundle.js \
  --data /absolute/path/to/new-demo-build/DEMO_DATA.json \
  --output /absolute/path/to/new-runtime-replay
```

`build.py` uses only Python's standard library. Omit `--output` only when
intentionally rebuilding generated files in this `demo/` directory. A nondefault
output directory must be empty or new. The runtime replay requires a new output
directory and never overwrites a prior run. No dependency installation or network
request occurs. Link arguments are owner-configurable; an omitted companion
link remains visibly unavailable rather than pointing at a nonexistent archive.

The build emits the standalone HTML, `runtime_bundle.js`,
`RUNTIME_BUNDLE_MANIFEST.json`, `DEMO_DATA.json`, and `BUILD_MANIFEST.json`. It
checks each frozen candidate hash against the confirmed result, checks that the
economic summary binds those result bytes, and records all 14 runtime module
identities. Static named imports, namespace imports and named exports are
rewritten to module-scoped IIFEs; unsupported module syntax fails closed. This
adapts the existing AWE / Next Advantage bundler and uses no runtime `eval`,
dynamic import or competing execution engine.

The runtime entry imports the two frozen candidates and the actual
`implementation/adapter.mjs` delivery function. The build embeds the recorded
J05-V1 public example, all primary result metrics, construction observations and
three complete recorded cash traces: no assumed attention benefit; the Alpha
52-job, $20 investment, $5 price, two-job collection-delay counterfactual with
60 seconds assumed saved attention; and that case with a declared $10 maintenance
shock. The display does not recompute the economic model or select an unrelated
fictional improvement. Each complete selected canonical ledger is included.

The saved `runtime-smoke-v1/runtime-smoke.json` reports **82 passing assertions**
for the actual bundled Workbench: Alpha and conventional constructions, each in
English and French, produce complete packs and six artifacts per execution.
Both sides contain eight declared paths; the retained example contains two hash
differences and two proposed action groups. The replay checks the independent
fixture's normalized rows and differences, exact asset identities, all output
bytes, report languages and unchanged authority/admission/settlement status.
This is four demonstration evaluations of **one already evaluated job**, with
zero new confirmatory jobs. Browser, approved operator and production execution
remain `NOT_RUN`.

The first smoke attempt stopped before runtime invocation because Node 24 exposes
a getter-only global `crypto`. `runtime-smoke-first-failure.json` preserves that
failure. The test harness now uses existing WebCrypto and defines a fallback only
if absent. No frozen candidate, protocol or primary confirmation changed.

## Template contract

The root-owned build process substitutes exactly four markers in
`index.template.html`:

| Marker | Replacement |
|---|---|
| `/*__STYLE__*/` | Contents of `style.css` |
| `/*__DATA__*/` | A script assigning the study data to `DATA` or `globalThis.DATA` |
| `/*__RUNTIME__*/` | The reviewed static runtime bundle |
| `/*__APP__*/` | Contents of `app.js` |

The resulting HTML needs no external fonts, libraries, images or network calls.
Escape `<` as `\u003c` when embedding serialized JSON into the script so source
text cannot close its containing script tag. Do not evaluate input as code.
Publication/download links are supplied explicitly by the existing owner; they
are never fetched automatically. This source does not edit the documentation
website or initiate publication.

The runtime must expose:

```js
globalThis.FUNDED_ADVANTAGE = {
  async run({left: {text, format}, right: {text, format}}, language, method) {
    // Return the actual existing Workbench pack.
  }
};
globalThis.FUNDED_ADVANTAGE_SOURCE = "runtime source SHA-256";
```

`language` is `en` or `fr`; `method` is `alpha` or `conventional`. `format` is
`auto`, `json`, `csv` or `sha256sum`. The source identity may alternatively be an
object with a `sourceHash` or `sha256` property.

The interface reads the exact adapter result fields in
`implementation/adapter.mjs`: `pack.result.summary`,
`pack.result.evidence.assetHash`, `.comparison.differences`, `.measured`,
`pack.result.artifacts`, and `pack.evaluation`. It downloads the **actual returned
artifact content** and the complete returned pack. It never fabricates a report
from headline metrics. The saved J05-V1 pack shape was inspected while building
the interface; that inspection is not a new runtime acceptance test.

## Embedded data

Numbers are finite JSON numbers. Missing or null monetary/numeric values remain
unknown; no conversion from token quantities or other currencies is inferred.
Labels and explanations can be strings or `{en, fr}` objects.

```js
DATA = {
  sample: {
    left: {text: "...", format: "json", label: {en: "...", fr: "..."}},
    right: {text: "...", format: "sha256sum", label: {en: "...", fr: "..."}}
  },
  defaultMethod: "conventional",
  assetHashes: {alpha: "...", conventional: "..."},
  summary: {
    uniqueJobs: 16,
    evaluations: null,
    acceptedEvaluations: null,
    refusalPassed: null,
    refusalProbes: null,
    conclusion: {en: "Actual study conclusion", fr: "Conclusion réelle"},
    defaultMethodReason: {en: "Evidence-based reason", fr: "Motif fondé sur les preuves"},
    construction: {
      alpha: {elapsedSeconds: null},
      conventional: {elapsedSeconds: null}
    },
    execution: {ci: {en: "Actual CI status", fr: "État réel de la CI"}}
  },
  economics: {
    scenarios: [{
      label: {en: "Recorded conditional case", fr: "Cas conditionnel enregistré"},
      method: "conventional",
      assetHash: "exact tested capability SHA-256",
      status: "HOLD",
      horizonJobs: null,
      avoidedAttentionSecondsPerJob: null,
      investmentUsd: null,
      availableSurplusUsd: null,
      paybackJob: null,
      cumulativeIncrementalValueUsd: null,
      explanation: {en: "Assumptions and interpretation", fr: "Hypothèses et interprétation"}
    }]
  },
  downloadLinks: {paper: "...", source: "...", companion: "..."}
};
```

The example above specifies shape, not numerical study outcomes. The declared
16-job design is separate from the actual method evaluations. The interface also
accepts `economics.examples` instead of `.scenarios`. Each complete record remains
inspectable, including any additional cash ledger fields. `paybackJob: null`
means no repayment within that recorded modeled horizon; omit the field when it
is unknown or uncomputed. `MODELED_ADMISSION` is labeled conditional and never
changes the observed economic HOLD. The complete embedded summary and economics
are downloadable without omissions from the evidence button.

## Interaction and scope

One main action runs the public example. Advanced controls accept replacement
inventories, format choices and either frozen construction. The input remains
local to the page, with no persistence. Changing input or implementation clears
the prior result and disables stale downloads. Switching language preserves
inputs and results and identifies the language of existing report bytes;
rerunning generates a report in the selected language. Controls disable while a
run is pending. A refused run clears previous artifacts and shows its actual
error message as text.

The first eight differences form a clearly labeled preview. Downloads retain
every difference, proposed action, normalized input and pack artifact. Source
paths and other user-provided content are inserted with `textContent`, never HTML
evaluation. All dynamic artifact downloads retain their exact supplied bytes.

### Complete delivery bounds

The candidate normalizers permit up to 1,000,000 UTF-8 input bytes, 128 rows and
64,000 UTF-8 bytes per scalar. Those are **intake limits**, not a guarantee that
every such input can produce a complete Workbench pack. The unchanged TI guide
has a 200,000-character normalized CSV limit and 4,096-UTF-16-unit cell bound;
the unchanged Workbench has its own 200,000-character artifact and 2 MB canonical
serialization bounds. Oversized downstream inputs or artifacts refuse without
truncation. These limits and legacy Jobs rehearsal templates remain unchanged.
Legacy template grouping is not domain-specific or operator qualification.

This page compares declared identities; it does not read named files or certify
source behavior or security. `$AGIALPHA` routes remain separate from the Manager
USDC route. No settlement, financial transaction, installed-profile change or
automatic capability promotion is performed.

## UI verification

```sh
node studies/agi-alpha-funded-advantage-v1/demo/ui-test.cjs
```

`ui-test.cjs` exercises a deliberately minimal DOM shim with a **mock runtime**.
It checks language parity, all handlers, exact download bytes, data-driven
defaults, refusal behavior, stale-result clearing, pending-run exclusion,
scenario labeling and missing-cost propagation. It cannot establish visual
layout, keyboard navigation in a real browser, native file downloading, actual
runtime acceptance or browser compatibility. Its machine-readable output labels
both browser execution and actual runtime execution `NOT_RUN`.

No browser was launched; the outstanding browser refusal was not retried through
any route. CSS includes small-screen layouts, native keyboard controls, visible
focus indicators, reduced-motion treatment and a print view. Their real-browser
visual and accessibility acceptance remains unqualified.
