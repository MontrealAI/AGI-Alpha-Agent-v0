// SPDX-License-Identifier: Apache-2.0
// Executes the actual statically bundled runtime in Node. No browser or network.
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const { performance } = require('node:perf_hooks');
const root = path.resolve(__dirname, '..');
const options = {};
for (let i = 2; i < process.argv.length; i += 2) {
  const key = process.argv[i];
  if (!['--bundle', '--data', '--cases', '--output'].includes(key) || !process.argv[i + 1]) throw Error('USAGE: node demo/runtime-smoke.cjs --output NEW_DIRECTORY [--bundle FILE] [--data FILE] [--cases FILE]');
  options[key.slice(2)] = path.resolve(process.argv[i + 1]);
}
if (!options.output) throw Error('OUTPUT_REQUIRED: use a new output directory');
if (fs.existsSync(options.output)) throw Error('OUTPUT_EXISTS: original artifacts are never overwritten');
const bundlePath = options.bundle ?? path.join(__dirname, 'runtime_bundle.js');
const dataPath = options.data ?? path.join(path.dirname(bundlePath), 'DEMO_DATA.json');
const casesPath = options.cases ?? path.join(root, 'evidence/confirmation/cases.json');
const manifestPath = path.join(path.dirname(bundlePath), 'RUNTIME_BUNDLE_MANIFEST.json');
const read = (filename) => JSON.parse(fs.readFileSync(filename, 'utf8'));
const sha = (value) => crypto.createHash('sha256').update(value).digest('hex');
const identity = (filename) => ({ path: path.relative(root, filename), bytes: fs.statSync(filename).size, sha256: sha(fs.readFileSync(filename)) });
const manifest = read(manifestPath);
const data = read(dataPath);
const sample = read(casesPath).find((item) => item.id === 'J05-V1');
if (!sample || data.sample.caseId !== sample.id) throw Error('SAMPLE_IDENTITY');
let assertions = 0;
const same = (actual, expected, message) => { assertions += 1; assert.deepEqual(actual, expected, message); };
same(sha(fs.readFileSync(bundlePath)), manifest.bundleSha256, 'bundle bytes bind manifest');
for (const file of manifest.files) same(sha(fs.readFileSync(path.join(root, file.path))), file.sha256, file.path);
same(sha(fs.readFileSync(path.join(root, manifest.bundler.path))), manifest.bundler.sha256, 'bundler source identity');
if (!globalThis.crypto?.subtle) Object.defineProperty(globalThis, 'crypto', { value: crypto.webcrypto, configurable: true });
if (!globalThis.performance) Object.defineProperty(globalThis, 'performance', { value: performance, configurable: true });
globalThis.fetch = () => { throw Error('NETWORK_FORBIDDEN_IN_LOCAL_SMOKE'); };
require(bundlePath);
same(globalThis.FUNDED_ADVANTAGE_SOURCE, manifest.sourceHash, 'actual bundled source identity');
same(globalThis.FUNDED_ADVANTAGE_ASSETS, data.assetHashes, 'asset identities match demo data');
fs.mkdirSync(options.output, { recursive: true });
const began = new Date().toISOString();
const records = [];
const artifactNames = ['actions.csv', 'asset-identity.json', 'complete-comparison.json', 'differences.csv', 'inventory-report.md', 'normalized-inventories.json'];

(async () => {
  try {
    for (const method of ['alpha', 'conventional']) {
      for (const language of ['en', 'fr']) {
        const input = { left: { text: data.sample.left.text, format: data.sample.left.format }, right: { text: data.sample.right.text, format: data.sample.right.format } };
        same(input, { left: sample.left, right: sample.right }, 'embedded sample bytes');
        const before = performance.now();
        const pack = await globalThis.FUNDED_ADVANTAGE.run(input, language, method);
        const elapsedMillis = performance.now() - before;
        same(pack.evaluation, { scope: 'PUBLIC_LOCAL_EXECUTION', independentProof: false, admission: 'HOLD', authority: [], settlement: 'NOT_CONNECTED' }, 'authority and execution scope');
        same(pack.result.evidence.normalized.left, sample.expected_left, 'exact left normalization');
        same(pack.result.evidence.normalized.right, sample.expected_right, 'exact right normalization');
        const differences = pack.result.evidence.comparison.differences.map((item) => ({ path: item.key, kind: item.kind, left: item.leftValue, right: item.rightValue }));
        same(differences, sample.expected_differences, 'independent fixture differences');
        same(pack.result.summary, { leftRows: sample.expected_left.length, rightRows: sample.expected_right.length,
          fieldDifferences: sample.expected_differences.filter((item) => item.kind === 'conflict').length,
          unmatchedRows: sample.expected_differences.filter((item) => item.kind !== 'conflict').length,
          actionGroups: new Set(sample.expected_differences.map((item) => item.path)).size }, 'complete summary');
        same(pack.result.evidence.assetHash, manifest.assetHashes[method], 'tested capability identity');
        same(pack.result.evidence.economicAdmission, 'HOLD_FULL_COST_AND_DEMAND_UNKNOWN', 'economic admission remains HOLD');
        same(pack.result.artifacts.map((artifact) => artifact.name).sort(), artifactNames, 'all deliverable artifacts');
        const report = pack.result.artifacts.find((artifact) => artifact.name === 'inventory-report.md');
        same(report.content.startsWith(language === 'fr' ? '# Inventaire de livraison' : '# Release inventory'), true, 'actual report language');
        const directory = path.join(options.output, `${method}-${language}`);
        fs.mkdirSync(directory);
        fs.writeFileSync(path.join(directory, 'pack.json'), JSON.stringify(pack, null, 2) + '\n', { flag: 'wx' });
        const saved = [];
        for (const artifact of pack.result.artifacts) {
          if (!/^[a-z0-9][a-z0-9.-]*$/i.test(artifact.name) || artifact.name.includes('..')) throw Error('UNSAFE_ARTIFACT_NAME');
          const destination = path.join(directory, artifact.name);
          fs.writeFileSync(destination, artifact.content, { encoding: 'utf8', flag: 'wx' });
          same(fs.readFileSync(destination, 'utf8'), artifact.content, 'complete artifact bytes');
          saved.push({ name: artifact.name, bytes: Buffer.byteLength(artifact.content), sha256: sha(Buffer.from(artifact.content)), workbenchDigest: artifact.digest });
        }
        records.push({ method, language, caseId: sample.id, uniqueJobId: sample.job_id, elapsedMillis,
          summary: pack.result.summary, assetHash: manifest.assetHashes[method], evaluation: pack.evaluation,
          pack: { path: path.relative(options.output, path.join(directory, 'pack.json')), sha256: sha(fs.readFileSync(path.join(directory, 'pack.json'))) }, artifacts: saved });
      }
    }
    const result = { schema: 'funded-advantage-bundled-runtime-smoke/v1', scope: 'ACTUAL_BUNDLED_WORKBENCH_IN_NODE', browser: 'NOT_RUN', approvedOperator: 'NOT_RUN', production: 'NOT_RUN',
      began, ended: new Date().toISOString(), sourceHash: manifest.sourceHash, assertions, passed: true,
      uniqueJobs: 1, repeatedDemonstrationEvaluations: records.length, newConfirmatoryJobs: 0,
      inputIdentities: [identity(bundlePath), identity(dataPath), identity(casesPath), identity(manifestPath)],
      interpretation: 'Reuse of the already evaluated public J05-V1 example to qualify the static bundle and both report languages. These are not fresh confirmation jobs or browser acceptance.', records };
    fs.writeFileSync(path.join(options.output, 'runtime-smoke.json'), JSON.stringify(result, null, 2) + '\n', { flag: 'wx' });
    console.log(JSON.stringify({ ...result, records: records.map(({ artifacts, ...record }) => ({ ...record, artifacts: artifacts.length })) }, null, 2));
  } catch (error) {
    const failure = { schema: 'funded-advantage-bundled-runtime-smoke/v1', passed: false, began, ended: new Date().toISOString(), assertions, browser: 'NOT_RUN', error: String(error.stack ?? error), completed: records };
    fs.writeFileSync(path.join(options.output, 'failure.json'), JSON.stringify(failure, null, 2) + '\n', { flag: 'wx' });
    console.error(JSON.stringify(failure, null, 2));
    process.exitCode = 1;
  }
})();
