// SPDX-License-Identifier: Apache-2.0
// Deliberately a DOM shim and mock runtime. This is NOT browser acceptance.
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const html = fs.readFileSync(path.join(__dirname, 'index.template.html'), 'utf8');
const script = fs.readFileSync(path.join(__dirname, 'app.js'), 'utf8');
const css = fs.readFileSync(path.join(__dirname, 'style.css'), 'utf8');
const clone = (value) => JSON.parse(JSON.stringify(value));
const hash = 'a'.repeat(64);
const other = 'b'.repeat(64);
const names = ['inventory-report.md', 'differences.csv', 'actions.csv', 'normalized-inventories.json', 'complete-comparison.json', 'asset-identity.json'];
const inputData = {
  sample: { left: { text: '{"sources":{}}', format: 'json', label: { en: 'Mock old inventory', fr: 'Ancien inventaire fictif' } }, right: { text: 'path,sha256\n', format: 'csv', label: { en: 'Mock new inventory', fr: 'Nouvel inventaire fictif' } } },
  defaultMethod: 'conventional', assetHashes: { alpha: hash, conventional: other },
  summary: { uniqueJobs: 2, evaluations: 6, acceptedEvaluations: 6, refusalPassed: 3, refusalProbes: 3, conclusion: { en: 'Mock conclusion only.', fr: 'Conclusion fictive uniquement.' }, construction: { alpha: { elapsedSeconds: 12.5 }, conventional: { elapsedSeconds: 9 } } },
  economics: { scenarios: [
    { label: { en: 'Mock HOLD', fr: 'Attente fictive' }, status: 'HOLD', horizonJobs: 16, avoidedAttentionSecondsPerJob: 0, investmentUsd: 20, availableSurplusUsd: 0, paybackJob: null, cumulativeIncrementalValueUsd: -20 },
    { label: { en: 'Mock conditional pass', fr: 'Admission conditionnelle fictive' }, status: 'MODELED_ADMISSION', horizonJobs: 52, avoidedAttentionSecondsPerJob: 60, investmentUsd: 5, availableSurplusUsd: 7, paybackJob: 11, cumulativeIncrementalValueUsd: 15, assetHash: other },
  ] },
  downloadLinks: { paper: '../paper/paper.pdf', source: 'javascript:alert(1)', companion: '../companion.zip' },
};
function makePack(language = 'en', method = 'conventional') {
  return { schema: 'mock-workbench/v1', integrityDigest: 'MOCK_NOT_RUNTIME_EVIDENCE', evaluation: { scope: 'PUBLIC_LOCAL_EXECUTION', admission: 'HOLD', authority: [], settlement: 'NOT_CONNECTED' },
    result: { summary: { leftRows: 8, rightRows: 9, fieldDifferences: 2, unmatchedRows: 1, actionGroups: 3 },
      evidence: { assetHash: method === 'alpha' ? hash : other, comparison: { differences: [{ key: '<img src=x onerror=alert(1)>', kind: 'conflict' }, { key: 'readme.txt', kind: 'missing_from_left' }] }, measured: { preparationMicros: 125, comparisonMicros: 2000 } },
      artifacts: names.map((name) => ({ name, type: name.endsWith('.csv') ? 'text/csv' : name.endsWith('.json') ? 'application/json' : 'text/markdown', content: `${name} exact mock bytes ${language}\n`, digest: 'MOCK_DIGEST' })) } };
}

function environment(data = inputData, runtime = async (_input, language, method) => makePack(language, method)) {
  const nodes = [];
  const ids = new Map();
  const downloads = [];
  const blobs = new Map();
  const calls = [];
  let blobCounter = 0;
  const document = { documentElement: { lang: 'en' }, title: '', activeElement: null };
  class Element {
    constructor(tag) { this.tagName = tag.toUpperCase(); this.attributes = {}; this.dataset = {}; this.children = []; this.listeners = {}; this.value = ''; this.hidden = false; this.disabled = false; this._text = ''; this.parentNode = null; nodes.push(this); }
    set textContent(value) { this._text = String(value); this.children = []; }
    get textContent() { return this._text + this.children.map((child) => child.textContent).join(''); }
    set innerHTML(_value) { throw new Error('HTML_INJECTION_API_USED'); }
    setAttribute(name, value) { this.attributes[name] = String(value); if (name === 'id') { this.id = String(value); ids.set(this.id, this); } if (name.startsWith('data-')) this.dataset[name.slice(5).replace(/-([a-z])/g, (_, char) => char.toUpperCase())] = String(value); if (name === 'hidden') this.hidden = true; if (name === 'disabled') this.disabled = true; }
    getAttribute(name) { return this.attributes[name] ?? null; }
    removeAttribute(name) { delete this.attributes[name]; }
    appendChild(child) { child.parentNode = this; this.children.push(child); return child; }
    replaceChildren(...children) { this.children = []; this._text = ''; for (const child of children) this.appendChild(child); }
    addEventListener(type, handler) { (this.listeners[type] ??= []).push(handler); }
    async dispatch(type) { if (type === 'click' && this.disabled) return; return Promise.all((this.listeners[type] ?? []).map((handler) => handler({ type, target: this, preventDefault() {} }))); }
    click() { if (this.tagName === 'A') downloads.push({ name: this.download, href: this.href, blob: blobs.get(this.href) }); else return this.dispatch('click'); }
    remove() { if (this.parentNode) this.parentNode.children = this.parentNode.children.filter((child) => child !== this); }
    focus() { document.activeElement = this; }
  }
  document.body = new Element('body');
  for (const match of html.matchAll(/<([a-z][a-z0-9-]*)([^<>]*)>/gi)) {
    const node = new Element(match[1]);
    for (const attribute of match[2].matchAll(/([a-zA-Z_:][-a-zA-Z0-9_:.]*)(?:="([^"]*)")?/g)) node.setAttribute(attribute[1], attribute[2] ?? '');
  }
  document.getElementById = (id) => ids.get(id) ?? null;
  document.createElement = (tag) => new Element(tag);
  document.querySelectorAll = (selector) => {
    const match = /^\[([^\]]+)\]$/.exec(selector);
    if (!match) throw new Error(`Unsupported shim selector: ${selector}`);
    return nodes.filter((node) => Object.hasOwn(node.attributes, match[1]));
  };
  const context = vm.createContext({ document, DATA: clone(data), FUNDED_ADVANTAGE_SOURCE: 'c'.repeat(64),
    FUNDED_ADVANTAGE: runtime ? { run: async (...args) => { calls.push(clone(args)); return runtime(...args); } } : undefined,
    Blob, TextEncoder, console, Intl, setTimeout: (callback) => { callback(); return 0; },
    URL: { createObjectURL(blob) { const url = `blob:mock/${++blobCounter}`; blobs.set(url, blob); return url; }, revokeObjectURL() {} },
  });
  vm.runInContext(script, context, { filename: 'demo/app.js' });
  return { context, document, nodes, ids, downloads, calls, ui: context.FUNDED_ADVANTAGE_UI };
}

const checks = [];
async function check(name, fn) {
  try { await fn(); checks.push({ name, passed: true }); }
  catch (error) { checks.push({ name, passed: false, error: String(error.stack ?? error) }); }
}

(async () => {
  const began = new Date().toISOString();
  const env = environment();
  const get = (id) => env.ids.get(id);
  await check('four-template-markers-once', () => {
    for (const marker of ['/*__STYLE__*/', '/*__DATA__*/', '/*__RUNTIME__*/', '/*__APP__*/']) assert.equal(html.split(marker).length - 1, 1);
  });
  await check('self-contained-no-fetch-eval-or-external-resources', () => {
    assert(!/<(?:script|link|img|iframe)[^>]*(?:src|href)="https?:/i.test(html));
    assert(!/\b(?:fetch|eval)\s*\(|new\s+Function\b|localStorage|sessionStorage|XMLHttpRequest/u.test(script));
    assert(!/@import|https?:\/\//u.test(css));
  });
  await check('english-french-key-parity', () => {
    const keys = clone(env.ui.translationKeys());
    assert.deepEqual(keys.en, keys.fr);
    assert(keys.en.length > 100);
  });
  await check('every-static-string-has-both-translations', () => {
    const keys = new Set(env.ui.translationKeys().en);
    for (const node of env.document.querySelectorAll('[data-i18n]')) { assert(keys.has(node.dataset.i18n), node.dataset.i18n); assert(node.textContent); assert.notEqual(node.textContent, node.dataset.i18n); }
  });
  await check('all-static-buttons-and-selects-have-handlers', () => {
    for (const node of env.nodes.filter((node) => node.tagName === 'BUTTON')) assert(node.listeners.click?.length, node.id ?? node.dataset.artifact);
    for (const id of ['method', 'left-format', 'right-format', 'scenario']) assert(get(id).listeners.change?.length, id);
    for (const id of ['left-text', 'right-text']) assert(get(id).listeners.input?.length, id);
  });
  await check('default-method-and-inputs-come-from-data', () => {
    assert.equal(get('method').value, 'conventional');
    assert.equal(get('left-text').value, inputData.sample.left.text);
    assert.equal(get('right-format').value, 'csv');
    assert.equal(get('unique-jobs').textContent, '2');
    assert.equal(get('accepted-evaluations').textContent, '6 / 6');
    assert.equal(env.calls.length, 0);
  });
  await check('unsafe-publication-link-is-inert', () => {
    assert.equal(get('source-link').getAttribute('href'), null);
    assert.equal(get('source-link').getAttribute('aria-disabled'), 'true');
    assert.equal(get('paper-link').getAttribute('href'), inputData.downloadLinks.paper);
  });
  await check('primary-handler-calls-runtime-with-exact-inputs', async () => {
    await get('run-button').dispatch('click');
    assert.deepEqual(env.calls[0], [{ left: { text: inputData.sample.left.text, format: 'json' }, right: { text: inputData.sample.right.text, format: 'csv' } }, 'en', 'conventional']);
    assert.equal(get('result-panel').hidden, false);
    assert.equal(get('hash-differences').textContent, '2');
    assert.equal(get('missing-paths').textContent, '1');
    assert.equal(get('action-groups').textContent, '3');
    assert.equal(get('pack-admission').textContent, 'HOLD');
    assert.equal(get('pack-scope').textContent, 'PUBLIC_LOCAL_EXECUTION');
  });
  await check('user-path-is-text-not-html', () => {
    const firstCell = get('difference-preview').children[0].children[0];
    assert.equal(firstCell.textContent, '<img src=x onerror=alert(1)>');
    assert.equal(firstCell.children.length, 0);
  });
  await check('all-primary-artifact-downloads-preserve-exact-bytes', async () => {
    for (const node of env.document.querySelectorAll('[data-artifact]')) {
      assert.equal(node.disabled, false);
      await node.dispatch('click');
      const saved = env.downloads.at(-1);
      assert.equal(saved.name, node.dataset.artifact);
      assert.equal(await saved.blob.text(), `${node.dataset.artifact} exact mock bytes en\n`);
    }
  });
  await check('complete-pack-download-preserves-returned-pack', async () => {
    await get('download-pack').dispatch('click');
    assert.equal(env.downloads.at(-1).name, 'workbench-pack.json');
    assert.deepEqual(JSON.parse(await env.downloads.at(-1).blob.text()), makePack());
  });
  await check('every-runtime-artifact-has-a-working-download', async () => {
    assert.equal(get('all-artifacts').children.length, names.length);
    for (let i = 0; i < names.length; i += 1) {
      await get('all-artifacts').children[i].dispatch('click');
      assert.equal(env.downloads.at(-1).name, names[i]);
    }
  });
  await check('french-switch-preserves-input-and-discloses-report-language', async () => {
    const count = env.calls.length;
    await get('language-fr').dispatch('click');
    assert.equal(env.document.documentElement.lang, 'fr');
    assert.equal(get('language-fr').getAttribute('aria-pressed'), 'true');
    assert.equal(get('language-en').getAttribute('aria-pressed'), 'false');
    assert.equal(get('run-label').textContent, 'Essayer maintenant');
    assert.equal(get('left-text').value, inputData.sample.left.text);
    assert(get('result-description').textContent.includes('English'));
    assert(get('result-description').textContent.includes('Relancez'));
    assert.equal(env.calls.length, count);
  });
  await check('french-run-passes-french-to-runtime', async () => {
    await get('run-button').dispatch('click');
    assert.equal(env.calls.at(-1)[1], 'fr');
    const report = env.document.querySelectorAll('[data-artifact]').find((node) => node.dataset.artifact === 'inventory-report.md');
    await report.dispatch('click');
    assert((await env.downloads.at(-1).blob.text()).endsWith('fr\n'));
  });
  await check('method-change-invalidates-stale-results', async () => {
    get('method').value = 'alpha';
    await get('method').dispatch('change');
    assert.equal(get('result-panel').hidden, true);
    assert.equal(get('download-pack').disabled, true);
    await get('run-button').dispatch('click');
    assert.equal(env.calls.at(-1)[2], 'alpha');
    assert.equal(get('used-asset').textContent, hash);
  });
  await check('text-and-format-changes-invalidate-and-pass-verbatim', async () => {
    get('left-text').value = 'custom inventory';
    await get('left-text').dispatch('input');
    assert.equal(get('download-pack').disabled, true);
    get('left-format').value = 'sha256sum';
    await get('left-format').dispatch('change');
    await get('run-button').dispatch('click');
    assert.deepEqual(env.calls.at(-1)[0].left, { text: 'custom inventory', format: 'sha256sum' });
  });
  await check('sample-reset-restores-input-without-running', async () => {
    const count = env.calls.length;
    await get('reset-button').dispatch('click');
    assert.equal(get('left-text').value, inputData.sample.left.text);
    assert.equal(get('left-format').value, inputData.sample.left.format);
    assert.equal(get('result-panel').hidden, true);
    assert.equal(env.calls.length, count);
  });
  await check('scenario-control-renders-recorded-values-only', async () => {
    get('scenario').value = '1';
    await get('scenario').dispatch('change');
    assert.equal(env.ui.getState().scenarioIndex, 1);
    assert.equal(get('scenario-payback').textContent, '11');
    assert(get('scenario-status').textContent.includes('modélisée'));
    assert.deepEqual(JSON.parse(get('scenario-record').textContent), inputData.economics.scenarios[1]);
  });
  await check('zero-savings-and-no-payback-are-not-hidden', async () => {
    get('scenario').value = '0';
    await get('scenario').dispatch('change');
    assert.equal(get('scenario-attention').textContent, '0 s');
    assert(get('scenario-payback').textContent.includes('Non remboursé'));
    assert(get('scenario-value').textContent.includes('20'));
  });
  await check('embedded-evidence-download-preserves-full-data', async () => {
    await get('download-evidence').dispatch('click');
    const saved = JSON.parse(await env.downloads.at(-1).blob.text());
    assert.deepEqual(saved.summary, inputData.summary);
    assert.deepEqual(saved.economics, inputData.economics);
    assert.deepEqual(saved.assetHashes, inputData.assetHashes);
  });
  await check('runtime-refusal-clears-output-and-preserves-message', async () => {
    let refuse = false;
    const trial = environment(inputData, async () => { if (refuse) throw new Error('PATH_REFUSED <literal>'); return makePack(); });
    await trial.ui.run();
    refuse = true;
    await trial.ui.run();
    assert.equal(trial.ids.get('result-panel').hidden, true);
    assert.equal(trial.ids.get('error-panel').hidden, false);
    assert.equal(trial.ids.get('error-message').textContent, 'PATH_REFUSED <literal>');
    assert.equal(trial.ids.get('download-pack').disabled, true);
    trial.ui.resetSample();
    assert.equal(trial.ids.get('error-panel').hidden, true);
  });
  await check('busy-state-prevents-duplicate-runs-and-releases-controls', async () => {
    let finish;
    const trial = environment(inputData, () => new Promise((resolve) => { finish = resolve; }));
    const pending = trial.ui.run();
    assert.equal(trial.ui.getState().busy, true);
    assert.equal(trial.ids.get('run-button').disabled, true);
    assert.equal(trial.ids.get('left-text').disabled, true);
    assert.equal(trial.ids.get('mission').getAttribute('aria-busy'), 'true');
    trial.ui.setLanguage('fr');
    assert.equal(trial.ui.getState().language, 'en');
    await trial.ui.run();
    assert.equal(trial.calls.length, 1);
    finish(makePack()); await pending;
    assert.equal(trial.ui.getState().busy, false);
    assert.equal(trial.ids.get('run-button').disabled, false);
    assert.equal(trial.ids.get('mission').getAttribute('aria-busy'), 'false');
  });
  await check('invalid-runtime-pack-refuses-without-artifact-buttons', async () => {
    const trial = environment(inputData, async () => ({ result: { summary: {}, artifacts: [{ name: 'x', content: null }] } }));
    await trial.ui.run();
    assert.equal(trial.ids.get('error-message').textContent, 'INVALID_WORKBENCH_PACK');
    assert.equal(trial.ids.get('download-pack').disabled, true);
  });
  await check('missing-runtime-is-explicit', async () => {
    const trial = environment(inputData, null);
    await trial.ui.run();
    assert(trial.ids.get('error-message').textContent.includes('unavailable'));
    assert.equal(trial.ids.get('result-panel').hidden, true);
  });
  await check('missing-numbers-stay-unknown-not-zero', () => {
    const trial = environment({ sample: inputData.sample, summary: {}, economics: {}, defaultMethod: 'alpha' });
    assert.equal(trial.ids.get('unique-jobs').textContent, 'Unknown');
    assert.equal(trial.ids.get('alpha-construction').textContent, 'Unknown');
    assert.equal(trial.ids.get('scenario-investment').textContent, 'Unknown');
    assert.equal(trial.ids.get('scenario').disabled, true);
    assert.equal(trial.ids.get('method').value, 'alpha');
    trial.ui.setLanguage('fr');
    assert.equal(trial.ids.get('scenario-investment').textContent, 'Inconnu');
  });
  await check('all-control-labels-resolve-and-mobile-reduced-motion-rules-exist', () => {
    for (const match of html.matchAll(/<label[^>]*for="([^"]+)"/g)) assert(env.ids.has(match[1]), match[1]);
    assert(css.includes('@media(max-width:620px)'));
    assert(css.includes('@media(prefers-reduced-motion:reduce)'));
    assert(html.includes('aria-live="polite"'));
    assert(html.includes('role="alert"'));
  });
  await check('downstream-bounds-and-financial-status-remain-visible-in-both-languages', () => {
    for (const language of ['en', 'fr']) {
      env.ui.setLanguage(language);
      const text = env.document.querySelectorAll('[data-i18n]').map((node) => node.textContent).join('\n');
      assert(text.includes(language === 'fr' ? 'sans troncature' : 'nothing is truncated'));
      assert(text.includes(language === 'fr' ? 'ne sont pas des revenus gagnés' : 'not earned revenue'));
      assert(text.includes(language === 'fr' ? 'Un coût inconnu n’est pas nul' : 'Unknown cost is not zero'));
      assert(text.includes('USDC'));
    }
  });
  const failed = checks.filter((item) => !item.passed).length;
  console.log(JSON.stringify({ schema: 'funded-advantage-ui-shim/v1', scope: 'DOM_SHIM_WITH_MOCK_RUNTIME_ONLY', browser: 'NOT_RUN', actual_runtime_execution: 'NOT_RUN', began, ended: new Date().toISOString(), checks: checks.length, passed: checks.length - failed, failed, results: checks }, null, 2));
  if (failed) process.exitCode = 1;
})();
