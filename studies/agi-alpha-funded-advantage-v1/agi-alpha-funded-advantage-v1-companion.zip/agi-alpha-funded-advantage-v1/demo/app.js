// SPDX-License-Identifier: Apache-2.0
(() => {
  'use strict';
  const data = typeof DATA === 'object' && DATA ? DATA : (globalThis.DATA || {});
  const strings = {
    en: {
      skip: 'Skip to the demonstration', studyTitle: 'The advantage that funds the next',
      titleOne: 'Useful inventory checks.', titleTwo: 'Economic payback remains unproven.',
      heroDescription: 'Compare real release inventories with a retained executable capability. Inspect what changed, the fresh evidence, and the conditions an investment would need to repay its cost.',
      localExecution: 'Local execution', publicSources: 'Pinned public sources', noTransactions: 'No financial transactions',
      uniqueJobs: 'unique comparison jobs', acceptedEvaluations: 'accepted method evaluations', refusalResults: 'expected refusal checks',
      repetitionNote: 'Repeated representations and methods are robustness checks, not additional customers.',
      missionEyebrow: '01 / Useful work today', missionTitle: 'What changed in this release?', realRuntime: 'Actual Alpha Workbench',
      missionDescription: 'Run the included public example. The capability prepares two inventories, then the existing Alpha catalogue engine produces the complete differences and proposed actions.',
      leftInventory: 'Earlier inventory', rightInventory: 'Later inventory', tryNow: 'Try it now',
      methodLabel: 'Retained implementation', alphaMethod: 'Alpha construction', conventionalMethod: 'Conventional construction', resetSample: 'Restore the public example',
      methodExplanation: 'The default comes from the recorded evidence. Choosing an implementation does not establish economic superiority; ordinary delivery keeps its normal tools and caches.',
      advancedLabel: 'Inspect or replace the inventories',
      advancedHelp: 'Use public or synthetic text. Intake allows 1 MB and 128 exact SHA-256 paths, but the existing delivery engine has smaller cell and output limits. Some valid inventories can therefore refuse downstream; nothing is truncated. Named files are never opened.',
      format: 'Format', autoFormat: 'Automatic', inputPrivacy: 'The bundled runtime works in this page. Input text is not uploaded or persisted by this demonstration.',
      refusedTitle: 'This input was refused.', refusedHelp: 'No deliverable was accepted. Review the declared formats and path rules, or restore the public example.',
      resultEyebrow: 'Your deliverable', resultTitle: 'A complete release comparison', generatedLocally: 'Generated locally',
      hashDifferences: 'different declared hashes', missingPaths: 'entries absent from one side', actionGroups: 'proposed action groups',
      previewCaption: 'Difference preview · downloads preserve the full result', pathColumn: 'Path', differenceColumn: 'Difference',
      downloadReport: 'Report ↓', downloadDifferences: 'Differences CSV ↓', downloadActions: 'Actions CSV ↓', downloadNormalized: 'Normalized inputs ↓', downloadPack: 'Workbench pack ↓',
      identityLimit: 'These are checks of declared identities. They do not certify source behavior or security, and do not apply corrections.',
      inspectExecution: 'Inspect this execution and every artifact', usedAsset: 'Used asset SHA-256', runtimeScope: 'Execution scope', runtimeAdmission: 'Workbench admission', preparationTime: 'Preparation in this run', comparisonTime: 'Comparison in this run',
      storyEyebrow: '02 / What the investment changes', storyTitle: 'From useful work to an economic decision',
      stepMission: 'Useful mission', stepMissionText: 'Compare declared release identities.', stepBottleneck: 'Preparation cost', stepBottleneckText: 'Different inventory formats need exact intake.',
      stepAsset: 'Retained capability', stepAssetText: 'A versioned parser and explicit refusal rules.', stepFresh: 'Fresh public work', stepFreshText: 'Check unseen jobs against a separate reference.',
      stepPayback: 'Admission test', stepPaybackText: 'Include every cost and compare strong alternatives.', findingTitle: 'A useful asset is only the beginning.',
      conclusionFallback: 'Technical evidence and monetary value are separate questions. Complete-cost payback and measured attention savings have not been established.',
      economicsEyebrow: '03 / The cost of the next advantage', economicsTitle: 'Keep the economic claim honest.', economicHold: 'Observed economic admission: HOLD',
      observedCosts: 'What is observed', fullCostTitle: 'The complete monetary cost is unknown.',
      fullCostText: 'Execution and construction time are measured. Authoring inference, fully allocated infrastructure and human attention are not fully metered. Unknown cost is not zero.',
      alphaConstruction: 'Alpha construction elapsed', conventionalConstruction: 'Conventional construction elapsed', authoringBill: 'Complete authoring bill', attentionSaved: 'Measured attention saving', observedPayback: 'Observed full-cost payback',
      unknown: 'Unknown', notEstablished: 'Not established',
      constructionCaution: 'Shorter elapsed construction does not establish lower complete monetary cost. Both builders used the same declared contract and resource limits.',
      conditionalModel: 'A conditional financing model', scenarioTitle: 'What would have to be true?',
      scenarioWarning: 'Saved attention is an assumption, not a measured advantage. Modeled collections are not earned revenue. A positive case is conditional on its costs, demand and timing.',
      scenarioLabel: 'Inspect a recorded scenario', scenarioHorizon: 'Finite horizon', scenarioAttention: 'Assumed attention saved / job', scenarioInvestment: 'Complete modeled investment', scenarioSurplus: 'Available collected surplus', scenarioPayback: 'Modeled payback job', scenarioValue: 'Cumulative incremental value', scenarioRecord: 'Inspect the complete scenario record',
      seedCaution: 'Initial capital is separate from earned contribution. Receivables and customer savings are not spendable surplus. The funded asset must match the tested asset.',
      noScenarios: 'No modeled scenario embedded', scenarioFallback: 'Inspect the complete record for funding timing, reserves, failures and asset identity. This record does not change observed economic HOLD.',
      modeledOnly: 'Conditional model only', modeledAdmission: 'Modeled admission only', modeledHold: 'Modeled HOLD', notRepaid: 'Not repaid within the horizon', jobsUnit: 'jobs', secondsUnit: 's',
      evidenceEyebrow: '04 / Inspect the evidence', evidenceTitle: 'Take the work with you.', downloadEvidence: 'Embedded evidence JSON ↓',
      evidenceDescription: 'The paper, executable source and companion preserve the protocol, unsuccessful hypotheses, independent checks and complete machine-readable records.',
      paperLabel: 'Research paper', sourceLabel: 'Executable source', sourceLinkText: 'Inspect source ↗', companionLabel: 'Reproducible companion', companionLinkText: 'Download evidence ↗',
      inspectIdentities: 'Inspect source and candidate identities', sourceIdentity: 'Runtime source identity', alphaIdentity: 'Alpha candidate SHA-256', conventionalIdentity: 'Conventional candidate SHA-256',
      localState: 'This local demonstration', ciState: 'Isolated CI', operatorState: 'Approved operator', productionState: 'Production', notRun: 'Not run', ready: 'Ready to run', executed: 'Executed locally', refused: 'Refused',
      closing: 'Useful work today. Investment only when the evidence justifies it.',
      tokenNote: '$AGIALPHA routes and the Manager’s USDC route remain distinct. This demonstration performs no settlement, token transfer or financial transaction.',
      running: 'Comparing inventories…', complete: 'Comparison generated. Complete artifacts are ready below.', sampleRestored: 'Public example restored.', changed: 'Inputs or implementation changed. Run a fresh comparison.',
      runtimeUnavailable: 'The bundled runtime is unavailable. Open the complete built demonstration.',
      leftPublicLabel: 'Pinned historical inventory', rightPublicLabel: 'Pinned current inventory',
      resultDescription: '{left} declared paths on the left; {right} on the right. Report language: {language}.',
      differenceConflict: 'Declared SHA-256 changed', differenceMissingRight: 'Missing from the later inventory', differenceMissingLeft: 'New in the later inventory',
      noDifferences: 'No declared-identity differences in this result.', previewNote: 'Showing {shown} of {total} differences. The downloaded files retain every row.',
      runAgainLanguage: 'Rerun to generate a report in the selected language.', scenarioNumber: 'Scenario {number}',
    },
    fr: {
      skip: 'Aller à la démonstration', studyTitle: 'L’avantage qui finance le prochain progrès',
      titleOne: 'Des contrôles d’inventaire utiles.', titleTwo: 'Le retour économique reste à démontrer.',
      heroDescription: 'Comparez de vrais inventaires de livraison avec une capacité exécutable conservée. Examinez les changements, les nouveaux résultats et les conditions nécessaires au remboursement de l’investissement.',
      localExecution: 'Exécution locale', publicSources: 'Sources publiques figées', noTransactions: 'Aucune transaction financière',
      uniqueJobs: 'missions de comparaison uniques', acceptedEvaluations: 'évaluations de méthodes acceptées', refusalResults: 'contrôles de refus attendus',
      repetitionNote: 'Les représentations et méthodes répétées vérifient la robustesse ; elles ne représentent pas de nouveaux clients.',
      missionEyebrow: '01 / Du travail utile aujourd’hui', missionTitle: 'Qu’est-ce qui a changé dans cette livraison ?', realRuntime: 'Véritable Workbench Alpha',
      missionDescription: 'Exécutez l’exemple public fourni. La capacité prépare deux inventaires, puis le moteur de catalogue Alpha existant produit toutes les différences et les actions proposées.',
      leftInventory: 'Inventaire antérieur', rightInventory: 'Inventaire ultérieur', tryNow: 'Essayer maintenant',
      methodLabel: 'Implémentation conservée', alphaMethod: 'Construction Alpha', conventionalMethod: 'Construction conventionnelle', resetSample: 'Restaurer l’exemple public',
      methodExplanation: 'Le choix par défaut provient des résultats enregistrés. Choisir une implémentation ne démontre pas sa supériorité économique ; la méthode ordinaire conserve ses outils et caches habituels.',
      advancedLabel: 'Examiner ou remplacer les inventaires',
      advancedHelp: 'Utilisez du texte public ou synthétique. L’entrée autorise 1 Mo et 128 chemins SHA-256 exacts, mais le moteur de livraison impose des limites plus faibles aux cellules et sorties. Certains inventaires valides peuvent donc être refusés ensuite, sans troncature. Aucun fichier nommé n’est ouvert.',
      format: 'Format', autoFormat: 'Automatique', inputPrivacy: 'Le moteur intégré fonctionne dans cette page. Cette démonstration ne téléverse ni ne conserve le texte saisi.',
      refusedTitle: 'Cette entrée a été refusée.', refusedHelp: 'Aucun livrable n’a été accepté. Vérifiez les formats et les règles des chemins, ou restaurez l’exemple public.',
      resultEyebrow: 'Votre livrable', resultTitle: 'Une comparaison complète de livraison', generatedLocally: 'Générée localement',
      hashDifferences: 'empreintes déclarées différentes', missingPaths: 'entrées absentes d’un côté', actionGroups: 'groupes d’actions proposés',
      previewCaption: 'Aperçu des différences · les téléchargements conservent le résultat complet', pathColumn: 'Chemin', differenceColumn: 'Différence',
      downloadReport: 'Rapport ↓', downloadDifferences: 'Différences CSV ↓', downloadActions: 'Actions CSV ↓', downloadNormalized: 'Entrées normalisées ↓', downloadPack: 'Dossier Workbench ↓',
      identityLimit: 'Ces contrôles portent sur les identités déclarées. Ils ne certifient ni le comportement ni la sécurité des sources et n’appliquent aucune correction.',
      inspectExecution: 'Examiner cette exécution et tous les fichiers', usedAsset: 'SHA-256 de la capacité utilisée', runtimeScope: 'Portée de l’exécution', runtimeAdmission: 'Admission du Workbench', preparationTime: 'Préparation de cette exécution', comparisonTime: 'Comparaison de cette exécution',
      storyEyebrow: '02 / Ce que change l’investissement', storyTitle: 'Du travail utile à la décision économique',
      stepMission: 'Mission utile', stepMissionText: 'Comparer les identités déclarées des livraisons.', stepBottleneck: 'Coût de préparation', stepBottleneckText: 'Des formats différents exigent une lecture exacte.',
      stepAsset: 'Capacité conservée', stepAssetText: 'Un analyseur versionné et des règles de refus explicites.', stepFresh: 'Nouvelles missions', stepFreshText: 'Vérifier des missions inédites avec une référence distincte.',
      stepPayback: 'Test d’admission', stepPaybackText: 'Inclure tous les coûts et comparer des alternatives solides.', findingTitle: 'Une capacité utile n’est qu’un début.',
      conclusionFallback: 'Les résultats techniques et la valeur monétaire sont deux questions distinctes. Le remboursement du coût complet et le gain de temps d’attention mesuré restent à démontrer.',
      economicsEyebrow: '03 / Le coût du prochain avantage', economicsTitle: 'Rester fidèle aux preuves économiques.', economicHold: 'Admission économique observée : EN ATTENTE',
      observedCosts: 'Ce qui est observé', fullCostTitle: 'Le coût monétaire complet est inconnu.',
      fullCostText: 'Les durées d’exécution et de construction sont mesurées. L’inférence de conception, l’infrastructure entièrement imputée et l’attention humaine ne sont pas intégralement mesurées. Un coût inconnu n’est pas nul.',
      alphaConstruction: 'Durée de construction Alpha', conventionalConstruction: 'Durée de construction conventionnelle', authoringBill: 'Facture complète de conception', attentionSaved: 'Gain d’attention mesuré', observedPayback: 'Remboursement observé du coût complet',
      unknown: 'Inconnu', notEstablished: 'Non établi',
      constructionCaution: 'Une construction plus rapide ne prouve pas un coût monétaire complet inférieur. Les deux constructeurs disposaient du même contrat et des mêmes limites de ressources.',
      conditionalModel: 'Un modèle de financement conditionnel', scenarioTitle: 'Quelles conditions faudrait-il réunir ?',
      scenarioWarning: 'Le temps d’attention économisé est une hypothèse, pas un avantage mesuré. Les encaissements modélisés ne sont pas des revenus gagnés. Un cas positif dépend de ses coûts, de la demande et des délais.',
      scenarioLabel: 'Examiner un scénario enregistré', scenarioHorizon: 'Horizon fini', scenarioAttention: 'Attention économisée supposée / mission', scenarioInvestment: 'Investissement modélisé complet', scenarioSurplus: 'Surplus encaissé disponible', scenarioPayback: 'Mission de remboursement modélisée', scenarioValue: 'Valeur incrémentale cumulée', scenarioRecord: 'Examiner le scénario complet',
      seedCaution: 'Le capital initial est distinct de la contribution gagnée. Les créances et les économies du client ne sont pas un surplus disponible. La capacité financée doit être celle qui a été testée.',
      noScenarios: 'Aucun scénario modélisé intégré', scenarioFallback: 'Consultez le dossier complet pour les délais d’encaissement, les réserves, les échecs et l’identité de la capacité. Ce scénario ne change pas l’admission économique observée : EN ATTENTE.',
      modeledOnly: 'Modèle conditionnel uniquement', modeledAdmission: 'Admission modélisée uniquement', modeledHold: 'Modèle : EN ATTENTE', notRepaid: 'Non remboursé dans cet horizon', jobsUnit: 'missions', secondsUnit: 's',
      evidenceEyebrow: '04 / Examiner les preuves', evidenceTitle: 'Emportez les résultats.', downloadEvidence: 'Preuves intégrées JSON ↓',
      evidenceDescription: 'L’article, le code exécutable et le dossier reproductible conservent le protocole, les hypothèses infructueuses, les contrôles indépendants et les relevés complets lisibles par machine.',
      paperLabel: 'Article de recherche', sourceLabel: 'Code exécutable', sourceLinkText: 'Examiner le code ↗', companionLabel: 'Dossier reproductible', companionLinkText: 'Télécharger les preuves ↗',
      inspectIdentities: 'Examiner les identités du moteur et des capacités', sourceIdentity: 'Identité du code du moteur', alphaIdentity: 'SHA-256 de la capacité Alpha', conventionalIdentity: 'SHA-256 de la capacité conventionnelle',
      localState: 'Cette démonstration locale', ciState: 'CI isolée', operatorState: 'Opérateur approuvé', productionState: 'Production', notRun: 'Non exécuté', ready: 'Prêt à exécuter', executed: 'Exécuté localement', refused: 'Refusé',
      closing: 'Du travail utile aujourd’hui. Investir seulement lorsque les preuves le justifient.',
      tokenNote: 'Les voies $AGIALPHA et la voie USDC du Manager restent distinctes. Cette démonstration n’effectue aucun règlement, transfert de jeton ni transaction financière.',
      running: 'Comparaison des inventaires…', complete: 'Comparaison générée. Les fichiers complets sont disponibles ci-dessous.', sampleRestored: 'Exemple public restauré.', changed: 'Les entrées ou l’implémentation ont changé. Lancez une nouvelle comparaison.',
      runtimeUnavailable: 'Le moteur intégré est indisponible. Ouvrez la démonstration complète compilée.',
      leftPublicLabel: 'Inventaire historique figé', rightPublicLabel: 'Inventaire actuel figé',
      resultDescription: '{left} chemins déclarés à gauche ; {right} à droite. Langue du rapport : {language}.',
      differenceConflict: 'SHA-256 déclaré modifié', differenceMissingRight: 'Absent de l’inventaire ultérieur', differenceMissingLeft: 'Nouveau dans l’inventaire ultérieur',
      noDifferences: 'Aucune différence d’identité déclarée dans ce résultat.', previewNote: '{shown} différences affichées sur {total}. Les fichiers téléchargés conservent toutes les lignes.',
      runAgainLanguage: 'Relancez pour générer un rapport dans la langue sélectionnée.', scenarioNumber: 'Scénario {number}',
    },
  };
  const byId = (id) => document.getElementById(id);
  const all = (selector) => Array.from(document.querySelectorAll(selector));
  const state = { language: 'en', method: data.defaultMethod === 'alpha' ? 'alpha' : 'conventional', busy: false, pack: null, reportLanguage: null, statusKey: '', local: 'notRun', scenarioIndex: 0 };
  const t = (key, values = {}) => String(strings[state.language][key] ?? key).replace(/\{([a-zA-Z]+)\}/g, (_, name) => String(values[name] ?? `{${name}}`));
  const put = (id, value) => { const element = byId(id); if (element) element.textContent = String(value); };
  const localized = (value, fallback = '') => typeof value === 'string' ? value : value?.[state.language] ?? value?.en ?? fallback;
  const finite = (value) => typeof value === 'number' && Number.isFinite(value);
  const number = (value, digits = 0) => finite(value) ? new Intl.NumberFormat(state.language === 'fr' ? 'fr-CA' : 'en-CA', { maximumFractionDigits: digits }).format(value) : t('unknown');
  const ratio = (passed, total) => finite(passed) && finite(total) ? `${number(passed)} / ${number(total)}` : t('unknown');
  const money = (value) => finite(value) ? new Intl.NumberFormat(state.language === 'fr' ? 'fr-CA' : 'en-CA', { style: 'currency', currency: 'USD', maximumFractionDigits: 2 }).format(value) : t('unknown');
  const seconds = (value) => finite(value) ? `${number(value, 2)} ${t('secondsUnit')}` : t('unknown');
  const sourceIdentity = () => {
    const source = globalThis.FUNDED_ADVANTAGE_SOURCE;
    return typeof source === 'string' ? source : source?.sourceHash ?? source?.sha256 ?? t('unknown');
  };
  const summary = data.summary ?? {};
  const economics = data.economics ?? {};
  const scenarios = Array.isArray(economics.scenarios) ? economics.scenarios : (Array.isArray(economics.examples) ? economics.examples : []);

  function clear(element) { element.replaceChildren(); }
  function element(tag, text, className = '') {
    const node = document.createElement(tag);
    if (text !== undefined) node.textContent = String(text);
    if (className) node.className = className;
    return node;
  }
  function updateDownloadButtons() {
    for (const button of all('[data-artifact]')) {
      button.disabled = state.busy || !state.pack?.result?.artifacts?.some((artifact) => artifact.name === button.dataset.artifact);
    }
    byId('download-pack').disabled = state.busy || !state.pack;
  }
  function renderStudy() {
    put('unique-jobs', number(summary.uniqueJobs));
    put('accepted-evaluations', ratio(summary.acceptedEvaluations, summary.evaluations));
    put('refusal-results', ratio(summary.refusalPassed, summary.refusalProbes));
    put('study-conclusion', localized(summary.conclusion, t('conclusionFallback')));
    put('method-note', localized(summary.defaultMethodReason, t('methodExplanation')));
    for (const method of ['alpha', 'conventional']) {
      put(`${method}-construction`, seconds(summary.construction?.[method]?.elapsedSeconds));
      put(`${method}-hash`, data.assetHashes?.[method] ?? t('unknown'));
    }
    put('source-hash', sourceIdentity());
    put('local-state', t(state.local));
    put('ci-state', localized(summary.execution?.ci, t('notRun')));
    put('left-label', localized(data.sample?.left?.label ?? data.sample?.leftLabel, t('leftPublicLabel')));
    put('right-label', localized(data.sample?.right?.label ?? data.sample?.rightLabel, t('rightPublicLabel')));
    for (const [name, id] of [['paper', 'paper-link'], ['source', 'source-link'], ['companion', 'companion-link']]) {
      const link = byId(id);
      const url = data.downloadLinks?.[name];
      if (typeof url === 'string' && url.trim() && !/^\s*(?:javascript|data|vbscript):/iu.test(url)) {
        link.setAttribute('href', url);
        link.setAttribute('aria-disabled', 'false');
        link.setAttribute('rel', 'noopener');
      } else {
        link.removeAttribute('href');
        link.setAttribute('aria-disabled', 'true');
      }
    }
  }
  function renderScenarios() {
    const select = byId('scenario');
    clear(select);
    if (!scenarios.length) {
      const option = element('option', t('noScenarios'));
      option.value = '';
      select.appendChild(option);
      select.disabled = true;
      state.scenarioIndex = 0;
    } else {
      select.disabled = false;
      scenarios.forEach((scenario, index) => {
        const option = element('option', localized(scenario.label, t('scenarioNumber', { number: index + 1 })));
        option.value = String(index);
        select.appendChild(option);
      });
      select.value = String(state.scenarioIndex);
    }
    renderScenario();
  }
  function renderScenario() {
    const scenario = scenarios[state.scenarioIndex];
    let status = t('modeledOnly');
    if (scenario?.status === 'MODELED_ADMISSION') status = t('modeledAdmission');
    else if (scenario?.status?.includes('HOLD') || scenario?.status === 'REJECT') status = t('modeledHold');
    put('scenario-status', scenario ? status : t('noScenarios'));
    put('scenario-horizon', finite(scenario?.horizonJobs) ? `${number(scenario.horizonJobs)} ${t('jobsUnit')}` : t('unknown'));
    put('scenario-attention', seconds(scenario?.avoidedAttentionSecondsPerJob));
    put('scenario-investment', money(scenario?.investmentUsd));
    put('scenario-surplus', money(scenario?.availableSurplusUsd));
    put('scenario-value', money(scenario?.cumulativeIncrementalValueUsd));
    put('scenario-payback', scenario?.paybackJob === null ? t('notRepaid') : number(scenario?.paybackJob));
    put('scenario-explanation', localized(scenario?.explanation, t('scenarioFallback')));
    put('scenario-record', JSON.stringify(scenario ?? { status: 'NOT_PROVIDED' }, null, 2));
  }
  function artifactDownload(name) {
    const artifact = state.pack?.result?.artifacts?.find((item) => item.name === name);
    if (!artifact || state.busy) return false;
    download(artifact.name, artifact.type || 'application/octet-stream', artifact.content);
    return true;
  }
  function download(name, type, content) {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = name;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }
  function renderResult() {
    const pack = state.pack;
    byId('result-panel').hidden = !pack;
    updateDownloadButtons();
    if (!pack) return;
    const result = pack.result;
    const metrics = result.summary;
    put('result-description', t('resultDescription', { left: number(metrics.leftRows), right: number(metrics.rightRows), language: state.reportLanguage === 'fr' ? 'Français' : 'English' }) + (state.reportLanguage !== state.language ? ` ${t('runAgainLanguage')}` : ''));
    put('hash-differences', number(metrics.fieldDifferences));
    put('missing-paths', number(metrics.unmatchedRows));
    put('action-groups', number(metrics.actionGroups));
    const differences = Array.isArray(result.evidence?.comparison?.differences) ? result.evidence.comparison.differences : [];
    const body = byId('difference-preview');
    clear(body);
    if (!differences.length) {
      const row = element('tr');
      const cell = element('td', t('noDifferences'));
      cell.setAttribute('colspan', '2');
      row.appendChild(cell); body.appendChild(row);
    } else {
      for (const difference of differences.slice(0, 8)) {
        const row = element('tr');
        row.appendChild(element('td', difference.key ?? difference.path ?? t('unknown')));
        const key = { conflict: 'differenceConflict', missing_from_right: 'differenceMissingRight', missing_from_left: 'differenceMissingLeft' }[difference.kind];
        row.appendChild(element('td', key ? t(key) : difference.kind ?? t('unknown')));
        body.appendChild(row);
      }
    }
    put('preview-note', t('previewNote', { shown: Math.min(differences.length, 8), total: differences.length }));
    put('used-asset', result.evidence?.assetHash ?? t('unknown'));
    put('pack-scope', pack.evaluation?.scope ?? t('unknown'));
    put('pack-admission', typeof pack.admission === 'string' ? pack.admission : (pack.admission?.decision ?? pack.evaluation?.admission ?? t('unknown')));
    put('preparation-time', finite(result.evidence?.measured?.preparationMicros) ? `${number(result.evidence.measured.preparationMicros / 1000, 3)} ms` : t('unknown'));
    put('comparison-time', finite(result.evidence?.measured?.comparisonMicros) ? `${number(result.evidence.measured.comparisonMicros / 1000, 3)} ms` : t('unknown'));
    const list = byId('all-artifacts');
    clear(list);
    for (const artifact of result.artifacts) {
      const button = element('button', `${artifact.name} ↓`, 'button compact');
      button.type = 'button';
      button.addEventListener('click', () => artifactDownload(artifact.name));
      list.appendChild(button);
    }
  }
  function setBusy(busy) {
    state.busy = busy;
    byId('mission').setAttribute('aria-busy', String(busy));
    for (const id of ['run-button', 'reset-button', 'method', 'left-text', 'right-text', 'left-format', 'right-format', 'language-en', 'language-fr']) byId(id).disabled = busy;
    put('run-label', busy ? t('running') : t('tryNow'));
    updateDownloadButtons();
  }
  function invalidate(statusKey = 'changed') {
    if (state.busy) return;
    state.pack = null;
    state.reportLanguage = null;
    state.statusKey = statusKey;
    byId('error-panel').hidden = true;
    put('error-message', '');
    renderResult();
    put('run-status', statusKey ? t(statusKey) : '');
  }
  function resetSample(announce = true) {
    if (state.busy) return;
    for (const side of ['left', 'right']) {
      const sample = data.sample?.[side] ?? {};
      byId(`${side}-text`).value = typeof sample.text === 'string' ? sample.text : '';
      byId(`${side}-format`).value = ['auto', 'json', 'csv', 'sha256sum'].includes(sample.format) ? sample.format : 'auto';
    }
    invalidate(announce ? 'sampleRestored' : '');
  }
  async function run() {
    if (state.busy) return null;
    invalidate('');
    state.method = byId('method').value === 'alpha' ? 'alpha' : 'conventional';
    const language = state.language;
    setBusy(true);
    state.statusKey = 'running';
    put('run-status', t('running'));
    try {
      if (typeof globalThis.FUNDED_ADVANTAGE?.run !== 'function') throw new Error(t('runtimeUnavailable'));
      const input = Object.fromEntries(['left', 'right'].map((side) => [side, { text: byId(`${side}-text`).value, format: byId(`${side}-format`).value }]));
      const pack = await globalThis.FUNDED_ADVANTAGE.run(input, language, state.method);
      if (!pack?.result?.summary || !Array.isArray(pack?.result?.artifacts) || pack.result.artifacts.some((artifact) => typeof artifact.name !== 'string' || typeof artifact.content !== 'string')) throw new Error('INVALID_WORKBENCH_PACK');
      state.pack = pack;
      state.reportLanguage = language;
      state.local = 'executed';
      state.statusKey = 'complete';
      byId('error-panel').hidden = true;
      renderResult();
      byId('result-panel').focus({ preventScroll: true });
      return pack;
    } catch (error) {
      state.pack = null;
      state.local = 'refused';
      state.statusKey = '';
      byId('error-panel').hidden = false;
      put('error-message', error?.message ?? String(error));
      renderResult();
      return null;
    } finally {
      setBusy(false);
      put('run-status', state.statusKey ? t(state.statusKey) : '');
      put('local-state', t(state.local));
    }
  }
  function setLanguage(language) {
    if (!['en', 'fr'].includes(language) || state.busy) return;
    state.language = language;
    document.documentElement.lang = language;
    document.title = language === 'fr' ? 'AGI ALPHA · L’avantage qui finance le prochain progrès' : 'AGI ALPHA · The Advantage That Funds the Next';
    for (const node of all('[data-i18n]')) node.textContent = t(node.dataset.i18n);
    for (const node of all('[data-language]')) node.setAttribute('aria-pressed', String(node.dataset.language === language));
    renderStudy(); renderScenarios(); renderResult();
    put('run-status', state.statusKey ? t(state.statusKey) : '');
  }

  byId('method').value = state.method;
  for (const node of all('[data-language]')) node.addEventListener('click', () => setLanguage(node.dataset.language));
  byId('run-button').addEventListener('click', run);
  byId('reset-button').addEventListener('click', () => resetSample(true));
  byId('method').addEventListener('change', () => { state.method = byId('method').value; invalidate(); });
  for (const side of ['left', 'right']) {
    byId(`${side}-text`).addEventListener('input', () => invalidate());
    byId(`${side}-format`).addEventListener('change', () => invalidate());
  }
  byId('scenario').addEventListener('change', () => {
    const index = Number(byId('scenario').value);
    state.scenarioIndex = Number.isInteger(index) && index >= 0 && index < scenarios.length ? index : 0;
    renderScenario();
  });
  for (const node of all('[data-artifact]')) node.addEventListener('click', () => artifactDownload(node.dataset.artifact));
  byId('download-pack').addEventListener('click', () => { if (state.pack && !state.busy) download('workbench-pack.json', 'application/json', JSON.stringify(state.pack, null, 2) + '\n'); });
  byId('download-evidence').addEventListener('click', () => download('funded-advantage-evidence.json', 'application/json', JSON.stringify({ summary: data.summary ?? null, economics: data.economics ?? null, assetHashes: data.assetHashes ?? null, sourceIdentity: sourceIdentity() }, null, 2) + '\n'));
  resetSample(false);
  if (typeof globalThis.FUNDED_ADVANTAGE?.run === 'function') state.local = 'ready';
  setLanguage('en');
  globalThis.FUNDED_ADVANTAGE_UI = Object.freeze({ run, setLanguage, resetSample,
    getState: () => ({ language: state.language, method: state.method, busy: state.busy, hasPack: Boolean(state.pack), reportLanguage: state.reportLanguage, scenarioIndex: state.scenarioIndex }),
    translationKeys: () => ({ en: Object.keys(strings.en).sort(), fr: Object.keys(strings.fr).sort() }),
  });
})();
