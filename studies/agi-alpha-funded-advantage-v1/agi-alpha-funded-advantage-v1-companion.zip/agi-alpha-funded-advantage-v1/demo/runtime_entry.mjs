// SPDX-License-Identifier: Apache-2.0
import { normalize as alphaNormalize } from '../candidates/alpha/normalize.mjs';
import { normalize as conventionalNormalize } from '../candidates/conventional/normalize.mjs';
import { deliver } from '../implementation/adapter.mjs';

const normalizers = Object.freeze({ alpha: alphaNormalize, conventional: conventionalNormalize });

export async function run(input, language = 'en', method = 'conventional') {
  if (!Object.prototype.hasOwnProperty.call(normalizers, method)) throw Error('UNKNOWN_RETAINED_METHOD');
  if (!['en', 'fr'].includes(language)) throw Error('LANGUAGE');
  const assetHash = globalThis.FUNDED_ADVANTAGE_ASSETS?.[method];
  const sourceHash = globalThis.FUNDED_ADVANTAGE_SOURCE;
  if (!/^[0-9a-f]{64}$/.test(assetHash ?? '') || !/^[0-9a-f]{64}$/.test(sourceHash ?? '')) throw Error('BUNDLED_SOURCE_IDENTITY');
  return deliver(normalizers[method], assetHash, input, {
    sourceHash, language,
    name: language === 'fr' ? 'Inventaire de livraison' : 'Release inventory',
  });
}

globalThis.FUNDED_ADVANTAGE = Object.freeze({ run });
