# SPDX-License-Identifier: Apache-2.0
import argparse
import base64
import csv
import hashlib
import io
import json
import re
import subprocess
import sys
import tempfile
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from oracle import differences, normalize


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def compact(value: Any, sort: bool = True) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=sort, separators=(',', ':'))


def domain_hash(domain: str, value: Any) -> str:
    return sha(('successor-omega/v1:' + domain + '\0' + compact(value)).encode('utf-8'))


def jobs_hash(domain: str, value: Any) -> str:
    return 'sha256:' + sha(compact({'hashFormat': 'successor-canonical-json-v1', 'domain': domain, 'object': value}).encode())


def raw_csv(rows: list[dict[str, str]]) -> str:
    return 'path,sha256\r\n' + ''.join(','.join('"' + row[key].replace('"', '""') + '"' for key in ('path', 'sha256')) + '\r\n' for row in rows)


def safe_cell(value: Any) -> str:
    value = str(value)
    return "'" + value if re.match(r'^(?:\s*[=+\-@]|[\t\r\n])', value) else value


def parsed_csv(text: str) -> list[list[str]]:
    return list(csv.reader(io.StringIO(text, newline=''), strict=True))


def audit(root: Path, results: Path) -> dict[str, Any]:
    started = time.perf_counter()
    checks = Counter()
    failures = []
    def check(condition: bool, label: str, context: str = '') -> None:
        checks[label] += 1
        if not condition:
            failures.append({'check': label, 'context': context})
    def read(path: str) -> Any:
        return json.loads((root / path).read_text())
    data = root / 'evidence/confirmation'
    manifest = read('evidence/confirmation/DATA_MANIFEST.json')
    for name, expected in manifest['files'].items():
        check(sha((data / name).read_bytes()) == expected, 'confirmation-file-hash', name)
    source = read('evidence/confirmation/source-records.json')
    check(sha((data / 'source-records.json').read_bytes()) == manifest['source_record_sha256'], 'source-record-hash')
    all_paths = []
    for repository in source['repositories']:
        check(len(repository['files']) == 32, 'source-path-count', repository['name'])
        for item in repository['files']:
            all_paths.append((repository['name'], item['path']))
            for side in ('old', 'new'):
                blob = item[side]
                if blob is None:
                    continue
                raw = base64.b64decode(blob['base64'], validate=True)
                check(sha(raw) == blob['sha256'], 'raw-source-sha256', item['path'] + ':' + side)
                check(len(raw) == blob['bytes'], 'raw-source-length', item['path'] + ':' + side)
                oid = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
                check(oid == blob['git_blob'], 'raw-git-blob-identity', item['path'] + ':' + side)
                check(blob['git_mode'] in ('100644', '100755'), 'ordinary-git-mode', item['path'])
    check(len(set(all_paths)) == 128, 'unique-source-paths')
    frozen = read('protocol/CANDIDATE_FREEZE.json')
    for name, expected in frozen['files'].items():
        check(sha((root / name).read_bytes()) == expected, 'frozen-source-hash', name)
    dependencies = read('protocol/DEPENDENCIES.json')
    for item in dependencies:
        check(sha((root / item['path']).read_bytes()) == item['sha256'], 'dependency-hash', item['path'])
        check((root / item['path']).stat().st_size == item['bytes'], 'dependency-size', item['path'])
    assets = {'alpha': sha((root / 'candidates/alpha/normalize.mjs').read_bytes()),
              'conventional': sha((root / 'candidates/conventional/normalize.mjs').read_bytes()),
              'ordinary': sha((root / 'evaluation/oracle.py').read_bytes())}
    source_hash = sha(compact({'dependencies': dependencies,
                              'adapter': sha((root / 'implementation/adapter.mjs').read_bytes()),
                              'methods': assets}, sort=False).encode())
    summary = json.loads((results / 'summary.json').read_text())
    check(summary['sourceHash'] == source_hash, 'execution-source-binding')
    cases = {case['id']: case for case in read('evidence/confirmation/cases.json')}
    outcomes = json.loads((results / 'outcomes.json').read_text())
    outcome_map = {(row['method'], row['caseId']): row for row in outcomes}
    check(len(cases) == 64 and len(outcomes) == 192 and len(outcome_map) == 192, 'primary-counts')
    cases_by_job = Counter(case['job_id'] for case in cases.values())
    check(len(cases_by_job) == 16 and set(cases_by_job.values()) == {4}, 'unique-job-and-repetition-counts')
    pack_files = sorted((results / 'packs').glob('*/*.json'))
    check(len(pack_files) == 192, 'pack-count')
    difference_fields = ['id', 'occurrence', 'action', 'key', 'kind', 'leftRow', 'rightRow', 'field', 'leftValue', 'rightValue']
    action_fields = ['action', 'exact_key', 'type', 'left_data_rows', 'right_data_rows', 'original_review_occurrences', 'next_step']
    artifact_names = {'inventory-report.md', 'normalized-inventories.json', 'complete-comparison.json', 'differences.csv', 'actions.csv', 'asset-identity.json'}
    for file in pack_files:
        method, case_id = file.parent.name, file.stem
        context = method + '/' + case_id
        case = cases[case_id]
        pack = json.loads(file.read_text())
        outcome = outcome_map[(method, case_id)]
        check(pack['spec']['inputs'] == {'left': case['left'], 'right': case['right']}, 'exact-raw-input-binding', context)
        expected = {side: normalize(case[side]['text'], case[side]['format'])['rows'] for side in ('left', 'right')}
        for side in ('left', 'right'):
            check(expected[side] == case['expected_' + side], 'independent-normalization', context + ':' + side)
        ev = pack['result']['evidence']
        check(ev['normalized'] == expected, 'delivered-normalized-inventories', context)
        truth = differences(expected['left'], expected['right'])
        check(truth == case['expected_differences'], 'independent-semantic-truth', context)
        comp = ev['comparison']
        observed = []
        for item in comp['differences']:
            left_value = json.loads(item['leftValue'])[1] if item['kind'] == 'missing_from_right' else item['leftValue']
            right_value = json.loads(item['rightValue'])[1] if item['kind'] == 'missing_from_left' else item['rightValue']
            observed.append({'path': item['key'], 'kind': item['kind'], 'left': left_value, 'right': right_value})
            for side in ('left', 'right'):
                index = item[side + 'Row']
                if index != '':
                    check(1 <= index <= len(expected[side]) and expected[side][index - 1]['path'] == item['key'], 'difference-row-lineage', context)
        observed.sort(key=lambda item: item['path'])
        check(observed == truth, 'complete-semantic-differences', context)
        check(len({item['id'] for item in comp['differences']}) == len(comp['differences']), 'unique-difference-identities', context)
        for side in ('left', 'right'):
            raw = raw_csv(expected[side]).encode()
            check(comp[side + 'Identity'] == {'sha256': sha(raw), 'bytes': len(raw)}, 'comparison-input-identity', context + ':' + side)
        left_keys = {row['path'] for row in expected['left']}
        right_keys = {row['path'] for row in expected['right']}
        conflicts = sum(item['kind'] == 'conflict' for item in truth)
        metrics = {'leftRows': len(expected['left']), 'rightRows': len(expected['right']),
                   'matchedPairs': len(left_keys & right_keys), 'unmatchedRows': len(left_keys ^ right_keys),
                   'unmatchedKeys': len(left_keys ^ right_keys), 'conflictingPairs': conflicts,
                   'fieldDifferences': conflicts, 'actionGroups': len(truth), 'evidenceReferences': len(truth),
                   'leftDuplicates': {'keys': 0, 'extraRows': 0}, 'rightDuplicates': {'keys': 0, 'extraRows': 0},
                   'comparedColumns': ['sha256'], 'unsharedLeft': [], 'unsharedRight': []}
        check(comp['metrics'] == metrics, 'all-comparison-metrics', context)
        resolution = comp['resolution']
        check(resolution['coverage'] == {'originalOccurrences': len(truth), 'coveredOccurrences': len(truth), 'complete': True, 'missing': [], 'duplicates': []}, 'evidence-coverage', context)
        actions = resolution['actions']
        check(len(actions) == len(truth) and {action['key'] for action in actions} == {item['path'] for item in truth}, 'action-semantic-coverage', context)
        occurrences = [occurrence for action in actions for occurrence in action['occurrences']]
        check(set(occurrences) == {item['occurrence'] for item in comp['differences']} and len(occurrences) == len(set(occurrences)), 'action-occurrence-coverage', context)
        for action in actions:
            expected_occurrences = [item['occurrence'] for item in comp['differences'] if item['action'] == action['id']]
            check(action['occurrences'] == expected_occurrences, 'action-difference-binding', context)
        artifacts = {item['name']: item for item in pack['result']['artifacts']}
        check(set(artifacts) == artifact_names and len(pack['result']['artifacts']) == 6, 'artifact-completeness', context)
        check(json.loads(artifacts['normalized-inventories.json']['content']) == expected, 'normalized-download', context)
        check(json.loads(artifacts['complete-comparison.json']['content']) == comp, 'comparison-download', context)
        check(parsed_csv(artifacts['differences.csv']['content']) == [difference_fields] + [[safe_cell(item[key]) for key in difference_fields] for item in comp['differences']], 'difference-csv-exact', context)
        expected_action_rows = [action_fields] + [[safe_cell(action['id']), safe_cell(action['key']), safe_cell(action['type']),
                                                  ';'.join(str(index + 1) for index in action['leftRows']),
                                                  ';'.join(str(index + 1) for index in action['rightRows']),
                                                  ';'.join(action['occurrences']), safe_cell(action['nextStep'])] for action in actions]
        check(parsed_csv(artifacts['actions.csv']['content']) == expected_action_rows, 'action-csv-exact', context)
        check(artifacts['actions.csv']['content'] == resolution['actionsCsv'], 'action-csv-evidence-binding', context)
        identity = json.loads(artifacts['asset-identity.json']['content'])
        check(identity['sha256'] == assets[method] and identity['authority'] == [] and identity['actualCollections'] is None, 'downloaded-asset-identity', context)
        check(ev['assetHash'] == assets[method] == outcome['assetHash'], 'executed-asset-identity', context)
        for artifact in artifacts.values():
            payload = {key: value for key, value in artifact.items() if key != 'digest'}
            check(domain_hash('workbench-artifact', payload) == artifact['digest'], 'artifact-hash', context + ':' + artifact['name'])
        body = {key: value for key, value in pack.items() if key != 'integrityDigest'}
        check(domain_hash('workbench-pack', body) == pack['integrityDigest'], 'pack-integrity', context)
        semantic = {key: value for key, value in pack['spec'].items() if key not in ('name', 'language')}
        check(domain_hash('workbench-mission', semantic) == pack['frozen']['missionDigest'], 'mission-digest', context)
        check(domain_hash('workbench-release', pack['frozen']) == pack['releaseDigest'], 'release-digest', context)
        check(pack['frozen']['sourceHash'] == source_hash and pack['frozen']['authority'] == [], 'pack-source-and-authority', context)
        check(pack['evaluation'] == {'scope': 'PUBLIC_LOCAL_EXECUTION', 'independentProof': False, 'admission': 'HOLD', 'authority': [], 'settlement': 'NOT_CONNECTED'}, 'execution-state-boundary', context)
        check(pack['economics']['computeCost'] is None and pack['economics']['humanMinutes'] is None and pack['economics']['allowanceIs'] == 'UNFUNDED', 'unknown-cost-boundary', context)
        check(ev['economicAdmission'] == 'HOLD_FULL_COST_AND_DEMAND_UNKNOWN', 'economic-hold', context)
        check(pack['chronicle'] == [{'kind': 'local-result', 'decision': pack['result']['decision'], 'missionDigest': pack['frozen']['missionDigest'], 'releaseDigest': pack['releaseDigest'], 'inheritedProof': False, 'inheritedAuthority': False}], 'chronicle-binding', context)
        compilation = pack['compilation']
        check(compilation['mode'] == 'SYNTHETIC_REHEARSAL' and compilation['authorityCreated'] == 'NONE' and compilation['signatureStatus'] == 'UNSIGNED_COMMITMENT', 'inert-job-compilation', context)
        check(len(compilation['graph']['nodes']) == 7 and len(compilation['executionOrder']) == 7 and all(node['state'] == 'DRAFT' for node in compilation['graph']['nodes']), 'seven-draft-packages-not-paid-jobs', context)
        check(compilation['budgetReservations']['reservedBaseUnits'] == '0' and compilation['budgetReservations']['limitBaseUnits'] == '0', 'zero-funded-job-budget', context)
        check(all(item['status'] == 'PLANNED_NOT_ACCEPTED' for item in compilation['coverage']) and all(item['status'] == 'REQUESTED_NOT_GRANTED' for item in compilation['capabilityRequests']), 'no-lifecycle-acceptance-inferred', context)
        check(jobs_hash('successor.constitution.v1', compilation['constitution']) == compilation['digest'], 'constitution-digest', context)
        graph = compilation['graph']
        check(jobs_hash('successor.job-graph.v1', {key: value for key, value in graph.items() if key != 'digest'}) == graph['digest'], 'job-graph-digest', context)
        for node in graph['nodes']:
            payload = {key: value for key, value in node.items() if key not in ('digest', 'sealed', 'signatureStatus', 'state')}
            check(jobs_hash('successor.work-order.v1', payload) == node['digest'], 'work-order-digest', context + ':' + node['family'])
        check(outcome['accepted'] and not outcome['incorrectAcceptance'] and outcome['error'] is None, 'recorded-acceptance', context)
        check(outcome['preparationMicros'] == ev['measured']['preparationMicros'] and outcome['comparisonMicros'] == ev['measured']['comparisonMicros'], 'timing-evidence-binding', context)
    refused = json.loads((results / 'refusals.json').read_text())
    valid = json.loads((results / 'valid-boundaries.json').read_text())
    expected_refusals = {item['id']: item for item in read('evidence/confirmation/refusals.json')}
    expected_valid = {item['id']: item for item in read('evidence/confirmation/valid-boundaries.json')}
    check(len(refused) == 72 and len({(item['method'], item['id']) for item in refused}) == 72, 'refusal-evaluation-count')
    check(len(valid) == 24 and len({(item['method'], item['id']) for item in valid}) == 24, 'valid-boundary-count')
    for item in refused:
        check(item['refused'] and item['expected'] == 'REFUSE' and item['error'] is not None and item['reason'] == expected_refusals[item['id']]['reason'], 'recorded-refusal', item['method'] + ':' + item['id'])
    for item in valid:
        truth = expected_valid[item['id']]
        check(item['passed'] and item['value'] == normalize(truth['text'], truth['format']) and item['error'] is None, 'recorded-valid-boundary', item['method'] + ':' + item['id'])
    for method, arm in summary['arms'].items():
        rows = [item for item in outcomes if item['method'] == method]
        check(arm['acceptedUniqueJobs'] == 16 and arm['acceptedEvaluations'] == 64 and arm['incorrectAcceptances'] == 0, 'summary-acceptance', method)
        check(arm['totalEndToEndMicros'] == sum(item['endToEndMicros'] for item in rows), 'summary-timing-sum', method)
        check(arm['medianEndToEndMicros'] == sorted(item['endToEndMicros'] for item in rows)[32], 'summary-timing-median', method)
        check(arm['assetHash'] == assets[method] and arm['observedEconomicAdmission'] == 'HOLD_FULL_COST_AND_DEMAND_UNKNOWN', 'summary-asset-and-hold', method)
    with tempfile.TemporaryDirectory(prefix='funded-advantage-regeneration-') as directory:
        command = [sys.executable, str(root / 'evaluation/generate.py'), '--sources', str(data / 'source-records.json'), '--output', directory]
        process = subprocess.run(command, capture_output=True, text=True)
        check(process.returncode == 0, 'offline-data-regeneration-command', process.stderr[:500])
        for name, expected in manifest['files'].items():
            check(sha((Path(directory) / name).read_bytes()) == expected, 'offline-regenerated-file-hash', name)
        check((Path(directory) / 'DATA_MANIFEST.json').read_bytes() == (data / 'DATA_MANIFEST.json').read_bytes(), 'offline-regenerated-manifest')
    scope_path = root / 'evidence/WRAPPER_SCOPE_DIAGNOSTICS.json'
    scope = json.loads(scope_path.read_text()) if scope_path.exists() else None
    if scope:
        for diagnostic in scope['diagnostics']:
            check(diagnostic['correct'] and diagnostic['actual'] == diagnostic['expected'], 'post-primary-wrapper-scope', diagnostic['id'])
    elapsed = time.perf_counter() - started
    return {'schema': 'funded-advantage-independent-audit/v1', 'completed_at_utc': datetime.now(timezone.utc).isoformat(),
            'passed': not failures, 'assertions': sum(checks.values()), 'check_groups': dict(sorted(checks.items())), 'failures': failures,
            'unique_jobs': 16, 'source_paths': 128, 'primary_method_evaluations': 192, 'workbench_packs': len(pack_files),
            'refusal_method_evaluations': 72, 'secondary_valid_method_evaluations': 24,
            'elapsed_seconds': elapsed, 'sourceHash': source_hash, 'assets': assets,
            'audit_source_sha256': sha(Path(__file__).read_bytes()),
            'results_summary_sha256': sha((results / 'summary.json').read_bytes()),
            'independence': 'Same-session separate evaluator; independent Python recomputation, not external institutional qualification.',
            'limitations': ['Recorded refusal outcomes are audited; this audit does not independently rerun candidate parsers.',
                            'The source archive verifies raw byte identities and Git blob identities; original repository membership was observed by the source collector.',
                            'The unchanged Jobs compilation retains synthetic rehearsal, aggregation-oriented hard-gate and comparator wording. These inert templates are not purpose-specific Jobs qualification.',
                            'Intake parser limits exceed downstream guide, artifact and Workbench envelope limits. The post-primary wrapper diagnostics preserve explicit refusals.',
                            'The declared sourceHash covers adapter, methods and vendored dependencies; the runner/cache orchestration and data are separately committed, not included in that digest.',
                            'Neither source hashes nor local acceptance establish production security, operator approval, demand, full monetary cost or profitable reinvestment.']}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument('--results', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    report = audit(root, args.results.resolve() if args.results else root / 'evidence/results')
    target = args.output or root / 'evidence/AUDIT.json'
    target.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(report, ensure_ascii=False, indent=2))
    if not report['passed']:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
