# SPDX-License-Identifier: Apache-2.0
import csv
import io
import json
import math
import re
import sys
import time
from typing import Any

MAX_INPUT = 1000000
MAX_SCALAR = 64000
MAX_ROWS = 128
MAX_DEPTH = 16


def reject(message: str) -> None:
    raise ValueError(message)


def scalar(value: str) -> str:
    try:
        size = len(value.encode('utf-8'))
    except UnicodeError:
        reject('UNICODE_SCALAR')
    if size > MAX_SCALAR:
        reject('SCALAR_LIMIT')
    return value


def path_value(value: Any) -> str:
    if not isinstance(value, str) or not value:
        reject('PATH')
    scalar(value)
    if value.startswith('/') or '\\' in value or re.search(r'[\x00-\x1f\x7f-\x9f]', value):
        reject('PATH')
    if re.match(r'^[A-Za-z][A-Za-z0-9+.-]*:', value):
        reject('PATH_PREFIX')
    if any(part in ('', '.', '..') for part in value.split('/')):
        reject('PATH_SEGMENT')
    return value


def digest_value(value: Any) -> str:
    if not isinstance(value, str) or re.fullmatch(r'[0-9a-fA-F]{64}', value) is None:
        reject('SHA256')
    return value.lower()


def strict_pairs(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    out = {}
    for key, value in pairs:
        if key in out:
            reject('JSON_DUPLICATE_KEY')
        out[key] = value
    return out


def finite_number(raw: str) -> float:
    if len(raw.encode('utf-8')) > MAX_SCALAR:
        reject('SCALAR_LIMIT')
    value = float(raw)
    if not math.isfinite(value):
        reject('JSON_NUMBER')
    return value


def inspect_json(value: Any, depth: int = 0) -> None:
    if depth > MAX_DEPTH:
        reject('JSON_DEPTH')
    if isinstance(value, str):
        scalar(value)
    elif isinstance(value, dict):
        for key, item in value.items():
            scalar(key)
            inspect_json(item, depth + 1)
    elif isinstance(value, list):
        for item in value:
            inspect_json(item, depth + 1)


def from_json(text: str) -> list[tuple[Any, Any]]:
    value = json.loads(text, object_pairs_hook=strict_pairs, parse_float=finite_number,
                       parse_int=finite_number, parse_constant=lambda _: reject('JSON_NUMBER'))
    if not isinstance(value, dict):
        reject('JSON_ROOT')
    inspect_json(value)
    roots = [key for key in ('sources', 'files', 'authoritativeArtifacts') if key in value]
    if len(roots) != 1:
        reject('JSON_INVENTORY_ROOT')
    base = value.get('pathBase', '')
    if not isinstance(base, str):
        reject('PATH_BASE')
    if base.startswith('/'):
        reject('PATH_BASE')
    if base.endswith('/'):
        base = base[:-1]
    if base:
        path_value(base)
    key = roots[0]
    data = value[key]
    records = []
    if key == 'sources':
        if not isinstance(data, dict):
            reject('JSON_SOURCES')
        records = list(data.items())
    elif key == 'files' and isinstance(data, dict):
        for name, item in data.items():
            if not isinstance(item, dict) or 'sha256' not in item:
                reject('JSON_FILE_RECORD')
            records.append((name, item['sha256']))
    elif isinstance(data, list):
        for item in data:
            if not isinstance(item, dict) or 'path' not in item or 'sha256' not in item:
                reject('JSON_FILE_RECORD')
            records.append((item['path'], item['sha256']))
    else:
        reject('JSON_INVENTORY_TYPE')
    return [((base + '/' if base else '') + path_value(name), digest) for name, digest in records]


def validate_csv_quoting(text: str) -> None:
    mode = 'start'
    index = 0
    while index < len(text):
        char = text[index]
        if mode == 'quoted':
            if char == '"':
                if index + 1 < len(text) and text[index + 1] == '"':
                    index += 1
                else:
                    mode = 'closed'
        elif char in ',\r\n':
            mode = 'start'
        elif char == '"':
            if mode != 'start':
                reject('CSV_QUOTING')
            mode = 'quoted'
        elif mode == 'closed':
            reject('CSV_QUOTING')
        else:
            mode = 'bare'
        index += 1
    if mode == 'quoted':
        reject('CSV_QUOTING')


def from_csv(text: str) -> list[tuple[Any, Any]]:
    validate_csv_quoting(text)
    parsed = list(csv.reader(io.StringIO(text, newline=''), strict=True))
    if not parsed or parsed[0] != ['path', 'sha256']:
        reject('CSV_HEADER')
    if any(len(row) != 2 for row in parsed[1:]):
        reject('CSV_ROW')
    return [(row[0], row[1]) for row in parsed[1:]]


def from_sums(text: str) -> list[tuple[Any, Any]]:
    if text == '':
        return []
    parts = re.split(r'\r\n|\n', text)
    if parts[-1] == '':
        parts.pop()
    records = []
    for line in parts:
        match = re.fullmatch(r'([0-9a-fA-F]{64}) [ *](.+)', line)
        if not match:
            reject('SUMS_LINE')
        records.append((match[2], match[1]))
    return records


PARSERS = {'json': from_json, 'csv': from_csv, 'sha256sum': from_sums}


def normalize(text: str, format: str = 'auto') -> dict[str, Any]:
    if not isinstance(text, str):
        reject('INPUT_TYPE')
    try:
        size = len(text.encode('utf-8'))
    except UnicodeError:
        reject('UNICODE_SCALAR')
    if size > MAX_INPUT:
        reject('INPUT_LIMIT')
    if format not in ('auto', *PARSERS):
        reject('FORMAT')
    accepted = []
    for family in (PARSERS if format == 'auto' else [format]):
        if format == 'auto' and text == '':
            continue
        try:
            records = PARSERS[family](text)
            if len(records) > MAX_ROWS:
                reject('ROW_LIMIT')
            seen = set()
            rows = []
            for name, digest in records:
                path = path_value(name)
                sha = digest_value(digest)
                if path in seen:
                    reject('DUPLICATE_PATH')
                seen.add(path)
                rows.append({'path': path, 'sha256': sha})
            rows.sort(key=lambda row: row['path'])
            accepted.append({'format': family, 'rows': rows})
        except (ValueError, TypeError, OverflowError, RecursionError, csv.Error):
            if format != 'auto':
                raise
    if len(accepted) != 1:
        reject('FORMAT_UNRECOGNIZED_OR_AMBIGUOUS')
    return accepted[0]


def differences(left: list[dict[str, str]], right: list[dict[str, str]]) -> list[dict[str, str]]:
    a = {row['path']: row['sha256'] for row in left}
    b = {row['path']: row['sha256'] for row in right}
    result = []
    for path in sorted(a.keys() | b.keys()):
        if path not in b:
            result.append({'path': path, 'kind': 'missing_from_right', 'left': a[path], 'right': ''})
        elif path not in a:
            result.append({'path': path, 'kind': 'missing_from_left', 'left': '', 'right': b[path]})
        elif a[path] != b[path]:
            result.append({'path': path, 'kind': 'conflict', 'left': a[path], 'right': b[path]})
    return result


def main() -> None:
    for line in sys.stdin:
        started = time.perf_counter_ns()
        try:
            request = json.loads(line)
            result = normalize(request['text'], request.get('format', 'auto'))
            response = {'ok': True, 'value': result}
        except Exception as exc:
            response = {'ok': False, 'error': type(exc).__name__ + ':' + str(exc)}
        response['elapsed_ns'] = time.perf_counter_ns() - started
        print(json.dumps(response, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
