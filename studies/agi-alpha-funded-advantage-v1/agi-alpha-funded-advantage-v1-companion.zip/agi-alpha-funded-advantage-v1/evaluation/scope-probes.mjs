// SPDX-License-Identifier: Apache-2.0
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {normalize} from '../candidates/alpha/normalize.mjs';
import {deliver,rawCsv} from '../implementation/adapter.mjs';
const root=path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const arguments_=process.argv.slice(2);
let output=path.join(root,'evidence/WRAPPER_SCOPE_DIAGNOSTICS.json');
let results=path.join(root,'evidence/results/summary.json');
for(let index=0;index<arguments_.length;index+=2){
  const option=arguments_[index],value=arguments_[index+1];
  if(!['--output','--results'].includes(option)||!value||!path.isAbsolute(value))throw Error('Usage: node evaluation/scope-probes.mjs [--output /absolute/report.json] [--results /absolute/summary.json]');
  if(option==='--output')output=value;
  else results=value;
}
const sourceHash=JSON.parse(fs.readFileSync(results,'utf8')).sourceHash;
const assetHash=createHash('sha256').update(fs.readFileSync(path.join(root,'candidates/alpha/normalize.mjs'))).digest('hex');
const h='a'.repeat(64);
const documents=[
  {id:'D01',name:'valid intake path exceeds existing guide cell limit',sources:{['x'.repeat(4097)]:h},expected:'REFUSE'},
  {id:'D02',name:'valid intake rows exceed existing guide CSV byte limit',sources:Object.fromEntries(Array.from({length:128},(_,i)=>['p'+String(i).padStart(3,'0')+'/'+'x'.repeat(2000),h])),expected:'REFUSE'},
  {id:'D03',name:'empty inventories produce an empty complete report',sources:{},expected:'ACCEPT'},
  {id:'D04',name:'valid guide input exceeds existing individual artifact limit',sources:Object.fromEntries(Array.from({length:64},(_,i)=>['p'+String(i).padStart(3,'0')+'/'+'x'.repeat(2500),h])),expected:'REFUSE'},
];
const diagnostics=[];
for(const item of documents){
  const started=performance.now(),text=JSON.stringify({sources:item.sources}),prepared=normalize(text,'json');
  let error=null,pack=null;
  try{pack=await deliver(normalize,assetHash,{left:{text,format:'json'},right:{text,format:'json'}},{sourceHash,name:'Scope '+item.id});}catch(e){error=String(e.message??e);}
  const actual=pack?'ACCEPT':'REFUSE';
  const correct=actual===item.expected && (item.id!=='D03'||pack.result.summary.leftRows===0&&pack.result.summary.rightRows===0&&pack.result.summary.actionGroups===0);
  diagnostics.push({id:item.id,name:item.name,role:'post-primary wrapper-scope diagnostic, not a new primary job',
    inputSha256:createHash('sha256').update(text).digest('hex'),inputBytes:Buffer.byteLength(text),
    normalizedRows:prepared.rows.length,normalizedCsvBytes:Buffer.byteLength(rawCsv(prepared.rows)),
    parserAccepted:true,expected:item.expected,actual,error,correct,elapsedMicros:Math.round((performance.now()-started)*1000),
    packIntegrity:pack?.integrityDigest??null});
}
const report={schema:'funded-advantage-wrapper-scope/v1',at:new Date().toISOString(),assetHash,sourceHash,
  diagnostics,passed:diagnostics.filter(x=>x.correct).length,total:diagnostics.length,
  note:'Candidates and primary outcomes remain unchanged. These diagnostic refusals demonstrate downstream limits, not complete intake-to-delivery coverage.'};
fs.writeFileSync(output,JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
if(report.passed!==report.total)process.exitCode=1;
