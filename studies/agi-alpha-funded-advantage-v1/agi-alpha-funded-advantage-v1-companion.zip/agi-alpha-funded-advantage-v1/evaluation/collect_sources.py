# SPDX-License-Identifier: Apache-2.0
import argparse
import base64
import hashlib
import json
import subprocess
from pathlib import Path
from typing import Any


def git(repository: Path, *arguments: str) -> bytes:
    return subprocess.run(['git', '-C', str(repository), '--no-pager', *arguments], check=True,
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE).stdout


def tree(repository: Path, commit: str) -> dict[str, tuple[str, str]]:
    result = {}
    for record in git(repository, 'ls-tree', '-r', '-z', commit).split(b'\0'):
        if not record:
            continue
        metadata, name = record.split(b'\t', 1)
        mode, kind, oid = metadata.decode('ascii').split()
        if mode in ('100644', '100755') and kind == 'blob':
            try:
                path = name.decode('utf-8')
            except UnicodeError:
                continue
            result[path] = (oid, mode)
    return result


def blob_record(repository: Path, sha: str, mode: str) -> dict[str, Any] | None:
    size = int(git(repository, 'cat-file', '-s', sha))
    if size > 100000:
        return None
    raw = git(repository, 'cat-file', 'blob', sha)
    try:
        text = raw.decode('utf-8')
    except UnicodeError:
        return None
    if '\x00' in text:
        return None
    return {'git_blob': sha, 'git_mode': mode, 'sha256': hashlib.sha256(raw).hexdigest(),
            'bytes': len(raw), 'base64': base64.b64encode(raw).decode('ascii')}


def collect(specification: Path, output: Path) -> dict[str, Any]:
    settings = json.loads(specification.read_text())
    repositories = []
    for request in settings:
        repository = Path(request['local_path'])
        current = request['commit']
        headers = git(repository, 'cat-file', '-p', current).split(b'\n\n', 1)[0].decode('ascii')
        parent = next(line.split()[1] for line in headers.splitlines() if line.startswith('parent '))
        old_tree = tree(repository, parent)
        new_tree = tree(repository, current)
        files = []
        excluded = []
        for path in sorted(old_tree.keys() | new_tree.keys()):
            records = {}
            skip = False
            for side, source in [('old', old_tree), ('new', new_tree)]:
                record = blob_record(repository, *source[path]) if path in source else None
                if path in source and record is None:
                    skip = True
                    break
                records[side] = record
            if skip:
                excluded.append(path)
                continue
            files.append({'path': path, **records})
            if len(files) == 32:
                break
        if len(files) != 32:
            raise ValueError('Need 32 qualifying paths for ' + request['name'])
        repositories.append({'name': request['name'], 'repository_url': request['url'],
                             'old_commit': parent, 'new_commit': current,
                             'excluded_before_32': excluded, 'files': files})
    document = {'schema': 'funded-advantage-source-bytes/v1',
                'sampling': 'First 32 lexicographically sorted ordinary UTF-8 text paths from current/first-parent union; <=100000 bytes per blob, no NUL; paths partitioned round-robin into four disjoint subsets per repo.',
                'independence': 'Collected after candidate freeze; evaluation is same-session role separation.',
                'repositories': repositories}
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(document, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    return {'source_record': str(output), 'sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
            'repositories': [{'name': r['name'], 'old_commit': r['old_commit'], 'new_commit': r['new_commit'],
                              'paths': len(r['files'])} for r in repositories]}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--repositories', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(collect(args.repositories, args.output), indent=2))


if __name__ == '__main__':
    main()
