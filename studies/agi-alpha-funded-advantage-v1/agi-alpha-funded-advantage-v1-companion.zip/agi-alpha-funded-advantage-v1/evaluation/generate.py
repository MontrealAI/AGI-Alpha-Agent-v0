# SPDX-License-Identifier: Apache-2.0
import argparse
import base64
import csv
import hashlib
import io
import json
from pathlib import Path
from typing import Any

from oracle import differences, normalize


def dump(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def csv_text(rows: list[dict[str, str]]) -> str:
    stream = io.StringIO(newline='')
    writer = csv.writer(stream, lineterminator='\r\n')
    writer.writerow(['path', 'sha256'])
    writer.writerows((row['path'], row['sha256']) for row in rows)
    return stream.getvalue()


def render(rows: list[dict[str, str]], repo: str, family: int, repetition: int) -> tuple[str, str]:
    if repetition in (2, 3):
        if repetition == 2:
            return csv_text(rows), 'csv'
        return ''.join(row['sha256'].upper() + (' *' if index % 2 else '  ') + row['path'] + '\n'
                       for index, row in enumerate(reversed(rows))), 'sha256sum'
    local = [{'path': row['path'][len(repo) + 1:], 'sha256': row['sha256']} for row in rows]
    if family == 0:
        value = {'sources': {row['path']: row['sha256'] for row in local}}
    elif family == 1:
        value = {'files': {row['path']: {'sha256': row['sha256'], 'note': 'Byte lengths are preserved in source-records.json'} for row in local}}
    elif family == 2:
        value = {'files': [dict(row, role='declared-public-source') for row in local]}
    else:
        value = {'authoritativeArtifacts': [dict(row, kind='declared-public-source') for row in local]}
    value['pathBase'] = repo + ('/' if repetition == 1 else '')
    value['schema'] = 'funded-advantage-derived-inventory/v1'
    value['provenance'] = 'Evaluator-derived from pinned public Git bytes; not a repository release attestation.'
    if repetition == 1:
        value = {'pathBase': repo, 'sources': {row['path']: row['sha256'].upper() for row in reversed(local)},
                 'metadata': {'sequence': 1.25, 'note': 'Whitespace/key order variation of same underlying job'}}
    return json.dumps(value, ensure_ascii=False, indent=2 if repetition == 0 else 4) + '\n', 'json'


def refusal_probes() -> list[dict[str, Any]]:
    h = 'ab' * 32
    def j(value: Any) -> str:
        return json.dumps(value, ensure_ascii=False)
    definitions = [
        ('multiple-roots', j({'sources': {'a': h}, 'files': []}), 'json'),
        ('duplicate-json-metadata', '{"sources":{"a":"' + h + '"},"n":1,"n":2}', 'json'),
        ('duplicate-json-inventory-key', '{"sources":{"a":"' + h + '","a":"' + h + '"}}', 'json'),
        ('duplicate-final-path', j({'files': [{'path': 'a', 'sha256': h}, {'path': 'a', 'sha256': h}]}), 'json'),
        ('sha1-is-not-sha256', j({'files': [{'path': 'a', 'gitBlob': 'a' * 40}]}), 'json'),
        ('absolute-path', j({'sources': {'/a': h}}), 'json'),
        ('parent-traversal', j({'sources': {'a/../b': h}}), 'json'),
        ('empty-segment', j({'sources': {'a//b': h}}), 'json'),
        ('dot-segment', j({'sources': {'./a': h}}), 'json'),
        ('backslash', j({'sources': {'a\\b': h}}), 'json'),
        ('drive-prefix', j({'sources': {'C:/a': h}}), 'json'),
        ('url-prefix', j({'sources': {'https://example.invalid/a': h}}), 'json'),
        ('control-in-path', j({'sources': {'a\tb': h}}), 'json'),
        ('invalid-hex', j({'sources': {'a': 'g' * 64}}), 'json'),
        ('hash-type', j({'sources': {'a': 123}}), 'json'),
        ('csv-extra-column', 'path,sha256,bytes\na,' + h + ',0\n', 'csv'),
        ('csv-unclosed-quote', 'path,sha256\n"a,' + h + '\n', 'csv'),
        ('sums-gnu-escape', '\\' + h + '  a\\nb\n', 'sha256sum'),
        ('sums-one-space', h + ' a\n', 'sha256sum'),
        ('row-limit', j({'sources': {'path-' + str(i): h for i in range(129)}}), 'json'),
        ('scalar-limit', j({'sources': {}, 'metadata': 'x' * 64001}), 'json'),
        ('depth-limit', '{"sources":{},"m":' + '[' * 17 + '0' + ']' * 17 + '}', 'json'),
        ('input-limit', '{"sources":{}}' + ' ' * 1000000, 'json'),
        ('auto-empty', '', 'auto'),
    ]
    out = []
    for index, (reason, text, fmt) in enumerate(definitions, 1):
        try:
            normalize(text, fmt)
        except Exception as exc:
            out.append({'id': 'R' + str(index).zfill(2), 'reason': reason, 'text': text, 'format': fmt,
                        'expected': 'REFUSE', 'oracle_error': type(exc).__name__ + ':' + str(exc)})
        else:
            raise AssertionError('Refusal definition accepted: ' + reason)
    return out


def valid_boundaries() -> list[dict[str, Any]]:
    h = 'aB' * 32
    def j(value: Any) -> str:
        return json.dumps(value, ensure_ascii=False)
    definitions = [
        ('unicode-codepoints-and-no-normalization', j({'sources': {name: h for name in ['\ue000', '\U00010000', 'é', 'e\u0301']}}), 'auto'),
        ('ordinary-object-property-names', j({'sources': {name: h for name in ['__proto__', 'constructor', 'hasOwnProperty']}}), 'json'),
        ('quoted-comma-quote-space-paths', csv_text([{'path': name, 'sha256': h} for name in ['a,b', 'a"b', ' leading', 'trailing ']]), 'auto'),
        ('exact-case-and-leading-trailing-spaces', j({'sources': {name: h for name in [' A', 'a ', 'A', 'a']}}), 'json'),
        ('empty-json-inventory', '{"sources":{}}', 'auto'),
        ('empty-quoted-csv', '"path","sha256"\r\n', 'auto'),
        ('empty-explicit-sums', '', 'sha256sum'),
        ('base-and-finite-number-metadata', j({'files': [{'path': 'évidence/a.txt', 'sha256': h, 'bytes': 1.25}], 'pathBase': 'docs/', 'n': -125.5}), 'auto'),
    ]
    return [{'id': 'V' + str(index).zfill(2), 'reason': reason, 'text': text, 'format': fmt,
             'expected': normalize(text, fmt), 'role': 'pre-outcome-secondary-valid-boundary-not-real-job'}
            for index, (reason, text, fmt) in enumerate(definitions, 1)]


def generate(source_record: Path, output: Path) -> dict[str, Any]:
    source = json.loads(source_record.read_text())
    cases = []
    jobs = []
    for family, repository in enumerate(source['repositories']):
        repo = repository['name']
        for subset in range(4):
            files = [item for index, item in enumerate(repository['files']) if index % 4 == subset]
            left = []
            right = []
            for item in files:
                for side, rows in [('old', left), ('new', right)]:
                    blob = item[side]
                    if blob is None:
                        continue
                    raw = base64.b64decode(blob['base64'], validate=True)
                    observed = hashlib.sha256(raw).hexdigest()
                    if observed != blob['sha256'] or len(raw) != blob['bytes']:
                        raise AssertionError('Source byte identity mismatch')
                    rows.append({'path': repo + '/' + item['path'], 'sha256': observed})
            left.sort(key=lambda row: row['path'])
            right.sort(key=lambda row: row['path'])
            identifier = 'J' + str(family * 4 + subset + 1).zfill(2)
            expected = differences(left, right)
            jobs.append({'id': identifier, 'repository': repo, 'old_commit': repository['old_commit'],
                         'new_commit': repository['new_commit'], 'paths': [item['path'] for item in files],
                         'left_rows': left, 'right_rows': right, 'differences': expected,
                         'source_kind': 'public-committed-source-subset', 'customer_demand': 'NOT_OBSERVED'})
            for repetition in range(4):
                left_text, fmt = render(left, repo, family, repetition)
                right_text, _ = render(right, repo, family, repetition)
                left_parsed = normalize(left_text, fmt)['rows']
                right_parsed = normalize(right_text, fmt)['rows']
                if left_parsed != left or right_parsed != right:
                    raise AssertionError('Generated representation differs from committed bytes')
                cases.append({'id': identifier + '-V' + str(repetition + 1), 'job_id': identifier,
                              'representation': ['observed-native-shape-json', 'canonical-json-whitespace', 'csv', 'sha256sum'][repetition],
                              'left': {'text': left_text, 'format': fmt}, 'right': {'text': right_text, 'format': fmt},
                              'expected_left': left, 'expected_right': right, 'expected_differences': expected})
    refusals = refusal_probes()
    dump(output / 'jobs.json', jobs)
    dump(output / 'cases.json', cases)
    dump(output / 'refusals.json', refusals)
    dump(output / 'valid-boundaries.json', valid_boundaries())
    report = {'schema': 'funded-advantage-confirmation-data/v1', 'source_record_sha256': hashlib.sha256(source_record.read_bytes()).hexdigest(),
              'unique_jobs': len(jobs), 'representations_per_job': 4, 'accepted_case_evaluations_per_arm': len(cases),
              'refusal_inputs': len(refusals), 'secondary_valid_boundary_inputs': 8, 'unique_source_paths': sum(len(job['paths']) for job in jobs),
              'semantic_difference_occurrences': sum(len(job['differences']) for job in jobs),
              'files': {name: hashlib.sha256((output / name).read_bytes()).hexdigest()
                        for name in ('jobs.json', 'cases.json', 'refusals.json', 'valid-boundaries.json')},
              'note': 'Generated only after both builders freeze. Same-session separated evaluator; no external institutional independence.'}
    dump(output / 'DATA_MANIFEST.json', report)
    return report


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--sources', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    arguments = parser.parse_args()
    print(json.dumps(generate(arguments.sources, arguments.output), indent=2))


if __name__ == '__main__':
    main()
