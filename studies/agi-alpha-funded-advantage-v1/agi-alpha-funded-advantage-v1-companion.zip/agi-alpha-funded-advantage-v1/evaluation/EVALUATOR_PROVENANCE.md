# Separate evaluator and ordinary specialist

The evaluator was a same-session model-assisted role, separate from both candidate
builders. It did not read their source or confirmation outcomes when writing the
oracle, generator and source collector. This is procedural separation, not an
external laboratory or person. The ordinary comparison uses this evaluator-authored
standard-library interpreter and fixed per-format parser registry. It is not an
unmodified pre-existing Alpha capability. Its adoption and authoring costs must
remain in the study accounting.

## Work record before confirmation

- Read the frozen contract and the repository contributor guide.
- Requested shared clarification of format labels, depth, Unicode/control bounds,
  scalar limits, finite JSON numbers and empty input behavior. The coordinator
  supplied the same clarification to both builders before their source freeze.
- Implemented independent JSON duplicate detection, CSV quoting validation,
  SHA256SUMS parsing and exact path/hash normalization.
- Reused Python's standard `json`, `csv`, `hashlib`, `subprocess` and byte encoding
  primitives. This is conventional software construction, not an invented method.
- Ran seven infrastructure probes covering the three input formats, explicit and
  automatic empty input, invalid CSV quoting and an absolute path base. These
  are development checks, not withheld confirmation jobs.
- Compiled all three modules with Python's `py_compile`.
- Built a collector for the first 32 eligible lexical paths per repository and a
  deterministic four-representation generator. Neither confirmation collection
  nor generation began while either candidate was still unfrozen.

First oracle source write: 2026-10-25T23:53:16.807501Z, from filesystem birthtime.
This is not the beginning of planning or model inference. Full authoring duration,
token counts, model billing and attributable human effort were not exposed and
remain unknown. File-write intervals and process timings are lower-bound activity
records, not complete monetary costs.

The source collector reads immutable Git objects and does not execute inspected
source. Its raw-byte archive enables offline data regeneration without repository
or network access. The confirmation generator checks every stored SHA-256 and
length before deriving any expected inventory. JSON native-shape representations
are evaluator-generated; they are not original release attestations. Ordinary
Git object IDs are retained separately and are never treated as SHA-256 digests.
