# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import hashlib, json, re, shutil, subprocess

ROOT = Path(__file__).resolve().parents[3]
STUDY = Path(__file__).resolve().parents[1]

def main():
    pending = ['examples/successor-workbench/engine.mjs', 'examples/ti-guide/guide.mjs']
    seen = set()
    while pending:
        name = pending.pop()
        if name in seen:
            continue
        seen.add(name)
        source = ROOT / name
        text = source.read_text()
        target = STUDY / 'vendor' / 'alpha' / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        for relative in re.findall(r'^import[^\n;]*?[\'\"]([^\'\"]+)[\'\"]', text, re.M):
            if relative.startswith('.'):
                pending.append(str((source.parent / relative).resolve().relative_to(ROOT)))
    shared = STUDY / 'vendor' / 'shared'
    shared.mkdir(parents=True, exist_ok=True)
    for name in ['automated-costs.mjs', 'shadow-ledger.mjs']:
        content = subprocess.check_output(['git', 'show', f'origin/integration:examples/successor-alpha/{name}'], cwd=ROOT)
        (shared / name).write_bytes(content)
    shutil.copyfile(ROOT / 'LICENSE', STUDY / 'vendor' / 'ALPHA-LICENSE')
    records = []
    for path in sorted((STUDY / 'vendor').rglob('*')):
        if path.is_file():
            records.append({'path':str(path.relative_to(STUDY)), 'sha256':hashlib.sha256(path.read_bytes()).hexdigest(), 'bytes':path.stat().st_size, 'source': 'e2503611666ee170266cbce51dc250492285f2e8' if '/shared/' in str(path) else '95d1e97d4d1c0aaebd592767fc5e5d2da56f6aa7'})
    (STUDY / 'protocol' / 'DEPENDENCIES.json').write_text(json.dumps(records, indent=2)+'\n')
    print(json.dumps({'vendoredFiles':len(records),'bytes':sum(x['bytes'] for x in records)}))

if __name__ == '__main__':
    main()
