// SPDX-License-Identifier: Apache-2.0
import {createWorkbench} from '../vendor/alpha/examples/successor-workbench/engine.mjs';
import * as guide from '../vendor/alpha/examples/ti-guide/guide.mjs';

const exact = (v, keys) => v && typeof v === 'object' && !Array.isArray(v)
  && Object.keys(v).sort().join('|') === [...keys].sort().join('|');
const json = (name, data) => ({name, type:'application/json', content:JSON.stringify(data,null,2)+'\n'});
const rawCsv = rows => ['path,sha256', ...rows.map(row => [row.path,row.sha256]
  .map(value => '"'+value.replaceAll('"','""')+'"').join(','))].join('\r\n')+'\r\n';
const clock = () => globalThis.performance.now();

export function createIntakeAdapter(normalize, assetHash, language = 'en') {
  if (typeof normalize !== 'function' || !/^[0-9a-f]{64}$/.test(assetHash)) throw Error('ASSET_IDENTITY');
  return {
    manifest:{id:'release-inventory-intake',version:1,
      en:'Check release inventories',fr:'Vérifier les inventaires de livraison',
      scope:'Compare exact declared SHA-256 inventories from bounded public or synthetic documents. No source execution or security certification.',
      artifact:'inventory-report.md'},
    validate(input) {
      if (!exact(input,['left','right'])) throw Error('INPUT_FIELDS');
      for (const side of [input.left,input.right]) {
        if (!exact(side,['text','format']) || typeof side.text !== 'string'
          || new TextEncoder().encode(side.text).length > 1000000
          || !['auto','json','csv','sha256sum'].includes(side.format)) throw Error('INPUT_BOUND');
      }
    },
    async execute(input,checkpoint) {
      await checkpoint('preparing inventories');
      const prepStart = clock();
      const left = await normalize(input.left.text,input.left.format);
      const right = await normalize(input.right.text,input.right.format);
      const preparationMicros = Math.round((clock()-prepStart)*1000);
      const normalized = {left:left.rows,right:right.rows};
      const comparisonInput = {leftCsv:rawCsv(left.rows),rightCsv:rawCsv(right.rows),leftKey:'path',rightKey:'path'};
      await checkpoint('comparing exact identities');
      const executionStart = clock();
      const comparison = await guide.compute(comparisonInput);
      const comparisonMicros = Math.round((clock()-executionStart)*1000);
      const fr = language === 'fr';
      const lines = [fr?'# Inventaire de livraison — résultat':'# Release inventory — result',
        '', `${fr?'Fichiers déclarés':'Declared files'}: ${left.rows.length} / ${right.rows.length}.`,
        `${fr?'Différences de champs':'Field differences'}: ${comparison.metrics.fieldDifferences}.`,
        `${fr?'Entrées absentes':'Missing entries'}: ${comparison.metrics.unmatchedRows}.`,
        `${fr?'Actions proposées':'Proposed actions'}: ${comparison.metrics.actionGroups}.`,
        '', fr?'Les fichiers téléchargés conservent toutes les différences. Aucune correction automatique.':'The downloads preserve every difference. No automatic correction.',
        fr?'Ce contrôle compare des identités déclarées; il ne certifie ni le comportement ni la sécurité des sources.':'This check compares declared identities; it certifies neither source behavior nor source security.',
        '', `${fr?'Capacité utilisée':'Retained asset'}: ${assetHash}`, '',
        fr?'Exécution locale. Admission économique réelle : EN ATTENTE. Encaissements réels : inconnus.':'Local execution. Observed economic admission: HOLD. Actual collections: unknown.'];
      await checkpoint('packaging complete evidence');
      return {decision:'DELIVERABLE_READY_FOR_INDEPENDENT_CHECK',
        summary:{leftRows:left.rows.length,rightRows:right.rows.length,fieldDifferences:comparison.metrics.fieldDifferences,
          unmatchedRows:comparison.metrics.unmatchedRows,actionGroups:comparison.metrics.actionGroups},
        evidence:{assetHash,formats:{left:left.format,right:right.format},normalized,comparison,
          measured:{preparationMicros,comparisonMicros},economicAdmission:'HOLD_FULL_COST_AND_DEMAND_UNKNOWN'},
        artifacts:[{name:'inventory-report.md',type:'text/markdown',content:lines.join('\n')+'\n'},
          json('normalized-inventories.json',normalized),json('complete-comparison.json',comparison),
          {name:'differences.csv',type:'text/csv',content:guide.fullDifferencesCsv(comparison)},
          {name:'actions.csv',type:'text/csv',content:guide.actionPlanCsv(comparison)},
          json('asset-identity.json',{sha256:assetHash,scope:'reviewed local research candidate',authority:[],actualCollections:null})],
        limits:['Declared identity comparison only. No file reads or execution.',
          'The unchanged Workbench pack remains local, unapproved for production and unfunded.',
          'Construction was assisted by a current-session model outside the installed runtime; no autonomous invention claim.',
          'No observed full-cost payback or revenue is established.']};
    }
  };
}

export async function deliver(normalize,assetHash,input,{sourceHash,language='en',name='Release inventory'}={}) {
  const adapter=createIntakeAdapter(normalize,assetHash,language),workbench=createWorkbench([adapter]);
  const spec={schema:'successor-workbench/v1',family:adapter.manifest.id,name,language,owner:'local-research',
    rights:{dataClass:'public',source:'Pinned public source manifests or explicitly labeled synthetic variations',license:'Apache-2.0'},
    reviewMinutes:1,inputs:input};
  const pack=await workbench.run(spec,{sourceHash});
  await workbench.inspectPack(pack);
  return pack;
}

export {rawCsv};
