// SPDX-License-Identifier: Apache-2.0
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import {deliver} from './adapter.mjs';

const root=path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const [candidate,requestFile,outputDirectory]=process.argv.slice(2);
if (!['alpha','conventional'].includes(candidate)||!requestFile||!outputDirectory) {
  throw Error('Usage: node implementation/run_one.mjs alpha|conventional request.json new-output-directory');
}
const modulePath=path.join(root,'candidates',candidate,'normalize.mjs');
const assetHash=createHash('sha256').update(fs.readFileSync(modulePath)).digest('hex');
const {normalize}=await import(pathToFileURL(modulePath));
const request=JSON.parse(fs.readFileSync(requestFile,'utf8'));
const closure=JSON.parse(fs.readFileSync(path.join(root,'protocol','DEPENDENCIES.json'),'utf8'));
const files=[...closure.map(x=>x.path),'implementation/adapter.mjs',`candidates/${candidate}/normalize.mjs`];
const identities=Object.fromEntries(files.map(name=>[name,createHash('sha256').update(fs.readFileSync(path.join(root,name))).digest('hex')]));
const sourceHash=createHash('sha256').update(JSON.stringify(identities)).digest('hex');
const pack=await deliver(normalize,assetHash,request.inputs??request,{sourceHash,language:request.language??'en'});
fs.mkdirSync(outputDirectory,{recursive:false});
fs.writeFileSync(path.join(outputDirectory,'workbench-pack.json'),JSON.stringify(pack,null,2)+'\n');
for(const artifact of pack.result.artifacts) fs.writeFileSync(path.join(outputDirectory,artifact.name),artifact.content);
fs.writeFileSync(path.join(outputDirectory,'executed-source.json'),JSON.stringify({sourceHash,assetHash,identities},null,2)+'\n');
console.log(JSON.stringify({assetHash,sourceHash,summary:pack.result.summary,scope:pack.evaluation.scope}));
