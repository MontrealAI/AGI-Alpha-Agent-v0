// SPDX-License-Identifier: Apache-2.0
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import {spawn} from 'node:child_process';
import readline from 'node:readline';
import {deliver} from './adapter.mjs';

const root=path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const read=name=>JSON.parse(fs.readFileSync(path.join(root,name),'utf8'));
const out=path.resolve(process.argv[2]??path.join(root,'evidence','results'));
if(fs.existsSync(out))throw Error('OUTPUT_ALREADY_EXISTS');
fs.mkdirSync(out,{recursive:true});
const write=(name,data)=>{const p=path.join(out,name);fs.mkdirSync(path.dirname(p),{recursive:true});
  fs.writeFileSync(p,JSON.stringify(data,null,2)+'\n');};
const freeze=read('protocol/CANDIDATE_FREEZE.json');
for(const [name,expected] of Object.entries(freeze.files))if(hash(fs.readFileSync(path.join(root,name)))!==expected)throw Error('FROZEN_SOURCE_CHANGED:'+name);
const manifest=read('evidence/confirmation/DATA_MANIFEST.json');
for(const [name,expected] of Object.entries(manifest.files))if(hash(fs.readFileSync(path.join(root,'evidence/confirmation',name)))!==expected)throw Error('DATA_CHANGED:'+name);
const cases=read('evidence/confirmation/cases.json'),refusals=read('evidence/confirmation/refusals.json');
const valids=read('evidence/confirmation/valid-boundaries.json');
const methods={};
for(const name of ['alpha','conventional']){
  const p=path.join(root,'candidates',name,'normalize.mjs');
  methods[name]={normalize:(await import(pathToFileURL(p))).normalize,assetHash:hash(fs.readFileSync(p))};
}
const startedAt=new Date().toISOString();
const startupStart=performance.now();
const child=spawn(process.env.PYTHON??'python3',[path.join(root,'evaluation','oracle.py')],{stdio:['pipe','pipe','pipe']});
let stderr='';child.stderr.on('data',x=>stderr+=String(x));
const lines=readline.createInterface({input:child.stdout}),queue=[];
lines.on('line',line=>{const next=queue.shift();if(next)next.resolve(JSON.parse(line));});
child.on('error',error=>{for(const item of queue.splice(0))item.reject(error);});
child.on('exit',code=>{for(const item of queue.splice(0))item.reject(Error('ORACLE_EXIT:'+code+':'+stderr));});
const ordinary=async(text,format)=>{
  const response=await new Promise((resolve,reject)=>{queue.push({resolve,reject});child.stdin.write(JSON.stringify({text,format})+'\n');});
  if(!response.ok)throw Error(response.error);
  return response.value;
};
await ordinary('{"sources":{}}','json');
const ordinaryStartupMicros=Math.round((performance.now()-startupStart)*1000);
methods.ordinary={normalize:ordinary,assetHash:hash(fs.readFileSync(path.join(root,'evaluation','oracle.py')))};
const dependencies=read('protocol/DEPENDENCIES.json');
for(const row of dependencies)if(hash(fs.readFileSync(path.join(root,row.path)))!==row.sha256)throw Error('DEPENDENCY_CHANGED:'+row.path);
const sourceHash=hash(JSON.stringify({dependencies,adapter:hash(fs.readFileSync(path.join(root,'implementation/adapter.mjs'))),methods:Object.fromEntries(Object.entries(methods).map(([name,m])=>[name,m.assetHash]))}));
for(const method of Object.values(methods)){
  const cache=new Map();let bytes=0;
  method.cacheHits=0;method.cacheMisses=0;
  method.cached=async(text,format)=>{
    const key=hash(format+'\0'+text);
    if(cache.has(key)){method.cacheHits++;return structuredClone(cache.get(key).value);}
    method.cacheMisses++;
    const value=await method.normalize(text,format),size=Buffer.byteLength(text);
    while(cache.size&&(cache.size>=64||bytes+size>8000000)){
      const oldest=cache.keys().next().value;bytes-=cache.get(oldest).size;cache.delete(oldest);
    }
    cache.set(key,{value:structuredClone(value),size});bytes+=size;return value;
  };
}
const equal=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
const sortDiff=values=>values.slice().sort((a,b)=>a.path<b.path?-1:a.path>b.path?1:a.kind.localeCompare(b.kind));
function verify(pack,test){
  const ev=pack.result.evidence;
  if(!equal(ev.normalized.left,test.expected_left)||!equal(ev.normalized.right,test.expected_right))throw Error('NORMALIZED_ROWS');
  const actual=ev.comparison.differences.map(d=>({path:d.key,kind:d.kind,
    left:d.kind==='missing_from_right'?JSON.parse(d.leftValue)[1]:d.leftValue,
    right:d.kind==='missing_from_left'?JSON.parse(d.rightValue)[1]:d.rightValue}));
  if(!equal(sortDiff(actual),sortDiff(test.expected_differences)))throw Error('SEMANTIC_DIFFERENCES');
  const m=ev.comparison.metrics;
  if(m.leftRows!==test.expected_left.length||m.rightRows!==test.expected_right.length
    ||m.actionGroups!==test.expected_differences.length)throw Error('METRICS');
  if(pack.evaluation.admission!=='HOLD'||pack.evaluation.settlement!=='NOT_CONNECTED')throw Error('AUTHORITY');
}
const outcomes=[],boundaries=[],validOutcomes=[];
try {
  for(let index=0;index<cases.length;index++){
    const test=cases[index],order=['ordinary','alpha','conventional'];
    for(const name of order.slice(index%3).concat(order.slice(0,index%3))){
      const method=methods[name],started=performance.now();let pack=null,error=null,correct=false;
      try{
        pack=await deliver(method.cached,method.assetHash,{left:test.left,right:test.right},{sourceHash,name:test.job_id+' release inventory'});
        verify(pack,test);correct=true;
      }catch(e){error=String(e.message??e);}
      const endToEndMicros=Math.round((performance.now()-started)*1000);
      if(pack)write(`packs/${name}/${test.id}.json`,pack);
      outcomes.push({method:name,caseId:test.id,jobId:test.job_id,representation:test.representation,
        accepted:correct,producedPack:Boolean(pack),incorrectAcceptance:Boolean(pack)&&!correct,error,endToEndMicros,
        preparationMicros:pack?.result.evidence.measured.preparationMicros??null,
        comparisonMicros:pack?.result.evidence.measured.comparisonMicros??null,assetHash:method.assetHash});
    }
  }
  for(const test of refusals)for(const [name,method] of Object.entries(methods)){
    let refused=false,error=null;
    try{await method.cached(test.text,test.format);}catch(e){refused=true;error=String(e.message??e);}
    boundaries.push({method:name,id:test.id,reason:test.reason,expected:'REFUSE',refused,error});
  }
  for(const test of valids)for(const [name,method] of Object.entries(methods)){
    let value=null,error=null;
    try{value=await method.cached(test.text,test.format);}catch(e){error=String(e.message??e);}
    validOutcomes.push({method:name,id:test.id,reason:test.reason,passed:equal(value,test.expected),value,error});
  }
}finally{child.stdin.end();lines.close();}
const median=values=>values.length?values.slice().sort((a,b)=>a-b)[Math.floor(values.length/2)]:null;
const arms={};
for(const [name,method] of Object.entries(methods)){
  const rows=outcomes.filter(x=>x.method===name),probes=boundaries.filter(x=>x.method===name),valid=validOutcomes.filter(x=>x.method===name);
  const jobs=[...new Set(rows.map(x=>x.jobId))];
  arms[name]={uniqueJobs:jobs.length,acceptedUniqueJobs:jobs.filter(id=>rows.filter(x=>x.jobId===id).every(x=>x.accepted)).length,
    caseEvaluations:rows.length,acceptedEvaluations:rows.filter(x=>x.accepted).length,
    incorrectAcceptances:rows.filter(x=>x.incorrectAcceptance).length,refusalProbes:probes.length,refusalFailures:probes.filter(x=>!x.refused).length,
    validBoundaryProbes:valid.length,validBoundaryFailures:valid.filter(x=>!x.passed).length,
    medianEndToEndMicros:median(rows.map(x=>x.endToEndMicros)),medianPreparationMicros:median(rows.map(x=>x.preparationMicros).filter(x=>x!==null)),
    totalEndToEndMicros:rows.reduce((s,x)=>s+x.endToEndMicros,0),assetHash:method.assetHash,
    cacheHits:method.cacheHits,cacheMisses:method.cacheMisses,
    technicalAdmission:rows.every(x=>x.accepted)&&probes.every(x=>x.refused)&&valid.every(x=>x.passed)?'PASS_FINITE_CONTRACT':'HOLD',
    observedEconomicAdmission:'HOLD_FULL_COST_AND_DEMAND_UNKNOWN'};
}
const summary={schema:'funded-advantage-results/v1',startedAt,endedAt:new Date().toISOString(),sourceHash,
  arms,ordinaryStartupMicros,uniqueJobs:manifest.unique_jobs,semanticDifferences:manifest.semantic_difference_occurrences,
  primaryMethodEvaluations:outcomes.length,refusalMethodEvaluations:boundaries.length,secondaryMethodEvaluations:validOutcomes.length,
  measuredCustomerMinutes:null,actualCollections:null,modelInferenceCost:null,
  execution:{local:'EXECUTED',isolatedCI:'NOT_RUN',approvedOperator:'NOT_RUN',production:'NOT_RUN'},
  timingCaveat:'Warm per-method exact-input cache; balanced order. Python IPC is included in ordinary end-to-end cost. No algorithm/model superiority claim. These are small finite engineering observations, not a general performance benchmark.'};
write('outcomes.json',outcomes);write('refusals.json',boundaries);write('valid-boundaries.json',validOutcomes);write('summary.json',summary);
const csvKeys=Object.keys(outcomes[0]);
fs.writeFileSync(path.join(out,'outcomes.csv'),[csvKeys,...outcomes.map(x=>csvKeys.map(k=>x[k]??''))]
  .map(row=>row.map(x=>'"'+String(x).replaceAll('"','""')+'"').join(',')).join('\n')+'\n');
for(const [name,expected] of Object.entries(freeze.files))if(hash(fs.readFileSync(path.join(root,name)))!==expected)throw Error('FROZEN_SOURCE_CHANGED_AFTER_RUN:'+name);
console.log(JSON.stringify(summary,null,2));
