# Economics: what the evidence supports

The primary result is **economic HOLD**. All three implemented intake routes
support the finite technical contract. No recurring provider or customer
attention reduction was measured. The ordinary specialist already performs the
same normalization work. Its assembly was real work and is chargeable; it is
not a historical installed no-investment baseline.

The recorded ordinary median whole-pipeline duration is 23,154 microseconds,
versus 23,233 for Alpha and 23,238 for the conventional retained asset. Total-time
ordering differs. These small local observations include ordinary Python IPC;
they do not establish robust algorithm, model or end-to-end speed superiority.
The 23,560-microsecond ordinary process startup is reported separately.

## Run and independently audit

From the study directory:

```sh
node economics/analyze.mjs --protocol-check
node economics/analyze.mjs --out /absolute/new-output/economics
python3 economics/audit.py /absolute/new-output/economics --report /absolute/new-output/economics/audit.json
```

For a fresh local production replay, add
`--results /absolute/new-output/results/summary.json` to the analysis command.
The default is the preserved original `evidence/results/summary.json`. The
program records the exact input hash and path. Neither invocation repeats model
construction, customer sales, human labor or production execution.

Dependencies are only Node.js and Python standard libraries plus the two
unchanged canonical modules under `vendor/shared/`. Their SHA-256 identities
are checked against the original dependency register. No new ledger, payment
mechanism or token function is implemented.

## Costs and provenance

`automated-cost-records.json` uses `alpha-automated-costs/v1`. Its observed records
leave marginal, recurring and fully loaded monetary costs unknown for every arm.
Observed builder elapsed times are 246.660815 seconds for Alpha and 170 seconds
for the conventional builder, including its failed first candidate. Elapsed
model-assisted construction time is not converted into human labor or a model
bill. Complete authoring tokens, inference bills, human attention, ordinary
specialist assembly cost, shared development and real demand remain unknown.

The USD investment grid is an assumed **complete incremental cost envelope**
covering incremental discovery, both successful and unsuccessful construction,
integration, initial qualification and unmetered authoring/inference. Recurring
delivery and upkeep are charged separately. The USD0 point is only a mathematical
lower bound. It is not an assertion that construction was free.

Finite modeled cash paths charge a USD20 shared setup bound, including ordinary
specialist assembly, and USD0.25 per attempt for remaining recurring delivery and
business costs. Those are explicit hypothetical aggregate bounds, not observed
prices or complete empirical cost measurements. A USD5-per-attempt cost-overrun
stress is also included. These assumptions must hold for the conditional
arithmetic to describe an operating configuration.

The original horizon, investment, price, compute and attention grids were
registered before confirmation. `PROTOCOL.json` candidly records that the
additional cash specification was written after the result message. A first
exploratory run did not deplete cash under modest costs; the explicit adverse
cost-overrun case was then added. It is an accounting stress, not a change to
the frozen asset, confirmation inputs or technical outcome.

## Primary and counterfactual results

The complete analysis exports 3,528 investment-frontier rows, 8,064 human-cost
threshold rows and 6,720 finite cash scenarios. **All 3,360 primary cash scenarios
retain ordinary delivery and make zero new investments.** Their assumed
additional avoided provider attention is zero. A larger customer price does not
repair an unproductive asset: common price cancels when accepted work is equal.

The secondary cash scenarios assume an additional **60 seconds of avoided
provider attention per job**. That benefit was not observed. Under complete
cost bounds, some of those scenarios can fund and repay the actual tested,
SHA-256-identified candidate. Every such path is labeled
`COUNTERFACTUAL_BENEFIT_NOT_ESTABLISHED`; actual economic admission remains false.

A concrete arithmetic example uses Alpha, 52 offered jobs, USD20 complete
incremental investment, USD5 collected price and two-job collection delay. With
the unobserved 60-second benefit, the modeled ledger funds the tested asset after
job13. It is then used on 39 modeled subsequent jobs, first exceeds investment
recovery at job46, and finishes with USD3.79 incremental benefit. Adding the
declared USD10 maintenance exposure prevents that investment within the same
horizon. This demonstrates the admission rule's dependence on complete costs
and timing; it is not an earned-revenue or empirical improvement result.

For the same USD20 investment, USD0.01 incremental upkeep per job and USD1/hour
compute assumption, the static inverse frontier requires more than approximately
123.50, 38.68, 19.83 and 10.40 avoided provider seconds per use over respectively
16, 52, 104 and 208 uses. The experiment establishes none of those attention
savings. A connected financing path may need more jobs because investment must
wait for collected contribution.

## Cash and obligations

All paths start with the same USD100 seed and never replenish it. The seed is
separate from earned contribution. Shared setup is paid first. Collections are
delayed by zero, two or eight job intervals; outstanding receivables do not fund
construction. Every failed attempt still costs money. One next ordinary attempt
and declared maintenance exposure remain protected. Investment requires both
available cash and collected operating contribution to cover the whole cost,
with strictly positive remaining-horizon incremental value.

Lower demand, every-tenth-job failure, maintenance shocks and recurring cost
overruns are retained. In the original arithmetic run, 364 scenarios stop for
depleted cash while preserving the declared reserve; no balance goes negative.
The price frontier reports the lowest successful price **among the sampled
prices**, not an exact market price or willingness-to-pay estimate.

Sixty preselected complete cash traces contain the original
`alpha-shadow-ledger/v1` event records and canonical replay summaries. Every
`collected` field remains unknown. Canonical assumed-price totals and the
chronological modeled-collection view are explicitly distinct. Setup is an
accounting anchor, not an extra customer job. Other parameter combinations
retain their complete aggregate cash outcomes and conservation identities.

## Human comparison

The sourced June2026 office/admin employer-compensation rate is USD36.73/hour.
The May2025 QA median wage is USD50.14/hour and developer median wage is
USD65.38/hour; those two exclude benefits. Original source URLs and periods are
in `sources.json`. No matched traditional task duration was measured.

For the provider, the break-even human duration uses the full scenario cost.
For the buyer, it uses selling price plus customer attention. These are separate
comparisons. At USD36.73/hour, each USD1 of buyer cost requires 1.634 minutes of
equivalent human work to break even. A competent non-AI human may use normal
software and saved scripts. Customer savings never become provider revenue.

## Audit and files

`audit.py` independently recomputes fractional cost-tier arithmetic, every
integer investment frontier, all cash conservation equations, seed/surplus
separation, delayed receipts, affordability, asset identities, canonical costs,
sampled price thresholds and unknown observed collections. It checks all output
rows and complete chronological traces, using Python rather than the JavaScript
implementation.

Outputs include JSON and CSV frontiers, buyer/provider thresholds, every finite
cash outcome, complete canonical traces, shared automated-cost records and
summaries, source assumptions and the independent audit receipt. These are
reproducible conditional calculations bound to useful local execution. They do
not demonstrate profitable capability admission or sustained acceleration.
