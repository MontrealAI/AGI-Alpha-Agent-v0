# SPDX-License-Identifier: Apache-2.0
import argparse
import hashlib
import json
import math
from fractions import Fraction
from pathlib import Path


def audit(directory):
    checks = 0

    def require(condition, message):
        nonlocal checks
        checks += 1
        if not condition:
            raise AssertionError(message)

    def read(name):
        return json.loads((directory / name).read_text())

    summary = read('economics-summary.json')
    inputs = read('economic-inputs.json')
    plan = inputs['plan']
    results = summary['inputResults']
    wage = inputs['sources']['labor'][0]['valueCentsPerHour']
    require(summary['actualCollections'] is None, 'Actual collections were invented')
    require(summary['actualInvestableSurplus'] is None, 'Actual surplus was invented')
    require(summary['actualFinancialTransactions'] == 0, 'Financial transaction claim')
    require(summary['measuredAvoidedProviderAttentionSeconds'] is None, 'Human saving was invented')
    require(summary['primaryAssumedAvoidedProviderAttentionSeconds'] == 0, 'Primary labor handicap')
    require(results['uniqueJobs'] == 16, 'Robustness repetitions miscounted as unique jobs')
    for arm in ['alpha', 'conventional', 'ordinary']:
        require(summary['observedCompleteCostPerAccepted'][arm] is None, 'Unknown full cost became zero')
    records = read('automated-cost-records.json')
    automated = read('automated-cost-summaries.json')
    for arm, observed in automated['observed'].items():
        for scenario in observed['scenarios']:
            for tier in ['marginalMicrosPerAccepted', 'recurringMicrosPerAccepted', 'fullyLoadedMicrosPerAccepted']:
                require(scenario['costs'][tier] is None, f'{arm}: unknown tier was priced')
    for arm, record in records['modeled'].items():
        calculated = {row['name']: row for row in automated['modeled'][arm]['scenarios']}
        for scenario in record['scenarios']:
            acceptance = Fraction(scenario['acceptanceBps']['value'], 10000)
            attempts = Fraction(scenario['attemptsPerRequestPpm']['value'], 1000000)
            requests = Fraction(scenario['capacityRequestsPerMonth']['value']) * Fraction(scenario['utilizationBps']['value'], 10000)
            variable = sum(Fraction(row['unitsPerOccurrencePpm']['value'], 1000000) * row['unitCostMicros']['value'] *
                {'request': Fraction(1), 'attempt': attempts, 'accepted': acceptance}[row['frequency']]
                for row in scenario['operations'])
            shared = sum(Fraction(row['amountMicros']['value'] * row['allocationBps']['value'], 10000) for row in scenario['monthly'])
            fixed = sum(Fraction(row['amountMicros']['value'] * row['allocationBps']['value'],
                10000 * row['amortizationMonths']['value']) for row in scenario['investments'])
            output = calculated[scenario['name']]['costs']
            require(output['marginalMicrosPerAccepted'] == math.ceil(variable / acceptance), 'Marginal arithmetic mismatch')
            require(output['recurringMicrosPerAccepted'] == math.ceil((variable * requests + shared) / (requests * acceptance)), 'Recurring arithmetic mismatch')
            require(output['fullyLoadedMicrosPerAccepted'] == math.ceil((variable * requests + shared + fixed) / (requests * acceptance)), 'Full-cost arithmetic mismatch')
            require(calculated[scenario['name']]['humanBaselineMicrosPerAccepted'] is None, 'Human duration invented')
    frontiers = read('frontier.json')
    require(len(frontiers) == summary['counters']['frontierRows'], 'Frontier row loss')
    for row in frontiers:
        difference = results['arms']['ordinary']['medianEndToEndMicros'] - results['arms'][row['arm']]['medianEndToEndMicros']
        rate = round(row['computeUsdPerHour'] * 100)
        numerator = row['horizon'] * (difference * rate + row['avoidedAttentionSeconds'] * wage * 1000000)
        gross = numerator // 360000
        upkeep = row['horizon'] * row['maintenanceCentsPerAttempt'] * 10000
        fixed = row['investmentUsd'] * 1000000
        require(row['grossSavingMicros'] == gross, 'Independent gross-saving mismatch')
        require(row['netBenefitMicros'] == gross - upkeep - fixed, 'Incremental cost mismatch')
        require(row['observedEconomicAdmission'] is False, 'Observed admission without full costs')
        require(row['equalPriceCancels'] is True, 'Price should cancel for equal acceptance')
        require(row['assetHash'] == results['arms'][row['arm']]['assetHash'], 'Wrong financed asset')
        if row['avoidedAttentionSeconds'] > 0:
            require(row['evidenceStatus'] == 'COUNTERFACTUAL_BENEFIT_NOT_ESTABLISHED', 'Unobserved attention mislabeled')
    thresholds = read('human-thresholds.json')
    require(len(thresholds) == summary['counters']['humanThresholdRows'], 'Threshold row loss')
    for row in thresholds:
        expected = row['priceUsd'] * 3600 / row['hourlyUsd'] + row['customerAttentionSeconds']
        require(abs(row['buyerBreakEvenHumanSeconds'] - expected) < 1e-9, 'Buyer threshold mismatch')
        require(row['traditionalDurationSeconds'] is None and row['observedSavingsRatio'] is None, 'Invented human comparison')
        require(row['fullyLoadedMicros'] >= row['recurringMicros'] >= row['marginalMicros'], 'Cost-tier ordering')
    cash_rows = read('cash-outcomes.json')
    require(len(cash_rows) == summary['counters']['cashScenarios'], 'Cash scenario loss')
    admitted = primary = exhausted = 0
    for row in cash_rows:
        expected = row['initialCashCents'] - row['commonSetupPaidCents'] + row['modeledCollectedCents'] - row['operatingPaidCents'] - row['investmentPaidCents'] - row['maintenanceShockPaidCents']
        require(row['endingCashCents'] == expected, 'Cash conservation failure')
        require(row['endingEarnedContributionCents'] == row['endingCashCents'] - row['initialCashCents'], 'Seed became earned surplus')
        require(row['endingCashCents'] >= 0 and row['minimumCashCents'] >= 0, 'Negative unfinanced cash')
        require(row['actualCollections'] is None and row['actualEconomicAdmission'] is False, 'Modeled revenue or admission relabeled')
        require(row['actualFinancialTransactions'] == 0 and row['injectedCapitalAfterStartCents'] == 0, 'Hidden replenishment')
        require(row['acceptedJobs'] + row['rejectedJobs'] == row['attemptedJobs'] <= row['offeredJobs'] <= row['horizon'], 'Unique-job count failure')
        require(row['assetHash'] == results['arms'][row['arm']]['assetHash'], 'Wrong asset identity')
        require(row['pendingReceivablesCents'] + row['modeledCollectedCents'] == row['acceptedJobs'] * round(row['priceUsd'] * 100), 'Receipts/receivables mismatch')
        if row['modeledInvestmentOccurred']:
            admitted += 1
            budget = row['budgetAtInvestment']
            require(row['technicalQualified'], 'Technically failed candidate funded')
            require(budget['prospectiveIncrementalCents'] > 0, 'Nonpositive economic admission')
            require(row['investmentPaidCents'] == round(row['investmentUsd'] * 100), 'Wrong candidate construction cost')
            require(min(budget['cashCents'], budget['earnedContributionCents']) - budget['protectedReserveCents'] >= row['investmentPaidCents'], 'Unaffordable investment')
            require(row['evidenceStatus'] == 'COUNTERFACTUAL_BENEFIT_NOT_ESTABLISHED', 'Unsupported benefit called observed')
        if row['avoidedAttentionSeconds'] == 0:
            primary += 1
            require(not row['modeledInvestmentOccurred'], 'Primary unsupported promotion')
        if row['stopReason'].startswith('CASH_EXHAUSTED'):
            exhausted += 1
    require(primary == summary['counters']['primaryCashScenarios'], 'Primary scenario count')
    require(admitted == summary['counters']['counterfactualInvestments'], 'Conditional scenario count')
    require(exhausted == summary['counters']['exhaustedScenarios'] and exhausted > 0, 'No genuine depletion stress')
    groups = {}
    for row in cash_rows:
        key = tuple(row[name] for name in ['arm', 'horizon', 'investmentUsd', 'delayJobs', 'profile', 'avoidedAttentionSeconds'])
        groups.setdefault(key, []).append(row)
    prices = read('financing-price-frontier.json')
    require(len(prices) == summary['counters']['financingPriceGroups'], 'Price frontier lost groups')
    for row in prices:
        key = tuple(row[name] for name in ['arm', 'horizon', 'investmentUsd', 'delayJobs', 'profile', 'avoidedAttentionSeconds'])
        eligible = [item['priceUsd'] for item in groups[key] if item['modeledInvestmentOccurred'] and item['terminalIncrementalBenefitCents'] > 0]
        require(row['lowestSuccessfulSampledPriceUsd'] == (min(eligible) if eligible else None), 'Sampled price threshold mismatch')
        require(row['exactPriceThresholdIdentified'] is False, 'Grid estimate mislabeled exact')
    traces = read('cash-traces.json')
    require(len(traces) == summary['counters']['completeCanonicalCashTraces'], 'Trace count')
    for trace in traces:
        row = trace['row']
        cash = row['initialCashCents'] - row['commonSetupPaidCents']
        pending = []
        collections = 0
        for step in trace['steps'][1:]:
            require(step['openingCashCents'] == cash, 'Cash discontinuity')
            due = [receipt for receipt in pending if receipt[0] <= step['step']]
            pending = [receipt for receipt in pending if receipt[0] > step['step']]
            paid = sum(receipt[1] for receipt in due)
            require(step['receiptsBeforeCents'] == paid, 'Collection delay bypassed')
            cash += paid
            collections += paid
            if step['kind'] == 'job':
                cash -= step['costCents'] + step['maintenanceShockCents'] + step['investmentPaidCents']
                require(step['immediateReceiptsCents'] == (round(row['priceUsd'] * 100) if step['accepted'] and row['delayJobs'] == 0 else 0), 'Immediate receipt mismatch')
                cash += step['immediateReceiptsCents']
                collections += step['immediateReceiptsCents']
                if step['accepted'] and row['delayJobs']:
                    pending.append((step['step'] + row['delayJobs'], round(row['priceUsd'] * 100)))
            require(cash == step['closingCashCents'] and cash >= 0, 'Step cash conservation')
            require(step['earnedContributionCents'] == cash - row['initialCashCents'], 'Step earned/seed separation')
        require(cash == row['endingCashCents'] and collections == row['modeledCollectedCents'], 'Trace/result mismatch')
        events = trace['ledger']['events']
        require(len({event['id'] for event in events}) == len(events), 'Duplicate canonical events')
        for event in events:
            if event['type'] == 'revenue' and event['category'] == 'collected':
                require(event['amountMinor'] is None and event['basis'] == 'unknown', 'Simulated collection written as observed')
        costs = sum(event['amountMinor'] for event in events if event['type'] == 'cost')
        require(costs == row['commonSetupPaidCents'] + row['operatingPaidCents'] + row['investmentPaidCents'] + row['maintenanceShockPaidCents'], 'Canonical cost omission')
        require(trace['canonicalSummary']['observed']['availableSurplus'] is None, 'Canonical unknown surplus lost')
        require(trace['canonicalSummary']['scenario']['fullCost'] == costs, 'Canonical arithmetic mismatch')
    return {'schema': 'funded-advantage-economic-audit/v1', 'status': 'PASS', 'checks': checks,
        'cashScenarios': len(cash_rows), 'completeCashTraces': len(traces),
        'primaryInvestments': 0, 'counterfactualInvestments': admitted, 'depletedCashScenarios': exhausted,
        'observedCollections': None, 'observedEconomicAdmission': 'HOLD',
        'auditMethod': 'Independent Python standard-library integer/Fraction arithmetic over exported records and chronological event traces.',
        'summarySha256': hashlib.sha256((directory / 'economics-summary.json').read_bytes()).hexdigest()}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('directory', type=Path)
    parser.add_argument('--report', type=Path)
    arguments = parser.parse_args()
    report = audit(arguments.directory)
    text = json.dumps(report, indent=2) + '\n'
    if arguments.report:
        arguments.report.write_text(text)
    print(text, end='')
