// SPDX-License-Identifier: Apache-2.0
import assert from 'node:assert/strict';
import {readFileSync, writeFileSync, mkdirSync} from 'node:fs';
import {resolve, dirname, isAbsolute} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {AUTOMATED_STAGES, evaluateAutomatedCosts} from '../vendor/shared/automated-costs.mjs';
import {planMission, replayLedger, calculateInvestment} from '../vendor/shared/shadow-ledger.mjs';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const read = path => JSON.parse(readFileSync(resolve(root, path), 'utf8'));
const hash = path => createHash('sha256').update(readFileSync(resolve(root, path))).digest('hex');
const plan = read('economics/PROTOCOL.json'), sources = read('economics/sources.json');
const wageCents = sources.labor.find(row => row.id === 'bls-office-admin-june2026').valueCentsPerHour;
const fact = (value, basis, reference) => ({value, basis, reference});
const unknown = reference => fact(null, 'unknown', reference);
const estimate = (value, reference) => fact(value, 'estimated', reference);
const zero = reference => fact(0, 'estimated', reference);
const toCents = dollars => Math.round(dollars * 100);
const floorDivide = (n, d) => n / d - (n < 0n && n % d !== 0n ? 1n : 0n);
const runtimeMicrosCost = (elapsedMicros, centsPerHour) =>
  Number((BigInt(elapsedMicros) * BigInt(centsPerHour) + 359999n) / 360000n);
const attentionMicrosCost = seconds =>
  Number((BigInt(seconds) * BigInt(wageCents) * 1000000n + 359999n) / 360000n);
const cashCents = micros => Math.ceil(micros / 10000);
const sameAcceptance = rows => new Set(Object.values(rows).map(row => row.acceptedUniqueJobs)).size === 1;
const qualifies = row => row.acceptedUniqueJobs === row.uniqueJobs &&
  row.acceptedEvaluations === row.caseEvaluations && row.incorrectAcceptances === 0 &&
  row.refusalFailures === 0 && row.validBoundaryFailures === 0;

function dependencies() {
  const manifest = read('protocol/DEPENDENCIES.json');
  const shared = manifest.filter(row => row.path.startsWith('vendor/shared/'));
  assert.equal(shared.length, 2);
  for (const row of shared) assert.equal(hash(row.path), row.sha256, `Canonical source changed: ${row.path}`);
  return shared;
}

function observedRecord(arm) {
  const scenario = name => ({
    name,
    capacityRequestsPerMonth: unknown('No observed customer demand or monthly capacity measurement.'),
    utilizationBps: unknown('Research jobs are not observed monthly utilization.'),
    acceptanceBps: unknown('Finite technical acceptance does not identify future customer acceptance.'),
    attemptsPerRequestPpm: unknown('Future retries and recovery rates are not measured.'),
    operations: AUTOMATED_STAGES.map(stage => ({
      id: `${arm}-${stage}`, stage, frequency: 'request',
      unitsPerOccurrencePpm: unknown(`Complete priced ${stage} quantities remain unmetered.`),
      unitCostMicros: unknown('No complete observed monetary unit cost.'), implementation: 'implemented'
    })),
    residual: [{id: `${arm}-residual`, stage: 'recovery',
      exceptionsPerRequestPpm: unknown('Residual exception incidence unmeasured.'),
      minutesPerException: unknown('Residual labor unmeasured.'),
      hourlyCostMicros: fact(wageCents * 10000, 'sourced', sources.labor[0].url)}],
    monthly: ['capacity', 'maintenance', 'business'].map(kind => ({
      id: `${arm}-${kind}`, kind, amountMicros: unknown(`Complete ${kind} cost unknown.`),
      allocationBps: unknown('Allocation across actual accepted demand unknown.')
    })),
    investments: ['setup', 'development'].map(kind => ({
      id: `${arm}-${kind}`, kind,
      amountMicros: unknown('Includes ordinary assembly or candidate work, discovery, failed construction, integration and qualification.'),
      allocationBps: unknown('Full attributable allocation unmeasured.'),
      amortizationMonths: unknown('No observed economic service horizon.')
    })),
    humanBaseline: {minutesPerAccepted: unknown('Equivalent competent non-AI human duration unmeasured.'),
      hourlyCostMicros: fact(wageCents * 10000, 'sourced', sources.labor[0].url)}
  });
  return {schema: 'alpha-automated-costs/v1', offeringId: `inventory-${arm}`, currency: 'USD',
    scenarios: ['base', 'conservative', 'stress'].map(scenario)};
}

function modeledRecord(arm, metrics) {
  const settings = [
    {name: 'base', horizon: 104, investment: 20, hourly: 100, maintenance: 1},
    {name: 'conservative', horizon: 52, investment: 100, hourly: 100, maintenance: 1},
    {name: 'stress', horizon: 16, investment: 500, hourly: 1000, maintenance: 10}
  ];
  const ref = 'Exploratory complete-cost bounds in economics/PROTOCOL.json; not observed costs, bills or demand.';
  return {schema: 'alpha-automated-costs/v1', offeringId: `inventory-${arm}-modeled`, currency: 'USD',
    scenarios: settings.map(setting => ({
      name: setting.name,
      capacityRequestsPerMonth: estimate(setting.horizon, 'Treat finite scenario as one accounting period; not measured monthly capacity.'),
      utilizationBps: estimate(10000, 'All stated hypothetical jobs occur in this scenario.'),
      acceptanceBps: estimate(10000, 'Hypothetical continuation of finite technical acceptance; not customer demand.'),
      attemptsPerRequestPpm: estimate(1000000, 'One modeled attempt per job in this cost-tier example; cash stresses include failures.'),
      operations: [
        ...AUTOMATED_STAGES.map(stage => ({id: `${arm}-${stage}`, stage, frequency: 'request',
          unitsPerOccurrencePpm: estimate(1000000, 'One aggregate occurrence per attempted job.'),
          unitCostMicros: stage === 'execution' ? estimate(
            runtimeMicrosCost(metrics.medianEndToEndMicros, setting.hourly),
            'Median measured whole local pipeline duration multiplied by assumed compute price; no runtime superiority inferred.'
          ) : zero('Zero ADDITIONAL cost; the full timed local pipeline is aggregated under execution.'),
          implementation: 'implemented'})),
        {id: `${arm}-common-recurring`, stage: 'reporting', frequency: 'attempt',
          unitsPerOccurrencePpm: estimate(1000000, ref),
          unitCostMicros: estimate(plan.cashCommonRecurringCentsPerAttempt * 10000,
            'Assumed complete aggregate bound for remaining delivery, business and residual costs; not observed.'), implementation: 'modeled'},
        {id: `${arm}-incremental-upkeep`, stage: 'correction', frequency: 'attempt',
          unitsPerOccurrencePpm: estimate(1000000, ref),
          unitCostMicros: estimate(setting.maintenance * 10000, 'Explicit assumed incremental upkeep per use.'), implementation: 'modeled'}
      ],
      residual: [],
      monthly: [{id: `${arm}-monthly`, kind: 'business', amountMicros: zero('Included in common recurring aggregate bound.'),
        allocationBps: estimate(10000, ref)}],
      investments: [
        {id: `${arm}-common-setup`, kind: 'setup', amountMicros: estimate(plan.commonSetupCents * 10000,
          'Assumed shared setup/ordinary specialist assembly; charged to every arm.'),
          allocationBps: estimate(10000, ref), amortizationMonths: estimate(1, 'Charge all setup within this one finite accounting period.')},
        {id: `${arm}-complete-investment`, kind: 'development', amountMicros: estimate(setting.investment * 1000000,
          'Assumed COMPLETE incremental discovery/construction/failed-candidate/integration/qualification/authoring bound.'),
          allocationBps: estimate(10000, ref), amortizationMonths: estimate(1, 'Charge the whole investment within the finite horizon.')}
      ],
      humanBaseline: {minutesPerAccepted: unknown('No matched traditional human duration.'),
        hourlyCostMicros: fact(wageCents * 10000, 'sourced', sources.labor[0].url)}
    }))};
}

function frontier(results) {
  const output = [], ordinary = results.arms.ordinary;
  for (const arm of ['alpha', 'conventional']) for (const horizon of plan.horizons)
    for (const computeUsdPerHour of plan.computeUsdPerHour)
      for (const investmentUsd of plan.completeIncrementalInvestmentUsd)
        for (const avoidedAttentionSeconds of plan.avoidedProviderAttentionSeconds)
          for (const maintenanceCentsPerAttempt of plan.frontierIncrementalMaintenanceCentsPerAttempt) {
            const runtimeDifference = ordinary.medianEndToEndMicros - results.arms[arm].medianEndToEndMicros;
            const numerator = BigInt(horizon) * (BigInt(runtimeDifference) * BigInt(toCents(computeUsdPerHour)) +
              BigInt(avoidedAttentionSeconds) * BigInt(wageCents) * 1000000n);
            const grossSavingMicros = Number(floorDivide(numerator, 360000n));
            const maintenanceMicros = horizon * maintenanceCentsPerAttempt * 10000;
            const fixedMicros = investmentUsd * 1000000;
            const netBenefitMicros = grossSavingMicros - maintenanceMicros - fixedMicros;
            const exactPerJobSavingMicros = Number(numerator) / 360000 / horizon;
            const netPerJob = exactPerJobSavingMicros - maintenanceCentsPerAttempt * 10000;
            const runtimePerJob = runtimeDifference * toCents(computeUsdPerHour) / 360000;
            const requiredAttentionSeconds = Math.max(0,
              (fixedMicros / horizon + maintenanceCentsPerAttempt * 10000 - runtimePerJob) * 3600 / (wageCents * 10000));
            const canonical = calculateInvestment({constructionCostMinor: toCents(investmentUsd),
              failedConstructionCostMinor: 0, maintenancePerReuseMinor: maintenanceCentsPerAttempt,
              expectedSavingPerReuseMinor: Math.floor(exactPerJobSavingMicros / 10000), remainingReuses: horizon});
            output.push({arm, assetHash: results.arms[arm].assetHash, horizon, computeUsdPerHour,
              investmentUsd, avoidedAttentionSeconds, maintenanceCentsPerAttempt, grossSavingMicros,
              maintenanceMicros, fixedMicros, netBenefitMicros,
              maximumCompleteIncrementalInvestmentUsd: (grossSavingMicros - maintenanceMicros) / 1000000,
              requiredAttentionSeconds, strictPositivePaybackJobs: netPerJob > 0 ? Math.floor(fixedMicros / netPerJob) + 1 : null,
              canonicalConservativeCentNetBenefit: canonical.netBenefit,
              technicalQualified: qualifies(results.arms[arm]), equalPriceCancels: sameAcceptance(results.arms),
              mathematicalPositive: netBenefitMicros > 0 && qualifies(results.arms[arm]),
              observedEconomicAdmission: false,
              evidenceStatus: avoidedAttentionSeconds > 0 ? 'COUNTERFACTUAL_BENEFIT_NOT_ESTABLISHED' :
                investmentUsd === 0 ? 'ZERO_COST_LOWER_BOUND_NOT_OBSERVED' : 'PRIMARY_ZERO_UNOBSERVED_ATTENTION_SAVING'});
          }
  return output;
}

function humanThresholds(results) {
  const rows = [];
  for (const arm of ['alpha', 'conventional']) for (const horizon of plan.horizons)
    for (const investmentUsd of plan.completeIncrementalInvestmentUsd)
      for (const computeUsdPerHour of plan.computeUsdPerHour)
        for (const customerAttentionSeconds of plan.customerAttentionSeconds)
          for (const priceUsd of plan.sellingPriceUsd) for (const labor of sources.labor) {
            const computeMicros = runtimeMicrosCost(results.arms[arm].medianEndToEndMicros, toCents(computeUsdPerHour));
            const marginalMicros = computeMicros + plan.cashCommonRecurringCentsPerAttempt * 10000;
            const recurringMicros = marginalMicros + plan.cashIncrementalMaintenanceCentsPerAttempt * 10000;
            const fullyLoadedMicros = recurringMicros +
              Math.ceil((investmentUsd * 1000000 + plan.commonSetupCents * 10000) / horizon);
            const hourlyUsd = labor.valueCentsPerHour / 100;
            rows.push({arm, horizon, investmentUsd, computeUsdPerHour, customerAttentionSeconds, priceUsd,
              laborSource: labor.id, hourlyUsd, marginalMicros, recurringMicros, fullyLoadedMicros,
              providerBreakEvenPriceUsd: fullyLoadedMicros / 1000000,
              providerBreakEvenHumanSeconds: fullyLoadedMicros / 1000000 * 3600 / hourlyUsd,
              buyerBreakEvenHumanSeconds: priceUsd * 3600 / hourlyUsd + customerAttentionSeconds,
              traditionalDurationSeconds: null, observedSavingsRatio: null,
              evidenceStatus: 'CONDITIONAL_COST_BOUNDS_DURATION_UNKNOWN'});
          }
  return rows;
}

function cashProjection(results, config, keepTrace) {
  const {arm, horizon, investmentUsd, priceUsd, delayJobs, profile, avoidedAttentionSeconds} = config;
  const metrics = results.arms[arm], assetHash = metrics.assetHash;
  const offered = profile === 'lower-demand' ? Math.floor(horizon / plan.lowerDemandDivisor) : horizon;
  const price = toCents(priceUsd), investment = toCents(investmentUsd);
  const ordinaryCompute = cashCents(runtimeMicrosCost(results.arms.ordinary.medianEndToEndMicros, 100));
  const candidateCompute = cashCents(runtimeMicrosCost(metrics.medianEndToEndMicros, 100));
  const commonRecurring = profile === 'cost-overrun' ?
    plan.costOverrunCommonRecurringCentsPerAttempt : plan.cashCommonRecurringCentsPerAttempt;
  const ordinaryCost = commonRecurring + ordinaryCompute + cashCents(attentionMicrosCost(avoidedAttentionSeconds));
  const candidateCost = commonRecurring + candidateCompute + plan.cashIncrementalMaintenanceCentsPerAttempt;
  const shock = profile === 'maintenance-shock' ? plan.maintenanceShockCents : 0;
  let cash = plan.initialCashCents - plan.commonSetupCents, earned = -plan.commonSetupCents;
  let totalCollected = 0, operating = 0, paidInvestment = 0, paidShock = 0, minCash = cash;
  let invested = false, investmentAtJob = null, paybackAtJob = null, attempted = 0, accepted = 0;
  let retainedAttempts = 0, cumulativeIncremental = 0, stopReason = 'FINITE_HORIZON', budgetAtInvestment = null;
  const pending = [], steps = [];
  const addStep = step => { if (keepTrace) steps.push(step); };
  addStep({kind: 'initialization', step: 0, initialCashCents: plan.initialCashCents,
    setupPaidCents: plan.commonSetupCents, closingCashCents: cash, earnedContributionCents: earned});
  for (let index = 1; index <= offered; index++) {
    const openingCash = cash;
    const due = pending.filter(row => row.dueStep <= index && !row.collected);
    const receiptsBefore = due.reduce((sum, row) => sum + row.amountCents, 0);
    for (const receipt of due) receipt.collected = true;
    cash += receiptsBefore; earned += receiptsBefore; totalCollected += receiptsBefore;
    const reserveExposure = Math.max(ordinaryCost, candidateCost) + (paidShock ? 0 : shock);
    const usedAsset = invested;
    const cost = usedAsset ? candidateCost : ordinaryCost;
    if (cash - reserveExposure < cost) {
      stopReason = 'CASH_EXHAUSTED_WITH_PROTECTED_RESERVE';
      addStep({kind: 'stopped', step: index, openingCashCents: openingCash,
        receiptsBeforeCents: receiptsBefore, reserveCents: reserveExposure,
        closingCashCents: cash, earnedContributionCents: earned});
      break;
    }
    attempted++;
    cash -= cost; earned -= cost; operating += cost;
    if (usedAsset) { retainedAttempts++; cumulativeIncremental += ordinaryCost - candidateCost; }
    const isAccepted = !(profile === 'failed-jobs' && index % plan.failedJobInterval === 0);
    let immediate = 0;
    if (isAccepted) {
      accepted++;
      if (delayJobs === 0) { immediate = price; cash += price; earned += price; totalCollected += price; }
      else pending.push({job: index, dueStep: index + delayJobs, amountCents: price, collected: false});
    }
    let thisShock = 0;
    if (usedAsset && shock && retainedAttempts === plan.maintenanceShockAtRetainedAttempt) {
      assert.ok(cash >= shock, 'Maintenance exposure was not reserved');
      thisShock = shock; cash -= shock; earned -= shock; paidShock += shock; cumulativeIncremental -= shock;
    }
    if (usedAsset && paybackAtJob === null && cumulativeIncremental > 0) paybackAtJob = index;
    let thisInvestment = 0;
    const remaining = offered - index;
    const terminalReserve = Math.max(ordinaryCost, candidateCost) + (paidShock ? 0 : shock);
    const fullFutureShock = remaining >= plan.maintenanceShockAtRetainedAttempt ? shock : 0;
    const prospectiveIncremental = remaining * (ordinaryCost - candidateCost) - investment - fullFutureShock;
    if (!invested && qualifies(metrics) && prospectiveIncremental > 0 && remaining > 0 &&
        Math.min(cash - terminalReserve, earned - terminalReserve) >= investment) {
      budgetAtInvestment = {cashCents: cash, earnedContributionCents: earned,
        protectedReserveCents: terminalReserve, prospectiveIncrementalCents: prospectiveIncremental};
      invested = true; investmentAtJob = index; thisInvestment = investment;
      cash -= investment; earned -= investment; paidInvestment += investment;
      cumulativeIncremental = -investment;
    }
    minCash = Math.min(minCash, cash);
    assert.ok(cash >= 0);
    addStep({kind: 'job', step: index, openingCashCents: openingCash,
      receiptsBeforeCents: receiptsBefore, immediateReceiptsCents: immediate,
      accepted: isAccepted, usedRetainedAsset: usedAsset, costCents: cost,
      maintenanceShockCents: thisShock, investmentPaidCents: thisInvestment,
      closingCashCents: cash, earnedContributionCents: earned,
      reserveCents: terminalReserve, cumulativeIncrementalCents: cumulativeIncremental});
  }
  const receivable = pending.filter(row => !row.collected).reduce((sum, row) => sum + row.amountCents, 0);
  const row = {...config, assetHash, offeredJobs: offered, attemptedJobs: attempted,
    acceptedJobs: accepted, rejectedJobs: attempted - accepted, initialCashCents: plan.initialCashCents,
    commonSetupPaidCents: plan.commonSetupCents, commonRecurringCentsPerAttempt: commonRecurring,
    ordinaryCostCentsPerAttempt: ordinaryCost,
    retainedCostCentsPerAttempt: candidateCost, modeledCollectedCents: totalCollected,
    pendingReceivablesCents: receivable, operatingPaidCents: operating,
    investmentPaidCents: paidInvestment, maintenanceShockPaidCents: paidShock,
    endingCashCents: cash, minimumCashCents: minCash, endingEarnedContributionCents: earned,
    investmentAtJob, retainedAttempts, firstStrictPaybackJob: paybackAtJob,
    terminalIncrementalBenefitCents: cumulativeIncremental,
    budgetAtInvestment, stopReason, technicalQualified: qualifies(metrics),
    modeledInvestmentOccurred: invested, actualCollections: null, actualEconomicAdmission: false,
    actualFinancialTransactions: 0, injectedCapitalAfterStartCents: 0,
    evidenceStatus: avoidedAttentionSeconds > 0 ? 'COUNTERFACTUAL_BENEFIT_NOT_ESTABLISHED' :
      'PRIMARY_NO_UNOBSERVED_ATTENTION_SAVING'};
  assert.equal(cash, plan.initialCashCents - plan.commonSetupCents + totalCollected - operating - paidInvestment - paidShock);
  assert.equal(earned, cash - plan.initialCashCents);
  return {row, steps, pending};
}

function canonicalTrace(projection) {
  const {row, steps} = projection;
  const reference = `Modeled bound only; tested asset ${row.assetHash}; actual collections unknown; ${row.evidenceStatus}`;
  const setup = planMission({missionId: 'accounting-setup', currency: 'USD', acceptance: 'accepted',
    reference: `${reference}; accounting anchor, not an additional customer job`,
    totalCollectedCents: null, priceAssumptionCents: 0, totalOperatingCostCents: row.commonSetupPaidCents,
    operatingCostsComplete: true, capabilityCostCents: 0, reserveCents: 0, obligationCents: 0});
  const events = [...setup.ledger.events];
  const jobs = steps.filter(step => step.kind === 'job');
  for (let index = 0; index < jobs.length; index++) {
    const job = jobs[index];
    const planned = planMission({missionId: `job-${job.step}`, currency: 'USD',
      acceptance: job.accepted ? 'accepted' : 'rejected', reference,
      totalCollectedCents: null, priceAssumptionCents: job.accepted ? toCents(row.priceUsd) : 0,
      totalOperatingCostCents: job.costCents + job.maintenanceShockCents,
      operatingCostsComplete: true, capabilityCostCents: job.investmentPaidCents,
      reserveCents: index === jobs.length - 1 ? job.reserveCents : 0, obligationCents: 0});
    events.push(...planned.ledger.events);
  }
  const ledger = {schema: 'alpha-shadow-ledger/v1', currency: 'USD', events};
  const summary = replayLedger(ledger, {reinvestmentBps: 0});
  assert.equal(summary.observed.availableSurplus, null);
  assert.equal(summary.scenario.fullCost,
    row.commonSetupPaidCents + row.operatingPaidCents + row.investmentPaidCents + row.maintenanceShockPaidCents);
  return {row, steps, pending: projection.pending, ledger, canonicalSummary: summary,
    distinction: 'Canonical scenario revenue contains assumed prices. Only the separate dated cash projection counts modeled payments when due. The setup anchor is not a unique customer job.'};
}

function csv(rows) {
  if (!rows.length) return '';
  const keys = Object.keys(rows[0]);
  const quote = value => {
    const text = value === null || value === undefined ? '' : typeof value === 'object' ? JSON.stringify(value) : String(value);
    return /[",\r\n]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
  };
  return [keys.join(','), ...rows.map(row => keys.map(key => quote(row[key])).join(','))].join('\n') + '\n';
}

function run(output, resultsPath) {
  const dependencyRecords = dependencies();
  const resultsBytes = readFileSync(resultsPath);
  const results = JSON.parse(resultsBytes.toString('utf8'));
  assert.equal(results.schema, 'funded-advantage-results/v1');
  assert.equal(results.uniqueJobs, 16);
  assert.ok(sameAcceptance(results.arms), 'Unequal acceptance requires a separately priced outcome-value model.');
  for (const arm of ['alpha', 'conventional']) {
    assert.equal(results.arms[arm].assetHash, hash(`candidates/${arm}/normalize.mjs`), 'Unbound asset identity');
  }
  const alphaBuild = read('candidates/alpha/construction.json');
  const conventionalBuild = read('candidates/conventional/construction.json');
  const buildObservations = {
    alpha: {elapsedSeconds: alphaBuild.timing.elapsed_seconds, attempts: alphaBuild.budget.attempts_used},
    conventional: {elapsedSeconds: conventionalBuild.elapsedConstructionSeconds, attempts: conventionalBuild.budget.candidatesUsed},
    ordinary: {elapsedSeconds: null, attempts: null, note: 'Assembly is real and chargeable. Complete elapsed/authoring cost not recorded by this economic analysis.'}
  };
  const observed = Object.fromEntries(['ordinary', 'alpha', 'conventional'].map(arm => [arm, observedRecord(arm)]));
  const modeled = Object.fromEntries(['alpha', 'conventional'].map(arm => [arm, modeledRecord(arm, results.arms[arm])]));
  const automatedSummaries = {
    observed: Object.fromEntries(Object.entries(observed).map(([key, record]) => [key, evaluateAutomatedCosts(record)])),
    modeled: Object.fromEntries(Object.entries(modeled).map(([key, record]) => [key, evaluateAutomatedCosts(record)]))
  };
  for (const record of Object.values(automatedSummaries.observed)) for (const scenario of record.scenarios) {
    assert.equal(scenario.costs.fullyLoadedMicrosPerAccepted, null);
    assert.equal(scenario.costs.marginalMicrosPerAccepted, null);
  }
  const frontiers = frontier(results), thresholds = humanThresholds(results), cashRows = [], cashTraces = [];
  for (const arm of ['alpha', 'conventional']) for (const horizon of plan.horizons)
    for (const investmentUsd of plan.completeIncrementalInvestmentUsd)
      for (const priceUsd of plan.sellingPriceUsd) for (const delayJobs of plan.collectionDelayJobs)
        for (const profile of plan.cashStressProfiles) for (const avoidedAttentionSeconds of plan.counterfactualCashAttentionSeconds) {
          const keep = horizon === plan.completeTraceSubset.horizon &&
            priceUsd === plan.completeTraceSubset.priceUsd && investmentUsd === plan.completeTraceSubset.investmentUsd;
          const projection = cashProjection(results,
            {arm, horizon, investmentUsd, priceUsd, delayJobs, profile, avoidedAttentionSeconds}, keep);
          cashRows.push(projection.row);
          if (keep) cashTraces.push(canonicalTrace(projection));
        }
  const primaryCash = cashRows.filter(row => row.avoidedAttentionSeconds === 0);
  assert.ok(primaryCash.every(row => !row.modeledInvestmentOccurred), 'Primary cash model unexpectedly promotes a dominated asset.');
  const priceGroups = new Map();
  for (const row of cashRows) {
    const key = [row.arm, row.horizon, row.investmentUsd, row.delayJobs, row.profile, row.avoidedAttentionSeconds].join('|');
    if (!priceGroups.has(key)) priceGroups.set(key, []);
    priceGroups.get(key).push(row);
  }
  const financingPrices = [...priceGroups.values()].map(group => {
    const first = group[0];
    const successful = group.filter(row => row.modeledInvestmentOccurred && row.terminalIncrementalBenefitCents > 0);
    return {arm: first.arm, assetHash: first.assetHash, horizon: first.horizon,
      investmentUsd: first.investmentUsd, delayJobs: first.delayJobs, profile: first.profile,
      avoidedAttentionSeconds: first.avoidedAttentionSeconds,
      testedPricesUsd: plan.sellingPriceUsd,
      lowestSuccessfulSampledPriceUsd: successful.length ? Math.min(...successful.map(row => row.priceUsd)) : null,
      exactPriceThresholdIdentified: false,
      interpretation: 'Grid-dependent financing threshold only. Price cancels from equal-acceptance incremental value; no customer willingness to pay is observed.'};
  });
  const summary = {
    schema: 'funded-advantage-economic-results/v1', currency: 'USD',
    inputResultsSha256: createHash('sha256').update(resultsBytes).digest('hex'),
    inputResultsSource: resultsPath, planSha256: hash('economics/PROTOCOL.json'),
    inputResults: results, buildObservations, dependencies: dependencyRecords,
    actualCollections: null, actualInvestableSurplus: null, actualFinancialTransactions: 0,
    measuredAvoidedProviderAttentionSeconds: null, primaryAssumedAvoidedProviderAttentionSeconds: 0,
    observedCompleteCostPerAccepted: {ordinary: null, alpha: null, conventional: null},
    observedEconomicAdmission: {ordinary: 'UNKNOWN_COMPLETE_COST', alpha: 'HOLD', conventional: 'HOLD'},
    counters: {frontierRows: frontiers.length, humanThresholdRows: thresholds.length,
      cashScenarios: cashRows.length, financingPriceGroups: financingPrices.length,
      completeCanonicalCashTraces: cashTraces.length,
      primaryCashScenarios: primaryCash.length,
      primaryInvestments: primaryCash.filter(row => row.modeledInvestmentOccurred).length,
      counterfactualInvestments: cashRows.filter(row => row.avoidedAttentionSeconds > 0 && row.modeledInvestmentOccurred).length,
      counterfactualTerminalPositive: cashRows.filter(row => row.avoidedAttentionSeconds > 0 &&
        row.modeledInvestmentOccurred && row.terminalIncrementalBenefitCents > 0).length,
      exhaustedScenarios: cashRows.filter(row => row.stopReason.startsWith('CASH_EXHAUSTED')).length},
    conclusion: 'All three arms support the finite acceptance contract. No recurring provider/customer attention reduction was measured. Ordinary has the fastest median end-to-end time in this recorded run. Full costs and real demand remain unknown; observed economic admission is HOLD. Positive financing paths require an explicit counterfactual recurring labor benefit and complete cost bounds, not demonstrated by this experiment.',
    caveats: [
      'The ordinary control was assembled for the study; it is not a historical no-investment experiment.',
      'Timing samples include cross-language IPC; ordering of means and medians differs, so no robust speed superiority is claimed.',
      'All grids beyond 16 source requests are modeled workloads, not additional executed unique customer jobs.',
      'The complete incremental investment envelope includes failed construction, integration, qualification and unknown authoring; shared ordinary assembly/setup and delivery/upkeep are separately charged.',
      'New cash assumptions are transparently exploratory post-outcome accounting. Original protocol grids retain their prior registration.',
      'No asset is financially or operationally promoted by these nontransactional calculations.'
    ]
  };
  mkdirSync(output, {recursive: true});
  const writeJSON = (name, value, pretty = false) => writeFileSync(resolve(output, name), JSON.stringify(value, null, pretty ? 2 : 0) + '\n');
  writeJSON('economics-summary.json', summary, true);
  writeJSON('economic-inputs.json', {plan, sources, buildObservations}, true);
  writeJSON('automated-cost-records.json', {observed, modeled}, true);
  writeJSON('automated-cost-summaries.json', automatedSummaries, true);
  writeJSON('frontier.json', frontiers);
  writeJSON('human-thresholds.json', thresholds);
  writeJSON('cash-outcomes.json', cashRows);
  writeJSON('cash-traces.json', cashTraces);
  writeJSON('financing-price-frontier.json', financingPrices);
  for (const [name, rows] of [['frontier', frontiers], ['human-thresholds', thresholds],
    ['cash-outcomes', cashRows], ['financing-price-frontier', financingPrices]])
    writeFileSync(resolve(output, `${name}.csv`), csv(rows));
  console.log(JSON.stringify({status: 'PASS', output, ...summary.counters,
    actualCollections: null, observedEconomicAdmission: summary.observedEconomicAdmission}));
}

const args = process.argv.slice(2);
if (args.length === 1 && args[0] === '--protocol-check') {
  dependencies();
  for (const arm of ['ordinary', 'alpha', 'conventional']) evaluateAutomatedCosts(observedRecord(arm));
  assert.equal(plan.primaryAvoidedProviderAttentionSeconds, 0);
  assert.equal(plan.actualCollections, null);
  assert.equal(calculateInvestment({constructionCostMinor: 100, failedConstructionCostMinor: 0,
    maintenancePerReuseMinor: 0, expectedSavingPerReuseMinor: 10, remainingReuses: 10}).netBenefit, 0);
  console.log(JSON.stringify({status: 'PASS', canonicalDependenciesUnchanged: true,
    unknownObservedCostsPreserved: true, observedAdmissionRequiresStrictlyPositiveCompleteValue: true}));
} else {
  assert.ok([2, 4].includes(args.length) && args[0] === '--out' && isAbsolute(args[1]) &&
    (args.length === 2 || (args[2] === '--results' && isAbsolute(args[3]))),
    'Usage: node economics/analyze.mjs --out /absolute/output [--results /absolute/summary.json] or --protocol-check');
  run(resolve(args[1]), args.length === 4 ? resolve(args[3]) : resolve(root, 'evidence/results/summary.json'));
}
