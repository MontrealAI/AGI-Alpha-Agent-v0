# Conventional retained inventory intake — version 1

This comparator adopts conventional parsing and validation methods. It makes no
algorithmic novelty or autonomous enterprise claim. The builder used the shared
prospective contract and four public development inventories. It did not inspect
the Alpha candidate or confirmatory inputs.

`normalize.mjs` is a standalone JavaScript ES module with no imports and no file,
network, subprocess or evaluation capability. It exports:

```js
normalize(text, format = 'auto')
```

The return value is `{format, rows}`. The format family is `json`, `csv` or
`sha256sum`; rows contain only `path` and lowercase `sha256`, ordered by Unicode
code points. It supports the four declared JSON inventory shapes, strict
two-column CSV and SHA256SUMS text/binary markers. A small recursive JSON reader
preserves duplicate-key detection before object construction, including inert
metadata. The CSV reader implements quoting and doubled quotes. Paths remain
exact and are never trimmed, normalized or deduplicated.

The shared boundary clarification is applied: JSON root depth is zero, children
increase depth by one, finite metadata numbers are allowed, decoded string/key
and numeric-literal scalar limits are enforced, C0/DEL/C1 and unpaired surrogates
are refused, and empty text is accepted only with explicit `sha256sum` format.

## Construction and development evidence

The construction window was 2026-10-25 23:52:21–23:55:11 UTC: 170 elapsed seconds,
within the shared 20-minute budget. Two candidates were used. The first passed
38 development checks but a separate self-authored probe found that JavaScript's
dot regex rejected U+2028 inside a valid checksum path. The second replaces that
dot with an explicit any-character class, retains path control validation, and
adds U+2028/U+2029 regression coverage. All 39 final checks pass, including the
four real development inputs. This repair preceded confirmation.

`construction.json` preserves the first candidate's complete source, its failing
probe and the final freeze identities. Model token usage, monetary inference
cost and full attributable human/research cost were not metered; they remain
unknown. The observed elapsed construction time is not a complete dollar cost.

Run the exact frozen development checks:

```sh
node studies/agi-alpha-funded-advantage-v1/candidates/conventional/development-tests.mjs
```

Runtime observed: Node.js 24.22.1. The normalizer uses JavaScript built-ins only;
the development tests use Node's built-in assert, fs and test modules. Test file
reads are confined to the four declared public development inputs.

Final normalizer SHA-256:
`ce44d675dc840b3bfd68e2bdb13d1aa5a5be230ff6a0318d430835a16826cb72`.

Final development-test SHA-256:
`19185fe29ca3a0f0d16fa666da713f73086f85f130440afe33439751f4710d27`.

The source and tests are frozen. Confirmation is owned by the independent
same-session evaluator. No confirmation-based repair, production promotion,
financial action or held execution route is authorized by this artifact.
