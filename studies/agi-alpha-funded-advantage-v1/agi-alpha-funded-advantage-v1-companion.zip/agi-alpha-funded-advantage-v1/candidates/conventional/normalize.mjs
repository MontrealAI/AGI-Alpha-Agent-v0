// SPDX-License-Identifier: Apache-2.0
const encoder = new TextEncoder();
const byteLength = text => encoder.encode(text).length;
const fail = message => { throw new Error(message); };
const own = (object, key) => Object.hasOwn(object, key);
const record = object => object !== null && typeof object === 'object' && !Array.isArray(object);

function scalar(text) {
  for (let i = 0; i < text.length; i++) {
    const code = text.charCodeAt(i);
    if (code >= 0xd800 && code <= 0xdbff) {
      const following = text.charCodeAt(++i);
      if (!(following >= 0xdc00 && following <= 0xdfff)) fail('Unpaired Unicode surrogate');
    } else if (code >= 0xdc00 && code <= 0xdfff) fail('Unpaired Unicode surrogate');
  }
  if (byteLength(text) > 64000) fail('Scalar exceeds 64000 UTF-8 bytes');
  return text;
}

function parseJSON(text) {
  let offset = 0;
  const whitespace = () => { while (/[\x20\t\r\n]/.test(text[offset] ?? '') && offset < text.length) offset++; };
  const string = () => {
    const begin = offset++;
    while (offset < text.length) {
      const character = text[offset++];
      if (character === '\\') offset++;
      else if (character === '"') return scalar(JSON.parse(text.slice(begin, offset)));
    }
    return fail('Unterminated JSON string');
  };
  const value = depth => {
    if (depth > 16) fail('JSON depth exceeds 16');
    whitespace();
    const character = text[offset];
    if (character === '"') return string();
    if (character === '{') {
      offset++;
      const output = Object.create(null), keys = new Set();
      whitespace();
      if (text[offset] === '}') { offset++; return output; }
      for (;;) {
        whitespace();
        if (text[offset] !== '"') fail('Expected JSON object key');
        const key = string();
        if (keys.has(key)) fail('Duplicate JSON key');
        keys.add(key);
        whitespace();
        if (text[offset++] !== ':') fail('Expected JSON colon');
        output[key] = value(depth + 1);
        whitespace();
        const separator = text[offset++];
        if (separator === '}') return output;
        if (separator !== ',') fail('Expected JSON object separator');
      }
    }
    if (character === '[') {
      offset++;
      const output = [];
      whitespace();
      if (text[offset] === ']') { offset++; return output; }
      for (;;) {
        output.push(value(depth + 1));
        whitespace();
        const separator = text[offset++];
        if (separator === ']') return output;
        if (separator !== ',') fail('Expected JSON array separator');
      }
    }
    for (const [literal, primitive] of [['true', true], ['false', false], ['null', null]]) {
      if (text.startsWith(literal, offset)) { offset += literal.length; return primitive; }
    }
    const number = /^-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?/.exec(text.slice(offset));
    if (!number) fail('Invalid JSON value');
    scalar(number[0]);
    offset += number[0].length;
    const parsed = Number(number[0]);
    if (!Number.isFinite(parsed)) fail('Nonfinite JSON number');
    return parsed;
  };
  const output = value(0);
  whitespace();
  if (offset !== text.length) fail('Trailing JSON input');
  return output;
}

function pathValue(path) {
  if (typeof path !== 'string') fail('Path must be a string');
  scalar(path);
  if (!path || path.startsWith('/') || /[\\\u0000-\u001f\u007f-\u009f]/u.test(path) ||
      /^[A-Za-z][A-Za-z0-9+.-]*:/.test(path) || path.split('/').some(part => !part || part === '.' || part === '..'))
    fail('Unsupported relative path');
  return path;
}

function jsonRows(text) {
  const root = parseJSON(text);
  if (!record(root)) fail('JSON inventory root must be an object');
  const roots = ['sources', 'files', 'authoritativeArtifacts'].filter(key => own(root, key));
  if (roots.length !== 1) fail('Expected exactly one inventory root');
  let base = own(root, 'pathBase') ? root.pathBase : '';
  if (typeof base !== 'string') fail('pathBase must be a string');
  if (base.endsWith('/')) base = base.slice(0, -1);
  if (base) pathValue(base);
  else if (own(root, 'pathBase') && root.pathBase !== '') fail('Invalid pathBase');
  const name = roots[0], inventory = root[name];
  let rows;
  if (name === 'sources') {
    if (!record(inventory)) fail('sources must be a map');
    rows = Object.entries(inventory).map(([path, sha256]) => ({path, sha256}));
  } else if (Array.isArray(inventory)) {
    rows = inventory.map(row => {
      if (!record(row) || !own(row, 'path') || !own(row, 'sha256')) fail('Invalid array inventory row');
      return {path: row.path, sha256: row.sha256};
    });
  } else if (name === 'files' && record(inventory)) {
    rows = Object.entries(inventory).map(([path, row]) => {
      if (!record(row) || !own(row, 'sha256')) fail('Invalid files inventory row');
      return {path, sha256: row.sha256};
    });
  } else fail('Unsupported inventory shape');
  return rows.map(({path, sha256}) => ({path: base ? `${base}/${pathValue(path)}` : path, sha256}));
}

function csvRows(text) {
  let offset = 0;
  const rows = [];
  if (!text) fail('Missing CSV header');
  while (offset < text.length) {
    const row = [];
    for (;;) {
      let field = '';
      if (text[offset] === '"') {
        offset++;
        let closed = false;
        while (offset < text.length) {
          const character = text[offset++];
          if (character !== '"') field += character;
          else if (text[offset] === '"') { field += '"'; offset++; }
          else { closed = true; break; }
        }
        if (!closed) fail('Unclosed CSV quote');
      } else {
        while (offset < text.length && !',\r\n'.includes(text[offset])) {
          if (text[offset] === '"') fail('Quote inside unquoted CSV field');
          field += text[offset++];
        }
      }
      row.push(scalar(field));
      if (text[offset] === ',') { offset++; continue; }
      if (offset < text.length && text[offset] !== '\r' && text[offset] !== '\n') fail('Data after CSV quote');
      if (text[offset] === '\r') {
        if (text[offset + 1] !== '\n') fail('Lone CSV carriage return');
        offset += 2;
      } else if (text[offset] === '\n') offset++;
      break;
    }
    if (row.length !== 2) fail('CSV requires exactly two columns');
    rows.push(row);
    if (rows.length > 129) fail('Too many CSV rows');
  }
  if (rows[0][0] !== 'path' || rows[0][1] !== 'sha256') fail('CSV header must be path,sha256');
  return rows.slice(1).map(([path, sha256]) => ({path, sha256}));
}

function checksumRows(text) {
  if (!text) return [];
  const lines = text.split(/\r?\n/);
  if (lines.at(-1) === '') lines.pop();
  if (lines.length > 128) fail('Too many checksum rows');
  return lines.map(line => {
    const match = /^([0-9a-fA-F]{64}) (?: |\*)([\s\S]*)$/u.exec(line);
    if (!match) fail('Invalid SHA256SUMS line');
    return {path: match[2], sha256: match[1]};
  });
}

function codePointOrder(left, right) {
  const a = Array.from(left.path, character => character.codePointAt(0));
  const b = Array.from(right.path, character => character.codePointAt(0));
  for (let i = 0; i < Math.min(a.length, b.length); i++) if (a[i] !== b[i]) return a[i] - b[i];
  return a.length - b.length;
}

function checkedRows(rows) {
  if (rows.length > 128) fail('Inventory exceeds 128 rows');
  const seen = new Set();
  const output = rows.map(({path, sha256}) => {
    pathValue(path);
    if (seen.has(path)) fail('Duplicate final path');
    seen.add(path);
    if (typeof sha256 !== 'string' || !/^[0-9a-fA-F]{64}$/.test(sha256)) fail('Invalid SHA-256');
    return {path, sha256: sha256.toLowerCase()};
  });
  return output.sort(codePointOrder);
}

export function normalize(text, format = 'auto') {
  if (typeof text !== 'string' || !['auto', 'json', 'csv', 'sha256sum'].includes(format)) fail('Invalid normalize input');
  if (byteLength(text) > 1000000) fail('Input exceeds 1000000 UTF-8 bytes');
  const parsers = {json: jsonRows, csv: csvRows, sha256sum: checksumRows};
  if (format !== 'auto') return {format, rows: checkedRows(parsers[format](text))};
  if (!text.trim()) fail('Cannot infer empty input format');
  const candidates = [];
  for (const [name, parser] of Object.entries(parsers)) {
    try { candidates.push({format: name, rows: checkedRows(parser(text))}); } catch { /* Invalid format candidate. */ }
  }
  if (candidates.length !== 1) fail('Unrecognized or ambiguous input format');
  return candidates[0];
}
