// SPDX-License-Identifier: Apache-2.0
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import test from 'node:test';
import {normalize} from './normalize.mjs';

const digest = 'A'.repeat(64), lower = digest.toLowerCase();
for (let index = 1; index <= 4; index++) {
  test(`public development inventory ${index}`, () => {
    const text = readFileSync(new URL(`../../development/dev-${index}.json`, import.meta.url), 'utf8');
    const parsed = JSON.parse(text), base = parsed.pathBase ? `${parsed.pathBase.replace(/\/$/, '')}/` : '';
    const expected = parsed.sources ? Object.entries(parsed.sources).map(([path, sha256]) => ({path, sha256})) :
      Array.isArray(parsed.files) ? parsed.files.map(({path, sha256}) => ({path, sha256})) :
      parsed.authoritativeArtifacts ? parsed.authoritativeArtifacts.map(({path, sha256}) => ({path, sha256})) :
      Object.entries(parsed.files).map(([path, item]) => ({path, sha256: item.sha256}));
    const reference = expected.map(row => ({path: base + row.path, sha256: row.sha256.toLowerCase()}))
      .sort((a, b) => a.path < b.path ? -1 : a.path > b.path ? 1 : 0);
    assert.deepEqual(normalize(text), {format: 'json', rows: reference});
  });
}

test('CSV preserves quoting, commas, whitespace, exact case and hashes', () => {
  const text = `"path","sha256"\r\n"A, ""quoted"".txt",${digest}\r\n a.txt ,${lower}\r\n`;
  assert.deepEqual(normalize(text), {format: 'csv', rows: [
    {path: ' a.txt ', sha256: lower}, {path: 'A, "quoted".txt', sha256: lower}
  ]});
});
test('SHA256SUMS accepts text/binary markers without trimming names', () => {
  assert.deepEqual(normalize(`${digest} *b\n${lower}   a \n`), {format: 'sha256sum', rows: [
    {path: ' a ', sha256: lower}, {path: 'b', sha256: lower}
  ]});
});
test('Unicode line separators are exact non-control path characters', () => {
  assert.deepEqual(normalize(`${digest}  a\u2028b\n`, 'sha256sum').rows, [{path: 'a\u2028b', sha256: lower}]);
  assert.deepEqual(normalize(`${digest}  a\u2029b\n`).rows, [{path: 'a\u2029b', sha256: lower}]);
});
test('empty inventories are valid and auto-empty is refused', () => {
  for (const text of ['{"sources":{}}', '{"files":{}}', '{"files":[]}', '{"authoritativeArtifacts":[]}'])
    assert.deepEqual(normalize(text).rows, []);
  assert.deepEqual(normalize('path,sha256\n').rows, []);
  assert.deepEqual(normalize('', 'sha256sum').rows, []);
  assert.throws(() => normalize(''));
});
test('pathBase and Unicode code-point ordering', () => {
  const text = JSON.stringify({files: [{path: '\u{10000}', sha256: digest}, {path: '\ue000', sha256: digest}], pathBase: 'repo/'});
  assert.deepEqual(normalize(text).rows.map(row => row.path), ['repo/\ue000', 'repo/\u{10000}']);
});
test('ordinary finite decimal metadata and safe literal prototype keys', () => {
  const text = `{"sources":{"__proto__":"${digest}"},"metadata":{"constructor":1.23e-4,"__proto__":null,"negative":-0.3}}`;
  assert.deepEqual(normalize(text).rows, [{path: '__proto__', sha256: lower}]);
});
test('JSON nesting and scalar limits accepted exactly and rejected above', () => {
  const nested = depth => JSON.stringify({sources: {}, meta: JSON.parse('['.repeat(depth) + '0' + ']'.repeat(depth))});
  assert.deepEqual(normalize(nested(15)).rows, []);
  assert.throws(() => normalize(nested(16)));
  assert.deepEqual(normalize(JSON.stringify({sources: {}, meta: 'x'.repeat(64000)})).rows, []);
  assert.throws(() => normalize(JSON.stringify({sources: {}, meta: 'x'.repeat(64001)})));
});
test('row count limit includes every row without truncation', () => {
  const rows = count => JSON.stringify({files: Array.from({length: count}, (_, i) => ({path: `x/${i}`, sha256: digest}))});
  assert.equal(normalize(rows(128)).rows.length, 128);
  assert.throws(() => normalize(rows(129)));
});

const refuse = [
  ['duplicate key in metadata', `{"sources":{},"meta":{"x":1,"x":2}}`],
  ['escaped duplicate key', '{"sources":{},"meta":{"x":1,"\\u0078":2}}'],
  ['ambiguous inventory roots', '{"sources":{},"files":[]}'],
  ['wrong SHA identity', '{"files":[{"path":"a","gitBlob":"' + 'a'.repeat(40) + '"}]}'],
  ['duplicate paths', JSON.stringify({files: [{path: 'a', sha256: digest}, {path: 'a', sha256: digest}]})],
  ['absolute path', JSON.stringify({sources: {'/a': digest}})],
  ['parent path', JSON.stringify({sources: {'a/../b': digest}})],
  ['empty segment', JSON.stringify({sources: {'a//b': digest}})],
  ['backslash', JSON.stringify({sources: {'a\\b': digest}})],
  ['drive prefix', JSON.stringify({sources: {'C:a': digest}})],
  ['URL prefix', JSON.stringify({sources: {'https://a': digest}})],
  ['C1 control', JSON.stringify({sources: {'a\u0085b': digest}})],
  ['unpaired surrogate', '{"sources":{"a\\ud800":"' + digest + '"}}'],
  ['invalid base', JSON.stringify({sources: {}, pathBase: '/'})],
  ['double base terminator', JSON.stringify({sources: {}, pathBase: 'repo//'})],
  ['nonfinite metadata', '{"sources":{},"meta":1e999}'],
  ['JSON trailing comma', '{"sources":{},}'],
  ['CSV column excess', `path,sha256\na,${digest},extra`],
  ['CSV duplicate', `path,sha256\na,${digest}\na,${digest}`],
  ['CSV quote junk', `path,sha256\n"a"x,${digest}`],
  ['CSV unquoted quote', `path,sha256\na"b,${digest}`],
  ['CSV path newline', `path,sha256\n"a\nb",${digest}`],
  ['CSV blank data row', 'path,sha256\n\n'],
  ['GNU escaped syntax', `\\${digest}  a\\nb`],
  ['SHA256SUMS blank data row', `${digest}  a\n\n`],
  ['nonhex digest', `path,sha256\na,${'g'.repeat(64)}`],
  ['oversized input', 'x'.repeat(1000001)]
];
for (const [name, text] of refuse) test(`refuse ${name}`, () => assert.throws(() => normalize(text)));
