# Alpha inventory intake candidate — version 1.0.0

This retained executable integrates conventional bounded JSON, CSV and
SHA256SUMS parsing with the prospective release-inventory contract. Its only
export is `normalize(text, format = 'auto')`, returning `{format, rows}`. The
format label is `json`, `csv` or `sha256sum`; each sorted row contains exactly
`path` and `sha256`.

The module has no imports and reads no named source. It does not execute source,
contact a network, mutate an installed runtime, or make an admission decision.
It can be bundled into the existing local Alpha experience after normal review.
An accepted inventory verifies declared identities, not the safety or behavior
of files that the inventory names.

The implementation uses a duplicate-aware JSON parser, strict two-column CSV
state machine, ordinary SHA256SUMS line parser, explicit path checks and Unicode
code-point ordering. The JSON parser accepts finite numeric metadata while
refusing duplicate keys at every depth. Input and scalar limits fail closed.
Per the prospective clarification, root JSON depth is zero and every child
value increments depth; C0, DEL and C1 controls and unpaired surrogates refuse.
Header-only CSV and explicitly selected empty SHA256SUMS inventories are valid;
empty automatic input refuses. CSV accepts LF and CRLF record separators, with
RFC4180 doubled-quote escaping; newline-containing paths still refuse.

The research model authored this implementation from the shared frozen contract
and four supplied public development inventories. This is adoption and
integration of standard methods, without a claim of algorithmic invention or
economic superiority. No confirmation inputs or conventional-builder files
were inspected. Unknown authoring-token counts, inference bill and human effort
remain unknown. Elapsed construction time is not measured active human labor.

Run development checks from any directory:

```sh
node studies/agi-alpha-funded-advantage-v1/candidates/alpha/development-tests.mjs
```

The suite binds the four public inputs by SHA256, checks all their rows through
JSON and derived CSV/SHA256SUMS representations, and exercises authored boundary
and refusal cases. This is development evidence, not untouched confirmation.
`construction.json` records the bounded attempt, outcomes and frozen source
identities. Confirmation must use these frozen bytes without repairs.
