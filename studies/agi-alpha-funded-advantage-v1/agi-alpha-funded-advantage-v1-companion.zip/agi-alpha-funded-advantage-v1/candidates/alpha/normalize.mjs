// SPDX-License-Identifier: Apache-2.0
// Version 1.0.0. Conventional bounded parsing; no source acquisition or execution.

const INPUT_LIMIT = 1_000_000;
const SCALAR_LIMIT = 64_000;
const ROW_LIMIT = 128;
const DEPTH_LIMIT = 16;
const encoder = new TextEncoder();
const own = (object, key) => Object.prototype.hasOwnProperty.call(object, key);
const record = (value) => value !== null && typeof value === 'object' && !Array.isArray(value);

function refuse(code, detail = '') {
  const error = new Error(detail ? `${code}: ${detail}` : code);
  error.name = 'InventoryInputError';
  error.code = code;
  throw error;
}

function unicode(value) {
  for (let i = 0; i < value.length; i += 1) {
    const code = value.charCodeAt(i);
    if (code >= 0xd800 && code <= 0xdbff) {
      const next = value.charCodeAt(i + 1);
      if (!(next >= 0xdc00 && next <= 0xdfff)) refuse('UNPAIRED_SURROGATE');
      i += 1;
    } else if (code >= 0xdc00 && code <= 0xdfff) {
      refuse('UNPAIRED_SURROGATE');
    }
  }
}

function scalar(value) {
  unicode(value);
  if (value.length > SCALAR_LIMIT || encoder.encode(value).length > SCALAR_LIMIT) {
    refuse('SCALAR_LIMIT');
  }
  return value;
}

// Every JSON value has a depth; the root is depth zero. A separate object-key
// set catches both literal and escape-equivalent duplicates before assignment.
function parseJson(text) {
  let position = 0;
  const space = () => {
    while (position < text.length && /[\x20\x09\x0a\x0d]/u.test(text[position])) position += 1;
  };
  function string() {
    const start = position;
    if (text[position] !== '"') refuse('JSON_STRING');
    position += 1;
    while (position < text.length) {
      const char = text[position];
      if (char === '"') {
        position += 1;
        let decoded;
        try { decoded = JSON.parse(text.slice(start, position)); }
        catch { refuse('JSON_STRING'); }
        return scalar(decoded);
      }
      if (char.charCodeAt(0) < 0x20) refuse('JSON_STRING_CONTROL');
      position += char === '\\' ? 2 : 1;
    }
    refuse('JSON_UNTERMINATED_STRING');
  }
  function value(depth) {
    if (depth > DEPTH_LIMIT) refuse('JSON_DEPTH_LIMIT');
    space();
    const char = text[position];
    if (char === '"') return string();
    if (char === '{') {
      position += 1;
      const result = Object.create(null);
      const keys = new Set();
      space();
      if (text[position] === '}') { position += 1; return result; }
      while (true) {
        space();
        const key = string();
        if (keys.has(key)) refuse('JSON_DUPLICATE_KEY');
        keys.add(key);
        space();
        if (text[position] !== ':') refuse('JSON_COLON');
        position += 1;
        result[key] = value(depth + 1);
        space();
        if (text[position] === '}') { position += 1; return result; }
        if (text[position] !== ',') refuse('JSON_OBJECT_SEPARATOR');
        position += 1;
      }
    }
    if (char === '[') {
      position += 1;
      const result = [];
      space();
      if (text[position] === ']') { position += 1; return result; }
      while (true) {
        result.push(value(depth + 1));
        space();
        if (text[position] === ']') { position += 1; return result; }
        if (text[position] !== ',') refuse('JSON_ARRAY_SEPARATOR');
        position += 1;
      }
    }
    for (const [token, result] of [['true', true], ['false', false], ['null', null]]) {
      if (text.startsWith(token, position)) { position += token.length; return result; }
    }
    const number = text.slice(position).match(/^-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?/u);
    if (!number) refuse('JSON_VALUE');
    if (number[0].length > SCALAR_LIMIT) refuse('SCALAR_LIMIT');
    position += number[0].length;
    const parsed = Number(number[0]);
    if (!Number.isFinite(parsed)) refuse('JSON_NONFINITE_NUMBER');
    return parsed;
  }
  const result = value(0);
  space();
  if (position !== text.length) refuse('JSON_TRAILING_CONTENT');
  return result;
}

function path(value) {
  if (typeof value !== 'string') refuse('PATH_TYPE');
  scalar(value);
  if (!value || value.startsWith('/') || value.includes('\\')) refuse('PATH_SYNTAX');
  if (/[\u0000-\u001f\u007f-\u009f]/u.test(value)) refuse('PATH_CONTROL');
  if (/^[a-z][a-z0-9+.-]*:/iu.test(value)) refuse('PATH_PREFIX');
  if (value.split('/').some((part) => !part || part === '.' || part === '..')) refuse('PATH_SEGMENT');
  return value;
}

function codePointOrder(left, right) {
  let i = 0;
  let j = 0;
  while (i < left.length && j < right.length) {
    const a = left.codePointAt(i);
    const b = right.codePointAt(j);
    if (a !== b) return a - b;
    i += a > 0xffff ? 2 : 1;
    j += b > 0xffff ? 2 : 1;
  }
  return i === left.length ? (j === right.length ? 0 : -1) : 1;
}

function finish(entries, base = '') {
  if (typeof base !== 'string') refuse('PATH_BASE_TYPE');
  if (base !== '') {
    if (base.startsWith('/')) refuse('PATH_BASE_ABSOLUTE');
    if (base.endsWith('/')) base = base.slice(0, -1);
    path(base);
  }
  if (entries.length > ROW_LIMIT) refuse('ROW_LIMIT');
  const seen = new Set();
  const rows = entries.map(([original, hash]) => {
    path(original);
    const final = path(base ? `${base}/${original}` : original);
    if (seen.has(final)) refuse('DUPLICATE_PATH');
    seen.add(final);
    if (typeof hash !== 'string' || !/^[0-9a-f]{64}$/iu.test(hash)) refuse('SHA256');
    return { path: final, sha256: hash.toLowerCase() };
  });
  rows.sort((a, b) => codePointOrder(a.path, b.path));
  return rows;
}

function json(text) {
  const root = parseJson(text);
  if (!record(root)) refuse('JSON_ROOT');
  const roots = ['sources', 'files', 'authoritativeArtifacts'].filter((key) => own(root, key));
  if (roots.length !== 1) refuse('JSON_INVENTORY_ROOT');
  const kind = roots[0];
  const inventory = root[kind];
  let entries;
  if (kind === 'sources') {
    if (!record(inventory)) refuse('SOURCES_TYPE');
    entries = Object.entries(inventory);
  } else if (Array.isArray(inventory)) {
    entries = inventory.map((entry) => {
      if (!record(entry) || !own(entry, 'path') || !own(entry, 'sha256')) refuse('FILE_ENTRY');
      return [entry.path, entry.sha256];
    });
  } else if (kind === 'files' && record(inventory)) {
    entries = Object.entries(inventory).map(([name, entry]) => {
      if (!record(entry) || !own(entry, 'sha256')) refuse('FILE_ENTRY');
      return [name, entry.sha256];
    });
  } else {
    refuse('INVENTORY_TYPE');
  }
  return finish(entries, own(root, 'pathBase') ? root.pathBase : '');
}

function csv(text) {
  const records = [];
  let position = 0;
  function field() {
    let decoded = '';
    if (text[position] === '"') {
      position += 1;
      let closed = false;
      while (position < text.length) {
        const char = text[position++];
        if (char !== '"') { decoded += char; continue; }
        if (text[position] === '"') { decoded += '"'; position += 1; continue; }
        closed = true;
        break;
      }
      if (!closed) refuse('CSV_UNTERMINATED_QUOTE');
    } else {
      const start = position;
      while (position < text.length && !',\r\n'.includes(text[position])) {
        if (text[position] === '"') refuse('CSV_UNQUOTED_QUOTE');
        position += 1;
      }
      decoded = text.slice(start, position);
    }
    return scalar(decoded);
  }
  while (position < text.length) {
    const row = [];
    while (true) {
      row.push(field());
      if (row.length > 2) refuse('CSV_COLUMNS');
      if (text[position] === ',') { position += 1; continue; }
      if (position === text.length) break;
      if (text[position] === '\n') { position += 1; break; }
      if (text[position] === '\r' && text[position + 1] === '\n') { position += 2; break; }
      refuse('CSV_SEPARATOR');
    }
    if (row.length !== 2) refuse('CSV_COLUMNS');
    records.push(row);
    if (records.length > ROW_LIMIT + 1) refuse('ROW_LIMIT');
  }
  if (records.length === 0 || records[0][0] !== 'path' || records[0][1] !== 'sha256') refuse('CSV_HEADER');
  return finish(records.slice(1));
}

function sha256sum(text) {
  if (text === '') return [];
  const lines = text.split(/\r?\n/u);
  if (lines[lines.length - 1] === '') lines.pop();
  if (lines.length > ROW_LIMIT) refuse('ROW_LIMIT');
  const entries = lines.map((line) => {
    const match = /^([0-9a-f]{64}) (?: |\*)(.*)$/iu.exec(line);
    if (!match) refuse('SHA256SUM_LINE');
    return [match[2], match[1]];
  });
  return finish(entries);
}

/** Normalize a bounded inventory without reading any named source. */
export function normalize(text, format = 'auto') {
  if (typeof text !== 'string') refuse('INPUT_TYPE');
  if (!['auto', 'json', 'csv', 'sha256sum'].includes(format)) refuse('FORMAT');
  unicode(text);
  if (text.length > INPUT_LIMIT || encoder.encode(text).length > INPUT_LIMIT) refuse('INPUT_LIMIT');
  const parsers = { json, csv, sha256sum };
  if (format !== 'auto') return { format, rows: parsers[format](text) };
  if (text === '') refuse('AUTO_EMPTY');
  const accepted = [];
  for (const [family, parser] of Object.entries(parsers)) {
    try { accepted.push({ format: family, rows: parser(text) }); }
    catch (error) { if (error.name !== 'InventoryInputError') throw error; }
  }
  if (accepted.length !== 1) refuse(accepted.length > 1 ? 'AUTO_AMBIGUOUS' : 'AUTO_UNRECOGNIZED');
  return accepted[0];
}
