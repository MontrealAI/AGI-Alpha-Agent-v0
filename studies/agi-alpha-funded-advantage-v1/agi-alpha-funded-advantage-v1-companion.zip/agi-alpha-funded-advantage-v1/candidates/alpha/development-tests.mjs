// SPDX-License-Identifier: Apache-2.0
// Development-only checks; this file never loads confirmation or another builder.
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { normalize } from './normalize.mjs';

const began = new Date().toISOString();
const results = [];
const hash = 'a'.repeat(64);
const other = 'b'.repeat(64);
const check = (name, fn) => {
  try { fn(); results.push({ name, passed: true }); }
  catch (error) { results.push({ name, passed: false, error: String(error.stack ?? error) }); }
};
const reject = (name, text, format = 'auto') => check(name, () => assert.throws(() => normalize(text, format)));
const json = (sources, metadata = {}) => JSON.stringify({ sources, ...metadata });
const expectedInputs = [
  [1, 8, '1ec3a1fbbf5a8a7b72909d12a1aa99b118e33857e70ea56e7e00b7ad789d3aee'],
  [2, 33, '67166aff67f9dfbb1dc49dde51e053ac5bf0f4ce44411cc14c4251cf979954ef'],
  [3, 55, 'e29a6b5282b0e06a21f0ad999b9053359b573ba058c3e9469f5341667f6909dd'],
  [4, 45, '8e4c49686ac76530a172c3055847d7354e0c5b8f14cdb8e25b3e2c93672d5292'],
];

for (const [id, count, sha256] of expectedInputs) {
  check(`public-development-${id}`, () => {
    const bytes = readFileSync(new URL(`../../development/dev-${id}.json`, import.meta.url));
    assert.equal(createHash('sha256').update(bytes).digest('hex'), sha256);
    const input = JSON.parse(bytes.toString('utf8'));
    const inventory = input.sources ?? input.files ?? input.authoritativeArtifacts;
    const pairs = Array.isArray(inventory)
      ? inventory.map((entry) => [entry.path, entry.sha256])
      : Object.entries(inventory).map(([name, value]) => [name, typeof value === 'string' ? value : value.sha256]);
    const prefix = input.pathBase ? `${input.pathBase.replace(/\/$/u, '')}/` : '';
    // All four supplied inventories use ASCII paths, so ordinary sort suffices here.
    const expected = pairs.map(([name, sha]) => ({ path: prefix + name, sha256: sha.toLowerCase() }))
      .sort((a, b) => a.path < b.path ? -1 : a.path > b.path ? 1 : 0);
    assert.equal(expected.length, count);
    assert.deepEqual(normalize(bytes.toString('utf8')), { format: 'json', rows: expected });
    assert.deepEqual(normalize(bytes.toString('utf8'), 'json').rows, expected);
    const quote = (value) => `"${value.replaceAll('"', '""')}"`;
    const csv = `path,sha256\r\n${expected.map((row) => `${quote(row.path)},${row.sha256}`).join('\r\n')}\r\n`;
    assert.deepEqual(normalize(csv).rows, expected);
    const sums = expected.map((row) => `${row.sha256} *${row.path}`).join('\n');
    assert.deepEqual(normalize(sums).rows, expected);
  });
}

check('empty-inventories', () => {
  for (const input of [{ sources: {} }, { files: {} }, { files: [] }, { authoritativeArtifacts: [] }]) {
    assert.deepEqual(normalize(JSON.stringify(input)), { format: 'json', rows: [] });
  }
  assert.deepEqual(normalize('path,sha256\n'), { format: 'csv', rows: [] });
  assert.deepEqual(normalize('', 'sha256sum'), { format: 'sha256sum', rows: [] });
});
check('metadata-finite-numbers', () => {
  assert.equal(normalize(json({ a: hash }, { metadata: [0, -1.25e9, 1e-9, true, null] })).rows.length, 1);
});
check('unicode-code-point-order-and-exact-paths', () => {
  const names = ['\u{10000}', '\ue000', 'é', 'e\u0301', 'A', 'a', ' x '];
  const actual = normalize(json(Object.fromEntries(names.map((name) => [name, hash.toUpperCase()]))));
  assert.deepEqual(actual.rows.map((row) => row.path), [' x ', 'A', 'a', 'e\u0301', 'é', '\ue000', '\u{10000}']);
  assert(actual.rows.every((row) => row.sha256 === hash));
});
check('prototype-names-are-ordinary-own-keys', () => {
  assert.deepEqual(normalize(`{"sources":{"__proto__":"${hash}","constructor":"${other}"}}`).rows,
    [{ path: '__proto__', sha256: hash }, { path: 'constructor', sha256: other }]);
});
check('path-base-and-csv-quoting', () => {
  assert.equal(normalize(json({ 'part, "one".txt': hash }, { pathBase: 'release/' })).rows[0].path, 'release/part, "one".txt');
  assert.deepEqual(normalize(`"path","sha256"\r\n"part, ""one"".txt",${hash}\r\n`).rows,
    [{ path: 'part, "one".txt', sha256: hash }]);
  assert.equal(normalize(json({ a: hash }, { pathBase: '' })).rows[0].path, 'a');
});
check('limits-inclusive', () => {
  assert.equal(normalize(json(Object.fromEntries(Array.from({ length: 128 }, (_, i) => [`p${i}`, hash])))).rows.length, 128);
  assert.equal(normalize(json({ ['é'.repeat(32_000)]: hash })).rows[0].path.length, 32_000);
  let nested = null;
  for (let i = 0; i < 15; i += 1) nested = [nested];
  assert.equal(normalize(json({}, { metadata: nested })).rows.length, 0);
  const compact = json({});
  assert.equal(normalize(compact + ' '.repeat(1_000_000 - compact.length), 'json').rows.length, 0);
});

reject('auto-empty', '');
reject('unknown-format', json({}), 'yaml');
reject('non-string-input', { sources: {} });
reject('unknown-json-root', '{"inventory":[]}');
reject('ambiguous-json-roots', '{"sources":{},"files":[]}');
reject('duplicate-root-key', '{"sources":{},"sources":{}}');
reject('duplicate-metadata-key', '{"sources":{},"meta":{"x":1,"x":2}}');
reject('escape-equivalent-key', '{"sources":{},"meta":{"a":1,"\\u0061":2}}');
reject('duplicate-array-path', JSON.stringify({ files: [{ path: 'a', sha256: hash }, { path: 'a', sha256: other }] }));
reject('git-blob-is-not-sha256', JSON.stringify({ files: [{ path: 'a', gitBlob: 'a'.repeat(40) }] }));
reject('malformed-hash', json({ a: 'a'.repeat(63) }));
reject('hash-whitespace', json({ a: `${hash} ` }));
reject('null-file-entry', '{"files":{"a":null}}');
reject('scalar-path-base', json({ a: hash }, { pathBase: 123 }));
reject('absolute-path-base', json({ a: hash }, { pathBase: '/' }));
reject('multiple-base-trailing-slashes', json({ a: hash }, { pathBase: 'root//' }));
for (const [name, invalid] of [
  ['empty', ''], ['absolute', '/a'], ['backslash', 'a\\b'], ['empty-segment', 'a//b'],
  ['dot', './a'], ['dotdot', 'a/../b'], ['url', 'https://example/a'], ['drive', 'C:a'],
  ['nul', 'a\0b'], ['del', 'a\x7fb'], ['c1', 'a\u0085b'], ['newline', 'a\nb'],
]) reject(`path-${name}`, json({ [invalid]: hash }));
reject('json-unpaired-surrogate', `{"sources":{"\\ud800":"${hash}"}}`);
reject('literal-unpaired-surrogate', `path,sha256\n\udc00,${hash}`);
reject('metadata-nonfinite-number', '{"sources":{},"metadata":1e400}');
reject('json-trailing-comma', '{"sources":{},}');
reject('json-trailing-content', '{"sources":{}} false');
reject('json-invalid-number', '{"sources":{},"metadata":01}');
reject('json-invalid-escape', '{"sources":{},"metadata":"\\x20"}');
reject('json-depth-limit', json({}, { metadata: Array.from({ length: 16 }).reduce((value) => [value], null) }));
reject('decoded-string-limit', json({}, { metadata: 'é'.repeat(32_001) }));
reject('number-literal-limit', '{"sources":{},"metadata":0.' + '0'.repeat(64_000) + '}');
reject('input-byte-limit', ' '.repeat(1_000_001), 'json');
reject('row-limit', json(Object.fromEntries(Array.from({ length: 129 }, (_, i) => [`p${i}`, hash]))));
reject('csv-extra-column', `path,sha256\na,${hash},oops`);
reject('csv-wrong-header', `name,sha256\na,${hash}`);
reject('csv-unquoted-quote', `path,sha256\na"b,${hash}`);
reject('csv-unclosed-quote', `path,sha256\n"a,${hash}`);
reject('csv-after-quote', `path,sha256\n"a"x,${hash}`);
reject('csv-blank-record', `path,sha256\na,${hash}\n\n`);
reject('csv-bare-carriage-return', `path,sha256\ra,${hash}`);
reject('csv-quoted-path-newline', `path,sha256\n"a\nb",${hash}`);
reject('sums-gnu-escape', `\\${hash}  a\\nb`);
reject('sums-single-separator', `${hash} a`);
reject('sums-blank-line', `${hash}  a\n\n`);
reject('sums-duplicate-path', `${hash}  a\n${other} *a`);

const failed = results.filter((result) => !result.passed);
console.log(JSON.stringify({ schema: 'funded-advantage-development-checks/v1', candidate: 'alpha',
  began, ended: new Date().toISOString(), checks: results.length, passed: results.length - failed.length,
  failed: failed.length, results }, null, 2));
if (failed.length) process.exitCode = 1;
