# SPDX-License-Identifier: Apache-2.0
"""Independent finite audit. Run: python -B audit/independent_check.py.

No source mutation; writes a report only when --output PATH is supplied.
The known midpoint is post-confirmation and excluded from the primary denominator.
"""
from pathlib import Path
from fractions import Fraction
from decimal import Decimal as D, localcontext
from datetime import datetime, timezone
from math import comb
import argparse, collections, hashlib, json, math, subprocess, sys

ROOT = Path(__file__).resolve().parents[1]
E = ROOT / 'experiment'

def read(name):
    return json.loads((E / name).read_text())

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def exact_integer_cdf(x, a, b):
    x = Fraction.from_float(x)
    n = int(a + b) - 1
    return sum((comb(n, k) * x**k * (1-x)**(n-k)
                for k in range(int(a), n+1)), Fraction())

def execute():
    freeze = read('source_freeze.json')
    mismatches = [n for n, h in freeze['files'].items() if sha(E/n) != h]
    evaluator = read('evaluator_freeze_v2.json')
    evaluator_mismatches = [n for n, h in evaluator['source_hashes'].items() if sha(E/n) != h]
    cases = read('fresh_cases.json')
    refs = read('fresh_references.json')
    meta = read('fresh_case_metadata.json')
    assert len(cases) == len(refs) == 64
    results = {}
    for arm in ('ordinary', 'expert', 'conventional'):
        raw = read(arm + '_raw.json')
        assert raw['complete'] and len(raw['rows']) == 64
        accepted = []
        for c, ref, record in zip(cases, refs, raw['rows']):
            assert c['id'] == ref['id'] == record['id']
            out = record.get('result')
            okay = ref['reference_verified'] and isinstance(out, dict)
            okay = okay and out.get('id') == c['id']
            if okay:
                kind = ref['kind']
                expected = {'numeric':'ok','underflow':'underflow','endpoint':'endpoint',
                            'invalid':'invalid','unsupported':'unsupported'}[kind]
                okay = out.get('status') == expected
                x, r = out.get('x'), ref['x']
                if kind in ('invalid', 'unsupported'):
                    okay = okay and x is None
                elif type(x) not in (int, float) or not math.isfinite(x) or not 0 <= x <= 1:
                    okay = False
                elif kind in ('endpoint', 'underflow') or r == 1:
                    okay = okay and x == r
                else:
                    tolerance = max(2*math.ulp(r), 1e-11*min(r, 1-r))
                    okay = okay and x > 0 and abs(x-r) <= tolerance
            okay = bool(okay and record['cpu_seconds'] <= 5)
            accepted.append(okay)
        expected_scores = read(arm + '_score.json')['checks']
        assert accepted == [x['pass'] for x in expected_scores]
        results[arm] = {'accepted':sum(accepted), 'cases':64,
                        'zero_cpu_observations':sum(x['cpu_seconds'] == 0 for x in raw['rows'])}
    controls = []
    with localcontext() as ctx:
        ctx.prec = 500
        for c, ref in zip(cases, refs):
            if ref['kind'] not in ('numeric', 'underflow'):
                continue
            q, a, b = [float(c[k]) for k in ('q','a','b')]
            r = ref['x']
            tol = max(2*math.ulp(r), 1e-11*min(r,1-r)) if 0 < r < 1 else 0
            if a == 1 or b == 1:
                Q, A, B = [D.from_float(v) for v in (q,a,b)]
                v = (Q.ln()/A).exp() if b == 1 else 1-((1-Q).ln()/B).exp()
                x = float(v)
                controls.append({'id':c['id'],'method':'Decimal500 analytic',
                                 'pass':x == r if r in (0,1) else abs(x-r) <= tol})
            elif a.is_integer() and b.is_integer() and a+b <= 64:
                okay = (exact_integer_cdf(max(0,r-tol),a,b) <= Fraction.from_float(q)
                        <= exact_integer_cdf(min(1,r+tol),a,b))
                controls.append({'id':c['id'],'method':'Fraction binomial CDF','pass':okay})
            elif a == .5 and b == 3:
                def cdf(x):
                    X = x if isinstance(x,D) else D.from_float(x)
                    z = X.sqrt()
                    return (15*z-10*z**3+3*z**5)/8
                Q = D.from_float(q)
                okay = (Q < cdf(D.from_float(math.ulp(0))/2) if r == 0 else
                        cdf(max(0,r-tol)) <= Q <= cdf(min(1,r+tol)))
                controls.append({'id':c['id'],'method':'Beta(1/2,3) closed form','pass':okay})
            elif a == .25 and b == 2 and r == 0:
                X = D.from_float(math.ulp(0))/2
                cdf = (X.ln()/4).exp()*(D('1.25')-X/4)
                controls.append({'id':c['id'],'method':'Beta(1/4,2) closed form',
                                 'pass':D.from_float(q) < cdf})
    midpoint = {'id':'known-midpoint-postconfirmation','q':math.ulp(0.),'a':1.,'b':2.}
    diagnostic = []
    for arm in ('ordinary','expert','conventional'):
        run = subprocess.run([sys.executable,'-B',str(E/'arms'/arm/'run.py')],
                             input=json.dumps(midpoint),text=True,capture_output=True,timeout=15)
        out = json.loads(run.stdout) if run.returncode == 0 else None
        diagnostic.append({'arm':arm,'output':out,
                           'pass':out is not None and out.get('status') == 'ok' and out.get('x') == midpoint['q']})
    delta = Fraction(1,2**1074)
    assert 2*(delta/2)-(delta/2)**2 < delta
    return {'audited_at_utc':datetime.now(timezone.utc).isoformat(),
            'source_mismatches':mismatches,'evaluator_mismatches':evaluator_mismatches,
            'casebank_hash_matches':sha(E/'fresh_cases.json') == meta['casebank_sha256'],
            'primary':results,'separate_controls':controls,
            'known_postconfirmation_midpoint_not_fresh':diagnostic,
            'scope':'Finite independent checks; no global correctness, model capability, demand, or cost advantage proof.'}

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output',type=Path)
    args = parser.parse_args()
    report = execute()
    content = json.dumps(report,indent=2)+'\n'
    if args.output:
        args.output.write_text(content)
    print(content)
