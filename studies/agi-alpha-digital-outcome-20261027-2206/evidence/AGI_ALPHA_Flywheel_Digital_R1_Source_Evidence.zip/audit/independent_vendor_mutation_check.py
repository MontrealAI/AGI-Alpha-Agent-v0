# SPDX-License-Identifier: Apache-2.0
"""Independently require the exact vendor-preflight failure in each mutation case.

Run from an extracted edition:
    python -B audit/independent_vendor_mutation_check.py --output /tmp/new-vendor-audit

The output directory must not already exist. The developer's original receipts
remain untouched. Fixtures are temporary, and source vendor hashes are checked
before and after by the companion mutation runner.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import types
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
EXPECTED_RUNTIME_SHA256 = "783a4a172c3859a6044f1a7d558d4a0a4e9e983dd3c23824fe3b07b6e769dcde"
EXPECTED_MANIFEST_SHA256 = "a4cd4c283e6f1f860487b50195ec4c71bf5fd4b8c1e1c36ecf2b96e473092709"


def digest(path: Path) -> str:
    """Hash the exact source bytes."""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def expected_errors(name: str) -> tuple[str, ...]:
    """Identify the intended preflight failure, excluding unrelated later errors."""
    if name == "modified_manifest_same_size":
        return ("Vendor manifest identity mismatch",)
    if name == "symlink_vendor_root":
        return ("Vendor root must be an actual directory, not a symlink",)
    if name == "modified_optional_bytecode":
        return ("Vendor content mismatch:", "Vendor file type or size mismatch:")
    if name.startswith("modified_"):
        return ("Vendor content mismatch:",)
    if name.startswith("missing_"):
        return ("Missing required vendor files:",)
    if name.startswith("extra_"):
        return ("Unexpected vendor file:",)
    if name.startswith("symlink_") or name == "special_file_fifo":
        return ("Vendor symlink or special file refused:",)
    raise AssertionError(f"Unexpected mutation case: {name}")


def main() -> None:
    """Run isolated mutations and strengthen every failure assertion."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path, help="New audit output directory")
    arguments = parser.parse_args()
    output = arguments.output.absolute()
    if output.exists():
        raise SystemExit("Output already exists; preserve it and choose a new directory")
    runtime = ROOT / "delivery/reproduce.py"
    manifest = ROOT / "delivery/vendor_manifest.json"
    if digest(runtime) != EXPECTED_RUNTIME_SHA256 or digest(manifest) != EXPECTED_MANIFEST_SHA256:
        raise SystemExit("Reviewed runtime or manifest identity changed")
    source = ROOT / "delivery/attempts/review_corrections/verify_vendor_mutations.py"
    captured = source.read_bytes()
    module = types.ModuleType("independent_vendor_mutation_review")
    module.__file__ = str(source)
    exec(compile(captured, str(source), "exec"), module.__dict__)
    output.mkdir(parents=True)
    setattr(module, "HERE", output)
    getattr(module, "main")()
    receipt = json.loads((output / "vendor_mutation_receipt.json").read_text())
    if receipt["passed"] != 16 or receipt["failed"] != 0:
        raise AssertionError("The complete mutation suite did not pass")
    checks: list[dict[str, Any]] = []
    for case in receipt["cases"]:
        name = case["case"]
        if name.startswith("clean_"):
            assert case["checks"]["required_vendor_files"] == 652
            checks.append({"case": name, "pass": True, "checks": case["checks"]})
            continue
        expected = expected_errors(name)
        stderr = case["stderr"]
        assert any("ValueError: " + message in stderr for message in expected), case
        assert "FileNotFoundError" not in stderr, case
        assert case["output_created"] is False, case
        checks.append({"case": name, "expected_errors": list(expected), "pass": True})
    report = {
        "checked_at_utc": datetime.now(timezone.utc).isoformat(),
        "test_source_snapshot_sha256": hashlib.sha256(captured).hexdigest(),
        "runtime_source_sha256": digest(runtime),
        "vendor_manifest_sha256": digest(manifest),
        "independently_rerun": len(checks),
        "exact_expected_error_checks": checks,
        "all_pass": True,
        "source_vendor_files_unchanged": receipt["source_vendor_files_unchanged"],
        "scope": (
            "Exact expected ValueError messages exclude unrelated missing-file errors. "
            "This is a dependency-integrity regression, not new scientific confirmation."
        ),
    }
    (output / "independent_strict_receipt.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({key: value for key, value in report.items() if key != "exact_expected_error_checks"}, indent=2))


if __name__ == "__main__":
    main()
