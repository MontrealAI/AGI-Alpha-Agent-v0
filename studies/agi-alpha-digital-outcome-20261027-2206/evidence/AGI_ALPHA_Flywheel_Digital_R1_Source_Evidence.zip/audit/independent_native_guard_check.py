# SPDX-License-Identifier: Apache-2.0
"""Exercise the reported native fitness-package shadow and a clean direct capture.

Run with --output pointing to a new directory. All mutations occur in an isolated
copy of public inputs; the original native and vendor trees are never edited.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
SHADOW = "alpha_factory_v1/core/eval/fitness/__init__.py"


def sha(path: Path) -> str:
    """Hash exact bytes."""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def copy_or_link(source: Path, target: Path) -> None:
    """Use a hardlink for immutable public fixtures, falling back across devices."""
    target.parent.mkdir(parents=True, exist_ok=True)
    try:
        os.link(source, target)
    except OSError:
        shutil.copyfile(source, target)


def main() -> None:
    """Require both entry points to reject the shadow before importing it."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    output = parser.parse_args().output.absolute()
    if output.exists():
        raise SystemExit("Choose a new output directory to preserve previous evidence")
    output.mkdir(parents=True)
    native_manifest = json.loads((ROOT / "delivery/native_reuse_manifest.json").read_text())
    vendor_manifest = json.loads((ROOT / "delivery/vendor_manifest.json").read_text())
    native_before = {row["path"]: sha(ROOT / "delivery/native_reuse" / row["path"]) for row in native_manifest["files"]}
    rows: list[dict[str, Any]] = []
    environment = os.environ.copy()
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    with tempfile.TemporaryDirectory(prefix="native-shadow-check-", dir=output) as temporary:
        fixture = Path(temporary)
        delivery = fixture / "delivery"
        delivery.mkdir()
        for name in ("reproduce.py", "native_bridge.py", "native_reuse_manifest.json", "vendor_manifest.json"):
            shutil.copyfile(ROOT / "delivery" / name, delivery / name)
        for row in native_manifest["files"]:
            copy_or_link(ROOT / "delivery/native_reuse" / row["path"], delivery / "native_reuse" / row["path"])
        for relative in vendor_manifest["required_files"]:
            copy_or_link(ROOT / "vendor" / relative, fixture / "vendor" / relative)
        shadow = delivery / "native_reuse" / SHADOW
        shadow.parent.mkdir()
        shadow.write_text("raise RuntimeError('INDEPENDENT_SHADOW_PACKAGE_EXECUTED')\n")
        expected = "ValueError: Unexpected native file: " + SHADOW
        for label, command, target in (
            (
                "reproduce_native_rejects_shadow",
                [sys.executable, "-B", str(delivery / "reproduce.py"), "--native", "--output", str(fixture / "replay")],
                fixture / "replay",
            ),
            (
                "direct_bridge_rejects_shadow",
                [
                    sys.executable, "-B", str(delivery / "native_bridge.py"), "--experiment", str(ROOT / "experiment"),
                    "--output", str(fixture / "rejected_native.json"),
                ],
                fixture / "rejected_native.json",
            ),
        ):
            result = subprocess.run(command, env=environment, text=True, capture_output=True, timeout=30)
            passed = (
                result.returncode != 0 and expected in result.stderr and not target.exists()
                and "RuntimeError: INDEPENDENT_SHADOW_PACKAGE_EXECUTED" not in result.stderr
            )
            rows.append({"case": label, "pass": passed, "returncode": result.returncode,
                         "output_created": target.exists(), "stdout": result.stdout, "stderr": result.stderr})
            assert passed, rows[-1]
        shadow.unlink()
        shadow.parent.rmdir()
        target = fixture / "clean_native.json"
        result = subprocess.run(
            [sys.executable, "-B", str(delivery / "native_bridge.py"), "--experiment", str(ROOT / "experiment"),
             "--output", str(target)],
            env=environment, text=True, capture_output=True, timeout=30,
        )
        assert result.returncode == 0 and target.is_file(), result.stderr
        capture = json.loads(target.read_text())
        assert capture["journal_verification"] is True or capture["journal_verification"].get("valid") is True
        assert capture["receipts_micro_usd"] == 0 and capture["known_actual_complete_cost_micro_usd"] is None
        rows.append({"case": "clean_direct_native_capture", "pass": True, "returncode": result.returncode,
                     "journal_verification": capture["journal_verification"], "receipts_micro_usd": 0,
                     "known_actual_complete_cost_micro_usd": None, "events": len(capture["public_signed_events"]),
                     "stdout": result.stdout, "stderr": result.stderr})
        (output / "clean_native_capture.json").write_text(json.dumps(capture, indent=2) + "\n")
    native_after = {row["path"]: sha(ROOT / "delivery/native_reuse" / row["path"]) for row in native_manifest["files"]}
    assert native_before == native_after
    report = {
        "completed_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_sha256": {name: sha(ROOT / "delivery" / name) for name in ("reproduce.py", "native_bridge.py")},
        "cases": rows, "passed": len(rows), "failed": 0, "native_originals_unchanged": len(native_before),
        "scope": "Specific shadow-package regression at both entry points plus a clean native capture; no new numerical cases.",
    }
    (output / "independent_native_guard_receipt.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({key: value for key, value in report.items() if key != "cases"}, indent=2))


if __name__ == "__main__":
    main()
