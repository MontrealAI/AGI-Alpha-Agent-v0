# Exact-source public review verification

1. Read current main immediately before mutation. The read-only preflight at 2026-10-27 22:49 UTC observed commit `3947e4ec8fd74ad40e13e8ff825a149fa98a10e9`, tree `1eae5408a1b41d326f04b512de14203825398530`. Do not assume this remains current if another owner integrates meanwhile.
2. Build one additive commit under `studies/agi-alpha-digital-outcome-20261027-2206/`. Prove unrelated tree entries match the base; do not update catalog/homepage/workflows, versions, owner branches or main.
3. Create a unique review branch from the exact candidate commit and open a draft PR using the standard disclaimer and `[alpha_factory]` title prefix. Record commit/tree/branch/PR identities and creation receipts.
4. Fetch the exact commit and its tree, and verify each published artifact Git blob identity. Fetch the pinned GitHub Markdown reading page and confirm it presents this edition's title, results and boundaries. A raw HTML download is not automatically an executed public webpage.
5. Fetch the pinned raw PDF, brief, HTML and evidence ZIP as unauthenticated public bytes; compare SHA-256 and sizes against the local publication manifest. Record HTTP status, final URL, timestamp and identity. The HTML must be usable offline; the Markdown page is a complete public reading route even if GitHub serves raw HTML as a download.
6. After the source exists, attach the exact immutable links to the owner handoff and coordinate in #4850 under the existing authorization. Do not report the artifact as canonical or production simply because the draft is public.
7. Required subsequent gates remain exact-head configured code/security review, required hosted PR checks, applicable resulting-main full integration/release acceptance, owner publication decision, and actual deploy plus served-byte verification. Do not dispatch, merge or publish beyond the existing authorization/process. Green preparation with skipped deployment is not success.

## Exact template requirements

The current `.github/pull_request_template.md` begins with the standard conceptual-prototype disclaimer and requires Summary, Checks and Testing. All checkboxes must describe actual outcomes; local pre-commit absence does not block a draft, but no required hosted gate is waived. Title prefix: `[alpha_factory]`.

`AGENTS.md` requires Apache-2.0 SPDX headers on new source unless another license is explicitly stated, preserving existing third-party headers. Frozen research evidence must remain unchanged. If providing licensed/normalized executable copies, map each to its frozen source and verify the intended behavior separately; do not silently rewrite historical hashes.

The HTML-disclaimer hook specifically addresses `docs/index.html` pages. This additive study does not change those paths. Keeping the standard disclaimer accessible in study documentation is prudent and does not confer production approval. Scripts needing to print the standard disclaimer should import the existing `alpha_factory_v1.utils.disclaimer.DISCLAIMER` rather than create a divergent copy.
