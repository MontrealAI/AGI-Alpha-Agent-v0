# SPDX-License-Identifier: Apache-2.0
"""Transactional mission journal with an Ed25519 identity and verified recovery."""

from __future__ import annotations

import base64
import hashlib
import json
import os
import secrets
import shutil
import sqlite3
import stat
import subprocess
import time
import uuid
import zipfile
from collections.abc import Iterator
from contextlib import ExitStack, closing, contextmanager
from pathlib import Path
from typing import IO, Any

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives.serialization import Encoding, NoEncryption, PrivateFormat, PublicFormat

from .models import Mission, RuntimeConfig

MAX_RECOVERY_BYTES = 256 * 1024**2
SUCCESSOR_PRINCIPAL_FILES = frozenset(
    {"principals.json", "local-controller.key", "local-producer.key", "local-verifier.key"}
)


def _private_recovery_bytes(path: Path, *, limit: int) -> bytes:
    """Read private credential bytes from a bounded regular file without following links."""
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode) or before.st_size > limit:
        raise ValueError("recovery credentials must be bounded regular files, not links")
    if os.name != "nt" and (before.st_mode & 0o077 or before.st_uid != os.getuid()):
        raise ValueError("recovery credentials must be private to the current account")
    descriptor = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0))
    with os.fdopen(descriptor, "rb") as stream:
        opened = os.fstat(stream.fileno())
        if (opened.st_dev, opened.st_ino) != (before.st_dev, before.st_ino) or not stat.S_ISREG(opened.st_mode):
            raise ValueError("recovery credential changed during collection")
        data = stream.read(limit + 1)
    if len(data) > limit:
        raise ValueError("recovery credential exceeds its byte limit")
    return data


def _successor_recovery_files(root: Path) -> dict[str, bytes]:
    """Collect only the explicitly allowed optional SUCCESSOR disaster-recovery files."""
    from .successor.trust import validate_external_trust_bytes, validate_local_principal_files

    files: dict[str, bytes] = {}
    directory = root / "successor-principals"
    if directory.exists() or directory.is_symlink():
        info = directory.lstat()
        if not stat.S_ISDIR(info.st_mode):
            raise ValueError("local principal recovery directory must not be a link")
        if os.name != "nt" and (info.st_mode & 0o077 or info.st_uid != os.getuid()):
            raise ValueError("local principal recovery directory must be private")
        if {path.name for path in directory.iterdir()} != SUCCESSOR_PRINCIPAL_FILES:
            raise ValueError("private recovery requires the complete exact local principal file set")
        local = {
            name: _private_recovery_bytes(directory / name, limit=16_384 if name == "principals.json" else 32)
            for name in sorted(SUCCESSOR_PRINCIPAL_FILES)
        }
        validate_local_principal_files(local)
        files.update({"successor-principals/" + name: data for name, data in local.items()})
    trust = root / "successor-trust.json"
    if trust.exists() or trust.is_symlink():
        data = _private_recovery_bytes(trust, limit=131_072)
        validate_external_trust_bytes(data)
        files["successor-trust.json"] = data
    return files


def _validate_successor_recovery_files(files: dict[str, bytes]) -> None:
    """Check the optional extension before creating any restored credential state."""
    from .successor.trust import validate_external_trust_bytes, validate_local_principal_files

    local = {name.split("/", 1)[1]: data for name, data in files.items() if name.startswith("successor-principals/")}
    if local:
        validate_local_principal_files(local)
    if "successor-trust.json" in files:
        validate_external_trust_bytes(files["successor-trust.json"])


def _recovery_manifest_pairs(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate recovery manifest key")
        result[key] = value
    return result


def canonical(value: Any) -> bytes:
    """Encode finite JSON consistently for hashes and signatures."""
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def digest(value: Any) -> str:
    """Return a canonical JSON SHA-256 digest."""
    return hashlib.sha256(canonical(value)).hexdigest()


def restrict_access(path: Path) -> None:
    """Grant only the current OS account access before writing private state."""
    if os.name != "nt":
        path.chmod(0o700 if path.is_dir() else 0o600)
        return
    script = r"""
$ErrorActionPreference = 'Stop'
$path = $env:ALPHA_PRIVATE_PATH
$sid = [System.Security.Principal.WindowsIdentity]::GetCurrent().User
if ((Get-Item -LiteralPath $path).PSIsContainer) {
    $acl = New-Object System.Security.AccessControl.DirectorySecurity
    $inherit = [System.Security.AccessControl.InheritanceFlags]'ContainerInherit, ObjectInherit'
} else {
    $acl = New-Object System.Security.AccessControl.FileSecurity
    $inherit = [System.Security.AccessControl.InheritanceFlags]::None
}
$acl.SetOwner($sid)
$acl.SetAccessRuleProtection($true, $false)
$rule = New-Object System.Security.AccessControl.FileSystemAccessRule($sid, 'FullControl', $inherit, 'None', 'Allow')
$acl.AddAccessRule($rule)
Set-Acl -LiteralPath $path -AclObject $acl
"""
    subprocess.run(
        ["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", script],
        env={**os.environ, "ALPHA_PRIVATE_PATH": str(path.resolve())},
        check=True,
        capture_output=True,
        timeout=30,
    )


def private_write(path: Path, data: bytes) -> None:
    """Create a private file exclusively, without following an existing link."""
    fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    with os.fdopen(fd, "wb") as stream:
        if os.name == "nt":
            restrict_access(path)
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())


def _private_batch_binding(path: Path, stream: IO[bytes], identity: tuple[int, int]) -> None:
    """Require the held empty file and its pathname to retain one identity."""
    opened, named = os.fstat(stream.fileno()), path.lstat()
    for info in (opened, named):
        if (
            not stat.S_ISREG(info.st_mode)
            or not info.st_ino
            or (info.st_dev, info.st_ino) != identity
            or info.st_nlink != 1
            or info.st_size != 0
            or getattr(info, "st_file_attributes", 0) & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0)
        ):
            raise ValueError("private batch file binding changed")
        if os.name != "nt" and info.st_mode & 0o077:
            raise ValueError("private batch file permissions changed")


def private_write_batch(files: list[tuple[Path, bytes]]) -> None:
    """Protect a finite exclusively created file set before writing any payload.

    Windows receives only literal path strings, never file contents. All held
    descriptors close on failure; an incomplete batch is never reported complete.
    Filesystem identities that cannot be checked are refused rather than skipped.
    """
    if not 1 <= len(files) <= 8:
        raise ValueError("private file batch must contain one to eight files")
    paths = [path.absolute() for path, _ in files]
    if len({os.path.normcase(os.path.abspath(path)) for path in paths}) != len(paths):
        raise ValueError("private file batch requires distinct paths")
    transport = json.dumps([str(path) for path in paths], ensure_ascii=True)
    if len(transport) > 16_384:
        raise ValueError("private file batch paths exceed the transport bound")
    with ExitStack() as stack:
        opened: list[tuple[Path, bytes, IO[bytes], tuple[int, int]]] = []
        for path, (_, data) in zip(paths, files):
            descriptor = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
            try:
                stream: IO[bytes] = os.fdopen(descriptor, "wb")
            except BaseException:
                os.close(descriptor)
                raise
            stack.enter_context(stream)
            if os.name != "nt":
                os.fchmod(stream.fileno(), 0o600)
            info = os.fstat(stream.fileno())
            identity = (info.st_dev, info.st_ino)
            _private_batch_binding(path, stream, identity)
            opened.append((path, data, stream, identity))
        if os.name == "nt":
            script = r"""
$ErrorActionPreference = 'Stop'
# Windows PowerShell 5.1 emits the JSON array as one pipeline object.
# Assign it directly so foreach receives its literal string elements.
$paths = ConvertFrom-Json -InputObject $env:ALPHA_PRIVATE_PATHS
if ($paths.Count -lt 1 -or $paths.Count -gt 8) { throw 'Invalid private file batch' }
$sid = [System.Security.Principal.WindowsIdentity]::GetCurrent().User
$inherit = [System.Security.AccessControl.InheritanceFlags]::None
foreach ($path in $paths) {
    if ($path -isnot [string] -or [string]::IsNullOrEmpty($path)) { throw 'Invalid private file path' }
    $item = Get-Item -LiteralPath $path -Force
    if ($item.PSIsContainer -or ($item.Attributes -band [System.IO.FileAttributes]::ReparsePoint)) {
        throw 'Private batch requires regular files'
    }
    $acl = New-Object System.Security.AccessControl.FileSecurity
    $acl.SetOwner($sid)
    $acl.SetAccessRuleProtection($true, $false)
    $rule = New-Object System.Security.AccessControl.FileSystemAccessRule(
        $sid, 'FullControl', $inherit, 'None', 'Allow'
    )
    $acl.AddAccessRule($rule)
    Set-Acl -LiteralPath $path -AclObject $acl
}
"""
            subprocess.run(
                ["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", script],
                env={**os.environ, "ALPHA_PRIVATE_PATHS": transport},
                check=True,
                capture_output=True,
                timeout=30,
            )
        # Check every empty destination after ACL application and before the
        # first byte. Recheck each held descriptor/path immediately before use.
        for path, _, stream, identity in opened:
            _private_batch_binding(path, stream, identity)
        for path, data, stream, identity in opened:
            _private_batch_binding(path, stream, identity)
            if stream.write(data) != len(data):
                raise OSError("private batch write incomplete")
            stream.flush()
            os.fsync(stream.fileno())


class Conflict(ValueError):
    """The reviewed state changed, or a transition is not allowed."""


def public_error(exc: Exception) -> str:
    """Keep useful operator errors while withholding provider response contents."""
    from pydantic import ValidationError

    from alpha_factory_v1.core.utils.secure_run import SandboxUnavailable

    if isinstance(exc, ValidationError):
        return "; ".join(
            f"{'.'.join(map(str, item['loc']))}: {item['msg']}"
            for item in exc.errors(include_input=False, include_context=False, include_url=False)
        )
    if type(exc) in {ValueError, Conflict, FileNotFoundError, FileExistsError, TimeoutError, SandboxUnavailable}:
        return str(exc)
    return f"{type(exc).__name__}: provider or dependency failed; inspect configuration and retained mission state"


class Journal:
    """Use a signed append-only journal as the authoritative mission state.

    Signatures expose corruption and bind evidence to a local key. They do not
    prove ENS ownership or protect against an attacker who steals that key.
    """

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root).resolve()
        self.path = self.root / "journal.sqlite3"
        self.config = RuntimeConfig.model_validate_json((self.root / "config.json").read_bytes())
        key = (self.root / "identity.key").read_bytes()
        self.key = Ed25519PrivateKey.from_private_bytes(key)
        self.public = self.key.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw).hex()
        self.identity = f"urn:agialpha:ed25519:{self.public}"
        if not self.path.is_file():
            raise ValueError("journal is missing; restore a verified backup")

    @classmethod
    def initialize(cls, root: str | Path, config: RuntimeConfig | None = None, *, allow_empty: bool = False) -> Journal:
        """Initialize a new directory or explicitly allowed empty mount; never overwrite identity."""
        path = Path(root).resolve()
        try:
            path.mkdir(mode=0o700, parents=True, exist_ok=False)
        except FileExistsError:
            if not allow_empty or not path.is_dir() or any(path.iterdir()):
                raise
        restrict_access(path)
        cfg = config or RuntimeConfig()
        key = Ed25519PrivateKey.generate()
        private_write_batch(
            [
                (path / "config.json", canonical(cfg.model_dump())),
                (path / "identity.key", key.private_bytes(Encoding.Raw, PrivateFormat.Raw, NoEncryption())),
                (path / "api.token", secrets.token_urlsafe(32).encode()),
                (path / "journal.sqlite3", b""),
            ]
        )
        with closing(sqlite3.connect(path / "journal.sqlite3")) as cx, cx:
            cx.execute("PRAGMA journal_mode=WAL")
            cx.execute(
                "CREATE TABLE events(seq INTEGER PRIMARY KEY, mission TEXT NOT NULL, "
                "body TEXT NOT NULL, hash TEXT NOT NULL UNIQUE, signature TEXT NOT NULL)"
            )
            cx.execute("CREATE INDEX events_mission ON events(mission,seq)")
        journal = cls(path)
        with journal.transaction() as cx:
            journal.append(cx, "@control", {"state": "ready", "config_hash": digest(cfg.model_dump())})
        return journal

    @contextmanager
    def transaction(self) -> Iterator[sqlite3.Connection]:
        """Serialize state changes and roll back on every exception."""
        with closing(sqlite3.connect(self.path, timeout=30)) as cx, cx:
            cx.execute("PRAGMA synchronous=FULL")
            cx.execute("BEGIN IMMEDIATE")
            yield cx

    def append(self, cx: sqlite3.Connection, mission: str, document: dict[str, Any]) -> dict[str, Any]:
        """Append a complete state document under the caller's transaction."""
        row = cx.execute("SELECT seq,hash FROM events ORDER BY seq DESC LIMIT 1").fetchone()
        sequence, previous = (row[0] + 1, row[1]) if row else (1, "0" * 64)
        body = {
            "schema": 1,
            "sequence": sequence,
            "previous": previous,
            "identity": self.identity,
            "mission": mission,
            "time_ns": time.time_ns(),
            "document": document,
        }
        hashed = digest(body)
        signature = base64.b64encode(self.key.sign(bytes.fromhex(hashed))).decode()
        cx.execute(
            "INSERT INTO events VALUES(?,?,?,?,?)", (sequence, mission, canonical(body).decode(), hashed, signature)
        )
        return {**document, "id": mission, "revision": sequence, "digest": hashed}

    def latest(self, mission: str, cx: sqlite3.Connection | None = None) -> dict[str, Any]:
        """Read a signed state; verify the full chain with ``verify`` at startup."""
        if cx is None:
            with closing(sqlite3.connect(self.path)) as connection:
                return self.latest(mission, connection)
        row = cx.execute(
            "SELECT seq,body,hash,signature FROM events WHERE mission=? ORDER BY seq DESC LIMIT 1", (mission,)
        ).fetchone()
        if row is None:
            raise KeyError(mission)
        body = json.loads(row[1])
        if digest(body) != row[2] or body["mission"] != mission or body["sequence"] != row[0]:
            raise ValueError("journal content is corrupt")
        self.key.public_key().verify(base64.b64decode(row[3], validate=True), bytes.fromhex(row[2]))
        return {**body["document"], "id": mission, "revision": row[0], "digest": row[2]}

    @staticmethod
    def document(record: dict[str, Any]) -> dict[str, Any]:
        """Strip read-side metadata before appending the next revision."""
        return {k: v for k, v in record.items() if k not in {"id", "revision", "digest"}}

    def submit(self, mission: Mission, request_id: str | None = None) -> dict[str, Any]:
        """Idempotently enqueue a request without executing it."""
        ident = str(uuid.UUID(request_id)) if request_id is not None else str(uuid.uuid4())
        payload = mission.model_dump()
        with self.transaction() as cx:
            try:
                existing = self.latest(ident, cx)
            except KeyError:
                return self.append(cx, ident, {"state": "queued", "request": payload, "request_hash": digest(payload)})
            if existing["request_hash"] != digest(payload):
                raise Conflict("request ID already belongs to different input")
            return existing

    def transition(
        self,
        ident: str,
        revision: int,
        allowed: set[str],
        state: str,
        *,
        fields: dict[str, Any] | None = None,
        require_ready: bool = True,
        expected_config_hash: str | None = None,
    ) -> dict[str, Any]:
        """Apply a compare-and-swap state transition and an optional result."""
        with self.transaction() as cx:
            if require_ready:
                control = self.latest("@control", cx)
                if control["state"] != "ready":
                    raise Conflict("agent is paused")
                config_hash = expected_config_hash or digest(self.config.model_dump())
                if control["config_hash"] != config_hash:
                    raise Conflict("configuration changed; restart and retry")
            old = self.latest(ident, cx)
            if old["revision"] != revision or old["state"] not in allowed:
                raise Conflict("mission state changed; review its current revision")
            return self.append(cx, ident, {**self.document(old), **(fields or {}), "state": state})

    def control(self, paused: bool) -> dict[str, Any]:
        """Persist the operator stop switch across process restarts."""
        with self.transaction() as cx:
            old = self.latest("@control", cx)
            return self.append(cx, "@control", {**self.document(old), "state": "paused" if paused else "ready"})

    def missions(self) -> list[dict[str, Any]]:
        """Return the latest state of each submitted mission."""
        with closing(sqlite3.connect(self.path)) as cx:
            ids = [
                row[0]
                for row in cx.execute(
                    "SELECT DISTINCT mission FROM events WHERE mission NOT LIKE '@%' ORDER BY mission"
                )
            ]
            return [self.latest(ident, cx) for ident in ids]

    def verify(self) -> dict[str, Any]:
        """Verify integrity, every signature, chain order and active configuration."""
        previous, count = "0" * 64, 0
        with closing(sqlite3.connect(self.path)) as cx:
            if cx.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                raise ValueError("SQLite integrity check failed")
            for seq, mission, raw, hashed, signature in cx.execute("SELECT * FROM events ORDER BY seq"):
                body = json.loads(raw)
                count += 1
                if seq != count or body["sequence"] != seq or body["previous"] != previous:
                    raise ValueError("journal sequence or hash chain is broken")
                if body["identity"] != self.identity or body["mission"] != mission or digest(body) != hashed:
                    raise ValueError("journal identity or content mismatch")
                Ed25519PublicKey.from_public_bytes(bytes.fromhex(self.public)).verify(
                    base64.b64decode(signature, validate=True), bytes.fromhex(hashed)
                )
                previous = hashed
            raw_config = (self.root / "config.json").read_bytes()
            if self.latest("@control", cx)["config_hash"] != digest(json.loads(raw_config)):
                raise ValueError("configuration changed outside the journal")
            if RuntimeConfig.model_validate_json(raw_config).model_dump() != self.config.model_dump():
                raise ValueError("configuration changed; restart the running process")
        return {"valid": True, "events": count, "head": previous, "identity": self.identity}

    def configure(self, config: RuntimeConfig) -> None:
        """Change provider policy only while paused, recording its full hash.

        Write-before-commit may leave a detectable mismatch after a crash. A
        verified backup provides recovery; no mismatched config is executed.
        """
        self.verify()
        with self.transaction() as cx:
            old = self.latest("@control", cx)
            if old["state"] != "paused":
                raise Conflict("pause the agent before changing configuration")
            temporary = self.root / f"config-{uuid.uuid4()}.tmp"
            private_write(temporary, canonical(config.model_dump()))
            os.replace(temporary, self.root / "config.json")
            self.append(cx, "@control", {**self.document(old), "config_hash": digest(config.model_dump())})
        self.config = config

    def backup(self, destination: str | Path) -> dict[str, Any]:
        """Create a private recovery archive, including any complete SUCCESSOR role identity."""
        self.verify()
        target = Path(destination).absolute()
        temporary = self.root / f"backup-{uuid.uuid4()}.sqlite3"
        created = False
        try:
            # Hold the writer lock while another connection snapshots committed
            # rows. configure() uses the same lock, so files and rows agree.
            with self.transaction() as cx:
                self.verify()
                with closing(sqlite3.connect(self.path)) as source, closing(sqlite3.connect(temporary)) as dest:
                    source.backup(dest)
                private_paths = [self.root / name for name in ("config.json", "identity.key", "api.token")]
                if sum(path.stat().st_size for path in [temporary, *private_paths]) > MAX_RECOVERY_BYTES:
                    raise ValueError("recovery archive exceeds 256 MiB limit")
                files = {name: (self.root / name).read_bytes() for name in ("config.json", "identity.key", "api.token")}
                files["journal.sqlite3"] = temporary.read_bytes()
                successor_files = _successor_recovery_files(self.root)
                if (
                    not successor_files
                    and cx.execute("SELECT 1 FROM events WHERE mission LIKE '@successor%' LIMIT 1").fetchone()
                ):
                    raise ValueError("SUCCESSOR recovery requires retained local principals or explicit public trust")
                files.update(successor_files)
            manifest = {name: hashlib.sha256(data).hexdigest() for name, data in files.items()}
            manifest_bytes = canonical(manifest)
            if sum(len(data) for data in files.values()) + len(manifest_bytes) > MAX_RECOVERY_BYTES:
                raise ValueError("recovery archive exceeds 256 MiB limit")
            descriptor = os.open(target, os.O_CREAT | os.O_EXCL | os.O_RDWR, 0o600)
            created = True
            with os.fdopen(descriptor, "w+b") as stream:
                if os.name == "nt":
                    restrict_access(target)
                with zipfile.ZipFile(stream, "w", compression=zipfile.ZIP_DEFLATED) as archive:
                    for name, data in files.items():
                        archive.writestr(name, data)
                    archive.writestr("manifest.json", manifest_bytes)
                stream.flush()
                os.fsync(stream.fileno())
                stream.seek(0)
                checksum = hashlib.file_digest(stream, "sha256").hexdigest()
            return {
                "path": str(target),
                "sha256": checksum,
                "contains_private_key": True,
            }
        except BaseException:
            if created:
                target.unlink(missing_ok=True)
            raise
        finally:
            temporary.unlink(missing_ok=True)

    @classmethod
    def restore(cls, backup: str | Path, destination: str | Path) -> Journal:
        """Restore into a new directory only, then verify signatures and identity."""
        target = Path(destination).absolute()
        required = {"config.json", "identity.key", "api.token", "journal.sqlite3", "manifest.json"}
        principals = {"successor-principals/" + name for name in SUCCESSOR_PRINCIPAL_FILES}
        if Path(backup).is_symlink():
            raise ValueError("recovery archive must not be a symbolic link")
        descriptor = os.open(backup, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0))
        with os.fdopen(descriptor, "rb") as stream:
            if not stat.S_ISREG(os.fstat(stream.fileno()).st_mode):
                raise ValueError("recovery archive must be a regular file")
            files = cls._read_recovery_archive(stream, required, principals)
        manifest = json.loads(files.pop("manifest.json"), object_pairs_hook=_recovery_manifest_pairs)
        if manifest != {name: hashlib.sha256(data).hexdigest() for name, data in files.items()}:
            raise ValueError("recovery archive checksum mismatch")
        _validate_successor_recovery_files(files)
        target.mkdir(parents=True, exist_ok=False, mode=0o700)
        try:
            restrict_access(target)
            if any(name in files for name in principals):
                directory = target / "successor-principals"
                directory.mkdir(mode=0o700)
                restrict_access(directory)
            for name, data in files.items():
                private_write(target / name, data)
            journal = cls(target)
            journal.verify()
            return journal
        except BaseException:
            shutil.rmtree(target)
            raise

    @staticmethod
    def _read_recovery_archive(stream: Any, required: set[str], principals: set[str]) -> dict[str, bytes]:
        """Read exact allowed regular-file members before creating any restored state."""
        with zipfile.ZipFile(stream) as archive:
            present = set(archive.namelist())
            expected = required | (principals if present.intersection(principals) else set())
            if "successor-trust.json" in present:
                expected.add("successor-trust.json")
            if present != expected or len(archive.infolist()) != len(expected):
                raise ValueError("unexpected or duplicate recovery archive members")
            if any(
                info.is_dir() or stat.S_IFMT(info.external_attr >> 16) not in {0, stat.S_IFREG}
                for info in archive.infolist()
            ):
                raise ValueError("recovery archive members must be regular files, not links")
            if sum(info.file_size for info in archive.infolist()) > MAX_RECOVERY_BYTES:
                raise ValueError("recovery archive exceeds 256 MiB limit")
            if archive.getinfo("manifest.json").file_size > 16_384:
                raise ValueError("recovery manifest exceeds its byte limit")
            files = {name: archive.read(name) for name in expected}
        return files
