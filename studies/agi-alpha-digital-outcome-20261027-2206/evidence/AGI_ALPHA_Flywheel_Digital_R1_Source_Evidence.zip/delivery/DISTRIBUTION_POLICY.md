# Distribution and preserved identities

This archive is an additive research review edition, DIGITAL-20261027-R1.
Original experiment artifacts remain byte-for-byte frozen. New AGI ALPHA code and original research text are supplied under Apache-2.0, including frozen originals whose headers were absent at experiment time. The root LICENSE is the unmodified repository license. Existing licenses in reused or third-party files take precedence.

`normalized_sources/` contains separately identified copies of original AGI ALPHA Python/C++ sources that lacked SPDX declarations. The only modification is adding an Apache-2.0 SPDX comment; `normalization_manifest.json` binds every old and new SHA-256 and checks Python AST equivalence. These copies are not primary experimental evidence and are not used by the replay. Original files, original hashes and original results remain authoritative.

Boost.Math is distributed with its Boost Software License 1.0, mpmath with its BSD license and wheel metadata, and inspected SciPy sources with their BSD notice. Reused MONTREAL.AI files keep their own license. The prior kinetics archive is included unchanged under its original identity; no new scientific claim is inferred from its inclusion.

Raw GitHub issue/comment prose, unrelated source snapshots, temporary rendering PNGs, local transport helpers, and duplicate replay work trees are not redistributed. Public-input body hashes, original URLs and an optional fail-closed retrieval script preserve provenance. The ordinary numerical replay requires no network access. The complete original third-party input snapshots remain in the local research record.

The initial opportunity screen is retained unchanged. Its phrase 'silently wrong' should be read with the later local reproduction: several failed SciPy calls emitted RuntimeWarnings, while others returned NaN without a warning. Current Boost already solved the five public examples before construction. No exclusive numerical breakthrough or discovery credit is claimed. The early repository audit's failed release preflight is historical; the later publication preflight records an in-progress rerun. Neither a preparation success nor a pinned review download proves canonical production publication.
