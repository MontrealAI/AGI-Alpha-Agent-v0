# SPDX-License-Identifier: Apache-2.0
"""Exercise the vendor preflight on isolated real file mutations without changing the source closure."""

from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
from typing import Any

HERE = Path(__file__).resolve().parent
DELIVERY = HERE.parents[1]
STUDY = DELIVERY.parent


def hash_files(root: Path) -> dict[str, str]:
    """Hash the source closure to prove tests did not change it."""
    return {
        path.relative_to(root).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in root.rglob("*")
        if path.is_file()
    }


def main() -> None:
    """Require every modified dependency to fail before compiler/import execution or output creation."""
    spec = importlib.util.spec_from_file_location("reviewed_reproduce", DELIVERY / "reproduce.py")
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    verify = getattr(module, "verify_vendor_closure")
    original_hashes = hash_files(STUDY / "vendor")
    manifest = json.loads((DELIVERY / "vendor_manifest.json").read_text())
    records: list[dict[str, Any]] = []
    with tempfile.TemporaryDirectory(prefix="vendor-mutation-", dir=HERE) as directory:
        root = Path(directory)
        vendor = root / "vendor"
        fixture_delivery = root / "delivery"
        fixture_delivery.mkdir()
        for name in ("reproduce.py", "vendor_manifest.json"):
            shutil.copyfile(DELIVERY / name, fixture_delivery / name)
        # Hardlinks save space; every content mutation below unlinks before writing, never modifies a linked inode.
        for relative in manifest["required_files"]:
            target = vendor / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            os.link(STUDY / "vendor" / relative, target)
        records.append({"case": "clean_archive_without_optional_caches", "passed": True, "checks": verify(vendor)})
        observed_cache_count = 0
        for relative in manifest["optional_historical_bytecode"]:
            if not (STUDY / "vendor" / relative).is_file():
                continue
            observed_cache_count += 1
            target = vendor / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            os.link(STUDY / "vendor" / relative, target)
        records.append(
            {
                "case": "clean_original_with_exact_optional_caches",
                "passed": True,
                "observed_exact_cache_files": observed_cache_count,
                "checks": verify(vendor),
            }
        )
        python_file = "mpmath130/mpmath/__init__.py"
        header = "boost_math/include/boost/math/special_functions/detail/ibeta_inverse.hpp"
        cache = next(iter(manifest["optional_historical_bytecode"]))
        cases = [
            ("modified_python_same_size", python_file, "modify"),
            ("modified_header_same_size", header, "modify"),
            ("missing_python", python_file, "missing"),
            ("missing_header", header, "missing"),
            ("extra_python", "mpmath130/mpmath/review_injected.py", "extra"),
            ("extra_header", "boost_math/include/review_injected.hpp", "extra"),
            ("modified_optional_bytecode", cache, "wrong_cache"),
            ("extra_bytecode", "mpmath130/mpmath/__pycache__/review_injected.cpython-312.pyc", "extra"),
            ("symlink_required_python", python_file, "symlink"),
            ("symlink_extra_directory", "mpmath130/review_symlink", "symlink_directory"),
            ("special_file_fifo", "mpmath130/review_fifo", "fifo"),
        ]
        for name, relative, change in cases:
            target = vendor / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            prior = target.read_bytes() if target.exists() else None
            if target.exists():
                target.unlink()
            if change == "modify":
                assert prior
                target.write_bytes(bytes([prior[0] ^ 1]) + prior[1:])
            elif change == "wrong_cache":
                target.write_bytes(b"Incorrect optional bytecode; this must never execute.")
            elif change == "extra":
                target.write_bytes(b"raise RuntimeError('unverified code must not execute')\n")
            elif change == "symlink":
                target.symlink_to(STUDY / "vendor" / relative)
            elif change == "symlink_directory":
                target.symlink_to(STUDY / "vendor/mpmath130/mpmath", target_is_directory=True)
            elif change == "fifo":
                os.mkfifo(target)
            output = root / ("output-" + name)
            result = subprocess.run(
                [sys.executable, "-B", str(fixture_delivery / "reproduce.py"), "--output", str(output)],
                text=True,
                capture_output=True,
                timeout=10,
            )
            expected_error = {
                "modify": f"ValueError: Vendor content mismatch: {relative}",
                "missing": f"ValueError: Missing required vendor files: ['{relative}']",
                "extra": f"ValueError: Unexpected vendor file: {relative}",
                "wrong_cache": f"ValueError: Vendor file type or size mismatch: {target}",
                "symlink": f"ValueError: Vendor symlink or special file refused: {relative}",
                "symlink_directory": f"ValueError: Vendor symlink or special file refused: {relative}",
                "fifo": f"ValueError: Vendor symlink or special file refused: {relative}",
            }[change]
            passed = result.returncode != 0 and not output.exists() and expected_error in result.stderr
            records.append(
                {
                    "case": name,
                    "passed": passed,
                    "returncode": result.returncode,
                    "output_created": output.exists(),
                    "expected_error": expected_error,
                    "stderr": result.stderr,
                }
            )
            assert passed, records[-1]
            if target.exists() or target.is_symlink():
                target.unlink()
            if prior is not None:
                target.write_bytes(prior)
        for name, target in (
            ("symlink_required_ancestor", vendor / "mpmath130/mpmath"),
            ("symlink_vendor_root", vendor),
        ):
            held = root / ("held-" + name)
            target.rename(held)
            target.symlink_to(held, target_is_directory=True)
            output = root / ("output-" + name)
            result = subprocess.run(
                [sys.executable, "-B", str(fixture_delivery / "reproduce.py"), "--output", str(output)],
                text=True,
                capture_output=True,
                timeout=10,
            )
            expected_error = (
                "ValueError: Vendor root must be an actual directory, not a symlink"
                if name == "symlink_vendor_root"
                else "ValueError: Vendor symlink or special file refused: mpmath130/mpmath"
            )
            passed = result.returncode != 0 and not output.exists() and expected_error in result.stderr
            records.append(
                {
                    "case": name,
                    "passed": passed,
                    "returncode": result.returncode,
                    "output_created": output.exists(),
                    "expected_error": expected_error,
                    "stderr": result.stderr,
                }
            )
            assert passed, records[-1]
            target.unlink()
            held.rename(target)
        manifest_path = fixture_delivery / "vendor_manifest.json"
        manifest_path.write_bytes(manifest_path.read_bytes().replace(b'"schema": 1', b'"schema": 2'))
        result = subprocess.run(
            [sys.executable, "-B", str(fixture_delivery / "reproduce.py"), "--output", str(root / "manifest-output")],
            text=True,
            capture_output=True,
            timeout=10,
        )
        manifest_output_created = (root / "manifest-output").exists()
        passed = (
            result.returncode != 0
            and not manifest_output_created
            and "ValueError: Vendor manifest identity mismatch" in result.stderr
        )
        records.append(
            {
                "case": "modified_manifest_same_size",
                "passed": passed,
                "output_created": manifest_output_created,
                "expected_error": "ValueError: Vendor manifest identity mismatch",
                "returncode": result.returncode,
                "stderr": result.stderr,
            }
        )
        assert passed
        assert verify(vendor)["required_vendor_files"] == 652
    assert hash_files(STUDY / "vendor") == original_hashes
    receipt = {
        "completed_at_utc": datetime.now(timezone.utc).isoformat(),
        "review": "PR4998 dependency integrity correction; no new scientific confirmation",
        "reproduce_sha256": hashlib.sha256((DELIVERY / "reproduce.py").read_bytes()).hexdigest(),
        "vendor_manifest_sha256": hashlib.sha256((DELIVERY / "vendor_manifest.json").read_bytes()).hexdigest(),
        "passed": len(records),
        "failed": 0,
        "source_vendor_files_unchanged": len(original_hashes),
        "observed_exact_source_cache_files": observed_cache_count,
        "strict_expected_error_assertions": True,
        "test_scope": "Real isolated filesystem mutations. All rejection cases stop before output creation or any build/import step.",
        "cases": records,
    }
    (HERE / "vendor_mutation_receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({key: value for key, value in receipt.items() if key != "cases"}, indent=2))


if __name__ == "__main__":
    main()
