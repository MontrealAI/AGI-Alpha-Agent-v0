# SPDX-License-Identifier: Apache-2.0
"""Check native import-shadowing and closure tampering before replay starts."""

from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
from typing import Any

HERE = Path(__file__).resolve().parent
DELIVERY = HERE.parents[1]
STUDY = DELIVERY.parent


def main() -> None:
    """Use actual isolated mutations and exact failure assertions; leave original source untouched."""
    spec = importlib.util.spec_from_file_location("native_reviewed_reproduce", DELIVERY / "reproduce.py")
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    initial = getattr(module, "verify_frozen_files")()
    native_manifest = json.loads((DELIVERY / "native_reuse_manifest.json").read_text())
    vendor_manifest = json.loads((DELIVERY / "vendor_manifest.json").read_text())
    rows: list[dict[str, Any]] = [{"case": "clean_all_closures", "passed": True, "checks": initial}]
    with tempfile.TemporaryDirectory(prefix="native-integrity-", dir=HERE) as temporary:
        root = Path(temporary)
        target_delivery = root / "delivery"
        target_delivery.mkdir()
        for name in ("reproduce.py", "native_bridge.py", "vendor_manifest.json", "native_reuse_manifest.json"):
            shutil.copyfile(DELIVERY / name, target_delivery / name)
        for relative in vendor_manifest["required_files"]:
            target = root / "vendor" / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            os.link(STUDY / "vendor" / relative, target)
        native = target_delivery / "native_reuse"
        for row in native_manifest["files"]:
            target = native / row["path"]
            target.parent.mkdir(parents=True, exist_ok=True)
            os.link(DELIVERY / "native_reuse" / row["path"], target)
        fitness = "alpha_factory_v1/core/eval/fitness.py"
        cases = [
            ("fitness_package_shadow", "alpha_factory_v1/core/eval/fitness/__init__.py", "extra"),
            ("unexpected_bytecode", "alpha_factory_v1/core/eval/__pycache__/fitness.cpython-312.pyc", "extra"),
            ("unexpected_extension", "alpha_factory_v1/core/eval/fitness.so", "extra"),
            ("modified_fitness", fitness, "modify"),
            ("missing_fitness", fitness, "missing"),
            ("symlink_fitness", fitness, "symlink"),
            ("special_fifo", "alpha_factory_v1/core/eval/unsafe_fifo", "fifo"),
        ]
        for name, relative, change in cases:
            target = native / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            prior = target.read_bytes() if target.exists() else None
            if target.exists():
                target.unlink()
            if change == "extra":
                target.write_bytes(b"raise RuntimeError('unverified native code executed')\n")
            elif change == "modify":
                assert prior
                target.write_bytes(bytes([prior[0] ^ 1]) + prior[1:])
            elif change == "symlink":
                target.symlink_to(DELIVERY / "native_reuse" / relative)
            elif change == "fifo":
                os.mkfifo(target)
            expected = {
                "extra": f"ValueError: Unexpected native file: {relative}",
                "modify": f"ValueError: Native content mismatch: {relative}",
                "missing": f"ValueError: Missing required native files: ['{relative}']",
                "symlink": f"ValueError: Native symlink or special file refused: {relative}",
                "fifo": f"ValueError: Native symlink or special file refused: {relative}",
            }[change]
            output = root / ("out-" + name)
            result = subprocess.run(
                [sys.executable, "-B", str(target_delivery / "reproduce.py"), "--output", str(output), "--native"],
                text=True,
                capture_output=True,
                timeout=10,
            )
            passed = result.returncode != 0 and not output.exists() and expected in result.stderr
            rows.append(
                {
                    "case": name,
                    "passed": passed,
                    "expected_error": expected,
                    "output_created": output.exists(),
                    "stderr": result.stderr,
                }
            )
            assert passed, rows[-1]
            if name == "fitness_package_shadow":
                direct_output = root / "direct-native-output.json"
                direct = subprocess.run(
                    [sys.executable, "-B", str(target_delivery / "native_bridge.py"), "--output", str(direct_output)],
                    text=True,
                    capture_output=True,
                    timeout=10,
                )
                direct_passed = direct.returncode != 0 and not direct_output.exists() and expected in direct.stderr
                rows.append(
                    {
                        "case": "direct_bridge_fitness_shadow",
                        "passed": direct_passed,
                        "expected_error": expected,
                        "output_created": direct_output.exists(),
                        "stderr": direct.stderr,
                    }
                )
                assert direct_passed, rows[-1]
            if target.exists() or target.is_symlink():
                target.unlink()
            if prior is not None:
                target.write_bytes(prior)
        for name, target in [
            ("symlink_native_ancestor", native / "alpha_factory_v1/core/eval"),
            ("symlink_native_root", native),
        ]:
            held = root / ("held-" + name)
            target.rename(held)
            target.symlink_to(held, target_is_directory=True)
            output = root / ("out-" + name)
            expected = (
                "ValueError: Native root must be an actual directory, not a symlink"
                if name == "symlink_native_root"
                else "ValueError: Native symlink or special file refused: alpha_factory_v1/core/eval"
            )
            result = subprocess.run(
                [sys.executable, "-B", str(target_delivery / "reproduce.py"), "--output", str(output), "--native"],
                text=True,
                capture_output=True,
                timeout=10,
            )
            passed = result.returncode != 0 and not output.exists() and expected in result.stderr
            rows.append(
                {
                    "case": name,
                    "passed": passed,
                    "expected_error": expected,
                    "output_created": output.exists(),
                    "stderr": result.stderr,
                }
            )
            assert passed, rows[-1]
            target.unlink()
            held.rename(target)
        path = target_delivery / "native_reuse_manifest.json"
        path.write_bytes(path.read_bytes().replace(b"3947e4ec", b"0947e4ec"))
        output = root / "out-manifest"
        result = subprocess.run(
            [sys.executable, "-B", str(target_delivery / "reproduce.py"), "--output", str(output), "--native"],
            text=True,
            capture_output=True,
            timeout=10,
        )
        expected = "ValueError: Native manifest identity mismatch"
        passed = result.returncode != 0 and not output.exists() and expected in result.stderr
        rows.append(
            {
                "case": "native_manifest_tamper",
                "passed": passed,
                "expected_error": expected,
                "output_created": output.exists(),
                "stderr": result.stderr,
            }
        )
        assert passed
        shutil.copyfile(DELIVERY / "native_reuse_manifest.json", target_delivery / "native_reuse_manifest.json")
        experiment = root / "experiment"
        experiment.mkdir()
        for source in ("source_freeze.json",):
            shutil.copyfile(STUDY / "experiment" / source, experiment / source)
        shutil.copyfile(DELIVERY / "provenance.json", target_delivery / "provenance.json")
        source_freeze = json.loads((experiment / "source_freeze.json").read_text())
        for relative in source_freeze["files"]:
            target = experiment / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            os.link(STUDY / "experiment" / relative, target)
        for name, target, old, new, expected in (
            (
                "source_freeze_manifest_tamper",
                experiment / "source_freeze.json",
                b"all_arm",
                b"All_arm",
                "ValueError: Source freeze manifest identity mismatch",
            ),
            (
                "provenance_manifest_tamper",
                target_delivery / "provenance.json",
                b"DIGITAL",
                b"dIGITAL",
                "ValueError: Provenance manifest identity mismatch",
            ),
        ):
            original = target.read_bytes()
            altered = original.replace(old, new, 1)
            assert altered != original and len(altered) == len(original)
            target.write_bytes(altered)
            output = root / ("out-" + name)
            result = subprocess.run(
                [sys.executable, "-B", str(target_delivery / "reproduce.py"), "--output", str(output)],
                text=True,
                capture_output=True,
                timeout=10,
            )
            passed = result.returncode != 0 and not output.exists() and expected in result.stderr
            rows.append(
                {
                    "case": name,
                    "passed": passed,
                    "expected_error": expected,
                    "output_created": output.exists(),
                    "stderr": result.stderr,
                }
            )
            assert passed, rows[-1]
            target.write_bytes(original)
    assert getattr(module, "verify_frozen_files")() == initial
    receipt = {
        "completed_at_utc": datetime.now(timezone.utc).isoformat(),
        "passed": len(rows),
        "failed": 0,
        "all_original_closure_hashes_unchanged": True,
        "reproduce_sha256": hashlib.sha256((DELIVERY / "reproduce.py").read_bytes()).hexdigest(),
        "native_manifest_sha256": hashlib.sha256((DELIVERY / "native_reuse_manifest.json").read_bytes()).hexdigest(),
        "scope": "PR4998 head49e988 native import shadowing correction, not new numerical confirmation.",
        "cases": rows,
    }
    (HERE / "native_mutation_receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({k: v for k, v in receipt.items() if k != "cases"}, indent=2))


if __name__ == "__main__":
    main()
