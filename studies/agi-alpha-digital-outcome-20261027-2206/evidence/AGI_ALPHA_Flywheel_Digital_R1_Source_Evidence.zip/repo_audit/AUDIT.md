# Continuation repository and publication audit

**Snapshot:** 2026-10-27 22:08–22:12 UTC. Read-only upstream audit for the new 120-minute research continuation beginning 22:06 UTC. No comment, branch, commit, PR, review, merge, dispatch, release or deployment was created by this audit.

## Decision

A complete research edition can be made public immediately as an **immutable, inspectable review branch and draft pull request**, with source, data, runnable construction, PDFs and downloadable HTML. That is a review edition, not canonical publication, a hosted application or software release. Existing policy explicitly permits opening a draft/PR with honestly disclosed unrun local checks; full hosted integration/release qualification remains required. An existing current example is #4993, whose 431 additions include Python, data, HTML, PDF and ZIP in a unique study subtree, with all broader gates pending.

A **separate focused passive-paper PR** is supported by the existing importer and classifier. It can contain the immutable PDF and optional TeX, catalog entry and exact generated presentation files. That proposal does not change publisher ownership or release sequencing. Its catalog/live delivery must follow the existing owner and exact-source gates. A paper PDF may link an immutable review evidence URL as an ordinary user-clicked HTTPS link. Do not add source, ZIP or new HTML to that narrow PR and describe it as paper-only.

## Current state and protected ownership

Main is `3947e4ec8fd74ad40e13e8ff825a149fa98a10e9`, a merge of #4994 (one publication-edition test allowlist correction). Previous main `47c17f6aca6b1bb8779dd3e47d5ba5f8af3329f4` is retained as the earlier experiment source. #4973, exact head `d7bd55799f68fc88b76e32b28a27a3e9062bedf6`, merged at 21:37:25 UTC; #4994 merged at 22:07:10 UTC. Neither merge establishes successful release.

Issue #4850 has 688 comments; only its final page (88 comments), not the full history, was downloaded. Latest comment is 6454206539, 21:37:04 UTC. It reserves the existing owner sequence: finish #4973/1.46.1 publication repair, reconcile qualified discovery children through their existing lineage, then qualify the resulting release. #4994 also identifies a separate 1.47 integration owner; no new release version is allocated here.

Protected runtime owners: #4960 Responses execution; #4961 specialist Gym/relay; #4963 enterprise decisions; #4972/#4975 discovery construction; #4984 cancellation closure; #4985 customer-fund accounting; #4987 prospective Operational Alpha comparisons; #4988 frozen Insight research bridge. Their branches and authority are unchanged.

Current publication evidence:

- Latest non-prerelease GitHub release is **v1.46.0**, published 2026-10-27 14:34:53 UTC.
- Main Agent release acceptance **40592298278 failed**, at job 122499576085. The ordinary publication preflight passed for v1.46.1 and current main, then `wait_for_release_ci --preflight` failed with **HTTP403: rate limit exceeded**. This is an observed external API failure, not evidence that scientific code failed. Downstream release jobs were skipped. No failed result is waived or relabeled.
- Paper site publication **40592298138 completed success**, but **deploy and verify-public were skipped**. It is not a successful public delivery. The existing overlay requires a matching public software baseline and defers otherwise.
- PR CI, Smoke and other current-main workflows were still running at snapshot. Public branch-protection settings could not be read unauthenticated (401); public rulesets returned an empty list. This does not prove branch protection is absent. Required names below come from repository policy, not an authenticated settings audit.

Primary records: [main](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/commit/3947e4ec8fd74ad40e13e8ff825a149fa98a10e9); [owner checkpoint](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/issues/4850#issuecomment-6454206539); [#4973](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/pull/4973); [#4994](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/pull/4994); [failed preflight](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/actions/runs/40592298278/job/122499576085); [paper no-deployment run](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/actions/runs/40592298138).

## Active-study exclusions

New since the first audit: **#4993**, `5dfd02ae6b508d0cc205afd9219af4519339184f`, reproducible discovery assessment/archive-claim pilot. Its exact finite inference instrument has an independent exhaustive check, authored confirmation cases, a conventional tie, no live archive payload, no flagship and no Operational/retained Alpha. Avoid repeating archive-claim/temporal partial-observation inference or describing public restricted metadata as available customer data. Its broader seven-candidate search is already recorded.

Other active or completed lanes remain excluded: #4983 microscopy; #4982 primary-report evidence construction; #4981 shared observations; #4980 inspection and library parity; #4979 original obligations/native seed procurement; #4977 scientific-model qualification; #4986 geospatial economics; #4989 care construction; #4990 passive event-history novelty; #4991 confidential reserve; #4992 output-disclosure audit. Earlier exclusions include safe retry, chronology, unlearning, temporal matching and DNA encoding. These are scope exclusions for this sprint, not blanket claims that every possible problem in those fields is solved.

#4992's strongest controls remain a conventional/library match, and its venture decision remains STOP. #4993 likewise reports no flagship. Preserve useful conventional engineering without turning a tie into discovery or construction superiority. #4989/#4991's existing add/add collision at `studies/agi-alpha-opportunity-construction-v1/` remains their integration concern; do not use that path.

## Exact passive-paper surface

Repository sources at current main:

- `docs/agent/PAPER_UPLOADS.md`: normal import/PR procedure, immutable originals, paper-only versus mixed-code classification, overlay and public-byte gates.
- `scripts/research_papers.py`: closed catalog schema, passive PDF validation and deterministic rendering.
- `scripts/paper_changes.py`: fail-closed exact Git-object/history proof.
- `.github/workflows/paper-scope.yml`: executes pre-change trusted policy, never uploaded policy.
- `.github/workflows/paper-publication.yml` and `scripts/publish_paper_site.py`: the existing canonical overlay producer/guard/live verifier.
- `CONTRIBUTING.md`, especially local-check disclosure, required hosted checks and paper guide link.

Allowed narrow change, all ordinary mode100644 files, no deletions:

1. `docs/research-papers.json`, preserving all existing immutable record identities.
2. New PDF and optional TeX referenced by the catalog. Normal importer paths are `docs/papers/<new-versioned-id>.pdf` and `.tex`; parser also retains legacy simple `docs/<name>.pdf/.tex` paths. Maximum manuscript/blob size25,000,000 bytes.
3. Only the deterministic bounded research blocks in `README.md` and `docs/index.html`.
4. Exact generated `docs/service-worker.js`, `docs/assets/service-worker.js`, `docs/alpha_factory_v1/demos/alpha_agi_insight_v1/service-worker.js`.
5. The classifier additionally permits a separately proved bounded editorial `docs/CHANGELOG.md` change. It is unnecessary for this proposed research edition and should be left alone.

Import command from a current exact source checkout:

```sh
python -m scripts.research_papers add --pdf /absolute/edition.pdf --tex /absolute/edition.tex --metadata /absolute/paper.json
python -m scripts.research_papers check
```

Omit `--tex` if unavailable. Temporary import metadata stays outside the repository. Do not hand-edit generated blocks or workers. Commit the complete valid import once. There is no software version bump for a proved passive-paper upload.

The pre-change classifier verifies *every introduced commit*, including side-branch transitions, not merely the final diff. Missing history, more than200 introduced commits, mixed/unknown paths, modes, deletions, source/runtime/dependency/workflow changes or any proof failure require full qualification. Web-upload intermediate bare-paper commits can be squashed into one complete valid main commit, but normal merge retaining invalid intermediate commits remains the full lane. A new evidence/source/HTML edition under `studies/` always takes full scope.

The passive validator stores TeX without compiling it and checks PDF bytes without rewriting them. It rejects scripts, launch actions, forms, external file references, arbitrary embedded content and active media; ordinary clicked HTTP(S)/mailto navigation is permitted. Linking already-public source in a paper is not executing or qualifying it.

Schema v2 already supports specific immutable resource roles, but adding new HTML requires full source qualification. The prose guide describes a subset of current code's resource roles; use the existing code as the exact validator, without extending it for this study. External companion/resource declarations require actual download identity verification; do not invent a research release or bypass its owner. A plain immutable evidence URL within PDF prose avoids creating a new catalog resource release dependency.

## Review and publication gates

A complete evidence review branch/draft may be opened with pending broader checks, disclosed as pending, because CONTRIBUTING and AGENTS explicitly say local hook completion is not a prerequisite for opening a draft/PR. No exception to required hosted merge/release checks follows. #4993 is a direct current precedent, not permission to borrow its reviews.

For normal integration, repository policy names exact required checks `✅ PR CI / Lint (ruff)` and `✅ PR CI / Smoke tests` and requires an up-to-date branch. Exact-head configured review must address findings; old-source reviews do not qualify a new head. Mixed source/data/HTML work also needs the existing full exact-resulting-main integration and Agent release acceptance route before canonical release. Scientific acceptance and source-specific evidence remain separate from repository safety and release qualification.

For a proved passive-paper update, the paper lane validates the immutable originals and generated presentation; it does not confer new software acceptance. Canonical site preparation restores the exact published software/site packs, proves paper descendants, validates homepage accessibility/EN-FR/no-JS/links, seals exact artifacts, then under the shared Pages lock rechecks current main, public release identity and monotonic paper provenance. The existing deploy and `verify-live` steps must actually run and pass. A green preparation that skips deployment is not public publication.

**External dependencies for this continuation:** owner's active publication/integration schedule; exact-head configured review and hosted required checks; current-main public API availability (rate-limited failed preflight observed); matching qualified public software baseline and site pack; existing Pages deployment and served-byte verifier. These are not resolved by a local PDF, draft PR, old clean review or assumed access. No change to credentials, permissions, CI gates or publisher is proposed.

## Existing components can be reused unchanged

`current_reuse_verification.json` proves **all24 previously fetched source files have identical Git blob identities at old47c17f6, current3947e4ec and local preserved bytes**. This includes foundations and root AGENTS/license, the minimal Journal/CostLedger/Charge/digest/signing/fitness closure and reference mission/evaluation modules. No refetch or new ledger/runtime/evaluation infrastructure is necessary.

Use the preserved `sprint/repo_audit/upstream` closure and `native_bridge.py` from the earlier gap package. The bridge records generic signed research evidence and unknown actual cost scope; it does not assert customer acceptance, live identities, funds or profit. Its native fitness is a summary of explicitly supplied check rows, not a universal scientific oracle. Mission-specific independent acceptance remains necessary.

The previous chemical result, frozen protocol, rejected cases, confirmation and signed evidence stay immutable. Fresh continuation outcomes must have distinct evidence bindings and cannot retroactively alter those96 decisions, their physical boundary or the STOP novelty conclusion. No full repository clone/build or optional new infrastructure was performed in this audit.

## Audit files and limits

Saved: current main and full nontruncated5798-entry Git tree, final issue-comment page, latest60 open PR metadata, selected PR state/files, relevant workflows and exact verified policy sources, main workflow/job outcomes, public release metadata, relevant preflight error excerpt,24-file current reuse comparison and proposed coordination text. #4993's changed-file API sample is only its first100 entries; its body provides431-file scope. This is not an exhaustive issue history or full security/CI audit. Main and owner refs must be refreshed before any external mutation.
