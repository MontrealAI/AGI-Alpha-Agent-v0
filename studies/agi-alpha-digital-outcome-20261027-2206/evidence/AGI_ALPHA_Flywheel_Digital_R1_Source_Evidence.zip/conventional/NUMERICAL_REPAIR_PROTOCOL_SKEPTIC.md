# Protocol skeptic notes — public numerical inference repair

## Selection boundary

The prospective recipient is a numerical/statistical software user needing an accurate, reviewable inverse-beta calculation under stated extreme-tail conditions. The deliverable is a corrected local implementation, fresh validation, and integration-ready evidence. This is a **conventional repair/service pilot**, not a new numerical algorithm or transformational capability. No customer has accepted it, no payment exists, and library maintainers have not approved our work.

Current narrow candidate: SciPy issue [#26531](https://github.com/scipy/scipy/issues/26531), opened 27 October 2026 at 20:30:11 UTC, titled `scipy.stats.beta.ppf returns wrong values or nan for small q`. Issue and its sole comment were read live through GitHub API. Reported values are source assertions until reproduced in this environment. The comment requests testing current Boost.Math master because it has recent incomplete-beta/inverse changes. Parent/discovery must pin current SciPy and Boost identities and check active PRs before selecting the final artifact.

**Decisive early conventional match:** the issue itself gives an asymptotic initial guess and log-domain Newton refinement and reports 13–15 correct digits in one or two steps for all five disclosed examples. It also supplies a high-precision mpmath reference. This means the useful remaining work is generalization, numerical failure handling and integration, not discovering that formulation. FULL source issue, including its correction recipe, must be supplied to every arm.

The issue's reported mechanism is differing Boost root-iteration and error policies: stats.beta.ppf and scipy.special.betaincinv share `ibeta_inv`, so their agreement is useful but not independent verification. SciPy official documentation confirms that betaincinv wraps Boost ibeta_inv. The stronger conventional options include current Boost, betaincinv/betainccinv, complementary-tail and shape symmetry, stable root inversion, and arbitrary precision. Do not restrict the comparator to the reported broken implementation.

## Freeze these acceptance decisions before any fresh agent executes

- Exact API scope: scalar finite binary64 q in [0,1], positive finite a and b within an explicit bounded region, plus the required rejection policy. If arrays/broadcasting/loc-scale are not built, label this a scalar kernel and do not claim a drop-in SciPy replacement. Cover ordinary central inputs as well as extreme tails.
- Define input semantics as the exact values of received binary64 numbers. High-precision reference must convert exact binary inputs, not substitute aesthetically cleaner decimal numbers. For q=0 and q=1, endpoint output is exactly 0 and 1. Inputs already rounded to q=1 do not retain a hidden small complementary probability; an inverse-survival interface would be a separate contract.
- Quantile accuracy must be relative or logarithmic when the target is tiny. A permissive absolute tolerance such as 1e-12 accepts an answer that is wrong by hundreds of orders of magnitude. Report relative quantile error and log-CDF residual for supported finite interior cases; define treatment of subnormal quantiles and correctly rounded zero before testing.
- Do not demand positive binary64 output for an exact quantile below the smallest representable positive value. Either define correctly rounded endpoint behavior, return an explicit log-quantile with a different interface, or delimit the supported representable domain openly. Excluding such cases without disclosure would be changing requirements after the fact.
- A numerically verified result and an explicit refusal are different outputs. Refusal protects a caller from a false answer but is not successful delivery for an in-domain accepted request. All timeouts, unresolved references, exceptions and retries must remain visible.
- Freeze performance ceiling without pretending latency parity across unknown model internals. Measure local shell CPU and wall time. No provider cost, token usage, temperature or exact backend identity is verified here; leave those fields unknown. Record actual same-session agent and shell execution.

## Independent confirmation requirements

1. Disclosed issue examples are development cases, never fresh confirmations. Freeze fresh input generation and hashes before arm execution. Include shape regimes away from the five source rows, transitions between any numerical branches, ordinary inputs, boundaries/invalids, and adversarial combinations where a probability residual can be misleading.
2. Use an independent reference algorithm, preferably bracketing/bisection with increasing precision and a separate incomplete-beta evaluation, not a copied version of the submitted Newton method. Validate reference stability at two precisions and record failure to establish a reference instead of silently replacing it by the candidate value. A high-precision root value is numerical evidence, not a formally certified interval unless directed rounding/enclosures are actually implemented.
3. Analytic cases provide a second check: a=1, b=1, or positive integer shape cases with an independently evaluated finite beta/binomial identity. Check monotonicity in q and shape/complement symmetry only where floating-point input/output information permits the comparison. Metamorphic agreement alone does not establish accuracy.
4. Freeze both output and source hashes before revealing held-out scores. Apply identical permitted repair opportunities and budgets to every arm. Do not let the expert arm see fresh failures while holding the ordinary arm frozen, unless this is explicitly a separately scored follow-up.
5. Reproduce the original public report on the exact tested version, then distinguish a local repair from an upstream patch, current-Boost fix, supported production implementation or maintainer-accepted contribution. No external PR/comment is authorized by this workstream.

## Agent comparison, scoped honestly

Use fresh fork_turns='none' agents for ordinary and operational arms, each receiving identical full issue text, source snapshot, relevant official docs, tool access, public development cases, acceptance contract and resource ceiling. Existing search agents have seen the proposed fix and cannot serve as blinded fresh baseline trials. They may be independent evaluators or conventional challengers.

The ordinary arm prompt should ask for competent professional work, allow planning, model reasoning, tests, iterative debugging and any established numerical methods. Do not tell it to avoid verification or to make a one-shot answer. The operational arm may be explicitly structured around obligation extraction, adversarial numerical checks, bounded fallback and validation. If the ordinary agent naturally does these things, that is a valid result.

A separate strongest conventional implementation can be the public recipe hardened with arbitrary precision/current Boost under the same relevant per-request resource ceiling. Its existence may establish that the outcome is conventionally achievable even if one ordinary sampled agent fails. One execution per arm permits a descriptive case comparison only, not a robust probability-of-success claim. Zero measured advantage does not erase a useful repair.

## Claims that this test cannot establish

- New beta-inversion mathematics or discovery of the already public correction.
- Uniform accuracy over all positive a,b or all binary64 inputs outside the frozen tested/analytically bounded scope.
- A rigorous global error guarantee from agreement on finitely many cases.
- Frequentist confidence-interval coverage, calibration, or safe clinical/financial decisions merely because quantile inversion improves.
- Exact same backend/inference compute, model superiority, general Operational Alpha from one sampled pair, or retained transfer benefit.
- Buyer willingness to pay, actual receipts or unmeasured maintenance cost.

## Exclusions preserved during the search

- statsmodels #10538 and #10536 have active proposed fixes #10539 and #10537, respectively (discovery workstream verified); do not duplicate as new repair.
- SciPy Normal narrow-interval logcdf #26119 has open PR #26125; explicitly excluded after live REST search. The GitHub connector's `search_issues` response did not enforce an `is:pr` query as expected, so exact REST search was used instead.
- SciPy Poisson-binomial tail #26409 has closed, unmerged attempted PR #26446. That proposal says finite logsf below floating-point range remains unresolved. It is a possible supporting comparator/future task, not selected here.
- SciPy Wasserstein negative distance #26490 has closed, unmerged attempted PR #26516, not a completed fix. It would require a strong primal/dual or exact transport comparator; no build began.
- Broad paper-to-counterexample automation and generic replication remain prior-art matches, not headline novelty. The repository's #4993 is specifically archived OCR/calibration uncertainty over authored latent histories; a different numerical inference artifact is distinguishable from that study.

## Sources

- https://github.com/scipy/scipy/issues/26531 and https://api.github.com/repos/scipy/scipy/issues/26531/comments — actual report and current Boost suggestion.
- https://docs.scipy.org/doc/scipy/reference/generated/scipy.special.betaincinv.html — inverse definition, positive shape parameters, Boost backend.
- https://www.boost.org/doc/libs/latest/libs/math/doc/html/math_toolkit/sf_beta/ibeta_inv_function.html — complementary inverses, cancellation-preserving paired output, sensitivity, high-precision test values and established inversion methods.
- mpmath current gamma/beta documentation could not be retrieved by web tool (403); no claim that it was inspected.

No fresh-case code or candidate implementation was written by this reviewer.
