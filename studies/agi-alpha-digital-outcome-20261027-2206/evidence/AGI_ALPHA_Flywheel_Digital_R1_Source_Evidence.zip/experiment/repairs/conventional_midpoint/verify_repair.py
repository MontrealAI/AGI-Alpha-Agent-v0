# SPDX-License-Identifier: Apache-2.0
"""Replay check only; no new blind confirmation claimed."""
from pathlib import Path
import hashlib,json,math,subprocess,sys
from fractions import Fraction
HERE=Path(__file__).resolve().parent
E=HERE.parents[1]
rows=json.loads((HERE/'replay_raw.json').read_text())['rows']
refs=json.loads((E/'fresh_references.json').read_text())
assert len(rows)==len(refs)==64
checks=[]
for rec,ref in zip(rows,refs):
    out=rec['result'];kind=ref['kind'];r=ref['x'];x=out.get('x')
    expected={'numeric':'ok','endpoint':'endpoint','underflow':'underflow','invalid':'invalid','unsupported':'unsupported'}[kind]
    okay=ref['reference_verified'] and rec['id']==ref['id']==out.get('id') and out.get('status')==expected
    if kind in ('invalid','unsupported'):okay=okay and x is None
    elif type(x) not in (int,float) or not math.isfinite(x) or not 0<=x<=1:okay=False
    elif kind in ('endpoint','underflow') or r==1:okay=okay and x==r
    else:okay=okay and x>0 and abs(x-r)<=max(2*math.ulp(r),1e-11*min(r,1-r))
    okay=okay and rec['cpu_seconds']<=5
    checks.append({'id':rec['id'],'pass':bool(okay)})
req={'id':'known-postconfirmation-midpoint','q':math.ulp(0.),'a':1.,'b':2.}
r=subprocess.run([sys.executable,'-B',str(HERE/'run.py')],input=json.dumps(req),text=True,capture_output=True,timeout=15)
out=json.loads(r.stdout) if r.returncode==0 else None
correct=out is not None and out.get('status')=='ok' and out.get('x')==req['q']
delta=Fraction(1,2**1074)
assert 2*(delta/2)-(delta/2)**2<delta
report={'label':'Post-confirmation replay of original64 plus one known development regression; no newly blindcases.','primary_replay_accepted':sum(c['pass'] for c in checks),'primary_replay_total':64,'known_midpoint_pass':correct,'known_midpoint_output':out,'checks':checks,'corrected_solution_sha256':hashlib.sha256((HERE/'solution.py').read_bytes()).hexdigest()}
(HERE/'repair_verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='checks'},indent=2))
assert report['primary_replay_accepted']==64 and correct
