# Corrected conventional comparator — post-confirmation

The frozen conventional arm passed all 64 prespecified fresh cases. A separate known midpoint regression then exposed a defect: for q = 2^-1074, a = 1, b = 2, direct mpmath-to-float conversion returned zero although the correct binary64 quantile is 2^-1074. Ordinary and expert arms had both already corrected this during development.

This copy applies the same standard remedy: 420-digit analytic evaluation for tiny probabilities and direct nearest-even rounding to the binary64 subnormal lattice. It is a conventional numerical correction, not an exclusive agent capability or a globally certified rounding algorithm. The original frozen conventional source and its failed diagnostic remain untouched.

Validation: 64/64 replay of the original bank, plus the exact known midpoint regression. These are post-confirmation replays, not new blind cases. Repair effort and source hashes are in repair_record.json; verify_repair.py reruns the checks against replay_raw.json and the retained references. To recompute numerical outputs, run experiment/worker.py with this directory and experiment/fresh_cases.json, writing replay_raw.json here.

The native kernel is an unchanged copy of the original conventional build. All Python and C++ source in this corrected copy carries the repository Apache-2.0 SPDX identifier. No frozen primary source or acceptance criterion changed.
