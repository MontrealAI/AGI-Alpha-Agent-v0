# SPDX-License-Identifier: Apache-2.0
"""Bounded scalar beta quantiles using established Boost and MP methods.

Exact received binary64 inputs; standard beta continued fraction; safeguarded
Newton in logit coordinates. No SciPy inverse is used as an oracle.
"""
import ctypes,math,os,sys,time
from pathlib import Path
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
VENDOR=Path(os.environ.get('BETA_VENDOR_ROOT',str(HERE.parents[2]/'vendor')))
sys.path.insert(0,str(VENDOR/'mpmath130'))
import mpmath
_IMPORT_START=time.perf_counter()
_NATIVE_ERROR=None
try:
    _LIB=ctypes.CDLL(str(HERE/'kernel.so'))
    _LIB.beta_seed.argtypes=[ctypes.c_double,ctypes.c_double,ctypes.c_double,ctypes.POINTER(ctypes.c_double),ctypes.POINTER(ctypes.c_double),ctypes.c_char_p,ctypes.c_uint]
    _LIB.beta_seed.restype=ctypes.c_int
except Exception as e:
    _LIB=None; _NATIVE_ERROR=str(e)
NATIVE_IMPORT_SECONDS=time.perf_counter()-_IMPORT_START

def _cf(c,a,b,x,deadline):
    """Standard modified-Lentz continued fraction for incomplete beta."""
    qab=a+b; qap=a+1; qam=a-1; tiny=c.mpf('1e-10000')
    C=c.one; D=1-qab*x/qap
    if abs(D)<tiny: D=tiny
    D=1/D; h=D
    for m in range(1,2001):
        m2=2*m
        aa=m*(b-m)*x/((qam+m2)*(a+m2))
        D=1+aa*D; C=1+aa/C
        if abs(D)<tiny: D=tiny
        if abs(C)<tiny: C=tiny
        D=1/D; h*=D*C
        aa=-(a+m)*(qab+m)*x/((a+m2)*(qap+m2))
        D=1+aa*D; C=1+aa/C
        if abs(D)<tiny: D=tiny
        if abs(C)<tiny: C=tiny
        D=1/D; delta=D*C; h*=delta
        if abs(delta-1)<c.mpf('1e-50'): return h,m
        if m%32==0 and time.process_time()>deadline: raise TimeoutError('continued-fraction CPU limit')
    raise ArithmeticError('continued fraction did not converge in 2000 iterations')

def _pair(c,s):
    if s<=0:
        z=c.exp(s); y=1/(1+z); x=z*y
        return x,y,s-c.log1p(z),-c.log1p(z)
    z=c.exp(-s); x=1/(1+z); y=z*x
    return x,y,-c.log1p(z),-s-c.log1p(z)

def _logcdf(c,a,b,s,lb,deadline):
    x,y,lx,ly=_pair(c,s)
    front=a*lx+b*ly-lb
    if x<(a+1)/(a+b+2):
        cf,n=_cf(c,a,b,x,deadline)
        lp=front+c.log(cf/a)
    else:
        cf,n=_cf(c,b,a,y,deadline)
        lc=front+c.log(cf/b)
        if lc>=0: raise ArithmeticError('invalid complemented CDF')
        lp=c.log(-c.expm1(lc))
    return lp,c.exp(front-lp),x,y,n

def _inverse(p,a,b,deadline):
    c=mpmath.mp.clone(); c.dps=420 if p<1e-280 and (a==1.0 or b==1.0) else 65
    A=c.mpf(a); B=c.mpf(b); P=c.mpf(p)
    if b==1.0: return c.exp(c.log(P)/A),'analytic_b1',0,None
    if a==1.0: return -c.expm1(c.log1p(-P)/B),'analytic_a1',0,None
    lb=c.loggamma(A)+c.loggamma(B)-c.loggamma(A+B)
    lp=c.log(P); native_error=_NATIVE_ERROR
    sx=ctypes.c_double(); sy=ctypes.c_double(); buf=ctypes.create_string_buffer(1024)
    if _LIB is not None:
        code=_LIB.beta_seed(a,b,p,ctypes.byref(sx),ctypes.byref(sy),buf,len(buf))
        native_error=buf.value.decode(errors='replace') if code else None
    else: code=1
    if not code and 0<sx.value<=1 and 0<sy.value<=1:
        s=c.log(c.mpf(sx.value))-c.log(c.mpf(sy.value))
    else:
        t=(lp+c.log(A)+lb)/A
        s=t-c.log(-c.expm1(t)) if t<c.mpf('-0.01') else c.log(A/B)
    lo=c.mpf(-4096); hi=c.mpf(4096)
    s=max(lo+1,min(hi-1,s))
    for iteration in range(120):
        if time.process_time()>deadline: raise TimeoutError('inversion CPU limit')
        value,deriv,x,y,terms=_logcdf(c,A,B,s,lb,deadline)
        residual=value-lp
        step=residual/deriv
        if abs(step)<c.mpf('1e-27'):
            return x,'boost_mp_cf' if not code else 'mp_cf_fallback',iteration+1,native_error
        if residual<0: lo=s
        else: hi=s
        proposed=s-step
        if not c.isfinite(proposed) or proposed<=lo or proposed>=hi:
            proposed=(lo+hi)/2
        s=proposed
    raise ArithmeticError('safeguarded root did not converge in 120 iterations')

def _round_binary64(value):
    """Round subnormals directly to nearest-even binary64 lattice units.

    This standard correction is disclosed after primary confirmation. Analytic
    tiny-q roots retain 420 digits so their quadratic term can decide a midpoint.
    It is not a globally certified rounding algorithm for arbitrary shapes.
    """
    c=mpmath.mp.clone(); c.dps=420
    value=c.mpf(value)
    if 0<value<c.mpf(float.fromhex('0x1p-1022')):
        ticks=c.ldexp(value,1074)
        lower=int(c.floor(ticks)); fraction=ticks-lower
        if fraction>c.mpf('.5') or (fraction==c.mpf('.5') and lower%2):
            lower+=1
        return math.ldexp(lower,-1074)
    return float(value)

def solve(request):
    identifier=request.get('id') if isinstance(request,dict) else None
    output={'id':identifier,'status':'invalid','x':None}
    if not isinstance(request,dict): return output
    try:
        raw=[request[k] for k in ('q','a','b')]
        if any(type(v) not in (int,float) for v in raw): return output
        q,a,b=map(float,raw)
    except (KeyError,OverflowError,TypeError,ValueError): return output
    if not all(map(math.isfinite,(q,a,b))) or not 0<=q<=1 or a<=0 or b<=0: return output
    if not (0.25<=a<=1e6 and 0.25<=b<=1e6 and min(a,b)<=100):
        output['status']='unsupported';return output
    if q in (0.0,1.0):
        output.update(status='endpoint',x=q);return output
    start=time.process_time()
    try:
        reflect=q>0.5
        p=1-q if reflect else q
        v,method,iterations,native_error=_inverse(p,b if reflect else a,a if reflect else b,start+4.5)
        if reflect: v=1-v
        x=_round_binary64(v)
        if not math.isfinite(x) or not 0<=x<=1: raise ArithmeticError('invalid final value')
        output.update(status='underflow' if x==0 else 'ok',x=x,method=method,iterations=iterations,cpu_seconds=time.process_time()-start)
        if native_error: output['recovered_seed_error']=native_error
    except Exception as e:
        output.update(status='failed',x=None,error=type(e).__name__+': '+str(e),cpu_seconds=time.process_time()-start)
    return output
