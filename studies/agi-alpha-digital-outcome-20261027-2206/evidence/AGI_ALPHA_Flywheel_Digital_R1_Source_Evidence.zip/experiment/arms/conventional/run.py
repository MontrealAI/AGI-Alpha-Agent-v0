"""JSON object/list CLI; optional input file, otherwise stdin."""
import json,sys
from pathlib import Path
from solution import solve

def main():
    if len(sys.argv)>2: raise SystemExit('usage: python run.py [input.json]')
    text=Path(sys.argv[1]).read_text() if len(sys.argv)==2 else sys.stdin.read()
    try: request=json.loads(text)
    except (ValueError,TypeError):
        print(json.dumps({'id':None,'status':'invalid','x':None}));return
    result=[solve(item) for item in request] if isinstance(request,list) else solve(request)
    print(json.dumps(result,allow_nan=False,separators=(',',':')))
if __name__=='__main__': main()
