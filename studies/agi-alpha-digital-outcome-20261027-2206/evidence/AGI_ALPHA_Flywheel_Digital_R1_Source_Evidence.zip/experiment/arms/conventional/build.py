"""Build the pinned, unmodified Boost.Math header wrapper."""
import json,os,subprocess,time
from datetime import datetime,timezone
from pathlib import Path
HERE=Path(__file__).resolve().parent
VENDOR=Path(os.environ.get('BETA_VENDOR_ROOT',str(HERE.parents[2]/'vendor')))
def build():
    command=['g++','-std=c++17','-O2','-fPIC','-shared','-DBOOST_MATH_STANDALONE','-I'+str(VENDOR/'boost_math/include'),str(HERE/'kernel.cpp'),'-o',str(HERE/'kernel.so')]
    start=time.perf_counter(); completed=subprocess.run(command,text=True,capture_output=True)
    record={'utc':datetime.now(timezone.utc).isoformat(),'command':command,'returncode':completed.returncode,'wall_seconds':time.perf_counter()-start,'stdout':completed.stdout,'stderr':completed.stderr,'compiler':subprocess.run(['g++','--version'],text=True,capture_output=True).stdout}
    (HERE/'build_result.json').write_text(json.dumps(record,indent=2)+'\n')
    if completed.returncode: raise RuntimeError(completed.stderr)
    return record
if __name__=='__main__': print(json.dumps(build(),indent=2))
