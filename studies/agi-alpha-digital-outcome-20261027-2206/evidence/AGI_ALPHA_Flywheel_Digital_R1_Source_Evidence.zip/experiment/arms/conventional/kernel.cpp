#include <boost/math/special_functions/beta.hpp>
#include <boost/math/policies/policy.hpp>
#include <cmath>
#include <cstdio>
#include <exception>
using namespace boost::math::policies;
using Safe=policy<promote_float<false>,promote_double<false>,domain_error<throw_on_error>,pole_error<throw_on_error>,overflow_error<throw_on_error>,evaluation_error<throw_on_error>,max_root_iterations<400>>;
extern "C" int beta_seed(double a,double b,double p,double* x,double* y,char* error,unsigned n) {
  try { *x=boost::math::ibeta_inv(a,b,p,y,Safe{});
    if(!std::isfinite(*x)||!std::isfinite(*y)) {std::snprintf(error,n,"nonfinite Boost estimate");return 2;}
    return 0;
  } catch(const std::exception& e) {std::snprintf(error,n,"%s",e.what());return 1;}
  catch(...) {std::snprintf(error,n,"unknown Boost exception");return 3;}
}
