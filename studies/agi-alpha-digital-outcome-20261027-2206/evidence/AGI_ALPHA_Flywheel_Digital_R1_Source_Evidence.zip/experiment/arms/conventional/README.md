# Conventional scalar beta-quantile compatibility kernel

This package implements the frozen DIGITAL-20261027-R1 contract for one bounded scalar scientific-software mission. It composes established numerical methods; it does not claim discovery of a new inversion algorithm, an upstream SciPy patch, or acceptance beyond the recorded development tests.

## Use

```python
from solution import solve
answer = solve({"id": "example", "q": 1e-300, "a": 2, "b": 1000000})
# status="ok", x approximately 1.4142128552668443e-156
```

```sh
python build.py
python run.py input.json
python run.py < input.json
python development_test.py
```

`run.py` accepts a JSON object or a list and emits corresponding JSON. It accepts either stdin or one optional input path. `solve` returns `id`, `status`, and `x`, plus numerical-method, iteration, CPU-time, and recovered-seed-error diagnostics when relevant. A missing or unusable native wrapper triggers the arbitrary-precision path. Rebuilding is recommended to reproduce the normal Boost-seeded path.

Supported numeric inputs are Python int/float scalars converted to their received binary64 values; booleans, strings, nonfinite values, invalid probabilities, and nonpositive shapes return `invalid`. The bounded supported region is 0 <= q <= 1, 0.25 <= a,b <= 1,000,000, and min(a,b) <= 100. Other finite positive shapes return `unsupported`. Shape validity/support is checked before endpoint handling. Valid q=0 and q=1 return `endpoint` and exact 0/1. An interior quantile rounded to zero returns `underflow`; one rounded to one returns `ok`. Failure returns `failed`, null x, and an explicit diagnostic.

## Numerical workflow

1. Use exact analytic inverses when either shape equals one, with arbitrary-precision `log`, `log1p`, and `expm1` to preserve small probabilities.
2. Reflect probabilities above one half, so root residuals concern the smaller probability. The binary64 subtraction is exact in this range.
3. Ask pinned Boost.Math for a double estimate and its complement. Promotion is disabled; domain, pole, overflow, and evaluation errors throw. The root iteration limit is 400. No exception is interpreted as a successful final iterate.
4. Refine every nonanalytic estimate using a 65-decimal-digit mpmath context. Evaluate the regularized incomplete beta through its standard modified-Lentz continued fraction, using the complementary fraction on the appropriate side of (a+1)/(a+b+2). Log beta is evaluated with high precision log-gamma functions.
5. Solve the log-CDF residual by safeguarded Newton iteration in the logit coordinate. Stable paired logistic values preserve both x and 1-x. A conservative [-4096,4096] coordinate bracket covers the bounded contract. The continued fraction is limited to 2,000 iterations and the root to 120 iterations. The stopping criterion bounds the Newton coordinate correction below 1e-27. This is a practical numerical termination rule, not a formal interval proof.
6. If Boost fails, use the standard leading-order small-tail estimate, or the logit of the mean, then the same safeguarded refinement. Convert to binary64 only at the end. A 4.5 observed CPU-second guard leaves margin under the 5-second per-call limit.

All numerical ingredients are conventional: current Boost inversion, analytic controls, beta continued fractions, high precision arithmetic, symmetry, Newton refinement, and bracketing. The public report already supplies the extreme-tail logarithmic repair recipe. SciPy beta.ppf and special.betaincinv are not treated as independent verifiers.

## Dependencies and portability

The supplied directory layout is:

```
ROOT/vendor/mpmath130/
ROOT/vendor/boost_math/include/
ROOT/vendor/boost_math/LICENSE_1_0.txt
ROOT/experiment/arms/conventional/
```

The default vendor root is resolved as `Path(__file__).resolve().parent.parents[2] / "vendor"`. This is ROOT/vendor for the supplied layout. To move the package independently, set `BETA_VENDOR_ROOT` to the directory containing `mpmath130` and `boost_math`. No global install is needed. `solution.py` disables bytecode writes before importing the shared vendor. Reproduction requires Python 3.12, mpmath 1.3.0, and for the normal native-seeded path, g++ 13.3 and the pinned Boost headers. SciPy and NumPy are available in the common environment but this delivery does not depend on them.

The Boost.Math pin is `70a36632cfbfe6a862cd8a5b88b357ca3a770a3d`. The shared archive SHA256 is `cbbee3c5f17277327735388e64c9f4f2148677da1205a6e52dfb4fda83c09dac`. mpmath 1.3.0 came from the verified wheel with SHA256 `a0b2b9fe80bbcd81a6647ff13108738cfb482d481d826cc0e02f5b35e5c88d2c`. Upstream licenses remain in the common vendor directories; upstream archives are not copied here. `build_result.json` records the exact compiler invocation, version, output, and elapsed time.

## Development evidence

- The initial 85-case authored smoke grid completed with no failed delivery. It covers all five public examples, subnormal q, underflow, central and complementary regimes, and strongly unequal shapes. This grid is not an independent reference check.
- `development_results.json` contains 48 numerical cases, including all five public examples, checked by a separate hypergeometric mpmath incomplete-beta implementation and a bracketed root search at both 80 and 120 decimal digits. Every case converged to the same rounded binary64 reference and the implementation returned that same float. There were no unresolved references and no numerical test failures in this suite.
- The same report records all 17 domain/endpoint/malformed checks passing and a list-input CLI check passing. `final_validation.json` records the final source's replay against the reference floats and additional object, file, and malformed-JSON CLI checks.
- `resource_and_fallback_results.json` records a replay with a 1 GiB address-space cap and 120 CPU-second process cap: 48 solves, approximately 0.08 aggregate CPU seconds, approximately 0.028 maximum reported per-call CPU seconds, approximately 16 MiB peak RSS, and approximately 0.021 seconds to import the module in that run. These are descriptive observations from this environment, not a broad performance benchmark.
- Six deliberate native-unavailable tests recovered successfully through the conventional high precision path. Five independent integer-shape finite binomial-sum CDF controls were consistent with the quantile tolerance; these are residual checks with a first-order error estimate, not a replacement for the converged inverse references.
- Boost actually raised a 400-iteration gamma inverse error for q=5e-324, a=100, b=1,000,000. The fallback recovered. The original error is retained in `attempts/initial_smoke.json` and the per-case outputs. Compilation and the independent reference suite had no observed failures.

The development suites overlap; their case counts should not be added as unique independent trials. Confirmation cases have not been accessed or generated by this arm. There is no empirical human-team comparison, population-level success-rate claim, or service deployment claim.

## Provenance and audit

Public source: [SciPy issue 26531](https://github.com/scipy/scipy/issues/26531), reported by chrisb83 with disclosed AI assistance. The supplied comment asks for testing current Boost master. The complete issue packet, pinned SciPy source excerpts, common current-Boost challenge, and relevant inverse source were read before implementation. The common challenge already demonstrated that the safe double/no-promotion Boost configuration solves all five public examples; this package starts from that conventional result.

`run_manifest.json` records UTC timing, actual tool/command operations, dependencies, interventions, observed failures, and tests. Model billing/token/seed data that were not observed remain null. `attempts/solution_initial.py` preserves the initial implementation before adding bytecode-write prevention; there was no numerical algorithm repair. `hashes.json` and `freeze.json` record final source hashes and the source-freeze boundary. No source editing is permitted after this arm reports completion.
