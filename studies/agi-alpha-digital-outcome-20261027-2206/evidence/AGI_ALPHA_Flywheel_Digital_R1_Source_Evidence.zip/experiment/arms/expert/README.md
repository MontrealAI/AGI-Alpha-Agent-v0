# Bounded scalar beta-quantile kernel

Implements DIGITAL-20261027-R1 `solution.solve(request)` and a JSON CLI using established numerical methods. This is one public software-delivery mission, not a novel algorithm, a vectorized SciPy replacement, upstream acceptance or a customer sale.

## Build and use

Preserve the shared layout: this package is `experiment/arms/expert`; shared assets are three parent levels above it. Paths derive from `__file__`, so no absolute build path is embedded in the Python source.

```sh
python -B build.py
python -B run.py request.json
python -B run.py < requests.json
python -B development_test.py
python -B stress_test.py
python -B rounding_test.py
```

The CLI accepts one object or a list, from stdin or an optional file path. `solve` returns `id`, `status`, `x`, and optional diagnostics. Python 3.12.14, g++ 13.3.0 and mpmath 1.3.0 were observed. The compiler command and build stdout/stderr are retained. No global installation is used.

Shared dependencies: `../../../vendor/boost_math/include` at commit `70a36632cfbfe6a862cd8a5b88b357ca3a770a3d`, and `../../../vendor/mpmath130`. Boost's license remains at `../../../vendor/boost_math/LICENSE_1_0.txt`; mpmath licensing/dist-info remain in its vendor directory. SciPy and NumPy are unused at runtime.

## Contract and methods

q/a/b must be Python int/float values excluding bool, strings and nonfinite values. Values are interpreted as their converted exact binary64 inputs. Supported shapes satisfy 0.25<=a,b<=1e6 and min(a,b)<=100. Nonpositive shapes or q outside [0,1] are invalid; other positive finite shapes are unsupported. Domain checks precede endpoint handling. q=0/1 returns endpoint; interior results rounded to zero return underflow; interior results rounded to one return ok. Failed recovery returns failed/null, never a successful last iterate.

The primary numerical method is current Boost double with promotion disabled, 400 root iterations, and throwing domain/pole/overflow/evaluation policies. It was already known to solve all five public examples. Long double had a documented public failure and is not assumed to improve reliability.

Analytic a=1/b=1 formulas use log1p/expm1 or logarithmic powers. Ordinary analytic work uses 80 digits; q<1e-280 uses 500 digits to retain the second-order term that can decide a subnormal midpoint. Every arbitrary-precision subnormal output is rounded as an integer count of 2^-1074 before float conversion, avoiding mpmath conversion double rounding.

A log leading estimate below -600 selects the 80-digit tiny-tail inverse; its discarded relative correction is below 1e-250 in this bounded region. Binary64 log-gamma only selects the route. Exceptions, nonpositive forward CDF, selected suspicious residuals and every q<1e-280 invoke 80-digit safeguarded Newton in logit coordinates with a classical incomplete-beta continued fraction evaluated by modified Lentz. A bracket, iteration limit and 4.5 CPU-second recovery deadline bound that work. A Boost forward residual is only a diagnostic, not an independent oracle.

## Final verification

| Check | Result | Evidence |
|---|---:|---|
| Public five and adverse numeric cases; independent 80/120-digit bracketed, finite-sum or analytic controls | 62/62, none unresolved | development_results.json |
| Status and input semantics | 17/17 | development_results.json |
| Independent positive-density quadrature for q=minsub and 1e-320, a=1e6,b=.25, at 80/120 digits | 2/2 | stress_results.json |
| Exact rational CDF comparisons at subnormal rounding midpoints for beta(1,b) | 30/30 | rounding_results.json |
| Deterministic authored stress cases | 512/512 agreement | stress_results.json |
| CLI object, list, path and malformed JSON | All completed | stress_results.json |

The stress comparisons independently check the CDF structure for 387 primary Boost cases. The other 125 share the fallback/tiny-tail reference path and are consistency checks only. Independent finite-sum, analytic and quadrature controls separately cover recovery regimes. These are finite development checks, not fresh confirmation or a global rounding proof.

Maximum final observed solve CPU was 0.008001 seconds; stress aggregate solve CPU was 0.161984 seconds. Complete stress checking took 10.234348 CPU seconds and peaked at 29,296 KiB RSS under a 1 GiB/120 CPU-second process cap. Module import took 0.027405 CPU seconds; compilation took 3.844079 wall seconds. Build CPU was not separately observed. Iteration deadlines are not a global execution-time proof.

## Failures and provenance

All failed source versions and evidence remain under attempts/, with some duplicate JSON evidence losslessly gzip-compressed after the shared volume filled during final README writing. The ENOSPC event, partial README and verified decompressed hashes are retained.

The initial package passed 49 resolved checks and had one reference hypergeometric nonconvergence. Eighteen targeted subnormal-q probes then exposed six wrong finite Boost values. Recovery was corrected and the independent reference orientation was improved. A later analytic midpoint check initially falsely agreed with a direct 400-digit-to-float reference. A 500-digit midpoint-excess calculation diagnosed conversion double rounding; integer-unit rounding plus exact rational CDF checks fixed it. The old records intentionally retain those misleading initial reference results.

The midpoint concern was sent to the parent, which said it would independently verify and record any evaluator correction before fresh-bank generation while preserving frozen acceptance. No evaluator or other-arm files were read, and no evaluator modification is asserted here.

The complete issue, contributor comment, log-domain recipe and public examples were read from `../../../discovery/scipy_26531.json`, public issue https://github.com/scipy/scipy/issues/26531. Discovery credit belongs to the public reporter and disclosed assistance. Shared source manifests and the current-Boost challenge were read before construction. See run_manifest.json for execution history, limitations and hashes, and freeze.json for the immutable-source handoff record.
