import sys
sys.dont_write_bytecode=True
import json, math, time, signal, resource, platform
from datetime import datetime, timezone
from pathlib import Path
HERE=Path(__file__).resolve().parent
start_import=time.process_time()
import solution
IMPORT_CPU=time.process_time()-start_import
mpmath=solution.mpmath


def reference(q,a,b,dps):
 mp=mpmath.mp.clone(); mp.dps=dps
 q=mp.mpf(q); a=mp.mpf(a); b=mp.mpf(b)
 if q==0 or q==1: return float(q),'endpoint'
 if a==1: return float(-mp.expm1(mp.log1p(-q)/b)),'analytic'
 if b==1: return float(mp.exp(mp.log(q)/a)),'analytic'
 flip=q>mp.mpf('.5')
 if flip: q=1-q; a,b=b,a
 def cdf(x):
  # Independent exact finite sum for positive integer b<=100.
  if b==int(b) and b<=100:
   y=1-x; term=mp.mpf(1); total=term
   for j in range(1,int(b)):
    term*=((a+j-1)/j)*y; total+=term
   return mp.power(x,a)*total
  return mp.betainc(a,b,0,x,regularized=True)
 logq=mp.log(q); estimate=(logq+mp.log(a)+mp.log(mp.beta(a,b)))/a
 lo=min(mp.mpf(-10),estimate-10); hi=mp.mpf(0)
 while cdf(mp.exp(lo))>q: lo*=2
 for _ in range(190):
  mid=(lo+hi)/2
  if cdf(mp.exp(mid))<q: lo=mid
  else: hi=mid
 x=mp.exp((lo+hi)/2)
 return float(1-x if flip else x),'bracketed_integer_sum' if b==int(b) and b<=100 else 'bracketed_mpmath_betainc'


def alarm(sig,frame): raise TimeoutError('development reference exceeded 4 wall seconds')
signal.signal(signal.SIGALRM,alarm)
public=[(1e-9,.5,2),(1e-16,.5,3),(1e-120,2,10),(1e-300,2,1e6),(1e-200,5,2)]
adverse=[(math.nextafter(0,1),.25,100),(1e-100,.25,.25),(1e-160,.5,2),(1e-161,.5,2),(1e-162,.5,2),
 (1e-300,100,1e6),(1e-300,1e6,2),(1e-100,1e6,10),(.5,100,1e6),(.5,1e6,100),(.5,.25,1e6),(.5,1e6,.25),(.5,.25,.25),
 (.01,.25,100),(.99,100,.25),(math.nextafter(1,0),100,.25),(math.nextafter(1,0),.25,100),
 (1e-20,.7,9.3),(math.nextafter(1e-20,0),.7,9.3),(1.00001e-20,.7,9.3),
 (math.exp(-300.1)/1.5,.5,2),(math.exp(-299.9)/1.5,.5,2)]
for aa,bb in [(1,1),(1,.25),(1,1e6),(.25,1),(1e6,1)]:
 for qq in [math.nextafter(0,1),1e-300,.5,math.nextafter(1,0)]: adverse.append((qq,aa,bb))
# Around the exact half-minimum-subnormal rounding transition.
mp=mpmath.mp.clone();mp.dps=120
qboundary=float(mp.mpf('1.5')*mp.sqrt(mp.power(2,-1075)))
for qq in [math.nextafter(qboundary,0),qboundary,math.nextafter(qboundary,1)]: adverse.append((qq,.5,2))
rows=[]
for i,(q,a,b) in enumerate(public+adverse):
 req={'id':('public_' if i<len(public) else 'adverse_')+str(i),'q':q,'a':a,'b':b}
 t=time.process_time(); got=solution.solve(req); cpu=time.process_time()-t
 row={'request':req,'output':got,'solve_cpu_seconds':cpu,'reference_80':None,'reference_120':None,'accepted':None}
 try:
  signal.setitimer(signal.ITIMER_REAL,4)
  r80,m80=reference(q,a,b,80)
  signal.setitimer(signal.ITIMER_REAL,4)
  r120,m120=reference(q,a,b,120)
  signal.setitimer(signal.ITIMER_REAL,0)
  row.update(reference_80=r80,reference_120=r120,reference_method=m120,reference_converged=r80==r120)
  if r80!=r120: row['reference_error']='precision did not converge'
  else:
   status='underflow' if r120==0 else 'ok'
   tolerance=max(2*math.ulp(r120),1e-11*min(r120,1-r120)) if r120 not in (0,1) else 0
   row.update(tolerance=tolerance,accepted=got['status']==status and got['x'] is not None and abs(got['x']-r120)<=tolerance and cpu<=5)
 except Exception as exc: row['reference_error']=repr(exc)
 finally: signal.setitimer(signal.ITIMER_REAL,0)
 rows.append(row)
 print(req['id'],got['status'],got.get('method'),row['accepted'],row.get('reference_error',''),flush=True)
 (HERE/'development_results.json').write_text(json.dumps({'utc':datetime.now(timezone.utc).isoformat(),'import_cpu_seconds':IMPORT_CPU,'rows':rows},indent=2)+'\n')
status_cases=[({'q':0,'a':.25,'b':1e6},'endpoint'),({'q':1,'a':1e6,'b':.25},'endpoint'),({'q':.5,'a':0,'b':1},'invalid'),({'q':-.1,'a':1,'b':1},'invalid'),({'q':1.1,'a':1,'b':1},'invalid'),({'q':True,'a':1,'b':1},'invalid'),({'q':'.5','a':1,'b':1},'invalid'),({'q':.5,'a':float('nan'),'b':1},'invalid'),({'q':float('inf'),'a':1,'b':1},'invalid'),({'q':.5,'a':.1,'b':1},'unsupported'),({'q':.5,'a':101,'b':101},'unsupported'),({'q':.5,'a':1e6+1,'b':1},'unsupported'),({'q':0,'a':.1,'b':1},'unsupported'),({'q':.5,'a':1},'invalid'),(None,'invalid'),([],'invalid'),({'q':.5,'a':10**1000,'b':1},'invalid')]
statuses=[]
for request,status in status_cases:
 got=solution.solve(request)
 statuses.append({'request_repr':repr(request),'expected':status,'output':got,'accepted':got['status']==status and ((got['x'] is None) if status in ('invalid','unsupported') else True)})
result={'utc':datetime.now(timezone.utc).isoformat(),'python':platform.python_version(),'mpmath':mpmath.__version__,'import_cpu_seconds':IMPORT_CPU,'max_solve_cpu_seconds':max(x['solve_cpu_seconds'] for x in rows),'aggregate_solve_cpu_seconds':sum(x['solve_cpu_seconds'] for x in rows),'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'numeric_accepted':sum(x['accepted'] is True for x in rows),'numeric_failed':sum(x['accepted'] is False for x in rows),'reference_unresolved':sum(x['accepted'] is None for x in rows),'rows':rows,'status_checks':statuses,'status_accepted':sum(x['accepted'] for x in statuses),'limits':'Authored public/development checks only; independent finite-precision validation, no global proof.'}
(HERE/'development_results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('rows','status_checks')},indent=2))
