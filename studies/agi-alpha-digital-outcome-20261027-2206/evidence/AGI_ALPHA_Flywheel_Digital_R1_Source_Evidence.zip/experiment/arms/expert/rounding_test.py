import sys
sys.dont_write_bytecode=True
from pathlib import Path
from fractions import Fraction
from datetime import datetime,timezone
import math,json,time
import solution
HERE=Path(__file__).resolve().parent
minimum=math.nextafter(0,1);unit=Fraction.from_float(minimum)
rows=[]
for b in [2,4,8,16,32]:
 for k in [1,3,5,7,9,11]:
  q=(b//2*k)*minimum
  request={'id':'exact_rounding','q':q,'a':1,'b':b}
  start=time.process_time();out=solution.solve(request);cpu=time.process_time()-start
  # I_x(1,b)=1-(1-x)^b. Compare exact rational probability with exact
  # rational half-ULP rounding boundaries; this is independent of mpmath.
  x=Fraction.from_float(out['x']);qq=Fraction.from_float(q)
  lo=max(Fraction(0),x-unit/2);hi=x+unit/2
  f=lambda t:1-(1-t)**b
  lower,upper=f(lo),f(hi)
  accepted=lower<qq<upper and out['status']=='ok'
  rows.append({'request':request,'output':out,'accepted':accepted,'solve_cpu_seconds':cpu,'method':'exact Fraction CDF comparisons at both subnormal rounding midpoints'})
result={'utc':datetime.now(timezone.utc).isoformat(),'cases':len(rows),'accepted':sum(row['accepted'] for row in rows),'max_solve_cpu_seconds':max(row['solve_cpu_seconds'] for row in rows),'rows':rows,'limitation':'Targeted exact controls for analytic midpoint regime, not a global rounding proof.'}
(HERE/'rounding_results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='rows'},indent=2))
