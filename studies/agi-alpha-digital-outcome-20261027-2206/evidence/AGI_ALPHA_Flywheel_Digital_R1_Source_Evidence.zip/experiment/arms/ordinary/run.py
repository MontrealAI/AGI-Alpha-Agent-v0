"""JSON object/list CLI: python run.py [input.json]."""
import json,sys
from solution import solve
def main():
    if len(sys.argv)>2: raise SystemExit('usage: python run.py [input.json]')
    if len(sys.argv)==2:
        with open(sys.argv[1]) as stream: data=json.load(stream)
    else: data=json.load(sys.stdin)
    output=[solve(item) for item in data] if isinstance(data,list) else solve(data)
    json.dump(output,sys.stdout,allow_nan=False); sys.stdout.write('\n')
if __name__=='__main__': main()
