# Bounded beta-quantile compatibility kernel — ordinary arm

This package provides `solution.solve(request)` and a JSON CLI for the frozen DIGITAL-20261027-R1 scalar contract. It uses conventional numerical methods and shared public sources. It is not a vectorized SciPy replacement, a new inversion algorithm, an upstream submission, or evidence of a customer sale.

## API and supported domain

Pass a dictionary with `id`, `q`, `a`, and `b`. Numeric values must be Python int/float scalars; booleans, strings and nonfinite values are invalid. Inputs are converted to their received binary64 values before numerical evaluation. The supported region is `0 <= q <= 1`, `0.25 <= a,b <= 1e6`, and `min(a,b) <= 100`. Other finite positive shapes return `unsupported`; nonpositive shapes and invalid probabilities return `invalid`.

The result contains `id`, `status`, and `x`. Accepted probabilities return a finite float in [0,1]. Exact probability endpoints return `endpoint`. An interior quantile rounding to zero returns `underflow`; an interior quantile rounding to one returns `ok`. Invalid/unsupported/failed requests have `x: null`. Diagnostic fields give method, iterations, Boost seed failure if any, log-probability residual and solve CPU seconds. Numerical failure is explicit; a failed iterate is never returned as success.

## Use and rebuild

From this package directory:

```sh
python build.py
python run.py < input.json
python run.py input.json
python verify.py
python stress.py
```

The CLI accepts one JSON object or a list. For Python use, import `solve` from `solution.py`. `kernel.so` is the supplied Linux x86_64 build. `build.py` rebuilds it with g++ C++17, optimization, standalone Boost headers and no promotion; the exact command, compiler output, compiler version and elapsed build time are in `build_results.json`.

The default shared asset root is computed as `Path(__file__).resolve().parent.parents[2] / 'vendor'`. For the authorized package layout, this is `/dev/shm/agi_alpha_digital_20261027/vendor`. It contains `boost_math/include` and isolated `mpmath130`. Preserve this relative layout, or set `BETA_VENDOR_ROOT` to a directory with those two children. No giant upstream archive is copied into this package. No global installation is needed. If the shared library is unavailable, the high-precision conventional solver still attempts delivery from its asymptotic/mean seed, and records the missing-library diagnostic. Building before use is recommended.

## Numerical method

1. Validate scalar inputs, domain and exact endpoints.
2. Use closed forms for a=1 or b=1, evaluated with mpmath to avoid endpoint cancellation.
3. Obtain an initial estimate and its complement from pinned Boost `ibeta_inv` using double, disabled promotion, throwing error policies, and a 400-root-iteration limit.
4. Reflect probabilities above one half. Preserve the complementary probability exactly at arbitrary precision.
5. Refine in the logit coordinate using the standard incomplete-beta continued fraction, modified Lentz evaluation and safeguarded Newton steps at 80 decimal digits. The continued fraction chooses the numerically suitable side. A bracket bounds the iteration; the stopping rule uses the probability residual divided by its derivative. This extends the public issue's log-domain recipe using established methods.
6. Round subnormal values directly to the binary64 lattice with ties to even. This avoids double rounding through a normal 53-bit significand. Analytic cases with probabilities below 1e-280 use 420 digits to retain corrections that decide a subnormal halfway case.

Each solve has a 4.5 CPU-second internal numerical deadline and bounded iteration counts. Compilation and import are measured separately. This is a finite tested implementation, not a proof of correct rounding for every real shape in the bounded domain. The stated acceptance tolerance remains the frozen one; no requirements have been weakened.

## Sources and credit

- Public report and supplied repair recipe: https://github.com/scipy/scipy/issues/26531 . Reporter chrisb83 disclosed AI assistance. The report and contributor comment recommending current Boost were read in full from `../../../discovery/scipy_26531.json`.
- Shared current-Boost challenge: `../../../boost_challenge/README.md`, `protocol.json`, `verification.json`, `build.json`, and `retrieval_manifest.json`. This already established that the conventional double/no-promotion/safe400 configuration solves all five public examples; long double failed one. The present work does not claim discovery of that result.
- Boost.Math commit `70a36632cfbfe6a862cd8a5b88b357ca3a770a3d`. Shared Boost Software License 1.0 is at `../../../vendor/boost_math/LICENSE_1_0.txt`; upstream notices remain in its headers. Relevant inversion source was inspected from the supplied discovery snapshot.
- mpmath 1.3.0 comes from the verified isolated wheel under `../../../vendor/mpmath130`; its license and dist-info are preserved there.
- Relevant supplied SciPy wrappers and beta distribution source were inspected from `../../../discovery/beta_sources/`. The snapshot of SciPy HEAD already routes beta PPF to `betaincinv`; this package addresses the reproduced environment's numerical delivery requirement, not a claim that HEAD is unchanged.

## Development evidence and retained failures

`development_results.json` records 58 numerical checks (including the five public examples, exact binary64 inputs, subnormal tails, central cases, complements, analytic controls and a deterministic authored random sample), 14 input-contract checks, CLI execution, import timing, and all results. Numerical references independently use mpmath `betainc` in a bracketed inversion at 80 and 120 digits. Analytic subnormal controls use higher precision. SciPy beta PPF and betaincinv agreement is not used as independent evidence.

`stress_results.json` separately records six large-shape checks at 80/120 digits using an independent positive quadrature transformation where needed. It also records 200 finite-result/resource checks over the declared shape range; those 200 have no independent numerical oracle and are not counted as numerical accuracy confirmation. `integer_controls.json` checks seven cases against independent terminating integer-shape CDF identities at 400/450 digits.

Two observed development failures are preserved:

- `attempts/001_before_subnormal_rounding/`: the first implementation and its test references used mpmath's float conversion. For q equal to the smallest subnormal, a=1,b=2, the exact quantile is strictly greater than q/2, so it rounds to the smallest subnormal. The conversion returned zero because it rounded twice. The initial test suite also missed this shared conversion defect. An analytic control exposed it; explicit lattice rounding repaired it. Initial source, test script, results and concrete failure evidence are retained.
- `attempts/002_unscaled_quadrature_oracle/`: the first independent quadrature check used an integral of absolute magnitude around 1e-396. Both 80- and 120-digit calls agreed on an inaccurate result for q=.5,a=1e6,b=99.75 because absolute quadrature tolerance hid relative error. The reference integrand was normalized before rerunning; the delivery kernel was unchanged. Original reference source/results and the intervention are retained.

A source-inspection tool output was truncated; targeted policy and final-iteration sections were read again. Compilation succeeded without retries. Remaining limitations, exact command/tool history, timestamps and source hashes are in `run_manifest.json`. All data here are public/authored development evidence. Fresh confirmation belongs to the root workflow and is generated only after source freeze.
