"""Bounded scalar beta inverse using pinned Boost and arbitrary-precision refinement.

The continued fraction and safeguarded Newton iteration are conventional methods;
the public issue supplies the log-coordinate inversion approach. No novelty claimed.
"""
from pathlib import Path
import ctypes, math, os, sys, time
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
VENDOR=Path(os.environ.get('BETA_VENDOR_ROOT',str(ROOT/'vendor')))
sys.path.insert(0,str(VENDOR/'mpmath130'))
import mpmath
try:
    _lib=ctypes.CDLL(str(HERE/'kernel.so'))
    _seed=_lib.beta_seed
    _seed.argtypes=[ctypes.c_double]*3+[ctypes.POINTER(ctypes.c_double)]*2+[ctypes.c_char_p,ctypes.c_uint]
    _seed.restype=ctypes.c_int
    _load_error=None
except OSError as exc:
    _seed=None
    _load_error=str(exc)

def _fraction(m,a,b,x,deadline):
    """Standard incomplete-beta continued fraction, modified Lentz evaluation."""
    qab=a+b; qap=a+1; qam=a-1
    tiny=m.mpf('1e-1000')
    c=m.one; d=1-qab*x/qap
    if abs(d)<tiny: d=tiny
    d=1/d; h=d
    for n in range(1,10001):
        k=2*n
        v=n*(b-n)*x/((qam+k)*(a+k))
        d=1+v*d; c=1+v/c
        if abs(d)<tiny: d=tiny
        if abs(c)<tiny: c=tiny
        d=1/d; h*=d*c
        v=-(a+n)*(qab+n)*x/((a+k)*(qap+k))
        d=1+v*d; c=1+v/c
        if abs(d)<tiny: d=tiny
        if abs(c)<tiny: c=tiny
        d=1/d; delta=d*c; h*=delta
        if abs(delta-1)<m.mpf('1e-55'): return h
        if n%32==0 and time.process_time()>deadline:
            raise TimeoutError('continued fraction CPU budget')
    raise ArithmeticError('continued fraction did not converge')

def _quantile(q,a,b,deadline):
    m=mpmath.mp.clone(); m.dps=80
    Q=m.mpf(q); A=m.mpf(a); B=m.mpf(b)
    # Analytic controls avoid endpoint cancellation. Extra precision retains
    # corrections that decide rounding at the subnormal halfway threshold.
    if a==1 or b==1:
        if q<1e-280: m.dps=420; Q=m.mpf(q); A=m.mpf(a); B=m.mpf(b)
        z=-m.expm1(m.log1p(-Q)/B) if a==1 else m.power(Q,1/A)
        return float(z),{'method':'analytic','iterations':0}
    reflected=q>0.5
    if reflected: A,B=B,A; Q=1-Q
    p=float(Q)
    err=ctypes.create_string_buffer(2048); xx=ctypes.c_double(); yy=ctypes.c_double()
    seed_status=_seed(p,float(A),float(B),ctypes.byref(xx),ctypes.byref(yy),err,len(err)) if _seed else 4
    lb=m.loggamma(A)+m.loggamma(B)-m.loggamma(A+B)
    lp=m.log(Q)
    leading=(lp+m.log(A)+lb)/A
    if seed_status==0 and 0<xx.value<1 and 0<yy.value<1:
        t=m.log(m.mpf(xx.value)/m.mpf(yy.value))
    elif leading < -m.mpf('0.1'):
        t=leading-m.log1p(-m.exp(leading))
    else: t=m.log(A/B)
    lo=m.mpf(-4096); hi=m.mpf(80)
    t=max(lo+1,min(hi-1,t))
    for iteration in range(1,101):
        if time.process_time()>deadline: raise TimeoutError('refinement CPU budget')
        lx=-m.log1p(m.exp(-t)); ly=-m.log1p(m.exp(t))
        x=m.exp(lx); y=m.exp(ly)
        pref=A*lx+B*ly-lb
        if x<(A+1)/(A+B+2):
            fval=pref+m.log(_fraction(m,A,B,x,deadline)/A)
        else:
            tail=pref+m.log(_fraction(m,B,A,y,deadline)/B)
            fval=m.log1p(-m.exp(tail))
        f=fval-lp
        deriv=m.exp(pref-fval)
        step=f/deriv
        if abs(step)<m.mpf('1e-35'):
            result=y if reflected else x
            diagnostics={'method':'boost_seed_mp_refinement','iterations':iteration,
                         'log_probability_residual':float(f),'seed_status':seed_status}
            if seed_status: diagnostics['seed_error']=err.value.decode(errors='replace') or _load_error
            return float(result),diagnostics
        if f>0: hi=t
        else: lo=t
        candidate=t-step
        t=candidate if lo<candidate<hi else (lo+hi)/2
    raise ArithmeticError('safeguarded Newton did not converge')

def solve(request):
    """Return the frozen scalar JSON response contract; never silently return an iterate."""
    result={'id':request.get('id') if isinstance(request,dict) else None,'status':'invalid','x':None}
    if not isinstance(request,dict): return result
    numbers=[]
    for key in ('q','a','b'):
        value=request.get(key)
        if isinstance(value,bool) or not isinstance(value,(int,float)): return result
        try: value=float(value)
        except (OverflowError,ValueError): return result
        if not math.isfinite(value): return result
        numbers.append(value)
    q,a,b=numbers
    if not 0<=q<=1 or a<=0 or b<=0: return result
    if not (0.25<=a<=1e6 and 0.25<=b<=1e6 and min(a,b)<=100):
        result['status']='unsupported'; return result
    if q==0 or q==1:
        result.update(status='endpoint',x=q); return result
    start=time.process_time()
    try:
        x,diagnostics=_quantile(q,a,b,start+4.5)
        if not math.isfinite(x) or not 0<=x<=1: raise ArithmeticError('nonfinite or out-of-range quantile')
        result.update(status='underflow' if x==0 else 'ok',x=x,diagnostics=diagnostics)
    except Exception as exc:
        result.update(status='failed',error=type(exc).__name__+': '+str(exc))
    result['cpu_seconds']=time.process_time()-start
    return result
