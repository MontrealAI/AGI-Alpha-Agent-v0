"""Development evidence. Independent mpmath betainc bracketed inversion at 80/120 dps."""
from pathlib import Path
from datetime import datetime, timezone
import json, math, random, sys, time, subprocess, platform
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
t0=time.perf_counter()
from solution import solve, VENDOR
import mpmath
IMPORT_WALL=time.perf_counter()-t0

def reference(q,a,b,dps):
    m=mpmath.mp.clone(); m.dps=dps
    A=m.mpf(a); B=m.mpf(b); Q=m.mpf(q)
    if a==1 or b==1:
        if q<1e-280: m.dps=dps+400; A=m.mpf(a); B=m.mpf(b); Q=m.mpf(q)
        return float(-m.expm1(m.log1p(-Q)/B) if a==1 else m.power(Q,1/A))
    reflected=q>0.5
    if reflected: A,B=B,A; Q=1-Q
    lp=m.log(Q); lb=m.log(m.beta(A,B))
    # Independent starting approximation and guaranteed global bracket.
    leading=(lp+m.log(A)+lb)/A
    lo=m.mpf(-4096); hi=m.mpf(80)
    t=leading-m.log1p(-m.exp(leading)) if leading<-m.mpf('.1') else m.log(A/B)
    t=max(lo+1,min(hi-1,t))
    for k in range(300):
        x=1/(1+m.exp(-t)); y=1/(1+m.exp(t))
        if x<=m.mpf('.5'):
            F=m.betainc(A,B,0,x,regularized=True)
        else:
            F=m.betainc(A,B,0,x,regularized=True)
        if F<=0 or F>1: raise ArithmeticError('reference CDF range')
        lf=m.log(F); f=lf-lp
        derivative=m.exp(A*m.log(x)+B*m.log(y)-lb-lf)
        step=f/derivative
        if abs(step)<m.mpf('1e-45'):
            return float(y if reflected else x)
        if f>0: hi=t
        else: lo=t
        candidate=t-step
        t=candidate if lo<candidate<hi else (lo+hi)/2
    raise ArithmeticError('independent bracketed reference nonconvergence')

cases=[]
def add(q,a,b,group): cases.append({'id':f'{group}_{len(cases):03d}','q':q,'a':a,'b':b,'group':group})
for q,a,b in [(1e-9,.5,2),(1e-16,.5,3),(1e-120,2,10),(1e-300,2,1e6),(1e-200,5,2)]: add(q,a,b,'public')
for q,a,b in [(5e-324,.25,2),(5e-324,.5,2),(5e-324,2,10),(5e-324,100,1e6),
 (1e-160,.5,3),(1e-162,.5,3),(1e-80,.25,1e6),(1e-81,.25,2),
 (.1,.25,1e6),(.5,100,1e6),(.9,100,1e6),(.1,1e6,2),(1e-300,1e6,2),
 (.9999999999999999,.25,.25),(.9999999999999999,2,.25),(.5,.25,.25),(.5,100,100),
 (1e-280,100,.25),(.99,.25,100),(1e-12,2.75,999999.5)]: add(q,a,b,'adverse')
for q,a,b in [(5e-324,1,2),(5e-324,1,1e6),(5e-324,1,.25),(1e-320,1,3),
 (5e-324,.25,1),(.9999999999999999,1,.25),(.5,1e6,1),(1e-300,100,1)]: add(q,a,b,'analytic')
rng=random.Random(20261027)
for k in range(25):
 a=10**rng.uniform(math.log10(.25),2); b=10**rng.uniform(math.log10(.25),2)
 q=10**rng.uniform(-320,-1) if k<15 else rng.uniform(.001,.999)
 add(q,a,b,'random_development')
records=[]; log=HERE/'development_rows.jsonl'
with log.open('w') as stream:
 for i,c in enumerate(cases):
  out=solve(c); rec={'request':c,'output':out}
  try:
   r80=reference(c['q'],c['a'],c['b'],80); r120=reference(c['q'],c['a'],c['b'],120)
   rec.update(reference80=r80,reference120=r120,precision_converged=r80==r120)
   tol=max(2*math.ulp(r120),1e-11*min(r120,1-r120))
   expected='underflow' if r120==0 else 'ok'
   rec.update(tolerance=tol,absolute_error=abs(out['x']-r120) if out['x'] is not None else None)
   rec['passed']=(r80==r120 and out['status']==expected and out['x'] is not None and abs(out['x']-r120)<=tol and out['cpu_seconds']<=5)
  except Exception as e: rec.update(passed=False,unresolved_reference=type(e).__name__+': '+str(e))
  records.append(rec); stream.write(json.dumps(rec)+'\n'); stream.flush()
  print(i,c['id'],out['status'],rec['passed'],round(out.get('cpu_seconds',0),5),rec.get('unresolved_reference',''),flush=True)
validation=[({'q':0,'a':2,'b':3},'endpoint',0),({'q':1,'a':2,'b':3},'endpoint',1),
 ({'q':.5,'a':101,'b':101},'unsupported',None),({'q':.5,'a':.1,'b':2},'unsupported',None),
 ({'q':.5,'a':1e6+1,'b':2},'unsupported',None),({'q':.5,'a':0,'b':2},'invalid',None),
 ({'q':True,'a':2,'b':3},'invalid',None),({'q':'0.2','a':2,'b':3},'invalid',None),
 ({'q':float('nan'),'a':2,'b':3},'invalid',None),({'q':.5,'a':float('inf'),'b':3},'invalid',None),
 ({'q':-.1,'a':2,'b':3},'invalid',None),({'q':1.1,'a':2,'b':3},'invalid',None),
 ({'q':.5,'a':2},'invalid',None),([], 'invalid',None)]
vr=[]
for i,(req,status,x) in enumerate(validation):
 out=solve(req); vr.append({'id':i,'input_repr':repr(req),'output':out,'passed':out['status']==status and out['x']==x})
cli_input=json.dumps([{'id':'cli_public','q':1e-300,'a':2,'b':1e6},{'id':'cli_endpoint','q':0,'a':2,'b':3}])
cli=subprocess.run([sys.executable,str(HERE/'run.py')],input=cli_input,text=True,capture_output=True)
cli_test={'command':[sys.executable,str(HERE/'run.py')],'input':json.loads(cli_input),'returncode':cli.returncode,'stdout':cli.stdout,'stderr':cli.stderr,'passed':cli.returncode==0 and len(json.loads(cli.stdout))==2}
results={'utc':datetime.now(timezone.utc).isoformat(),'label':'public and authored development only; not confirmation',
 'reference_method':'independent mpmath betainc with bracketed Newton at 80/120 dps, analytic controls at elevated precision for subnormal rounding',
 'numeric':records,'validation':vr,'cli':cli_test,'import_wall_seconds':IMPORT_WALL,
 'dependencies':{'python':sys.version,'mpmath_version':mpmath.__version__,'mpmath_path':mpmath.__file__},
 'numeric_passed':sum(r['passed'] for r in records),'numeric_total':len(records),
 'validation_passed':sum(r['passed'] for r in vr),'validation_total':len(vr),
 'maximum_solve_cpu_seconds':max(r['output'].get('cpu_seconds',0) for r in records)}
(HERE/'development_results.json').write_text(json.dumps(results,indent=2))
print('SUMMARY',json.dumps({k:v for k,v in results.items() if k not in ['numeric','validation','cli','dependencies']}),flush=True)
