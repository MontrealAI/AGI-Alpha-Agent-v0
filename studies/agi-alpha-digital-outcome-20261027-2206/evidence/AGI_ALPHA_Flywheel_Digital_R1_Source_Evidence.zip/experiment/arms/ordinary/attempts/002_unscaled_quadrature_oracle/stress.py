"""Additional large-shape development checks with a positive quadrature oracle."""
from pathlib import Path
from datetime import datetime, timezone
import json,math,random,sys,time
from solution import solve
import mpmath
HERE=Path(__file__).resolve().parent

def quad_reference(q,a,b,dps,seed):
 m=mpmath.mp.clone();m.dps=dps
 Q=m.mpf(q);A=m.mpf(a);B=m.mpf(b)
 if q>.5:
  A,B=B,A;Q=1-Q;reflected=True
 else: reflected=False
 lb=m.log(m.beta(A,B));lp=m.log(Q)
 if 0<seed<1: x=1-m.mpf(seed) if reflected else m.mpf(seed)
 else: x=m.exp((lp+m.log(A)+lb)/A)
 t=m.log(x/(1-x));lo=t-1;hi=t+1
 for k in range(20):
  x=1/(1+m.exp(-t));y=1/(1+m.exp(t))
  if A>10000 and x>.9:
   # t=x*exp(-u/a) transforms the beta integral into a positive,
   # exponentially decaying integral, independently of the solver's CF.
   integrand=lambda u:m.exp(-u)*(-m.expm1(m.log(x)-u/A))**(B-1)
   integral=m.quad(integrand,[0,1,4,16,64,m.inf])
   lf=A*m.log(x)-m.log(A)-lb+m.log(integral)
  else: lf=m.log(m.betainc(A,B,0,x,regularized=True))
  f=lf-lp;d=m.exp(A*m.log(x)+B*m.log(y)-lb-lf);step=f/d
  if abs(step)<m.mpf('1e-35'):return float(y if reflected else x)
  if f>0:hi=t
  else:lo=t
  nt=t-step;t=nt if lo<nt<hi else (lo+hi)/2
 raise ArithmeticError('quadrature reference nonconvergence')

cases=[(5e-324,1e6,.25),(1e-300,1e6,.5),(.1,1e6,.25),(.5,1e6,99.75),
       (.9999999999999999,1e6,.25),(.9999999999999999,.25,1e6)]
records=[]
for i,(q,a,b) in enumerate(cases):
 req={'id':f'large_quad_{i}','q':q,'a':a,'b':b};out=solve(req)
 rec={'request':req,'output':out}
 try:
  refs=[quad_reference(q,a,b,dps,out['x']) for dps in (80,120)]
  tol=max(2*math.ulp(refs[1]),1e-11*min(refs[1],1-refs[1]))
  rec.update(references=refs,tolerance=tol,passed=refs[0]==refs[1] and out['x'] is not None and abs(out['x']-refs[1])<=tol and out['cpu_seconds']<=5)
 except Exception as e:rec.update(passed=False,unresolved_reference=str(e))
 records.append(rec);print(json.dumps(rec),flush=True)
 (HERE/'stress_results.json').write_text(json.dumps({'quadrature':records},indent=2))
rng=random.Random(10817027);timing=[]
for i in range(200):
 small=10**rng.uniform(math.log10(.25),2);large=10**rng.uniform(2,6)
 a,b=(small,large) if i%2 else (large,small)
 q=(10**rng.uniform(-323,-.01)) if i%3 else rng.uniform(.000001,.999999)
 req={'id':f'resource_{i}','q':q,'a':a,'b':b};out=solve(req)
 timing.append({'request':req,'output':out,'passed':out['status'] in ['ok','underflow'] and out['cpu_seconds']<=5})
summary={'utc':datetime.now(timezone.utc).isoformat(),'quadrature':records,'resource_sweep':timing,
 'quadrature_passed':sum(r['passed'] for r in records),'quadrature_total':len(records),
 'resource_passed':sum(r['passed'] for r in timing),'resource_total':len(timing),
 'maximum_solve_cpu_seconds':max(r['output']['cpu_seconds'] for r in records+timing),
 'aggregate_solve_cpu_seconds':sum(r['output']['cpu_seconds'] for r in records+timing),
 'warning':'Resource sweep asserts finite bounded delivery and timing only; no independent numerical reference for its 200 cases.'}
(HERE/'stress_results.json').write_text(json.dumps(summary,indent=2))
print('SUMMARY',json.dumps({k:v for k,v in summary.items() if k not in ['quadrature','resource_sweep']}),flush=True)
