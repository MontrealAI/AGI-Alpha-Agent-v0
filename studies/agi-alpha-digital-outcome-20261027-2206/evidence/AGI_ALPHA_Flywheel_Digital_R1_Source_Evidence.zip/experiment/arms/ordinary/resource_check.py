"""Verify the delivered worker under the frozen address-space and CPU ceilings."""
import json,resource,sys,time
from pathlib import Path
resource.setrlimit(resource.RLIMIT_AS,(1<<30,1<<30))
resource.setrlimit(resource.RLIMIT_CPU,(120,120))
sys.dont_write_bytecode=True
start_cpu=time.process_time();start_wall=time.perf_counter()
from solution import solve
import mpmath
import_cpu=time.process_time()-start_cpu;import_wall=time.perf_counter()-start_wall
HERE=Path(__file__).resolve().parent
development=json.loads((HERE/'development_results.json').read_text())
rows=[]
for row in development['numeric']:
 out=solve(row['request']);r=row['reference120'];tol=row['tolerance']
 rows.append({'id':row['request']['id'],'output':out,'passed':out['status']==('underflow' if r==0 else 'ok') and out['x'] is not None and abs(out['x']-r)<=tol and out['cpu_seconds']<=5})
result={'limits':{'address_space_bytes':1<<30,'cpu_seconds':120},'import_cpu_seconds':import_cpu,
 'import_wall_seconds':import_wall,'python':sys.version,'mpmath':mpmath.__version__,'mpmath_path':mpmath.__file__,
 'passed':sum(r['passed'] for r in rows),'total':len(rows),'rows':rows,
 'maximum_solve_cpu_seconds':max(r['output']['cpu_seconds'] for r in rows),
 'aggregate_solve_cpu_seconds':sum(r['output']['cpu_seconds'] for r in rows),
 'maximum_resident_set_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
print(json.dumps(result))
