from pathlib import Path
import json,math,hashlib
ROOT=Path(__file__).resolve().parent
cases=json.loads((ROOT/"fresh_cases.json").read_text());refs=json.loads((ROOT/"fresh_references.json").read_text());groups=json.loads((ROOT/"fresh_case_metadata.json").read_text())["groups"]
assert len(cases)==len(refs)==64 and [x["id"] for x in cases]==[x["id"] for x in refs]
reports=[]
for arm in ("ordinary","expert","conventional"):
    raw=json.loads((ROOT/(arm+"_raw.json")).read_text());rows=raw["rows"];assert len(rows)==64 and [x["id"] for x in rows]==[x["id"] for x in cases]
    checks=[]
    for req,ref,rec in zip(cases,refs,rows):
        out=rec.get("result");errors=[];diff=None;tol=None
        if not ref["reference_verified"]:errors.append("unresolved_reference")
        if not isinstance(out,dict):errors.append("no_output_object")
        else:
            if out.get("id")!=req["id"]:errors.append("id_mismatch")
            expected={"numeric":"ok","underflow":"underflow","endpoint":"endpoint","invalid":"invalid","unsupported":"unsupported"}.get(ref["kind"])
            if out.get("status")!=expected:errors.append("status")
            x=out.get("x")
            if ref["kind"] in ("invalid","unsupported"):
                if x is not None:errors.append("refusal_has_value")
            elif ref["reference_verified"]:
                if isinstance(x,bool) or not isinstance(x,(int,float)) or not math.isfinite(x) or not 0<=x<=1:errors.append("invalid_numeric_value")
                elif ref["kind"] in ("endpoint","underflow") or ref["x"]==1:
                    if x!=ref["x"]:errors.append("endpoint_or_rounding_value")
                else:
                    diff=abs(x-ref["x"]);tol=max(2*math.ulp(ref["x"]),1e-11*min(ref["x"],1-ref["x"]))
                    if x==0 or diff>tol:errors.append("quantile_error")
        if rec["cpu_seconds"]>5:errors.append("cpu_allowance")
        checks.append({"id":req["id"],"group":groups[req["id"]],"pass":not errors,"errors":errors,"absolute_error":diff,"tolerance":tol,"cpu_seconds":rec["cpu_seconds"],"wall_seconds":rec["wall_seconds"]})
    report={"arm":arm,"cases":64,"accepted":sum(x["pass"] for x in checks),"numeric_and_endpoint_cases":sum(r["kind"] not in ("invalid","unsupported") for r in refs),"numeric_and_endpoint_accepted":sum(c["pass"] for c,r in zip(checks,refs) if r["kind"] not in ("invalid","unsupported")),"correct_refusals":sum(c["pass"] for c,r in zip(checks,refs) if r["kind"] in ("invalid","unsupported")),"solve_cpu_seconds":sum(x["cpu_seconds"] for x in rows),"solve_wall_seconds":sum(x["wall_seconds"] for x in rows),"max_cpu_seconds":max(x["cpu_seconds"] for x in rows),"import_and_build_cpu_seconds":raw["import_and_build_cpu_seconds"],"peak_rss_kib":raw["peak_rss_kib"],"checks":checks}
    (ROOT/(arm+"_score.json")).write_text(json.dumps(report,indent=2)+"\n");reports.append({k:v for k,v in report.items() if k!="checks"})
summary={"primary_results":reports,"reference_cases_verified":sum(r["reference_verified"] for r in refs),"interpretation":"One available-assistant implementation trial per arm on one public mission;64 authored fresh numerical/status cases. No population success rate, provider-attested parity, token-cost advantage, discovery credit or general OperationalAlpha established by these counts."}
(ROOT/"comparison_results.json").write_text(json.dumps(summary,indent=2)+"\n");print(json.dumps(summary,indent=2))
