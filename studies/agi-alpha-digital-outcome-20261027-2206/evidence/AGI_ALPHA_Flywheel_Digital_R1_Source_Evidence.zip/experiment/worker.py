from pathlib import Path
import os,sys,json,resource,importlib.util,time,signal,warnings,math
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"vendor/mpmath130"))
arm=Path(sys.argv[1]);cases=json.loads(Path(sys.argv[2]).read_text());outfile=Path(sys.argv[3]);sys.path.insert(0,str(arm))
resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3));resource.setrlimit(resource.RLIMIT_CPU,(120,125))
def cpu():
    c=resource.getrusage(resource.RUSAGE_CHILDREN);return time.process_time()+c.ru_utime+c.ru_stime
def clean(v):
    if isinstance(v,float) and not math.isfinite(v):return str(v)
    if isinstance(v,dict):return {str(k):clean(x) for k,x in v.items()}
    if isinstance(v,(list,tuple)):return [clean(x) for x in v]
    return v
start=time.perf_counter();ic=cpu();spec=importlib.util.spec_from_file_location("arm_solution",arm/"solution.py");m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
import_seconds=time.perf_counter()-start;import_cpu=cpu()-ic
rows=[]
def alarm(signum,frame):raise TimeoutError("10-second per-call wall guard")
signal.signal(signal.SIGALRM,alarm)
for req in cases:
    t=time.perf_counter();c=cpu();signal.alarm(10)
    try:
        with warnings.catch_warnings(record=True) as ws:
            warnings.simplefilter("always");result=m.solve(req)
        row={"id":req.get("id"),"result":clean(result),"warnings":[str(w.message) for w in ws]}
    except Exception as ex:row={"id":req.get("id"),"result":None,"exception":type(ex).__name__+": "+str(ex)}
    finally:signal.alarm(0)
    row.update({"cpu_seconds":cpu()-c,"wall_seconds":time.perf_counter()-t});rows.append(row)
    outfile.write_text(json.dumps({"arm":arm.name,"import_wall_seconds":import_seconds,"import_and_build_cpu_seconds":import_cpu,"rows":rows,"complete":len(rows)==len(cases),"peak_rss_kib":resource.getrusage(resource.RUSAGE_SELF).ru_maxrss},indent=2,allow_nan=False)+"\n")
print(json.dumps({"arm":arm.name,"cases":len(rows),"import_cpu":import_cpu,"solve_cpu":sum(x["cpu_seconds"] for x in rows)}))
