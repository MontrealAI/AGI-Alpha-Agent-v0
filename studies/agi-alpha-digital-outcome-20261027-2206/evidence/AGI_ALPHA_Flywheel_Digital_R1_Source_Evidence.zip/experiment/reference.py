from pathlib import Path
import sys, math, json, time
from fractions import Fraction
from math import comb
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"vendor/mpmath130"))
import mpmath as mp

def domain(r):
    try:
        if not isinstance(r,dict) or any(k not in r for k in ("id","q","a","b")): return "invalid"
        for k in ("q","a","b"):
            if isinstance(r[k],bool) or not isinstance(r[k],(int,float)) or not math.isfinite(float(r[k])): return "invalid"
        q,a,b=(float(r[k]) for k in ("q","a","b"))
        if not 0<=q<=1 or a<=0 or b<=0:return "invalid"
        if min(a,b)<.25 or max(a,b)>1e6 or min(a,b)>100:return "unsupported"
        return "endpoint" if q in (0.,1.) else "numeric"
    except (ValueError,TypeError,OverflowError):return "invalid"

def cf(a,b,x):
    tiny=mp.power(10,-4*mp.mp.dps); eps=mp.power(10,-mp.mp.dps+15)
    qab=a+b;qap=a+1;qam=a-1;c=mp.mpf(1);d=1-qab*x/qap
    if abs(d)<tiny:d=tiny
    d=1/d;h=d;stable=0
    for m in range(1,20001):
        m=mp.mpf(m);m2=2*m
        aa=m*(b-m)*x/((qam+m2)*(a+m2))
        d=1+aa*d;c=1+aa/c
        if abs(d)<tiny:d=tiny
        if abs(c)<tiny:c=tiny
        d=1/d;h*=d*c
        aa=-(a+m)*(qab+m)*x/((a+m2)*(qap+m2))
        d=1+aa*d;c=1+aa/c
        if abs(d)<tiny:d=tiny
        if abs(c)<tiny:c=tiny
        d=1/d;delta=d*c;h*=delta
        stable=stable+1 if abs(delta-1)<eps else 0
        if stable>=3:
            if h<=0:raise ArithmeticError("nonpositive continued fraction")
            return h
    raise ArithmeticError("continued fraction did not converge")

def logcdf(a,b,x,lb):
    if x<=0:return mp.ninf
    if x>=1:return mp.mpf(0)
    t=a*mp.log(x)+b*mp.log1p(-x)-lb
    if x<(a+1)/(a+b+2):return t+mp.log(cf(a,b,x))-mp.log(a)
    lt=t+mp.log(cf(b,a,1-x))-mp.log(b)
    if lt>=0:raise ArithmeticError("complement invalid")
    return mp.log(-mp.expm1(lt))

def inverse(q,a,b,dps,logtol="1e-30"):
    with mp.workdps(dps):
        q,a,b=mp.mpf(q),mp.mpf(a),mp.mpf(b)
        if q==0 or q==1:return +q
        flip=q>mp.mpf('.5')
        if flip:q,a,b=1-q,b,a
        if a==1:y=-mp.expm1(mp.log1p(-q)/b)
        elif b==1:y=mp.exp(mp.log(q)/a)
        else:
            lb=mp.loggamma(a)+mp.loggamma(b)-mp.loggamma(a+b);lq=mp.log(q)
            t0=(lq+mp.log(a)+lb)/a;lo=min(mp.mpf(-1),t0-2);hi=mp.mpf(0)
            while logcdf(a,b,mp.exp(lo),lb)>lq:lo*=2
            for _ in range(2000):
                mid=(lo+hi)/2
                if logcdf(a,b,mp.exp(mid),lb)<lq:lo=mid
                else:hi=mid
                if hi-lo<mp.mpf(logtol):break
            else:raise ArithmeticError("log bracket did not converge")
            y=mp.exp((lo+hi)/2)
        return +(1-y if flip else y)

def exact_cdf(x,a,b):
    x=x if isinstance(x,Fraction) else Fraction.from_float(float(x));n=a+b-1
    return sum((comb(n,j)*x**j*(1-x)**(n-j) for j in range(a,n+1)),Fraction())

def rounded(q,a,b,x,dps):
    with mp.workdps(dps):
        if x<=0 or x>=mp.mpf(float.fromhex("0x1.0p-1022")):return float(x),"ordinary_conversion"
        ticks=mp.ldexp(x,1074);k=int(mp.floor(ticks));frac=ticks-k
        near=abs(frac-mp.mpf('.5'))<mp.mpf('1e-24')*max(1,abs(ticks))
        if near and a.is_integer() and b.is_integer() and a+b<=64:
            midpoint=Fraction(2*k+1,2**1075);cdf=exact_cdf(midpoint,int(a),int(b));target=Fraction.from_float(q)
            up=cdf<target or (cdf==target and k%2==1)
            return math.ldexp(float(k+int(up)),-1074),"exact_integer_cdf_midpoint"
        if near:
            x500=inverse(q,a,b,500,"1e-380")
            with mp.workdps(500):
                ticks=mp.ldexp(x500,1074);k=int(mp.floor(ticks));frac=ticks-k
                if abs(frac-mp.mpf('.5'))<mp.mpf('1e-350')*max(1,abs(ticks)):raise ArithmeticError("subnormal midpoint remains unresolved")
                up=frac>mp.mpf('.5')
                return math.ldexp(float(k+int(up)),-1074),"adaptive_500_digit_lattice"
        up=frac>mp.mpf('.5') or (frac==mp.mpf('.5') and k%2==1)
        return math.ldexp(float(k+int(up)),-1074),"subnormal_lattice"

def reference(r):
    start=time.process_time();kind=domain(r)
    if kind in ("invalid","unsupported"):return {"id":r.get("id") if isinstance(r,dict) else None,"kind":kind,"x":None,"reference_verified":True}
    q,a,b=(float(r[k]) for k in ("q","a","b"))
    if kind=="endpoint":return {"id":r["id"],"kind":kind,"x":q,"reference_verified":True}
    try:
        x80=inverse(q,a,b,80);x120=inverse(q,a,b,120);f80,round80=rounded(q,a,b,x80,80);f120,round120=rounded(q,a,b,x120,120)
        agrees=(f80==f120 or abs(f80-f120)<=math.ulp(f120))
        check=None
        if a.is_integer() and b.is_integer() and a+b<=64 and 0<f120<1:
            tol=max(2*math.ulp(f120),1e-11*min(f120,1-f120));low=max(0.,f120-tol);high=min(1.,f120+tol)
            check=exact_cdf(low,int(a),int(b))<=Fraction.from_float(q)<=exact_cdf(high,int(a),int(b))
            agrees=agrees and check
        return {"id":r["id"],"kind":"underflow" if f120==0 else "numeric","x":f120,"x_hex":f120.hex(),"mp_x":mp.nstr(x120,65),"reference_verified":agrees,"precision_runs":[80,120],"rounding_methods":[round80,round120],"rounded_float_agreement":f80==f120,"integer_cdf_enclosure":check,"reference_cpu_seconds":time.process_time()-start}
    except Exception as ex:return {"id":r["id"],"kind":"unresolved_reference","x":None,"reference_verified":False,"error":type(ex).__name__+": "+str(ex),"reference_cpu_seconds":time.process_time()-start}

if __name__=="__main__":
    cases=json.loads(Path(sys.argv[1]).read_text());out=[reference(r) for r in cases];Path(sys.argv[2]).write_text(json.dumps(out,indent=2,allow_nan=False)+"\n");print(json.dumps({"cases":len(out),"verified":sum(r["reference_verified"] for r in out)}))
