# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
from datetime import datetime,timezone
import random,secrets,json,hashlib,math
ROOT=Path(__file__).resolve().parent
if not (ROOT/"source_freeze.json").exists():raise SystemExit("All arm sources must be frozen first")
if (ROOT/"fresh_cases.json").exists():raise SystemExit("Refusing to overwrite fresh evidence")
seed=secrets.randbits(64);rng=random.Random(seed);rows=[];groups={}
def add(group,q,a,b):
    i="fresh-"+str(len(rows)).zfill(3);rows.append({"id":i,"q":q,"a":a,"b":b});groups[i]=group
def shapes():
    a=10**rng.uniform(math.log10(.25),2);b=10**rng.uniform(math.log10(.25),6)
    return (b,a) if rng.random()<.5 else (a,b)
for i in range(24):
    a,b=shapes();q=10**(-rng.uniform(2,320)) if i<16 else 1-10**(-rng.uniform(1,15.95));add("tail",q,a,b)
for i in range(12):
    a,b=shapes();add("central",rng.uniform(.015,.985),a,b)
for i in range(8):
    s=10**rng.uniform(math.log10(.25),5);q=10**(-rng.uniform(2,310)) if i<4 else rng.uniform(.02,.98)
    a,b=(1.,s) if i%2 else (s,1.);add("analytic",q,a,b)
for q,a,b in [(0.12345,2.,3.),(.76543,7.,5.),(2.3e-8,3.,11.),(.4321,14.,2.)]:add("analytic_integer",q,a,b)
for q,a,b in [(0.,.25,1e6),(1.,100.,.25),(math.ulp(0.),.25,2.),(1e-300,.5,3.),(1e-150,.5,3.),(1e-160,.5,3.),(1e-161,.5,3.),(math.nextafter(1.,0.),1e6,.25)]:add("endpoint_or_underflow",q,a,b)
for q,a,b in [(-.01,2.,3.),(1.01,2.,3.),(.2,0.,3.),(.2,2.,-1.),(.2,True,3.),("0.1",2.,3.),(.2,1e7,2.),(.2,200.,200.)]:add("invalid_or_unsupported",q,a,b)
assert len(rows)==64 and len({r["id"] for r in rows})==64
(ROOT/"fresh_cases.json").write_text(json.dumps(rows,indent=2,allow_nan=False)+"\n")
meta={"generated_at_utc":datetime.now(timezone.utc).isoformat(),"seed":seed,"generator_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),"casebank_sha256":hashlib.sha256((ROOT/"fresh_cases.json").read_bytes()).hexdigest(),"cases":64,"groups":groups,"interpretation":"Authored fresh stress inputs for one real mission; not independent customers or a population sample."}
(ROOT/"fresh_case_metadata.json").write_text(json.dumps(meta,indent=2)+"\n");print(json.dumps({k:v for k,v in meta.items() if k!="groups"}))
