# SPDX-License-Identifier: Apache-2.0
"""Rebuild the small conventional Boost wrapper against the shared pinned headers."""
from pathlib import Path
import json, os, subprocess, time
from datetime import datetime, timezone
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
VENDOR=Path(os.environ.get('BETA_VENDOR_ROOT', str(ROOT/'vendor')))
def build():
 command=['g++','-std=c++17','-O2','-fPIC','-shared','-DBOOST_MATH_STANDALONE',
          '-I'+str(VENDOR/'boost_math'/'include'),str(HERE/'kernel.cpp'),'-o',str(HERE/'kernel.so')]
 start=time.perf_counter()
 result=subprocess.run(command,capture_output=True,text=True)
 evidence={'utc':datetime.now(timezone.utc).isoformat(),'command':command,
           'returncode':result.returncode,'wall_seconds':time.perf_counter()-start,
           'stdout':result.stdout,'stderr':result.stderr,
           'compiler':subprocess.check_output(['g++','--version'],text=True)}
 (HERE/'build_results.json').write_text(json.dumps(evidence,indent=2))
 if result.returncode: raise RuntimeError(result.stderr)
 return evidence
if __name__=='__main__': print(json.dumps(build(),indent=2))
