// SPDX-License-Identifier: Apache-2.0
#include <boost/math/special_functions/beta.hpp>
#include <boost/math/policies/policy.hpp>
#include <cmath>
#include <cstdio>
#include <exception>
using namespace boost::math::policies;
using Safe = policy<promote_float<false>, promote_double<false>,
 domain_error<throw_on_error>, pole_error<throw_on_error>,
 overflow_error<throw_on_error>, evaluation_error<throw_on_error>,
 max_root_iterations<400>>;
extern "C" int beta_seed(double q, double a, double b, double* x, double* y,
                         char* error, unsigned length) {
 try {
  *x = boost::math::ibeta_inv(a,b,q,y,Safe());
  if (!std::isfinite(*x) || !std::isfinite(*y)) return 2;
  return 0;
 } catch (const std::exception& e) {
  if (length) std::snprintf(error,length,"%s",e.what());
  return 1;
 } catch (...) {
  if (length) std::snprintf(error,length,"unknown Boost exception");
  return 3;
 }
}
