# SPDX-License-Identifier: Apache-2.0
"""Independent public/adverse development validation (not confirmation)."""
import json,math,sys,time,signal,random,subprocess
from pathlib import Path
from datetime import datetime,timezone
import solution
HERE=Path(__file__).resolve().parent

def timed_out(signum,frame): raise TimeoutError('independent reference exceeded 8 wall seconds')
signal.signal(signal.SIGALRM,timed_out)

def reference(q,a,b,dps,seed):
    c=solution.mpmath.mp.clone();c.dps=dps
    Q,A,B=map(c.mpf,(q,a,b))
    if Q==0:return c.zero
    if Q==1:return c.one
    if A==1:return -c.expm1(c.log1p(-Q)/B)
    if B==1:return c.exp(c.log(Q)/A)
    reflect=Q>c.mpf('.5')
    P=1-Q if reflect else Q
    if reflect:A,B=B,A
    lb=c.loggamma(A)+c.loggamma(B)-c.loggamma(A+B); lp=c.log(P)
    z=1-c.mpf(seed) if reflect else c.mpf(seed)
    if 0<z<1:s=c.log(z)-c.log1p(-z)
    else:
        t=(lp+c.log(A)+lb)/A
        s=t-c.log(-c.expm1(t)) if t<c.mpf('-.01') else c.log(A/B)
    def eval_at(t):
        if t<=0:
            e=c.exp(t);x=e/(1+e);y=1/(1+e)
        else:
            e=c.exp(-t);x=1/(1+e);y=e/(1+e)
        # Hypergeometric incomplete beta, independent of delivery's Lentz CF.
        if x<(A+1)/(A+B+2):cdf=c.betainc(A,B,0,x,regularized=True)
        else:cdf=1-c.betainc(B,A,0,y,regularized=True)
        v=c.log(cdf)-lp
        d=c.exp(A*c.log(x)+B*c.log(y)-lb)/cdf
        return v,d,x,y
    radius=c.mpf('1e-6');lo=s-radius;hi=s+radius
    for k in range(30):
        fl=eval_at(lo)[0];fh=eval_at(hi)[0]
        if fl<=0<=fh:break
        radius*=2;lo=s-radius;hi=s+radius
    else:raise ArithmeticError('reference failed to bracket')
    tol=c.power(10,-dps+20)
    for k in range(40):
        f,d,x,y=eval_at(s);step=f/d
        if abs(step)<tol:return y if reflect else x
        if f<0:lo=s
        else:hi=s
        sn=s-step
        s=sn if lo<sn<hi else (lo+hi)/2
    raise ArithmeticError('reference root did not converge')

def accepted(out,r):
    if r==0:return out['status']=='underflow' and out['x']==0
    if r==1:return out['status']=='ok' and out['x']==1
    return out['status']=='ok' and abs(out['x']-r)<=max(2*math.ulp(r),1e-11*min(r,1-r))

public=[(1e-9,.5,2),(1e-16,.5,3),(1e-120,2,10),(1e-300,2,1e6),(1e-200,5,2)]
adverse=[(5e-324,.25,1e6),(1e-300,.5,3),(1e-150,.5,3),(5e-324,100,1e6),(1e-300,1e6,.25),(.5,1e6,.25),(.99,.25,1e6),(math.nextafter(1,0),.25,.25),(5e-324,.25,.25),(5e-324,100,100),(1e-300,100,1e6),(1e-20,1e6,100),(.5,100,100),(.01,.25,.25),(.99,100,100)]
for a,b in [(1,1e6),(1e6,1),(1,.25),(.25,1)]:
    for q in [5e-324,1e-300,.5,math.nextafter(1,0)]:adverse.append((q,a,b))
rng=random.Random(271027)
for i in range(12):
    a=10**rng.uniform(math.log10(.25),2);b=10**rng.uniform(math.log10(.25),2)
    q=10**rng.uniform(-300,-1) if i%2==0 else rng.uniform(.001,.999)
    adverse.append((q,a,b))
results=[]
for index,(q,a,b) in enumerate(public+adverse):
    request={'id':'public'+str(index+1) if index<5 else 'adverse'+str(index-4),'q':q,'a':a,'b':b}
    t=time.process_time();out=solution.solve(request);duration=time.process_time()-t
    row={'request':request,'output':out,'solve_cpu_seconds':duration}
    try:
        if out['status'] not in ('ok','underflow'):raise ArithmeticError('delivery failed: '+str(out))
        signal.setitimer(signal.ITIMER_REAL,8)
        r80=reference(q,a,b,80,out['x']);r120=reference(q,a,b,120,out['x'])
        signal.setitimer(signal.ITIMER_REAL,0)
        f80=float(r80);f120=float(r120)
        row.update(reference80=str(r80),reference120=str(r120),reference_converged=f80==f120,reference_binary64=f120)
        row['accepted']=f80==f120 and accepted(out,f120)
        row['absolute_error']=abs(out['x']-f120)
        if f120 not in (0,1):row['relative_to_nearest_tail']=abs(out['x']-f120)/min(f120,1-f120)
    except Exception as e:
        signal.setitimer(signal.ITIMER_REAL,0)
        row.update(accepted=False,unresolved=True,reference_error=type(e).__name__+': '+str(e))
    results.append(row)
    print(request['id'],row.get('accepted'),row.get('reference_error',''),flush=True)
    (HERE/'attempts/development_in_progress.json').write_text(json.dumps(results,indent=2)+'\n')

validation=[({'id':'endpoint0','q':0,'a':.25,'b':1e6},'endpoint',0.0),({'id':'endpoint1','q':1,'a':1e6,'b':.25},'endpoint',1.0)]
for index,bad in enumerate([{'q':True,'a':1,'b':1},{'q':'.5','a':1,'b':1},{'q':float('nan'),'a':1,'b':1},{'q':.5,'a':float('inf'),'b':1},{'q':-1,'a':1,'b':1},{'q':1.01,'a':1,'b':1},{'q':.5,'a':0,'b':1},{'q':.5,'a':-1,'b':1},{'q':.5,'b':1},[],None]):
    if isinstance(bad,dict):bad['id']='invalid'+str(index)
    validation.append((bad,'invalid',None))
for index,(a,b) in enumerate([(.1,1),(101,101),(1e6+1,.25),(.25,1e6+1)]):validation.append(({'id':'unsupported'+str(index),'q':.5,'a':a,'b':b},'unsupported',None))
validation_results=[]
for request,status,x in validation:
    out=solution.solve(request)
    # JSON-safe representation retains explicit malformed input semantics.
    validation_results.append({'request_repr':repr(request),'expected_status':status,'output':out,'accepted':out['status']==status and out['x']==x})
cli_input=json.dumps([{'id':'cli1','q':1e-9,'a':.5,'b':2},{'id':'cli2','q':0,'a':1,'b':1}])
cli=subprocess.run([sys.executable,str(HERE/'run.py')],input=cli_input,text=True,capture_output=True)
(HERE/'attempts/cli.stdout.txt').write_text(cli.stdout);(HERE/'attempts/cli.stderr.txt').write_text(cli.stderr)
cli_out=json.loads(cli.stdout) if cli.returncode==0 else None
summary={'utc':datetime.now(timezone.utc).isoformat(),'scope':'Public and authored development checks only, not held-out confirmation','numeric_cases':len(results),'numeric_accepted':sum(r['accepted'] for r in results),'numeric_unresolved':sum(r.get('unresolved',False) for r in results),'numeric_failed':sum(not r['accepted'] and not r.get('unresolved',False) for r in results),'validation_cases':len(validation_results),'validation_accepted':sum(r['accepted'] for r in validation_results),'cli_accepted':cli.returncode==0 and cli_out[0]['status']=='ok' and cli_out[1]['status']=='endpoint','max_solve_cpu_seconds':max(r['solve_cpu_seconds'] for r in results),'numeric_results':results,'validation_results':validation_results,'cli':{'command':[sys.executable,str(HERE/'run.py')],'input':cli_input,'returncode':cli.returncode,'outputs':cli_out},'smoke_results':'attempts/initial_smoke.json','oracle':'Independent mpmath hypergeometric betainc with bracketed Newton at80/120decimal digits; analytic inverses for a=1 or b=1; exact received binary64 inputs'}
(HERE/'development_results.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ['numeric_results','validation_results','cli']},indent=2),flush=True)
