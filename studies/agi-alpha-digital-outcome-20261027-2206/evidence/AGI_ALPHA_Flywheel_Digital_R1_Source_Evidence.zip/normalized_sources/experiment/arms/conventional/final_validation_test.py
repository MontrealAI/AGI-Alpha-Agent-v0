# SPDX-License-Identifier: Apache-2.0
import json,sys,subprocess,time,resource
from pathlib import Path
from datetime import datetime,timezone
sys.dont_write_bytecode=True
from solution import solve
HERE=Path(__file__).resolve().parent
resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3))
resource.setrlimit(resource.RLIMIT_CPU,(120,120))
original=json.loads((HERE/'development_results.json').read_text())
start=time.process_time();replay=[]
for row in original['numeric_results']:
 out=solve(row['request']);reference=row['reference_binary64']
 replay.append({'id':row['request']['id'],'passed':out['x']==reference and out['status']==('underflow' if reference==0 else 'ok'),'output':out})
cli_cases=[]
for name,text,from_file in [('object','{"id":"object","q":0.5,"a":1,"b":1}',False),('file','[{"id":"file","q":1,"a":1,"b":1}]',True),('malformed','{',False)]:
 cmd=[sys.executable,str(HERE/'run.py')]
 if from_file:
  path=HERE/'attempts/cli_input.json';path.write_text(text);cmd.append(str(path))
 completed=subprocess.run(cmd,input=None if from_file else text,capture_output=True,text=True)
 output=json.loads(completed.stdout) if completed.returncode==0 else None
 expected={'object':{'id':'object','status':'ok','x':.5},'file':[{'id':'file','status':'endpoint','x':1.0}],'malformed':{'id':None,'status':'invalid','x':None}}[name]
 actual=output if name!='object' or output is None else {k:output[k] for k in ('id','status','x')}
 cli_cases.append({'name':name,'command':cmd,'input':text,'output':output,'stderr':completed.stderr,'returncode':completed.returncode,'passed':actual==expected})
record={'utc':datetime.now(timezone.utc).isoformat(),'numerical_replay_count':len(replay),'numerical_replay_passed':sum(r['passed'] for r in replay),'cpu_seconds':time.process_time()-start,'numeric_replay':replay,'cli_cases':cli_cases,'all_passed':all(r['passed'] for r in replay+cli_cases)}
(HERE/'final_validation.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k!='numeric_replay'},indent=2))
assert record['all_passed']
