# SPDX-License-Identifier: Apache-2.0
import sys
sys.dont_write_bytecode=True
import math,json,time,random,resource,subprocess
from pathlib import Path
from datetime import datetime,timezone
HERE=Path(__file__).resolve().parent
resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3));resource.setrlimit(resource.RLIMIT_CPU,(120,120))
import solution
mpmath=solution.mpmath
rng=random.Random(0xE20261027)
rows=[]
for i in range(512):
 a=math.exp(rng.uniform(math.log(.25),math.log(100)))
 b=math.exp(rng.uniform(math.log(.25),math.log(1e6)))
 if i%2: a,b=b,a
 if i%8==0: q=rng.uniform(.01,.99)
 elif i%8==1: q=math.nextafter(1,0)
 elif i%8==2: q=math.nextafter(0,1)
 else: q=10**rng.uniform(-323,-.31)
 request={'id':'grid_'+str(i),'q':q,'a':a,'b':b}
 t=time.process_time();output=solution.solve(request);cpu=time.process_time()-t
 row={'request':request,'output':output,'solve_cpu_seconds':cpu}
 try:
  r80=solution._refine(q,a,b,output['x'],time.process_time()+4.5)
  previous=solution._MP;solution._MP=mpmath.mp.clone();solution._MP.dps=120
  try: r120=solution._refine(q,a,b,output['x'],time.process_time()+4.5)
  finally: solution._MP=previous
  tolerance=max(2*math.ulp(r120),1e-11*min(r120,1-r120)) if r120 not in (0,1) else 0
  expected='underflow' if r120==0 else 'ok'
  row.update(cf80=r80,cf120=r120,precision_converged=r80==r120,agrees=r80==r120 and output['status']==expected and abs(output['x']-r120)<=tolerance and cpu<=5,
   reference_relationship='independent CDF structure from Boost' if output.get('method')=='boost_double_safe400' else 'same fallback path; consistency only')
 except Exception as exc:row.update(agrees=None,reference_error=repr(exc))
 rows.append(row)
 if i%64==63:
  print('STRESS',i+1,'disagreements',sum(r.get('agrees') is False for r in rows),'unresolved',sum(r.get('agrees') is None for r in rows),flush=True)
  (HERE/'stress_results.json').write_text(json.dumps({'rows':rows},indent=2)+'\n')


def quadrature_reference(q,a,b,dps,seed):
 mp=mpmath.mp.clone();mp.dps=dps
 q,a,b=map(mp.mpf,(q,a,b));target=mp.log(q)
 lognorm=mp.log(a)+mp.log(mp.beta(a,b))
 def value(z):
  f=lambda u:mp.exp(-u)*(-mp.expm1(-(z+u)/a))**(b-1)
  integral=mp.quad(f,[0,1,4,16,64,mp.inf])
  return -z-lognorm+mp.log(integral)
 z=-a*mp.log(mp.mpf(seed));lo=max(mp.mpf('1e-50'),z-1);hi=z+1
 while value(lo)<target:lo/=2
 while value(hi)>target:hi*=2
 for n in range(15):
  v=value(z);residual=v-target
  if abs(residual)<mp.mpf('1e-60'):return float(mp.exp(-z/a))
  if residual>0:lo=z
  else:hi=z
  t=-z/a;logy=mp.log(-mp.expm1(t))
  derivative=-mp.exp(a*t+(b-1)*logy-lognorm-v)
  trial=z-residual/derivative
  z=trial if lo<trial<hi else (lo+hi)/2
 raise RuntimeError('quadrature root did not converge')
quadrature=[]
for q in [math.nextafter(0,1),1e-320]:
 request={'id':'quad_tail','q':q,'a':1e6,'b':.25};out=solution.solve(request)
 t=time.process_time()
 try:
  r80=quadrature_reference(q,1e6,.25,80,out['x']);r120=quadrature_reference(q,1e6,.25,120,out['x'])
  tol=max(2*math.ulp(r120),1e-11*min(r120,1-r120))
  row={'request':request,'output':out,'reference80':r80,'reference120':r120,'accepted':r80==r120 and abs(out['x']-r120)<=tol,'reference_cpu_seconds':time.process_time()-t,'method':'independent transformed positive quadrature plus bracketed Newton'}
 except Exception as exc:row={'request':request,'output':out,'accepted':None,'reference_error':repr(exc)}
 quadrature.append(row);print('QUADRATURE',row,flush=True)
cli=[]
for label,input_text,args in [('object',json.dumps({'id':'one','q':.5,'a':1,'b':1}),[]),('list',json.dumps([{'id':'a','q':0,'a':1,'b':1},{'id':'b','q':.25,'a':1,'b':1}]),[]),('malformed','{',[])]:
 r=subprocess.run([sys.executable,'-B',str(HERE/'run.py'),*args],input=input_text,text=True,capture_output=True)
 cli.append({'mode':label,'command':[sys.executable,'-B',str(HERE/'run.py'),*args],'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'valid_json':isinstance(json.loads(r.stdout),(dict,list))})
f=HERE/'cli_input.json';f.write_text(json.dumps({'id':'file','q':.25,'a':1,'b':1}))
r=subprocess.run([sys.executable,'-B',str(HERE/'run.py'),str(f)],text=True,capture_output=True)
cli.append({'mode':'path','command':[sys.executable,'-B',str(HERE/'run.py'),str(f)],'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'accepted':json.loads(r.stdout)=={'id':'file','status':'ok','x':.25,'method':'analytic80'}})
result={'utc':datetime.now(timezone.utc).isoformat(),'seed':'0xE20261027','cases':len(rows),'agreements':sum(r.get('agrees') is True for r in rows),'disagreements':sum(r.get('agrees') is False for r in rows),'unresolved':sum(r.get('agrees') is None for r in rows),'max_solve_cpu_seconds':max(r['solve_cpu_seconds'] for r in rows),'aggregate_solve_cpu_seconds':sum(r['solve_cpu_seconds'] for r in rows),'peak_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'total_test_cpu_seconds':time.process_time(),'rows':rows,'quadrature_controls':quadrature,'cli_checks':cli,'warning':'Shared fallback references are consistency checks, not independent verification. No fresh confirmation cases were read.'}
(HERE/'stress_results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('rows','quadrature_controls','cli_checks')},indent=2))
