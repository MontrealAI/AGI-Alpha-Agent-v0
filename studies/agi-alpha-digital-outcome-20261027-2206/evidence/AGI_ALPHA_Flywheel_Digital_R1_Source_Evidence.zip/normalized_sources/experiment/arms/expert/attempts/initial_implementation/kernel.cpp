// SPDX-License-Identifier: Apache-2.0
#include <boost/math/special_functions/beta.hpp>
#include <boost/math/policies/policy.hpp>
#include <cmath>
#include <cstdio>
#include <exception>
using namespace boost::math::policies;
using safe_policy = policy<promote_float<false>, promote_double<false>, max_root_iterations<400>, domain_error<throw_on_error>, pole_error<throw_on_error>, overflow_error<throw_on_error>, evaluation_error<throw_on_error>>;
extern "C" int beta_inverse(double q, double a, double b, double* x, double* y, double* tail, char* error, int n) {
 try {
  *x = boost::math::ibeta_inv(a,b,q,y,safe_policy());
  if (!std::isfinite(*x) || *x<0 || *x>1) return 2;
  // Forward value is only a recovery diagnostic, not an independent oracle.
  *tail = q<=0.5 ? boost::math::ibeta(a,b,*x,safe_policy()) : boost::math::ibeta(b,a,*y,safe_policy());
  return 0;
 } catch(const std::exception& e) { if(n>0) std::snprintf(error,n,"%s",e.what()); return 1; }
 catch(...) { if(n>0) std::snprintf(error,n,"unknown C++ exception"); return 3; }
}
