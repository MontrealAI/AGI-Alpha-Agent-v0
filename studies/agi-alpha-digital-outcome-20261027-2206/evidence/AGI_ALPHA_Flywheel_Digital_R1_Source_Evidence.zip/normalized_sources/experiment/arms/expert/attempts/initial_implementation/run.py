# SPDX-License-Identifier: Apache-2.0
"""One JSON object or array from standard input or an optional input path."""
import sys, json
sys.dont_write_bytecode=True
from solution import solve

def main():
 try:
  if len(sys.argv)>2: raise ValueError('usage: run.py [input.json]')
  if len(sys.argv)==2:
   with open(sys.argv[1],encoding='utf-8') as stream: value=json.load(stream)
  else: value=json.load(sys.stdin)
  outputs=[solve(item) for item in value] if isinstance(value,list) else solve(value)
  print(json.dumps(outputs,allow_nan=False))
 except (ValueError,OSError) as exc:
  print(json.dumps({'id':None,'status':'invalid','x':None,'error':str(exc)}))
if __name__=='__main__': main()
