# SPDX-License-Identifier: Apache-2.0
"""Bounded scalar beta inverse with current Boost and conventional precision recovery."""
import ctypes, math, sys, time
from pathlib import Path
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
sys.path.insert(0,str(ROOT/'vendor/mpmath130'))
import mpmath
_MP=mpmath.mp.clone(); _MP.dps=80
try:
 _LIB=ctypes.CDLL(str(HERE/'kernel.so'))
 _FUN=_LIB.beta_inverse
 _FUN.argtypes=[ctypes.c_double]*3+[ctypes.POINTER(ctypes.c_double)]*3+[ctypes.c_char_p,ctypes.c_int]
 _FUN.restype=ctypes.c_int
 _LOAD_ERROR=None
except Exception as exc:
 _FUN=None; _LOAD_ERROR=str(exc)


def _cf(a,b,x,mp,deadline):
 """Classical incomplete-beta continued fraction, modified Lentz evaluation."""
 tiny=mp.mpf('1e-200'); eps=mp.mpf('1e-64')
 qab=a+b; qap=a+1; qam=a-1
 c=mp.mpf(1); d=1-qab*x/qap
 if abs(d)<tiny: d=tiny
 d=1/d; h=d
 for m in range(1,2001):
  if m%32==0 and time.process_time()>deadline: raise RuntimeError('fallback CPU budget exceeded')
  m2=2*m; aa=m*(b-m)*x/((qam+m2)*(a+m2))
  d=1+aa*d; c=1+aa/c
  if abs(d)<tiny: d=tiny
  if abs(c)<tiny: c=tiny
  d=1/d; h*=d*c
  aa=-(a+m)*(qab+m)*x/((a+m2)*(qap+m2))
  d=1+aa*d; c=1+aa/c
  if abs(d)<tiny: d=tiny
  if abs(c)<tiny: c=tiny
  d=1/d; delta=d*c; h*=delta
  if abs(delta-1)<eps: return h
 raise RuntimeError('continued fraction did not converge')


def _refine(q,a,b,seed,deadline):
 """Safeguarded Newton in logit coordinates using an independent CDF structure."""
 mp=_MP; q=mp.mpf(q); a=mp.mpf(a); b=mp.mpf(b)
 flip=q>mp.mpf('.5')
 if flip: q=1-q; a,b=b,a; seed=None if seed is None else 1-seed
 logq=mp.log(q); lb=mp.loggamma(a)+mp.loggamma(b)-mp.loggamma(a+b)
 estimate=(logq+mp.log(a)+lb)/a
 # Here the discarded correction is <1e-250 in the declared shape domain.
 if estimate < -600:
  x=mp.exp(estimate)
  return float(1-x if flip else x)
 lo=mp.mpf(-4000); hi=mp.mpf(40)
 if seed is not None and 0<seed<1: t=mp.log(mp.mpf(seed)/(1-mp.mpf(seed)))
 elif estimate < -1: t=estimate-mp.log1p(-mp.exp(estimate))
 else: t=mp.log(a/b)
 t=max(lo,min(hi,t))
 for iteration in range(100):
  if time.process_time()>deadline: raise RuntimeError('fallback CPU budget exceeded')
  if t<=0:
   x=1/(1+mp.exp(-t)); y=1-x
  else:
   y=1/(1+mp.exp(t)); x=1-y
  logx=mp.log(x); logy=mp.log(y)
  front=a*logx+b*logy-lb
  if x<(a+1)/(a+b+2): lf=front+mp.log(_cf(a,b,x,mp,deadline)/a)
  else:
   lu=front+mp.log(_cf(b,a,y,mp,deadline)/b)
   lf=mp.log1p(-mp.exp(lu))
  residual=lf-logq
  if abs(residual)<mp.mpf('1e-55'): return float(y if flip else x)
  if residual<0: lo=t
  else: hi=t
  derivative=mp.exp(front-lf)
  trial=t-residual/derivative
  if not lo<trial<hi: trial=(lo+hi)/2
  if abs(trial-t)<mp.mpf('1e-55'): return float(y if flip else x)
  t=trial
 raise RuntimeError('bracketed refinement exhausted iterations')


def solve(request):
 started=time.process_time()
 ident=request.get('id') if isinstance(request,dict) else None
 result={'id':ident,'status':'invalid','x':None}
 if not isinstance(request,dict): return result
 try:
  values=[request[k] for k in ('q','a','b')]
  if any(type(v) not in (int,float) for v in values): return result
  q,a,b=map(float,values)
  if not all(math.isfinite(v) for v in (q,a,b)): return result
 except (KeyError,TypeError,ValueError,OverflowError): return result
 if q<0 or q>1 or a<=0 or b<=0: return result
 if not (.25<=a<=1e6 and .25<=b<=1e6 and min(a,b)<=100):
  result['status']='unsupported'; return result
 if q==0 or q==1:
  result.update(status='endpoint',x=q); return result
 try:
  mp=_MP
  if a==1 or b==1:
   if a==1 and b==1: x=q
   elif a==1: x=float(-mp.expm1(mp.log1p(-mp.mpf(q))/mp.mpf(b)))
   else: x=float(mp.exp(mp.log(mp.mpf(q))/mp.mpf(a)))
   method='analytic80'
  else:
   # Approximation is used only to choose the tiny-tail path, never as final double precision output.
   estimate=(math.log(q)+math.log(a)+math.lgamma(a)+math.lgamma(b)-math.lgamma(a+b))/a
   if estimate < -600:
    x=_refine(q,a,b,None,started+4.5); method='tiny_tail80'
   elif _FUN is None:
    x=_refine(q,a,b,None,started+4.5); method='precision_fallback80'
   else:
    cx=ctypes.c_double(); cy=ctypes.c_double(); cf=ctypes.c_double(); error=ctypes.create_string_buffer(768)
    status=_FUN(q,a,b,ctypes.byref(cx),ctypes.byref(cy),ctypes.byref(cf),error,768)
    x=cx.value; target=min(q,1-q)
    suspicious=status!=0 or not math.isfinite(x) or not 0<x<=1
    # Residual controls are diagnostic; a small residual is not claimed as independent validation.
    if not suspicious and 0<x<1 and cf.value>0:
     relative=abs(cf.value-target)/target
     if relative>1e-8 and q<=.5 and x<.9: suspicious=True
    if suspicious:
     seed=x if status==0 and 0<x<1 else None
     x=_refine(q,a,b,seed,started+4.5); method='precision_fallback80'
     result['recovery_reason']=error.value.decode(errors='replace') if status else 'zero or suspicious residual'
    else: method='boost_double_safe400'
  if not math.isfinite(x) or not 0<=x<=1: raise ArithmeticError('nonfinite or out-of-domain result')
  result.update(status='underflow' if x==0 else 'ok',x=x,method=method)
 except Exception as exc:
  result.update(status='failed',x=None,error=str(exc))
 return result
