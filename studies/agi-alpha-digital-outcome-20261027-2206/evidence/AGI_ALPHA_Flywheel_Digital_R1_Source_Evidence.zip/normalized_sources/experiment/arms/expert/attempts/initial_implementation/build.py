# SPDX-License-Identifier: Apache-2.0
"""Reproducible build using pinned shared Boost headers; no global installation."""
from pathlib import Path
from datetime import datetime, timezone
import os, subprocess, json, time
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
cmd=['g++','-std=c++17','-O2','-shared','-fPIC','-DBOOST_MATH_STANDALONE','-I'+str(ROOT/'vendor/boost_math/include'),str(HERE/'kernel.cpp'),'-o',str(HERE/'kernel.so')]
env=os.environ.copy(); env['TMPDIR']=str(HERE)
t=time.perf_counter(); started=datetime.now(timezone.utc).isoformat()
r=subprocess.run(cmd,capture_output=True,text=True,env=env)
(HERE/'build.stdout.txt').write_text(r.stdout); (HERE/'build.stderr.txt').write_text(r.stderr)
(HERE/'build_record.json').write_text(json.dumps({'command':cmd,'started_utc':started,'ended_utc':datetime.now(timezone.utc).isoformat(),'wall_seconds':time.perf_counter()-t,'returncode':r.returncode,'compiler':subprocess.run(['g++','--version'],capture_output=True,text=True).stdout},indent=2)+'\n')
raise SystemExit(r.returncode)
