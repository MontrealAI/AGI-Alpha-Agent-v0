// SPDX-License-Identifier: Apache-2.0
#include <boost/math/special_functions/beta.hpp>
#include <boost/math/policies/policy.hpp>
#include <iostream>
#include <iomanip>
#include <limits>
#include <chrono>
#include <stdexcept>
#include <cmath>
#include <string>

using namespace boost::math::policies;
using Safe = policy<promote_float<false>,promote_double<false>,
  domain_error<throw_on_error>,pole_error<throw_on_error>,
  overflow_error<throw_on_error>,evaluation_error<throw_on_error>,
  max_root_iterations<400>>;
using More = policy<promote_float<false>,promote_double<false>,
  domain_error<throw_on_error>,pole_error<throw_on_error>,
  overflow_error<throw_on_error>,evaluation_error<throw_on_error>,
  max_root_iterations<2000>>;
struct Case { const char *id,*q,*a,*b; };
template<class T, class P>
void run(const Case &c,const char *kind,const char *policy_name,P pol) {
  T a=static_cast<T>(std::stold(c.a)),b=static_cast<T>(std::stold(c.b)),q=static_cast<T>(std::stold(c.q));
  auto t0=std::chrono::steady_clock::now();
  std::cout << c.id << '\t' << kind << '\t' << policy_name << '\t';
  try {
    T x=boost::math::ibeta_inv(a,b,q,pol);
    double elapsed=std::chrono::duration<double>(std::chrono::steady_clock::now()-t0).count();
    std::cout << "returned\t" << std::setprecision(std::numeric_limits<T>::max_digits10) << x << '\t' << elapsed << '\t';
    if(std::isfinite(x)) {try {std::cout << boost::math::ibeta(a,b,x,pol);}catch(const std::exception& e) {std::cout << "cdf_error:" << e.what();}}
    else std::cout << "nonfinite";
    std::cout << '\n';
  } catch(const std::exception &e) {
    double elapsed=std::chrono::duration<double>(std::chrono::steady_clock::now()-t0).count();
    std::cout << "error\t\t" << elapsed << '\t' << e.what() << '\n';
  }
}
int main(){
  std::cout << "#double_digits=" << std::numeric_limits<double>::digits << ",long_double_digits=" << std::numeric_limits<long double>::digits << ",long_double_max_exponent=" << std::numeric_limits<long double>::max_exponent << '\n';
  std::cout << "id\ttype\tpolicy\tstatus\tx\tseconds\tcdf_or_error\n";
  Case cases[]={{"issue1","1e-9","0.5","2"},{"issue2","1e-16","0.5","3"},{"issue3","1e-120","2","10"},{"issue4","1e-300","2","1000000"},{"issue5","1e-200","5","2"}};
  for(auto c:cases){run<double>(c,"double","safe400",Safe{});run<long double>(c,"long_double","safe400",Safe{});run<double>(c,"double","safe2000",More{});run<long double>(c,"long_double","safe2000",More{});}
}
