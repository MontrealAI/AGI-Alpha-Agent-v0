# SPDX-License-Identifier: Apache-2.0
"""Recheck five published issue examples; not fresh confirmation."""
from pathlib import Path
import csv
import json
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "vendor" / "mpmath130"))
import mpmath as mp

mp.mp.dps = 80
cases = json.loads((HERE / "protocol.json").read_text())["cases"]
references = {}
for n, values in enumerate(cases, 1):
    q, a, b = map(mp.mpf, values)
    t0 = (mp.log(q) + mp.log(a) + mp.log(mp.beta(a, b))) / a
    def residual(t):
        return mp.log(mp.betainc(a, b, 0, mp.exp(t), regularized=True)) - mp.log(q)
    t = mp.findroot(residual, t0)
    references[f"issue{n}"] = mp.exp(t)
rows = list(csv.DictReader((HERE / "results.tsv").read_text().splitlines()[1:], delimiter="\t"))
groups = {}
for row in rows:
    accepted = False
    if row["status"] == "returned":
        x = mp.mpf(row["x"])
        error = abs(x / references[row["id"]] - 1)
        accepted = bool(mp.isfinite(x) and 0 < x < 1 and error <= mp.mpf("1e-12"))
    key = row["type"] + "/" + row["policy"]
    groups.setdefault(key, {"accepted": 0, "cases": 0})
    groups[key]["accepted"] += int(accepted)
    groups[key]["cases"] += 1
print(json.dumps(groups, indent=2))
