# Current Boost conventional challenge — five published beta-inverse examples

**Decision: the strongest identified current conventional double-precision implementation solves all five public examples. Stop any claim that a new algorithm is required to solve those examples.**

This is an early disqualification test on development examples, not held-out confirmation. It does not establish the correctness of every beta quantile, a complete SciPy integration, customer acceptance, discovery advantage or Operational Alpha.

| Unchanged Boost numerical type | Safe root limit400 | Safe root limit2000 |
| --- | ---: | ---: |
| double, promotion disabled | 5/5 accepted | 5/5 accepted |
| long double,64-bit significand | 4/5 accepted | 4/5 accepted |

Acceptance was frozen before compilation: finite x strictly between0 and1, relative x error at most1e-12 against an80-digit mpmath reference using the public issue's log-coordinate root method. Decimal issue inputs were used for the reference; binary conversion in C++ introduces its normal rounding, well below the declared tolerance. The maximum accepted double error was **2.008e-14**, for q=1e-300,a=2,b=1,000,000. The same-library forward CDF values are retained as diagnostics, not an independent oracle.

The long-double implementation threw an explicit Halley root failure for q=1e-16,a=0.5,b=3 at both iteration limits. This is retained, not hidden by the successful double arm. The conventional practical solution for these five cases uses the double configuration. Default200-iteration policy and default promotion behavior were not tested in this challenge; the report does not claim they passed.

## Provenance and boundaries

- Public report: https://github.com/scipy/scipy/issues/26531 . Its contributor specifically requested testing current Boost master, since recent updates might already fix the issue. The idea and numerical root approach were supplied by this public source; they were not discovered by this sprint.
- Boost.Math source commit: `70a36632cfbfe6a862cd8a5b88b357ca3a770a3d`, exact archive URL and SHA256 in `retrieval_manifest.json`.557 header files were extracted without alteration. Every header hash is retained in `boost_header_manifest.json`.
- Boost Software License1.0 is preserved at `../vendor/boost_math/LICENSE_1_0.txt` from the official Boost license page; copyright/license notices remain in source headers.
- `mpmath==1.3.0` wheel from official PyPI, SHA256 `a0b2b9fe80bbcd81a6647ff13108738cfb482d481d826cc0e02f5b35e5c88d2c`, matched to official PyPI JSON metadata before extraction. Its license and dist-info remain in `../vendor/mpmath130`. No global install.
- Compiler g++13.3.0; Linux x86_64; double53-bit and long double64-bit significands. Standalone Boost was used with no system Boost installation.
- The earlier local SciPy1.17.0 screen reproduces the issue's pattern. This challenge does not rebuild SciPy1.18.1 or claim a submitted upstream patch.

Safe policies disable promotion and throw on domain,pole,overflow and evaluation errors; nonfinite returned values would also fail acceptance. No exception is converted into a last-iterate success. Only root iteration limit differs between the400 and2000 arms; all five examples and all outputs remain in the record.

## Reproduce

From this directory after preserving the sibling `vendor/` directory:

```sh
g++ -std=c++17 -O2 -DBOOST_MATH_STANDALONE -I../vendor/boost_math/include boost_issue_cases.cpp -o boost_issue_cases
./boost_issue_cases > results.tsv
python verify.py
```

Run on a filesystem that permits normal executable files. `build.json` retains the exact original command and compiler version; `compile.stdout.txt`, `compile.stderr.txt`, `run.stderr.txt` and raw `results.tsv` preserve actual outcomes. `protocol.json` records the pre-execution scope and criteria. `verification.json` contains all20 classified results and all five high-precision reference values. Native timing is descriptive only, includes cold-call/printing effects and is not a benchmark or model-efficiency comparison.

All model arms may import the identical verified library by placing `../vendor/mpmath130` first on their explicit task-local Python path. This gives the ordinary conventional comparator the same numerical asset; no retained-Alpha advantage follows from distributing it.
