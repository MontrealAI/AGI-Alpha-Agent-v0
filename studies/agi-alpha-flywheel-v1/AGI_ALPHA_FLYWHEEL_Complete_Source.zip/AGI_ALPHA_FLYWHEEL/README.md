# 🌌♾️ AGI ALPHA FLYWHEEL

## From Completed Work to Compounding Capability

**KEEP THE MEANS. RE-EARN THE PROOF.**

**🌌⚙️ SUCCESSOR Ω HARNESS — ACTIVATE. EVOLVE. SCALE.**  
Powered by **TRANSFORMATIONAL INTELLIGENCE ∞** and the applicable **$AGIALPHA** utility.

This publication package contains the paper, complete LaTeX, original vector figures, a self-contained browser demonstration and the executed research companion. It asks a concrete question: can accepted work leave reusable means that improve later work after construction, validation, failures, retention and intervention are accounted for?

**The bounded recurring loop runs. Retained recipes affect later work. The strong conventional cache ties the flywheel exactly; the prewritten expert workflow qualifies more tasks.** Useful inheritance and an advantage over the best alternative are separate findings. This package preserves both the positive evidence and the losses.

## Start here

| What you want | Open or run |
|---|---|
| Read the publication | [paper/AGI_ALPHA_FLYWHEEL.pdf](paper/AGI_ALPHA_FLYWHEEL.pdf) |
| Try the demonstration immediately | Open [demo/index.html](demo/index.html) in a current browser. No server or account is required. |
| Reproduce the complete primary experiment | Run the two commands below from the extracted package root. |
| Check a claim against its evidence | [EVIDENCE_DOCKET.md](EVIDENCE_DOCKET.md) and [evidence/claim-docket.json](evidence/claim-docket.json) |
| Inspect the exact execution boundary | [companion/EXECUTION_SCOPE.json](companion/EXECUTION_SCOPE.json) |

```sh
node companion/run.mjs reproduce fresh-run
python3 review/independent/review_results.py companion/fresh-run --output fresh-review.json
```

These commands use **Node 24.22.1** and **Python 3.12.14**, as tested on Linux x86_64. The runner has no npm dependencies; the independent checker uses only the Python standard library. Once the package and these runtimes are present, the experiment needs no network, model API, wallet, credentials or package download. It writes a new `companion/fresh-run/` directory and refuses to overwrite existing evidence.

### A clear browser journey

1. Choose **Start the recorded stream** to follow six generations: the first retained recipe, a changed requirement, later reuse and the full charged costs. This is explicitly labeled recorded evidence.
2. Compare all four workflows. Use **Show a rejected candidate**, the archive-cleared comparison and the recovery view to inspect failures and the point where rebuilding is cheaper.
3. Choose **Try a fresh check**, then **Run a fresh bounded stream** to execute the packaged research adapter through the actual released `createWorkbench(adapters)` interface on a separate demonstration seed. Download its results and completed packs.

The smaller **Run a fresh check** action executes the unchanged upstream source-understanding instrument on a public example or a valid imported public, nonpersonal source document. It is a different action from the six-generation fresh stream. Recorded replay, fresh instrument computation and fresh stream execution remain separately labeled.

Fresh browser computation runs **in the open tab**. Closing the tab stops it; this page does not start an unattended service. **Stop at the next checkpoint** requests a bounded stop. A browser without the required WebCrypto facility refuses the source-extension run. The included QA record reports **24 passing real-browser checks**, including local-file execution, downloads, keyboard use and narrow English/French layouts, against the exact demo bytes. This is local-browser evidence, not a verified public deployment. See [demo/README.md](demo/README.md).

## What was measured

The frozen primary contains **eight paired streams**, **six generations per stream**, **four arms** and **36 fresh terminal tasks per stream and arm**. Each generation has two development documents, two qualification documents and six terminal documents. Requirements change in graph structure, weights, clause order and size cap. The study produces **192 generation packs**, **1,152 terminal observations** and **140,388 original logical charge events**.

A qualified summary respects its clause cap, preserves every transitive prerequisite of its selected claims and achieves the **exact maximum supported weight under the supplied annotation graph**. This criterion does not measure factual truth, annotation completeness or reader benefit. The fixed primary budget is **500,000 standardized structural-work units per stream and arm**; all 36 registered terminal tasks remain in each denominator. The eight complete streams are the comparison units. The documents are not treated as independent population samples.

| Workflow | Qualified / 288 | Total structural-work units | Units per qualified output |
|---|---:|---:|---:|
| Flywheel | 271 | 2,017,944 | 7,446.29 |
| Conventional cache | 271 | 2,017,944 | 7,446.29 |
| Fixed lead selector, no acquired recipe | 58 | 1,412,176 | 24,347.86 |
| Prewritten expert router | 288 | 2,134,383 | 7,411.05 |

The conventional cache is an explicit equivalence control: it receives the same finite method grammar, information, storage, retrieval and adaptation rule as the flywheel. Its exact tie is an intended strong comparison, not two independently invented strategies coincidentally matching. The fixed lead selector is a secondary intervention comparator. The expert arm is an authored analytical router, not a measured human-expert labor experiment.

Flywheel coverage by stream is **36, 33, 32, 30, 35, 36, 35, 34**. Its paired difference from the expert is **0, −3, −4, −6, −1, 0, −1, −2** tasks: mean **−2.125**, range **−6 to 0**. The expert also leads at every registered descriptive budget-prefix point. Those prefix curves project the original run's cost prefixes; they are not fresh policy runs at new budgets. Lower aggregate flywheel spending does not establish better quality-adjusted productivity: the expert also has slightly fewer units per qualified output here.

The complete primary took **15.528 seconds wall time**, **11.756 seconds user CPU** and **3.408 seconds system CPU** on the observed host. Recorded storage before summary serialization was **47,020,876 bytes**. These are whole-process observations, not portable performance guarantees. The declared work units are a structural accounting model, not CPU instructions, FLOPs, electricity or money. Source and formula details are in [companion/protocol.json](companion/protocol.json).

### Retention helps, and can become a liability

Across the 48 flywheel generations, there are **16 admission actions**, **31 incumbent retentions** and **one rejected descendant**. The admissions resolve to **four distinct capability-content digests**, not 16 unique tools. Of 288 terminal outputs, **138** use a capability created in an earlier generation, and **134** of those qualify. Another 96 use a newly created capability in the current generation, and 54 have no attached capability. A nonempty digest alone is not proof of inheritance.

The registered stream-zero archive intervention preserves a useful causal distinction:

| Stream-zero condition | Qualified / 36 | Total work units |
|---|---:|---:|
| Retain the archive | 36 | 316,616 |
| Clear the archive before every generation; allow reconstruction and qualification | 30 | 279,432 |

Retention yields **six more qualified outputs at 37,184 additional units**. It saves **40,061 construction units** but adds **77,231 execution units**, plus small routing/maintenance differences. In generation 4, both conditions qualify all six tasks and reuse saves **12,266 units**. In generation 5, both qualify all six, but the retained graph recipe costs **168,563** units while the rebuilt audit recipe costs **128,901**: rebuilding saves **39,662 units** at equal observed quality.

The component-removal test qualifies **8/36** tasks; a newly digested equivalent recipe qualifies **36/36**. On the **18 true later-generation inherited uses** in this stream, these counts are **2/18** and **18/18**. This tests the selected component's effect. The separate archive-cleared intervention tests persistence while allowing reconstruction.

The active archive never exceeds **two recipes** or **789 canonical recipe bytes**. Full evidence is much larger and continues accumulating. **No retirement occurs in the primary run**: the implemented capacity/retirement rule is not evidence of observed primary eviction or bounded indefinite history.

### Preserved negative evidence

- The flywheel does not beat the conventional cache and misses **17** tasks that the expert qualifies.
- A deliberately incomplete annotation yields local structural score **20** and alternate-truth score **0**. This source-aware constructed challenge is not a blinded truth study.
- A self-consistently rehashed false score passes native pack-integrity inspection. The added task-bound semantic recomputation rejects it. Hash integrity alone is not semantic proof.
- Reuse sometimes costs more than rebuilding. No infinite-history retention, production growth, real customer demand or commercial growth is established.
- Original excluded development failures and pre-freeze corrections remain in `companion/development-*`; the primary is not silently substituted with a revised run.

## Interrupt, recover and inspect finite load

To reconcile a previously started output directory:

```sh
node companion/run.mjs resume fresh-run
```

This checks exact source, request and saved-result semantics. A committed result is reused without issuing a new result; verification still reexecutes pure deterministic work. An interrupted uncommitted computation may run again. Resume grants a new finite local research permit only. It grants no production authority.

The recorded whole-study resume reconciles **192 saved epochs and 1,152 rows**, with **zero fresh mission-result invocations**, but **192 verification reexecutions**, **12,938,483 additional verification units** and **7,124.42 ms** summed verification time. Recovery is neither free nor exactly-once CPU execution.

Regenerate ancillary experiments separately into new directories:

```sh
node companion/run.mjs faults fresh-faults
node companion/run.mjs load fresh-load
node companion/run.mjs ablations fresh-ablations
```

All **16 recorded fault assertions pass**. They cover lost acknowledgement, duplicate request, changed input, actual process restart, changed dependency bytes, invalid or self-consistently forged receipts, swapped tasks, forged retained capability, budget exhaustion, expired local permit, STOP, precommit recomputation, WAIT, actual prior-recipe reuse and rejected-descendant restart. The fault suite retains **2,467 units** of interrupted work rather than treating it as free. The prior-recipe test is not a production deployment rollback.

The load study uses **1, 2 and 4 actual Node worker processes**, each condition completing 16 epoch tasks and evaluating 96 terminal outputs:

| Worker processes | Epoch tasks/second | p50 latency | p95 latency | Qualified / 96 |
|---:|---:|---:|---:|---:|
| 1 | 17.74 | 47.20 ms | 71.68 ms | 66 |
| 2 | 26.34 | 59.18 ms | 106.15 ms | 66 |
| 4 | 41.29 | 77.62 ms | 99.77 ms | 66 |

All **30 qualification failures** remain in every load condition. Batch wall time includes process startup; per-task latency excludes waiting before a worker begins it. This finite local observation does not establish production scalability.

The ablation command reads the original `companion/results/` stream-zero evidence as its registered reference. It does not train a new candidate or replace the primary. Reproduction is also not a new blinded scientific sample: it checks the exact frozen computation. The clean-source reproduction matches all **1,152 normalized observations**, **140,388 exact ledger events**, **192 normalized generation records** and all scientific totals. Only declared nondeterministic timing fields and timestamp-derived pack identities differ.

## Scope, ownership and applicable token utility

The empirical companion extends the released **credential-free `createWorkbench(adapters)` source seam**, with eight unchanged vendored modules from Alpha commit `787bc547f8c44854931b316d7286b8bc9f9c8bba`. The driver selects the next requirement from a finite predeclared stream. Retained capabilities are typed selections from supplied bounded methods; this is not unrestricted code synthesis. The seven stage names label inspectable operations, not seven separately learned agents.

Every generation exposes **WORLD, POLICY, PROOF and AUTHORITY**. Historical recipes and evidence may persist; current proof and production permission do not transfer. The recorded packs retain empty inherited proof/authority, `HOLD` admission and `NOT_CONNECTED` settlement. Evaluation inputs and criteria are fixed outside candidate control.

The native signed Journal, native `CampaignExperiment`, preserved backend scheduler, maintained installed runtime and persistent operating service remain distinct. This package does not initialize native credentials or run held Harness, `enterprise.py` or Fleet actions. The existing native operating-driver owner retains the separate [#4891 lane](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/pull/4891); its [coordination checkpoint](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/issues/4850#issuecomment-6387753484) records corrections/review still pending. This paper does not adopt that change or assert qualified installed operation. Existing owners retain the publication/release lanes and the [original action restrictions](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/issues/4850#issuecomment-6386746278).

The [source audit](audit/FOUNDATION_AND_INTERFACE_AUDIT.md) inspects Alpha, Manager, Jobs v0 and Fleet interfaces, plus the five Alpha contracts: `AscensionAccess`, `NovaSeed`, `AscensionRiskOracle`, `AscensionJobMarket` and `AscensionMark`. Applicable $AGIALPHA functions include conditional staking, collateral, escrow and funding-lot flows where separately authorized and integrated. **No contract simulation, local EVM execution, installed financial adapter, current-chain readback or settlement was exercised here.** The Jobs AGIALPHA18 path remains distinct from Manager's USDC6 path. Issuance, scarcity or price is not evidence of productive growth. The package is unsigned, unfunded and disconnected from financial action.

## Freeze, review and intervention accounting

The source, protocol and task bytes were frozen at **2026-10-24 18:08:09.906 UTC**, before the confirmatory execution. The unchanged [freeze record](companion/freeze.json) and [prospective public record](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/issues/4850#issuecomment-6387744548) preserve that chronology. An explicit after-freeze, before-primary checker **schema-adapter amendment** preserves the original bytes; the reference mathematical core and receipt checker remained unchanged. Both adapters passed the primary outputs. This amendment is not hidden by regenerating the original freeze.

The separate reference implementation checks structural mathematics, receipts and accounting without importing the experimental selector or tariff implementation. Its reviewer was a separate collaborator in the same authoring session, **source-aware and not externally blinded**. See [review/independent/REVIEW_RESULT.md](review/independent/REVIEW_RESULT.md).

One assistant-operator launch starts the full registered primary, after which there are **zero manual phase triggers and zero human interventions within the timed primary**. Design, mission-family selection, setup, debugging, approval scope, launches, recovery studies, review and typesetting are still work. The [authoring intervention ledger](evidence/intervention-ledger-authoring.json) records those categories separately. Human review minutes, design hours, model-assisted authoring inference, electricity, hardware amortization, production upkeep and commercial delivery costs are **unknown, not zero**. No complete economic advantage is claimed.

## Rebuild the paper and editable figures

The publication source is [paper/AGI_ALPHA_FLYWHEEL.tex](paper/AGI_ALPHA_FLYWHEEL.tex), with [paper/references.bib](paper/references.bib), included section files and vector figures. The tested typesetting environment is **TeX Live 2023, XeLaTeX and BibTeX**, with Latin Modern Roman, Sans, Mono and Math fonts. Required TeX packages are declared at the top of the main source: `geometry`, `fontspec`, `unicode-math`, `microtype`, `graphicx`, `booktabs`, `array`, `tabularx`, `longtable`, `enumitem`, `amsmath`, `amsthm`, `xcolor`, `tikz`, `tcolorbox`, `titlesec`, `fancyhdr`, `caption`, `placeins`, `xurl`, `seqsplit`, `natbib` and `hyperref`.

```sh
python3 paper/build_paper.py --output rebuilt-paper
```

The builder uses XeLaTeX → BibTeX → XeLaTeX → XeLaTeX, disables shell escape, fixes the source timestamp, preserves the authoritative PDF and writes `rebuilt-paper/BUILD.json` with the compiler and resulting PDF identity. Choose a new output directory. Compilation uses the supplied vector PDFs and does not require Matplotlib.

To edit and regenerate figures, first provide the pinned Python dependencies in [paper/requirements-figures.txt](paper/requirements-figures.txt), then run the generator in a working copy of the package:

```sh
python3 -m pip install -r paper/requirements-figures.txt
python3 paper/make_figures.py
```

The optional dependency-installation step requires an existing package cache or network access; the core experiment does not. Figure generation writes editable SVGs and vector PDFs, plus PNG previews, under `paper/figures/`. Its pinned versions are **Matplotlib 3.10.8** and **NumPy 2.3.5**. Editing or regenerating publication artifacts creates a derivative and changes their hashes. Keep the supplied authoritative evidence intact.

## Package map

| Path | Contents |
|---|---|
| `paper/` | Authoritative PDF, complete compilable LaTeX, bibliography, vector figures, generators and reproducible build script. |
| `demo/` | Self-contained browser experience, source template, viewer, evidence collector and rebuild instructions. |
| `companion/protocol.json`, `tasks.json`, `freeze.json` | Frozen rules, actual finite task bytes and exact-source commitments. |
| `companion/kernel.mjs`, `run.mjs`, `vendor/` | Research adapter, finite runner, checkpoint reconciliation and unchanged upstream dependency closure. |
| `companion/results/` | Original primary packs, raw observations, all charge events, generation decisions, timings and summary. |
| `companion/faults/`, `load/`, `ablations/` | Original boundary tests, process load, removal/replacement/archive interventions and annotation counterexample. |
| `companion/reproduction/`, `reproduction-verification.json` | Fresh exact-source rerun and explicit semantic/accounting comparison. |
| `companion/reproduction-resume-*.json`, `analysis/` | Whole-study recovery costs, active/history storage and retention balance sheet. |
| `companion/development-*` | Excluded development records, original failures and pre-freeze design corrections. |
| `audit/` | Foundational reading, four-repository/five-contract source maps and exact inspected evidence copies. |
| `review/` | Method review, browser QA and independent arithmetic/receipt source, chronology and reports. |
| `evidence/` | Claim docket, prospective checkpoint receipts and authoring/intervention ledger. |
| `EVIDENCE_DOCKET.md` | Human-readable C01–C13 map matching the paper appendix. |
| `publication/` | Additive receiving-owner handoff material when supplied with this edition; it does not confer merge or deployment approval. |
| `LICENSE` | Apache License 2.0; upstream source notices are preserved. |

The final package manifest checks individual file bytes. Final archive identities, durable readback verification and publication handoff status belong to the **separate delivery report supplied with the downloads**; no archive hash or deployed website is inferred from this README. A hash identifies bytes. It does not certify scientific truth or grant authority.

**🌌 FIND YOUR ALPHA. BUILD YOUR SUCCESSOR Ω.**
