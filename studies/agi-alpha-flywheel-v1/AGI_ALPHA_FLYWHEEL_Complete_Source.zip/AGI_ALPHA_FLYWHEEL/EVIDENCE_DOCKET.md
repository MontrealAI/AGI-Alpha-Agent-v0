# AGI ALPHA FLYWHEEL — evidence docket

**Claims C01–C13 match the paper’s reproduction appendix.** This is a post-run map of the original experiment, its failures and its verification. The prospective protocol and freeze remain the research commitments. The machine-readable [claim docket](evidence/claim-docket.json) binds the exact bytes of each supporting file and each evidence set.

All paths below are relative to this publication package. The package manifest and the separate final delivery report cover final archive identity, rebuild/readback and publication status. This docket does not declare a deployment, clear an existing action restriction or turn historical evidence into current authority.

## Claim map

| Claim | Subject | Primary artifact |
|---|---|---|
| C01 | Prospective freeze and exact source | [companion/freeze.json](companion/freeze.json) |
| C02 | Four-arm coverage and complete-stream outcomes | [companion/results/summary.json](companion/results/summary.json) |
| C03 | Actual generation decisions and inherited identities | [companion/results/generations.json](companion/results/generations.json) |
| C04 | Complete declared structural-work ledger | [companion/results/ledger.jsonl](companion/results/ledger.jsonl) |
| C05 | Causal interventions and annotation failure | [companion/ablations/](companion/ablations/) |
| C06 | Recovery and refusal boundaries | [companion/faults/](companion/faults/) |
| C07 | Finite actual-process load | [companion/load/load.json](companion/load/load.json) |
| C08 | Storage growth and retention balance sheet | [companion/analysis/](companion/analysis/) |
| C09 | Separate reference mathematics and receipt review | [review/independent/](review/independent/) |
| C10 | Exact-source scientific reproduction | [companion/reproduction-verification.json](companion/reproduction-verification.json) |
| C11 | Actual local-browser demonstration | [review/browser-qa.json](review/browser-qa.json) |
| C12 | Source-inspected interfaces and token utility | [audit/](audit/) |
| C13 | Interventions and unmeasured work | [evidence/intervention-ledger-authoring.json](evidence/intervention-ledger-authoring.json) |

## Reading the evidence

The primary unit is a complete 36-task stream: eight paired streams, six generations and four arms. The reported outcome is exact structural qualification under supplied annotations. Standardized work units are a declared proxy; observed time, bytes and unknown authoring costs are separate. The strongest conventional cache uses the same controller and ties exactly. The expert workflow covers more tasks. These qualifications govern every claim below.

## C01 — Prospective freeze and exact source

The experiment source, protocol and finite task bytes were committed before primary execution; original freeze bytes and the explicit pre-primary checker-adapter amendment remain preserved.

Freeze: 2026-10-24 18:08:09.906 UTC.

Prospective public record: https://github.com/MontrealAI/AGI-Alpha-Agent-v0/issues/4850#issuecomment-6387744548.

**Inspect:**

- [companion/freeze.json](companion/freeze.json)
- [companion/protocol.json](companion/protocol.json)
- [companion/tasks.json](companion/tasks.json)
- [companion/upstream-manifest.json](companion/upstream-manifest.json)
- [evidence/pre-primary-checkpoint.json](evidence/pre-primary-checkpoint.json)
- [evidence/pre-primary-public-receipt.json](evidence/pre-primary-public-receipt.json)
- Further exact source/checker/history bindings are listed in the machine-readable claim docket.

**Check:** Compare file hashes, retained original checker bytes, public prospective checkpoint and recorded execution chronology. The runner verifies frozen source/task binding on reproduction.

**Limits:**

- This claim docket is a post-run synthesis, not the preregistration itself.
- The schema adapter changed after first freeze and before primary; its explicit amendment is part of the chronology. The mathematical core and receipt checker did not change.
- Public comments and local hash records identify claims and bytes; they do not establish independent custody or clear an action restriction.

## C02 — Four-arm coverage and complete-stream outcomes

The fixed 500,000-unit-per-stream primary gives flywheel and conventional cache 271/288, fixed lead 58/288 and expert router 288/288; all registered terminal tasks remain in each denominator.

Flywheel/cache units: 2,017,944 each; fixed lead: 1,412,176; expert: 2,134,383.

Expert coverage is higher and units per qualified output slightly lower (7,411.05 versus 7,446.29).

**Inspect:**

- [companion/results/summary.json](companion/results/summary.json)
- [companion/results/observations.jsonl](companion/results/observations.jsonl)
- [companion/results/timing.json](companion/results/timing.json)
- [review/independent/primary-verification-frozen.json](review/independent/primary-verification-frozen.json)
- [review/independent/primary-verification-amended.json](review/independent/primary-verification-amended.json)
- Evidence set `primary_packs`: 192 files, each with its own SHA-256 and byte count in the machine-readable docket.

**Check:** Recompute supported weight, exact optimum, qualification and fixed denominators independently, then aggregate whole streams and exact paired differences.

**Limits:**

- Structural quality is defined by authored annotations, not factual source truth, comprehension or real demand.
- The cache is an explicit equivalence control using the same controller and adaptation rule. No advantage over it is established.
- The expert is a prewritten analytical workflow; human-expert labor was not measured.
- Budget-prefix curves are descriptive projections of the original run, not new policy executions. Uncertainty is described over eight complete streams, not 288 independent tasks.

## C03 — Actual generation decisions and inherited identities

The recorded loop automatically progresses through the finite stream, preserves exact accepted recipe identities on later reuse, retains incumbents, rejects a descendant and does not inherit current proof or production authority.

138 terminal outputs use a recipe from an earlier generation; 134 qualify.

96 outputs use current-generation acquisitions; 54 have no attached capability.

**Inspect:**

- [companion/results/generations.json](companion/results/generations.json)
- [companion/results/observations.jsonl](companion/results/observations.jsonl)
- [companion/EXECUTION_SCOPE.json](companion/EXECUTION_SCOPE.json)
- [review/independent/lineage-verification.json](review/independent/lineage-verification.json)
- Evidence set `primary_packs`: 192 files, each with its own SHA-256 and byte count in the machine-readable docket.

**Check:** Bind each use to the actual recipe digest and creation epoch; verify method/source bodies, decisions, stage trace and empty proof/authority fields in the immutable workbench packs.

**Limits:**

- Sixteen admission actions are four distinct content digests, not sixteen unique algorithms.
- The acquired object selects supplied bounded methods. No general code invention or unrestricted self-modification is demonstrated.
- Native signed Journal, installed runtime and persistent operating service were not exercised. The process must remain running.

## C04 — Complete declared structural-work ledger

All 140,388 primary charge events are retained and reconcile once into generation, stream and arm totals, including search, qualification, execution, validation, routing, retention, maintenance and SDK charges.

Flywheel validation alone accounts for 1,053,126 of 2,017,944 units.

Unknown labor and authoring inference are not assigned zero cost.

**Inspect:**

- [companion/results/ledger.jsonl](companion/results/ledger.jsonl)
- [companion/results/generations.json](companion/results/generations.json)
- [companion/protocol.json](companion/protocol.json)
- [companion/kernel.mjs](companion/kernel.mjs)
- [review/independent/primary-verification-amended.json](review/independent/primary-verification-amended.json)
- [evidence/intervention-ledger-authoring.json](evidence/intervention-ledger-authoring.json)
- Evidence set `primary_packs`: 192 files, each with its own SHA-256 and byte count in the machine-readable docket.

**Check:** Recompute the comparison tariff separately, reconcile each admitted event and each category exactly once, and preserve refused attempted charges outside spent totals.

**Limits:**

- Observation cost_breakdown fields are epoch-cumulative snapshots; summing them would double-count setup.
- The original source comparison computes all five methods. Its full declared overhead is charged.
- These units are neither measured processor operations nor monetary/economic cost. Wall time, CPU, storage and unknown authoring cost remain separate.
- Logical budget admission is not a hard operating-system CPU limit; implementation overhead is not a fully priced economic cost.

## C05 — Causal interventions and annotation failure

Component removal, equivalent descriptor replacement and complete archive clearing produce distinct, preserved counterfactuals; a source-aware annotation challenge shows local structural success can fail under a different true dependency graph.

Retention: 36/36 at 316,616 units. Clearing: 30/36 at 279,432 units.

Equivalent replacement carries empty proof and authority.

**Inspect:**

- [companion/ablations/ablations.jsonl](companion/ablations/ablations.jsonl)
- [companion/ablations/archive-cleared.json](companion/ablations/archive-cleared.json)
- [companion/ablations/annotation-challenge.json](companion/ablations/annotation-challenge.json)
- [review/independent/secondary-verification.json](review/independent/secondary-verification.json)
- [companion/analysis/retention-balance-sheet.json](companion/analysis/retention-balance-sheet.json)
- Evidence set `archive_cleared_packs`: 6 files, each with its own SHA-256 and byte count in the machine-readable docket.

**Check:** Recompute all 72 component rows, six archive-cleared packs, corresponding work charges and both annotation graphs. Pair archive intervention by the exact registered stream-zero task bytes.

**Limits:**

- Component removal establishes the selected method effect; it does not prove persistence is the only way to obtain that method.
- Archive clearing allows reconstruction and fresh qualification; retention adds six outputs at 37,184 extra total units, not a net cost saving.
- The same stream-zero inputs are reused for the predeclared intervention. This is not a new independently blinded holdout.
- The annotation counterexample is source-aware and constructed, not a measurement of real-world annotation error prevalence.

## C06 — Recovery and refusal boundaries

Sixteen expected fault-boundary assertions pass, including real process restart, changed source bytes, duplicate identities, semantic forgery, exhausted budget, expired local permit, partial work, WAIT and rejected-descendant recovery.

All 16 cases pass their declared expected assertions; denied or rejected actions are successful boundary tests.

Whole-study resume verification takes 7,124.42 ms summed observed time.

**Inspect:**

- [companion/faults/failure_cases.json](companion/faults/failure_cases.json)
- [companion/reproduction-resume-report.json](companion/reproduction-resume-report.json)
- [companion/reproduction-resume-summary.json](companion/reproduction-resume-summary.json)
- [review/independent/operations-verification.json](review/independent/operations-verification.json)
- Evidence set `fault_evidence`: 16 files, each with its own SHA-256 and byte count in the machine-readable docket.

**Check:** Inspect source/input identity binding, saved receipts, actual child-process restart, changed dependency copy, partial charges, refusal states and the separate deterministic semantic replay.

**Limits:**

- Zero fresh results after commit does not mean zero computation. The complete resume reexecutes verification 192 times at 12,938,483 additional units.
- An uncommitted pure computation can run again; this is not distributed exactly-once execution.
- Native byte-integrity inspection accepts a self-consistently rehashed semantic forgery; the added task-bound semantic replay is what rejects it.
- Expired authority means the finite local research permit. Prior-recipe reuse is not a production deployment rollback.

## C07 — Finite actual-process load

A bounded 16-epoch-task batch was executed with one, two and four actual Node processes; throughput, latency, quality, CPU and output bytes are retained for every condition.

Throughput: 17.74, 26.34 and 41.29 epoch tasks/s for 1, 2 and 4 processes.

No human intervention occurs within the scripted batches.

**Inspect:**

- [companion/load/load.json](companion/load/load.json)
- [review/independent/operations-verification.json](review/independent/operations-verification.json)

**Check:** Recalculate task counts, throughput from recorded wall time, p50/p95 latency from task values, qualified counts, CPU totals and byte totals.

**Limits:**

- All conditions qualify 66/96 terminal outputs; 30 qualification failures persist in each.
- Wall time includes process startup; task latency excludes waiting before a worker starts.
- This is a small finite local test on one observed host, not evidence of production scalability or long-run reliability.

## C08 — Storage growth and retention balance sheet

The study measures active recipe storage separately from growing retained evidence, and compares acquisition savings with later execution costs under exact changed requirements.

Active archive: at most two recipes and 789 canonical bytes.

Generation 4 reuse saves 12,266 units; generation 5 rebuilding saves 39,662 units.

**Inspect:**

- [companion/analysis/storage-growth.json](companion/analysis/storage-growth.json)
- [companion/analysis/retention-balance-sheet.json](companion/analysis/retention-balance-sheet.json)
- [review/independent/storage-retention-verification.json](review/independent/storage-retention-verification.json)
- Evidence set `primary_packs`: 192 files, each with its own SHA-256 and byte count in the machine-readable docket.
- Evidence set `archive_cleared_packs`: 6 files, each with its own SHA-256 and byte count in the machine-readable docket.

**Check:** Measure actual retained pack bytes and canonical active-recipe bytes; reconcile per-epoch category differences against the archive-cleared counterfactual.

**Limits:**

- No primary retirement event occurred; capacity eviction is not empirically demonstrated by this primary trace.
- Small active recipe storage does not imply small history storage or bounded indefinite retention.
- Avoided construction is only one cost term. The retained recipe loses 39,662 units in generation 5 at equal observed quality.

## C09 — Separate reference mathematics and receipt review

A separate same-session implementation independently recomputes structural optima, qualification, raw accounting and unsigned receipt bindings; both original and amended primary adapters pass with zero reported errors.

Both frozen and explicitly amended primary adapters reconcile all primary evidence.

Original checker bytes and amendment receipts remain available.

**Inspect:**

- [review/independent/REVIEW_SCOPE.md](review/independent/REVIEW_SCOPE.md)
- [review/independent/REVIEW_RESULT.md](review/independent/REVIEW_RESULT.md)
- [review/independent/primary-verification-frozen.json](review/independent/primary-verification-frozen.json)
- [review/independent/primary-verification-amended.json](review/independent/primary-verification-amended.json)
- [review/independent/checker-amendment-01.json](review/independent/checker-amendment-01.json)
- [review/independent/secondary-checker-registration.json](review/independent/secondary-checker-registration.json)
- Evidence set `independent_review`: 31 files, each with its own SHA-256 and byte count in the machine-readable docket.

**Check:** Run review/independent/review_results.py on a fresh run; inspect verify.py integer-mask closure/optimum construction and receipt_verify.py hash/input checks, neither importing the experimental JavaScript or selector.

**Limits:**

- Reviewer is source-aware, in the same authoring session, not externally blinded or an independent institution.
- Secondary analysis adapters were added with their chronology disclosed; no post-hoc outcome adjustment is disguised as preregistration.
- Arithmetic/model consistency does not certify source truth, commercial value, production safety or publication authority.

## C10 — Exact-source scientific reproduction

A new source-only directory reproduced the primary scientific decisions and accounting exactly under specified nondeterministic exclusions.

Clean rerun: 14.913 seconds observed wall time.

Final archive extraction/build/readback verification is a later delivery record, separate from this claim.

**Inspect:**

- [companion/reproduction-verification.json](companion/reproduction-verification.json)
- [companion/reproduction/summary.json](companion/reproduction/summary.json)
- [companion/reproduction/observations.jsonl](companion/reproduction/observations.jsonl)
- [companion/reproduction/ledger.jsonl](companion/reproduction/ledger.jsonl)
- [companion/reproduction/generations.json](companion/reproduction/generations.json)
- [review/independent/reproduction-equivalence.json](review/independent/reproduction-equivalence.json)
- Further exact source/checker/history bindings are listed in the machine-readable claim docket.
- Evidence set `reproduction_packs`: 192 files, each with its own SHA-256 and byte count in the machine-readable docket.

**Check:** Compare all 1,152 normalized observation rows, all 140,388 exact event rows, all 192 normalized generation records and source/task/protocol-bound aggregate results.

**Limits:**

- Only elapsed_ns is excluded from observation comparison; only timestamp-derived packDigest is excluded from generation comparison. Ledger rows have no exclusions.
- Fresh timestamps, compilation expiries and derived pack identities need not be byte-identical.
- Repetition checks deterministic computation; it is not an additional independent scientific sample or portable speed guarantee.

## C11 — Actual local-browser demonstration

Twenty-four actual-browser checks passed against the exact self-contained demo, covering recorded navigation, separate fresh computation, downloads, keyboard use and narrow bilingual layouts.

The exact measured demo hash is bound in the machine-readable docket.

Screenshots listed as temporary review surfaces are not required publication artifacts.

**Inspect:**

- [review/browser-qa.json](review/browser-qa.json)
- [review/browser-fresh-download.json](review/browser-fresh-download.json)
- [review/browser-fresh-stream.json](review/browser-fresh-stream.json)
- [review/browser-stream-download.json](review/browser-stream-download.json)
- [demo/index.html](demo/index.html)
- [demo/README.md](demo/README.md)

**Check:** Compare demo bytes to browser-qa.json, inspect each real-browser case and actual downloaded fresh outputs. Distinguish replay, fresh source instrument and fresh bounded stream.

**Limits:**

- The fresh computation runs only while its browser tab is open. No persistent daemon or automatic upload is created.
- The local-file browser check does not establish a public HTTPS deployment or every browser/version.
- A context without the required WebCrypto API refuses the source-extension run.

## C12 — Source-inspected interfaces and token utility

The frozen audit maps four repositories and five Alpha contracts, with exact inspected source identities and explicit separation of potential token utility from executed software and settlement.

Applicable AGIALPHA functions are conditional staking, collateral, escrow and funding-lot uses.

The inspected historical deployment guide is historical source evidence, not a refreshed authority audit.

**Inspect:**

- [audit/FOUNDATION_AND_INTERFACE_AUDIT.md](audit/FOUNDATION_AND_INTERFACE_AUDIT.md)
- [audit/source-manifest.json](audit/source-manifest.json)
- [audit/retrieval-records.json](audit/retrieval-records.json)
- [audit/references-audit.bib](audit/references-audit.bib)
- Evidence set `inspected_interface_copies`: 6 files, each with its own SHA-256 and byte count in the machine-readable docket.

**Check:** Inspect exact source functions, public retrieval identities and source-pin records. Do not infer live deployment status from diagrams, imported files or historical documents.

**Limits:**

- No RPC/mainnet refresh, EVM run, contract logic simulation, installed financial adapter or settlement was executed.
- Token issuance, scarcity or price is not a measured productivity endpoint.
- Manager USDC6 and Jobs AGIALPHA18 balances/routes are distinct; no conversion or connected four-installed tuple is assumed.
- Existing owner, publication and original Harness/Fleet action restrictions remain unchanged. Native operating work in #4891 is a separate lane, not an adopted qualification.

## C13 — Interventions and unmeasured work

The authoring ledger distinguishes one user commission and one primary operator launch from zero manual phase triggers during the finite primary, while disclosing setup, debugging, reviews, ancillary launches and unknown costs.

Unknown: human review minutes, design hours, authoring inference, electricity/hardware costs, production maintenance and commercial delivery.

Publication packaging and durable-copy verification are recorded separately after final artifact preparation.

**Inspect:**

- [evidence/intervention-ledger-authoring.json](evidence/intervention-ledger-authoring.json)
- [companion/development-events.json](companion/development-events.json)
- [companion/results/summary.json](companion/results/summary.json)
- [companion/reproduction-resume-summary.json](companion/reproduction-resume-summary.json)
- [review/method-review-01.json](review/method-review-01.json)
- [review/method-review-02.json](review/method-review-02.json)
- Further exact source/checker/history bindings are listed in the machine-readable claim docket.

**Check:** Read category-level authoring history alongside exact timed-run intervention counters; preserve exclusions and failed development attempts rather than setting unknown effort to zero.

**Limits:**

- Labor durations and authoring-model inference were not measured. Category disclosure is not complete priced telemetry.
- One automatic finite run is not an unattended production service or evidence of growing commercial demand.
- Assistant setup, source review, debugging, launches and final publication preparation are not erased by zero in-run manual phase triggers.

## Ownership and delivery boundary

The [original issue #4850 decision map](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/issues/4850#issuecomment-6386746278) remains in force. The separately owned native operating change is [#4891](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/pull/4891); its [cited handoff](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/issues/4850#issuecomment-6387753484) records corrections/review pending. It is not adopted or qualified by this credential-free research package. Existing publication/release owners retain the receiving and publication lanes.

The final authoritative PDF, source archive identities, archive extraction/build verification and durable-copy readback are bound by the final delivery record supplied separately. A favorable local result, file hash or manuscript cannot grant production, settlement, merge or website-deployment authority.
