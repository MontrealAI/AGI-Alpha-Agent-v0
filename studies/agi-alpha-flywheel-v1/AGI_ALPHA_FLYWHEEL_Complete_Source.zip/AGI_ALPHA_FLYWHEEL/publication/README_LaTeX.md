# Rebuild the publication PDF

The archive preserves the authoritative `paper/AGI_ALPHA_FLYWHEEL.pdf` alongside its complete LaTeX source, bibliography, editable SVG/PDF figures and figure generator. Extract the ZIP, change into `AGI_ALPHA_FLYWHEEL`, then run:

```sh
python3 paper/build_paper.py --output rebuilt-paper
```

Use Python 3.12.14 and XeLaTeX/BibTeX from TeX Live 2023 (tested XeTeX 0.999995, Debian), with Latin Modern Roman/Sans/Mono/Math and standard packages listed at the beginning of `paper/AGI_ALPHA_FLYWHEEL.tex`. Shell escape is disabled. The script refuses an existing output directory and preserves the authoritative PDF. Its `BUILD.json` records the rebuilt hash and whether bytes match the packaged authoritative PDF. Results on different TeX distributions may have different typography or PDF metadata.

For Overleaf or another LaTeX editor, select XeLaTeX, use `paper/` as the project content root and choose `AGI_ALPHA_FLYWHEEL.tex`. Run BibTeX and the usual subsequent LaTeX passes. No network or external image retrieval is required during compilation.

The supplied figure PDFs are used directly. To regenerate PDF/SVG figures from their Python source, install the versions in `paper/requirements-figures.txt`, then run `python3 paper/make_figures.py` from the package root. The small `companion/results/` subset in this compact archive supplies the exact data used by the plots. The complete research companion contains the full raw evidence and runnable experiment.

`MANIFEST.json` records SHA-256 for every payload file. The authoritative PDF is the one inside the archives; a document platform may separately attach provenance metadata to a standalone PDF download. The final delivery report records durable-copy byte verification separately.
