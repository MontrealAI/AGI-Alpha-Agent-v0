# SPDX-License-Identifier: Apache-2.0
"""Create deterministic, inspectable publication archives from this package."""
from pathlib import Path
import argparse
import hashlib
import json
import shutil
import zipfile

ROOT = Path(__file__).resolve().parent.parent
STAMP = (2026, 10, 24, 18, 0, 0)
EXCLUDED_PARTS = {'__pycache__', 'node_modules', 'mpl-cache', 'tmp-build'}

def include(path):
    rel = path.relative_to(ROOT)
    if any(p.startswith('.') or p in EXCLUDED_PARTS or '-build-' in p for p in rel.parts):
        return False
    if path.suffix.lower() in {'.png', '.jpg', '.jpeg', '.webp', '.gif', '.pyc', '.aux', '.blg', '.bbl', '.log', '.out', '.toc'}:
        return False
    if len(rel.parts) == 1 and path.suffix.lower() in {'.zip', '.json'}:
        return False
    if str(rel) in {'audit/Out_Evolve.pdf', 'audit/Out_Evolve.txt', 'evidence/pre-primary-durable-receipt.json'}:
        return False
    return path.is_file()

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def archive(destination, files):
    manifest = {'schema': 'flywheel-publication-files/v1', 'files': [
        {'path': str(p.relative_to(ROOT)), 'bytes': p.stat().st_size, 'sha256': sha(p)} for p in files
    ]}
    with zipfile.ZipFile(destination, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as out:
        for path in files:
            entry = zipfile.ZipInfo('AGI_ALPHA_FLYWHEEL/' + str(path.relative_to(ROOT)), STAMP)
            entry.compress_type = zipfile.ZIP_DEFLATED
            entry.external_attr = 0o100644 << 16
            out.writestr(entry, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
        entry = zipfile.ZipInfo('AGI_ALPHA_FLYWHEEL/MANIFEST.json', STAMP)
        entry.compress_type = zipfile.ZIP_DEFLATED
        entry.external_attr = 0o100644 << 16
        out.writestr(entry, json.dumps(manifest, indent=2) + '\n')
    with zipfile.ZipFile(destination) as check:
        assert check.testzip() is None
        for record in manifest['files']:
            data = check.read('AGI_ALPHA_FLYWHEEL/' + record['path'])
            assert len(data) == record['bytes']
            assert hashlib.sha256(data).hexdigest() == record['sha256']
        assert check.read('AGI_ALPHA_FLYWHEEL/paper/AGI_ALPHA_FLYWHEEL.pdf') == (ROOT / 'paper/AGI_ALPHA_FLYWHEEL.pdf').read_bytes()
    return {'file': destination.name, 'bytes': destination.stat().st_size, 'sha256': sha(destination),
            'files': len(files), 'manifest_verified': True, 'authoritative_pdf_preserved': True}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True, help='New output directory, outside the source root.')
    args = parser.parse_args()
    output = args.output.resolve()
    if output == ROOT or ROOT in output.parents:
        raise SystemExit('Output must be outside the source root to avoid recursive packaging.')
    output.mkdir(parents=True, exist_ok=False)
    files = sorted(p for p in ROOT.rglob('*') if include(p))
    latex = [p for p in files if p.parts[len(ROOT.parts)] == 'paper' or str(p.relative_to(ROOT)) in {
        'LICENSE', 'publication/README_LaTeX.md', 'companion/results/summary.json', 'companion/results/generations.json'}]
    results = [archive(output/'AGI_ALPHA_FLYWHEEL_Complete_Source.zip', files),
               archive(output/'AGI_ALPHA_FLYWHEEL_LaTeX.zip', latex)]
    for source, name in [(ROOT/'paper/AGI_ALPHA_FLYWHEEL.pdf', 'AGI_ALPHA_FLYWHEEL.pdf'),
                         (ROOT/'demo/index.html', 'AGI_ALPHA_FLYWHEEL_Demo.html')]:
        shutil.copyfile(source, output/name)
        results.append({'file': name, 'bytes': (output/name).stat().st_size, 'sha256': sha(output/name)})
    record = {'schema': 'flywheel-publication-archives/v1', 'deterministic_zip_timestamp': list(STAMP),
              'authoritative_pdf_sha256': sha(ROOT/'paper/AGI_ALPHA_FLYWHEEL.pdf'), 'artifacts': results,
              'excluded': 'Internal QA screenshots, transient build/cache files, private durable-copy identifiers and redundant prior-paper PDFs are excluded. Scientific raw evidence and unsuccessful cases are retained.'}
    (output/'ARCHIVE_MANIFEST.json').write_text(json.dumps(record, indent=2)+'\n')
    (output/'SHA256SUMS.txt').write_text(''.join(f"{r['sha256']}  {r['file']}\n" for r in results))
    print(json.dumps(record, indent=2))

if __name__ == '__main__':
    main()
