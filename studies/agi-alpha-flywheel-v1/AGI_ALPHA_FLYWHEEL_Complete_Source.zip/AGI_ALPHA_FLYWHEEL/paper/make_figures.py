# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import json, os, math
from datetime import datetime, timezone
os.environ.setdefault('MPLCONFIGDIR',str(Path(__file__).parent/'mpl-cache'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'figures'
OUT.mkdir(exist_ok=True)
PURPLE='#5A31A0'; DARK='#211237'; LAV='#EDE5F7'; GOLD='#BF9447'; TEAL='#007A78'; ROSE='#A64E61'; INK='#1C2536'; MUTED='#61697A'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.edgecolor':'#D9D5E0','axes.labelcolor':INK,'text.color':INK,'svg.fonttype':'none','pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False,'savefig.facecolor':'white','svg.hashsalt':'AGI-ALPHA-FLYWHEEL-v1'})
def save(fig,name):
 for ext in ['pdf','svg','png']:
  fig.savefig(OUT/f'{name}.{ext}',bbox_inches='tight',pad_inches=.14,dpi=180,metadata=({'Creator':'AGI ALPHA FLYWHEEL research companion','CreationDate':datetime(2026,10,24,18,0,tzinfo=timezone.utc),'ModDate':datetime(2026,10,24,18,0,tzinfo=timezone.utc)} if ext=='pdf' else {'Date':'2026-10-24T18:00:00Z'} if ext=='svg' else None))
 plt.close(fig)
def box(ax,x,y,w,h,title,body,color=PURPLE):
 ax.add_patch(FancyBboxPatch((x-w/2,y-h/2),w,h,boxstyle='round,pad=.03,rounding_size=.12',facecolor='white',edgecolor=color,lw=1.25))
 ax.text(x,y+.15,title,ha='center',va='center',weight='bold',color=color,fontsize=12)
 ax.text(x,y-.2,body,ha='center',va='center',fontsize=9.5,linespacing=1.5)
def arrow(ax,a,b,color=PURPLE,style='-',rad=0):
 ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=14,lw=1.3,color=color,linestyle=style,connectionstyle=f'arc3,rad={rad}'))
def loop():
 fig,ax=plt.subplots(figsize=(10,6.2));ax.set(xlim=(-5,5),ylim=(-3.2,3.2));ax.axis('off')
 spots=[(-3.15,1.9),(0,1.9),(3.15,1.9),(3.15,-1.4),(0,-1.4),(-3.15,-1.4)]
 labels=[('SELECT','Next eligible mission\nFixed stream and purpose'),('CONSTRUCT / REUSE','Exact bounded method\nIncumbent remains available'),('EXECUTE','Existing Alpha workbench\nImmutable mission input'),('CHECK','Fresh task + independent rule\nFull cost charged'),('RETAIN / RETIRE','Executable method + scope\nHistory and failures preserved'),('CHOOSE NEXT','Changed requirements\nWAIT, abstain or STOP')]
 for (x,y),(title,body) in zip(spots,labels):box(ax,x,y,2.7,1.14,title,body)
 arrow(ax,(-1.75,1.9),(-1.4,1.9));arrow(ax,(1.4,1.9),(1.75,1.9));arrow(ax,(3.15,1.27),(3.15,-.78))
 arrow(ax,(1.75,-1.4),(1.4,-1.4));arrow(ax,(-1.4,-1.4),(-1.75,-1.4));arrow(ax,(-3.15,-.78),(-3.15,1.27))
 ax.text(0,.37,'KEEP THE MEANS.',ha='center',weight='bold',fontsize=17,color=PURPLE)
 ax.text(0,-.02,'RE-EARN THE PROOF.',ha='center',weight='bold',fontsize=17,color=INK)
 ax.text(0,-2.75,'Historical evidence may cross generations. Active proof and authority start empty.',ha='center',fontsize=10.3,color=MUTED)
 save(fig,'mission-capability-loop')
def lineage(generations=None):
 fig,ax=plt.subplots(figsize=(10,5.8));ax.axis('off');ax.set(xlim=(0,10),ylim=(0,6))
 spots=[(1.65,4.6),(5,4.6),(8.35,4.6),(8.35,2.65),(5,2.65),(1.65,2.65)]
 nodes=[('G0 / RETAIN','Lead-order\n6/6 qualified',MUTED),('G1 / ACQUIRE','Weighted selection\n6/6 qualified',PURPLE),('G2 / ACQUIRE','Exact graph selection\n6/6 qualified',PURPLE),('G3 / REUSE G2','New graph, cap 2\n6/6 qualified',TEAL),('G4 / REUSE G1','Independent clauses return\n6/6 qualified',TEAL),('G5 / REUSE G2','New graph, cap 1\n6/6 qualified',TEAL)]
 for (x,y),(title,body,c) in zip(spots,nodes):box(ax,x,y,2.7,1.1,title,body,c)
 arrow(ax,(3.06,4.6),(3.58,4.6));arrow(ax,(6.42,4.6),(6.94,4.6));arrow(ax,(8.35,3.98),(8.35,3.28));arrow(ax,(6.94,2.65),(6.42,2.65));arrow(ax,(3.58,2.65),(3.06,2.65))
 ax.text(5,5.62,'Recorded lineage / stream 0',ha='center',fontsize=13,weight='bold')
 ax.text(5,1.62,'Two acquired recipes. Original digests retained on later reuse. Fresh checks every time.',ha='center',fontsize=10,color=MUTED)
 ax.add_patch(FancyBboxPatch((.35,.25),9.3,.8,boxstyle='round,pad=.03,rounding_size=.1',facecolor='#FAF0F3',edgecolor=ROSE,lw=1))
 ax.text(5,.77,'SEPARATE NEGATIVE CASE / STREAM 3, G2',ha='center',weight='bold',color=ROSE,fontsize=10.5)
 ax.text(5,.43,'Audit descendant rejected. Lead incumbent retained. 0/6 terminal tasks qualified.',ha='center',fontsize=10)
 save(fig,'generation-lineage')
def coverage(summary):
 fig,ax=plt.subplots(figsize=(10,5.2))
 for key,label,c,mark in [('expert','Authored expert workflow',GOLD,'s'),('flywheel','Flywheel = conventional cache',PURPLE,'o'),('frozen','No acquired capability',MUTED,'^')]:
  rows=summary['budgetCurves'][key];xs=[r['budget']/1000 for r in rows];ys=[r['qualified'] for r in rows]
  ax.plot(xs,ys,color=c,marker=mark,lw=2.1,markersize=6,linestyle='--',label=label)
  ax.scatter([xs[-1]],[ys[-1]],s=120,color='white',edgecolor=c,linewidth=2,zorder=5,marker=mark)
  ax.annotate(str(ys[-1]),(xs[-1],ys[-1]),xytext=(11,0),textcoords='offset points',va='center',color=c,weight='bold')
 ax.set_xscale('log');ax.set_xticks([25,50,100,200,500],['25k','50k','100k','200k','500k']);ax.minorticks_off();ax.set_xlim(21,650);ax.set_ylim(0,305)
 ax.set_yticks([0,72,144,216,288]);ax.set_ylabel('Qualified terminal tasks / 288');ax.set_xlabel('Cumulative standardized-work budget per stream')
 ax.grid(axis='y',color='#E8E4EE',lw=.7);ax.legend(loc='lower right',frameon=False,fontsize=10)
 ax.set_title('Opportunity coverage after acquisition and checking costs',loc='left',fontsize=14,weight='bold',pad=15)
 fig.text(.13,-.02,'Open endpoints: primary 500k experiment. Dashed paths: descriptive prefixes of that run.',fontsize=10,color=MUTED)
 save(fig,'opportunity-coverage')
def costs(summary):
 fig,ax=plt.subplots(figsize=(10,5.4));arms=['flywheel','cache','frozen','expert'];ys=list(range(4));left=[0.0]*4
 categories=[('construction','Construction / search',PURPLE),('qualification','Candidate qualification','#A58CCD'),('execution','Terminal execution',TEAL),('validation','Current result validation','#8BBABB'),('overhead','Routing / retention / maintenance / SDK',GOLD)]
 for key,label,c in categories:
  vals=[(sum(v for k,v in summary['arms'][a]['costs'].items() if k in ['routing','retention','maintenance','runtime']) if key=='overhead' else summary['arms'][a]['costs'][key])/1e6 for a in arms]
  ax.barh(ys,vals,left=left,height=.52,color=c,label=label)
  left=[x+y for x,y in zip(left,vals)]
 for y,a,total in zip(ys,arms,left):ax.text(total+.04,y,f"{summary['arms'][a]['qualified']}/288",va='center',weight='bold',fontsize=11)
 ax.set_yticks(ys,['Flywheel','Conventional cache','No acquisition','Expert workflow']);ax.invert_yaxis();ax.set_xlim(0,2.55)
 ax.set_xlabel('Total standardized structural-work units (millions, eight streams)');ax.grid(axis='x',color='#E8E4EE',lw=.7);ax.set_axisbelow(True)
 ax.set_title('Full declared work / achieved qualified coverage',loc='left',fontsize=14,weight='bold',pad=16)
 ax.legend(loc='upper center',bbox_to_anchor=(.45,-.19),ncol=2,frameon=False,fontsize=9.8)
 save(fig,'full-cost-comparison')
def recovery():
 fig,ax=plt.subplots(figsize=(10,5.5));ax.axis('off');ax.set(xlim=(0,10),ylim=(0,5.5))
 box(ax,1.65,4.5,2.6,.95,'BOUND REQUEST','Identity + input + source')
 box(ax,5,4.5,2.6,.95,'LOCAL EXECUTION','Budget and scope checked')
 box(ax,8.35,4.5,2.6,.95,'COMMITTED RESULT','Durable reply and decision')
 arrow(ax,(3,4.5),(3.6,4.5));arrow(ax,(6.4,4.5),(7,4.5))
 labels=[(1.65,2.55,'DUPLICATE','Return prior identity\nReject changed payload',TEAL),(5,2.55,'INTERRUPTED','Resume from retained state\nCharge any repeated work',TEAL),(8.35,2.55,'LOST REPLY','Return committed receipt\nNo new accepted work',TEAL)]
 for x,y,title,body,c in labels:box(ax,x,y,2.65,1.2,title,body,c);arrow(ax,(x,3.95),(x,3.22),c)
 ax.add_patch(FancyBboxPatch((.3,.3),9.4,.9,boxstyle='round,pad=.04,rounding_size=.1',facecolor='#FAF0F3',edgecolor=ROSE,lw=1))
 ax.text(5,.87,'REFUSE / HOLD',ha='center',weight='bold',color=ROSE,fontsize=12)
 ax.text(5,.53,'Changed dependency  •  Invalid receipt  •  Exhausted budget  •  Expired authority',ha='center',fontsize=10)
 ax.text(5,5.27,'Local research failure map; exact outcomes are in the fault receipts.',ha='center',fontsize=11,color=MUTED)
 save(fig,'failure-recovery-map')
if __name__=='__main__':
 loop();lineage();recovery()
 summary_path=ROOT.parent/'companion/results/summary.json'
 if summary_path.exists():
  summary=json.loads(summary_path.read_text());coverage(summary);costs(summary)
