# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import argparse, hashlib, json, os, shutil, subprocess, sys

root=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description='Rebuild the paper in a new directory; preserve the authoritative PDF.')
p.add_argument('--output',type=Path,default=root/'build')
a=p.parse_args(); out=a.output.resolve()
if out.exists(): raise SystemExit('Choose a new output directory; existing evidence is preserved.')
out.mkdir(parents=True)
env=dict(os.environ,TZ='UTC',SOURCE_DATE_EPOCH='1792864800',FORCE_SOURCE_DATE='1',BIBINPUTS=str(root)+os.pathsep,BSTINPUTS=str(root)+os.pathsep)
commands=[['xelatex','-no-shell-escape','-interaction=nonstopmode','-halt-on-error','-output-directory='+str(out),'AGI_ALPHA_FLYWHEEL.tex'],['bibtex','AGI_ALPHA_FLYWHEEL'],['xelatex','-no-shell-escape','-interaction=nonstopmode','-halt-on-error','-output-directory='+str(out),'AGI_ALPHA_FLYWHEEL.tex'],['xelatex','-no-shell-escape','-interaction=nonstopmode','-halt-on-error','-output-directory='+str(out),'AGI_ALPHA_FLYWHEEL.tex']]
for i,command in enumerate(commands):
 with (out/f'pass-{i+1}.log').open('wb') as log:
  result=subprocess.run(command,cwd=out if command[0]=='bibtex' else root,env=env,stdout=log,stderr=subprocess.STDOUT)
 if result.returncode: raise SystemExit(f'Build failed; see {out/f"pass-{i+1}.log"}')
pdf=out/'AGI_ALPHA_FLYWHEEL.pdf'; reference=root/'AGI_ALPHA_FLYWHEEL.pdf'
record={'schema':'flywheel-paper-build/v1','pdf':str(pdf),'bytes':pdf.stat().st_size,'sha256':hashlib.sha256(pdf.read_bytes()).hexdigest(),'source_date_epoch':env['SOURCE_DATE_EPOCH'],'timezone':'UTC','compiler':subprocess.check_output(['xelatex','--version'],text=True).splitlines()[0],'shell_escape':False}
if reference.exists(): record['matches_packaged_authoritative_pdf']=reference.read_bytes()==pdf.read_bytes()
(out/'BUILD.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
