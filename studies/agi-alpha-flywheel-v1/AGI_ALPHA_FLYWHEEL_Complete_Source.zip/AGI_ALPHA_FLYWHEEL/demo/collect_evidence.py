from pathlib import Path
import json

root=Path(__file__).resolve().parent.parent
companion=root/'companion'
load=lambda path:json.loads(path.read_text())
rows=lambda path:[json.loads(line) for line in path.read_text().splitlines() if line.strip()]
data={
 'schema':'flywheel-viewer/v1',
 'status':'recorded-study-and-separate-fresh-browser-demo',
 'upstream_commit':'787bc547f8c44854931b316d7286b8bc9f9c8bba',
 'summary':load(companion/'results/summary.json'),
 'observations':rows(companion/'results/observations.jsonl'),
 'generations':load(companion/'results/generations.json'),
 'timing':load(companion/'results/timing.json'),
 'protocol':load(companion/'protocol.json'),
 'freeze':load(companion/'freeze.json'),
 'failures':load(companion/'faults/failure_cases.json'),
 'ablations':rows(companion/'ablations/ablations.jsonl'),
 'archive_cleared':load(companion/'ablations/archive-cleared.json'),
 'annotation_challenge':load(companion/'ablations/annotation-challenge.json'),
 'load':load(companion/'load/load.json')
}
for filename in ['interventions.jsonl','intervention-ledger.jsonl']:
 path=companion/filename
 if path.exists():data['interventions']=rows(path)
authoring_ledger=root/'evidence/intervention-ledger-authoring.json'
if authoring_ledger.exists():
 data['authoring_interventions']=load(authoring_ledger)
arms=data['summary']['arms']
data['summary']['conclusion']=f"Retained-capability workflow: {arms['flywheel']['qualified']}/288 qualified. Conventional adaptive cache: {arms['cache']['qualified']}/288, with exactly the same outcomes and structural costs. Authored expert workflow: {arms['expert']['qualified']}/288, at greater counted cost. Cache and flywheel share one policy and serve as an equivalence control. No advantage over conventional adaptive reuse was established."
data['summary']['cost_scope']=f"Declared structural units are a standardized accounting proxy, not CPU instructions, energy or money. The displayed wall times sum complete epoch execution and persistence; the whole primary process took {data['summary']['wall_ms']/1000:.2f} seconds. Human/model-assisted authoring and setup labor are unmeasured. The recorded process is a bounded source extension, not an installed persistent service."
target=companion/'results/viewer-data.json'
target.write_text(json.dumps(data,ensure_ascii=False,separators=(',',':'))+'\n')
print(json.dumps({'file':str(target),'bytes':target.stat().st_size,'observations':len(data['observations']),'generations':len(data['generations']),'fault_cases':len(data['failures']['cases'])}))
