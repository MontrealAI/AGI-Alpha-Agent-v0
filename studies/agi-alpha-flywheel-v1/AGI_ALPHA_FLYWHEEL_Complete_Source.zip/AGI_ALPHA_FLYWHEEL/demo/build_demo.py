from pathlib import Path
import json, hashlib, argparse
parser=argparse.ArgumentParser(); parser.add_argument('--data',default='../companion/results/viewer-data.json'); parser.add_argument('--kernel',default='../companion/vendor/docs/assets/transformational-intelligence/source-understanding.mjs'); parser.add_argument('--output',default='index.html'); args=parser.parse_args()
root=Path(__file__).resolve().parent
kp=(root/args.kernel).resolve(); kernel=kp.read_text(); data_path=(root/args.data).resolve(); data=json.loads(data_path.read_text()) if data_path.exists() else {'schema':'flywheel-viewer/v1','status':'awaiting-recorded-data','generations':[],'arms':[],'failures':[]}
data['kernel_sha256']=hashlib.sha256(kp.read_bytes()).hexdigest()
companion=root.parent/'companion'
module_paths=[companion/'kernel.mjs',*sorted((companion/'vendor').rglob('*.mjs'))]
modules={p.relative_to(companion).as_posix():p.read_text() for p in module_paths if p.is_file()}
manifest={name:hashlib.sha256(value.encode()).hexdigest() for name,value in sorted(modules.items())}
data['demo_source_manifest']=manifest
data['demo_bundle_manifest_root']=hashlib.sha256(json.dumps(manifest,sort_keys=True,separators=(',',':')).encode()).hexdigest()
data['demo_source_hash']=data.get('freeze',{}).get('sourceHash',data['demo_bundle_manifest_root'])
payload=json.dumps(data,ensure_ascii=False,separators=(',',':')).replace('<','\\u003c').replace('\u2028','\\u2028').replace('\u2029','\\u2029')
module_payload=json.dumps(modules,ensure_ascii=False,separators=(',',':')).replace('<','\\u003c').replace('\u2028','\\u2028').replace('\u2029','\\u2029')
page=(root/'template.html').read_text().replace('__FLYWHEEL_DATA__',payload).replace('__FLYWHEEL_MODULES__',module_payload).replace('__UPSTREAM_KERNEL__',kernel).replace('__VIEWER_SCRIPT__',(root/'viewer.js').read_text())
(root/args.output).write_text(page)
print(json.dumps({'output':str(root/args.output),'bytes':len(page.encode()),'kernel_sha256':data['kernel_sha256'],'data_status':data.get('status','recorded')}))
