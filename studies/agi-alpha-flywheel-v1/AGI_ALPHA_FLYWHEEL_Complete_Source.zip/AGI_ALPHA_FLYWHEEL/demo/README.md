# AGI ALPHA FLYWHEEL — browser companion

Open `index.html` in a current desktop or mobile browser. The file contains its own styles, recorded evidence and
source modules. It makes no network, model-provider or financial request during computation. The project links open
external public pages only if you choose them.

## Two clearly labeled modes

**Recorded evidence:** choose **Start the recorded stream**, step through the six generations, inspect any of the eight
registered streams, and compare the four workflows. The view preserves exact generation records, failed candidates,
declared costs and the separate WORLD, POLICY, PROOF and AUTHORITY boundaries. Playing the timeline is a replay; it does
not rerun the confirmatory experiment.

**Show a rejected candidate** jumps to the recorded failed qualification. The comparison view displays the exact
conventional-cache tie, expert lead and the registered archive-cleared reconstruction test. Its generation-by-generation
cost table includes both the reuse saving and the later crossover where rebuilding wins at equal observed quality.
Recovery shows all 16 fault cases and separately counts the semantic verification computation used to validate a saved
receipt. The load table retains the measured 66/96 quality in every process-count condition. The complete authoring and
setup intervention ledger is included in the cost-evidence drawer; unknown labor and inference costs remain unknown.

**Fresh computation:** choose **Try a fresh check**. **Run a fresh bounded stream** executes the packaged research
adapter through the original `createWorkbench(adapters)` source interface. It uses a new demonstration seed, six
requirement epochs and a limit of 500,000 declared structural units. **Stop at the next checkpoint** requests a bounded
stop. Download the fresh result and completed packs to retain them. The research adapter is a source extension;
installed native operation and an unattended service are separate qualifications.

The smaller **Run a fresh check** action invokes the unchanged upstream source-understanding module on an authored
public example. Change the clause limit or import a valid public, nonpersonal `source-document/v1` JSON file. The
source-template download provides the complete input schema. All five methods and the raw output remain inspectable.
Incorrect or incomplete prerequisite annotations can still produce misleading structural success; the interface states
that limit beside the result.

## Runtime and persistence

The fresh process runs in this browser tab. Closing the tab stops it. The page does not start a daemon, schedule future
work, contact a provider, create credentials or grant production authority. Downloads preserve completed evidence;
the page does not silently upload it. A context without WebCrypto refuses the source-extension run; no insecure
substitute is used.

EN/FR changes the interface guidance. Exact source records and research data retain their original keys and wording.

## Rebuild from the research package

From the package root, after the recorded experiment, fault cases, ablations and load study exist:

```sh
python3 demo/collect_evidence.py
python3 demo/build_demo.py
```

The builder reads only packaged files. It embeds the exact source-module texts and hashes, resolving local imports to
browser Blob module URLs. The browser checks each original module's SHA-256 before importing it. Import-specifier
resolution is packaging; it does not alter the selector logic or confer authenticity on an unauthenticated package.
The independent source checks and main package manifest remain authoritative.

The accompanying browser QA record covers actual local-file computation, downloads, keyboard navigation and narrow
EN/FR viewports. It does not establish a public HTTPS deployment.
