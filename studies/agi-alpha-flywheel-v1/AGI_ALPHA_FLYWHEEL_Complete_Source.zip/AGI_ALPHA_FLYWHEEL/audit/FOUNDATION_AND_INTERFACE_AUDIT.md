# AGI ALPHA FLYWHEEL: foundation and interface audit

Observed on 24 October 2026. This is a read-only source audit, not a contract audit, an installed-product test, a deployment verification, or an authority decision. The new experiment must report its own execution separately.

## 1. Exact source basis

| Repository | Inspected main commit | Tree |
|---|---|---|
| Alpha | `787bc547f8c44854931b316d7286b8bc9f9c8bba` | `fddf8462e4508462e2bb0a591a1e940aa9da97ee` |
| Manager | `c5958eae872458c2f3cac48fea0b4bbfadc6ac6c` | `0c7022fd0d70ab12803869493917c130497aa6d4` |
| Jobs v0 | `2e234ab9b8f44eda0a2525b3ce75fc87ee7a4c7f` | `e738f07ab877bf95931dffd83fa1aba3b9b0600a` |
| Fleet Linux | `45759fb096faf8988f58ae5ea71248d0f35a97c7` | `71a0ab1f0d2784ba552d0126903bd31d60262313` |

The public coordination issue is [Alpha #4850](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/issues/4850). Its original-action decision record [6386746278](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/issues/4850#issuecomment-6386746278) retains the original Harness review/merge restrictions and Fleet review restriction and unresolved findings. This study neither executes those held targets nor grants their disposition. The existing operating-flywheel owner [6387479985](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/issues/4850#issuecomment-6387479985) owns a finite timed driver around the unheld source-clause campaign path. The research lane must not create a competing scheduler or adopt held enterprise/Harness code.

## 2. Foundations: what is inherited and what the new paper must add

All Alpha paths below are bound to the exact Alpha commit in section 1. File digests are in `source-manifest.json`. The audit reviewed abstracts, construction and succession mechanisms, evaluation rules, limitations and implementation interfaces. It does not rerun or independently validate the predecessors' experiments.

| Foundation | Substantive inherited result or rule | Consequence for this study |
|---|---|---|
| Transformational Intelligence: Learning to Change the Game (`docs/Transformational_Intelligence.tex`) | Makes the problem formulation editable while holding authorized purpose and an outcome bridge fixed. Its causal example has a matched unrestricted planner. Appendix B separates score gain from calibrated outcome gain and accounts for repeated attempts. | Frozen task/quality/authority rules remain outside candidate control. Do not infer unique intelligence from beating a restricted baseline. A structural score is not automatically an externally useful outcome. |
| Out-Learn: Change What You Need to Know (`docs/Out_Learn.tex`) | Constructs measurement schedules and learns calibration; charges both calibration and later use. A different calibration becomes preferable beyond nineteen uses in its supplied study. | Measure the investment and crossover, not only cheap post-acquisition uses. A future requirement can require recalibration or replacement. |
| Out-Think: Inventing the Space of Reasoning (`docs/Out_Think.tex`) | A representation can answer current questions but fail a permitted next operation. Its finite example shows that preserving an obsolete internal label can require more states than replacing the representation. | Retention cannot mean keeping every internal artifact. Test changed requirements, replacement and retirement. Historical proof is not proof of a changed operation. |
| Out-Design: Creating the Freedom to Transform (`docs/Out_Design.tex`) | A checked equivalent realization releases usable capacity; where capacity is released matters. A scalar computational saving does not by itself make a desired transition reachable. | Record which asset changes the next mission's feasible choices and whether resource savings are actually available under the operational bottleneck. |
| Out-Strategise: Constructing the Conditions of Success (`docs/Out_Strategise.tex`) | Couples information acquisition with construction of a completion that works across unresolved possibilities; a stricter successor purpose invalidates an old winning route and abstraction. | Preserve unknowns, full scope and cheaper conventional alternatives; do not force every successor to inherit. |
| Out-Execute: Constructing the Conditions of Completion (`docs/Out_Execute.tex`) | Builds executable boundary-value contracts, not merely cached answers. Equivalent boundaries can stop recomputation while current witnesses and acceptance change. Its strong fixed-certificate control remains competitive. | Distinguish executable method reuse from response caching. Charge current validation, and allow strong conventional caching/adaptation. |
| Out-Evolve: Building the Means of Discovery and Production (`docs/Out_Evolve.pdf`) | Defines a budget-conditioned frontier of qualified purposes. Its proposed industrial succession requires retained means to construct a genuinely different accepted capability; technical savings and feasible cost recovery are distinct. | Report frontier/coverage under full cumulative cost; separate bounded software execution, physical capability and observed demand. The supplied-theory examples do not constitute an operating enterprise. |

`docs/Out_Evolve.tex` is a 99-line wrapper whose chapter files are absent from the inspected tree. The complete public PDF was retrieved and its text extracted for substantive review. No claim that this wrapper alone is a compilable predecessor package is made.

### Difference from the preferred Harness detector edition

The inspected `docs/papers/successor-omega-harness-detector-v1.pdf` is the preferred 28-page edition. Its comparison must remain unchanged: per 96-request scenario, each arm qualifies 96 intervals and resolves 78 decisions; counted rational calls are enterprise 32,675, conventional cached 32,675, rebuild 37,422, and direct expert cached 32,583. All 768 primary/parallel invocations completed across eight scenarios. The 50,000-call/160-new-read primary budget yields equal coverage for all arms. This is a conventional tie and an expert advantage, not special superiority of an enterprise controller. Prefix projections are not separately executed stopped campaigns.

The hidden-gain failure also remains unchanged. Observations `(80,140,200,20,60)` are compatible both with signals `(50,100,150)` at unit gain and with `(46,92,138)` at gain `25/23`. The runtime reports mean 100 and interval `[98,102]`, which misses the second world's true mean 92. Its dark references cannot identify the common multiplicative error. Five truth violations remain in the amended challenge evidence. Direct construction of the child without a parent costs 426 counted calls rather than 474 with ancestry, so lineage itself is not a saving.

The new paper's distinct object is recurrent operation, retention/retirement and net coverage across a stream of changing missions. It should not replace, rerun under a new name, or silently repair the detector study.

## 3. Actual permitted Alpha path

The supported operator is the native `alpha-agent` profile documented in `docs/agent/SUCCESSOR_OPERATIONS.md`. `backend/agent_manager.py` and `ALPHA_CYCLE_SECONDS` belong to the preserved research orchestrator; a timer value is not a qualified continuously operating service. A browser replay, a source-level experiment, an installed runtime and a production service are separate evidence levels.

Within `alpha_factory_v1/core/runtime/successor/`:

- `transformation.py` supplies `IntentCharter`, `SourceDocument`, the closed `SelectionProgram`, `execute_selection`, `inspect_summary` and `DiscoveryLoop`.
- `DiscoveryLoop.create/approve/step/confirm/envelope/import_history` bind a campaign to charter, source, operator and instrument identities. Phases retain attempts, costs, a frozen finalist and terminal comparisons. Imported history does not import current approval.
- `campaign_experiment.py` supplies `CampaignExperiment.create/approve/train/confirm`, whole-campaign training and confirmation, parent/child reservations, code binding and journal-based reconciliation. `PolicyStudy` explicitly fixes `archive_access` to `none`: its native transfer is discovery-policy selection, not reuse of an acquired executable archive. Merely running it does not establish capability accumulation.
- `transformation_library.py` supplies `TransformationLibrary.archive/review/control/route`, versioning, explicit local promotion/retirement/rollback and source/scope/cost filtering. `route()` returns `authority_granted=false`, `execution_approved=false`, `spending_approved=false`. Local routing is not execution authorization.
- `store.py` provides the retained Journal used by these components. The present audit did not execute its recovery tests.

### Seven stages as inspectable operations

This is a mapping of the paper's vocabulary to concrete operations, not a claim that seven independently learned agents exist.

| Stage | Source operation and inspectable output |
|---|---|
| Identify | Select a permitted mission from the finite frozen stream; create its `IntentCharter` and normalized `DiscoveryRequest`. Record selection, authority, budget and reason. |
| Out-Learn | Validate `SourceDocument` claims and supplied prerequisite graph; record diagnostics and observed failures. The annotations are supplied, not autonomously inferred truth. |
| Out-Think | Construct/compare `sequence` and `argument-graph` representations; retain assumptions and `TransformationWitness`. |
| Out-Design | Trusted `OperatorRegistry` proposes `SelectionProgram` data; generated programs cannot modify the charter, checker or external environment. |
| Out-Strategise | Compare admissible candidates and conventional alternatives under declared budgets; freeze one exact candidate and retain the incumbent on ties/no gain. |
| Out-Execute | Execute the frozen selector with charges, emit exact selected source clauses and references, and recompute structural support with `inspect_summary`. |
| Out-Evolve | Confirm against fresh documents; retain rejected and no-gain outcomes. A separately authorized retention operation can archive the method and its scope; subsequent requests must actually consume it for an inheritance claim. |

The closed selector language admits representations `sequence` or `argument-graph` and productions `lead`, `weighted`, `audit-after` or `closure-search`. Closure search enumerates bounded subsets and maximizes supported weight. The comparator `unrestricted-exact-search` uses the same fully enabled graph/closure language; it can match a discovered closure selector. This is finite program selection within a supplied language, not learned general code synthesis.

The summary checker establishes support according to supplied weights/dependencies. It does not prove the underlying source statements true, certify annotation completeness, or measure human reader understanding. Those are explicit WORLD/measurement premises.

### WORLD, POLICY, PROOF and AUTHORITY

| Plane | Inspectable representation in this source path | What cannot be inherited automatically |
|---|---|---|
| WORLD | Exact source documents, supplied weights/prerequisite DAG, provenance, and declared model assumptions | Truth or completeness of changed annotations; a historical dependency graph cannot certify changed source meaning. |
| POLICY | Intent charter, permitted local actions, fixed artifact/length requirements, operator language, budgets and comparison rule | Permission to relax original quality, spend money, choose a new evaluator, or broaden the mission. |
| PROOF | Source/operator/instrument hashes, frozen finalist, retained attempts, fresh confirmation results and scope-bound local reviews | Current validity under a changed source, model, instrument or dependency. |
| AUTHORITY | Exact local campaign approval, parent-child study binding, STOP state, distinct configured local review/control records where actually used | Production permission, wallet authority, publication approval or external review independence. `import_history` explicitly records `active_permission:null`, `active_successor:null`, `historical-only`, and `reapproval_required:true`. |

The existing library keeps retired entries and audit history; its bound is 128 entries and 4,096 distinct operation identities, and capacity exhaustion refuses further writes. It does not demonstrate indefinite storage cleanup or long-run retention optimization. A study should report inactive/audit storage separately from the active capability inventory rather than imply that retirement deletes all costs.

## 4. Four-repository interface map

| Product | Inspected function/interface | What this study can truthfully say |
|---|---|---|
| Alpha | `DiscoveryLoop`, `CampaignExperiment`, `TransformationLibrary`; source refs above | Reused source interfaces where the experiment's own receipts show actual calls. Installed/released status must be separately tested. |
| Manager | `scripts/integrations/discovery-lab-work-request.mjs`: `discoveryLabReceiverCapabilities`, `inspectDiscoveryLabWorkRequest`, `receiveDiscoveryLabWorkRequest` | Source-inspected local admission on `manager-usdc`/`USDC6`. No submission; external execution unprovisioned; settlement not connected; authority none. |
| Jobs v0 | `integrations/alpha-agent/discovery-lab-work-request.mjs`: same three API names | Source-inspected local admission on `jobs-agialpha`/`AGIALPHA18`. The currency and branch are distinct from Manager; no shared balance or conversion. |
| Fleet Linux | `fleet/packages/AGI_Agent/successor/project.mjs`: `prepareCustomProject`, `inspectRequest`, `compileRequest`, `validateSidecarProject`, `checkReturnedWork` | Source-inspected bounded public computer-work project/receipt seam. Result fields include `independentController:'UNVERIFIED'`, `qualification:'NOT_RUN'`, `authority:'none'`, `payment:'unfunded'`. No installed Fleet experiment was run by this audit. |

The common request schema is `successor-discovery-work-request/v1`, with six stage discriminators, exact mission/revision/purpose/charter/model/source/evaluator bindings, resource vector, input artifacts and digest. Source contract validation accepts only `executionMode:'synthetic-local'`, `capBaseUnits:'0'` and `status:'DRAFT_NOT_SUBMITTED'`. A successful import is neither capability acceptance nor authority.

Current source-pin observations must not be silently combined: Manager's `config/discovery-release-alpha-source-v1.json` names Alpha `61532fb82621a065e668fd11e57289dcfb65c67b`; Jobs' `config/discovery-installed-alpha-v1.json` names Alpha `031bdb5d055c8bad896daa076baea2b5e17b242c`. These static configs include their own qualification labels and do not admit arbitrary newer Alpha sources. This study does not repin them or infer a connected four-installed tuple.

Exact raw copies of the four inspected interface files are in `source-interfaces/`; `retrieval-records.json` binds them to public URLs, Git blob IDs, SHA-256 and sizes. They are evidence copies, not standalone runnable modules or installed adapters.

## 5. Five Alpha contracts and applicable utility

Inspected sources: `contracts/ascension/` at Alpha `787bc547...`, plus `contracts/v2/Constants.sol`. The potential functions below are conditional integration uses, not exercised contract calls.

| Contract | Verified relevant functions | Practical role if separately authorized and integrated | This experiment |
|---|---|---|---|
| `AscensionAccess` | `register`, `setAdmission`, `owns`, `admitted`, `eligible` | Live ENS/wrapped-owner checks plus expiring admission. Registration is not enough: eligibility also needs admission and current ownership. | Source inspection only. No registration/admission or authority inherited. |
| `NovaSeed` | `seal`, `plan`, `creatorOf`; `genomes` | ERC-721 binds a capsule hash, immutable plan root, evidence hash and optional parent. `seal` requires business eligibility and parent ownership when supplied. | Source inspection only. No NFT minted; local artifact hashes are not on-chain seeds. |
| `AscensionRiskOracle` | `deposit`, `withdraw`, `isValidator`, `openReview`, `attest`, `green`, `setJobAvailability`, `lockForJob`, `releaseFromJob` | AGIALPHA stake; expiring owner-bound risk attestation; validator capacity reservation. Risk voting checks distinct addresses from owner/creator but cannot establish organizational independence. | Source inspection only. No stake, attestation or green status. |
| `AscensionJobMarket` | `post`, `postFromSeed`, `bid`, `award`, `submit`, `validate`, `timeout`, `claimRefund`, `terminal` | AGIALPHA escrow/bids/collateral; result-hash-bound committee votes; settlement or refunds; bounded execution/review windows. | Source inspection only. No commissioned marketplace work or settlement. |
| `AscensionMark` | `open`, `quote`, `buy`, `sell`, `transferLots`, `bloom`, `route`, `collect`, `close`, `reclaim` | Reversible funding lots before bloom; then plan-proof-restricted treasury routing and residual capital return. Funding authority and economic suitability are separate from technical acceptance. | Source inspection only. Unsigned, unfunded, disconnected. |

`AscensionToken` is an inherited helper, not a sixth deployed contract in the five-address campaign. It selects canonical AGIALPHA at `0xA61a3B3a130a9c20768EEBF97E21515A6046a1fA`, requires 18 decimals, checks exact deposits/payouts and verifies burns. JobMarket uses the token for bounty escrow, agent collateral, worker/validator payouts and specified burns; RiskOracle uses it for validator stake; Mark uses it for reserves and funding lots. Access and NovaSeed do not themselves establish productive value or demand. These facts explain applicable token utility without claiming that token scarcity, issuance or price measures capability growth.

The inspected `docs/agent/CURRENT_MAINNET_DEPLOYMENT.md` records five October 18 addresses and historical source `c0fc5217e364a39a4cd123d17a8317c06b80f820` at observed block 26220072. It explicitly says activation/public funding are not approved and that the trusted-provider observation is not a global authority audit. This audit made no RPC call and did not refresh those observations. Main source inspection is not deployed-byte verification.

### Execution-level truth table for the audit

| Level | Performed here? | Permitted inference |
|---|---|---|
| Public source and document inspection | Yes | Specific functions, static checks, source identities and documented historical boundaries |
| Simulated contract logic | No | None |
| Local EVM calls | No | None |
| Installed Manager/Jobs/Fleet adapters | No | None |
| Current mainnet readback | No | None beyond citing historical documents as historical |
| Real settlement or financial action | No | None |

## 6. Closest primary literature and defensible contribution

DreamCoder already learns reusable symbolic libraries and search policies; Voyager already combines an automatic curriculum with an executable skill library. Neither idea should be claimed as newly invented by the flywheel paper. A useful contribution here is a source-bound recurring implementation and an experiment that accounts for acquisition, current checking, retention/retirement, failures and interventions under a shared cumulative budget. Establish this contribution with executed receipts rather than terminology.

Kapoor et al., *AI Agents That Matter*, motivate joint cost/accuracy evaluation, adequate held-out tasks and reproducible comparisons. Zhang et al.'s negative-transfer survey gives the established term for harmful reuse. Dwork et al.'s holdout-reuse paper explains why repeated adaptive access to a confirmation set needs its own method; a local fixed bank does not become an independent population sample merely because candidate code cannot inspect it. RIFL is relevant background for durable operation identities and retained replies: local duplicate-control tests do not establish distributed exactly-once semantics.

Bibliographic candidates and source URLs are in `references-audit.bib`. ArXiv versions are preferred where available. These citations support background and comparison design, not this study's empirical results.
