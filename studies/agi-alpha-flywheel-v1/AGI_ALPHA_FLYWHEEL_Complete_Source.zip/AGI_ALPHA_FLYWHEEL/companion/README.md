# AGI ALPHA FLYWHEEL research companion

This bounded source extension uses the released `createWorkbench(adapters)` SDK and eight unchanged upstream modules at `787bc547f8c44854931b316d7286b8bc9f9c8bba`. It executes synthetic annotated source-summary work, retains typed selector recipes and tests new requirements. It uses no account, wallet, API key, model service, native identity credential or network call.

## Reproduce

Tested runtime: Node **24.22.1**, Linux x86_64. No npm dependencies are required. Python **3.12.14** is used for the separate standard-library evidence checker and manuscript utilities. The package includes exact vendored source and a manifest; internet access is unnecessary after obtaining the package.

From this directory:

```sh
node run.mjs reproduce my-fresh-run
python3 ../review/independent/review_results.py my-fresh-run --output my-fresh-review.json
```

The first command verifies the frozen source and task identities, then starts all eight finite paired streams. Each stream automatically selects the next registered requirement and carries all seven named stages through the existing SDK. It stops at its finite manifest, budget or expiry; a closed process does not continue operating. Files are written only under the new output directory. Existing output is never overwritten.

The final checker command's exact CLI is documented in `../review/independent/REVIEW_SCOPE.md`. A separate reference checker validates output semantics, receipts and accounting; it is source-aware same-session review, not an independent institution.

An interruption can be reconciled using the exact old directory:

```sh
node run.mjs resume my-fresh-run
```

Saved immutable packs are inspected against exact source, input and output semantics. Already committed missions issue no new result. Verification recomputes pure deterministic work and records its additional units/time separately. An uncommitted interrupted mission may be recomputed. Neither behavior is a claim of exactly-once CPU execution. The explicit resume invocation grants only a new finite local research permit, never production authority. A changed source or changed request refuses the prior identity.

## Inspect ancillary checks

```sh
node run.mjs faults my-fault-run
node run.mjs load my-load-run
node run.mjs ablations my-ablation-run
```

Faults cover actual new-process recovery, lost acknowledgement after committed output, duplicate requests, changed inputs, changed dependency bytes in a disposable source copy, invalid and self-consistent forged receipts, budget exhaustion, permit expiry, STOP, WAIT, earlier-recipe reuse and rejected-descendant recovery. The load command uses 1, 2 and 4 actual Node worker processes, not promise concurrency disguised as CPU parallelism.

The ablation command intentionally reads the authoritative recorded `results/` for stream 0. It tests component removal, a newly digested equivalent recipe, and whole-stream reconstruction with the archive cleared before each generation. These tests do not train or replace the frozen primary candidate.

## Interpret the evidence

The primary denominator is **36 registered fresh tasks per stream** and **288 per arm**. Missing tasks after a budget stop count zero. A qualifying output must respect the clause cap, preserve every prerequisite of its selected clauses and achieve exact optimal supported weight for the supplied graph. This does not establish source truth, reader understanding or real customer demand.

`flywheel` and `cache` receive the same grammar, information, caching, retrieval and adaptation. `frozen` is the same runtime with no acquired recipe, a secondary intervention comparator. `expert` is an authored analytical router, not a measured human-expert labor experiment. All inspection/search/validation tariffs are explicit; standardized structural units are a logical accounting model, not CPU instructions or money. Full process wall and CPU measurements and storage bytes are reported separately. Human/model-assisted authoring costs remain unknown.

An accepted recipe is a typed selection from a supplied closed grammar. It can be executed on a later mission, but it is not a new general algorithm. Every output is rechecked. `activeProof` and `activeAuthority` remain empty. The signed native runtime, preserved research scheduler, browser source demo and any operating service are separate scopes.

## Files

- `protocol.json`, `tasks.json`, `freeze.json`: frozen criteria, finite stream and exact-source commitments.
- `kernel.mjs`: browser-compatible research adapter and retained recipe operations.
- `run.mjs`: finite research experiment, immutable checkpoint reconciliation, faults and real process load.
- `vendor/`, `upstream-manifest.json`: unchanged upstream dependency closure.
- `results/`: original raw packs, observations, per-operation cost ledger, generations, process timing and summary.
- `faults/`, `load/`, `ablations/`: original ancillary measurements and retained negative results.
- `development-*`: excluded development records, including the original transport error and pre-freeze design corrections.

The `freeze` action is for research authors preparing a genuinely new protocol before observing outcomes. Do not overwrite or recreate the supplied freeze and describe it as the original study.
