#!/usr/bin/env python3
"""Batch adapter for independent verification of frozen research output packs.

The mathematical core is in verify.py. This adapter recomputes the published
summary from exact unsigned packs, reconciles flattened raw exports when
present, and preserves the eight whole-stream paired observations.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path

from receipt_verify import verify_pack
from verify import COST_FIELDS, LIMITS, load_jsonl, verify_cost_events, verify_retention, verify_stream


def canon(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def review(directory: Path, expected_streams: int = 8) -> dict:
    summary_path = directory / "summary.json"
    summary = json.loads(summary_path.read_text())
    source_hash = summary["sourceHash"]
    budget = summary["budget"]
    pack_paths = sorted((directory / "packs").rglob("*.json"))
    errors = []
    packs = defaultdict(list)
    pack_checks = []
    input_hashes = {"summary.json": sha(summary_path)}
    protocol_path = directory.parent / "protocol.json"
    tasks_path = directory.parent / "tasks.json"
    freeze_path = directory.parent / "freeze.json"
    protocol = json.loads(protocol_path.read_text()) if protocol_path.exists() else {}
    freeze = json.loads(freeze_path.read_text()) if freeze_path.exists() else {}
    for path, field in ((protocol_path, "protocol_sha256"), (tasks_path, "tasks_sha256")):
        if not path.exists() or sha(path) != summary.get(field) or sha(path) != freeze.get(field):
            errors.append(f"frozen {field} differs from exact input bytes")
        elif path.exists():
            input_hashes["../" + path.name] = sha(path)
    if freeze.get("sourceHash") != source_hash:
        errors.append("summary source hash differs from frozen source")
    if protocol.get("primary_budget_per_stream") != budget:
        errors.append("primary budget differs from frozen protocol")
    if freeze_path.exists():
        input_hashes["../freeze.json"] = sha(freeze_path)
    for path in pack_paths:
        pack = json.loads(path.read_text())
        evidence = pack["result"]["evidence"]
        check = verify_pack(pack, source_hash)
        check["path"] = str(path.relative_to(directory))
        check["file_sha256"] = sha(path)
        pack_checks.append(check)
        errors.extend(f"{check['path']}: {error}" for error in check["errors"])
        packs[(evidence["stream"], evidence["arm"])].append(pack)
        input_hashes[check["path"]] = check["file_sha256"]
    expected_keys = {(stream, arm) for stream in range(expected_streams)
                     for arm in ("flywheel", "cache", "frozen", "expert")}
    if set(packs) != expected_keys:
        errors.append("pack stream/arm set differs from registered Cartesian product")
    published_streams = {(row["stream"], row["arm"]): row for row in summary.get("streams", [])}
    if set(published_streams) != expected_keys:
        errors.append("summary stream/arm set differs from registered Cartesian product")
    stream_checks = []
    results = {}
    flat_observations = []
    flat_events = []
    for key, group in sorted(packs.items()):
        group.sort(key=lambda pack: pack["result"]["evidence"]["epoch"])
        generations = []
        observations = []
        events = []
        for pack in group:
            raw = pack["result"]["evidence"]
            generation = {field: value for field, value in raw.items()
                          if field not in {"observations", "cost_events"}}
            generation["packDigest"] = pack["integrityDigest"]
            generations.append(generation)
            observations.extend(raw["observations"])
            events.extend(dict(event, stream=key[0], arm=key[1], epoch=raw["epoch"])
                          for event in raw["cost_events"])
        if not generations:
            errors.append(f"stream {key}: no generation")
            continue
        published = published_streams.get(key, {})
        result = {"stream": key[0], "arm": key[1], "budget": budget,
                  "spent": generations[-1]["spent"], "retained": generations[-1]["retained"],
                  "generations": generations, "observations": observations,
                  "qualified": sum(generation["coverage"] for generation in generations),
                  "requested": 36, "state": published.get("state")}
        checked = verify_stream(result)
        checked["retention"] = verify_retention(result, source_hash)
        checked["cost_events"] = verify_cost_events(result, events)
        checked["errors"].extend("retention: " + error for error in checked["retention"]["errors"])
        checked["errors"].extend("cost_events: " + error for error in checked["cost_events"]["errors"])
        for field in ("qualified", "requested", "spent"):
            if published.get(field) != checked[field]:
                checked["errors"].append(f"published stream {field} differs from independent recomputation")
        if published.get("costs") != checked["cost_components"]:
            checked["errors"].append("published stream cost categories differ from raw events")
        if published.get("active_capabilities") != len(result["retained"]):
            checked["errors"].append("published active inventory differs from final retained set")
        checked["pass"] = not checked["errors"]
        errors.extend(f"stream {key}: {error}" for error in checked["errors"])
        stream_checks.append(checked)
        results[key] = result
        flat_observations.extend(observations)
        flat_events.extend(events)
    # Full-cost summaries include setup, validation, retention, maintenance,
    # routing and runtime charges. Per-output cumulative snapshots are not summed.
    arms = {}
    for arm in ("flywheel", "cache", "frozen", "expert"):
        group = [item for item in stream_checks if item["arm"] == arm]
        decisions = Counter(generation["decision"] for (stream, name), result in results.items()
                            if name == arm for generation in result["generations"])
        arms[arm] = {"qualified": sum(item["qualified"] for item in group),
                     "requested": 36 * expected_streams,
                     "total_units": sum(item["spent"] for item in group),
                     "counts": dict(sorted(decisions.items())),
                     "cost_components": {field: sum(item["cost_components"][field] for item in group)
                                         for field in COST_FIELDS}}
        published = summary.get("arms", {}).get(arm, {})
        for field in ("qualified", "requested", "total_units"):
            if published.get(field) != arms[arm][field]:
                errors.append(f"published arm {arm} {field} differs from independent recomputation")
        if "counts" in published and published["counts"] != arms[arm]["counts"]:
            errors.append(f"published arm {arm} decision counts differ from raw generations")
        if published.get("costs") != arms[arm]["cost_components"]:
            errors.append(f"published arm {arm} cost categories differ from raw events")
        expected_per_stream = [{"stream": item["stream"], "qualified": item["qualified"], "spent": item["spent"]}
                               for item in sorted(group, key=lambda item: item["stream"])]
        if published.get("per_stream") != expected_per_stream:
            errors.append(f"published arm {arm} per-stream rows differ from raw events")
    budget_curves = {}
    for arm in ("flywheel", "cache", "frozen", "expert"):
        budget_curves[arm] = []
        published = summary.get("budgetCurves", {}).get(arm, [])
        if [point.get("budget") for point in published] != protocol.get("secondary_budget_points"):
            errors.append(f"published arm {arm} budget points differ from frozen protocol")
        for point in published:
            counted = sum(row["qualified"] and row["cost_after"] <= point["budget"]
                          for row in flat_observations if row["arm"] == arm)
            if point.get("qualified") != counted:
                errors.append(f"published arm {arm} prefix {point['budget']} coverage differs")
            budget_curves[arm].append({"budget": point["budget"], "qualified": counted,
                                       "scope": "Descriptive cumulative-cost prefix, not a new policy run."})
    for name, collected in (("observations.jsonl", flat_observations), ("ledger.jsonl", flat_events)):
        path = directory / name
        if path.exists():
            exported = load_jsonl(path)
            if Counter(map(canon, exported)) != Counter(map(canon, collected)):
                errors.append(f"{name} flattened export differs from exact packs")
            input_hashes[name] = sha(path)
    pair_reports = {}
    for comparator in ("cache", "frozen", "expert"):
        pairs = []
        for stream in range(expected_streams):
            primary = results.get((stream, "flywheel"))
            other = results.get((stream, comparator))
            if not primary or not other:
                continue
            primary_rows = {row["mission_id"]: row for row in primary["observations"]}
            other_rows = {row["mission_id"]: row for row in other["observations"]}
            common = set(primary_rows) & set(other_rows)
            information_equal = all(primary_rows[name]["document"] == other_rows[name]["document"]
                                    and primary_rows[name]["max_clauses"] == other_rows[name]["max_clauses"]
                                    for name in common)
            if not information_equal:
                errors.append(f"stream {stream}: {comparator} received different matched terminal information")
            same_output = set(primary_rows) == set(other_rows) and all(
                all(primary_rows[name][field] == other_rows[name][field]
                    for field in ("method", "selected", "structural_score", "qualified", "cost_before", "cost_after", "cost_breakdown"))
                for name in common)
            pair = {"stream": stream, "qualified_difference": primary["qualified"] - other["qualified"],
                    "unit_difference": primary["spent"] - other["spent"],
                    "matched_terminal_information": information_equal,
                    "same_output_and_cost": same_output}
            if comparator == "cache" and (pair["qualified_difference"] != 0 or pair["unit_difference"] != 0 or not same_output):
                errors.append(f"stream {stream}: conventional-cache equivalence control does not tie exactly")
            pairs.append(pair)
        qdiff = [item["qualified_difference"] for item in pairs]
        cdiff = [item["unit_difference"] for item in pairs]
        pair_reports[comparator] = {"pairs": pairs,
                                   "qualified_difference_mean": sum(qdiff) / len(qdiff) if qdiff else None,
                                   "qualified_difference_range": [min(qdiff), max(qdiff)] if qdiff else None,
                                   "unit_difference_mean": sum(cdiff) / len(cdiff) if cdiff else None,
                                   "unit_difference_range": [min(cdiff), max(cdiff)] if cdiff else None,
                                   "interpretation": "Descriptive paired finite-stream results; no iid document-level inference."}
    return {"schema": "flywheel-independent-batch-review/v1", "pass": not errors,
            "errors": errors, "source_hash": source_hash, "budget": budget,
            "pack_count": len(pack_checks), "stream_arm_count": len(stream_checks),
            "observation_count": len(flat_observations), "cost_event_count": len(flat_events),
            "arms": arms, "paired_streams": pair_reports,
            "budget_curves": budget_curves,
            "pack_checks": pack_checks, "stream_checks": stream_checks,
            "input_hashes": input_hashes,
            "independence_limits": LIMITS}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("results", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--expected-streams", type=int, default=8)
    args = parser.parse_args()
    report = review(args.results, args.expected_streams)
    report["checker_files"] = {name: sha(Path(__file__).with_name(name))
                               for name in ("verify.py", "receipt_verify.py", "review_results.py")}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"pass": report["pass"], "packs": report["pack_count"],
                      "observations": report["observation_count"], "errors": report["errors"],
                      "output": str(args.output)}))
    return 0 if report["pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
