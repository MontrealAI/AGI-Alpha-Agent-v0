#!/usr/bin/env python3
"""Post-run consistency review of fault receipts and finite-load measurements.

This does not independently inject faults or reproduce timings. It reconciles
the retained observations, saved pack content, and arithmetic without running
the production implementation.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path

from receipt_verify import verify_pack
from verify import verify_cost_events


def close(a, b):
    return math.isclose(a, b, rel_tol=1e-12, abs_tol=1e-9)


def review(companion: Path) -> dict:
    errors = []
    fault_path = companion / "faults" / "failure_cases.json"
    load_path = companion / "load" / "load.json"
    faults = json.loads(fault_path.read_text())
    load = json.loads(load_path.read_text())
    cases = {case["name"]: case for case in faults["cases"]}
    expected_errors = {
        "changed-input": "DUPLICATE_REQUEST_CONFLICT", "changed-dependency": "SOURCE_DEPENDENCY_CHANGED",
        "invalid-receipt": "PACK_INTEGRITY", "self-consistent-invalid-receipt": "SEMANTIC_RECEIPT_INVALID",
        "self-consistent-task-swap": "RECEIPT_TASK_BINDING", "forged-retained-candidate": "CAPABILITY_BINDING",
        "expired-authority": "RESEARCH_PERMIT_EXPIRED", "STOP": "CANCELLED",
    }
    expected_names = set(expected_errors) | {"lost-acknowledgement", "duplicate-request", "process-restart",
                                            "exhausted-budget", "precommit-recovery", "WAIT", "rollback", "rejected-result-restart"}
    if set(cases) != expected_names or len(cases) != len(faults["cases"]):
        errors.append("fault case names are incomplete or duplicated")
    for name, expected in expected_errors.items():
        if cases[name].get("error") != expected:
            errors.append(f"fault {name}: error differs from declared expectation")
    if not faults.get("passed") or not all(case.get("passed") is True for case in cases.values()):
        errors.append("a recorded fault assertion did not pass")
    first = cases["lost-acknowledgement"]["first"]
    if first != {"error": "SIMULATED_ACKNOWLEDGEMENT_LOSS", "fresh_invocations": 1}:
        errors.append("lost acknowledgement first-commit record differs")
    recovery_records = [cases["lost-acknowledgement"]["recovery"], cases["duplicate-request"],
                        cases["process-restart"], cases["rejected-result-restart"]]
    for index, record in enumerate(recovery_records):
        if record.get("fresh_invocations") != 0 or record.get("verification_reexecutions") != 1 or record.get("verification_units", 0) <= 0:
            errors.append(f"recovery {index}: replay or verification-cost accounting differs")
    if cases["self-consistent-invalid-receipt"].get("nativeAccepted") is not True:
        errors.append("self-consistent receipt counterexample omitted native acceptance")
    if cases["exhausted-budget"].get("decision") != "STOP_BUDGET" or cases["exhausted-budget"].get("spent") != 2:
        errors.append("exhausted-budget outcome differs")
    if cases["precommit-recovery"].get("fresh_invocations") != 1:
        errors.append("precommit recovery did not record recomputation")
    if cases["WAIT"].get("waiting", {}).get("state") != "WAIT" or cases["WAIT"].get("ready", {}).get("state") != "READY":
        errors.append("WAIT/READY transition differs")
    rollback = cases["rollback"]
    if not set(rollback["reused_digests"]) <= set(rollback["prior_digests"]):
        errors.append("rollback reused an unlisted prior artifact")
    if rollback.get("proof") != [] or rollback.get("authority") != []:
        errors.append("rollback inherited proof or authority")
    stop = cases["STOP"]["partial"]
    stop_stream = {"stream": stop["stream"], "arm": stop["arm"], "budget": 500000,
                   "spent": stop["spent"], "generations": [stop]}
    stop_events = [dict(event, epoch=stop["epoch"]) for event in stop["cost_events"]]
    stop_check = verify_cost_events(stop_stream, stop_events)
    errors.extend("STOP cost: " + error for error in stop_check["errors"])
    if stop["observations"] != []:
        errors.append("STOP partial contains issued terminal outputs")
    changed = cases["changed-dependency"]["changed_file_sha256"]
    changed_files = [str(path.relative_to(companion / "faults")) for path in (companion / "faults" / "changed-source").rglob("*")
                     if path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest() == changed]
    if not changed_files:
        errors.append("changed dependency byte identity has no retained matching file")
    saved_pack_checks = []
    for relative in ("saved/s0-flywheel-g1.json", "interrupted/s0-flywheel-g2.json", "rejected/s1-flywheel-g5.json"):
        path = companion / "faults" / relative
        pack = json.loads(path.read_text())
        check = verify_pack(pack)
        check["path"] = relative
        saved_pack_checks.append(check)
        errors.extend(f"fault pack {relative}: {error}" for error in check["errors"])
        if relative.startswith("rejected/"):
            evidence = pack["result"]["evidence"]
            if evidence["decision"] != "REJECT_DESCENDANT" or evidence["selected"] != evidence["incumbent"]:
                errors.append("saved rejected descendant replaced incumbent")
    load_checks = []
    quality_by_task = None
    for case in load["cases"]:
        rows = case["results"]
        local = []
        count = len(rows)
        if count != 16 or {row["task"] for row in rows} != set(range(16)) or case["tasks"] != count:
            local.append("load task identities/count differ")
        quality = {row["task"]: row["qualified"] for row in rows}
        if quality_by_task is None:
            quality_by_task = quality
        elif quality != quality_by_task:
            local.append("per-task quality changes across load configurations")
        sums = {"qualified": sum(row["qualified"] for row in rows),
                "cpu_microseconds": sum(row["cpu_microseconds"]["user"] + row["cpu_microseconds"]["system"] for row in rows),
                "output_bytes": sum(row["output_bytes"] for row in rows)}
        for field, value in sums.items():
            if case[field] != value:
                local.append(f"load {field} total differs")
        ordered = sorted(row["latency_ms"] for row in rows)
        p50 = ordered[count // 2]
        p95 = ordered[min(count - 1, math.ceil(count * .95) - 1)]
        throughput = count * 1000 / case["wall_ms"]
        for field, value in (("p50_latency_ms", p50), ("p95_latency_ms", p95), ("throughput_tasks_per_second", throughput)):
            if not close(case[field], value):
                local.append(f"load {field} arithmetic differs")
        if case["requested"] != count * 6:
            local.append("load output denominator differs")
        if case["workers"] != case["actual_processes"]:
            local.append("reported process count differs from worker count")
        load_checks.append({"workers": case["workers"], "pass": not local, "errors": local,
                            "tasks": count, "qualified": sums["qualified"], "requested": count * 6,
                            "wall_ms": case["wall_ms"], "throughput_tasks_per_second": throughput,
                            "p50_upper_order_statistic_ms": p50, "p95_nearest_rank_ms": p95,
                            "cpu_microseconds": sums["cpu_microseconds"], "output_bytes": sums["output_bytes"]})
        errors.extend(f"load workers={case['workers']}: {error}" for error in local)
    if {case["workers"] for case in load["cases"]} != {1, 2, 4}:
        errors.append("load configurations differ from protocol")
    return {"schema": "flywheel-independent-operation-consistency/v1", "pass": not errors, "errors": errors,
            "fault_cases": len(cases), "recorded_fault_assertions_pass": all(case["passed"] for case in cases.values()),
            "recovery_verification_units": sum(record["verification_units"] for record in recovery_records),
            "interrupted_additional_units": stop["spent"], "stop_event_check": stop_check,
            "changed_dependency_matching_files": changed_files, "saved_pack_checks": saved_pack_checks,
            "load_checks": load_checks,
            "limits": ["Post-run arithmetic/receipt consistency review, not independent fault reinjection or repeated timing experiment.",
                       "Fresh mission issuance and deterministic verification re-execution are distinct; the latter consumes extra work.",
                       "Fault cost values here cover stated verification and interrupted work, not every authoring/debugging/failed-call overhead.",
                       "Load timings are single short finite batches with process startup and no queue-delay measurement; no sustained-service scaling claim.",
                       "Reported process counts and human-intervention fields originate from the same-session runner, not an external observer."]}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("companion", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    report = review(args.companion)
    report["checker_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    report["input_sha256"] = {relative: hashlib.sha256((args.companion / relative).read_bytes()).hexdigest()
                              for relative in ("faults/failure_cases.json", "load/load.json")}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"pass": report["pass"], "errors": report["errors"], "output": str(args.output)}))
    return 0 if report["pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
