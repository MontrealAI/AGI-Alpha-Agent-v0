# Independent arithmetic and receipt review — final docket

## Disposition

**The recorded primary outputs, costs and unsigned receipt bindings reconcile.**
Both the batch adapter captured by the original freeze and the explicitly
amended batch adapter passed: 192 generation packs, 1,152 terminal observations,
32 stream/arm trajectories and 140,388 raw charge events. The separately written
integer-mask evaluator confirmed every reported structural optimum, achieved
score and qualification decision. This is an arithmetic and provenance result
within the authored synthetic task model. It is not external certification,
semantic ground truth, production approval or evidence of commercial growth.

The primary source binding is
`d03406c0df742f269ca3d21e1ca973c2504e08d4303417dda4510652e71eb6db`.
The unchanged original freeze SHA-256 is
`95d3f19acabb33ee13cbb9dcc5b695ea14267de79ef984b7ebeb55c2a0621169`.

## Primary findings

The denominator is 288 tasks for each arm: eight complete, correlated
36-task streams. The resource limit is 500,000 declared logical units **per
stream**, with actual consumed units reported below. These are proxy tariffs,
not measured CPU instruction counts or full monetary costs.

| Arm | Qualified / requested | Total logical units | Units / qualified output |
|---|---:|---:|---:|
| Flywheel | 271 / 288 | 2,017,944 | 7,446.29 |
| Conventional cache | 271 / 288 | 2,017,944 | 7,446.29 |
| Fixed lead selector | 58 / 288 | 1,412,176 | 24,347.86 |
| Direct exact construction | 288 / 288 | 2,134,383 | 7,411.05 |

The conventional cache arm is an explicit equivalence control running the
same logical controller. Its outputs and logical costs match the flywheel
exactly in all eight paired streams; this is not two independently discovered
strategies coincidentally tying. The exact constructor attains more qualified
coverage at the primary budget, and also leads at every registered descriptive
budget-prefix point. The lower aggregate flywheel spending must not be presented
as better quality-adjusted productivity: its units per qualified output are
slightly higher here.

Flywheel minus exact-constructor qualified-count differences are
`[0, -3, -4, -6, -1, 0, -1, -2]`, with mean −2.125 and range −6 to 0.
The corresponding cost differences range from −37,209 to +49,146 logical units.
These are descriptive paired finite-stream results. The 288 tasks are not
treated as 288 independent samples, and no population superiority or inferential
confidence interval is asserted.

The flywheel's full charged categories reconcile to construction 406,382;
qualification 350,670; execution 206,861; validation 1,053,126; retention 144;
maintenance 103; routing 610; and runtime 48. Summing per-output cost snapshots
would double-count setup: those snapshots are cumulative within an epoch. The
review instead reconciles each raw charge once, then generation and stream
totals. Unmeasured authoring, human labor and some implementation overhead
remain outside the tariff and cannot be inferred to be zero.

Evidence: `primary-verification-frozen.json`,
`primary-verification-amended.json`.

## What actually persists

Across the 48 flywheel generations there are 16 admission actions, 31 incumbent
retentions and one descendant rejection. There are **four distinct capability
content digests**, not 16 unique new tools: identical method/source/creation-epoch
bodies recur across independent streams. These capabilities select existing
bounded executable recipes; this experiment does not demonstrate invention of
a new general programming language or unrestricted agent self-modification.

Of the 288 flywheel terminal outputs, 138 use an attached capability created in
an earlier epoch; 134 of those qualify. Another 96 use one created in the current
epoch, of which 89 qualify. The remaining 54 have no attached capability. A
nonnull capability digest alone therefore does not establish earlier-generation
inheritance. The independent tally resolves each digest to its creation epoch.

The active inventory never exceeds two records. Its largest canonical payload
is 789 bytes, but evidence files are much larger and continue accumulating over
the finite trace. No retirement event occurred in the primary run. Capacity
limits and stale-source rejection must not be described as empirically proven
infinite-history garbage collection or observed primary retirement.

Evidence: `lineage-verification.json`, `storage-retention-verification.json`.

## Causal interventions and a real liability

Component removal and archive clearing answer different questions. Forcing the
lead selector on all 36 stream-zero tasks leaves 8 qualified outputs; replacing
the attached recipe with a fresh equivalent body restores all 36. On the 18
tasks that actually reuse a capability from an earlier epoch, those counts are
2 and 18. Replacement bodies have empty proof and authority fields. This
establishes the effect of the selected component, not that persistence is the
only way to obtain it.

The separately registered archive-cleared run empties memory before each epoch,
allows reconstruction and requalification, and charges those operations. It
uses the same frozen stream-zero inputs and policy. Retention achieves 36/36 at
316,616 units; clearing achieves 30/36 at 279,432 units. Thus retention contributes
six additional qualified outputs **and costs 37,184 additional units overall**.
It does not save total units in this intervention.

The per-epoch contrast is informative. In epoch 3, the retained graph recipe
qualifies six outputs that clearing misses, at 9,786 extra units. In epoch 4,
both qualify all six and reuse saves 12,266 units. In epoch 5, both qualify all
six but retained graph execution costs 39,662 additional units relative to the
rebuilt alternative. The persistent recipe is useful in one situation and an
avoidable cost in another. Construction avoided is only one term of the balance
sheet.

Evidence: `secondary-verification.json`, `storage-retention-verification.json`.

## Annotation counterexample

The declared graph omits a premise required by an evaluator's alternate truth
graph. The selected conclusion qualifies under the submitted annotation with
score 20, then fails under the specified truth graph with score 0 because the
premise is absent. Both calculations were independently recomputed.

This is a source-aware, author-constructed model-corruption counterexample,
excluded from primary coverage. It shows that flawless calculation over a bad
annotation cannot establish semantic validity. It is not a blinded empirical
truth study or an estimate of annotation error prevalence.

Evidence: `secondary-verification.json`, `annotation_challenge` field.

## Recovery and finite load

The 16 retained fault-case assertions and saved receipt data are internally
consistent. The review checked exact saved pack identities, STOP partial-charge
events, the retained changed-dependency bytes and the reported denial/decision
states. It did not independently reinject the faults.

Acknowledgement loss, duplicate delivery, process restart and rejected-result
restore report zero new mission issuances but each performs deterministic
verification re-execution. Those four verification checks consume 169,832
additional logical units. Interrupted work contributes another recorded 2,467
units before recovery. These are stated recovery cost components, not a complete
valuation of every debugging or failed-call overhead. "No duplicated mission
issuance" must not be rewritten as "no repeated computation."

| Worker processes | Batch tasks | Qualified outputs | Throughput, tasks/s | p50 task latency, ms | CPU, microseconds |
|---:|---:|---:|---:|---:|---:|
| 1 | 16 | 66 / 96 | 17.74 | 47.20 | 979,040 |
| 2 | 16 | 66 / 96 | 26.34 | 59.18 | 1,258,768 |
| 4 | 16 | 66 / 96 | 41.29 | 77.62 | 1,468,621 |

Each configuration is one short local batch. Wall time includes process startup;
per-task latency excludes queue waiting. p50 is the reported upper-middle order
statistic for 16 observations. Throughput rises while task latency and total CPU
also rise. These observations support a bounded process-concurrency result,
not a sustained-service scalability claim. The zero intervention field applies
to the automated batch interval; it does not erase setup and authoring work.

Evidence: `operations-verification.json`.

## Reproduction

The source-only reproduction independently passes the same full mathematical,
cost and receipt checks. A separate read-only structural comparison confirms
exact equality of all 1,152 scientific observations after excluding only
`elapsed_ns`; all 140,388 ledger records with no exclusions; and all 192 generation
records after excluding only time-dependent `packDigest`. Published arm, stream,
budget-prefix and frozen-source fields also match. The independently calculated
normalized hashes agree with the runtime author's reproduction receipt.

Timing, creation dates, derived expiry dates and resulting pack hashes are fresh
measurements and are not claimed byte-identical. This is same-environment,
source-aware reproducibility, not external replication.

Evidence: `reproduction-verification-independent.json`,
`reproduction-equivalence.json`.

## Review chronology and independence limits

The mathematical core and receipt checker were frozen before primary execution.
The reviewer first exercised hand-authored controls and an explicitly excluded
development fixture. No primary task bytes were inspected before notification
of the completed frozen run.

A concurrent-write race is preserved openly. The initial freeze captured batch
adapter hash `fbd60ad5…`; schema-only reconciliation additions finished immediately
afterward, producing `8048d7a5…`. Before primary authorization, an explicit amendment
recorded the old/new hashes and unchanged mathematical core/receipt checker.
Exact original adapter bytes and both snapshot versions are retained. A provisional
snapshot description that incorrectly said "before freeze" was preserved and
corrected to "after freeze, before primary." Both the original frozen adapter
and amended adapter subsequently passed the primary data. No primary scientific
source, data, numerical criterion or acceptance threshold changed.

The secondary adapter was registered after the source freeze but before this
reviewer saw experimental outputs; the operations adapter is explicitly post-run
consistency analysis. The reviewer is a separate collaborator in the same
session, with source/schema access and no external institutional independence.
It imports no production selector, constructs mathematical closure and feasible
subsets independently, and creates no signatures, credentials, spending or
authority. None of these review results clears a Harness/Fleet restriction or
authorizes publication, production deployment or settlement.

Evidence: `checker-amendment-01.json`, `preconfirmation-checker-snapshot.json`,
`secondary-checker-registration.json`, `archive/`.
