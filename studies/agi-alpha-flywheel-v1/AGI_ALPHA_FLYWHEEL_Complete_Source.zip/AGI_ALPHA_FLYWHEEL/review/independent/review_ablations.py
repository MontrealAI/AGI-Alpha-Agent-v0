#!/usr/bin/env python3
"""Independent secondary analysis: selector replacement, archive clearing and model corruption.

Written as a separate post-freeze review adapter. It changes neither frozen
primary data nor acceptance criteria. It imports no production implementation.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from collections import defaultdict
from pathlib import Path

from receipt_verify import verify_pack
from verify import CAPABILITY_BODY_FIELDS, domain_digest, evaluate, load_jsonl, verify_cost_events, verify_stream


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def normalized_missing(items):
    return sorted(({"id": item["id"], "missing": sorted(item["missing"])} for item in items), key=lambda item: item["id"])


def review(directory: Path, primary_directory: Path) -> dict:
    errors = []
    primary_summary = json.loads((primary_directory / "summary.json").read_text())
    source_hash = primary_summary["sourceHash"]
    primary_rows_all = load_jsonl(primary_directory / "observations.jsonl")
    originals = {row["mission_id"]: row for row in primary_rows_all if row["stream"] == 0 and row["arm"] == "flywheel"}
    attached = {}
    primary_packs = {}
    for path in sorted((primary_directory / "packs").glob("s0-flywheel-g*.json")):
        pack = json.loads(path.read_text())
        primary_packs[pack["result"]["evidence"]["epoch"]] = pack
        for capability in pack["result"]["evidence"]["retained"]:
            attached[capability["digest"]] = capability
    execution_by_arm = {}
    previous_execution = defaultdict(int)
    for row in primary_rows_all:
        key = (row["stream"], row["arm"], row["epoch"])
        current = row["cost_breakdown"]["execution"]
        execution_by_arm[(row["stream"], row["arm"], row["mission_id"])] = current - previous_execution[key]
        previous_execution[key] = current
    ablations = load_jsonl(directory / "ablations.jsonl")
    seen = set()
    details = []
    for index, row in enumerate(ablations):
        local = []
        key = (row["pair_id"], row["variant"])
        if key in seen:
            local.append("duplicate ablation pair/variant")
        seen.add(key)
        original = originals.get(row["pair_id"])
        if original is None:
            local.append("ablation has no primary pair")
            errors.extend(f"ablation {index}: {error}" for error in local)
            continue
        if row["variant"] not in {"remove", "replace"}:
            local.append("unknown ablation variant")
        if row["document"] != original["document"] or row["max_clauses"] != original["max_clauses"]:
            local.append("ablation task differs from paired primary task")
        result = evaluate(row["document"], row["max_clauses"], row["selected"])
        for field, independent in (("structural_score", result["selected_weight"]),
                                   ("optimal_score", result["optimum_weight"]),
                                   ("qualified", result["qualified"])):
            if row[field] != independent:
                local.append(f"{field} differs from independent mathematical result")
        if normalized_missing(row["missing"]) != result["missing_by_claim"]:
            local.append("missing prerequisites differ from independent closure")
        original_math = evaluate(original["document"], original["max_clauses"], original["selected"])
        if row["original_qualified"] is not original_math["qualified"]:
            local.append("original qualification differs from independent result")
        if row["original_method"] != original["method"] or row["original_capability_digest"] != original["capability_digest"]:
            local.append("original method or attached asset binding differs")
        if row["had_inherited_capability"] is not (original["capability_digest"] is not None):
            local.append("raw nonnull-capability flag inconsistent")
        replacement_charge = 0
        if row["variant"] == "replace":
            replacement = row["replacement"]
            body = {field: replacement[field] for field in CAPABILITY_BODY_FIELDS}
            if replacement["digest"] != domain_digest("flywheel-capability", body):
                local.append("replacement artifact hash mismatch")
            if replacement["proof"] != [] or replacement["authority"] != []:
                local.append("replacement inherits proof/authority")
            if replacement["sourceHash"] != source_hash or replacement["method"] != original["method"]:
                local.append("replacement source/method differs")
            if row["selected"] != original["selected"] or result["qualified"] != original_math["qualified"]:
                local.append("semantic-equivalent replacement did not restore exact output")
            if row["replacement_semantics_unchanged"] is not True:
                local.append("replacement semantics flag differs")
            replacement_charge = math.ceil(len(canonical(replacement).encode()) / 1024)
            execution_units = execution_by_arm[(0, "flywheel", row["pair_id"])]
        else:
            if row["method"] != "lead-order" or row["selected"] != [claim["id"] for claim in row["document"]["claims"][:row["max_clauses"]]]:
                local.append("removal variant does not implement the declared lead policy")
            if row["replacement"] is not None or row["replacement_semantics_unchanged"] is not False:
                local.append("removal variant unexpectedly has a replacement")
            execution_units = execution_by_arm.get((0, "frozen", row["pair_id"]))
        n = result["claim_count"]
        edges = sum(len(claim["depends_on"]) for claim in row["document"]["claims"])
        validation = n * (2 ** n) + result["bounded_masks"] * (n + edges + 1) + 5 * n + 2 * edges
        if execution_units is not None and row["units"] != execution_units + validation + replacement_charge:
            local.append("ablation units differ from same-operation execution receipt plus independent validation/retention tariff")
        asset = attached.get(original["capability_digest"])
        earlier_reuse = asset is not None and asset["created_epoch"] < original["epoch"]
        details.append({"pair_id": row["pair_id"], "variant": row["variant"],
                        "original_qualified": original_math["qualified"], "qualified": result["qualified"],
                        "attached_capability": asset is not None,
                        "inherited_from_earlier_epoch": earlier_reuse,
                        "capability_created_epoch": asset["created_epoch"] if asset else None,
                        "mission_epoch": original["epoch"], "units": row["units"],
                        "checks_pass": not local, "errors": local})
        errors.extend(f"ablation {index}: {error}" for error in local)
    expected = {(name, variant) for name in originals for variant in ("remove", "replace")}
    if seen != expected:
        errors.append("ablation pair/variant coverage differs from registered stream-zero rows")
    variants = {}
    for variant in ("remove", "replace"):
        group = [row for row in details if row["variant"] == variant]
        prior = [row for row in group if row["inherited_from_earlier_epoch"]]
        variants[variant] = {"missions": len(group), "qualified": sum(row["qualified"] for row in group),
                             "original_qualified": sum(row["original_qualified"] for row in group),
                             "lost_qualification": sum(row["original_qualified"] and not row["qualified"] for row in group),
                             "gained_qualification": sum(not row["original_qualified"] and row["qualified"] for row in group),
                             "earlier_inheritance_missions": len(prior),
                             "earlier_inheritance_qualified": sum(row["qualified"] for row in prior),
                             "earlier_inheritance_original_qualified": sum(row["original_qualified"] for row in prior),
                             "units": sum(row["units"] for row in group)}
    cleared = json.loads((directory / "archive-cleared.json").read_text())
    cleared["arm"] = "flywheel"
    cleared["retained"] = cleared["generations"][-1]["retained"]
    archive_check = verify_stream(cleared)
    events = []
    archive_pack_checks = []
    for path in sorted((directory / "archive-cleared-packs").glob("generation-*.json")):
        pack = json.loads(path.read_text())
        check = verify_pack(pack, source_hash)
        check["path"] = str(path.relative_to(directory))
        archive_pack_checks.append(check)
        errors.extend(f"{check['path']}: {error}" for error in check["errors"])
        evidence = pack["result"]["evidence"]
        epoch = evidence["epoch"]
        if pack["spec"]["inputs"]["retained"] != []:
            errors.append(f"archive-clear epoch {epoch}: archive was not empty at start")
        original_inputs = primary_packs[epoch]["spec"]["inputs"]
        for field in ("development", "qualification", "missions", "max_clauses", "sourceHash", "budget"):
            if pack["spec"]["inputs"][field] != original_inputs[field]:
                errors.append(f"archive-clear epoch {epoch}: input field {field} differs from paired primary")
        events.extend(dict(event, epoch=epoch, stream=0, arm="flywheel") for event in evidence["cost_events"])
    archive_events = verify_cost_events(cleared, events)
    errors.extend("archive-clear: " + error for error in archive_check["errors"])
    errors.extend("archive-clear events: " + error for error in archive_events["errors"])
    original_stream = next(row for row in primary_summary["streams"] if row["stream"] == 0 and row["arm"] == "flywheel")
    archive_effect = {"retained_qualified": original_stream["qualified"], "cleared_qualified": archive_check["qualified"],
                      "retained_units": original_stream["spent"], "cleared_units": archive_check["spent"],
                      "qualified_benefit_of_retention": original_stream["qualified"] - archive_check["qualified"],
                      "units_saved_by_retention": archive_check["spent"] - original_stream["spent"],
                      "scope": "Within-policy stream-zero archive intervention with full repeated construction/requalification charged; does not establish uniqueness over conventional caching."}
    challenge = json.loads((directory / "annotation-challenge.json").read_text())
    declared = evaluate(challenge["submitted_document"], challenge["max_clauses"], challenge["selected"])
    truth = evaluate(challenge["hidden_true_document"], challenge["max_clauses"], challenge["selected"])
    if challenge["locally_supported"] != (not declared["unsupported"]) or challenge["true_supported"] != (not truth["unsupported"]):
        errors.append("annotation challenge support flags differ")
    if challenge["local_score"] != declared["selected_weight"] or challenge["true_score"] != truth["selected_weight"]:
        errors.append("annotation challenge scores differ")
    if not declared["qualified"] or truth["qualified"]:
        errors.append("annotation challenge failed to exhibit the preregistered model boundary")
    annotation = {"declared_qualified": declared["qualified"], "truth_qualified": truth["qualified"],
                  "declared_score": declared["selected_weight"], "truth_score": truth["selected_weight"],
                  "truth_missing": truth["missing_by_claim"],
                  "scope": "Source-aware, author-constructed annotation-corruption counterexample, excluded from primary coverage; not an estimate of real error prevalence."}
    return {"schema": "flywheel-independent-secondary-review/v1", "pass": not errors,
            "errors": errors, "source_hash": source_hash, "variant_summaries": variants,
            "component_pairs": details, "archive_effect": archive_effect,
            "archive_check": archive_check, "archive_event_check": archive_events,
            "archive_pack_checks": archive_pack_checks, "annotation_challenge": annotation,
            "limits": ["Same-session source-aware reviewer; no external blinding.",
                       "Nonnull capability_digest is not sufficient evidence of inheritance from an earlier epoch.",
                       "Forced lead ablation is component removal; archive-cleared rerun addresses persistence separately.",
                       "No inherited proof or authority, signing, credentials or external economic execution."]}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("ablations", type=Path)
    parser.add_argument("primary", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = review(args.ablations, args.primary)
    result["checker_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    result["input_hashes"] = {str(path.relative_to(args.ablations)): hashlib.sha256(path.read_bytes()).hexdigest()
                               for path in sorted(args.ablations.rglob("*")) if path.is_file()}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"pass": result["pass"], "errors": result["errors"], "output": str(args.output)}))
    return 0 if result["pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
