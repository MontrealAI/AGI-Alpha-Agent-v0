# Independent arithmetic and receipt review

## Scope and independence

This reviewer is a separate collaborator in the same authoring session. It is
**source-aware, not externally blinded**. The upstream schema, structural
scoring definition and digest format were visible. No claim is made that the
reviewer is an independent institution, credential holder or publication
authority. No keys are generated and no signatures, contract transactions or
installed-runtime acceptance tests are performed.

`verify.py` imports only Python standard-library modules. It does not import or
execute the companion's selector, tariff implementation, orchestration kernel
or upstream JavaScript modules. Its mathematical instrument independently
constructs transitive prerequisite closure with bitset reachability and
enumerates the Boolean subset domain. It calculates qualified output from the
source weights, prerequisite closure and clause limit rather than trusting a
candidate's reported score.

This check establishes consistency with the **authored structural model**. It
does not establish factual correctness of the clauses, completeness of the
annotations, reader benefit, commercial demand or general intelligence.

## What is checked

- Exact optimum, achieved supported weight, selected-ID validity, transitive
  missing prerequisites and terminal qualification.
- Terminal denominator and qualified counts by epoch and whole stream.
- Monotonic cumulative accounting, eight cost categories and full generation
  totals. Terminal row breakdowns are cumulative **within an epoch**; summing
  those snapshots would double-count setup. Raw events are reconciled once.
- The shared comparison tariff independently derived from source size, edge
  count and the number of bounded subsets. These are declared proxy units,
  not measured CPU instructions or monetary labor valuations.
- Exact capability content hashes, source binding, bounded active inventory,
  lifecycle chronology, retirement receipts and empty inherited proof and
  authority fields.
- Rejection retains the incumbent; output reuse names a known retained asset.

## Preconfirmation development

`dev_check.py` contains hand-authored mathematical controls: a prerequisite
that blocks a high-weight clause; different clause budgets; a transitive
diamond; equal optima; a rejected cycle; and tampered quality/cost receipts.
These fixtures are development controls and are excluded from the paper's
confirmatory sample.

The first runtime fixture inspected was explicitly labeled
`development-smoke.json` (seed 101). No confirmatory source document was
inspected before notification of the implementation/protocol freeze. The
freeze chronology and later extensions to this reviewer must remain visible
in the final review report.

Run the development controls from this folder:

```sh
python3 dev_check.py
```

The final verifier input identities, counts, failures and return status are
recorded in the generated verification JSON. A favorable arithmetic report
does not grant production authority or clear any existing Harness/Fleet hold.
