#!/usr/bin/env python3
"""Independent hash/binding checks for existing unsigned workbench receipts.

This verifies content identities and declared local boundaries. It does not
sign receipts, recreate the JobCompiler, or confer review/production authority.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from verify import domain_digest, evaluate


def verify_pack(pack: dict, source_hash: str | None = None) -> dict:
    errors = []
    body = {key: value for key, value in pack.items() if key != "integrityDigest"}
    if pack.get("integrityDigest") != domain_digest("workbench-pack", body):
        errors.append("full pack hash mismatch")
    if pack.get("schema") != "successor-workbench/v1":
        errors.append("pack schema mismatch")
    spec = pack.get("spec", {})
    semantic = {key: value for key, value in spec.items() if key not in {"name", "language"}}
    frozen = pack.get("frozen", {})
    if frozen.get("missionDigest") != domain_digest("workbench-mission", semantic):
        errors.append("semantic mission hash mismatch")
    if pack.get("releaseDigest") != domain_digest("workbench-release", frozen):
        errors.append("release hash mismatch")
    if frozen.get("authority") != []:
        errors.append("frozen authority is nonempty")
    inputs = spec.get("inputs", {})
    if frozen.get("sourceHash") != inputs.get("sourceHash"):
        errors.append("frozen and input source hashes differ")
    if source_hash is not None and frozen.get("sourceHash") != source_hash:
        errors.append("pack source differs from declared source")
    names = []
    for index, artifact in enumerate(pack.get("result", {}).get("artifacts", [])):
        content = {key: value for key, value in artifact.items() if key != "digest"}
        if artifact.get("digest") != domain_digest("workbench-artifact", content):
            errors.append(f"artifact {index} content hash mismatch")
        names.append(artifact.get("name"))
    if len(names) != len(set(names)):
        errors.append("duplicate artifact name")
    evaluation = pack.get("evaluation", {})
    required_evaluation = {"scope": "PUBLIC_LOCAL_EXECUTION", "independentProof": False,
                           "admission": "HOLD", "authority": [], "settlement": "NOT_CONNECTED"}
    if evaluation != required_evaluation:
        errors.append("local unsigned evaluation boundary differs")
    economics = pack.get("economics", {})
    if economics.get("providerSpendBaseUnits") != "0" or economics.get("settlementSpendBaseUnits") != "0":
        errors.append("nonzero external spending in local receipt")
    if economics.get("allowanceIs") != "UNFUNDED":
        errors.append("funding boundary differs")
    compilation = pack.get("compilation", {})
    if compilation.get("authorityCreated") != "NONE" or compilation.get("signatureStatus") != "UNSIGNED_COMMITMENT":
        errors.append("compiler authority/signature boundary differs")
    for item in pack.get("chronicle", []):
        if item.get("inheritedProof") is not False or item.get("inheritedAuthority") is not False:
            errors.append("chronicle inherits proof or authority")
        if item.get("missionDigest") != frozen.get("missionDigest") or item.get("releaseDigest") != pack.get("releaseDigest"):
            errors.append("chronicle mission/release identity differs")
    evidence = pack.get("result", {}).get("evidence", {})
    for key in ("stream", "arm", "epoch"):
        if inputs.get(key) != evidence.get(key):
            errors.append(f"{key} differs between input and evidence")
    mission_docs = inputs.get("missions", [])
    observations = evidence.get("observations", [])
    for index, row in enumerate(observations):
        if index >= len(mission_docs) or row.get("document") != mission_docs[index]:
            errors.append(f"terminal {index} document differs from bound mission input")
        if row.get("max_clauses") != inputs.get("max_clauses"):
            errors.append(f"terminal {index} clause cap differs from bound input")
    summary = pack.get("result", {}).get("summary", {})
    independent_qualified = sum(evaluate(row["document"], row["max_clauses"], row["selected"])["qualified"]
                                for row in observations)
    if summary.get("qualified") != independent_qualified:
        errors.append("pack summary qualified count differs from independent terminal math")
    if summary.get("requested") != len(mission_docs):
        errors.append("pack summary denominator differs from bound mission inputs")
    return {"pass": not errors, "errors": errors,
            "stream": inputs.get("stream"), "arm": inputs.get("arm"), "epoch": inputs.get("epoch"),
            "terminal_observations": len(observations), "qualified": independent_qualified,
            "source_hash": frozen.get("sourceHash"),
            "integrity_digest": pack.get("integrityDigest"), "artifact_count": len(names),
            "limits": ["Unsigned content binding, not authenticated origin or production approval.",
                       "JobCompiler structure is not independently recompiled here.",
                       "Structural annotation correctness remains an assumption."]}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("pack", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--source-hash")
    args = parser.parse_args()
    report = verify_pack(json.loads(args.pack.read_text()), args.source_hash)
    report["file_sha256"] = hashlib.sha256(args.pack.read_bytes()).hexdigest()
    report["checker_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"pass": report["pass"], "errors": report["errors"], "output": str(args.output)}))
    return 0 if report["pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
