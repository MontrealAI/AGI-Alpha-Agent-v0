#!/usr/bin/env python3
"""Independent arithmetic and receipt checker for the finite flywheel study.

This file imports no study implementation, selector, or vendored AGI ALPHA code.
It uses integer bit masks and transitive prerequisite closure to exhaust the
finite subset domain. Independence is algorithmic and source-level only: its
author is a same-session collaborator who has read upstream model definitions.
It is not externally blinded validation, an authority grant, or a signature.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any


COST_FIELDS = (
    "construction", "qualification", "execution", "validation",
    "retention", "maintenance", "routing", "runtime",
)
LIMITS = [
    "Same-session collaborator, not an external independent institution.",
    "Upstream schema and mathematical scoring definition were visible before implementation.",
    "No imports from the implementation under review; independent subset enumeration.",
    "Checks authored structural annotations, not semantic truth or reader utility.",
    "Reconciles observed operation counts/proxy tariffs; cannot establish real labor prices.",
    "No signing, new credentials, financial action, installed-runtime qualification, or authority grant.",
]


class InvalidRecord(ValueError):
    pass


def integer(value: Any, where: str, minimum: int = 0) -> int:
    if type(value) is not int or value < minimum:
        raise InvalidRecord(f"{where}: expected integer >= {minimum}, got {value!r}")
    return value


def document_model(document: dict[str, Any]) -> dict[str, Any]:
    """Construct transitive closures without the production scorer's routines."""
    claims = document.get("claims")
    if not isinstance(claims, list) or not 1 <= len(claims) <= 20:
        raise InvalidRecord("claims must contain between 1 and 20 items")
    ids = []
    weights = []
    for index, claim in enumerate(claims):
        name = claim.get("id")
        if not isinstance(name, str) or not name or name in ids:
            raise InvalidRecord(f"claim {index}: nonempty unique string ID required")
        ids.append(name)
        weights.append(integer(claim.get("weight"), f"{name}.weight", 1))
    positions = {name: index for index, name in enumerate(ids)}
    closure = []
    for claim in claims:
        dependencies = claim.get("depends_on")
        if not isinstance(dependencies, list) or len(set(dependencies)) != len(dependencies):
            raise InvalidRecord(f"{claim['id']}.depends_on must be a unique list")
        required = 0
        for dependency in dependencies:
            if dependency not in positions:
                raise InvalidRecord(f"{claim['id']}: unknown prerequisite {dependency!r}")
            required |= 1 << positions[dependency]
        closure.append(required)
    # Bitset fixed point computes reachability on the annotated graph. It is
    # independent of production recursive/combination-based selector code.
    changed = True
    while changed:
        changed = False
        for index in range(len(ids)):
            expanded = closure[index]
            for prerequisite in range(len(ids)):
                if expanded & (1 << prerequisite):
                    expanded |= closure[prerequisite]
            if expanded != closure[index]:
                closure[index] = expanded
                changed = True
    if any(mask & (1 << index) for index, mask in enumerate(closure)):
        raise InvalidRecord("prerequisite graph has a directed cycle")
    return {"ids": ids, "weights": weights, "closure": closure,
            "positions": positions, "total_weight": sum(weights)}


def evaluate(document: dict[str, Any], max_clauses: int,
             selected: list[str]) -> dict[str, Any]:
    """Exhaust all bounded sets; report exact optimum and supplied-set quality."""
    model = document_model(document)
    ids, weights, closure = model["ids"], model["weights"], model["closure"]
    n = len(ids)
    cap = integer(max_clauses, "max_clauses", 1)
    if cap > n:
        raise InvalidRecord("max_clauses exceeds source clause count")
    if not isinstance(selected, list) or any(not isinstance(x, str) for x in selected):
        raise InvalidRecord("selected must be a list of IDs")
    unknown = sorted(set(selected) - set(ids))
    duplicate = len(selected) != len(set(selected))
    supplied_mask = sum(1 << model["positions"][name] for name in set(selected) if name in model["positions"])
    supported = []
    unsupported = []
    missing_mask = 0
    missing_by_claim = []
    achieved_weight = 0
    for index, name in enumerate(ids):
        if supplied_mask & (1 << index):
            absent = closure[index] & ~supplied_mask
            if absent:
                unsupported.append(name)
                missing_mask |= absent
                missing_by_claim.append({"id": name, "missing": sorted(
                    ids[j] for j in range(n) if absent & (1 << j))})
            else:
                supported.append(name)
                achieved_weight += weights[index]
    best_weight = -1
    best_key = None
    best_mask = 0
    optimum_count = 0
    feasible_count = 0
    bounded_count = 0
    # The representation ranges over the entire Boolean cube; feasibility and
    # value are derived here rather than copied from candidate receipts.
    for mask in range(1 << n):
        count = mask.bit_count()
        if count > cap:
            continue
        bounded_count += 1
        feasible = True
        weight = 0
        for index in range(n):
            if mask & (1 << index):
                if closure[index] & ~mask:
                    feasible = False
                    break
                weight += weights[index]
        if not feasible:
            continue
        feasible_count += 1
        names = tuple(ids[index] for index in range(n) if mask & (1 << index))
        key = (count, names)
        if weight > best_weight:
            best_weight, best_mask, best_key, optimum_count = weight, mask, key, 1
        elif weight == best_weight:
            optimum_count += 1
            if key < best_key:
                best_mask, best_key = mask, key
    valid_selection = not unknown and not duplicate and len(selected) <= cap
    all_supported = not unsupported
    qualified = valid_selection and all_supported and achieved_weight == best_weight
    return {
        "claim_count": n,
        "total_weight": model["total_weight"],
        "enumerated_masks": 1 << n,
        "bounded_masks": bounded_count,
        "feasible_masks": feasible_count,
        "optimum_weight": best_weight,
        "optimal_score_millionths": best_weight * 1_000_000 // model["total_weight"],
        "optimal_selected": [ids[index] for index in range(n) if best_mask & (1 << index)],
        "optimal_set_count": optimum_count,
        "selected_weight": achieved_weight,
        "structural_score_millionths": achieved_weight * 1_000_000 // model["total_weight"],
        "supported": supported,
        "unsupported": sorted(unsupported),
        "missing_prerequisites": sorted(ids[index] for index in range(n) if missing_mask & (1 << index)),
        "missing_by_claim": sorted(missing_by_claim, key=lambda item: item["id"]),
        "unknown_ids": unknown,
        "duplicate_ids": duplicate,
        "valid_selection": valid_selection,
        "qualified": qualified,
    }


def row_errors(row: dict[str, Any], math_result: dict[str, Any],
               score_unit: str, missing_field: str, breakdown_mode: str = "incremental") -> list[str]:
    errors = []
    completed = row.get("status") == "completed"
    if row.get("status") not in {"completed", "budget-exhausted"}:
        errors.append("unrecognized status")
    score_key = "selected_weight" if score_unit == "weight" else "structural_score_millionths"
    optimum_key = "optimum_weight" if score_unit == "weight" else "optimal_score_millionths"
    if row.get("optimal_score") != math_result[optimum_key]:
        errors.append(f"optimal_score {row.get('optimal_score')!r} != {math_result[optimum_key]}")
    if completed:
        if row.get("structural_score") != math_result[score_key]:
            errors.append(f"structural_score {row.get('structural_score')!r} != {math_result[score_key]}")
        if row.get("qualified") is not math_result["qualified"]:
            errors.append(f"qualified {row.get('qualified')!r} != {math_result['qualified']}")
        missing = row.get("missing", [])
        if missing_field == "missing_by_claim":
            missing = sorted(({"id": item["id"], "missing": sorted(item["missing"])}
                              for item in missing), key=lambda item: item["id"])
        else:
            missing = sorted(missing)
        if missing != math_result[missing_field]:
            errors.append("missing annotations disagree with independently recomputed closure")
    else:
        if row.get("qualified") is not False:
            errors.append("budget-exhausted output cannot be qualified")
    costs = row.get("cost_breakdown", {})
    if set(costs) != set(COST_FIELDS):
        errors.append("cost_breakdown field set differs from fixed eight categories")
    try:
        before = integer(row.get("cost_before"), "cost_before")
        after = integer(row.get("cost_after"), "cost_after")
        parts = [integer(costs.get(field), f"cost_breakdown.{field}") for field in COST_FIELDS]
        if breakdown_mode == "incremental" and after - before != sum(parts):
            errors.append(f"cost delta {after - before} != component sum {sum(parts)}")
        if after < before:
            errors.append("cumulative cost decreased")
        integer(row.get("elapsed_ns"), "elapsed_ns")
    except InvalidRecord as exc:
        errors.append(str(exc))
    return errors


def verify_rows(rows: list[dict[str, Any]], *, score_unit: str = "weight",
                missing_field: str = "missing_prerequisites",
                budget: int | None = None, breakdown_mode: str = "incremental") -> dict[str, Any]:
    errors = []
    detailed = []
    grouped = defaultdict(list)
    identities = set()
    for line, row in enumerate(rows, 1):
        identity = (row.get("stream"), row.get("arm"), row.get("mission_id"))
        local = []
        if identity in identities:
            local.append("duplicate stream/arm/mission identity")
        identities.add(identity)
        try:
            result = evaluate(row["document"], row["max_clauses"], row.get("selected", []))
            local.extend(row_errors(row, result, score_unit, missing_field, breakdown_mode))
        except (InvalidRecord, KeyError, TypeError) as exc:
            result = None
            local.append(str(exc))
        if budget is not None and type(row.get("cost_after")) is int and row["cost_after"] > budget:
            local.append("cumulative cost exceeded declared budget")
        entry = {"line": line, "stream": identity[0], "arm": identity[1], "epoch": row.get("epoch"),
                 "mission_id": row.get("mission_id"), "checks_pass": not local,
                 "errors": local, "independent_math": result}
        detailed.append(entry)
        grouped[identity[:2]].append((row, entry))
        errors.extend(f"line {line}: {error}" for error in local)
    summaries = []
    for (stream, arm), group in sorted(grouped.items(), key=lambda item: (str(item[0][0]), str(item[0][1]))):
        group.sort(key=lambda pair: pair[0]["epoch"])
        previous = 0
        cost_totals = {field: 0 for field in COST_FIELDS}
        qualified = 0
        executed = 0
        for row, entry in group:
            if breakdown_mode == "incremental" and row.get("cost_before") != previous:
                errors.append(f"stream {stream} arm {arm} epoch {row.get('epoch')}: noncontiguous cumulative ledger")
            previous = row.get("cost_after", previous)
            if row.get("status") == "completed":
                executed += 1
                if entry["independent_math"] and entry["independent_math"]["qualified"]:
                    qualified += 1
            for field in COST_FIELDS if breakdown_mode == "incremental" else ():
                value = row.get("cost_breakdown", {}).get(field)
                if type(value) is int:
                    cost_totals[field] += value
        summaries.append({"stream": stream, "arm": arm, "missions": len(group),
                          "executed": executed, "qualified": qualified,
                          "cumulative_cost": previous, "cost_components": cost_totals})
    return {"schema": "flywheel-independent-verification/v1", "pass": not errors,
            "observations": len(rows), "score_unit": score_unit,
            "missing_field": missing_field, "budget": budget, "breakdown_mode": breakdown_mode,
            "errors": errors, "per_stream": summaries, "per_observation": detailed,
            "independence_limits": LIMITS}


def verify_stream(result: dict[str, Any], *, expected_requested: int = 36) -> dict[str, Any]:
    """Reconcile epoch snapshots with full generation costs; no double counting."""
    budget = integer(result.get("budget"), "budget")
    rows = result.get("observations", [])
    report = verify_rows(rows, missing_field="missing_by_claim", budget=budget,
                         breakdown_mode="epoch-cumulative")
    errors = report["errors"]
    stream, arm = result.get("stream"), result.get("arm")
    if result.get("requested") != expected_requested:
        errors.append("requested denominator differs from protocol")
    if len(rows) > expected_requested:
        errors.append("too many terminal observations")
    if any(row.get("stream") != stream or row.get("arm") != arm for row in rows):
        errors.append("terminal observation identity differs from stream pack")
    observations_by_epoch = defaultdict(list)
    for row in rows:
        observations_by_epoch[row["epoch"]].append(row)
    mathematics = {entry["mission_id"]: entry["independent_math"] for entry in report["per_observation"]}
    generation_report = []
    previous_spent = 0
    total_costs = {field: 0 for field in COST_FIELDS}
    generation_ids = set()
    total_qualified = 0
    for generation in result.get("generations", []):
        epoch = generation["epoch"]
        local = []
        if epoch in generation_ids:
            local.append("duplicate generation")
        generation_ids.add(epoch)
        costs = generation.get("costs", {})
        if set(costs) != set(COST_FIELDS):
            local.append("generation cost category set differs")
        try:
            current_spent = integer(generation.get("spent"), "generation.spent")
            gen_total = sum(integer(costs.get(field), f"generation.costs.{field}") for field in COST_FIELDS)
        except InvalidRecord as exc:
            local.append(str(exc))
            current_spent, gen_total = previous_spent, 0
        if current_spent - previous_spent != gen_total:
            local.append("generation cost delta does not reconcile to component totals")
        if current_spent > budget:
            local.append("generation overspent stream budget")
        epoch_rows = observations_by_epoch.get(epoch, [])
        qualified = 0
        previous_row_after = None
        previous_breakdown = {field: 0 for field in COST_FIELDS}
        for row in epoch_rows:
            row_total = sum(row.get("cost_breakdown", {}).values())
            if row["cost_after"] - previous_spent != row_total:
                local.append(f"{row['mission_id']}: epoch snapshot fails cumulative reconciliation")
            if previous_row_after is not None and row["cost_before"] != previous_row_after:
                local.append(f"{row['mission_id']}: within-epoch terminal costs not contiguous")
            if row["cost_before"] < previous_spent or row["cost_after"] > current_spent:
                local.append(f"{row['mission_id']}: terminal cost outside generation bounds")
            for field in COST_FIELDS:
                now = row["cost_breakdown"][field]
                if now < previous_breakdown[field] or now > costs[field]:
                    local.append(f"{row['mission_id']}: {field} snapshot outside monotone generation totals")
            # The shared structural comparator's published tariff is derived
            # independently from document size and the number of bounded sets.
            model = mathematics[row["mission_id"]]
            if model:
                n = model["claim_count"]
                edges = sum(len(claim["depends_on"]) for claim in row["document"]["claims"])
                validation_expected = n * (2 ** n) + model["bounded_masks"] * (n + edges + 1) + 5 * n + 2 * edges
                validation_delta = row["cost_breakdown"]["validation"] - previous_breakdown["validation"]
                if validation_delta != validation_expected:
                    local.append(f"{row['mission_id']}: validation tariff {validation_delta} != {validation_expected}")
                qualified += int(model["qualified"] and row["status"] == "completed")
            previous_row_after = row["cost_after"]
            previous_breakdown = row["cost_breakdown"]
        if generation.get("coverage") != qualified:
            local.append("generation qualified coverage differs from independent terminal count")
        total_qualified += qualified
        for field in COST_FIELDS:
            total_costs[field] += costs.get(field, 0)
        generation_report.append({"epoch": epoch, "qualified": qualified,
                                  "terminal_observations": len(epoch_rows),
                                  "cost": gen_total, "cumulative_cost": current_spent,
                                  "errors": local, "checks_pass": not local})
        errors.extend(f"epoch {epoch}: {error}" for error in local)
        previous_spent = current_spent
    if set(observations_by_epoch) - generation_ids:
        errors.append("terminal observations refer to absent generation")
    if result.get("spent") != previous_spent:
        errors.append("final spent differs from final generation cumulative cost")
    if result.get("qualified") != total_qualified:
        errors.append("final qualified differs from independently recomputed count")
    report.update({"pass": not errors, "stream": stream, "arm": arm,
                   "requested": expected_requested, "qualified": total_qualified,
                   "spent": previous_spent, "cost_components": total_costs,
                   "generation_checks": generation_report})
    return report


CAPABILITY_BODY_FIELDS = (
    "schema", "method", "scope", "sourceHash", "created_epoch", "proof", "authority", "reuse",
)


def domain_digest(domain: str, value: Any) -> str:
    """Recompute documented integer/string canonical JSON hash in Python."""
    encoded = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(("successor-omega/v1:" + domain + "\0" + encoded).encode("utf-8")).hexdigest()


def verify_capability(capability: dict[str, Any], epoch: int,
                      source_hash: str | None = None) -> list[str]:
    errors = []
    if any(field not in capability for field in CAPABILITY_BODY_FIELDS):
        return ["capability body missing required fields"]
    body = {field: capability[field] for field in CAPABILITY_BODY_FIELDS}
    if capability.get("digest") != domain_digest("flywheel-capability", body):
        errors.append("capability digest differs from independently hashed body")
    if body["schema"] != "flywheel-capability/v1":
        errors.append("capability schema differs")
    if body["proof"] != [] or body["authority"] != []:
        errors.append("capability inherits proof or authority")
    if body["reuse"] != "Fresh result checks remain required.":
        errors.append("capability reuse boundary differs")
    if source_hash is not None and body["sourceHash"] != source_hash:
        errors.append("capability source differs from execution source")
    try:
        created = integer(body["created_epoch"], "created_epoch")
        validated = integer(capability["validated_epoch"], "validated_epoch")
        used = integer(capability["last_used_epoch"], "last_used_epoch")
        if not created <= validated <= epoch or not created <= used <= epoch:
            errors.append("capability lifecycle epoch outside permitted chronology")
    except (KeyError, InvalidRecord) as exc:
        errors.append(str(exc))
    return errors


def verify_retention(result: dict[str, Any], source_hash: str | None = None) -> dict[str, Any]:
    errors = []
    bodies = {}
    known = {}
    previous_active = set()
    previous_capabilities = {}
    report = []
    for generation in result.get("generations", []):
        epoch = generation["epoch"]
        retained = generation.get("retained", [])
        local = []
        if len(retained) > 2:
            local.append("active capability count exceeds capacity two")
        active = set()
        capabilities = {}
        for capability in retained:
            digest = capability.get("digest")
            if digest in active:
                local.append("duplicate retained capability identity")
            active.add(digest)
            capabilities[digest] = capability
            local.extend(verify_capability(capability, epoch, source_hash))
            body = {field: capability.get(field) for field in CAPABILITY_BODY_FIELDS}
            if digest in bodies and body != bodies[digest]:
                local.append("existing capability identity changed body")
            bodies[digest] = body
            known[digest] = capability
        removed = previous_active - active
        retirement_records = generation.get("retired", [])
        retirement_ids = {record.get("digest") if isinstance(record, dict) else record
                          for record in retirement_records}
        if removed - retirement_ids:
            local.append("capability disappeared without a retirement record")
        if active & retirement_ids:
            local.append("retired capability remains active")
        # Capacity eviction must use the declared LRU key if its record names
        # that reason. Other invalidation reasons require different evidence.
        for record in retirement_records:
            if isinstance(record, dict) and record.get("reason") in {"capacity", "capacity-lru", "lru-capacity"}:
                candidates = list(previous_capabilities.values())
                if candidates:
                    least_recent = min(candidates, key=lambda cap: (cap["last_used_epoch"], cap["digest"]))
                    if record.get("digest") != least_recent["digest"]:
                        local.append("capacity retirement does not match LRU/digest ordering")
        if generation.get("decision") == "REJECT_DESCENDANT" and generation.get("selected") != generation.get("incumbent"):
            local.append("rejected descendant replaced incumbent")
        for row in result.get("observations", []):
            if row.get("epoch") != epoch or row.get("capability_digest") is None:
                continue
            digest = row["capability_digest"]
            if digest not in active and digest not in previous_active:
                local.append(f"{row['mission_id']}: output capability lacks retained provenance")
            elif bodies.get(digest, {}).get("method") != row.get("method"):
                local.append(f"{row['mission_id']}: output method differs from capability body")
        report.append({"epoch": epoch, "active": sorted(active),
                       "removed": sorted(removed), "checks_pass": not local, "errors": local})
        errors.extend(f"epoch {epoch}: {error}" for error in local)
        previous_active, previous_capabilities = active, capabilities
    final_ids = {item.get("digest") for item in result.get("retained", [])}
    if final_ids != previous_active:
        errors.append("final retained set differs from final generation")
    return {"pass": not errors, "distinct_capabilities": len(known),
            "errors": errors, "generations": report,
            "proof_and_authority_inheritance": "empty fields checked; no external authority inferred"}


def verify_cost_events(result: dict[str, Any], events: list[dict[str, Any]]) -> dict[str, Any]:
    """Reconcile each raw charge, full stream cumulative total and epoch category."""
    errors = []
    running = 0
    grouped = defaultdict(lambda: {field: 0 for field in COST_FIELDS})
    for index, event in enumerate(events):
        try:
            units = integer(event.get("units"), "event.units")
            cumulative = integer(event.get("cumulative"), "event.cumulative")
            epoch = integer(event.get("epoch"), "event.epoch")
            category = event.get("category")
            if category not in COST_FIELDS:
                raise InvalidRecord("unknown event category")
            if not isinstance(event.get("operation"), str) or not event["operation"]:
                raise InvalidRecord("event operation label missing")
            if event.get("stream", result.get("stream")) != result.get("stream") or event.get("arm", result.get("arm")) != result.get("arm"):
                raise InvalidRecord("event stream/arm binding differs")
            running += units
            grouped[epoch][category] += units
            if cumulative != running:
                errors.append(f"event {index}: cumulative charge differs from prior + units")
            if cumulative > result["budget"]:
                errors.append(f"event {index}: stream budget exceeded")
        except InvalidRecord as exc:
            errors.append(f"event {index}: {exc}")
    for generation in result.get("generations", []):
        epoch = generation["epoch"]
        if grouped[epoch] != generation["costs"]:
            errors.append(f"epoch {epoch}: event totals differ from generation categories")
    if running != result.get("spent"):
        errors.append("event charges differ from final stream spending")
    return {"pass": not errors, "event_count": len(events), "units": running,
            "errors": errors, "epoch_categories": dict(grouped)}


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("observations", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--score-unit", choices=("weight", "millionths"), default="weight")
    parser.add_argument("--missing-field", choices=("missing_prerequisites", "unsupported", "missing_by_claim"), default="missing_prerequisites")
    parser.add_argument("--budget", type=int)
    parser.add_argument("--stream", action="store_true", help="Read a whole-stream JSON object (or {sourceHash,result} wrapper)")
    parser.add_argument("--source-hash", help="Expected frozen implementation hash for capability binding")
    parser.add_argument("--cost-events", type=Path, help="Raw event JSONL to reconcile for this whole stream")
    args = parser.parse_args()
    if args.stream:
        loaded = json.loads(args.observations.read_text(encoding="utf-8"))
        result = loaded.get("result", loaded)
        report = verify_stream(result)
        report["retention"] = verify_retention(result, args.source_hash or loaded.get("sourceHash"))
        report["errors"].extend("retention: " + error for error in report["retention"]["errors"])
        if args.cost_events:
            report["cost_events"] = verify_cost_events(result, load_jsonl(args.cost_events))
            report["errors"].extend("cost_events: " + error for error in report["cost_events"]["errors"])
        report["pass"] = not report["errors"]
    else:
        rows = load_jsonl(args.observations)
        report = verify_rows(rows, score_unit=args.score_unit, missing_field=args.missing_field, budget=args.budget)
    report["input_sha256"] = hashlib.sha256(args.observations.read_bytes()).hexdigest()
    report["checker_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"pass": report["pass"], "observations": report["observations"],
                      "errors": len(report["errors"]), "output": str(args.output)}))
    return 0 if report["pass"] else 1


if __name__ == "__main__":
    sys.exit(main())
