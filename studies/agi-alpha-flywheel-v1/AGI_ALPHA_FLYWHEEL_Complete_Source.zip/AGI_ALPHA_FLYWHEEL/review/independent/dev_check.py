#!/usr/bin/env python3
"""Hand-authored preconfirmation mathematical controls, not experimental data."""
import json
from pathlib import Path
from verify import (InvalidRecord, evaluate, verify_rows, verify_cost_events,
                    verify_capability, domain_digest, COST_FIELDS)


def doc(items):
    return {"schema": "source-document/v1", "title": "Independent checker development toy",
            "source_url": "https://example.org/independent-development-toy",
            "public_non_personal": True,
            "claims": [{"id": name, "weight": weight, "depends_on": deps,
                        "text": f"Synthetic development clause {name}.",
                        "provenance": "Independent checker hand-authored toy"}
                       for name, weight, deps in items]}


source = doc([("c", 2, []), ("g", 9, ["c"]), ("d", 7, [])])
records = []
for cap, selected, optimum, score, qualified in (
        (1, ["d"], 7, 7, True),
        (1, ["g"], 7, 0, False),
        (2, ["c", "g"], 11, 11, True),
        (2, ["g", "d"], 11, 7, False)):
    actual = evaluate(source, cap, selected)
    assert actual["optimum_weight"] == optimum
    assert actual["selected_weight"] == score
    assert actual["qualified"] is qualified
    records.append({"control": f"cap{cap}-{'-'.join(selected)}", "pass": True,
                    "result": actual})

diamond = doc([("a", 1, []), ("b", 3, ["a"]),
               ("c", 4, ["a"]), ("d", 20, ["b", "c"])])
actual = evaluate(diamond, 3, ["b", "c", "d"])
assert actual["optimum_weight"] == 8
assert actual["selected_weight"] == 0
assert actual["missing_prerequisites"] == ["a"]
records.append({"control": "transitive-diamond", "pass": True, "result": actual})

tie = evaluate(doc([("z", 2, []), ("a", 2, []), ("b", 2, [])]), 1, ["b"])
assert tie["optimum_weight"] == 2 and tie["optimal_set_count"] == 3
assert tie["optimal_selected"] == ["a"] and tie["qualified"]
records.append({"control": "equal-optima", "pass": True, "result": tie})

try:
    evaluate(doc([("a", 1, ["b"]), ("b", 2, ["a"])]), 1, ["a"])
except InvalidRecord:
    records.append({"control": "cycle-rejected", "pass": True})
else:
    raise AssertionError("cyclic graph was accepted")

row = {"stream": "development", "arm": "toy", "epoch": 0,
       "mission_id": "manual-toy", "document": source, "max_clauses": 2,
       "method": "hand-authored-fixture", "selected": ["c", "g"],
       "structural_score": 11, "optimal_score": 11, "missing": [],
       "qualified": True, "status": "completed", "cost_before": 0,
       "cost_after": 10, "cost_breakdown": {"construction": 2, "qualification": 2,
       "execution": 3, "validation": 2, "retention": 1, "maintenance": 0, "routing": 0, "runtime": 0},
       "elapsed_ns": 0, "capability_digest": None}
assert verify_rows([row], budget=10)["pass"]
bad = dict(row, qualified=False)
assert not verify_rows([bad], budget=10)["pass"]
bad = dict(row, cost_after=9)
assert not verify_rows([bad], budget=10)["pass"]
records.extend([
    {"control": "valid-toy-receipt", "pass": True},
    {"control": "tampered-quality-rejected", "pass": True},
    {"control": "tampered-cost-rejected", "pass": True},
])

events = []
running = 0
for field in COST_FIELDS:
    units = row["cost_breakdown"][field]
    running += units
    events.append({"epoch": 0, "category": field, "units": units,
                   "operation": "manual-dev-charge", "cumulative": running})
event_stream = {"stream": "development", "arm": "toy", "budget": 10, "spent": 10,
                "generations": [{"epoch": 0, "costs": row["cost_breakdown"]}]}
assert verify_cost_events(event_stream, events)["pass"]
tampered_events = [dict(event) for event in events]
tampered_events[2]["cumulative"] += 1
assert not verify_cost_events(event_stream, tampered_events)["pass"]
records.extend([
    {"control": "complete-event-ledger", "pass": True},
    {"control": "tampered-cumulative-event-rejected", "pass": True},
])

capability = {"schema": "flywheel-capability/v1", "method": "dev-only-method",
              "scope": "dev-only", "sourceHash": "0" * 64, "created_epoch": 0,
              "proof": [], "authority": [], "reuse": "Fresh result checks remain required."}
capability["digest"] = domain_digest("flywheel-capability", capability)
capability["validated_epoch"] = 0
capability["last_used_epoch"] = 1
assert not verify_capability(capability, 1, "0" * 64)
assert verify_capability(capability, 1, "1" * 64)
bad_capability = dict(capability, authority=["inherited-authority"])
assert verify_capability(bad_capability, 1, "0" * 64)
records.extend([
    {"control": "valid-capability-hash", "pass": True},
    {"control": "changed-source-capability-rejected", "pass": True},
    {"control": "inherited-authority-rejected", "pass": True},
])

declared = doc([("target", 10, []), ("calibration", 1, [])])
truth = doc([("target", 10, ["calibration"]), ("calibration", 1, [])])
assert evaluate(declared, 1, ["target"])["qualified"]
assert not evaluate(truth, 1, ["target"])["qualified"]
records.append({"control": "annotation-omission-limits-checker", "pass": True,
                "meaning": "A correct structural calculation cannot repair an omitted real prerequisite."})
out = Path(__file__).with_name("development-verification.json")
out.write_text(json.dumps({"scope": "hand-authored development controls only",
                           "confirmatory_inputs_seen": False, "controls": records,
                           "pass": True}, indent=2) + "\n")
print(json.dumps({"pass": True, "controls": len(records), "output": str(out)}))
