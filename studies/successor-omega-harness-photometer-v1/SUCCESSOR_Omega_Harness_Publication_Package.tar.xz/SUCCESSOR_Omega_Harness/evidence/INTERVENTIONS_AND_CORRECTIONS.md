# Interventions, failures and corrections

This record accompanies the SUCCESSOR Ω Harness photometer edition. The machine-readable `EVIDENCE_DOCKET.json` maps paper claims C01–C09 to exact package-relative artifacts and SHA-256 hashes. Original numerical results, earlier development records and later explanatory corrections retain their separate identities.

## Authorship, oversight and unknown costs

The instrument model, finite constructor grammar, validators, comparison policies and runtime adapters were supplied by the researchers. The “expert” comparator is a deterministic sufficient-design program. No human expert productivity trial or physical detector experiment was conducted. The role keys and the separately implemented artifact auditor are controlled within one research effort; implementation separation does not establish organizational independence.

The primary scientific campaigns required zero interactive prompts and zero manual overrides while running. The runtime crash demonstration required one scripted controller recovery decision. These counts describe execution of prepared scripts. Authoring, integration, review, troubleshooting and a future operator’s judgment were not timed prospectively. Their costs are **unknown, not zero**. Human participant minutes, infrastructure allocation prices, electricity/depreciation and commercial value are unmeasured.

The scientific resource coordinates are counted rational operations, simulated detector acquisitions, and measured process/wall time. Runtime dispatch reservations, journal persistence and recovery add their own costs. They have no asserted common exchange rate. No outbound payment or financial transaction occurs in the demonstration; this does not establish a zero-cost research project or realized profit.

Primary disclosures: `companion/experiment/results/interventions.json`, `companion/experiment/results/campaigns.json`, `companion/integration/INTEGRATION_RESULTS.json`, and `companion/benchmark/protocol.json`.

## Corrections before the frozen scientific campaigns

The retained scientific pilot preceded review and the implementation freeze. Its separate source identity remains development evidence under `companion/experiment/development/` and `demo_pilot.json`.

Pre-main review led to concrete changes: admitted time/control programs and world metadata are checked; the full bounded-noise calibrated risk includes its large-noise branch; the parent nuisance recipe is actually parsed and evaluated on the new grid; parent verification work and all seven callback stages are charged. The shorter risk expression in the original protocol is equivalent for accepted designs at the declared .02 threshold; the implementation evaluates the full expression. The protocol’s thresholds, candidate grammar, budgets and campaign seeds were not changed after seeing main outcomes.

`companion/experiment/pre_main_clarification.json` records these changes and their timing. `implementation_freeze.json` binds the evaluated protocol and three Python source/test files. `verification_record.json` confirms the frozen source files remain unchanged, eighteen scientific tests pass, and the complete main study reproduces its scientific records after timing fields are excluded.

The parent recipe is a useful representation with provenance, but it is not necessary for a competent direct constructor to build the joint decoder. Parent integrity checks add 49 counted operations to the first transition. The shared solver existed before the ancestor mission. These interpretations were made explicit before the main campaigns and are preserved in the final conclusions.

## Runtime development failures retained

`companion/integration/development_failures.json` records two corrections before final runtime evidence:

| Record | Observed problem | Correction and scope |
|---|---|---|
| I001 | The initial smoke supplied an undeclared `acceptance_rule` field to `MissionConstitution`; strict validation rejected it before a graph executed. | Use the existing `constraints` field and explicit job `acceptance_conditions`. No released schema or vendor source was changed. |
| I002 | Initial pipeline JSON snapshots preceded proof/inspection operations, so the ledger snapshot omitted the later inspection and proof-count naming was ambiguous. | Name the pre-qualification counts explicitly, refresh final counters/ledger after qualification, and retain the earlier development records. Full original event histories and total demo timing were not replaced. |

Final nominal, crash and negative-transfer records are under `companion/integration/evidence/`. The separate `development-*` records are not substituted for these final runs.

## Failures and comparator wins that remain results

All four scientific policies qualify 192 of 192 missions under the frozen resource vector. Harness and conventional reuse have the same scientific outputs and 609,524 counted operations each. The sufficient expert program uses 169,732 operations; exhaustive reconstruction uses 7,953,264. The study retains the coverage tie and expert win. No post-result threshold change makes the proposed method appear superior.

The nine scientific negative controls preserve seven intended refusals and two internally accepted failures against simulator truth: gain changing between reference and sample, and interference shaped like a valid signal. Hashes, narrow intervals and exact cancellation identities cannot establish an unobserved world assumption. `companion/experiment/results/failure_map.json` retains `accepted:true` and `oracle_qualified:false` together for those two cases.

The shared negative-control capability construction costs 46,992 counted operations. The separate scientific correction/recovery sequence costs 70,478 additional operations and 24 simulated readings. The post-main deterministic candidate audit records the finite rejected proposals without relabeling its audit work as part of the primary budgeted experiment.

The final runtime crash test observes an extra eight simulated readings and 82 operations in the injected lost computation. The journal preserves the first attempt as uncertain and charges its full reservation; it does not silently acquire the test observer’s knowledge. The negative-transfer runtime run retains 1,617 counted operations **plus unknown rejected-design computation**. Its failed callback did not return a counter, so the missing compute is not zero.

The original thirteen runtime controls include a deliberately accepted physical falsehood signed by the configured acceptance role. “13/13 expected behaviors matched” includes this semantic limitation. Two separately frozen controls test STOP and expiry during computation. The callback may finish; the post-handler boundary suppresses its output. There is no hard real-time preemption guarantee or dedicated cancellation enum.

The direct durable loop wins the nominal load overhead comparison. That loop has the same scientific callbacks, cache, journal and signature primitives, while omitting the full successor lifecycle. The eighteen batches retain all timings and matching-science checks. The result is a scoped nominal ablation, not a demonstrated comparison of equivalent production governance. Increasing the batch changes queue length rather than worker concurrency.

## Fresh setup: original failures and successful correction

`reproduction/setup/commands.json` retains the exact commands and observed outcomes. A new virtual environment was created without system site packages. Two sandboxed pip invocations returned “no matching distribution” for the first pinned requirement. Their outputs are retained. The same exact pins then downloaded and installed successfully from public PyPI under approved network-enabled execution. The first outputs alone do not establish that the versions were unavailable or identify the precise cause of the failed attempts.

The successful environment passed `pip check`, executed the copied package’s actual nominal journey, and passed the independent artifact verifier: 106 events, fourteen accepted stage receipts, 34 role envelopes, 47,956 counted operations and twenty simulated detector readings. Installed versions, venv configuration and the full new run are retained under `reproduction/setup/`. The verification virtual environment itself is excluded from the publication package.

This is a clean installation of companion dependencies followed by released-source execution. It is not installation or execution of the full Alpha product or its normal credential-producing initializer.

## Final explanatory and interface corrections

The initial package review and the later correction check are retained separately as `evidence/review/package_review.json` and `package_review_corrections.json`. The following seven findings were addressed in documentation, interface presentation or the paper:

1. Replace an “installed Alpha integration” phrase with “released-source Alpha runtime integration.”
2. Mark a rejected design stage as rejected rather than completed.
3. Display a missing failed-callback operation count as unknown; do not coerce `null` to zero.
4. Use the actual stage record’s `family` field.
5. Describe recovery as preserving the interrupted attempt, rather than claiming to preserve an unretained lost result.
6. Scope duplicate suppression to the tuple of institution, job, authorization and invocation identifier. A fresh authorized attempt may reuse the invocation’s string label.
7. Describe durable STOP/expiry refusals without inventing a dedicated cancellation state or asynchronous preemption.

These corrections did not change the frozen scientific constructor, adapter, released source closure, measured campaigns or raw final runtime histories. All 27 integration source-manifest file hashes matched after the correction check. Final visual inspection and build results have their own root-owned records under `reproduction/`.

## Public fixtures, authority and unrun connections

The fixture audit verifies the three published RFC 8032 Ed25519 known-answer vectors, the exact released journal schema, and the eleven byte-identical vendor files. Eighteen retained benchmark `identity.key` files contain the same deliberately public vector-1 seed. These are reproducible test data and cannot authenticate a real user or service. The fixture does not generate a new secret or API token and does not call the standard Alpha initializer.

Historical evidence can transfer with provenance; current proof and grants restart. Recovery does not clear a retained STOP or restore expired authority. The study exercises no financial action, production grant, deployed contract read, local EVM campaign, Jobs/Manager admission, Fleet worker or held Harness overlay. Their `NOT_RUN` labels remain explicit. A new research source branch or draft handoff does not establish a merged release or a deployed website.

The original review JSON files retain historical workspace-relative references. `evidence/review/RELOCATION_MAP.json` maps those references to their delivered package locations without rewriting their original contents.


## Final document and UI presentation corrections

The first complete PDF was rendered before acceptance. Visual review found collisions in the architecture transfer label, recovery timeline, lineage footer and failure-map footer. These vector layouts were corrected without changing experimental sources or outcomes. Review also found LaTeX typography converting CLI double hyphens to en dashes and omitting a visible continuation backslash; all reproduction commands now use literal verbatim text. Original review records retain the initial defects. The final source compiles with no overfull boxes, missing glyph warnings or unresolved citations.

After the164-check local UI pass, the Out-Think description received a wording-only precision correction: nuisance rank and necessary dimension are computed there, and full candidates are checked during design. The156-check standalone replay pass records that final wording and verifies offline behavior. Displayed error bounds and interval radii round outward. The replay is explicitly recorded evidence; it is not represented as fresh Python execution.
