# SUCCESSOR Ω Harness

## Make Every Mission Build What Comes Next

**Powered by TRANSFORMATIONAL INTELLIGENCE ∞.**  
**For TRANSFORMATIONAL AUTONOMOUS ENTERPRISES: ACTIVATE. EVOLVE. SCALE.**

This publication package contains the finished research paper, complete compilable source, original vector figures, a working local demonstration and the frozen evidence behind its claims. Start with `SUCCESSOR_Omega_Harness.pdf`. This README is an operating guide, not a substitute for the paper.

## A three-minute demonstration

The mission constructs an exact drift-rejecting virtual photometer, calibrates it, and uses the accepted result to help construct a distinct two-signal instrument. A scalar answer cannot meet the new output contract. The successor requires a new measurement program, fresh qualification and a separately scoped local grant.

The interactive `SUCCESSOR_Omega_Demo.html` can be opened directly for a clearly labelled **recorded evidence replay**. To execute the actual released-source runtime on your computer, use CPython **3.12.14**, then run these commands from the extracted package directory:

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r companion/requirements.txt
.venv/bin/python companion/serve.py
```

Open **http://127.0.0.1:8765**. Setup downloads the pinned packages once; the demonstration itself requires no external service, account, model-provider credential or wallet. A fresh-venv installation and an actual nominal run were verified; see `reproduction/setup/`. Scientific calculations use Python's standard library. Other Python/platform combinations have not been newly qualified here.

1. **Build what comes next.** Follow the scalar ancestor and joint successor. Inspect raw readings, exact decoder weights, seven stage artifacts, fresh evidence and the authority boundary.
2. **Interrupt and recover.** Inject a loss after pure computation but before retention. The same attempt is refused on replay. A new authorized attempt recovers while the uncertain original remains in history.
3. **Ask for the impossible.** Request a two-signal instrument that also cancels quartic background within six samples. The child is rejected, downstream stages remain unrun, and the accepted incumbent is retained.

Download the JSON evidence ZIP after a fresh run. The browser reports genuine callback and journal outputs. A rejected stage is labelled rejected; a lost operation counter is unknown. The server accepts only the three fixed scenarios, binds to loopback, and writes new run directories. Stop it with Ctrl+C. Override the port or run directory with `--port` and `--runs`.

## What the evidence says

| Scientific policy | Qualified missions | Counted rational operations | Simulated readings |
|---|---:|---:|---:|
| Harness reuse | 192/192 | 609,524 | 2,112 |
| Competent conventional reuse | 192/192 | 609,524 | 2,112 |
| Expert-coded sufficient construction | 192/192 | 169,732 | 2,112 |
| Exhaustive rebuilding | 192/192 | 7,953,264 | 2,112 |

The fixed budget produces **zero coverage advantage** for the Harness. Ordinary caching matches its scientific benefit. The sufficient expert construction uses the least counted work. The first scalar-to-joint inheritance transition costs **49 more** rational operations than direct fresh construction. These losses are retained, not hidden behind the title.

The useful change is a new measurement capability: the joint instrument estimates two amplitudes with six reference plus six sample readings. Two separately calibrated scalar procedures would require sixteen. A competent conventional or expert constructor is allowed the same joint design and matches the twelve-reading result. The comparison does not establish a universal sixteen-reading lower bound.

The actual released Alpha dispatcher completes the nominal two-mission journey with **106 verified events and 14 accepted stage receipts**. The crash scenario retains 112 events; the impossible successor retains 84. The independent artifact auditor does not import the scientific constructor or runtime. The load study retains 18 batches and 246 qualified executions. A smaller direct durable nominal workflow is faster; it does not implement all lifecycle features of the Alpha arm.

Seven of nine scientific negative controls are refused before acquisition. Two are internally accepted but fail against simulator truth: changing gain between reference and sample, and signal-shaped interference. Exact algebra does not prove a true physical model. All readings are simulated; no physical detector was operated.

Counted numerical work, simulated acquisitions, host time, measured spending and unknown labor are separate quantities. No monetary savings, profit, equal human engineering hours, independent organizational review, demand or production deployment is established.

## Reproduce and verify

Verify the archived payload without executing its research code:

```sh
python3 verify_manifest.py
```

Rerun all 768 method–mission observations, eighteen scientific tests and eleven comparison targets. Choose an empty output directory; original evidence is never overwritten:

```sh
python3 companion/experiment/reproduce.py --output runs/science
```

Execute an actual released-source journey and audit the newly produced evidence:

```sh
.venv/bin/python companion/integration/run_integration.py --output runs/nominal --scenario nominal
.venv/bin/python companion/integration/verify_evidence.py runs/nominal
```

Use `--scenario crash` or `--scenario negative_transfer` for the other bounded demonstrations. Additional controls:

```sh
.venv/bin/python companion/integration/run_controls.py --output runs/controls
.venv/bin/python companion/integration/run_boundary_controls.py --output runs/boundaries
.venv/bin/python companion/integration/audit_fixtures.py --output runs/fixture-audit.json
```

Reproduce the longer load study on an otherwise idle computer:

```sh
.venv/bin/python companion/benchmark/run_benchmark.py --output runs/load --expected-instrument-sha ea7d3a4cc01a3733c8983899f95ed8ae93a5ca79a8efc2ae7a8e56894dc78c2b
.venv/bin/python companion/benchmark/check_replay_guards.py --results runs/load --output runs/load-replay-checks.json
```

Machine timings, fresh event timestamps and grants are expected to differ. Exact scientific results and counters are compared separately. A historical signature does not make an expired grant current.

## Rebuild the paper

The complete `SUCCESSOR_Omega_Harness.tex` embeds all sections, vector figures and the resolved bibliography. A TeX Live installation with the packages named in its preamble can compile it directly, without shell escape or network access:

```sh
pdflatex -interaction=nonstopmode -halt-on-error SUCCESSOR_Omega_Harness.tex
pdflatex -interaction=nonstopmode -halt-on-error SUCCESSOR_Omega_Harness.tex
```

For the editable modular source, bibliography regeneration and PDF/SVG figure exports, use `python3 build_paper.py`. This requires `latexmk`, `pdflatex`, `bibtex` and `pdftocairo`. The build script fixes PDF metadata and verifies stabilization after reference resolution. Same-toolchain byte identity is tested; identical output across different TeX distributions is not promised. `reproduction/` records the actual build, reproduction and visual inspection.

## Files and provenance

| Path | Contents |
|---|---|
| `SUCCESSOR_Omega_Harness.pdf` / `.tex` | Finished paper and complete standalone source |
| `paper/` | Editable modular LaTeX, bibliography, original TikZ/PGFPlots figures plus PDF/SVG exports |
| `companion/web/`, `companion/serve.py` | Local interactive demonstration |
| `companion/experiment/` | Frozen scientific protocol, source, tests, raw missions, failures and exact reproduction wrapper |
| `companion/integration/` | Released-source adapter, eleven original Alpha dependency files, public fixtures, actual run evidence and independent auditor |
| `companion/benchmark/` | Separately frozen load protocol, paired implementations, all journals and raw timings |
| `sources/foundations/` | Unmodified seven-paper TI/Out-stage PDF and TeX corpus with hashes |
| `sources/audit/` | Repository and five-contract source audit, exact versions, retained public coordination evidence |
| `evidence/` | Claim-to-artifact docket, review and intervention disclosures |
| `reproduction/` | Setup, exact scientific replay, packaged rebuild and page inspection records |
| `publication/` | Additive owner handoff, proposed catalogue text and review boundaries |
| `MANIFEST.json`, `SHA256SUMS` | Payload file identities; manifest files exclude themselves |

The source papers, original protocols and original research results retain their own identities. Later review corrections are disclosed separately. There is no hidden external dataset or model call in the companion.

## Integration scope and ownership

The exercised seam is Alpha v1.41.0 commit `031bdb5d055c8bad896daa076baea2b5e17b242c`: `JobDispatcher.execute_tool` with real handlers and retained outputs, the signed SQLite journal, typed contracts, successor store and trust registry. This is **released-source dependency-closure execution**, not a newly installed complete Alpha product or a deployed four-repository integration. The held Harness PR and Fleet candidate are not imported, adopted or activated. Jobs, Manager, EVM execution, deployed contract reads and settlement are explicitly unrun in this experiment.

The fixture uses only the openly published RFC8032 test-vector seeds. They are reproducible public data, not newly generated credentials or production identities. The normal private initializer is not exercised. All roles are scripted by one operator; their distinct envelopes do not establish independent people.

The five Alpha contracts are analyzed from exact source. Their verified commitments, eligibility checks, bounded jobs and settlement interfaces are distinguished from scientific truth and current authorization. Alpha's `$AGIALPHA` route is separate from Manager's USDC route. The companion initiates no transactions.

Publication coordination is through [Alpha issue #4850](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/issues/4850). The proposed isolated study is `studies/successor-omega-harness-photometer-v1`. Shared catalogue edits, reviews, merge, Pages publication and served-byte verification remain the existing owners' process. A draft source handoff or downloadable package is not a deployed website.

## Notices

New companion implementation is Apache-2.0, as marked in source. Original Alpha notices and license are preserved in `companion/integration/vendor/`. Foundation papers retain their original authorship and notices; this package does not relabel them as new work. Research and manuscript preparation used AI assistance, disclosed in the paper. No independent peer review is claimed.

**Don’t just complete the mission. Build what the next mission can become.**
