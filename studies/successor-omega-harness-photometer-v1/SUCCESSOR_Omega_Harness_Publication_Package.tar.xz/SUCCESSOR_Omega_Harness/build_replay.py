#!/usr/bin/env python3
"""Produce a single offline HTML viewer of the three preserved research runs."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
WEB = ROOT / 'companion/web'


def main():
    records = {name: json.loads((ROOT / 'companion/integration/evidence' / directory / 'demo.json').read_text())
               for name, directory in [('nominal', 'nominal'), ('crash', 'crash'), ('negative_transfer', 'negative-transfer')]}
    study = json.loads((WEB / 'study.json').read_text())
    payload = json.dumps({'records': records, 'study': study}, separators=(',', ':')).replace('</', '<\\/')
    shim = '''const ARCHIVED = __PAYLOAD__;
window.fetch = async function(url, options) {
  if (url === '/api/status') return new Response(JSON.stringify({status:'recorded'}));
  if (url === 'study.json') return new Response(JSON.stringify(ARCHIVED.study));
  if (url === '/api/run') {
    const scenario = JSON.parse(options.body).scenario;
    return new Response(JSON.stringify({result:ARCHIVED.records[scenario],download_url:'recorded'}));
  }
  throw new Error('This offline viewer makes no network requests.');
};
'''.replace('__PAYLOAD__', payload)
    script = (WEB / 'app.js').read_text()
    replacements = {
        'Running real local computation': 'Replaying preserved evidence',
        'Constructing the instrument, recording each stage, and qualifying the successor…': 'Opening the source-pinned recorded run…',
        'Executed in ${small(current.elapsed_ns/1e9,2)} s': 'Recorded execution: ${small(current.elapsed_ns/1e9,2)} s',
        'Local companion ready': 'Recorded evidence · offline viewer',
        'Launch local companion': 'Recorded evidence viewer',
        "$('download').addEventListener('click',()=>{if(exportUrl)window.location.assign(exportUrl);});":
        "$('download').addEventListener('click',()=>{if(!current)return;const a=document.createElement('a');const u=URL.createObjectURL(new Blob([JSON.stringify(current,null,2)],{type:'application/json'}));a.href=u;a.download='SUCCESSOR_Omega-recorded-evidence.json';a.click();setTimeout(()=>URL.revokeObjectURL(u),1000);});"
    }
    for old, new in replacements.items():
        if old not in script:
            raise ValueError('UI source changed; review replay substitution: ' + old)
        script = script.replace(old, new)
    html = (WEB / 'index.html').read_text()
    html = html.replace('<link rel="stylesheet" href="style.css"><script src="app.js" defer></script>',
                        '<style>' + (WEB / 'style.css').read_text() + '</style>')
    replacements = {
        'Checking local companion': 'Recorded evidence · offline viewer',
        'Run the connected experiment': 'Explore the recorded experiment',
        'A virtual photometer. Real local computation.<br>No wallet, account or remote worker required.':
        'A virtual photometer. Preserved evidence.<br>Fresh execution is included in the local companion.',
        'THE WORKING DEMONSTRATION': 'RECORDED EVIDENCE REPLAY',
        'Ready to construct': 'Ready to inspect a recorded run',
        'Construct & qualify</strong>': 'Replay: construct & qualify</strong>',
        'Interrupt & recover</strong>': 'Replay: interrupt & recover</strong>',
        'Find the limit</strong>': 'Replay: find the limit</strong>',
        'Choose a scenario to run the actual released-source dispatcher and scientific callbacks on this computer.':
        'Choose a preserved source-pinned run. This standalone file replays evidence; it does not execute Python. For fresh execution: install the package dependencies and run python companion/serve.py.',
        'Your actual acquired readings and recovered amplitudes will appear here.':
        'Recorded acquired readings and recovered amplitudes will appear here.',
        'The detector is simulated. The constructor, estimator and validators execute.':
        'The detector was simulated. The constructor, estimator and validators executed in the preserved run.',
        'Download this run ↓': 'Download recorded JSON ↓',
        '<b>Executed here:</b>': '<b>Recorded execution:</b>',
        'Local, inspectable, bounded.': 'Recorded replay · fresh execution included in the package.'
    }
    for old, new in replacements.items():
        if old not in html:
            raise ValueError('UI source changed; review HTML substitution: ' + old)
        html = html.replace(old, new)
    html = html.replace('</body>', '<script>' + shim + script + '</script></body>')
    dest = ROOT / 'SUCCESSOR_Omega_Demo.html'
    dest.write_text(html)
    print(json.dumps({'path': str(dest), 'bytes': dest.stat().st_size,
                      'mode': 'recorded evidence replay; fresh Python execution requires local companion'}))


if __name__ == '__main__':
    main()
