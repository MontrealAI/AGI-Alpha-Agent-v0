#!/usr/bin/env python3
"""Build modular and complete-source papers, and export editable vector figures."""
import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PAPER = ROOT / 'paper'


def run(command, cwd, log, env):
    result = subprocess.run(command, cwd=cwd, env=env, text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    log.write_text(result.stdout)
    if result.returncode:
        raise SystemExit(f'Build failed; inspect {log}')


def expand(path):
    text = path.read_text()
    def replace(match):
        child = PAPER / match.group(1)
        if not child.suffix:
            child = child.with_suffix('.tex')
        if not child.resolve().is_relative_to(PAPER):
            raise ValueError('An input leaves the paper source directory.')
        return '\n% BEGIN ' + str(child.relative_to(PAPER)) + '\n' + expand(child) + '\n% END input\n'
    return re.sub(r'\\input\{([^}]+)\}', replace, text)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=ROOT / 'build')
    parser.add_argument('--skip-figures', action='store_true')
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ, SOURCE_DATE_EPOCH='1792800000', FORCE_SOURCE_DATE='1', TZ='UTC')
    modular = output / 'modular'
    modular.mkdir(exist_ok=True)
    for item in PAPER.rglob('*'):
        if item.is_file() and item.suffix in {'.tex', '.bib'}:
            target = modular / item.relative_to(PAPER)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(item, target)
    run(['latexmk', '-pdf', '-g', '-interaction=nonstopmode', '-halt-on-error', 'main.tex'],
        modular, output / 'modular-build.log', env)
    source = expand(PAPER / 'main.tex')
    source = re.sub(r'\\bibliographystyle\{[^}]+\}\s*\\bibliography\{references\}',
                    lambda _: (modular / 'main.bbl').read_text(), source)
    source = '% Complete source. Build with pdflatex twice. No shell escape or external figures.\n' + source
    complete = ROOT / 'SUCCESSOR_Omega_Harness.tex'
    complete.write_text(source)
    standalone = output / 'standalone'
    standalone.mkdir(exist_ok=True)
    shutil.copy2(complete, standalone / complete.name)
    hashes = []
    for pass_number in range(1, 4):
        run(['pdflatex', '-interaction=nonstopmode', '-halt-on-error', complete.name], standalone,
            standalone / f'pass-{pass_number}.log', env)
        hashes.append(hashlib.sha256((standalone / complete.with_suffix('.pdf').name).read_bytes()).hexdigest())
    if hashes[1] != hashes[2]:
        raise SystemExit('The standalone paper did not stabilize after references resolved.')
    shutil.copy2(standalone / complete.with_suffix('.pdf').name, ROOT / complete.with_suffix('.pdf').name)
    if not args.skip_figures:
        for name in ('architecture', 'recovery', 'lineage', 'comparison', 'failure_map'):
            dest = output / ('figure-' + name)
            dest.mkdir(exist_ok=True)
            preamble = (PAPER / 'main.tex').read_text().split('\\begin{document}', 1)[0]
            preamble = preamble.replace('\\documentclass[11pt]{article}', '\\documentclass[border=5mm,varwidth=166mm]{standalone}')
            preamble = re.sub(r'\\usepackage\[a4paper[^\n]+\n', '', preamble)
            body = preamble + '\n\\begin{document}\n\\centering\n' + (PAPER / 'figures' / (name + '.tex')).read_text() + '\n\\end{document}\n'
            (dest / (name + '.tex')).write_text(body)
            run(['pdflatex', '-interaction=nonstopmode', '-halt-on-error', name + '.tex'], dest, dest / 'build.log', env)
            shutil.copy2(dest / (name + '.pdf'), PAPER / 'figures' / (name + '.pdf'))
            run(['pdftocairo', '-svg', str(dest / (name + '.pdf')), str(PAPER / 'figures' / (name + '.svg'))],
                dest, dest / 'svg.log', env)
    record = {'complete_tex_sha256': hashlib.sha256(complete.read_bytes()).hexdigest(),
              'standalone_pdf_sha256': hashes[-1], 'pass2_equals_pass3': hashes[1] == hashes[2],
              'passes': hashes, 'source_date_epoch': env['SOURCE_DATE_EPOCH'],
              'scope': 'Same recorded TeX toolchain; byte identity across different TeX distributions is not promised.'}
    (output / 'build_record.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record, indent=2))


if __name__ == '__main__':
    main()
