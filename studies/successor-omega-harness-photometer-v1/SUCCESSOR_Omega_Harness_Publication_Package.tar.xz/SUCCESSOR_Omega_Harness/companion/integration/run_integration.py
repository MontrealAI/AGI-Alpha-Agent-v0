# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import argparse
import base64
import hashlib
import importlib.metadata
import json
import os
import platform
import sqlite3
import sys
import tempfile
import time
from copy import deepcopy
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any, Callable

HERE = Path(__file__).resolve().parent
_vendor_manifest = json.loads((HERE / "VENDOR_MANIFEST.json").read_text())
for _entry in _vendor_manifest["files"]:
    _path = HERE / "vendor" / _entry["path"]
    if _path.is_symlink() or hashlib.sha256(_path.read_bytes()).hexdigest() != _entry["sha256"]:
        raise ValueError("Pinned Alpha dependency changed before import: " + _entry["path"])
sys.path.insert(0, str(HERE / "vendor"))
sys.path.insert(0, str(HERE.parent / "experiment"))

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat

from alpha_factory_v1.core.runtime.models import RuntimeConfig
from alpha_factory_v1.core.runtime.store import Conflict, Journal, canonical as journal_canonical, digest as journal_digest
from alpha_factory_v1.core.runtime.successor.jobs import JobDispatcher, JobResult
from alpha_factory_v1.core.runtime.successor.protocol import (
    AdmissionDecision, AuthorityEnvelope, BehaviorArtifact, CandidateReleaseManifest, ExecutionAuthorization,
    Institution, JobContract, JobDependency, JobGraph, MissionConstitution, ProofReceipt, ResourceBudget,
    VerifierDisclosure, canonical, digest,
)
from alpha_factory_v1.core.runtime.successor.state import ActionGateway, ActionRequest, SuccessorStore
from alpha_factory_v1.core.runtime.successor.trust import JournalCheckpoint, TrustAnchor, TrustRegistry, sign_record

ALPHA_COMMIT = "031bdb5d055c8bad896daa076baea2b5e17b242c"
STAGES = ("identify", "out_learn", "out_think", "out_design", "out_strategise", "out_execute", "out_evolve")
FAMILIES = ("constitution", "evidence", "challenge", "formation", "admission", "verification", "renewal")
FIXTURE_SCOPE = (
    "PUBLIC RFC 8032 test vectors: insecure for identity/authentication; offline fixture only. "
    "No service, API token, wallet, new credential or external authority. Manual fixture bootstrap, "
    "unchanged released Journal/JobDispatcher code; installed-package initializer NOT_RUN."
)
PUBLIC_TEST_SEEDS = {
    "local-controller": "9d61b19deffd5a60ba844af492ec2cc44449c5697b326919703bac031cae7f60",
    "local-producer": "4ccd089b28ff96da9db6c346ec114e0f5b8a319f35aba624da8cf6ed4fb8a6fb",
    "local-verifier": "c5aa8df43f9f837bedb7442f31dcb7b166d38535076f094b85ce3a2e0b4458f7",
}
ROLES = {
    "local-controller": {"controller", "admission", "authority", "acceptance", "control", "worker"},
    "local-producer": {"producer", "worker"},
    "local-verifier": {"verifier", "acceptance", "worker"},
}


def stamp(offset: int = 0) -> str:
    return (datetime.now(UTC) + timedelta(seconds=offset)).isoformat(timespec="seconds").replace("+00:00", "Z")


def dump(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + "\n", encoding="utf-8")


def verify_vendor() -> dict[str, Any]:
    manifest = json.loads((HERE / "VENDOR_MANIFEST.json").read_text())
    for row in manifest["files"]:
        path = HERE / "vendor" / row["path"]
        if path.is_symlink() or hashlib.sha256(path.read_bytes()).hexdigest() != row["sha256"]:
            raise ValueError("Pinned Alpha dependency changed: " + row["path"])
    return manifest


def fixture_journal(root: Path) -> tuple[Journal, TrustRegistry, dict[str, Ed25519PrivateKey]]:
    root.mkdir(parents=True, exist_ok=False, mode=0o700)
    config = RuntimeConfig()
    (root / "config.json").write_bytes(journal_canonical(config.model_dump()))
    (root / "identity.key").write_bytes(bytes.fromhex(PUBLIC_TEST_SEEDS["local-controller"]))
    os.chmod(root / "identity.key", 0o600)
    with sqlite3.connect(root / "journal.sqlite3") as cx:
        cx.execute("PRAGMA journal_mode=WAL")
        cx.execute("CREATE TABLE events(seq INTEGER PRIMARY KEY, mission TEXT NOT NULL, body TEXT NOT NULL, hash TEXT NOT NULL UNIQUE, signature TEXT NOT NULL)")
        cx.execute("CREATE INDEX events_mission ON events(mission,seq)")
    journal = Journal(root)
    with journal.transaction() as cx:
        journal.append(cx, "@control", {"state": "ready", "config_hash": journal_digest(config.model_dump())})
        journal.append(cx, "@research-fixture", {"scope": FIXTURE_SCOPE, "source": "https://www.rfc-editor.org/rfc/rfc8032#section-7.1"})
    registry, keys = fixture_roles()
    return journal, registry, keys


def fixture_roles() -> tuple[TrustRegistry, dict[str, Ed25519PrivateKey]]:
    keys = {name: Ed25519PrivateKey.from_private_bytes(bytes.fromhex(seed)) for name, seed in PUBLIC_TEST_SEEDS.items()}
    registry = TrustRegistry({name: TrustAnchor(key.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw).hex(), frozenset(ROLES[name])) for name, key in keys.items()})
    return registry, keys


def environment() -> dict[str, Any]:
    return {"python": platform.python_version(), "platform": platform.system(), "machine": platform.machine(), "pydantic": importlib.metadata.version("pydantic"), "cryptography": importlib.metadata.version("cryptography"), "alpha_commit": ALPHA_COMMIT, "profile": "source-closure-public-fixture"}


def institution(store: SuccessorStore, name: str, source_hash: str, spec: dict[str, Any], parent: dict[str, Any] | None = None) -> tuple[CandidateReleaseManifest, str]:
    budget = ResourceBudget(limits={"calls": 32, "inspections": 4}, units={"calls": "bounded pure adapter dispatches", "inspections": "local artifact inspections"}, enforceable=["calls", "inspections"], unknown_costs=["author-labor", "independent-review", "real-detector-cost", "money"])
    constitution = MissionConstitution(mission_id=name, owner="local-controller", objective="Construct and independently check a nuisance-rejecting scientific instrument", scope="Synthetic measurement model; local fixture; no production or settlement", proof_requirements=["correctness"], authority_ceiling="sandbox", prohibited_actions=["network", "deploy", "settle", "production"], constraints=["Exact instrument algebra plus declared bounded-noise criterion"], budget=budget)
    store.create_institution(Institution(id=name, constitution=constitution, controller="local-controller", predecessor_id=parent["institution_id"] if parent else None), {"calls": 32, "inspections": 4})
    artifacts = [BehaviorArtifact(name="instrument-source", role="source", digest=source_hash), BehaviorArtifact(name="integration-source", role="source", digest=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()), BehaviorArtifact(name="alpha-source-manifest", role="dependency", digest=hashlib.sha256((HERE / "VENDOR_MANIFEST.json").read_bytes()).hexdigest()), BehaviorArtifact(name="frozen-protocol", role="policy", digest=hashlib.sha256((HERE.parent / "experiment" / "protocol.json").read_bytes()).hexdigest()), BehaviorArtifact(name="mission-spec", role="world", digest=digest("mission-spec", spec))]
    if parent:
        artifacts.append(BehaviorArtifact(name="parent-package", role="other", digest=digest("parent-package", parent["package"])))
    manifest = CandidateReleaseManifest(release_id=name + "-source-v1", institution_id=name, mission_id=name, producer="local-producer", environment_digest=digest("instrument-environment", environment()), artifacts=artifacts, world_digest=digest("world", spec), policy_digest=digest("policy", {"publicOnly": True, "production": False, "currency": "none"}), parent_release_digest=parent["release_digest"] if parent else None, configuration={"instrument": "exact-rational-demodulation", "fixture": "public-test-vector", "signals": spec["signals"], "drift_degree": spec["drift_degree"]}, budget=budget)
    if parent:
        store.descendant(name, manifest, request_id="register-child")
    else:
        store.register_release(name, manifest, request_id="register-ancestor")
    return manifest, digest("release", manifest)


def graph(manifest: CandidateReleaseManifest, release_digest: str) -> JobGraph:
    jobs = []
    for index, (stage, family) in enumerate(zip(STAGES, FAMILIES)):
        worker = "local-verifier" if family in {"challenge", "verification"} else "local-controller" if family in {"constitution", "admission"} else "local-producer"
        owner = "local-verifier" if worker == "local-controller" else "local-controller"
        jobs.append(JobContract(job_id=stage, family=family, worker=worker, acceptance_owner=owner, release_digest=release_digest, environment_digest=manifest.environment_digest, inputs={"context": "instrument-context-v1"} if index else {}, outputs={"context": "instrument-context-v1"}, critical_functions=[stage], resources={"calls": 1}, valid_until=stamp(3600), max_attempts=2, allowed_tools=["instrument-stage"], prohibited_effects=["network", "deployment", "settlement"], institution_id=manifest.institution_id, mission_id=manifest.mission_id, acceptance_conditions=["Source-bound retained output digest and complete declared stage record"], effects=[]))
    edges = [JobDependency(source=STAGES[i - 1], target=stage, kind="evidence", required_type="instrument-context-v1") for i, stage in enumerate(STAGES) if i]
    return JobGraph(jobs=jobs, edges=edges, required_families=list(FAMILIES), required_functions=list(STAGES))


def assignment(terms: JobContract, attempt: int = 1, expiry: str | None = None) -> ExecutionAuthorization:
    return ExecutionAuthorization(authorization_id=terms.job_id + "-attempt-" + str(attempt), acting_identity=terms.worker, job_terms_digest=digest("job-terms", terms), release_digest=terms.release_digest, environment_digest=terms.environment_digest, capabilities=["instrument-stage"], reservation_id=terms.job_id + "-reservation-" + str(attempt), expires_at=expiry or stamp(3600))


def accept_stage(dispatcher: JobDispatcher, keys: dict[str, Any], terms: JobContract, auth: ExecutionAuthorization, result: dict[str, Any], invocation_id: str) -> dict[str, Any]:
    retained = dispatcher.journal.latest(dispatcher.key)["runs"][terms.job_id][-1]["tools"][invocation_id]
    result_hash = digest("job-tool-output", result)
    if retained["state"] != "completed" or retained["result_digest"] != result_hash or retained["result_json"] != canonical(result).decode():
        raise ValueError("Scientific adapter cannot accept an unretained or altered tool output")
    verdict = "fail" if result.get("artifacts", {}).get("out_execute", {}).get("accepted") is False else "reported"
    report = JobResult(job_id=terms.job_id, authorization_id=auth.authorization_id, terms_digest=digest("job-terms", terms), output_digest=result_hash, outputs=terms.outputs, accepted=True, accepted_by=terms.acceptance_owner, valid_until=stamp(3600), permitted_uses=["dependency"], candidate_verdict=verdict, actual_resources={"calls": 1})
    return dispatcher.complete(sign_record(keys[terms.acceptance_owner], terms.acceptance_owner, "job-acceptance", report))


def observed_failure(action: Callable[[], Any]) -> dict[str, Any]:
    try:
        action()
    except (ValueError, Conflict) as exc:
        return {"blocked": True, "error_class": type(exc).__name__, "message": str(exc)}
    return {"blocked": False, "message": "Action unexpectedly completed"}


def run_pipeline(store: SuccessorStore, keys: dict[str, Any], name: str, spec: dict[str, Any], output: Path, parent: dict[str, Any] | None = None, crash: bool = False) -> dict[str, Any]:
    import instrument

    source_hash = hashlib.sha256(Path(instrument.__file__).read_bytes()).hexdigest()
    manifest, release_digest = institution(store, name, source_hash, spec, parent)
    frozen = graph(manifest, release_digest)
    dispatcher = JobDispatcher(store, name)
    dispatcher.seal(frozen)
    context: dict[str, Any] = {"spec": spec, "artifacts": {}, "costs": {}}
    if parent:
        context["parent"] = deepcopy(parent["package"])
    stages, recovery, failure = [], [], None
    start = time.perf_counter_ns()
    for terms in frozen.jobs:
        stage_started = time.perf_counter_ns()
        auth = assignment(terms)
        dispatcher.dispatch(terms.job_id, sign_record(keys["local-controller"], "local-controller", "execution", auth))
        tool_id = terms.job_id + "-computation"
        prior = deepcopy(context)
        if crash and terms.job_id == "out_execute":
            lost: list[dict[str, Any]] = []

            def loss_after_computation() -> dict[str, Any]:
                lost.append(instrument.run_stage(terms.job_id, deepcopy(prior)))
                raise SystemExit("injected process-loss boundary after pure calculation, before retained result")

            try:
                dispatcher.execute_tool(terms.job_id, tool="instrument-stage", actor=terms.worker, invocation_id=tool_id, handler=loss_after_computation, retain_result=True)
            except SystemExit:
                pass
            restarted = Journal(store.journal.root)
            store = SuccessorStore(restarted, store.trust)
            dispatcher = JobDispatcher(store, name)
            duplicate = observed_failure(lambda: dispatcher.execute_tool(terms.job_id, tool="instrument-stage", actor=terms.worker, invocation_id=tool_id, handler=lambda: instrument.run_stage(terms.job_id, deepcopy(prior)), retain_result=True))
            before = restarted.latest(dispatcher.key)["runs"][terms.job_id][-1]
            repair = {"institution_id": name, "job_id": terms.job_id, "authorization_id": auth.authorization_id, "reason": "Scripted fixture controller closes uncertain pure computation; new attempt requires new signed assignment"}
            dispatcher.recover_job(sign_record(keys["local-controller"], "local-controller", "job-recovery", repair))
            auth = assignment(terms, 2)
            dispatcher.dispatch(terms.job_id, sign_record(keys["local-controller"], "local-controller", "execution", auth))
            recovery.append({"injection": "SystemExit after completed pure calculation; no external side effect", "prior_attempt_state": before["state"], "prior_invocation_state": before["tools"][tool_id]["state"], "duplicate_refused": duplicate, "lost_stage_costs_observed_by_test": lost[0].get("costs", {}).get(terms.job_id), "journal_cost_class": "unknown; full reservation charged", "scripted_controller_decisions": 1, "human_interventions": 0, "new_authorization_id": auth.authorization_id})
        try:
            context = dispatcher.execute_tool(terms.job_id, tool="instrument-stage", actor=terms.worker, invocation_id=tool_id, handler=lambda stage=terms.job_id, previous=deepcopy(prior): instrument.run_stage(stage, previous), retain_result=True)
        except ValueError as exc:
            cause = exc.__cause__ or exc
            failure = {"stage": terms.job_id, "error_class": type(cause).__name__, "message": str(cause), "outer_message": str(exc), "remaining_stages": list(STAGES[STAGES.index(terms.job_id) + 1:]), "remaining_status": "NOT_RUN", "decision": "stop_and_retain_incumbent"}
            rejected = JobResult(job_id=terms.job_id, authorization_id=auth.authorization_id, terms_digest=digest("job-terms", terms), output_digest=digest("failure-report", failure), outputs=terms.outputs, accepted=False, accepted_by=terms.acceptance_owner, valid_until=stamp(3600), actual_resources={"calls": 1}, candidate_verdict="fail", failures=[str(cause)])
            dispatcher.complete(sign_record(keys[terms.acceptance_owner], terms.acceptance_owner, "job-acceptance", rejected))
            stages.append({"stage": terms.job_id, "family": terms.family, "status": "rejected", "failure": failure, "costs": {"fraction_ops": None, "simulated_detector_readings": 0 if terms.job_id == "out_design" else None, "cost_status": "failed callback did not return counters; not treated as zero compute"}, "elapsed_ns_including_dispatch": time.perf_counter_ns() - stage_started})
            dump(output / name / "failure.json", failure)
            break
        accept_stage(dispatcher, keys, terms, auth, context, tool_id)
        artifact = context.get("artifacts", {}).get(terms.job_id, {})
        stages.append({"stage": terms.job_id, "family": terms.family, "worker": terms.worker, "acceptance_owner": terms.acceptance_owner, "artifact": artifact, "costs": context.get("costs", {}).get(terms.job_id, {}), "elapsed_ns_including_dispatch": time.perf_counter_ns() - stage_started, "output_digest": digest("job-tool-output", context), "authorization_id": auth.authorization_id})
        dump(output / name / (terms.job_id + ".json"), context)
    snapshot = store.read(name)
    final = {"institution_id": name, "release_digest": release_digest, "source_sha256": source_hash, "manifest": manifest.model_dump(mode="json"), "context": context, "stages": stages, "recovery": recovery, "failure": failure, "elapsed_ns": time.perf_counter_ns() - start, "package": context.get("artifacts", {}).get("out_evolve", {}), "proofs_before_fresh_qualification": len(snapshot["proofs"]), "grants_before_fresh_qualification": len(snapshot["grants"]), "production_authority": False, "resource_ledger": snapshot["resources"]}
    dump(output / name / "pipeline.json", final)
    return final


def export_events(journal: Journal) -> list[dict[str, Any]]:
    with sqlite3.connect(journal.path) as cx:
        return [{"sequence": seq, "mission": mission, "body": json.loads(body), "hash": hashed, "signature": signature} for seq, mission, body, hashed, signature in cx.execute("SELECT * FROM events ORDER BY seq")]


def publish_local_proof(store: SuccessorStore, keys: dict[str, Any], pipeline: dict[str, Any], accepted: bool, *, grant_seconds: int = 3600, execute_inspection: bool = True) -> dict[str, Any]:
    name = pipeline["institution_id"]
    manifest = CandidateReleaseManifest.model_validate(pipeline["manifest"])
    context = pipeline["context"]
    proof = ProofReceipt(proof_id=name + "-qualification", institution_id=name, mission_id=name, release_digest=pipeline["release_digest"], environment_digest=manifest.environment_digest, verifier="local-verifier", valid_until=stamp(3600), issued_at=stamp(-1), outcome="pass" if accepted else "fail", claim="correctness", comparator_manifest_digest=digest("comparators", ["expert-direct", "conventional-cached", "rebuild"]), protocol_digest=hashlib.sha256((HERE.parent / "experiment" / "protocol.json").read_bytes()).hexdigest(), evidence_commitment=digest("scientific-result", context), disclosure=VerifierDisclosure(verifier="local-verifier", organization="single local research operator", control_separation="public test-vector role separation only", custodian="local-controller", funding_and_conflicts="same research implementation; no organizational independence", protocol_controller="local-controller", replication_status="local-replay"), evaluation_units=1, uncertainty="Exact conditional synthetic-model validation; no physical instrument evidence")
    signed = sign_record(keys["local-verifier"], "local-verifier", "proof", proof)
    store.record_proof(name, signed, request_id="proof-" + name)
    if not accepted:
        decision = AdmissionDecision(decision_id=name + "-refusal", institution_id=name, release_digest=pipeline["release_digest"], principal="local-controller", outcome="refuse", rationale="Scientific acceptance criteria failed; retain prior accepted capability")
        store.admit(name, sign_record(keys["local-controller"], "local-controller", "admission", decision), request_id="refuse-" + name)
        return {"proof": signed.model_dump(mode="json"), "admission": "refuse", "grant": None, "serving_release": None}
    decision = AdmissionDecision(decision_id=name + "-admit", institution_id=name, release_digest=pipeline["release_digest"], principal="local-controller", outcome="admit", proof_ids=[proof.proof_id], rationale="Scripted research admission for local synthetic inspection only")
    store.admit(name, sign_record(keys["local-controller"], "local-controller", "admission", decision), request_id="admit-" + name)
    grant = AuthorityEnvelope(grant_id=name + "-local-inspection", institution_id=name, mission_id=name, release_digest=pipeline["release_digest"], subject="local-producer", issuer="local-controller", actions=["inspect"], tools=["instrument-artifact"], targets=["synthetic-report"], resources={"inspections": 1}, proof_ids=[proof.proof_id], valid_until=stamp(grant_seconds), context_digest=digest("inspection-context", {"mission": name}), scope="sandbox", approval_required=False)
    store.grant(name, sign_record(keys["local-controller"], "local-controller", "authority", grant), request_id="grant-" + name)
    store.cutover(name, sign_record(keys["local-controller"], "local-controller", "cutover", {"release_digest": pipeline["release_digest"]}), request_id="cutover-" + name, expected_revision=store.read(name)["revision"])
    action = ActionRequest(action_id=name + "-inspect", subject="local-producer", release_digest=pipeline["release_digest"], environment_digest=manifest.environment_digest, action="inspect", tool="instrument-artifact", target="synthetic-report", context_digest=grant.context_digest, resources={"inspections": 1})
    if execute_inspection:
        store.dispatch_action(name, action)
        store.execute_action(name, action.action_id, ActionGateway({("instrument-artifact", "inspect"): lambda _: {"package_digest": digest("parent-package", pipeline["package"]), "scope": "synthetic-local"}}), actual_resources={"inspections": 1})
    return {"proof": signed.model_dump(mode="json"), "admission": "admit", "grant": grant.model_dump(mode="json"), "serving_release": store.read(name)["serving_release"], "production_authority": False}


def scientific_accepted(context: dict[str, Any]) -> bool:
    result = context.get("artifacts", {}).get("out_execute", {})
    for key in ("accepted", "qualified", "passed"):
        if key in result and type(result[key]) is bool:
            return result[key]
    raise ValueError("Scientific adapter returned no explicit acceptance verdict")


def run_demo(output_dir: str | Path, scenario: str = "nominal") -> dict[str, Any]:
    if scenario not in {"nominal", "crash", "negative_transfer"}:
        raise ValueError("Unsupported scenario")
    verify_vendor()
    output = Path(output_dir).resolve()
    if output.exists() and any(output.iterdir()):
        raise FileExistsError("Preserve prior evidence: choose a new empty output directory")
    output.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter_ns()
    with tempfile.TemporaryDirectory(prefix="successor-public-fixture-") as transient:
        journal, trust, keys = fixture_journal(Path(transient) / "journal")
        store = SuccessorStore(journal, trust)
        ancestor = run_pipeline(store, keys, "ancestor", {"signals": 1, "drift_degree": 2, "seed": 20261024, "acquisition_cap": 12}, output, crash=scenario == "crash")
        ancestor["qualification"] = publish_local_proof(store, keys, ancestor, scientific_accepted(ancestor["context"]))
        successor = run_pipeline(store, keys, "successor", {"signals": 2, "drift_degree": 4 if scenario == "negative_transfer" else 2, "seed": 20261025, "acquisition_cap": 12}, output, parent=ancestor)
        successor["historical_parent_proof_reuse"] = observed_failure(lambda: store.record_proof("successor", sign_record(keys["local-verifier"], "local-verifier", "proof", ancestor["qualification"]["proof"]["payload"]), request_id="forbidden-proof-reuse"))
        successor["qualification"] = publish_local_proof(store, keys, successor, successor["failure"] is None and scientific_accepted(successor["context"]))
        for pipeline in [ancestor, successor]:
            state = store.read(pipeline["institution_id"])
            pipeline["resource_ledger"] = state["resources"]
            pipeline["final_retained_proofs"] = len(state["proofs"])
            pipeline["final_retained_grants"] = len(state["grants"])
            dump(output / pipeline["institution_id"] / "pipeline.json", pipeline)
        checkpoint = JournalCheckpoint.capture(journal)
        events = export_events(journal)
        dump(output / "events.json", events)
        dump(output / "checkpoint.json", {"identity": checkpoint.identity, "sequence": checkpoint.sequence, "head": checkpoint.head, "scope": "Separately exported public fixture checkpoint, not independent custody"})
        result = {"schema": "successor-harness-research-demo/v1", "scenario": scenario, "scope": FIXTURE_SCOPE, "alpha_commit": ALPHA_COMMIT, "environment": environment(), "ancestor": ancestor, "successor": successor, "events": {"count": len(events), "head": checkpoint.head, "path": "events.json", "valid": journal.verify()["valid"]}, "elapsed_ns": time.perf_counter_ns() - started, "human_interventions": 0, "human_time_minutes": None, "human_time_status": "not measured; scripted local role decisions are not human review", "currency_spent": {"USD": "0", "USDC": "0", "AGIALPHA": "0"}, "external_integrations": {"Alpha": "executed-source-closure", "Alpha_installed_package": "NOT_RUN", "held_Harness_PR4863": "NOT_RUN", "Jobs": "NOT_RUN", "Manager": "NOT_RUN", "Fleet": "NOT_RUN", "EVM": "NOT_RUN", "deployed_contract_reads": "NOT_RUN", "settlement": "NOT_RUN"}, "artifacts": ["events.json", "checkpoint.json", "ancestor/pipeline.json", "successor/pipeline.json"]}
        dump(output / "demo.json", result)
        return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True)
    parser.add_argument("--scenario", default="nominal", choices=["nominal", "crash", "negative_transfer"])
    arguments = parser.parse_args()
    completed = run_demo(arguments.output, arguments.scenario)
    print(json.dumps({"output": str(Path(arguments.output).resolve()), "scenario": completed["scenario"], "events": completed["events"], "successor_admission": completed["successor"]["qualification"]["admission"]}, indent=2))
