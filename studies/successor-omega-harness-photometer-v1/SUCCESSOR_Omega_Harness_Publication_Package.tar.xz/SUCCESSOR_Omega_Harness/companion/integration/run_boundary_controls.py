# SPDX-License-Identifier: Apache-2.0
"""Separately frozen in-flight STOP and deadline controls for the released seam."""
from __future__ import annotations

import argparse
import hashlib
import json
import tempfile
import time
from pathlib import Path
from typing import Any

import run_controls as c
import run_integration as r


def run_case(name: str, root: Path) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    journal, store, keys, _, _, frozen, dispatcher = c.setup(root)
    first = frozen.jobs[0]
    expiry = r.stamp(2 if name == "expiry_after_computation_suppresses_finished_result" else 3600)
    auth = c.authorize(dispatcher, keys, first, expiry=expiry)
    calls: list[dict[str, Any]] = []

    def handler() -> dict[str, Any]:
        result = {"value": sum(i * i for i in range(1000)), "scope": "pure boundary fixture"}
        observation = {"computation_finished_at": r.stamp(), "finished_value": result["value"]}
        if name == "inflight_stop_suppresses_finished_result":
            journal.control(True)
            observation["stop_persisted_at"] = r.stamp()
        elif name == "expiry_after_computation_suppresses_finished_result":
            deadline = c.datetime_from_stamp(expiry)
            while time.time() <= deadline:
                time.sleep(min(0.05, max(0.005, deadline - time.time())))
        else:
            raise ValueError(name)
        observation["returned_at"] = r.stamp()
        calls.append(observation)
        return result

    denied = c.blocked(lambda: dispatcher.execute_tool(first.job_id, tool="instrument-stage", actor=first.worker, invocation_id="boundary", handler=handler, retain_result=True))
    assert len(calls) == 1
    before = journal.latest(dispatcher.key)["runs"][first.job_id][-1]
    invocation = before["tools"]["boundary"]
    assert invocation["state"] == "failed" and invocation["result_digest"] is None and invocation["result_json"] is None
    assert before["result"] is None
    decision = {"institution_id": "control", "job_id": first.job_id, "authorization_id": auth.authorization_id, "reason": "Explicit supplemental control: close finished but invalidated pure callback without accepting output"}
    dispatcher.recover_job(r.sign_record(keys["local-controller"], "local-controller", "job-recovery", decision))
    after = journal.latest(dispatcher.key)["runs"][first.job_id][-1]
    ledger = store.read("control")["resources"]
    assert after["state"] == "uncertain" and ledger["unknown"] == [auth.authorization_id]
    assert ledger["spent"]["calls"] == 1
    paused = journal.latest("@control")["state"] == "paused"
    if name == "inflight_stop_suppresses_finished_result":
        assert paused
        remaining = c.blocked(lambda: c.authorize(dispatcher, keys, first, attempt=2))
    else:
        assert not paused
        remaining = c.blocked(lambda: c.authorize(dispatcher, keys, first, attempt=2, expiry=expiry))
    detail = {
        "handler_calls": len(calls), "computation_observations": calls,
        "assignment_expiry": expiry, "post_computation_refusal": denied,
        "invocation_before_recovery": invocation,
        "attempt_state_after_recovery": after["state"], "accepted_work_count": 0,
        "reservation_ledger": ledger, "stop_persists_after_recovery": paused,
        "unchanged_stop_or_expired_assignment_refusal": remaining,
        "asynchronous_preemption": False, "dedicated_cancelled_state": False,
        "stop_authorization_scope": "Direct local fixture Journal.control call; no remote authentication or independent controller envelope for STOP"
    }
    return {"case": name, "expectation_matched": True, "detail": detail, "journal": journal.verify()}, r.export_events(journal)


def run_controls(output: Path) -> dict[str, Any]:
    if output.exists() and any(output.iterdir()):
        raise FileExistsError("Preserve previous evidence: choose a new empty output directory")
    protocol_path = r.HERE / "boundary_protocol.json"
    protocol = json.loads(protocol_path.read_text())
    rows = []
    for case in protocol["cases"]:
        started = time.perf_counter_ns()
        with tempfile.TemporaryDirectory(prefix="successor-boundary-") as temporary:
            try:
                row, events = run_case(case["name"], Path(temporary) / "journal")
                r.dump(output / case["name"] / "events.json", events)
            except Exception as exc:
                row = {"case": case["name"], "expectation_matched": False, "error_class": type(exc).__name__, "error": str(exc)}
            row["elapsed_ns"] = time.perf_counter_ns() - started
            rows.append(row)
            r.dump(output / case["name"] / "result.json", row)
    result = {
        "schema": "successor-harness-supplemental-boundary-result/v1",
        "protocol_sha256": hashlib.sha256(protocol_path.read_bytes()).hexdigest(),
        "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "integration_source_sha256": hashlib.sha256((r.HERE / "run_integration.py").read_bytes()).hexdigest(),
        "original_control_source_sha256": hashlib.sha256((r.HERE / "run_controls.py").read_bytes()).hexdigest(),
        "fixture_scope": r.FIXTURE_SCOPE, "environment": r.environment(),
        "cases": rows, "expectations_matched": sum(x["expectation_matched"] for x in rows), "total": len(rows)
    }
    r.dump(output / "controls.json", result)
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True, type=Path)
    report = run_controls(parser.parse_args().output)
    print(json.dumps({"matched": report["expectations_matched"], "total": report["total"], "failures": [x for x in report["cases"] if not x["expectation_matched"]]}, indent=2))
    raise SystemExit(0 if report["expectations_matched"] == report["total"] else 1)
