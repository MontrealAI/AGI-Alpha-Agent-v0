# Released Alpha source integration

This companion calls the existing Alpha `JobDispatcher`, `SuccessorStore`, typed contracts, trust registry and signed SQLite journal. The eleven vendored source files are byte-for-byte from Alpha commit `031bdb5d055c8bad896daa076baea2b5e17b242c` / release `v1.41.0`; `VENDOR_MANIFEST.json` records every hash. No held Harness PR source is imported, and no repository admission rule is changed.

## Run locally

The verified execution environment was Python 3.12.14, Pydantic 2.14.1, Cryptography 50.0.2 on Linux x86_64. The instrument uses Python's standard library; the native Alpha dependency closure requires the versions pinned in `requirements.txt`. From the companion root:

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r integration/requirements.txt
.venv/bin/python integration/run_integration.py --output runs/nominal --scenario nominal
.venv/bin/python integration/verify_evidence.py runs/nominal
.venv/bin/python integration/run_controls.py --output runs/controls
.venv/bin/python integration/run_boundary_controls.py --output runs/boundaries
.venv/bin/python integration/audit_fixtures.py --output runs/fixture-audit.json
```

Setup may download the pinned Python dependencies once. The actual experiment makes no network request. It opens no server, creates no account, wallet or API token, and performs no financial action. An environment that already has the pinned packages can run the commands directly with `python3`.

The integration is **source-closure execution**, not a newly installed full Alpha product. Package installation, the private runtime initializer, Jobs/Manager admissions, Fleet execution, the held Harness PR, EVM execution, deployed contract observations and settlement are all explicitly `NOT_RUN` for this study.

Use a new output directory for each run. The demo refuses to overwrite an existing nonempty evidence directory. Three scenarios are available:

| Scenario | Actual behavior |
|---|---|
| `nominal` | Seven real computations construct and test a scalar drift-rejecting instrument. A distinct successor then runs all seven stages for a two-signal instrument. Each receives new local qualification and a separate sandbox-only inspection grant. |
| `crash` | An injected `SystemExit` occurs after pure scalar measurement computation and before its output is retained. The journal is reopened; same-invocation replay is refused; a scripted controller closes the uncertain attempt and issues a fresh assignment. Unknown reservation and externally observed test costs are both preserved. The separate control suite additionally tests a real child process exiting with code 23. |
| `negative_transfer` | The ancestor is accepted. The two-signal successor asks for rejection of polynomial drift through degree four within six sampling positions, which makes the required seven independent dimensions impossible. Design stops; downstream stages remain `NOT_RUN`; the negative proof/refusal is retained and the incumbent remains accepted. |

## The signature fixture is deliberately public

The local journal and three distinct role keys use the published Ed25519 test vectors 1–3 in [RFC 8032 §7.1](https://www.rfc-editor.org/rfc/rfc8032#section-7.1). These are public test data, not newly generated credentials. They have no identity assurance and must never be trusted by a real service. Anyone can reproduce their signatures.

The fixture bootstrap creates the existing journal's exact SQLite schema and opens it using the unchanged `Journal(root)` constructor. It does **not** call `Journal.initialize`, create an API token, patch permission checks or run a service. The standard installed initializer is not tested. All role assignments and acceptance decisions are scripted under one operator; they are not independent organizational review. Temporary fixture storage is deleted after public event export.

`audit_fixtures.py` checks the three published RFC known-answer signatures, inspects the fixture functions without importing the runtime, compares their SQL schema to the unmodified released initializer, and verifies every vendored file hash. Its optional `--source-checkout` argument also compares the bytes to the frozen Alpha checkout. This audit does not call the product initializer or claim an installed-package test.

This permits reproducible local control tests while respecting the writing task's prohibition on new credentials. In a deployed system, secret key protection, independently supplied trust roots, external custody and a retained head checkpoint would be necessary assumptions. Public signatures in this companion demonstrate parsing and state-transition behavior only.

## What is actually retained

`demo.json` contains both mission specifications, source-bound manifests, every stage's actual artifact and separate detector/compute/time costs, admission results, lineage, recovery disclosure and all unexercised integration labels. `events.json` is the complete public journal body/hash/signature chain. `checkpoint.json` records its final head. The stage JSON files retain the exact evolving contexts, including raw synthetic detector readings, rational matrices, gain intervals, failures and proposed next requirements.

`verify_evidence.py` is a separately written auditor that does not import the Alpha runtime or the instrument implementation. It verifies the raw journal chain, Ed25519 envelopes, accepted tool/result bindings, exact nuisance cancellation, signal reconstruction, raw-reading demodulation, calibrated intervals and fresh successor proof boundary using direct JSON, rational arithmetic and Cryptography. It is a second implementation under the same research authorship, not an independent organization.

`control_protocol.json` froze thirteen expected behaviors before the control campaign. They cover missing dependencies, expiry, wrong controller, pause, actual process exit and explicit recovery, altered retained outputs, revoked dependencies, descendant proof/grant boundaries, expired grants, journal tampering, prefix rollback, physical-truth limits and resource overrun. `run_controls.py` records each case separately, including failed expectations if any.

The separate `boundary_protocol.json` adds two predeclared cases without changing that original campaign: local STOP during computation and assignment expiry after computation. They test whether the existing post-handler check suppresses the returned output, preserves the failed invocation, and requires explicit recovery. A callback may finish after cancellation or expiry. The runtime performs cooperative checks at its boundaries; it does not asynchronously preempt arbitrary running code, provide a dedicated cancelled state, or promise a hard real-time deadline. The fixture calls the host's durable `Journal.control` stop flag directly, so this is not a test of remote STOP authentication.

## Boundaries and costs

The pure-tool seam prevents replay of one invocation identity in a trusted journal. It cannot establish universal exactly-once external execution. A remote effect would require destination idempotency or separately verified outcome reconciliation; neither is simulated as completed here.

The generic runtime accepts a physically false report when its configured acceptance role signs that report. This retained negative control is intentional: a commitment is not a scientific oracle. The instrument's exact mathematical checker supplies a narrower model-conditional test, and even that cannot prove its physical assumptions.

Every stage records simulated detector readings, counted rational arithmetic and measured wall/CPU time separately. Wrapper dispatch time includes journal, signature and artifact overhead. A failed callback that does not return its counter is explicitly unknown, not zero. Authoring labor, independent review time, physical acquisition cost and commercial profit are unmeasured. `human_interventions: 0` means no human input was required while this scripted local run executed; it does not assert zero preparation or oversight labor.

## Source and license

The original Apache-2.0 notices are preserved in each vendored file and `vendor/LICENSE-ALPHA.txt`. New integration code is Apache-2.0. Source hashes identify the exact studied implementation; they do not grant deployment authority. The separately held Harness/Fleet decisions and receiving-owner publication controls remain unchanged.
