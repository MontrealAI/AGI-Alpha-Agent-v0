# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import argparse
import base64
import hashlib
import json
from fractions import Fraction as F
from pathlib import Path

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

PUBLIC = {
    "local-controller": "d75a980182b10ab7d54bfed3c964073a0ee172f3daa62325af021a68f707511a",
    "local-producer": "3d4017c3e843895a92b70aa74d1b7ebc9c982ccf2ec4968cc0cd55f12af4660c",
    "local-verifier": "fc51cd8e6218a1a38da47ed00230f0580816ed13ba3303ac5deb911548908025",
}


def compact(x):
    return json.dumps(x, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode()


def domain_hash(domain, x):
    return hashlib.sha256(b"successor-omega/v1:" + domain.encode() + b"\0" + compact(x)).hexdigest()


def verify_signature(envelope):
    public = PUBLIC[envelope["principal"]]
    commitment = domain_hash(envelope["domain"], {"principal": envelope["principal"], "payload": envelope["payload"]})
    Ed25519PublicKey.from_public_bytes(bytes.fromhex(public)).verify(base64.b64decode(envelope["signature"], validate=True), bytes.fromhex(commitment))


def verify_instrument(pipeline):
    artifacts = pipeline["context"]["artifacts"]
    if "out_execute" not in artifacts:
        assert pipeline["failure"] and pipeline["qualification"]["admission"] == "refuse"
        return {"status": "construction_failed_and_refused", "failure": pipeline["failure"]}
    capability = artifacts["out_design"]
    spec = pipeline["context"]["spec"]
    n, k, degree = len(capability["times"]), spec["signals"], spec["drift_degree"]
    ts = list(map(F, capability["times"]))
    weights = [[F(x) for x in row] for row in capability["weights"]]
    controls = [[F(x) for x in row] for row in capability["controls"]]
    assert len(weights) == k and all(len(row) == n for row in weights)
    for i, row in enumerate(weights):
        for power in range(degree + 1):
            assert sum(w * t ** power for w, t in zip(row, ts)) == 0
        for column in range(k):
            assert sum(row[j] * controls[j][column] for j in range(n)) == (1 if i == column else 0)
        assert sum(map(abs, row)) == F(capability["noise_amplification_l1"][i])
    outcome = artifacts["out_execute"]
    if not outcome["accepted"]:
        assert pipeline["qualification"]["admission"] == "refuse"
        return {"status": "algebra_verified_mission_refused"}
    reference = list(map(F, outcome["raw_reference"]))
    sample = list(map(F, outcome["raw_sample"]))
    ref = [sum(w * y for w, y in zip(row, reference)) for row in weights]
    obs = [sum(w * y for w, y in zip(row, sample)) for row in weights]
    assert ref == list(map(F, outcome["demodulated_reference"]))
    assert obs == list(map(F, outcome["demodulated_sample"]))
    eta = F(capability["applicability"]["noise_bound"])
    radius = [eta * sum(map(abs, row)) for row in weights]
    lo = max(F(capability["applicability"]["gain_range"][0]), max(x - e for x, e in zip(ref, radius)))
    hi = min(F(capability["applicability"]["gain_range"][1]), min(x + e for x, e in zip(ref, radius)))
    assert lo > 0 and lo <= hi
    assert [lo, hi] == list(map(F, outcome["gain_interval"]))
    for i, (value, error) in enumerate(zip(obs, radius)):
        endpoints = [(value + sign * error) / gain for sign in [-1, 1] for gain in [lo, hi]]
        expected = [max(F(-1), min(endpoints)), min(F(1), max(endpoints))]
        interval = list(map(F, outcome["signal_intervals"][i]))
        assert expected == interval
        assert (interval[1] - interval[0]) / 2 <= F(1, 50)
        truth = F(outcome["oracle"]["signals"][i])
        assert interval[0] <= truth <= interval[1]
    assert outcome["detector_readings"] == 2 * n <= spec["acquisition_cap"]
    return {"status": "verified", "signals": k, "drift_degree": degree, "WV_zero": True, "WR_identity": True, "raw_observations_recomputed": True, "intervals_recomputed": True, "detector_readings": 2 * n, "scope": "synthetic conditional model; oracle truth supplied by experiment"}


def verify(directory):
    demo = json.loads((directory / "demo.json").read_text())
    events = json.loads((directory / "events.json").read_text())
    checkpoint = json.loads((directory / "checkpoint.json").read_text())
    last, snapshots = "0" * 64, {}
    journal_public = PUBLIC["local-controller"]
    journal_key = Ed25519PublicKey.from_public_bytes(bytes.fromhex(journal_public))
    for index, event in enumerate(events, 1):
        body = event["body"]
        assert event["sequence"] == index == body["sequence"]
        assert body["previous"] == last
        assert body["identity"] == "urn:agialpha:ed25519:" + journal_public
        assert body["mission"] == event["mission"]
        assert hashlib.sha256(compact(body)).hexdigest() == event["hash"]
        journal_key.verify(base64.b64decode(event["signature"], validate=True), bytes.fromhex(event["hash"]))
        last = event["hash"]
        snapshots[event["mission"]] = body["document"]
    assert last == checkpoint["head"] == demo["events"]["head"]
    assert len(events) == checkpoint["sequence"] == demo["events"]["count"]
    envelope_count = 0
    accepted_jobs = 0
    for name, state in snapshots.items():
        if name.startswith("@successor-jobs:"):
            for job, attempts in state["runs"].items():
                for attempt in attempts:
                    verify_signature(attempt["authorization_envelope"])
                    envelope_count += 1
                    if attempt["acceptance"]:
                        verify_signature(attempt["acceptance"])
                        envelope_count += 1
                        if attempt["result"]["accepted"]:
                            result_hash = attempt["result"]["output_digest"]
                            matches = [tool for tool in attempt["tools"].values() if tool["state"] == "completed" and tool["result_digest"] == result_hash]
                            assert len(matches) == 1
                            assert domain_hash("job-tool-output", json.loads(matches[0]["result_json"])) == result_hash
                            accepted_jobs += 1
        if name.startswith("@successor:"):
            for group in ["proofs", "admissions", "grants"]:
                for entry in state[group].values():
                    verify_signature(entry["envelope"])
                    envelope_count += 1
                    if group == "grants":
                        assert entry["envelope"]["payload"]["scope"] == "sandbox"
    scientific = {name: verify_instrument(demo[name]) for name in ["ancestor", "successor"]}
    assert demo["successor"].get("proofs_before_fresh_qualification", demo["successor"].get("current_proofs")) == 0
    assert demo["successor"].get("grants_before_fresh_qualification", demo["successor"].get("current_grants")) == 0
    assert demo["successor"]["historical_parent_proof_reuse"]["blocked"]
    return {"passed": True, "scenario": demo["scenario"], "events_verified": len(events), "role_envelopes_verified": envelope_count, "accepted_job_receipts_verified": accepted_jobs, "scientific": scientific, "fresh_successor_proof_and_authority_required": True, "public_test_fixture_authentication": False, "vendor_runtime_imported": False, "method": "Separately authored direct JSON/Fraction/Ed25519 auditor, without importing runtime or instrument implementation"}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("directory", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    report = verify(args.directory)
    if args.output:
        args.output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))
