# SPDX-License-Identifier: Apache-2.0
"""Audit public signing fixtures without importing the runtime or demo module."""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
from pathlib import Path

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat

HERE = Path(__file__).resolve().parent


def literals(tree: ast.AST, prefix: str) -> list[str]:
    return sorted(" ".join(n.value.split()) for n in ast.walk(tree) if isinstance(n, ast.Constant) and isinstance(n.value, str) and n.value.startswith(prefix))


def audit(source_checkout: Path | None = None) -> dict:
    helper_source = HERE / "run_integration.py"
    helper = ast.parse(helper_source.read_text())
    seeds = next(ast.literal_eval(n.value) for n in helper.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "PUBLIC_TEST_SEEDS" for t in n.targets))
    funcs = {n.name: n for n in helper.body if isinstance(n, ast.FunctionDef)}
    vectors = json.loads((HERE / "RFC8032_PUBLIC_FIXTURES.json").read_text())
    rows = []
    for name, vector in zip(("local-controller", "local-producer", "local-verifier"), vectors["vectors"], strict=True):
        assert seeds[name] == vector["public_seed_hex"]
        key = Ed25519PrivateKey.from_private_bytes(bytes.fromhex(seeds[name]))
        public = key.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw).hex()
        signature = key.sign(bytes.fromhex(vector["message_hex"])).hex()
        assert public == vector["public_key_hex"] and signature == vector["signature_hex"]
        rows.append({"role": name, "rfc_test": vector["rfc_test"], "published_public_key": public, "published_signature_matches": True})
    calls = [n.func.attr for name in ("fixture_journal", "fixture_roles") for n in ast.walk(funcs[name]) if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)]
    assert not set(calls) & {"initialize", "generate", "token_urlsafe", "token_hex", "urandom"}
    assert "api.token" not in ast.unparse(funcs["fixture_journal"])
    vendor_manifest = json.loads((HERE / "VENDOR_MANIFEST.json").read_text())
    verified = []
    for entry in vendor_manifest["files"]:
        content = (HERE / "vendor" / entry["path"]).read_bytes()
        assert hashlib.sha256(content).hexdigest() == entry["sha256"]
        if source_checkout is not None:
            assert content == (source_checkout / entry["path"]).read_bytes()
        verified.append(entry["path"])
    store_ast = ast.parse((HERE / "vendor/alpha_factory_v1/core/runtime/store.py").read_text())
    journal = next(n for n in store_ast.body if isinstance(n, ast.ClassDef) and n.name == "Journal")
    initializer = next(n for n in journal.body if isinstance(n, ast.FunctionDef) and n.name == "initialize")
    expected_sql = literals(initializer, "CREATE ")
    actual_sql = literals(funcs["fixture_journal"], "CREATE ")
    assert expected_sql == actual_sql and len(actual_sql) == 2
    return {
        "schema": "successor-public-fixture-audit/v1", "passed": True,
        "auditor_source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "integration_source_sha256": hashlib.sha256(helper_source.read_bytes()).hexdigest(),
        "public_vector_source": vectors["source"], "published_vectors": rows,
        "source_files_manifest_verified": verified,
        "checkout_comparison_performed": source_checkout is not None,
        "checkout_commit_claim": vendor_manifest["commit"] if source_checkout is not None else None,
        "exact_sql_schema_matches_released_initializer": True,
        "fixture_initializer_calls": 0, "fixture_random_signing_key_calls": 0, "fixture_api_token_writes": 0,
        "claims": {"new_credential_created": False, "full_product_installed": False, "installed_initializer_tested": False, "real_authentication": False, "external_authority": False},
        "limitation": "Static inspection of fixture functions plus public known-answer crypto tests; it is not proof of remote authenticity or independent organizational control. Vendored initializer exists unchanged but the fixture does not call it."
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-checkout", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = audit(args.source_checkout)
    if args.output:
        if args.output.exists():
            raise FileExistsError("Preserve the previous fixture audit; choose a new output path")
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
