# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Any

import run_integration as r


def setup(root: Path) -> tuple[Any, ...]:
    journal, trust, keys = r.fixture_journal(root)
    store = r.SuccessorStore(journal, trust)
    manifest, release_hash = r.institution(store, "control", hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), {"signals": 1, "drift_degree": 2})
    frozen = r.graph(manifest, release_hash)
    dispatcher = r.JobDispatcher(store, "control")
    dispatcher.seal(frozen)
    return journal, store, keys, manifest, release_hash, frozen, dispatcher


def authorize(dispatcher: Any, keys: dict, terms: Any, attempt: int = 1, expiry: str | None = None) -> Any:
    assignment = r.assignment(terms, attempt, expiry)
    dispatcher.dispatch(terms.job_id, r.sign_record(keys["local-controller"], "local-controller", "execution", assignment))
    return assignment


def calculate(dispatcher: Any, keys: dict, terms: Any, auth: Any, value: int = 7) -> dict:
    result = dispatcher.execute_tool(terms.job_id, tool="instrument-stage", actor=terms.worker, invocation_id="calc", handler=lambda: {"value": value, "scope": "control arithmetic"}, retain_result=True)
    r.accept_stage(dispatcher, keys, terms, auth, result, "calc")
    return result


def blocked(fn: Any) -> dict:
    evidence = r.observed_failure(fn)
    assert evidence["blocked"], evidence
    return evidence


def public_pipeline(manifest: Any, release_hash: str) -> dict:
    return {"institution_id": "control", "release_digest": release_hash, "manifest": manifest.model_dump(mode="json"), "context": {"arithmetic": "3+4=7", "verified": 3 + 4 == 7}, "package": {"scope": "control-arithmetic"}}


def inspect_action(manifest: Any, release_hash: str, ident: str = "later-inspection") -> Any:
    return r.ActionRequest(action_id=ident, subject="local-producer", release_digest=release_hash, environment_digest=manifest.environment_digest, action="inspect", tool="instrument-artifact", target="synthetic-report", context_digest=r.digest("inspection-context", {"mission": "control"}), resources={"inspections": 1})


def run_case(name: str, root: Path) -> tuple[dict, list]:
    journal, store, keys, manifest, release_hash, frozen, dispatcher = setup(root)
    first, second = frozen.jobs[:2]
    if name == "missing_dependency_rejected":
        detail = blocked(lambda: authorize(dispatcher, keys, second))
    elif name == "expired_assignment_rejected":
        detail = blocked(lambda: authorize(dispatcher, keys, first, expiry=r.stamp(-10)))
    elif name == "wrong_controller_rejected":
        auth = r.assignment(first)
        detail = blocked(lambda: dispatcher.dispatch(first.job_id, r.sign_record(keys["local-producer"], "local-producer", "execution", auth)))
    elif name == "pause_before_handler_prevents_computation":
        authorize(dispatcher, keys, first)
        journal.control(True)
        calls = []
        detail = blocked(lambda: dispatcher.execute_tool(first.job_id, tool="instrument-stage", actor=first.worker, invocation_id="paused", handler=lambda: calls.append(True) or {"value": 7}, retain_result=True))
        assert calls == []
        detail["handler_calls"] = len(calls)
    elif name == "actual_process_exit_preserves_uncertainty_and_requires_fresh_attempt":
        auth = authorize(dispatcher, keys, first)
        child = subprocess.run([sys.executable, str(Path(__file__).resolve()), "--worker-crash", str(root.resolve())], capture_output=True, text=True, timeout=15)
        assert child.returncode == 23, child.stderr
        reopened = r.Journal(root)
        store = r.SuccessorStore(reopened, store.trust)
        dispatcher = r.JobDispatcher(store, "control")
        raw = reopened.latest(dispatcher.key)
        assert raw["runs"][first.job_id][-1]["tools"]["process-crash"]["state"] == "executing"
        replay = blocked(lambda: dispatcher.execute_tool(first.job_id, tool="instrument-stage", actor=first.worker, invocation_id="process-crash", handler=lambda: {"value": 7}, retain_result=True))
        decision = {"institution_id": "control", "job_id": first.job_id, "authorization_id": auth.authorization_id, "reason": "Actual child exit 23; explicitly close uncertain pure local calculation"}
        dispatcher.recover_job(r.sign_record(keys["local-controller"], "local-controller", "job-recovery", decision))
        recovered = reopened.latest(dispatcher.key)["runs"][first.job_id][-1]
        assert recovered["state"] == "uncertain"
        assert recovered["tools"]["process-crash"]["state"] == "uncertain"
        second_auth = authorize(dispatcher, keys, first, 2)
        calculate(dispatcher, keys, first, second_auth)
        ledger = store.read("control")["resources"]
        assert ledger["spent"]["calls"] == 2 and ledger["unknown"] == [auth.authorization_id]
        detail = {"child_exit": child.returncode, "replay": replay, "prior_attempt": recovered, "ledger": ledger, "fresh_authorization": second_auth.model_dump(mode="json")}
    elif name == "scientific_adapter_rejects_altered_retained_output":
        auth = authorize(dispatcher, keys, first)
        result = dispatcher.execute_tool(first.job_id, tool="instrument-stage", actor=first.worker, invocation_id="calc", handler=lambda: {"value": 7}, retain_result=True)
        detail = blocked(lambda: r.accept_stage(dispatcher, keys, first, auth, {"value": 8}, "calc"))
        r.accept_stage(dispatcher, keys, first, auth, result, "calc")
    elif name == "revoked_dependency_blocks_successor_job":
        auth = authorize(dispatcher, keys, first)
        calculate(dispatcher, keys, first, auth)
        dispatcher.revoke_dependency(r.sign_record(keys["local-controller"], "local-controller", "job-revocation", {"job_id": first.job_id, "reason": "fixture evidence revocation"}))
        detail = blocked(lambda: authorize(dispatcher, keys, second))
        detail["revoked_jobs"] = journal.latest(dispatcher.key)["revoked_jobs"]
        assert len(detail["revoked_jobs"]) == 7
    elif name == "descendant_does_not_inherit_current_proof_or_grant":
        parent = r.publish_local_proof(store, keys, public_pipeline(manifest, release_hash), True, execute_inspection=False)
        child = manifest.model_copy(update={"release_id": "control-child", "parent_release_digest": release_hash, "configuration": {"new_requirement": "different-signal-rank"}})
        child_hash = r.digest("release", child)
        store.descendant("control", child, request_id="new-descendant")
        decision = r.AdmissionDecision(decision_id="bad-child-admission", institution_id="control", release_digest=child_hash, principal="local-controller", outcome="admit", proof_ids=["control-qualification"])
        refusal = blocked(lambda: store.admit("control", r.sign_record(keys["local-controller"], "local-controller", "admission", decision), request_id="bad-child-admit"))
        state = store.read("control")
        assert state["serving_release"] == release_hash
        assert not any(x["envelope"]["payload"]["release_digest"] == child_hash for x in state["grants"].values())
        detail = {"parent_proof_reuse": refusal, "incumbent_retained": state["serving_release"] == release_hash, "child_grants": 0, "child_release": child_hash, "parent_release": release_hash, "parent_admission": parent["admission"]}
    elif name == "expired_sandbox_grant_cannot_execute_after_recovery":
        proof = r.publish_local_proof(store, keys, public_pipeline(manifest, release_hash), True, grant_seconds=2, execute_inspection=False)
        action = inspect_action(manifest, release_hash)
        store.dispatch_action("control", action)
        deadline = datetime_from_stamp(proof["grant"]["valid_until"])
        while time.time() <= deadline:
            time.sleep(min(0.1, max(0.01, deadline - time.time())))
        denied = blocked(lambda: store.execute_action("control", action.action_id, r.ActionGateway({("instrument-artifact", "inspect"): lambda _: {"value": 7}}), actual_resources={"inspections": 1}))
        store.recover("control", r.sign_record(keys["local-controller"], "local-controller", "recovery", {"institution_id": "control"}), request_id="recover-expired")
        state = store.read("control")
        assert state["stopped"] and state["grants"]["control-local-inspection"]["status"] == "impaired"
        denied_after = blocked(lambda: store.dispatch_action("control", inspect_action(manifest, release_hash, "after-recovery")))
        detail = {"grant_expiry": proof["grant"]["valid_until"], "observed_at": r.stamp(), "expired_execution": denied, "after_recovery": denied_after, "grant_status": state["grants"]["control-local-inspection"]["status"], "stopped": state["stopped"]}
    elif name == "journal_tamper_detected":
        clone = root.parent / "altered"
        clone.mkdir()
        for f in ["config.json", "identity.key"]:
            shutil.copyfile(root / f, clone / f)
        with sqlite3.connect(journal.path) as source, sqlite3.connect(clone / "journal.sqlite3") as dest:
            source.backup(dest)
        with sqlite3.connect(clone / "journal.sqlite3") as cx:
            cx.execute("UPDATE events SET body=replace(body,'control-arithmetic','altered') WHERE seq=2")
            row = cx.execute("SELECT body FROM events WHERE seq=2").fetchone()[0]
            body = json.loads(row)
            body["data"] = {"false": "changed event"}
            cx.execute("UPDATE events SET body=? WHERE seq=2", (json.dumps(body),))
        detail = blocked(lambda: r.Journal(clone).verify())
    elif name == "valid_prefix_needs_separate_checkpoint":
        anchor = r.JournalCheckpoint.capture(journal)
        clone = root.parent / "prefix"
        clone.mkdir()
        for f in ["config.json", "identity.key"]:
            shutil.copyfile(root / f, clone / f)
        with sqlite3.connect(journal.path) as source, sqlite3.connect(clone / "journal.sqlite3") as dest:
            source.backup(dest)
        with sqlite3.connect(clone / "journal.sqlite3") as cx:
            cx.execute("DELETE FROM events WHERE seq>?", (anchor.sequence - 1,))
        shorter = r.Journal(clone)
        valid_prefix = shorter.verify()
        assert valid_prefix["valid"]
        detail = {"self_verification_passes": True, "prefix_events": valid_prefix["events"], "trusted_head_events": anchor.sequence, "checkpoint_refusal": blocked(lambda: anchor.verify(shorter))}
    elif name == "generic_runtime_accepts_false_claim_from_trusted_acceptance_role":
        auth = authorize(dispatcher, keys, first)
        false_claim = {"claim": "An actual physical photometer was calibrated", "fixture_ground_truth": "No physical instrument exists in this test"}
        computed = dispatcher.execute_tool(first.job_id, tool="instrument-stage", actor=first.worker, invocation_id="false-claim", handler=lambda: false_claim, retain_result=True)
        raw = r.accept_stage(dispatcher, keys, first, auth, computed, "false-claim")
        assert raw["runs"][first.job_id][-1]["result"]["accepted"]
        detail = {"detected": False, "expected_limitation": True, "false_claim": false_claim, "reason": "Generic runtime checks authorized attribution/binding, not physical truth; configured acceptance role can lie"}
    elif name == "resource_overrun_stops_remaining_work":
        auth = authorize(dispatcher, keys, first)
        output = dispatcher.execute_tool(first.job_id, tool="instrument-stage", actor=first.worker, invocation_id="overrun", handler=lambda: {"value": 7}, retain_result=True)
        report = r.JobResult(job_id=first.job_id, authorization_id=auth.authorization_id, terms_digest=r.digest("job-terms", first), output_digest=r.digest("job-tool-output", output), outputs=first.outputs, accepted=True, accepted_by=first.acceptance_owner, valid_until=r.stamp(3600), actual_resources={"calls": 2})
        dispatcher.complete(r.sign_record(keys[first.acceptance_owner], first.acceptance_owner, "job-acceptance", report))
        state = store.read("control")
        assert state["stopped"] and state["resources"]["spent"]["calls"] == 2
        detail = {"overrun": state["resources"]["overruns"], "remaining_job": blocked(lambda: authorize(dispatcher, keys, second))}
    else:
        raise ValueError(name)
    return {"case": name, "expectation_matched": True, "detail": detail, "journal": journal.verify()}, r.export_events(journal)


def datetime_from_stamp(value: str) -> float:
    from datetime import datetime
    return datetime.fromisoformat(value.replace("Z", "+00:00")).timestamp()


def crash_worker(root: Path) -> None:
    trust, _ = r.fixture_roles()
    journal = r.Journal(root)
    dispatcher = r.JobDispatcher(r.SuccessorStore(journal, trust), "control")
    term = r.JobContract.model_validate(journal.latest(dispatcher.key)["graph"]["jobs"][0])

    def crash() -> dict:
        sum(i * i for i in range(1000))
        os._exit(23)

    dispatcher.execute_tool(term.job_id, tool="instrument-stage", actor=term.worker, invocation_id="process-crash", handler=crash, retain_result=True)


def run_controls(output: Path) -> dict:
    r.verify_vendor()
    if output.exists() and any(output.iterdir()):
        raise FileExistsError("Preserve prior controls: choose a new empty output directory")
    protocol = json.loads((r.HERE / "control_protocol.json").read_text())
    rows = []
    for name in protocol["cases"]:
        started = time.perf_counter_ns()
        with tempfile.TemporaryDirectory(prefix="successor-control-") as temporary:
            try:
                row, events = run_case(name, Path(temporary) / "journal")
                r.dump(output / name / "events.json", events)
            except Exception as exc:
                row = {"case": name, "expectation_matched": False, "error_class": type(exc).__name__, "error": str(exc)}
            row["elapsed_ns"] = time.perf_counter_ns() - started
            rows.append(row)
            r.dump(output / name / "result.json", row)
    result = {"schema": "successor-harness-runtime-controls-result/v1", "protocol_sha256": hashlib.sha256((r.HERE / "control_protocol.json").read_bytes()).hexdigest(), "control_source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), "integration_source_sha256": hashlib.sha256((r.HERE / "run_integration.py").read_bytes()).hexdigest(), "runtime_source": r.ALPHA_COMMIT, "fixture_scope": r.FIXTURE_SCOPE, "environment": r.environment(), "cases": rows, "expectations_matched": sum(x["expectation_matched"] for x in rows), "total": len(rows), "physical_false_claim_detection": False, "independent_control": False}
    r.dump(output / "controls.json", result)
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    parser.add_argument("--worker-crash", type=Path)
    args = parser.parse_args()
    if args.worker_crash:
        crash_worker(args.worker_crash)
    else:
        report = run_controls(args.output)
        print(json.dumps({"matched": report["expectations_matched"], "total": report["total"], "failures": [x for x in report["cases"] if not x["expectation_matched"]]}, indent=2))
        raise SystemExit(0 if report["expectations_matched"] == report["total"] else 1)
