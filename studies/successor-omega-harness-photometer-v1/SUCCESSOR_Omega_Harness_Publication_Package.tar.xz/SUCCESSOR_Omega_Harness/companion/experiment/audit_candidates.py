import argparse
import json
from fractions import Fraction as F
from pathlib import Path
import instrument as m


def audit():
    rows = []
    for signals, degree in ((1, 2), (2, 2), (2, 3), (2, 4)):
        times = m.times_for(signals)
        for index, response in enumerate(m.candidate_controls(signals)):
            c = m.Counter()
            c.phase = 'supplemental_candidate_audit'
            nuisance = m.nuisance_basis(times, degree, c)
            row = {'signals': signals, 'drift_degree': degree, 'candidate_index': index,
                   'times': [str(t) for t in times], 'controls': m.encode_matrix(response)}
            try:
                weights = m.estimator(nuisance, response, c)
                amplifications = m.row_l1(weights, c)
                risks = [m.calibrated_risk(a, c) for a in amplifications]
                wv, wr = m.matmul(weights, nuisance, c), m.matmul(weights, response, c)
                exact = all(a == 0 for rr in wv for a in rr) and wr == [[F(int(i == j)) for j in range(signals)] for i in range(signals)]
                admitted = exact and max(risks) <= m.TOL
                row.update({'weights': m.encode_matrix(weights), 'noise_amplification_l1': [str(a) for a in amplifications],
                            'worst_case_risk': [str(a) for a in risks], 'exact_identities': exact,
                            'admitted': admitted, 'reason': 'qualified' if admitted else 'risk_bound_exceeds_tolerance'})
            except m.Infeasible as e:
                row.update({'admitted': False, 'reason': str(e)})
            row['supplemental_audit_fraction_ops'] = c.ops
            rows.append(row)
    return {'scope': 'Post-main deterministic audit of every fixed candidate. It changes no protocol or result and is not included in primary budgeted costs.',
            'source': m.source_identity(), 'candidates': rows,
            'summary': [{'signals': k, 'drift_degree': d, 'examined': sum(r['signals'] == k and r['drift_degree'] == d for r in rows),
                         'qualified': sum(r['signals'] == k and r['drift_degree'] == d and r['admitted'] for r in rows),
                         'reasons': {reason: sum(r['signals'] == k and r['drift_degree'] == d and r['reason'] == reason for r in rows)
                                     for reason in sorted({r['reason'] for r in rows if r['signals'] == k and r['drift_degree'] == d})}}
                        for k, d in ((1, 2), (2, 2), (2, 3), (2, 4))]}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    target = Path(args.output)
    if target.exists():
        raise SystemExit('Choose a new path; prior candidate audit is preserved.')
    result = audit()
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result['summary'], indent=2))
