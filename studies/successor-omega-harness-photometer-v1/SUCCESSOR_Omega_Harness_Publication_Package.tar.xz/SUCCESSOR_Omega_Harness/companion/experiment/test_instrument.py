import copy
import unittest
from fractions import Fraction as F
import instrument as m


class PhotometerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.scalar = m.construct_capability({'signals': 1, 'drift_degree': 2})
        cls.dual = m.construct_capability({'signals': 2, 'drift_degree': 2})

    def test_original_scalar_protocol_exactly_recovered(self):
        self.assertEqual(self.scalar['weights'], [['-1/8', '5/8', '-5/8', '1/8']])
        self.assertEqual(self.scalar['noise_amplification_l1'], ['3/2'])

    def test_dual_decoder_independent_moments(self):
        w = m.decode_matrix(self.dual['weights'])
        r = m.decode_matrix(self.dual['controls'])
        times = [F(t) for t in self.dual['times']]
        for j, row in enumerate(w):
            self.assertEqual(sum(abs(a) for a in row), 1)
            for d in range(3):
                self.assertEqual(sum(a * t ** d for a, t in zip(row, times)), 0)
            for k in range(2):
                self.assertEqual(sum(a * rr[k] for a, rr in zip(row, r)), int(j == k))

    def test_known_large_polynomial_cancels_exactly(self):
        ts = [F(t) for t in self.dual['times']]
        r, w = m.decode_matrix(self.dual['controls']), m.decode_matrix(self.dual['weights'])
        signals = [F(7, 13), F(-11, 19)]
        y = m.observe(ts, r, signals, F(1), [F(10**30), F(-10**20), F(10**10)], [F(0)] * 6)
        z = [sum(a * b for a, b in zip(row, y)) for row in w]
        self.assertEqual(z, signals)

    def test_bounded_noise_extrema_interval_covers_truth(self):
        w = m.decode_matrix(self.dual['weights'])
        ts, r = [F(t) for t in self.dual['times']], m.decode_matrix(self.dual['controls'])
        for truth in (F(-1), F(-1, 2), F(0), F(1, 2), F(1)):
            for gain in (m.GMIN, F(1), m.GMAX):
                for ref_sign in (-1, 1):
                    for sample_sign in (-1, 1):
                        er = [m.ETA * ref_sign * (1 if a >= 0 else -1) for a in w[0]]
                        eo = [m.ETA * sample_sign * (1 if a >= 0 else -1) for a in w[0]]
                        ref = m.observe(ts, r, [F(1), F(1)], gain, [F(2), F(-3), F(4)], er)
                        obs = m.observe(ts, r, [truth, F(0)], gain, [F(-5), F(7), F(-11)], eo)
                        out = m.estimate_from_observations(self.dual, ref, obs)
                        self.assertTrue(out['accepted'])
                        self.assertLessEqual(F(out['signal_intervals'][0][0]), truth)
                        self.assertGreaterEqual(F(out['signal_intervals'][0][1]), truth)
                        self.assertLessEqual(abs(F(out['signal_estimates'][0]) - truth), m.TOL)

    def test_rank_infeasibility(self):
        with self.assertRaises(m.Infeasible):
            m.construct_capability({'signals': 2, 'drift_degree': 4})
        v = m.nuisance_basis([F(i) for i in range(6)], 2)
        with self.assertRaises(m.Infeasible):
            m.estimator(v, [[F(1), F(1)]] * 6)

    def test_scalar_cannot_be_relabelled_dual(self):
        result = m.validate_capability(self.scalar, {'signals': 2, 'drift_degree': 2})
        self.assertFalse(result['valid'])
        self.assertIn('signal_dimension_mismatch', result['reasons'])

    def test_corrupted_weight_rejected_even_after_rehash(self):
        bad = copy.deepcopy(self.dual)
        bad['weights'][0][0] = str(F(bad['weights'][0][0]) + F(1, 10))
        bad['capability_sha256'] = m.digest({k: v for k, v in bad.items() if k != 'capability_sha256'})
        result = m.validate_capability(bad, {'signals': 2, 'drift_degree': 2})
        self.assertFalse(result['valid'])
        self.assertIn('drift_annihilation_failed', result['reasons'])
        self.assertIn('signal_identity_failed', result['reasons'])

    def test_degree_change_requires_requalification(self):
        result = m.validate_capability(self.dual, {'signals': 2, 'drift_degree': 3})
        self.assertFalse(result['valid'])
        self.assertIn('nuisance_scope_mismatch', result['reasons'])

    def test_budget_never_overruns_counter(self):
        c = m.Counter(operation_cap=17)
        with self.assertRaises(m.BudgetExhausted):
            m.construct_capability({'signals': 2, 'drift_degree': 2}, counter=c)
        self.assertEqual(c.ops, 17)
        c = m.Counter(detector_cap=11)
        with self.assertRaises(m.BudgetExhausted):
            m.execute_mission(self.dual, {'signals': 2, 'drift_degree': 2}, c)
        self.assertEqual(c.detectors, 0)

    def test_cap_stops_before_acquisition(self):
        c = m.Counter()
        outcome = m.execute_mission(self.dual, {'signals': 2, 'drift_degree': 2, 'acquisition_cap': 11}, c)
        self.assertEqual(outcome['reason'], 'mission_acquisition_cap')
        self.assertEqual(c.detectors, 0)

    def test_source_binding_rejects(self):
        cap = copy.deepcopy(self.dual)
        cap['source']['implementation_sha256'] = '0' * 64
        cap['capability_sha256'] = m.digest({k: v for k, v in cap.items() if k != 'capability_sha256'})
        result = m.validate_capability(cap, {'signals': 2, 'drift_degree': 2})
        self.assertIn('source_or_protocol_mismatch', result['reasons'])

    def test_false_metadata_rejected_even_after_rehash(self):
        variants = [('noise_amplification_l1', ['0', '0'], 'noise_amplification_metadata_mismatch'),
                    ('worst_case_calibrated_error', ['0', '0'], 'risk_metadata_mismatch'),
                    ('nuisance_basis', [['0']] * 6, 'nuisance_metadata_mismatch'),
                    ('authority', {'production_grant': 'ancestor', 'inheritable': True}, 'unsupported_authority_claim')]
        for field, value, reason in variants:
            cap = copy.deepcopy(self.dual)
            cap[field] = value
            cap['capability_sha256'] = m.digest({k: v for k, v in cap.items() if k != 'capability_sha256'})
            self.assertIn(reason, m.validate_capability(cap, {'signals': 2, 'drift_degree': 2})['reasons'])

    def test_unadmitted_controls_rejected_even_when_identities_hold(self):
        cap = copy.deepcopy(self.dual)
        cap['controls'] = [[str(F(v) * 2) for v in row] for row in cap['controls']]
        cap['weights'] = [[str(F(v) / 2) for v in row] for row in cap['weights']]
        cap['noise_amplification_l1'] = ['1/2', '1/2']
        cap['worst_case_calibrated_error'] = [str(m.calibrated_risk(F(1, 2)))] * 2
        cap['capability_sha256'] = m.digest({k: v for k, v in cap.items() if k != 'capability_sha256'})
        result = m.validate_capability(cap, {'signals': 2, 'drift_degree': 2})
        self.assertIn('unadmitted_control_program', result['reasons'])
        self.assertNotIn('signal_identity_failed', result['reasons'])

    def test_full_risk_formula_for_large_noise(self):
        self.assertEqual(m.calibrated_risk(F(500)), F(1))

    def test_successor_package_has_no_inherited_authority(self):
        context = m.run_journey({'signals': 1, 'drift_degree': 2, 'seed': 1})
        package = context['artifacts']['out_evolve']
        self.assertEqual(package['successor_proof_status'], 'UNQUALIFIED')
        self.assertIsNone(package['successor_authority'])
        self.assertFalse(package['inherited_production_authority'])
        self.assertFalse(package['inherited_proof_status'])

    def test_parent_recipe_is_consumed_and_regridded(self):
        ancestor = m.run_journey({'signals': 1, 'drift_degree': 2, 'seed': 1})
        parent = ancestor['artifacts']['out_evolve']
        context = {'spec': {'signals': 2, 'drift_degree': 2, 'seed': 2}, 'parent': parent}
        context = m.run_stage('identify', context)
        context = m.run_stage('out_learn', context)
        learned = context['artifacts']['out_learn']
        self.assertEqual(learned['consumed_parent_recipe_sha256'], parent['capability']['nuisance_recipe']['recipe_sha256'])
        self.assertTrue(learned['parent_semantics_reused'])
        self.assertFalse(learned['parent_sampling_basis_reused_verbatim'])
        self.assertEqual(len(learned['basis']), 6)
        self.assertEqual(learned['basis'][4], ['1', '4', '16'])

    def test_corrupt_parent_recipe_cannot_be_inherited(self):
        ancestor = m.run_journey({'signals': 1, 'drift_degree': 2, 'seed': 1})
        parent = copy.deepcopy(ancestor['artifacts']['out_evolve'])
        parent['capability']['nuisance_recipe']['monomial_exponents'] = [0, 1, 3]
        parent['capability']['capability_sha256'] = m.digest({k: v for k, v in parent['capability'].items() if k != 'capability_sha256'})
        with self.assertRaises(m.Infeasible):
            m.run_stage('out_learn', {'spec': {'signals': 2, 'drift_degree': 2}, 'parent': parent})

    def test_shared_counter_costs_sum(self):
        c = m.Counter()
        context = {'spec': {'signals': 1, 'drift_degree': 2, 'seed': 42}, 'artifacts': {}, 'costs': {}}
        for stage in m.STAGES:
            context = m.run_stage(stage, context, c)
        self.assertEqual(sum(v['fraction_ops'] for v in context['costs'].values()), c.ops)
        self.assertEqual(sum(v['simulated_detector_readings'] for v in context['costs'].values()), c.detectors)


if __name__ == '__main__':
    unittest.main()
