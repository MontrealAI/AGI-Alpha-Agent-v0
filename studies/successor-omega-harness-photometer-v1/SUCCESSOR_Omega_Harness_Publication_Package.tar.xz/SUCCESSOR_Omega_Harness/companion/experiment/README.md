# SUCCESSOR Ω — programmable photometer research companion

This local, wallet-free companion constructs and tests a measurement capability. An accepted scalar photometer supplies a source-bound polynomial-nuisance recipe. A successor actually evaluates that recipe on a new sampling grid, constructs a two-output decoder, obtains fresh calibration and sample evidence, and packages a new capability with no inherited production authority.

The detector is a **computational emulator**, not physical instrumentation. Python's exact `Fraction` arithmetic is used for the numerical certificate. The released-source Alpha runtime integration is a separate package component; these scientific callbacks do not claim Fleet, Jobs, mainnet or production activation.

## Pinned setup

The executed environment was Python **3.12.14** on Linux. These scientific programs have **no third-party Python dependencies**. The interpreter's standard-library `random.Random` supplies the specified pseudorandom integer draws; the raw held-out missions and observations are retained. Exact scientific results were rerun and compared, while CPU/wall times are allowed to vary.

```bash
python3 --version
python3 -m unittest -v test_instrument.py
python3 instrument.py demo --output my-photometer-demo.json
python3 reproduce.py --output my-new-reproduction
```

Run these commands from this directory. Use a new filename for the single demonstration and a new empty directory for `reproduce.py`. The reproduction wrapper refuses to overwrite the frozen evidence. The lower-level, frozen `run_experiments.py` is retained as the exact evaluated runner; its `--output` path must also be a new directory when called directly.

## A three-minute reading of the demonstration

1. Open `results/demo_ancestor.json`. The original four-reading estimator has weights `(-1,5,-5,1)/8` at times `(0,2,3,5)`. It removes quadratic ambient drift and measures one spectral amplitude after a fresh reference.
2. Open `results/demo_successor.json`. The child consumes the parent's nuisance recipe hash, re-evaluates it on times `(0,1,2,3,4,5)`, and builds a **new two-output estimator**. Its two rows are `(1,-1,-2,2,1,-1)/8` and `(1,-3,4,-4,3,-1)/16` for the stored two-column control matrix. Both rows exactly remove degree-two drift and recover their own amplitude without cross-talk.
3. Inspect `out_execute`: raw reference and sample readings, gain interval, signal intervals, independent identity checks, source-bound receipt, hidden simulator truth and measured errors are all retained. A six-reading reference plus six-reading sample uses **12 readings**. Two separately calibrated four-reading scalar programs require **16**.
4. Inspect `out_evolve`: the accepted result supplies evidence and reusable representation, but the proposed child starts `UNQUALIFIED` with `successor_authority: null`.
5. Read `results/failure_map.json`. Rank, scope, corrupted weights and an insufficient budget are rejected. Two more difficult failures—gain changing after calibration and interference shaped exactly like a valid signal—**pass internal validation but fail the hidden-truth check**. Those are unresolved physical assumptions, not successful detection.

The paper's visual research companion presents these same records more accessibly. The files here remain the exact executable evidence.

## Seven actual computations

`instrument.run_stage(stage, context, counter=None)` accepts the seven stage names in `instrument.STAGES`. Initialize with:

```python
context = {'spec': {'signals': 1, 'drift_degree': 2, 'seed': 20261024, 'acquisition_cap': 12}, 'artifacts': {}, 'costs': {}}
```

For the successor, set `signals` to `2` and supply `parent=ancestor['artifacts']['out_evolve']`. Each callback returns a new JSON-serializable context.

| Stage | Actual computation and artifact |
|---|---|
| Identify | Computes ranks of the ambient-plus-unmodulated design, exposing the original confounding. |
| Out-Learn | Builds or verifies a polynomial-nuisance recipe, evaluates it on the current time grid and computes its rank. This is model-based representation construction, not empirical discovery of a physical law. |
| Out-Think | Tests the necessary dimension condition and names exact rank, error, freshness and source obligations. |
| Out-Design | Enumerates the finite response library, solves exact least-norm decoders, and checks identity, annihilation and bounded-error conditions. |
| Out-Strategise | Compares the required reading count with the mission cap before acquisition. |
| Out-Execute | Obtains fresh emulator reference/sample observations, derives the gain and signal intervals and independently rechecks the capability. |
| Out-Evolve | Packages the accepted capability and provenance, proposes a changed requirement and explicitly withholds current child proof and authority. |

The shared numerical solver was supplied by the researchers. It was **not invented by the scalar mission**. The inherited nuisance recipe is a small actual data artifact; a direct expert can construct an equivalent one. First-transition inheritance is not shown to be cheaper, and every stage name is not claimed to be causally necessary. The stage-linked structural probes are distinguished from direct altered-computation comparisons.

## Frozen protocol and results

`protocol.json` and `protocol.sha256` precede the main evaluation. `pre_main_clarification.json` records independent-review corrections and the precise transfer/cost interpretation without altering thresholds, seeds, candidate controls or budgets. `implementation_freeze.json` binds the evaluated source files.

The study uses four paired campaigns of 48 held-out numerical missions. Each method receives the same ordered worlds, nominal tools, cache eligibility, validators and resource vector: at most 800 simulated detector readings and 2,000,000 counted rational-kernel operations per campaign.

| Method | Qualified missions | Detector readings | Counted Fraction operations |
|---|---:|---:|---:|
| Harness scientific reuse policy | 192/192 | 2,112 | 609,524 |
| Competent conventional reuse | 192/192 | 2,112 | 609,524 |
| Expert-coded satisficing reuse | 192/192 | 2,112 | 169,732 |
| Exhaustive rebuilding | 192/192 | 2,112 | 7,953,264 |

**All methods tie on qualified coverage at the frozen budget.** The expert-coded reference wins counted computation while satisfying the same quality threshold. Harness/conventional scientific outputs and counted costs agree exactly case by case. Reuse saves construction work relative to rebuilding, but does not establish a unique Harness efficiency advantage.

Raw observations and costs are in `results/raw_results.jsonl`; compact per-mission rows are in `results/mission_metrics.csv`; method/campaign summaries, failed proposals, negative controls, recovery and disclosures accompany them. No held-out threshold or budget was changed after inspection.

## Cost and evidence boundaries

Simulated detector readings, counted `Fraction` additions/subtractions/multiplications/divisions, measured CPU/wall time, runtime events and unknown labor are separate quantities. The rational counter covers representation, construction, certificate, demodulation and interval kernels. Emulator generation, hidden-truth evaluation, integer planning, candidate bookkeeping, hashing and serialization are outside that counter but inside measured time. It is not a universal computational-cost measure.

No human participants were studied. The main script required zero interactive prompts and zero manual overrides while running. Authoring, review, integration and future operator time are unknown, not zero. No paid service calls or financial transactions are used. Allocation price, infrastructure depreciation and commercial labor cost are unmeasured.

`results/recovery.json` retains a corrupt candidate's rejection, the unchanged incumbent, a fresh incumbent mission and a newly constructed cubic-drift successor. This pure local simulation is not evidence of exactly-once external effects. Runtime crash/uncertainty and signed-event tests are supplied separately by the Alpha integration.

## Rebuild verification

`reproduce.py` reruns all 18 scientific tests, runs the full frozen study into a new directory, and compares exact scientific records, arithmetic counts, negative controls, recipes, ancestry and disclosures with the original. It excludes only CPU/wall-time fields and environment metadata from equality. The verified scientific digest is:

```text
da9d53f64df6bd369f166a42483ea60ea05c0c8c891ddc73e0d10304b07112a3
```

Keep the original `results/` directory and `implementation_freeze.json` unchanged. Corrections should use a new directory and retain the original run.
