import argparse
import hashlib
import json
import platform
import subprocess
import sys
from pathlib import Path
from run_experiments import clean_timing


ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', required=True)
    parser.add_argument('--reference', default=str(ROOT / 'results'))
    args = parser.parse_args()
    output, reference = Path(args.output).resolve(), Path(args.reference).resolve()
    if output == reference or (output.exists() and any(output.iterdir())):
        raise SystemExit('Choose a new empty output directory. Frozen evidence is never overwritten by this wrapper.')
    output.mkdir(parents=True, exist_ok=True)
    tests = subprocess.run([sys.executable, '-m', 'unittest', '-v', 'test_instrument.py'], cwd=ROOT,
                           text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (output / 'tests.log').write_text(tests.stdout)
    if tests.returncode:
        raise SystemExit('Scientific tests failed. See the new output directory; no main rerun performed.')
    result = subprocess.run([sys.executable, str(ROOT / 'run_experiments.py'), '--output', str(output / 'results')],
                            cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (output / 'run.log').write_text(result.stdout)
    if result.returncode:
        raise SystemExit('Reproduction run failed. Original evidence remains unchanged.')
    rerun = output / 'results'
    names = ('summary.json', 'campaigns.json', 'failure_map.json', 'stage_ablations.json', 'recovery.json',
             'demo_ancestor.json', 'demo_successor.json', 'heldout_missions.json', 'interventions.json')
    comparisons = {}
    for name in names:
        expected = clean_timing(json.loads((reference / name).read_text()))
        actual = clean_timing(json.loads((rerun / name).read_text()))
        comparisons[name] = actual == expected
    expected_raw = [clean_timing(json.loads(line)) for line in (reference / 'raw_results.jsonl').read_text().splitlines()]
    actual_raw = [clean_timing(json.loads(line)) for line in (rerun / 'raw_results.jsonl').read_text().splitlines()]
    comparisons['raw_results.jsonl'] = actual_raw == expected_raw
    original_digest = json.loads((reference / 'summary.json').read_text())['scientific_digest']
    rerun_digest = json.loads((rerun / 'summary.json').read_text())['scientific_digest']
    comparisons['scientific_digest'] = original_digest == rerun_digest
    record = {'verified': all(comparisons.values()), 'comparisons': comparisons,
              'reference_scientific_digest': original_digest, 'rerun_scientific_digest': rerun_digest,
              'reference_raw_results_sha256': hashlib.sha256((reference / 'raw_results.jsonl').read_bytes()).hexdigest(),
              'rerun_raw_results_sha256': hashlib.sha256((rerun / 'raw_results.jsonl').read_bytes()).hexdigest(),
              'timing_fields_expected_to_differ': True,
              'note': 'All scientific records, exact arithmetic counts, failures, ancestry and interventions compared after removing timing fields. Wall/CPU times are host observations.',
              'python': platform.python_version(), 'operator_prompts_during_run': 0}
    (output / 'reproduction_record.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record, indent=2))
    if not record['verified']:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
