import argparse
import copy
import hashlib
import itertools
import json
import random
import time
from fractions import Fraction as F
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ETA, GMIN, GMAX, TOL, SMAX = F(1, 500), F(4, 5), F(6, 5), F(1, 50), F(1)
STAGES = ('identify', 'out_learn', 'out_think', 'out_design', 'out_strategise', 'out_execute', 'out_evolve')


class BudgetExhausted(Exception):
    pass


class Infeasible(Exception):
    pass


class Counter:
    def __init__(self, operation_cap=None, detector_cap=None):
        self.ops = 0
        self.detectors = 0
        self.operation_cap = operation_cap
        self.detector_cap = detector_cap
        self.phase = 'unspecified'
        self.phases = {}

    def charge(self, n=1):
        if self.operation_cap is not None and self.ops + n > self.operation_cap:
            raise BudgetExhausted('fraction_arithmetic_budget')
        self.ops += n
        self.phases[self.phase] = self.phases.get(self.phase, 0) + n

    def acquire(self, n):
        if self.detector_cap is not None and self.detectors + n > self.detector_cap:
            raise BudgetExhausted('detector_reading_budget')
        self.detectors += n


def op(c, kind, a, b):
    if c is not None:
        c.charge()
    if kind == '+':
        return a + b
    if kind == '-':
        return a - b
    if kind == '*':
        return a * b
    if kind == '/':
        return a / b
    raise ValueError(kind)


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def source_identity():
    return {'implementation_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'protocol_sha256': hashlib.sha256((ROOT / 'protocol.json').read_bytes()).hexdigest()}


def encode_matrix(a):
    return [[str(v) for v in row] for row in a]


def decode_matrix(a):
    return [[F(v) for v in row] for row in a]


def transpose(a):
    return [list(row) for row in zip(*a)]


def matmul(a, b, c=None):
    bt = transpose(b)
    ans = []
    for row in a:
        out = []
        for col in bt:
            v = F(0)
            for x, y in zip(row, col):
                v = op(c, '+', v, op(c, '*', x, y))
            out.append(v)
        ans.append(out)
    return ans


def rank(a, c=None):
    x = [list(row) for row in a]
    if not x:
        return 0
    pivot_row = 0
    for col in range(len(x[0])):
        pivot = next((r for r in range(pivot_row, len(x)) if x[r][col]), None)
        if pivot is None:
            continue
        x[pivot_row], x[pivot] = x[pivot], x[pivot_row]
        p = x[pivot_row][col]
        x[pivot_row] = [op(c, '/', v, p) for v in x[pivot_row]]
        for row in range(pivot_row + 1, len(x)):
            q = x[row][col]
            if q:
                x[row] = [op(c, '-', v, op(c, '*', q, u)) for v, u in zip(x[row], x[pivot_row])]
        pivot_row += 1
        if pivot_row == len(x):
            break
    return pivot_row


def inverse(a, c=None):
    n = len(a)
    x = [list(row) + [F(int(i == j)) for j in range(n)] for i, row in enumerate(a)]
    for col in range(n):
        pivot = next((r for r in range(col, n) if x[r][col]), None)
        if pivot is None:
            raise Infeasible('singular_design')
        x[col], x[pivot] = x[pivot], x[col]
        p = x[col][col]
        x[col] = [op(c, '/', v, p) for v in x[col]]
        for row in range(n):
            if row == col:
                continue
            q = x[row][col]
            if q:
                x[row] = [op(c, '-', v, op(c, '*', q, u)) for v, u in zip(x[row], x[col])]
    return [row[n:] for row in x]


def times_for(signals):
    return [F(v) for v in ((0, 2, 3, 5) if signals == 1 else (0, 1, 2, 3, 4, 5))]


def nuisance_basis(times, degree, c=None):
    basis = []
    for t in times:
        row = [F(1)]
        for _ in range(degree):
            row.append(op(c, '*', row[-1], t))
        basis.append(row)
    return basis


def make_nuisance_recipe(degree):
    recipe = {'schema': 'polynomial-nuisance-recipe/1', 'coordinate': 'mission_relative_detector_time',
              'field': 'rational', 'monomial_exponents': list(range(degree + 1)),
              'maximum_degree': degree, 'coefficients_may_change_between_blocks': True,
              'source': source_identity()}
    recipe['recipe_sha256'] = digest(recipe)
    return recipe


def evaluate_nuisance_recipe(recipe, times, degree, c=None):
    if recipe != make_nuisance_recipe(degree):
        raise Infeasible('nuisance_recipe_source_or_scope_mismatch')
    result = []
    for t in times:
        powers = [F(1)]
        for _ in range(max(recipe['monomial_exponents'])):
            powers.append(op(c, '*', powers[-1], t))
        result.append([powers[exponent] for exponent in recipe['monomial_exponents']])
    return result


def candidate_controls(signals):
    if signals == 1:
        return [[[F(1)], [F(1)], [F(-1)], [F(-1)]]]
    if signals != 2:
        raise Infeasible('unsupported_signal_dimension')
    columns = sorted([p for p in itertools.product((-1, 1), repeat=6) if p[0] == 1 and sum(p) == 0])
    return [[[F(a), F(b)] for a, b in zip(u, v)] for u, v in itertools.combinations(columns, 2)]


def estimator(v, r, c=None):
    b = [vr + rr for vr, rr in zip(v, r)]
    ncols = len(b[0])
    if ncols > len(b):
        raise Infeasible('more_unknowns_than_readings')
    bt = transpose(b)
    gram = matmul(bt, b, c)
    pinv = matmul(inverse(gram, c), bt, c)
    return pinv[-len(r[0]):]


def row_l1(w, c=None):
    ans = []
    for row in w:
        s = F(0)
        for a in row:
            s = op(c, '+', s, abs(a))
        ans.append(s)
    return ans


def calibrated_risk(a, c=None):
    e = op(c, '*', ETA, a)
    two_e = op(c, '*', F(2), e)
    return min(SMAX, max(op(c, '/', two_e, op(c, '+', GMIN, two_e)), op(c, '/', e, GMIN)))


def applicability(degree):
    return {'gain_range': [str(GMIN), str(GMAX)], 'noise_bound': str(ETA),
            'signal_range': ['-1', '1'], 'gain_stable_within_mission': True,
            'polynomial_drift_max_degree': degree, 'physical_validation': False}


def normalized_spec(spec):
    result = {'signals': 1, 'drift_degree': 2, 'seed': 20261024, 'acquisition_cap': 12}
    result.update(spec)
    if result['signals'] not in (1, 2) or result['drift_degree'] < 0:
        raise Infeasible('unsupported_specification')
    return result


def construct_capability(spec, strategy='search', counter=None, learned_basis=None, nuisance_recipe=None):
    c = counter or Counter()
    c.phase = 'construction'
    spec = normalized_spec(spec)
    k, degree = spec['signals'], spec['drift_degree']
    ts = times_for(k)
    recipe = nuisance_recipe or make_nuisance_recipe(degree)
    if recipe != make_nuisance_recipe(degree):
        raise Infeasible('nuisance_recipe_source_or_scope_mismatch')
    v = decode_matrix(learned_basis) if learned_basis is not None else evaluate_nuisance_recipe(recipe, ts, degree, c)
    expected = nuisance_basis(ts, degree, c)
    if v != expected:
        raise Infeasible('incorrect_nuisance_representation')
    if len(ts) < degree + 1 + k:
        raise Infeasible('more_unknowns_than_readings')
    best, tried, nonsingular, acceptable = None, 0, 0, 0
    failures = {}
    for r in candidate_controls(k):
        tried += 1
        try:
            w = estimator(v, r, c)
        except Infeasible as e:
            failures[str(e)] = failures.get(str(e), 0) + 1
            continue
        nonsingular += 1
        amps = row_l1(w, c)
        risks = [calibrated_risk(a, c) for a in amps]
        if max(risks) > TOL:
            failures['risk_bound_exceeds_tolerance'] = failures.get('risk_bound_exceeds_tolerance', 0) + 1
            continue
        acceptable += 1
        energy = F(0)
        for row in w:
            for val in row:
                energy = op(c, '+', energy, op(c, '*', val, val))
        key = (max(amps), energy, tuple(tuple(row) for row in r))
        if best is None or key < best[0]:
            best = (key, r, w, amps, risks)
        if strategy == 'expert':
            break
    if best is None:
        raise Infeasible('no_candidate_meets_quality')
    _, r, w, amps, risks = best
    capability = {'schema': 'successor-photometer-capability/1', 'signals': k, 'drift_degree': degree,
                  'times': [str(t) for t in ts], 'controls': encode_matrix(r), 'nuisance_basis': encode_matrix(v),
                  'nuisance_recipe': recipe,
                  'weights': encode_matrix(w), 'noise_amplification_l1': [str(a) for a in amps],
                  'worst_case_calibrated_error': [str(a) for a in risks], 'source': source_identity(),
                  'construction': {'strategy': strategy, 'candidates_tried': tried, 'nonsingular_candidates': nonsingular,
                                   'quality_candidates': acceptable, 'rejected_candidates': failures},
                  'applicability': applicability(degree),
                  'authority': {'production_grant': None, 'inheritable': False}}
    capability['capability_sha256'] = digest(capability)
    validation = validate_capability(capability, spec, c)
    if not validation['valid']:
        raise AssertionError(validation)
    return capability


def validate_capability(capability, spec, counter=None):
    c = counter or Counter()
    c.phase = 'requalification'
    spec = normalized_spec(spec)
    reasons = []
    if capability.get('schema') != 'successor-photometer-capability/1':
        reasons.append('unsupported_capability_schema')
    core = {k: v for k, v in capability.items() if k != 'capability_sha256'}
    if capability.get('capability_sha256') != digest(core):
        reasons.append('capability_hash_mismatch')
    if capability.get('source') != source_identity():
        reasons.append('source_or_protocol_mismatch')
    if capability.get('signals') != spec['signals']:
        reasons.append('signal_dimension_mismatch')
    if capability.get('drift_degree') != spec['drift_degree']:
        reasons.append('nuisance_scope_mismatch')
    if capability.get('applicability') != applicability(spec['drift_degree']):
        reasons.append('world_applicability_mismatch')
    if capability.get('nuisance_recipe') != make_nuisance_recipe(spec['drift_degree']):
        reasons.append('nuisance_recipe_mismatch')
    if capability.get('authority') != {'production_grant': None, 'inheritable': False}:
        reasons.append('unsupported_authority_claim')
    try:
        w, r = decode_matrix(capability['weights']), decode_matrix(capability['controls'])
        ts = [F(t) for t in capability['times']]
        k = spec['signals']
        v = nuisance_basis(ts, spec['drift_degree'], c)
        if ts != times_for(k):
            reasons.append('unadmitted_sampling_times')
        if r not in candidate_controls(k):
            reasons.append('unadmitted_control_program')
        if capability.get('nuisance_basis') != encode_matrix(v):
            reasons.append('nuisance_metadata_mismatch')
        expected_shape = (len(w) == k and all(len(row) == len(ts) for row in w)
                          and len(r) == len(ts) and all(len(row) == k for row in r))
        if not expected_shape:
            reasons.append('estimator_shape_mismatch')
        else:
            wv, wr = matmul(w, v, c), matmul(w, r, c)
            if any(a for row in wv for a in row):
                reasons.append('drift_annihilation_failed')
            if wr != [[F(int(i == j)) for j in range(k)] for i in range(k)]:
                reasons.append('signal_identity_failed')
            amps = row_l1(w, c)
            risks = [calibrated_risk(a, c) for a in amps]
            if capability.get('noise_amplification_l1') != [str(a) for a in amps]:
                reasons.append('noise_amplification_metadata_mismatch')
            if capability.get('worst_case_calibrated_error') != [str(a) for a in risks]:
                reasons.append('risk_metadata_mismatch')
            if any(a > TOL for a in risks):
                reasons.append('noise_bound_failed')
    except (KeyError, ValueError, TypeError, ZeroDivisionError) as e:
        reasons.append('malformed_artifact:' + type(e).__name__)
    return {'valid': not reasons, 'reasons': reasons, 'checks': ['content_hash', 'source_binding', 'scope', 'WV=0', 'WR=I', 'error_bound']}


def draw_world(spec):
    spec = normalized_spec(spec)
    rng = random.Random(spec['seed'])
    k, d, n = spec['signals'], spec['drift_degree'], len(times_for(spec['signals']))
    return {'signals': [F(rng.randint(-900, 900), 1000) for _ in range(k)],
            'gain': F(rng.randint(800, 1200), 1000),
            'reference_drift': [F(rng.randint(-50, 50), 10) for _ in range(d + 1)],
            'sample_drift': [F(rng.randint(-50, 50), 10) for _ in range(d + 1)],
            'reference_noise': [F(rng.randint(-1000, 1000), 500000) for _ in range(n)],
            'sample_noise': [F(rng.randint(-1000, 1000), 500000) for _ in range(n)]}


def observe(times, controls, signals, gain, drift, noise, interference=None):
    ans = []
    for i, (t, row) in enumerate(zip(times, controls)):
        value = gain * sum((a * b for a, b in zip(row, signals)), F(0))
        value += sum((a * t ** j for j, a in enumerate(drift)), F(0))
        value += noise[i]
        if interference is not None:
            value += interference[i]
        ans.append(value)
    return ans


def estimate_from_observations(capability, reference, sample, counter=None):
    c = counter or Counter()
    c.phase = 'execution'
    w = decode_matrix(capability['weights'])
    amps = row_l1(w, c)
    zref = [row[0] for row in matmul(w, [[a] for a in reference], c)]
    z = [row[0] for row in matmul(w, [[a] for a in sample], c)]
    eps = [op(c, '*', ETA, a) for a in amps]
    lo = max([GMIN] + [op(c, '-', a, e) for a, e in zip(zref, eps)])
    hi = min([GMAX] + [op(c, '+', a, e) for a, e in zip(zref, eps)])
    if lo > hi or lo <= 0:
        return {'accepted': False, 'reason': 'inconsistent_gain_interval', 'gain_interval': [str(lo), str(hi)]}
    intervals, estimates, radii = [], [], []
    for value, e in zip(z, eps):
        bounds = [op(c, '/', a, g) for a in (op(c, '-', value, e), op(c, '+', value, e)) for g in (lo, hi)]
        lower, upper = max(-SMAX, min(bounds)), min(SMAX, max(bounds))
        if lower > upper:
            return {'accepted': False, 'reason': 'signal_interval_empty', 'gain_interval': [str(lo), str(hi)]}
        estimate = op(c, '/', op(c, '+', lower, upper), F(2))
        radius = op(c, '/', op(c, '-', upper, lower), F(2))
        intervals.append([str(lower), str(upper)])
        estimates.append(str(estimate))
        radii.append(str(radius))
    accepted = all(F(r) <= TOL for r in radii)
    return {'accepted': accepted, 'reason': 'qualified_under_declared_model' if accepted else 'observed_interval_too_wide',
            'gain_interval': [str(lo), str(hi)], 'demodulated_reference': [str(a) for a in zref],
            'demodulated_sample': [str(a) for a in z], 'signal_intervals': intervals,
            'signal_estimates': estimates, 'interval_radii': radii}


def execute_mission(capability, spec, counter=None, world=None, sample_gain=None, sample_interference=None):
    c = counter or Counter()
    spec = normalized_spec(spec)
    validation = validate_capability(capability, spec, c)
    if not validation['valid']:
        return {'accepted': False, 'oracle_qualified': False, 'reason': 'capability_rejected', 'validation': validation}
    n = len(capability['times'])
    if 2 * n > spec['acquisition_cap']:
        return {'accepted': False, 'oracle_qualified': False, 'reason': 'mission_acquisition_cap', 'validation': validation}
    c.acquire(2 * n)
    world = world or draw_world(spec)
    ts, r = [F(t) for t in capability['times']], decode_matrix(capability['controls'])
    reference = observe(ts, r, [F(1)] * spec['signals'], world['gain'], world['reference_drift'], world['reference_noise'])
    sample = observe(ts, r, world['signals'], world['gain'] if sample_gain is None else sample_gain,
                     world['sample_drift'], world['sample_noise'], sample_interference)
    outcome = estimate_from_observations(capability, reference, sample, c)
    true_signals = world['signals']
    errors = [abs(F(a) - b) for a, b in zip(outcome.get('signal_estimates', []), true_signals)]
    covers = outcome['accepted'] and all(F(lo) <= truth <= F(hi) for (lo, hi), truth in zip(outcome['signal_intervals'], true_signals))
    oracle_qualified = bool(covers and len(errors) == len(true_signals) and all(a <= TOL for a in errors))
    outcome.update({'oracle_qualified': oracle_qualified, 'capability_sha256': capability['capability_sha256'],
                    'validation': validation, 'spec': spec, 'raw_reference': [str(a) for a in reference],
                    'raw_sample': [str(a) for a in sample], 'oracle': {'signals': [str(a) for a in true_signals],
                    'gain': str(world['gain']), 'actual_errors': [str(a) for a in errors],
                    'model_scope_holds': sample_gain is None and sample_interference is None},
                    'detector_readings': 2 * n})
    outcome['receipt_sha256'] = digest(outcome)
    return outcome


def run_stage(stage, context, counter=None):
    if stage not in STAGES:
        raise ValueError('unknown_stage:' + stage)
    context = copy.deepcopy(context)
    spec = normalized_spec(context.get('spec', {}))
    context['spec'] = spec
    artifacts = context.setdefault('artifacts', {})
    costs = context.setdefault('costs', {})
    c = counter or Counter()
    initial_ops, initial_detectors = c.ops, c.detectors
    initial_phases = dict(c.phases)
    c.phase = stage
    wall, cpu = time.perf_counter_ns(), time.process_time_ns()
    k, degree = spec['signals'], spec['drift_degree']
    ts = times_for(k)
    if stage == 'identify':
        v = nuisance_basis(ts, degree, c)
        baseline = [row + [F(1)] * k for row in v]
        r0, r1 = rank(v, c), rank(baseline, c)
        artifact = {'mission': 'Recover one spectral amplitude' if k == 1 else 'Separate two spectral amplitudes in one bounded sequence',
                    'unmodulated_design_rank': r1, 'nuisance_rank': r0,
                    'required_rank': r0 + k, 'baseline_identifiable': r1 == r0 + k,
                    'constraint': 'Ambient offset and unmodulated amplitudes are linearly confounded.',
                    'acquisition_cap': spec['acquisition_cap']}
    elif stage == 'out_learn':
        parent = context.get('parent', {})
        prior = parent.get('capability', {})
        compatible = bool(parent.get('accepted_parent') and prior and prior.get('drift_degree') == degree)
        if compatible:
            parent_check = validate_capability(prior, {'signals': prior['signals'], 'drift_degree': prior['drift_degree']}, c)
            if not parent_check['valid']:
                raise Infeasible('parent_representation_provenance_rejected:' + ','.join(parent_check['reasons']))
            recipe = copy.deepcopy(prior['nuisance_recipe'])
        else:
            recipe = make_nuisance_recipe(degree)
        c.phase = stage
        v = evaluate_nuisance_recipe(recipe, ts, degree, c)
        artifact = {'basis': encode_matrix(v), 'times': [str(t) for t in ts], 'basis_rank': rank(v, c),
                    'method': 'Construct the nuisance representation from the declared polynomial model.',
                    'declared_world_assumption': 'Polynomial drift degree is bounded; it is not inferred universally from finite traces.',
                    'parent_semantics_reused': compatible,
                    'nuisance_recipe': recipe, 'consumed_parent_recipe_sha256': recipe['recipe_sha256'] if compatible else None,
                    'consumed_parent_capability_sha256': prior.get('capability_sha256') if compatible else None,
                    'representation_origin': 'evaluated_parent_constructed_recipe' if compatible else 'fresh_recipe_construction',
                    'parent_sampling_basis_reused_verbatim': compatible and prior.get('times') == [str(t) for t in ts],
                    'current_basis_reconstructed': True, 'fresh_gain_reference_required': True}
    elif stage == 'out_think':
        v = decode_matrix(artifacts['out_learn']['basis'])
        nuisance_rank = rank(v, c)
        artifact = {'nuisance_rank': nuisance_rank, 'needed_independent_signal_columns': k,
                    'readings_available': len(ts), 'necessary_dimension_condition': nuisance_rank + k <= len(ts),
                    'candidate_count': len(candidate_controls(k)),
                    'criterion': 'rank([V,R]) = rank(V) + signals',
                    'proof_obligations': ['W V = 0', 'W R = I', 'bounded calibrated error', 'fresh gain reference', 'source identity']}
    elif stage == 'out_design':
        if context.get('cached_capability') is not None:
            artifact = copy.deepcopy(context['cached_capability'])
            check = validate_capability(artifact, spec, c)
            if not check['valid']:
                raise Infeasible('cached_capability_requalification_failed:' + ','.join(check['reasons']))
        else:
            strategy = context.get('policy', {}).get('constructor', 'search')
            artifact = construct_capability(spec, strategy=strategy, counter=c, learned_basis=artifacts['out_learn']['basis'],
                                            nuisance_recipe=artifacts['out_learn']['nuisance_recipe'])
    elif stage == 'out_strategise':
        capability = artifacts['out_design']
        reads = 2 * len(capability['times'])
        artifact = {'program': 'joint reference followed by joint sample' if k == 2 else 'scalar reference followed by scalar sample',
                    'detector_readings_required': reads, 'detector_reading_cap': spec['acquisition_cap'],
                    'plan_admitted': reads <= spec['acquisition_cap'], 'separate_scalar_channel_readings': 8 * k,
                    'authority': 'local pure simulator only; no production grant',
                    'decision': 'execute' if reads <= spec['acquisition_cap'] else 'stop_before_acquisition'}
    elif stage == 'out_execute':
        if not artifacts['out_strategise']['plan_admitted']:
            artifact = {'accepted': False, 'oracle_qualified': False, 'reason': 'mission_acquisition_cap'}
        else:
            artifact = execute_mission(artifacts['out_design'], spec, c)
    elif stage == 'out_evolve':
        outcome = artifacts['out_execute']
        capability = artifacts['out_design']
        accepted = bool(outcome.get('accepted'))
        next_spec = dict(spec)
        next_spec.update({'signals': 2, 'drift_degree': degree if k == 1 else degree + 1, 'seed': spec['seed'] + 1})
        artifact = {'schema': 'successor-photometer-lineage/1', 'accepted_parent': accepted,
                    'parent_receipt_sha256': outcome.get('receipt_sha256'),
                    'capability': capability if accepted else None,
                    'successor_requirement': next_spec,
                    'successor_change': 'one amplitude to two distinct amplitudes' if k == 1 else 'higher-order nuisance rejection',
                    'transferable': ['parent-constructed nuisance recipe', 'historical raw evidence'],
                    'shared_preexisting_software': ['source-pinned numerical solver'],
                    'requires_fresh_work': ['sampling-grid nuisance basis', 'signal-specific decoder', 'noise certificate', 'gain interval', 'current mission proof'],
                    'successor_proof_status': 'UNQUALIFIED', 'successor_authority': None,
                    'inherited_proof_status': False, 'inherited_production_authority': False,
                    'retain_incumbent_on_failure': True}
        artifact['lineage_sha256'] = digest(artifact)
    elapsed_wall, elapsed_cpu = time.perf_counter_ns() - wall, time.process_time_ns() - cpu
    artifacts[stage] = artifact
    costs[stage] = {'fraction_ops': c.ops - initial_ops, 'simulated_detector_readings': c.detectors - initial_detectors,
                    'wall_ns': elapsed_wall, 'cpu_ns': elapsed_cpu,
                    'fraction_ops_by_phase': {key: value - initial_phases.get(key, 0) for key, value in c.phases.items()
                                             if value != initial_phases.get(key, 0)}}
    return context


def run_journey(spec, parent=None):
    context = {'spec': spec, 'artifacts': {}, 'costs': {}}
    if parent is not None:
        context['parent'] = parent
    for stage in STAGES:
        context = run_stage(stage, context)
    return context


def main():
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest='command', required=True)
    stage = sub.add_parser('stage')
    stage.add_argument('stage', choices=STAGES)
    stage.add_argument('--context', required=True)
    stage.add_argument('--output', required=True)
    demo = sub.add_parser('demo')
    demo.add_argument('--output', required=True)
    args = parser.parse_args()
    if args.command == 'stage':
        result = run_stage(args.stage, json.loads(Path(args.context).read_text()))
    else:
        ancestor = run_journey({'signals': 1, 'drift_degree': 2, 'seed': 20261024, 'acquisition_cap': 12})
        successor = run_journey({'signals': 2, 'drift_degree': 2, 'seed': 20261025, 'acquisition_cap': 12}, ancestor['artifacts']['out_evolve'])
        result = {'ancestor': ancestor, 'successor': successor}
    Path(args.output).write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'output': str(Path(args.output).resolve()), 'source': source_identity()}))


if __name__ == '__main__':
    main()
