import argparse
import copy
import csv
import hashlib
import json
import platform
import time
from fractions import Fraction as F
from pathlib import Path
import instrument as m


ROOT = Path(__file__).resolve().parent


def write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')


def clean_timing(value):
    if isinstance(value, dict):
        return {k: clean_timing(v) for k, v in value.items() if not k.endswith('_ns') and k not in ('environment', 'scientific_digest')}
    if isinstance(value, list):
        return [clean_timing(v) for v in value]
    return value


def mission_specs(protocol, seed):
    cases = []
    for i in range(protocol['primary_study']['missions_per_campaign']):
        k, d = (1, 2) if i == 0 or (i - 1) % 4 == 3 else ((2, 3) if (i - 1) % 4 == 2 else (2, 2))
        cases.append({'signals': k, 'drift_degree': d, 'seed': seed * 1000 + i,
                      'acquisition_cap': protocol['acceptance']['per_mission_detector_reading_cap'],
                      'case_id': f'{seed}-{i:02d}'})
    return cases


def campaign(protocol, seed, method, outdir):
    budget = protocol['primary_study']['budget']
    c = m.Counter(budget['counted_fraction_arithmetic_operations'], budget['detector_readings'])
    cache, records, completed, accepted, hits, constructed = {}, [], 0, 0, 0, 0
    start_wall, start_cpu = time.perf_counter_ns(), time.process_time_ns()
    for index, spec in enumerate(mission_specs(protocol, seed)):
        key = (spec['signals'], spec['drift_degree'])
        cache_hit = method['cache'] and key in cache
        context = {'spec': spec, 'policy': {'constructor': method['constructor']}, 'artifacts': {}, 'costs': {}}
        if cache_hit:
            context['cached_capability'] = cache[key]
        before_ops, before_detectors = c.ops, c.detectors
        before_phases = dict(c.phases)
        tw, tc = time.perf_counter_ns(), time.process_time_ns()
        error = None
        stage = 'not_started'
        try:
            for stage in m.STAGES:
                context = m.run_stage(stage, context, c)
        except (m.BudgetExhausted, m.Infeasible) as e:
            error = {'type': type(e).__name__, 'reason': str(e), 'stage': stage}
        wall_ns, cpu_ns = time.perf_counter_ns() - tw, time.process_time_ns() - tc
        outcome = context['artifacts'].get('out_execute', {})
        qualified = bool(outcome.get('oracle_qualified'))
        validator_accepted = bool(outcome.get('accepted'))
        completed += qualified
        accepted += validator_accepted
        hits += cache_hit
        cap = context['artifacts'].get('out_design')
        if cap is not None and not cache_hit:
            constructed += 1
        if cap is not None:
            write_json(outdir / 'capabilities' / (cap['capability_sha256'] + '.json'), cap)
        if method['cache'] and validator_accepted and cap is not None:
            cache[key] = cap
        phase_delta = {p: value - before_phases.get(p, 0) for p, value in c.phases.items() if value != before_phases.get(p, 0)}
        record = {'campaign_seed': seed, 'method': method['id'], 'mission_index': index, 'spec': spec,
                  'cache_hit': cache_hit, 'qualified': qualified, 'validator_accepted': validator_accepted,
                  'error': error, 'fraction_ops': c.ops - before_ops,
                  'fraction_ops_by_phase': phase_delta, 'simulated_detector_readings': c.detectors - before_detectors,
                  'cumulative_fraction_ops': c.ops, 'cumulative_detector_readings': c.detectors,
                  'wall_ns': wall_ns, 'cpu_ns': cpu_ns,
                  'stage_costs': context.get('costs'), 'outcome': outcome,
                  'capability_sha256': cap.get('capability_sha256') if cap else None,
                  'candidate_count': cap['construction']['candidates_tried'] if cap and not cache_hit else 0}
        records.append(record)
        if error and error['type'] == 'BudgetExhausted':
            break
    total_wall, total_cpu = time.perf_counter_ns() - start_wall, time.process_time_ns() - start_cpu
    summary = {'campaign_seed': seed, 'method': method['id'], 'attempted': len(records),
               'qualified': completed, 'validator_accepted': accepted, 'fraction_ops': c.ops,
               'fraction_ops_by_phase': c.phases, 'simulated_detector_readings': c.detectors,
               'cache_hits': hits, 'constructed_capabilities': constructed,
               'wall_ns': total_wall, 'cpu_ns': total_cpu,
               'budget_stop': records[-1]['error'] if records and records[-1]['error'] else None,
               'max_actual_error': max([float(F(v)) for r in records for v in r['outcome'].get('oracle', {}).get('actual_errors', [])] or [0]),
               'max_interval_radius': max([float(F(v)) for r in records for v in r['outcome'].get('interval_radii', [])] or [0]),
               'runtime_human_prompts': 0, 'human_authoring_and_review_minutes': None}
    return records, summary


def controlled_world(k=2):
    return {'signals': [F(1, 5), F(-3, 10)][:k], 'gain': F(1),
            'reference_drift': [F(7), F(-3), F(2)], 'sample_drift': [F(-11), F(4), F(-1)],
            'reference_noise': [F(0)] * (6 if k == 2 else 4), 'sample_noise': [F(0)] * (6 if k == 2 else 4)}


def failures_and_ablations():
    c = m.Counter()
    scalar = m.construct_capability({'signals': 1, 'drift_degree': 2}, counter=c)
    dual = m.construct_capability({'signals': 2, 'drift_degree': 2}, counter=c)
    initial_construction = {'fraction_ops': c.ops, 'detector_readings': c.detectors, 'phases': dict(c.phases)}
    negative = []

    def event(name, fn, detects, note):
        counter = m.Counter()
        wall, cpu = time.perf_counter_ns(), time.process_time_ns()
        try:
            result = fn(counter)
        except (m.Infeasible, m.BudgetExhausted) as e:
            result = {'rejected': True, 'reason': str(e), 'type': type(e).__name__}
        negative.append({'control': name, 'scripted': True, 'expected_detectability': detects,
                         'result': result, 'note': note, 'fraction_ops': counter.ops,
                         'simulated_detector_readings': counter.detectors,
                         'wall_ns': time.perf_counter_ns() - wall, 'cpu_ns': time.process_time_ns() - cpu})

    def unmodulated(counter):
        counter.phase = 'negative_control'
        v = m.nuisance_basis([F(i) for i in range(6)], 2, counter)
        r = [[F(1), F(1)]] * 6
        return {'nuisance_rank': m.rank(v, counter), 'combined_rank': m.rank([a + b for a, b in zip(v, r)], counter),
                'required_combined_rank': 5, 'rejected': True, 'reason': 'signal_confounded_with_background'}

    event('unmodulated_rank', unmodulated, 'detected', 'No estimator can recover two unknown constant amplitudes separately from an arbitrary ambient offset.')
    event('collinear_controls', lambda q: m.estimator(m.nuisance_basis([F(i) for i in range(6)], 2, q),
          [[F(1 if i % 2 == 0 else -1)] * 2 for i in range(6)], q), 'detected', 'Independent signal columns are necessary.')
    event('degree_four_infeasible', lambda q: m.construct_capability({'signals': 2, 'drift_degree': 4}, counter=q),
          'detected', 'Seven unknown polynomial-and-signal coefficients cannot be identified from six readings.')
    event('scalar_as_dual', lambda q: m.validate_capability(scalar, {'signals': 2, 'drift_degree': 2}, q),
          'detected', 'Parent history is useful but scalar proof is not a two-channel proof.')
    event('degree_change_without_requalification', lambda q: m.validate_capability(dual, {'signals': 2, 'drift_degree': 3}, q),
          'detected', 'Higher nuisance order is a new WORLD obligation.')
    bad = copy.deepcopy(dual)
    bad['weights'][0][0] = str(F(bad['weights'][0][0]) + F(1, 10))
    bad['capability_sha256'] = m.digest({k: v for k, v in bad.items() if k != 'capability_sha256'})
    event('corrupted_weights_rehashed', lambda q: m.validate_capability(bad, {'signals': 2, 'drift_degree': 2}, q),
          'detected', 'Recomputing a content hash does not repair a false scientific certificate.')
    gain_world = controlled_world()
    gain_world['gain'] = F(4, 5)
    gain_world['signals'] = [F(2, 5), F(-1, 5)]
    event('gain_changes_after_reference', lambda q: m.execute_mission(dual, {'signals': 2, 'drift_degree': 2}, q,
          world=gain_world, sample_gain=F(6, 5)), 'not_detectable_in_general',
          'Reference gain is 0.8 and sample gain 1.2. Common-gain scope is false, yet all algebra and interval checks can pass.')
    r = m.decode_matrix(dual['controls'])
    interference = [F(1, 10) * row[0] for row in r]
    event('signal_shaped_interference', lambda q: m.execute_mission(dual, {'signals': 2, 'drift_degree': 2}, q,
          world=controlled_world(), sample_interference=interference), 'not_detectable_from_these_observations',
          'Interference in the first signal column is observationally identical to a changed first amplitude; a new sensor or WORLD assumption is needed.')
    event('cap_eleven', lambda q: m.execute_mission(dual, {'signals': 2, 'drift_degree': 2, 'acquisition_cap': 11}, q),
          'detected', 'Admission stops before any detector reading; the rejected plan does not mutate accepted evidence.')

    w = controlled_world()
    ts, rr = [F(v) for v in dual['times']], m.decode_matrix(dual['controls'])
    observations = m.observe(ts, rr, w['signals'], F(1), w['sample_drift'], [F(0)] * 6)
    q = m.Counter()
    q.phase = 'ablation_no_nuisance'
    rt = m.transpose(rr)
    nominal_w = m.matmul(m.inverse(m.matmul(rt, rr, q), q), rt, q)
    nominal_z = [row[0] for row in m.matmul(nominal_w, [[a] for a in observations], q)]
    leakage = [abs(a - b) for a, b in zip(nominal_z, w['signals'])]
    separate = m.Counter(detector_cap=12)
    first = m.execute_mission(scalar, {'signals': 1, 'drift_degree': 2, 'seed': 41}, separate)
    try:
        second = m.execute_mission(scalar, {'signals': 1, 'drift_degree': 2, 'seed': 42}, separate)
    except m.BudgetExhausted as e:
        second = {'accepted': False, 'reason': str(e)}
    ablations = [
        {'stage': 'Identify', 'omission': 'No check for offset-confounded unmodulated channels', 'artifact': negative[0]['result'],
         'contribution': 'Makes the initial impossibility explicit rather than returning a spurious amplitude.'},
        {'stage': 'Out-Learn', 'omission': 'No polynomial nuisance representation',
         'artifact': {'nominal_weights': m.encode_matrix(nominal_w), 'estimates': [str(a) for a in nominal_z],
                      'truth': [str(a) for a in w['signals']], 'absolute_errors': [str(a) for a in leakage],
                      'fraction_ops': q.ops, 'exceeds_tolerance': any(a > m.TOL for a in leakage)},
         'contribution': 'A response-only fit leaks background drift; the full checker would reject its certificate.'},
        {'stage': 'Out-Think', 'omission': 'No independent-column obligation', 'artifact': negative[1]['result'],
         'contribution': 'The inverse does not exist for collinear responses; the solver fails closed.'},
        {'stage': 'Out-Design', 'omission': 'Relabel the scalar artifact as the dual instrument', 'artifact': negative[3]['result'],
         'contribution': 'A new rank-two decoder must actually be constructed.'},
        {'stage': 'Out-Strategise', 'omission': 'Run two scalar programs under the successor total cap',
         'artifact': {'required_reads': 16, 'cap': 12, 'reads_spent': separate.detectors,
                      'first_channel_accepted': first['accepted'], 'second_channel': second},
         'contribution': 'Joint coding qualifies both channels with 12 readings; sequential scalar procedures cannot finish under that cap.'},
        {'stage': 'Out-Execute', 'omission': 'Treat an old gain reference as valid for changed gain', 'artifact': negative[6]['result'],
         'contribution': 'Fresh references are required across missions, and within-mission gain stability remains an explicit physical assumption.'},
        {'stage': 'Out-Evolve', 'omission': 'Discard all accepted reusable capabilities',
         'artifact': {'comparison': 'rebuild_search versus harness_reuse in primary results'},
         'contribution': 'Reuse can save constructor operations; a conventional cached workflow is allowed the same saving.'}
    ]
    recovery_counter = m.Counter()
    incumbent_hash = dual['capability_sha256']
    rejection = m.validate_capability(bad, {'signals': 2, 'drift_degree': 2}, recovery_counter)
    incumbent_result = m.execute_mission(dual, {'signals': 2, 'drift_degree': 2, 'seed': 991}, recovery_counter)
    successor = m.construct_capability({'signals': 2, 'drift_degree': 3}, counter=recovery_counter)
    successor_result = m.execute_mission(successor, {'signals': 2, 'drift_degree': 3, 'seed': 992}, recovery_counter)
    recovery = {'scripted_control': True, 'prior_accepted_capability_sha256': incumbent_hash,
                'rejected_candidate_validation': rejection, 'incumbent_preserved': dual['capability_sha256'] == incumbent_hash,
                'incumbent_fresh_mission': incumbent_result, 'new_cubic_successor': successor,
                'new_cubic_successor_mission': successor_result,
                'fraction_ops': recovery_counter.ops, 'fraction_ops_by_phase': recovery_counter.phases,
                'simulated_detector_readings': recovery_counter.detectors,
                'history_rewritten': False, 'authority_restored_from_ancestor': False}
    return {'shared_control_construction_cost': initial_construction, 'controls': negative}, ablations, recovery


def aggregate(summaries, records, protocol):
    combined = []
    for method in protocol['primary_study']['methods']:
        rows = [r for r in summaries if r['method'] == method['id']]
        total = {'method': method['id']}
        for field in ('attempted', 'qualified', 'validator_accepted', 'fraction_ops', 'simulated_detector_readings',
                      'cache_hits', 'constructed_capabilities', 'wall_ns', 'cpu_ns', 'runtime_human_prompts'):
            total[field] = sum(row[field] for row in rows)
        total['fraction_ops_by_phase'] = {key: sum(r['fraction_ops_by_phase'].get(key, 0) for r in rows)
                                          for key in sorted({key for r in rows for key in r['fraction_ops_by_phase']})}
        total['max_actual_error'] = max(row['max_actual_error'] for row in rows)
        total['max_interval_radius'] = max(row['max_interval_radius'] for row in rows)
        total['budget_stops'] = sum(row['budget_stop'] is not None for row in rows)
        combined.append(total)
    paired = []
    for seed in protocol['primary_study']['campaign_seeds']:
        a = [r for r in records if r['campaign_seed'] == seed and r['method'] == 'harness_reuse']
        b = [r for r in records if r['campaign_seed'] == seed and r['method'] == 'conventional_reuse']
        fields = ('qualified', 'validator_accepted', 'fraction_ops', 'simulated_detector_readings', 'outcome', 'capability_sha256')
        equality = len(a) == len(b) and all(all(x[f] == y[f] for f in fields) for x, y in zip(a, b))
        paired.append({'seed': seed, 'scientific_and_counted_cost_equality': equality})
    return {'methods': combined, 'paired_harness_conventional': paired,
            'all_harness_conventional_scientific_results_equal': all(r['scientific_and_counted_cost_equality'] for r in paired)}


def run(outdir):
    outdir.mkdir(parents=True, exist_ok=True)
    protocol = json.loads((ROOT / 'protocol.json').read_text())
    current_protocol_hash = hashlib.sha256((ROOT / 'protocol.json').read_bytes()).hexdigest()
    frozen_hash = (ROOT / 'protocol.sha256').read_text().split()[0]
    if current_protocol_hash != frozen_hash:
        raise RuntimeError('Frozen protocol hash mismatch; stop instead of silently changing the study.')
    source = m.source_identity()
    write_json(outdir / 'execution_manifest.json', {'protocol_sha256': frozen_hash, 'instrument_source': source,
              'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'environment': {'python': platform.python_version(), 'platform': platform.platform(), 'processor': platform.processor()},
              'main_experiment_started': True, 'new_paid_services': False, 'financial_transactions': False})
    records, summaries = [], []
    all_cases = [case for seed in protocol['primary_study']['campaign_seeds'] for case in mission_specs(protocol, seed)]
    write_json(outdir / 'heldout_missions.json', all_cases)
    for seed in protocol['primary_study']['campaign_seeds']:
        for method in protocol['primary_study']['methods']:
            row_records, summary = campaign(protocol, seed, method, outdir)
            records.extend(row_records)
            summaries.append(summary)
            print(json.dumps({key: summary[key] for key in ('campaign_seed', 'method', 'qualified', 'fraction_ops', 'simulated_detector_readings', 'budget_stop')}), flush=True)
    with (outdir / 'raw_results.jsonl').open('w') as stream:
        for row in records:
            stream.write(json.dumps(row, sort_keys=True, separators=(',', ':')) + '\n')
    with (outdir / 'mission_metrics.csv').open('w', newline='') as stream:
        fields = ('campaign_seed', 'method', 'mission_index', 'qualified', 'validator_accepted', 'cache_hit',
                  'fraction_ops', 'simulated_detector_readings', 'cumulative_fraction_ops', 'cumulative_detector_readings', 'wall_ns', 'cpu_ns')
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows({key: row[key] for key in fields} for row in records)
    write_json(outdir / 'campaigns.json', summaries)
    total = aggregate(summaries, records, protocol)
    total['protocol_sha256'] = frozen_hash
    total['source'] = source
    total['scientific_digest'] = m.digest(clean_timing({'records': records, 'summary': total}))
    write_json(outdir / 'summary.json', total)
    negative, ablations, recovery = failures_and_ablations()
    write_json(outdir / 'failure_map.json', negative)
    write_json(outdir / 'stage_ablations.json', ablations)
    write_json(outdir / 'recovery.json', recovery)
    ancestor = m.run_journey({'signals': 1, 'drift_degree': 2, 'seed': 20261024, 'acquisition_cap': 12})
    successor = m.run_journey({'signals': 2, 'drift_degree': 2, 'seed': 20261025, 'acquisition_cap': 12}, ancestor['artifacts']['out_evolve'])
    write_json(outdir / 'demo_ancestor.json', ancestor)
    write_json(outdir / 'demo_successor.json', successor)
    write_json(outdir / 'interventions.json', {
        'main_run_operator_prompts': 0, 'main_run_manual_overrides': 0,
        'scripted_negative_controls': len(negative['controls']), 'scripted_instrument_recovery_sequences': 1,
        'all_controls_are_synthetic_local_emulator_faults': True,
        'measured_human_participant_minutes': None, 'authoring_integration_review_minutes': None,
        'labor_cost_unknown_not_zero': True, 'paid_calls_or_spending_requested': False,
        'environment_allocation_price': None,
        'pre_main_independent_review_corrections': ['Bind admitted times/control library and WORLD metadata in validator.',
                                                     'Compute complete bounded-noise calibrated risk, including large-noise branch.'],
        'heldout_threshold_budget_seed_changes': 0,
        'note': 'No participant productivity, real instrument throughput, commercial profit or zero total human burden is inferred.'})
    print(json.dumps({'output': str(outdir.resolve()), 'scientific_digest': total['scientific_digest'], 'summary': total['methods']}), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', default=str(ROOT / 'results'))
    args = parser.parse_args()
    run(Path(args.output))
