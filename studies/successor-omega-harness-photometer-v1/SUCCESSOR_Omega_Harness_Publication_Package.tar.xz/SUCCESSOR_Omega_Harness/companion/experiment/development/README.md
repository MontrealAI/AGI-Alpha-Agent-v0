# Retained development checkpoint

This pilot preceded independent-review corrections and the frozen main study. Its source hash differs from the final instrument. It is preserved as historical development evidence, not used for final scientific or runtime claims. Final records are in ../results and are bound by ../implementation_freeze.json.
