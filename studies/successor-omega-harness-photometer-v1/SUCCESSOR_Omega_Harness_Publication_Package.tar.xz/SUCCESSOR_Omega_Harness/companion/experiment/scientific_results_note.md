# Scientific results and interpretation for the paper

## What was newly constructed

The demonstration extends the actual Out-Learn scalar measurement model to two independently coded amplitudes. It uses established linear algebra, bounded-error demodulation and a finite exact-arithmetic design search. It does not claim to invent photometry, nuisance projection, workflow persistence or caching.

The emulator is

\[
y= g R s+V_d\beta+e,\qquad |s_j|\leq 1,\quad 4/5\leq g\leq6/5,\quad |e_i|\leq1/500.
\]

The reference has known amplitudes all equal to one. Gain is constant between that reference and the associated sample, while ambient polynomial coefficients can differ arbitrarily between blocks. A decoder exists exactly when `rank([V,R]) = rank(V)+k`; its certificate is `WV=0`, `WR=I_k`. For row `j`, demodulation noise is bounded by `eta ||W_j||_1`. A changed nuisance order, time grid, response family, noise bound or gain scope requires renewed qualification.

The ancestor retains the Out-Learn schedule: `t=(0,2,3,5)`, `R=(1,1,-1,-1)^T`, `W=(-1,5,-5,1)/8`. Its amplification is `3/2` and its worst-case calibrated absolute risk is `3/403` under this study's noise/gain constants.

The constructed quadratic-drift successor uses

\[
R=\begin{pmatrix}1&1\\-1&-1\\-1&1\\1&-1\\1&1\\-1&-1\end{pmatrix},\quad
W=\begin{pmatrix}1/8&-1/8&-1/4&1/4&1/8&-1/8\\1/16&-3/16&1/4&-1/4&3/16&-1/16\end{pmatrix}
\]

on `t=(0,1,2,3,4,5)`. Both rows have L1 norm one. This is globally minimal for each row among any admissible +/-1 response designs, because `1=|W_j R_j|<=||W_j||_1`. The finite library search found a decoder achieving that lower bound for both outputs simultaneously. Its rowwise worst-case calibrated risk is `1/201`, about 0.00497512. The scalar program's corresponding bound is about 0.00744417.

One reference plus one sample requires twelve detector readings for the joint successor. Two independent reference/sample scalar procedures require sixteen. Under the twelve-reading successor cap, the joint capability makes the two-output investigation feasible. A competent expert can construct it directly as well: this feasibility gain belongs to the constructed measurement program, not uniquely to the Harness or ancestry.

The cubic-drift successor is also constructed, with exact rows `(3,-5,-10,30,-25,7)/80` and `(7,-25,30,-10,-5,3)/80`, each L1 norm one. For this family the 45 examined control pairs include six singular and thirteen quality-rejected proposals. These failed candidates remain counted in construction cost and are retained in each capability's construction record. A degree-four two-output requirement at six readings is rejected because it entails seven unknown coefficients.

## What the parent actually contributes

The parent constructs and packages a source-bound nuisance recipe with exponents `[0,1,2]`, coordinate semantics and scope. The successor consumes the exact parent recipe hash `105ce549bac04ed97ecf33eb89b714f2801759115f7cf6813d30b2b1796f097a`, verifies its parent capability, and actually evaluates its terms at the new six-point grid. Its new sample basis, decoder, noise certificate, gain reference and mission result are rebuilt and requalified. The shared numerical solver was already supplied by the researchers.

The current scalar-to-dual inherited demonstration costs **47,157** counted operations, versus **47,108** for direct fresh construction of the same dual requirement. The 49-operation difference is parent artifact verification. This is an observed case in which inheritance adds work. It is not a first-transition efficiency win. The benefit of the recorded transition is inspectable representation/provenance continuity; repeated-profile decoder reuse is a separate cost question.

The whole two-mission guided demonstration costs 799+47,157=47,956 counted rational-kernel operations and 8+12=20 simulated detector readings. It includes all its ancestor work. These counts are not currency, detector exposure time or human labor.

## Frozen main study

Protocol SHA-256: `cb3a71483ade02deb1c835b8a5358dc728d87ed29d7df48812d97940e586f263`.

Instrument source SHA-256: `ea7d3a4cc01a3733c8983899f95ed8ae93a5ca79a8efc2ae7a8e56894dc78c2b`.

Four paired campaign seeds (73001–73004), 48 missions each, supplied 192 held-out numerical worlds. Every campaign contains twelve scalar quadratic missions, twenty-four joint quadratic missions and twelve joint cubic missions. Worlds vary amplitudes, gain, independent polynomial drift in each block and bounded additive errors. These are held-out numerical instances of explicitly declared families, not a claim of transfer to arbitrary unknown physical instruments.

| Method | Qualified | Kernel ops | Detector readings | Cache hits | Capability constructions | Maximum actual absolute error | Maximum interval radius |
|---|---:|---:|---:|---:|---:|---:|---:|
| Harness scientific reuse | 192/192 | 609,524 | 2,112 | 180 | 12 | 0.00328335 | 0.00598660 |
| Conventional scientific reuse | 192/192 | 609,524 | 2,112 | 180 | 12 | 0.00328335 | 0.00598660 |
| Expert-coded satisficing reuse | 192/192 | 169,732 | 2,112 | 180 | 12 | 0.00336635 | 0.00873794 |
| Exhaustive rebuild | 192/192 | 7,953,264 | 2,112 | 0 | 192 | 0.00328335 | 0.00598660 |

The primary quality threshold was 0.02. **Every method completed the full primary budgeted mission sequence.** Rebuild used 1,988,316 of the 2,000,000-operation budget in each campaign, so its coverage still tied. No budget was retuned to turn that tie into a Harness win. Detector spending is equal across the four methods. The expert-coded reference wins counted construction work, with somewhat less tight accepted certificates.

Harness and conventional outputs, exact costs and receipts match in all 192 paired cases. A reuse policy by itself is not a distinct scientific algorithm. The runtime benchmark must report actual orchestration overhead separately and should not claim to recover that overhead through a scientific advantage absent from these results.

### Cost decomposition (all four campaigns)

| Phase | Harness / conventional | Expert-coded | Rebuild |
|---|---:|---:|---:|
| Construction | 465,524 | 25,732 | 7,809,264 |
| Identification | 43,536 | 43,536 | 43,536 |
| Representation construction | 18,480 | 18,480 | 18,480 |
| Feasibility/rank reasoning | 16,080 | 16,080 | 16,080 |
| Requalification | 51,936 | 51,936 | 51,936 |
| Demodulation/interval execution | 13,968 | 13,968 | 13,968 |

Integer planning, hashing, serialization, candidate bookkeeping, emulator generation and hidden-truth checking are outside this rational-kernel counter. Measured process/wall time includes those activities; the load benchmark additionally includes durable runtime mechanics. No single operation count is represented as all computational or financial cost.

The primary script's descriptive aggregate process CPU times were 1.0604 s for Harness scientific policy, 1.0852 s for conventional scientific policy, 0.6799 s for expert-coded policy and 7.1872 s for rebuilding. These timings are single-host observations with identical scientific code, not evidence that the Harness is faster than conventional execution. Use the separately frozen runtime/load experiment for orchestration comparisons. Reproduction timings naturally vary.

## Conditional break-even, without unmeasured economics

For one repeated joint quadratic requirement, a full constructor-plus-fresh-mission path uses 47,108 counted operations; a cached, requalified continuation uses 796. Thus, after the first accepted construction,

\[
C_{\rm rebuild}(n)=47\,108n,\qquad C_{\rm reuse}(n)=47\,108+796(n-1),
\]

with twelve simulated detector readings per mission in either case. The counted difference is `46,312(n-1)`. The expert-coded constructor uses 1,864 for the first instance, then 796, so its analogous savings are only `1,068(n-1)`.

These formulas exclude unknown additional engineering, maintenance and review labor, real instrument procurement and runtime authority overhead. If someone chooses a common monetary valuation, the reuse inequality would additionally require its valued computational savings to exceed those extra costs. None of those prices or labor quantities were measured, so **no monetary break-even or realized profit is established**. For the competent cached conventional comparator, the scientific cost difference is zero; any additional Harness expense needs a separate justification such as evidence integrity or bounded recovery.

## Failures and recovery

Seven of nine scripted negative controls are rejected: unmodulated rank failure, collinear controls, degree-four infeasibility, scalar artifact relabeling, changed nuisance scope, a rehashed corrupt coefficient and an eleven-reading cap. Two controls pass internal checks but fail the hidden-truth criterion:

* A reference at gain 0.8 followed by a sample at gain 1.2 is outside the common-gain model. Internal validation accepts, while the two output errors are approximately 0.199255 and 0.0996291.
* Interference of `0.1 R[:,0]` is exactly signal-shaped. Internal validation accepts, while the first amplitude error is approximately 0.100005. This is an identifiability limit; content hashes, exact arithmetic and event logs cannot detect it from these observations alone.

Recovery retains a rejected, rehashed candidate's failure record, preserves the exact incumbent hash, performs a fresh incumbent mission, and separately constructs/qualifies a cubic successor. Its source/evidence history is not rewritten and no ancestral authority is restored. Runtime crash/uncertainty tests are distinct from this pure simulator sequence.

## Stage-linked probes and limits

The no-nuisance fit and no-cache comparison actually change computation. The separate-scalar budget comparison actually spends eight readings on one channel and is blocked from the second eight-reading acquisition under the total twelve-reading cap. Other stage-linked probes illustrate rank/scope obligations or model violations; they are not surgical demonstrations that each named callback is causally necessary. The gain-change control tests a violated physical assumption, not a new empirical study of stale calibration management.

There were no interactive prompts or manual overrides during the primary script. Nine negative controls and one recovery sequence were scripted. No participants were measured; total authoring, independent review, integration and deployment labor are unknown. The experiment does not establish autonomous discovery, hardware validity, higher commercial profit, universal exactly-once effects, Fleet qualification or live settlement.
