'use strict';
const stages = [
  ['identify', 'Identify', 'State the target, the declared world and the resource limit. Test the incumbent against the new question.'],
  ['out_learn', 'Out-Learn', 'Construct or verify the nuisance representation that makes the background removable.'],
  ['out_think', 'Out-Think', 'Compute the nuisance rank, necessary observation dimension and decoder obligations. Design then checks each full candidate.'],
  ['out_design', 'Out-Design', 'Construct an exact measurement program and check its noise amplification.'],
  ['out_strategise', 'Out-Strategise', 'Calculate the acquisition requirement and admit or stop the bounded plan.'],
  ['out_execute', 'Out-Execute', 'Acquire fresh simulated reference and sample readings, estimate the signals and validate the result.'],
  ['out_evolve', 'Out-Evolve', 'Package the accepted artifact and its limits; propose a new requirement without copying proof or authority.']
];
const $ = id => document.getElementById(id);
let current = null, missionName = 'ancestor', stageName = 'identify', exportUrl = null, busy = false;
function esc(value) { return String(value).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch])); }
function num(v) { if (typeof v === 'number') return v; if (v == null) return NaN; const a = String(v).split('/').map(Number); return a.length === 2 ? a[0] / a[1] : a[0]; }
function small(v, n = 4) { return Number.isFinite(num(v)) ? num(v).toFixed(n) : '—'; }
function upper(v, n = 4) { return Number.isFinite(num(v)) ? (Math.ceil(num(v) * 10 ** n) / 10 ** n).toFixed(n) : '—'; }
function displayedRadius(value, radius, n = 4) { return upper(num(radius)+Math.abs(num(value)-Number(small(value,n))),n); }
function integer(v) { return v != null && Number.isFinite(Number(v)) ? Number(v).toLocaleString('en-US') : '—'; }
function renderStages() {
  const pipeline = current?.[missionName];
  $('stages').innerHTML = stages.map(([id,label],i) => {
    const record=pipeline?.stages.find(s=>s.stage===id), rejected=record?.status==='rejected', done=!!record&&!rejected;
    return `<button class="stage ${rejected?'rejected':done?'done':''} ${stageName===id?'active':''}" data-stage="${id}" aria-pressed="${stageName===id}" aria-label="${label}: ${rejected?'rejected':done?'completed':'not completed'}"><span class="stage-dot">${rejected?'×':done?'✓':String(i+1).padStart(2,'0')}</span><span>${label}</span></button>`;
  }).join('');
  document.querySelectorAll('[data-stage]').forEach(b=>b.addEventListener('click',()=>{stageName=b.dataset.stage;renderStages();renderDetail();}));
}
function renderDetail() {
  if (!current) return;
  const p=current[missionName], record=p.stages.find(s=>s.stage===stageName), item=stages.find(s=>s[0]===stageName);
  if (!record) {
    $('stage-detail').innerHTML=`<h4>${esc(item[1])} · not completed</h4><p>${esc(p.failure ? `The mission stopped at ${p.failure.stage}: ${p.failure.message}. No later stage is marked complete.` : 'No completed stage record.')}</p>`;
    return;
  }
  const c=record.costs;
  const rejected=record.status==='rejected';
  const failureReason=record.failure?.message==='more_unknowns_than_readings'?'Six readings cannot identify the requested background and both signal channels.':'The candidate did not meet the current mission requirements.';
  const explanation=rejected?`${failureReason} The candidate was rejected; later stages were not executed. Its computation cost is unavailable.`:item[2];
  $('stage-detail').innerHTML=`<h4>${esc(item[1])} · ${rejected?'rejected':'completed computation'}</h4><p>${esc(explanation)}</p><div class="detail-chips"><span>${c.fraction_ops==null?'Unknown rational-operation count':integer(c.fraction_ops)+' rational operations'}</span><span>${c.simulated_detector_readings==null?'Unknown acquisition count':integer(c.simulated_detector_readings)+' simulated acquisitions'}</span><span>${small(record.elapsed_ns_including_dispatch/1e6,2)} ms including dispatch</span><span>${esc(record.family)} lifecycle</span></div><details><summary>Inspect ${rejected?'rejection record':'artifact and source-bound receipt'}</summary><pre id="stage-json"></pre></details>`;
  $('stage-json').textContent=JSON.stringify(record,null,2);
}
function drawPlot(cap, output) {
  if (!output?.raw_sample) {
    $('plot').innerHTML='<div class="plot-empty"><span class="empty-glyph">⊘</span><h3>The right result is to stop.</h3><p>The declared nuisance and two signal channels exceed the six-reading rank. The ancestor remains available.</p></div>';
    $('signal-cards').innerHTML='';return;
  }
  const times=cap.times.map(num), sample=output.raw_sample.map(num), reference=output.raw_reference.map(num), values=[...sample,...reference];
  let lo=Math.min(...values),hi=Math.max(...values),pad=(hi-lo||1)*.16;lo-=pad;hi+=pad;
  const width=Math.max(240,Math.round($('plot').clientWidth)),height=235,left=42,right=14,top=25,bottom=35;
  const x=t=>left+(t-Math.min(...times))/(Math.max(...times)-Math.min(...times)||1)*(width-left-right);
  const y=v=>height-bottom-(v-lo)/(hi-lo)*(height-top-bottom);
  const line=a=>a.map((v,i)=>`${i?'L':'M'}${x(times[i]).toFixed(2)},${y(v).toFixed(2)}`).join(' ');
  let svg=`<svg viewBox="0 0 ${width} ${height}" role="img" aria-label="Actual simulated reference and sample readings before nuisance cancellation">`;
  for(let i=0;i<4;i++){const v=lo+(hi-lo)*i/3;svg+=`<line x1="${left}" x2="${width-right}" y1="${y(v)}" y2="${y(v)}" stroke="#eee7f4"/><text x="${left-8}" y="${y(v)+3}" text-anchor="end" fill="#81728f" font-size="10">${v.toFixed(1)}</text>`;}
  svg+=`<path d="${line(reference)}" fill="none" stroke="#b8b0c5" stroke-width="1.7" stroke-dasharray="4 4"/><path d="${line(sample)}" fill="none" stroke="#8050b8" stroke-width="2.5"/>`;
  sample.forEach((v,i)=>{svg+=`<circle cx="${x(times[i])}" cy="${y(v)}" r="4" fill="#8050b8" stroke="#fff" stroke-width="2"/><text x="${x(times[i])}" y="${height-13}" text-anchor="middle" fill="#81728f" font-size="10">t=${times[i]}</text>`;});
  svg+=`<circle cx="${left}" cy="10" r="3" fill="#8050b8"/><text x="${left+9}" y="13" fill="#7c6b8c" font-size="10">Sample</text><line x1="${left+72}" x2="${left+85}" y1="10" y2="10" stroke="#b8b0c5" stroke-width="2" stroke-dasharray="3 2"/><text x="${left+91}" y="13" fill="#7c6b8c" font-size="10">Reference</text>${width>=450?`<text x="${width-right}" y="13" text-anchor="end" fill="#a091ad" font-size="8">RAW ACQUIRED READINGS</text>`:''}</svg>`;
  $('plot').innerHTML=svg;
  $('signal-cards').innerHTML=output.signal_estimates.map((v,j)=>`<div class="signal-card">RECOVERED SIGNAL ${j?'B':'A'}<strong>${small(v)} <small>± ${displayedRadius(v,output.interval_radii[j])}</small></strong>True simulated value ${small(output.oracle?.signals[j])} · error ${small(output.oracle?.actual_errors[j],6)}</div>`).join('');
}
function renderMission() {
  if(!current){renderStages();return;}
  const p=current[missionName],art=p.context.artifacts,cap=art.out_design,output=art.out_execute,plan=art.out_strategise;
  document.querySelectorAll('[data-mission]').forEach(b=>b.classList.toggle('active',b.dataset.mission===missionName));
  $('cap-title').textContent=missionName==='ancestor'?'One signal, calibrated.':p.failure?'A limit, correctly exposed.':'Two signals, freshly qualified.';
  const metrics=[[(cap?.signals ?? p.manifest.configuration.signals),'target signals'],[output?.detector_readings ?? (p.failure?.stage==='out_design'?0:'—'),'simulated acquisitions'],[cap?'≤ '+upper(Math.max(...cap.worst_case_calibrated_error.map(num))):'—','absolute error bound'],[integer(current.events.count),'journal events in this run']];
  $('metrics').innerHTML=metrics.map(([v,l])=>`<div><strong>${esc(v)}</strong><span>${l}</span></div>`).join('');
  $('weights').textContent=cap?cap.weights.map((row,i)=>`W${i+1} = [ ${row.join('  ')} ]`).join('\n'):'No admissible decoder. No measurement executed.';
  $('admission').classList.toggle('bad',!!p.failure);
  $('admission').textContent=p.failure?'STOPPED · No successor grant. The accepted ancestor remains intact.':`QUALIFIED IN THE DECLARED MODEL · ${output?.detector_readings} readings. Local research permission only.`;
  $('plot-caption').textContent=output?`The varying background is removed by exact weights. Both reference and sample were acquired afresh; ${output.oracle_qualified?'the simulator truth lies inside the accepted interval.':'the result did not qualify against simulator truth.'}`:'The rank requirement failed before detector acquisition. This is a useful refusal.';
  drawPlot(cap,output);renderStages();renderDetail();
  const replay=current.successor.historical_parent_proof_reuse;
  $('lineage-result').textContent=replay?.blocked?(current.successor.failure?'Observed: replay of the ancestor’s proof into the successor was refused. A fresh failed qualification records the refusal; the accepted ancestor remains available.':'Observed: replay of the ancestor’s proof into the successor was refused. The child received a separate qualification record.'):'Inspect the exported lineage and qualification records.';
  const recovery=current.ancestor.recovery;
  $('recovery-result').textContent=recovery?.length?`Observed: ${recovery.length} uncertain attempt retained; duplicate invocation refused; one scripted recovery decision authorized a fresh attempt. The lost reservation remains charged. No external effect was involved.`:'“Interrupt & recover” preserves the interrupted attempt and refuses automatic replay. It cannot establish exactly-once behavior across an external service.';
}
async function run(scenario) {
  if(busy)return;busy=true;
  document.querySelectorAll('.run').forEach(b=>{b.disabled=true;b.classList.toggle('selected',b.dataset.scenario===scenario);});
  $('run-status').className='badge running';$('run-status').textContent='Running real local computation';
  $('run-message').innerHTML='<span class="running-indicator">Constructing the instrument, recording each stage, and qualifying the successor…</span>';
  try {
    const response=await fetch('/api/run',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({scenario})});
    const body=await response.json();if(!response.ok)throw new Error(body.error||'The run did not complete.');
    current=body.result;exportUrl=body.download_url;missionName='successor';stageName=current.successor.failure?'out_think':'out_execute';
    const stopped=!!current.successor.failure;
    $('run-status').className='badge '+(stopped?'stopped':'success');
    $('run-status').textContent=stopped?'Limit found · ancestor retained':'Mission & successor qualified';
    $('run-message').textContent=`Executed in ${small(current.elapsed_ns/1e9,2)} s · ${integer(current.events.count)} durable events · journal verified. ${scenario==='crash'?'Uncertain first attempt and recovery are both retained.':stopped?'The successor was refused before acquisition.':'Fresh reference, fresh proof and separately granted local authority.'}`;
    $('download').disabled=false;renderMission();
    document.querySelector('.workspace').scrollIntoView({behavior:'smooth',block:'start'});
  } catch(error) {
    $('run-status').className='badge stopped';$('run-status').textContent='Run not completed';
    $('run-message').textContent=`${error.message} Start the local companion with “python companion/serve.py” and open the printed address. No successful execution is claimed.`;
  } finally {busy=false;document.querySelectorAll('.run').forEach(b=>b.disabled=false);}
}
document.querySelectorAll('.run').forEach(b=>b.addEventListener('click',()=>run(b.dataset.scenario)));
document.querySelectorAll('[data-mission]').forEach(b=>b.addEventListener('click',()=>{missionName=b.dataset.mission;renderMission();}));
let resizeTimer;
window.addEventListener('resize',()=>{clearTimeout(resizeTimer);resizeTimer=setTimeout(()=>{if(current)renderMission();},80);});
$('download').addEventListener('click',()=>{if(exportUrl)window.location.assign(exportUrl);});
renderStages();
fetch('/api/status').then(r=>{if(!r.ok)throw new Error('not ready');return r.json();}).then(()=>{$('connection').classList.add('ready');$('connection').innerHTML='<i></i>Local companion ready';}).catch(()=>{$('connection').innerHTML='<i></i>Launch local companion';});
fetch('study.json').then(r=>{if(!r.ok)throw new Error('missing');return r.json();}).then(data=>{
  $('study-table').innerHTML='<table><thead><tr><th>METHOD</th><th>QUALIFIED MISSIONS</th><th>COUNTED RATIONAL OPERATIONS</th><th>SIMULATED READINGS</th></tr></thead><tbody>'+data.methods.map(row=>`<tr><td>${esc(row.label)}</td><td>${integer(row.qualified)} / ${integer(row.offered)}</td><td>${integer(row.operations)}</td><td>${integer(row.readings)}</td></tr>`).join('')+'</tbody></table><p class="caption">'+esc(data.note)+'</p>';
}).catch(()=>{});
