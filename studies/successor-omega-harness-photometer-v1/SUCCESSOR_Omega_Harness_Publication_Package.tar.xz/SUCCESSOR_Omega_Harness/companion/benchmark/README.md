# Local durable workflow load study

This is the source and evidence companion for a **nominal sequential workflow
ablation**. It measures the actual pinned Alpha `JobDispatcher` against a small
direct callback loop using the same released journal, signature verification,
scientific callbacks, compatible durable cache and fresh scientific validation.
The direct loop deliberately omits the full successor lifecycle. It is not a
replacement engine, a deployed service, or a benchmark of equivalent production
security guarantees.

## Reproduce

Place this directory beside `experiment/` and `integration/`, as in the publication
package. Use the package's pinned Python setup. Run the following commands from the `companion/` directory:

```sh
python benchmark/run_benchmark.py \
  --output benchmark/reproduction \
  --expected-instrument-sha ea7d3a4cc01a3733c8983899f95ed8ae93a5ca79a8efc2ae7a8e56894dc78c2b
python benchmark/check_replay_guards.py \
  --results benchmark/reproduction \
  --output benchmark/reproduction_replay_checks.json
```

The destination must not already exist. The runner checks the frozen protocol,
instrument source, integration adapter, vendored runtime manifest and its own
source. A source change during the measured run causes a stop. No credential,
wallet, service token or financial transaction is created. The known RFC 8032
fixture seeds are public test data and provide no production authenticity.

## What is measured

`protocol.json` and `freeze_record.json` were written before timings. The immutable
protocol SHA-256 is
`caa3ebf06be4f33c2ed02b5326381f711c7635692bd1f0e932d5818b59607689`.

The study uses batches of 1, 8 and 32 missions, three repeats, one sequential worker
and alternating method order. Every mission is available at the batch start.
Queue-inclusive latency therefore includes waiting behind earlier missions. Service
latency is also reported; its definition includes mission setup and artifact writes.
The primary throughput denominator includes fixture initialization, scientific work,
compatible cache loading/writing, fsynced stage/final JSON artifacts, full journal
verification, event export and checkpoint retention. Python imports and the final
self-referential summary write are excluded consistently.

Each batch starts with an empty cache. The first occurrences of scalar quadratic,
joint quadratic and joint cubic instruments pay full construction cost. Later
compatible artifacts are read from disk and requalified. The exact same callback
policy runs in both methods; fresh simulated reference and sample observations are
required in every mission. A paired digest strips only nested timing fields to
check deterministic scientific equality independently of orchestration.

`results/raw_results.json` preserves every batch and mission's metrics.
`results/summary.json` aggregates all three repeats and records paired scientific
equality. Every batch directory retains its SQLite journal, signed events, head
checkpoint, seven stage-context files per mission, final mission objects and cache
artifacts. `guard_checks.json` is a separate post-measurement two-case replay check;
it is not a crash/recovery or universal security test.

## Interpretation boundaries

Both implementations create the same source-bound institution/release description
and use the same bounded job/authorization/result types. The Alpha arm additionally
seals and executes the full released graph and successor state transitions. The
direct loop checks the nominal sequential dependencies, expiry, current source,
call cap and signed receipts; it persists an invocation claim before the callback
and refuses repeated entry under the same identity.

The direct loop does **not** implement graph-wide separation checks, admission,
descendant proof or authority handling, revocation propagation, cancellation,
recovery authorization or action dispatch. Its speed is therefore an overhead
comparison for this bounded nominal workload, not evidence that equivalent safety
can always be delivered more cheaply. Public fixture roles are controlled by one
script, not independent people. The nominal study has no injected failures and no
measured human participants. Authoring, review and maintenance labor are unknown.

Batch size varies queue/history length, not concurrency. All timings describe one
shared host. OS cache and unrelated contention are uncontrolled. No throughput is
extrapolated to physical detectors, a production Fleet, or a remote deployment.
Detector acquisitions, counted rational operations, host time and unknown labor
remain separate resources. Neither modeled nor measured time is commercial profit.
