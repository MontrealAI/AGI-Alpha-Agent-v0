"""Bounded nominal workflow ablation; never a production authority implementation."""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import math
import os
import platform
import statistics
import sys
import time
from datetime import UTC, datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
sys.path.insert(0, str(WORK / "integration"))
sys.path.insert(0, str(WORK / "experiment"))
import run_integration as ri
import instrument
from alpha_factory_v1.core.runtime.successor.state import current, utc_now
from alpha_factory_v1.core.runtime.successor.trust import SignedEnvelope


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def persist(path, value):
    """Identical fsynced JSON artifact persistence for both methods."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    raw = (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + "\n").encode()
    temporary = path.with_suffix(path.suffix + ".pending")
    with temporary.open("wb") as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)
    descriptor = os.open(path.parent, os.O_RDONLY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def timing_free(value):
    if isinstance(value, dict):
        return {key: timing_free(item) for key, item in value.items() if key not in {"wall_ns", "cpu_ns"}}
    if isinstance(value, list):
        return [timing_free(item) for item in value]
    return value


def percentile95(values):
    return sorted(values)[max(0, math.ceil(0.95 * len(values)) - 1)] if values else None


def source_snapshot():
    paths = {
        "instrument": Path(instrument.__file__),
        "scientific_protocol": WORK / "experiment" / "protocol.json",
        "integration_adapter": WORK / "integration" / "run_integration.py",
        "vendor_manifest": WORK / "integration" / "VENDOR_MANIFEST.json",
        "benchmark": Path(__file__),
        "load_protocol": HERE / "protocol.json",
    }
    return {key: {"path": str(path.relative_to(WORK)), "sha256": sha(path)} for key, path in paths.items()}


def ensure_sources(snapshot):
    for value in snapshot.values():
        if sha(WORK / value["path"]) != value["sha256"]:
            raise ValueError("source_changed_during_benchmark:" + value["path"])


def cache_key(spec):
    return instrument.digest({"signals": spec["signals"], "drift_degree": spec["drift_degree"], "source": instrument.source_identity()})


def request_spec(index):
    k, d = ((1, 2), (2, 2), (2, 3), (1, 2))[index % 4]
    return {"signals": k, "drift_degree": d, "seed": 94000 + index, "acquisition_cap": 12}


def direct_stage(journal, trust, keys, mission_key, terms, authorization, context, handler, previous_key):
    """Transparent sequential loop with scoped replay refusal and durable receipts.

    Deliberately no graph compiler, descendant authority, recovery or revocation
    propagation. The paper labels this a matched nominal-path ablation.
    """
    signed = ri.sign_record(keys["local-controller"], "local-controller", "execution", authorization)
    auth = ri.ExecutionAuthorization.model_validate(trust.verify(signed, "execution", "controller"))
    now = utc_now()
    if (auth.acting_identity != terms.worker or auth.acting_identity == terms.acceptance_owner
            or auth.job_terms_digest != ri.digest("job-terms", terms)
            or auth.release_digest != terms.release_digest or auth.environment_digest != terms.environment_digest
            or not current(auth.expires_at, now) or not current(terms.valid_until, now)
            or "instrument-stage" not in auth.capabilities or "instrument-stage" not in terms.allowed_tools):
        raise ValueError("direct_assignment_scope_mismatch")
    trust.anchor(terms.worker, "worker")
    invocation_key = mission_key + "/" + terms.job_id + "/" + auth.authorization_id
    input_hash = ri.digest("job-tool-output", context)
    request_hash = ri.digest("direct-request", {"authorization": auth.model_dump(mode="json"), "input": input_hash})
    with journal.transaction() as cx:
        state = journal.latest(mission_key, cx)
        if journal.latest("@control", cx)["state"] != "ready":
            raise ValueError("direct_agent_paused")
        if (state["release_digest"] != auth.release_digest or state["environment_digest"] != auth.environment_digest
                or state["source"] != instrument.source_identity() or context["spec"] != state["spec"]):
            raise ValueError("direct_current_source_or_mission_mismatch")
        try:
            prior_claim = journal.latest(invocation_key, cx)
        except KeyError:
            prior_claim = None
        if prior_claim is not None:
            if prior_claim["request_hash"] != request_hash:
                raise ValueError("direct_request_identity_rebound")
            raise ValueError("direct_invocation_already_claimed")
        if previous_key is not None:
            previous = journal.latest(previous_key, cx)
            prior_receipt = ri.JobResult.model_validate(trust.verify(SignedEnvelope.model_validate(previous["acceptance"]), "job-acceptance", "acceptance"))
            if (previous["state"] != "completed" or previous["output_digest"] != input_hash
                    or not prior_receipt.accepted or prior_receipt.revoked or not current(prior_receipt.valid_until, now)
                    or "dependency" not in prior_receipt.permitted_uses
                    or "instrument-context-v1" not in prior_receipt.outputs.values()):
                raise ValueError("direct_input_dependency_invalid")
        charge = terms.resources.get("calls", 0)
        if charge < 1 or state["calls_reserved"] + charge > state["call_budget"]:
            raise ValueError("direct_call_budget")
        journal.append(cx, mission_key, {**journal.document(state), "calls_reserved": state["calls_reserved"] + charge})
        journal.append(cx, invocation_key, {"state": "invoking", "request_hash": request_hash, "input_digest": input_hash,
                       "terms": terms.model_dump(mode="json"), "authorization": signed.model_dump(mode="json"),
                       "source": instrument.source_identity(), "scope": "nominal_direct_loop"})
    result = handler()
    result_hash = ri.digest("job-tool-output", result)
    verdict = "fail" if result.get("artifacts", {}).get("out_execute", {}).get("accepted") is False else "reported"
    report = ri.JobResult(job_id=terms.job_id, authorization_id=auth.authorization_id,
                          terms_digest=ri.digest("job-terms", terms), output_digest=result_hash,
                          outputs=terms.outputs, accepted=True, accepted_by=terms.acceptance_owner,
                          valid_until=ri.stamp(3600), permitted_uses=["dependency"], candidate_verdict=verdict,
                          actual_resources={"calls": 1})
    signed_report = ri.sign_record(keys[terms.acceptance_owner], terms.acceptance_owner, "job-acceptance", report)
    checked = ri.JobResult.model_validate(trust.verify(signed_report, "job-acceptance", "acceptance"))
    if (checked.accepted_by != terms.acceptance_owner or checked.authorization_id != auth.authorization_id
            or checked.terms_digest != ri.digest("job-terms", terms) or checked.output_digest != result_hash
            or not current(checked.valid_until, utc_now())):
        raise ValueError("direct_receipt_invalid")
    with journal.transaction() as cx:
        retained = journal.latest(invocation_key, cx)
        if retained["state"] != "invoking" or retained["request_hash"] != request_hash:
            raise ValueError("direct_completion_not_current")
        journal.append(cx, invocation_key, {**journal.document(retained), "state": "completed",
                       "output_digest": result_hash, "result_json": ri.canonical(result).decode(),
                       "acceptance": signed_report.model_dump(mode="json")})
    return result, invocation_key


def run_mission(method, journal, trust, keys, store, name, spec, output, cache_dir, snapshot, deadline):
    started, started_cpu = time.perf_counter_ns(), time.process_time_ns()
    manifest, release_digest = ri.institution(store, name, sha(instrument.__file__), spec)
    frozen = ri.graph(manifest, release_digest)
    dispatcher = ri.JobDispatcher(store, name) if method == "alpha_dispatcher" else None
    mission_key = "@nominal-direct/" + name
    if dispatcher:
        dispatcher.seal(frozen)
    else:
        with journal.transaction() as cx:
            journal.append(cx, mission_key, {"source": instrument.source_identity(), "spec": spec,
                           "release_digest": release_digest, "environment_digest": manifest.environment_digest,
                           "call_budget": 32, "calls_reserved": 0, "scope": "nominal_direct_loop"})
    context = {"spec": spec, "artifacts": {}, "costs": {}, "policy": {"constructor": "search"}}
    cached = cache_dir / (cache_key(spec) + ".json")
    cache_hit = cached.exists()
    if cache_hit:
        context["cached_capability"] = json.loads(cached.read_text())
    callback_wall, callback_cpu, previous_key = 0, 0, None
    records = []
    for terms in frozen.jobs:
        ensure_sources(snapshot)
        if time.perf_counter_ns() > deadline:
            raise TimeoutError("batch_deadline_between_stages")
        stage_start = time.perf_counter_ns()
        auth = ri.assignment(terms)
        previous = copy.deepcopy(context)

        def callback(stage=terms.job_id, incoming=previous):
            nonlocal callback_wall, callback_cpu
            wall, cpu = time.perf_counter_ns(), time.process_time_ns()
            try:
                return instrument.run_stage(stage, incoming)
            finally:
                callback_wall += time.perf_counter_ns() - wall
                callback_cpu += time.process_time_ns() - cpu

        if dispatcher:
            dispatcher.dispatch(terms.job_id, ri.sign_record(keys["local-controller"], "local-controller", "execution", auth))
            tool_id = terms.job_id + "-computation"
            context = dispatcher.execute_tool(terms.job_id, tool="instrument-stage", actor=terms.worker,
                        invocation_id=tool_id, handler=callback, retain_result=True)
            ri.accept_stage(dispatcher, keys, terms, auth, context, tool_id)
        else:
            context, previous_key = direct_stage(journal, trust, keys, mission_key, terms, auth, context, callback, previous_key)
        persist(output / name / (terms.job_id + ".json"), context)
        records.append({"stage": terms.job_id, "wall_ns": time.perf_counter_ns() - stage_start})
    result = context["artifacts"]["out_execute"]
    if not result.get("accepted") or not result.get("oracle_qualified"):
        raise ValueError("scientific_outcome_not_qualified")
    persist(cached, context["artifacts"]["out_design"])
    scientific_hash = instrument.digest(timing_free(context))
    payload = {"name": name, "spec": spec, "context": context, "scientific_hash": scientific_hash,
               "release_digest": release_digest, "cache_hit": cache_hit, "stage_timings": records}
    persist(output / name / "mission.json", payload)
    return {"name": name, "spec": spec, "scientific_hash": scientific_hash, "cache_hit": cache_hit,
            "service_ns": time.perf_counter_ns() - started, "cpu_ns": time.process_time_ns() - started_cpu,
            "callback_wall_ns": callback_wall, "callback_cpu_ns": callback_cpu,
            "fraction_ops": sum(v["fraction_ops"] for v in context["costs"].values()),
            "detector_readings": sum(v["simulated_detector_readings"] for v in context["costs"].values()),
            "accepted": True, "oracle_qualified": True, "scripted_acceptance_actions": len(records)}


def run_batch(method, size, repeat, output, snapshot):
    output.mkdir(parents=True, exist_ok=False)
    start, cpu = time.perf_counter_ns(), time.process_time_ns()
    deadline = start + 300_000_000_000
    journal, trust, keys = ri.fixture_journal(output / "journal")
    store = ri.SuccessorStore(journal, trust)
    cache_dir = output / "cache"
    cache_dir.mkdir()
    initialization_ns = time.perf_counter_ns() - start
    results, failures = [], []
    for index in range(size):
        try:
            row = run_mission(method, journal, trust, keys, store, "mission-" + str(index), request_spec(index),
                              output, cache_dir, snapshot, deadline)
            row["end_to_end_ns"] = time.perf_counter_ns() - start
            results.append(row)
        except Exception as exc:
            failure = {"mission_index": index, "class": type(exc).__name__, "message": str(exc),
                       "spent_wall_ns": time.perf_counter_ns() - start,
                       "failed_mission_scientific_counters": "Inspect last persisted stage context; work after an unobserved callback failure is unknown, never assigned zero.",
                       "reserved_calls": "Retained in signed Journal records, including invocation claim before callback."}
            failures.append(failure)
            persist(output / "failure.json", failure)
            break
    finalization = time.perf_counter_ns()
    checked = journal.verify()
    events = ri.export_events(journal)
    persist(output / "events.json", events)
    persist(output / "checkpoint.json", {"identity": checked["identity"], "sequence": checked["events"], "head": checked["head"],
                                          "scope": "local public-fixture retention, not independent custody"})
    output_bytes = sum(path.stat().st_size for path in output.rglob("*") if path.is_file())
    finalization_ns = time.perf_counter_ns() - finalization
    elapsed, elapsed_cpu = time.perf_counter_ns() - start, time.process_time_ns() - cpu
    queue = [r["end_to_end_ns"] for r in results]
    services = [r["service_ns"] for r in results]
    result = {"method": method, "batch_size": size, "repeat": repeat, "qualified_missions": len(results),
              "batch_wall_ns": elapsed, "batch_cpu_ns": elapsed_cpu, "initialization_ns": initialization_ns,
              "finalization_ns": finalization_ns, "throughput_missions_per_second": len(results) * 1e9 / elapsed,
              "end_to_end_median_ns": statistics.median(queue) if queue else None, "end_to_end_p95_ns": percentile95(queue),
              "service_median_ns": statistics.median(services) if services else None, "service_p95_ns": percentile95(services),
              "callback_wall_ns": sum(r["callback_wall_ns"] for r in results),
              "fraction_ops": sum(r["fraction_ops"] for r in results), "detector_readings": sum(r["detector_readings"] for r in results),
              "cache_hits": sum(r["cache_hit"] for r in results), "events": checked["events"], "journal_valid": checked["valid"],
              "output_bytes_before_summary": output_bytes, "failures": failures, "missions": results,
              "scripted_acceptance_actions": sum(r["scripted_acceptance_actions"] for r in results),
              "actual_operator_interventions": 0, "authoring_and_review_labor": "unknown, not included as zero",
              "timing_scope": "Imports excluded; initialization, science, all measured output writes and final journal verification/export included. Summary JSON write excluded to avoid self-referential timing."}
    persist(output / "summary.json", result)
    return result


def summarize(rows):
    groups = []
    for size in (1, 8, 32):
        for method in ("alpha_dispatcher", "direct_durable"):
            chosen = [r for r in rows if r["batch_size"] == size and r["method"] == method]
            metrics = ("throughput_missions_per_second", "batch_wall_ns", "end_to_end_median_ns", "end_to_end_p95_ns",
                       "service_median_ns", "service_p95_ns", "fraction_ops", "detector_readings", "events", "output_bytes_before_summary")
            group = {"batch_size": size, "method": method, "repeats": len(chosen),
                     "qualified_missions": [r["qualified_missions"] for r in chosen], "failures": sum(len(r["failures"]) for r in chosen)}
            for metric in metrics:
                values = [r[metric] for r in chosen if r[metric] is not None]
                group[metric] = {"median": statistics.median(values), "min": min(values), "max": max(values)} if values else None
            groups.append(group)
    comparisons = []
    for size in (1, 8, 32):
        for repeat in range(3):
            pair = [r for r in rows if r["batch_size"] == size and r["repeat"] == repeat]
            if len(pair) == 2:
                left, right = pair
                comparisons.append({"batch_size": size, "repeat": repeat,
                    "science_identical": [m["scientific_hash"] for m in left["missions"]] == [m["scientific_hash"] for m in right["missions"]],
                    "fraction_ops_identical": left["fraction_ops"] == right["fraction_ops"],
                    "detector_readings_identical": left["detector_readings"] == right["detector_readings"]})
    return {"groups": groups, "paired_scientific_matching": comparisons,
            "all_science_matched": all(p["science_identical"] and p["fraction_ops_identical"] and p["detector_readings_identical"] for p in comparisons),
            "all_batches_completed": len(rows) == 18 and all(r["qualified_missions"] == r["batch_size"] and not r["failures"] for r in rows),
            "scope": "Bounded sequential nominal-path ablation; direct implementation lacks full Alpha authority/recovery/security scope."}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True)
    parser.add_argument("--expected-instrument-sha", required=True)
    args = parser.parse_args()
    if sha(instrument.__file__) != args.expected_instrument_sha:
        raise ValueError("instrument_not_at_expected_freeze")
    protocol = json.loads((HERE / "protocol.json").read_text())
    freeze = json.loads((HERE / "freeze_record.json").read_text())
    if sha(HERE / "protocol.json") != freeze["sha256"]:
        raise ValueError("load_protocol_changed_since_freeze")
    ri.verify_vendor()
    snapshot = source_snapshot()
    output = Path(args.output).resolve()
    output.mkdir(parents=True, exist_ok=False)
    persist(output / "source_manifest.json", {"sources": snapshot, "protocol_freeze": freeze,
              "started_at_utc": datetime.now(UTC).isoformat(), "environment": ri.environment(),
              "processor": platform.processor(), "execution_scope": "released source closure, not installed package"})
    rows = []
    for size_index, size in enumerate(protocol["workload"]["batch_sizes"]):
        for repeat in range(protocol["workload"]["repeats_per_size"]):
            methods = ["alpha_dispatcher", "direct_durable"]
            if (repeat + size_index) % 2:
                methods.reverse()
            for method in methods:
                ensure_sources(snapshot)
                result = run_batch(method, size, repeat, output / (f"n{size}-r{repeat}-" + method), snapshot)
                rows.append(result)
                persist(output / "raw_results.json", rows)
                print(json.dumps({"method": method, "batch_size": size, "repeat": repeat, "qualified": result["qualified_missions"],
                      "seconds": result["batch_wall_ns"] / 1e9, "failures": result["failures"]}), flush=True)
    summary = summarize(rows)
    persist(output / "summary.json", summary)
    if not summary["all_science_matched"]:
        raise ValueError("paired_scientific_mismatch; preserve raw results and investigate")


if __name__ == "__main__":
    main()
