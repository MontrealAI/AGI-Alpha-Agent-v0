"""Post-measurement checks of the direct baseline's narrowly claimed replay guard."""
import argparse
import copy
import json
from pathlib import Path
import run_benchmark as bench


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    root = Path(args.results) / "n1-r0-direct_durable" / "journal"
    journal = bench.ri.Journal(root)
    trust, keys = bench.ri.fixture_roles()
    mission_key = "@nominal-direct/mission-0"
    invocation_key = mission_key + "/identify/identify-attempt-1"
    record = journal.latest(invocation_key)
    terms = bench.ri.JobContract.model_validate(record["terms"])
    authorization = bench.ri.ExecutionAuthorization.model_validate(record["authorization"]["payload"])
    initial = {"spec": bench.request_spec(0), "artifacts": {}, "costs": {}, "policy": {"constructor": "search"}}
    before = journal.verify()
    cases, calls = [], []

    def callback():
        calls.append("UNEXPECTED_CALLBACK")
        return {}

    for label, changed, expected in [
        ("exact_replay", False, "direct_invocation_already_claimed"),
        ("request_payload_rebinding", True, "direct_request_identity_rebound"),
    ]:
        context = copy.deepcopy(initial)
        if changed:
            context["changed_payload"] = "same identity, changed intent"
        observed = None
        try:
            bench.direct_stage(journal, trust, keys, mission_key, terms, authorization, context, callback, None)
        except ValueError as exc:
            observed = str(exc)
        cases.append({"case": label, "expected_refusal": expected, "observed_refusal": observed, "passed": observed == expected})
    after = journal.verify()
    result = {"scope": "Two post-measurement direct-loop guard checks. No broad security, crash or external-effects guarantee.",
              "cases": cases, "callback_entries": len(calls), "journal_unchanged": before == after,
              "passed": all(row["passed"] for row in cases) and not calls and before == after,
              "benchmark_sha256": bench.sha(bench.__file__), "check_script_sha256": bench.sha(__file__)}
    bench.persist(Path(args.output), result)
    print(json.dumps(result, indent=2))
    if not result["passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
