# Local load results and interpretation

The frozen nominal load study completed all 18 batches: two implementations,
three batch sizes, and three repeats. All 246 mission outcomes were validator
accepted and oracle qualified. All nine paired comparisons matched the complete
timing-free scientific contexts, counted rational operations and simulated detector
readings. There were no observed failures, manual overrides or runtime operator
interventions. This is a nominal workload result, not a fault-tolerance rate.

| Queued missions | Alpha throughput, missions/s | Direct throughput, missions/s | Alpha median service, s | Direct median service, s | Alpha p95 service, s | Direct p95 service, s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 1 | 0.8682 | 11.4551 | 1.0969 | 0.0703 | 1.0969 | 0.0703 |
| 8 | 0.7654 | 8.2210 | 1.2552 | 0.1047 | 1.4083 | 0.1527 |
| 32 | 0.8163 | 9.3425 | 1.1491 | 0.0967 | 1.3221 | 0.1441 |

Each displayed metric is the median of the three corresponding per-repeat metrics,
not a pooled percentile across all missions. The p95 within each repeat is the
nearest-rank order statistic. In the one-mission condition it is the sole service
observation. Full minima, maxima and raw measurements appear in `load_summary.csv`
and `results/raw_results.json`.

For 32 missions, the median batch wall times were 39.2021 s for Alpha and 3.4252 s
for the direct loop. The median of the per-repeat queue-inclusive p95 completion
latencies was 36.569 s versus 3.109 s. All missions enter the queue at the same batch
start, so these queue latencies reflect waiting behind preceding missions. There is
one sequential worker throughout; batch size does not vary concurrency.

At 32 missions the exact shared scientific work was 136,749 counted rational
operations, with compatible cached construction reused after its first occurrences.
The Alpha journal had 1,442 events and the direct journal 770 events. The 1- and
8-mission workloads used 799 and 121,473 counted rational operations per method,
respectively. All ancestor construction was charged. The joint designs dominate
the cold-construction cost; the larger batch reuses them.

## What this comparison establishes

The direct loop wins measured nominal local overhead. This result is retained
without changing workload, thresholds, ordering or the original protocol. The
additional Alpha mechanisms carry measurable costs in this implementation and host.
There is no latency or throughput win for the Harness to claim from these data.

Both arms execute the same seven scientific callbacks, use the same source-bound
capability cache and fresh scientific validator, retain the same JSON artifact
classes, and use the identical released SQLite Journal and signing/verification
functions. Both create the same institution/release description. The common batch
denominator includes fixture initialization, cache and artifact persistence, full
final journal verification, event export and head retention. Imports are excluded.

The direct loop is a deliberately scoped matched ablation. It does not reproduce
Alpha's full graph-wide separation, descendant proof/authority, admission, revocation
propagation, cancellation, recovery authorization or action-dispatch mechanisms.
Therefore the comparison does not establish that an equivalently secured production
engine is eleven times faster, or assign a universal cost to authority controls.
The speed difference is an observed result for these two concrete nominal local
paths. The intended scientific reuse advantage is identical in both arms.

## Oversight, provenance and reproduction

The two arms performed seven scripted acceptance actions per successful mission:
861 per arm across all batches. These public-fixture script actions are not human
reviews. No human participants were timed. Development, integration, review and
maintenance labor are unknown and cannot be declared equal or zero.

After timing finished, two narrowly scoped direct-loop guard checks replayed an
already completed first-stage invocation and rebound its request payload. Both were
rejected before callback entry; the verified journal head and event count remained
unchanged. `guard_checks.json` preserves those observations.
They do not constitute a crash-schedule, concurrency or universal security audit.

`results/source_manifest.json` records the actual source hashes and Python/dependency
versions. Runtime code came from the immutable Alpha source closure, not an installed
wheel or deployed service. All three test identities are public RFC 8032 vectors,
which authenticate no independent real party. No money was spent through a paid
service or settlement interface by these scripts; compute allocation price is unknown.

All primary raw artifacts are retained under `results/`; no batch was dropped or
rerun to improve the headline. The experiment and integration agents held their
heavy tasks while these sequential timing batches ran, but OS caching and other
shared-host contention were not controlled. The three repeats describe variation
on this host and do not support distributed, Fleet, physical-device, or commercial
extrapolation.
