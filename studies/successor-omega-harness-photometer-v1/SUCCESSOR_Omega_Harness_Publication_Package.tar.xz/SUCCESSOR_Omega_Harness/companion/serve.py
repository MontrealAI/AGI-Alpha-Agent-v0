# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import argparse
import io
import json
import mimetypes
import sys
import threading
import time
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'integration'))
RUN_LOCK = threading.Lock()


class Handler(BaseHTTPRequestHandler):
    def reply(self, status, body, content_type='application/json', disposition=None):
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Content-Security-Policy', "default-src 'self'; style-src 'self'; script-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'")
        if disposition:
            self.send_header('Content-Disposition', disposition)
        self.end_headers()
        self.wfile.write(body)

    def json_reply(self, status, value):
        self.reply(status, json.dumps(value, ensure_ascii=False, allow_nan=False).encode())

    def local_request(self):
        return self.headers.get('Host') in {f'127.0.0.1:{self.server.server_port}', f'localhost:{self.server.server_port}'}

    def do_GET(self):
        if not self.local_request():
            self.json_reply(403, {'error': 'Use the printed localhost address.'})
            return
        path = urlparse(self.path).path
        if path == '/api/status':
            self.json_reply(200, {'status': 'ready', 'mode': 'local released-source research', 'external_execution': False})
            return
        if path.startswith('/api/export/'):
            name = path.rsplit('/', 1)[-1]
            if not name.startswith('run-') or not name[4:].isdigit():
                self.json_reply(400, {'error': 'Unknown run.'})
                return
            target = self.server.runs / name
            if not (target / 'demo.json').is_file():
                self.json_reply(404, {'error': 'Run not found.'})
                return
            memory = io.BytesIO()
            with zipfile.ZipFile(memory, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
                for item in sorted(target.rglob('*.json')):
                    if not item.is_symlink():
                        archive.write(item, str(Path(name) / item.relative_to(target)))
            self.reply(200, memory.getvalue(), 'application/zip', f'attachment; filename="{name}-evidence.zip"')
            return
        routes = {'/': ROOT / 'web/index.html', '/index.html': ROOT / 'web/index.html', '/style.css': ROOT / 'web/style.css', '/app.js': ROOT / 'web/app.js', '/study.json': ROOT / 'web/study.json'}
        item = routes.get(path)
        if item is None or not item.is_file():
            self.json_reply(404, {'error': 'Not found.'})
            return
        self.reply(200, item.read_bytes(), (mimetypes.guess_type(item.name)[0] or 'application/octet-stream') + ('; charset=utf-8' if item.suffix in {'.html', '.js', '.css', '.json'} else ''))

    def do_POST(self):
        if not self.local_request() or urlparse(self.path).path != '/api/run':
            self.json_reply(403, {'error': 'Local research endpoint only.'})
            return
        origin = self.headers.get('Origin')
        if origin and origin not in {f'http://127.0.0.1:{self.server.server_port}', f'http://localhost:{self.server.server_port}'}:
            self.json_reply(403, {'error': 'Open the local companion to run a mission.'})
            return
        try:
            length = int(self.headers.get('Content-Length', '0'))
            if not 0 < length <= 1024 or self.headers.get_content_type() != 'application/json':
                raise ValueError('Send a small JSON scenario selection.')
            body = json.loads(self.rfile.read(length))
            if set(body) != {'scenario'} or body['scenario'] not in {'nominal', 'crash', 'negative_transfer'}:
                raise ValueError('Choose one of the three bounded scenarios.')
        except (ValueError, TypeError, json.JSONDecodeError) as exc:
            self.json_reply(400, {'error': str(exc)})
            return
        if not RUN_LOCK.acquire(blocking=False):
            self.json_reply(409, {'error': 'A mission is running. Wait for its evidence.'})
            return
        try:
            from run_integration import run_demo
            name = 'run-' + str(time.time_ns())
            target = self.server.runs / name
            result = run_demo(target, body['scenario'])
            self.json_reply(200, {'run_id': name, 'download_url': '/api/export/' + name, 'result': result})
        except Exception as exc:
            self.json_reply(500, {'error': str(exc), 'type': type(exc).__name__, 'help': 'Check the pinned setup instructions in README.md. No successful mission is claimed.'})
        finally:
            RUN_LOCK.release()

    def log_message(self, fmt, *args):
        print('[companion]', fmt % args)


def main():
    parser = argparse.ArgumentParser(description='Run the local SUCCESSOR Omega research companion.')
    parser.add_argument('--port', type=int, default=8765)
    parser.add_argument('--runs', type=Path, default=ROOT / 'local-runs')
    args = parser.parse_args()
    from run_integration import verify_vendor
    verify_vendor()
    server = ThreadingHTTPServer(('127.0.0.1', args.port), Handler)
    server.runs = args.runs.resolve()
    server.runs.mkdir(parents=True, exist_ok=True)
    print(f'\nSUCCESSOR Ω Harness — local research companion\nOpen http://127.0.0.1:{server.server_port}\nPress Ctrl+C to stop.\n', flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == '__main__':
    main()
