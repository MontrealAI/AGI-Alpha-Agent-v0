# Source research for SUCCESSOR Omega Harness

Research date: 24 October 2026. This is an internal source audit, not new experimental evidence.
Canonical public source snapshot: MontrealAI/AGI-Alpha-Agent-v0 at
031bdb5d055c8bad896daa076baea2b5e17b242c.
All seven PDFs below were inspected from actual full files. Library originals were
materialized without alteration, then compared byte-for-byte with the public repository files.
This audit did not rerun the prior papers' experiments. Their numerical results remain
attributed prior-paper claims, not results of the new Harness experiment.

## Canonical corpus and edition selection

| Stage/source | Exact public title | Manuscript date | Public filename | SHA-256 |
| --- | --- | --- | --- | --- |
| Foundation | Transformational Intelligence: Learning to Change the Game | October 2026 | Transformational_Intelligence.pdf | d7170e8217e3bf6aa1b84868c1c76c5994c6995c5297ed092d7e72a6430c664f |
| Out-Learn | Out-Learn: Change What You Need to Know — Constructed Experiments and Sharp Calibration Guarantees for Reusable Learning | 21 October 2026, revised | Out_Learn.pdf | 01a8ea668f4c75cd0b5fafe3c5720e445bab7986abf27baee5bbba7d5e77febb |
| Out-Think | Out-Think: Transformational Intelligence for Inventing the Space of Reasoning | 21 October 2026 | Out_Think.pdf | 22280da9d3c74b995b0770b3b1a633924a0849d4f72fad51facd8f78c0336029 |
| Out-Design | Out-Design: Creating the Freedom to Transform | 21 October 2026, revised | Out_Design.pdf | 65849e2f872b2dcdbc4a57baabb63e6a2644208c68dcc7c23ec0ee11ac1fe5dd |
| Out-Strategise | Out-Strategise: Transformational Intelligence for Constructing the Conditions of Success | 20 October 2026 | Out_Strategise.pdf | 8a848150f14c578106633324edb54bc59713a579c1318d9ea872d3d5b3ec7e77 |
| Out-Execute | Out-Execute: Constructing the Conditions of Completion — From Repeated Work to Reusable Means of Execution | 21 October 2026, revised | Out_Execute.pdf | 85c6834e2dd496748f72a9099d3a70cb13047b49e09e3ed84ce911e1f1c530f3 |
| Out-Evolve | Out-Evolve: Building the Means of Discovery and Production | 20 October 2026, revised | Out_Evolve.pdf | 5979bcaf704934ba42e4722389cbb1a9ef0cbc889e1b286428615a82a31e99bc |

All list Vincent Boucher, MONTREAL.AI, Montreal, Quebec, Canada as author/affiliation.
Each public source URL is the immutable base
https://github.com/MontrealAI/AGI-Alpha-Agent-v0/blob/031bdb5d055c8bad896daa076baea2b5e17b242c/docs/
plus the exact public filename. The corresponding .tex file exists in that directory.

Edition caveats:
- The Library's Out_Learn_Revised.pdf equals public Out_Learn.pdf.
- The Library's Out_Design_Revised.pdf equals public Out_Design.pdf.
- The Library's Out_Strategise(3).pdf equals public Out_Strategise.pdf.
- The Library's Out_Execute_Revised.pdf equals public Out_Execute.pdf.
- The Library's Out_Evolve(1).pdf and Out_Evolve(2).pdf equal public Out_Evolve.pdf.
- A distinct Library Out_Evolve.pdf has SHA-256
  308e9167e80b8273ccebccfbbc397dbec2bbe6bc3da0d02230f6c652758e3c71 and title
  "Build What Makes Discovery Possible". It studies a 1,024-run precision-aware design.
  It is not the canonical public Out_Evolve.pdf in this snapshot. Do not mix its
  results into the public paper's attribution.
- Out_Evolve_Capability_Constructor.pdf, SHA-256
  4aaa92f4fe1c8f6afc5d6c090a81db85b99bdc1890aeec207b25b199778d2148,
  is explicitly a prepared implementation brief ("No implementation started"),
  not evidence that its constructor has run.
- Out_Strategise_Refined.pdf is another distinct study, about an affine-readout
  separate-or-cover construction. The canonical public paper is the network study.

## Foundation: what TI actually requires

TI separates the authorized intent charter, the problem formulation, and the evaluation
instrument (sections 2, 4). The charter fixes purpose, material requirements,
permissions, and budgets. The formulation contains representations, model assumptions,
information procedures, policy language, and intermediate targets. The evaluator is a
measurement instrument; it cannot silently become the user's purpose.

A useful transformation must have an executable construction, a realization in the
original environment, an outcome bridge, and a witness identifying the old restriction
and a possible disconfirmation (section 4.3). A formal bridge is conditional on its
predicates and assumptions. It cannot excuse unauthorized construction actions.

The exact example is a supplied two-world causal model. Passive observations cannot
distinguish the worlds, while permitted interventions can. At twelve interventions
the stated accuracy is 8191/8192. An unrestricted exact Bellman planner matches.
The paper explicitly denies that this is a new causal-discovery algorithm,
autonomous LLM invention, or general transformational intelligence (sections 3, 11).

Experimental instructions inherited by the Harness study:
- Same permitted tools and information for unrestricted competitors.
- A competent hand-engineered construction, with its actual costs.
- Structural ablation, not merely a label comparison.
- Search, setup, failed proposals, verification, maintenance, and human effort included.
- Retain the incumbent or stop when construction is not worthwhile.
- Transfer of a capability and improvement of a discovery policy are distinct claims.
- Hashes bind bytes; they do not prove truth, independence, or semantic applicability.

For the new photometer study, the binding restriction can be an unidentifiable
measurement channel. The transformation changes the observation operator while
preserving the intended scientific signal. The Harness's contribution should concern
how that constructed instrument becomes an accountable, usable inheritance.

## Out-Learn: construct an informative measurement, then calibrate

Actual model (sections 1–6):
y_i = g sigma_i s + sum_{k=0}^d theta_k t_i^k + e_i.
The signal remains constant inside one block; the unknown positive gain satisfies
g >= g0 > 0 and is stable across a reference/use scope; drift coefficients can vary
arbitrarily between blocks; raw errors have a deterministic componentwise bound.
Polarity reversal preserves the intended signal's meaning.

The constructor produces times, signs, and weights with
w^T sigma = 1 and w^T V_d = 0.
Then z = w^T y has error at most eta ||w||_1 about g s.
The sparse known-gain result uses d+2 readings under its deletion-monotone
reading/switching/waiting cost and distinct-time assumptions. This is classical
optimal-recovery/linear-programming structure specialized to this model, not
new physical primitives.

The concrete quadratic design is:
times (0,2,3,5), signs (+,+,-,-), weights (-1,5,-5,1)/8.
A unit reference with raw readings (62,112,153,323)/5 gives c=7/5.
A separate unknown-signal block with raw readings (17,17,28,88)/5 gives z=2/5.
The recovered signal is 2/7, despite different drift polynomials.

The calibration interval is
[a,b] = [max(g0,c-e_c), c+e_c], e_c=eta_c ||w_c||_1.
For a fixed reference/query pair, e_o=eta_o ||w_o||_1, the paper proves the
sharp risk min{S, max{(S e_c+e_o)/(g0+2e_c), e_o/g0}}.
At stated prices (read=1, switch=2, elapsed unit=0.1), its one-use pair costs
13 acquisition units and guarantees 3/1003 error. Those units do not price
candidate-scoring computation, hardware construction, qualification, or labor.

The new experiment must not inherit those numbers. It may reuse the observation
principle and compare a newly constructed two-channel decoder.

Scope-changing successor and failures (section 8):
- An old d=1 three-reading program fails when the query scope admits quadratic drift.
- A compatible historical gain reference can survive, but the query program must change.
- If the old reference itself violated its original nuisance scope, that reference cannot transfer.
- A signal-shaped nuisance b sigma is indistinguishable from signal; every signal-preserving
  contrast passes it. This is an honest undetected model misspecification.
- Cubic drift defeats the quadratic contract unless its residual is separately bounded.
- Gain changes invalidate old calibration.
- Exact rational computation does not establish sensor range or floating-point stability.
The strong exact specialist is explicitly allowed to match.

## Out-Think: today's sufficient answer may be tomorrow's insufficient state

The finite model supplies source states S, truthful query contexts, required answers,
and permitted state transitions. A canonical interface consists of h, d, and U_a with
d(h(s),c)=f_c(s) and U_a(h(s))=h(T_a(s)).
Static answer preservation alone does not imply a valid update. The compiler derives
current conflicts and their closure under future operations, and checks transition
consistency (sections 2–4).

The modular example starts with h0(x,y)=x+2y mod p. Adding multiplication of x by a
primitive root requires a new interface. Preserving h0 as recoverable forces p^2 labels;
replacing it while preserving external answers permits 3p. At p=101, 303 versus 10,201
resident labels are mathematical alphabet sizes, not model speedups or total storage.
Re-encoding needs source data or sufficient evidence: the old label alone generally
cannot construct the new one (section 5).

Photometer relevance: a one-signal contrast can be sufficient for the ancestor and
insufficient for two separately identifiable amplitudes. Preserve the raw evidence,
nuisance semantics, and solver implementation; construct the new representation and
check its rank/decoding obligations. Do not cite the graph theorem as a proof about
the instrument.

Failure lessons: false but compatible contextual assumptions can yield an undetectably
wrong answer; adding another permitted operation can remove the compression advantage;
the specialized constructor rejects structures outside its premises (section 9).

## Out-Design: a saving matters only if it enables the next construction

The revised model preserves required functions on all independent inputs, while
allowing joint code realization under explicit resource envelopes. A release certificate
contains complete source contracts, executable joint kernel, equivalence check,
resource account, authorized handover, and the identity of the vacated worker
(sections 3–5).

The reported finite example replaces 171 abstract instructions for two services with
a checked 111-instruction joint realization under a 120-instruction worker cap.
The useful released worker enables all eight endpoint configurations. Releasing the
wrong worker achieves the same kernel saving but no changed endpoint.
This is not a hardware benchmark.

An actual source-study successor reopens the saved joint realization, requalifies it,
constructs a distinct threshold service, and provides twelve service identities on
eleven workers. The new implementation, input lanes, qualification, routing, and changed
failure exposure remain charged. The paper preserves the specialist tie (section 9).

Photometer relevance: choose a realizable modulation/measurement design that meets
quality and budget, and show the additional identifiable signal it enables. A lower
operation count without a qualified new observable is not the intended transformation.

## Out-Strategise: optimize information and construction together

The canonical public study has a finite hypothesis set and constructible modules.
A common completion must be the same executable policy across all surviving worlds:
world-by-world existence is insufficient. The exact compiler optimizes observations
and construction together. Its deferred-construction normal form requires
noninterference, persistent assets, and the stated timing semantics (sections 2–3).

For m groups of k links, one failed link, group alarm c, fine test t, repair r, bypass b:
v(k)=min{b,kr,r+(k-1)t}, and for c<=t,
V(m,k)=min{m min(b,kr), c+v(k)}.
At m=k=4 and (c,t,r,b)=(2,2,3,5), the joint strategy costs seven versus eleven
for repair-only and twenty for observation-free construction.
An unrestricted comparator receives all modules and matches the optimum.
These are supplied abstract costs and synthetic topology, not model intelligence gains.

A stronger successor adds a mandatory checkpoint skipped by the old bypass.
The parent action is rejected; retained uncertainty informs a newly qualified four-unit
extension. The old exact count quotient is invalid under some new destinations,
showing that compression must be indexed by purpose (sections 5, 7).

Photometer relevance: compare reusable calibration plus requalification against direct
construction/rebuild under the same resource model, including stop. More sensing is
not automatically better than constructing a measurement that avoids needing to
identify each nuisance coefficient.

## Out-Execute: preserve continuation behavior and renew acceptance

The canonical revised model uses finite separable cost systems.
A module exports its complete boundary value function v_i(b) and an attaining witness
for every admissible boundary assignment. With complete factor ownership,
min F = min_b[f0(b)+sum_i v_i(b)].
Two components are interchangeable for every allowed external continuation precisely
when their boundary value functions agree (sections 3–4). This is a precise
specialization of variable elimination and semantic continuation equivalence.

When an interior changes but its boundary profile does not, outside optimization can
stop propagating. The changed local witness, input identity, current-output check and
receipt still have to be renewed. A stored scalar optimum is not a sufficient interface.

The source paper reports 576 synthetic snapshots agreeing with full enumeration,
158 semantic stops, and a saved 98-task system extended to 101 tasks by building
one new module and reusing 32. It explicitly preserves the competitive fixed-certificate
executor and does not infer speedup from incomparable counts (section 7).

Its local SQLite acceptance service checks current revision and authority, binds
qualified profiles to current source, verifies complete ownership and the final
assignment, and atomically commits accepted head plus receipt.
Request identity is bound to payload. Exact replay returns the old receipt; rebinding
is rejected. The prior paper's six actual process-crash cuts and four races are
source-paper results, not rerun here (section 8).

The stated guarantee is local and conditional on a correct checker, complete controlled
updates, immutable qualification records, identity checks and transactional storage.
An arbitrary remote effect with lost acknowledgement and no durable request key/outcome
query remains uncertain. No universal exactly-once property transfers.

## Out-Evolve: a capability expands the next useful frontier conditionally

The canonical public paper's central conditional theory contrasts arbitrary scalar
response on n binary controls (2^n exact point queries) with a qualified degree-k
response class (sum_{j<=k} binom(n,j) queries). For n=20,k=2 this is 1,048,576 versus
211. A compatible 21st switch preserving the old baseline requires 21 new exact
calibrations. These are dimension bounds for declared function classes, not a
performance comparison against an entitled specialist (section 2).

The qualification burden is central: structure must be constructed and verified,
not inferred from an attractive fit. A shared nonlinear bottleneck, changed baseline,
higher-order terms, or unstable measurement can break inheritance. Minimal acquisition
can be numerically fragile: the 211-point design can amplify bounded reading errors
by 721. Construction, calibration precision, computation and labor all matter.

Two source-study mechanisms are explicitly synthetic:
- A retained reversible operation can be reopened to obtain an eight-step successor
  instead of ten using sealed reuse; unrestricted fresh search also reaches eight.
- A technically cheaper measurement architecture can still fail cost recovery under
  supplied participation constraints. Feasible cost recovery is not commercial profit.
The industrial manufacturing/assembly succession is a proposed research program,
not an implemented deployment (sections 4–5).

Photometer relevance: freeze an executable calibrated instrument, exercise fresh
purposes, then add a distinct accepted measurement capability. Report both full
ancestor-plus-successor cost and incremental successor cost. Calibration, scope and
new authority must be earned again where changed.

## Suggested seven-stage implementation contract

This table is a design mapping for the new study. Only claim a row as executed after
the experiment/runtime artifacts establish it.

| Stage | Inputs | Actual computation to exhibit | Artifact | Cost to record | Falsifiable contribution |
| --- | --- | --- | --- | --- | --- |
| Identify | Mission, quality, nuisance model, permitted controls | Check identifiability/rank and incumbent failure | Obstruction witness and mission specification | Matrix work, diagnosis time | Show unmodulated signal aliases nuisance |
| Out-Learn | Raw unit-reference observations | Produce bounded gain/calibration interval | Calibration record with scope | Simulated detector reads separately from arithmetic | Removing valid calibration widens/invalidates response |
| Out-Think | Required observable(s), nuisance basis, available times | Construct quotient/projection representation and new decoder obligations | Basis/decoder contract | Linear algebra and serialization | Ancestor scalar representation cannot resolve two signals |
| Out-Design | Control grammar and resource limits | Construct/select admissible modulation program | Executable schedule and certificate | Candidate evaluation, build and checking | Wrong/rank-deficient schedule fails unchanged quality |
| Out-Strategise | Reuse horizon and complete cost vector | Choose retain/requalify/rebuild/stop under fixed budget | Decision record with all alternatives | Selection and ancestor costs | Short-horizon or expensive requalification may favor rebuild |
| Out-Execute | Frozen mission, adapter and current authority | Run existing dispatcher, validate receipt, recover bound retry | Durable events and accepted artifact | Execution, checks, persistence, recovery | Interrupted or stale work never silently becomes current accepted work |
| Out-Evolve | Accepted package and materially different requirement | Import valid assets, construct new rank/decoder, fresh qualification | Successor package and lineage | Import, new build, new reads and requalification | Changed scope fails unless missing capability is built; new authority required |

For a k-channel linear instrument y=S a+V theta+e, a decoder W satisfying
WS=I_k and WV=0 exists iff rank([V S])=rank(V)+k.
This is established linear algebra. It is a useful mechanism certificate, not a novel
general theorem. Componentwise raw bounds imply coordinate error eta||W_j||_1
before any additional gain-uncertainty treatment.

## Related work: primary sources checked

1. Temporal documentation, "Activity Definition", accessed 24 October 2026:
   https://docs.temporal.io/activity-definition
   Activities are ordinary functions; safe retries require idempotency design.
   Supports ordinary workflow engineering attribution, not the experiment's performance.

2. Malcolm Featonby, Amazon Builders' Library, "Making retries safe with idempotent APIs":
   https://aws.amazon.com/builders-library/making-retries-safe-with-idempotent-APIs/
   Documents caller-supplied request identity, uncertain response and duplicate-effect risks.

3. Collin Lee, Seo Jin Park, Ankita Kejriwal, Satoshi Matsushita, John Ousterhout (2015),
   "Implementing Linearizability at Large Scale and Low Latency", SOSP, 71–86:
   https://web.stanford.edu/~ouster/cgi-bin/papers/rifl.pdf
   DOI 10.1145/2815400.2815416.
   RIFL retains completion records and manages deduplication metadata. Do not generalize
   its protocol assumptions to uninstrumented external services.

4. Luc Moreau and Paolo Missier (editors), W3C (2013), "PROV-DM: The PROV Data Model":
   https://www.w3.org/TR/prov-dm/
   Establishes entities, activities, agents, derivations and attribution. Recorded provenance
   supports assessment; provenance alone is not semantic correctness or authority.

5. George C. Necula (1997), "Proof-Carrying Code", POPL, 106–119:
   DOI 10.1145/263699.263712.
   Author's publication index:
   https://people.eecs.berkeley.edu/~necula/papers.html
   Strong precedent for producer-supplied evidence checked at a consumer boundary.
   A JSON receipt is not equivalent to a formal PCC proof.

6. Ross M. McConnell, Kurt Mehlhorn, Stefan Näher, Pascal Schweitzer (2011),
   "Certifying Algorithms", Computer Science Review 5(2), 119–161:
   https://www.cs.colostate.edu/~rmm/cert11.pdf
   DOI 10.1016/j.cosrev.2010.09.009.
   Separating complex construction from simpler output checking is established practice.

7. Jim Gray and Leslie Lamport (2006), "Consensus on Transaction Commit",
   ACM Transactions on Database Systems 31(1), 133–160:
   https://www.microsoft.com/en-us/research/publication/consensus-on-transaction-commit/
   DOI 10.1145/1132863.1132867.
   Source compares Two-Phase Commit and Paxos Commit under explicit failure assumptions.
   A thin Harness does not introduce a new distributed commit protocol.

8. Martin Fowler (2005), "Event Sourcing":
   https://martinfowler.com/eaaDev/EventSourcing.html
   Historical original engineering article, explicitly a draft. State changes as an
   event sequence and reconstruction from history are established architectural ideas.

9. Ted Doiron (1993), "Drift Eliminating Designs for Non-Simultaneous Comparison
   Calibrations", Journal of Research of NIST 98(2), 217–224:
   https://doi.org/10.6028/jres.098.016
   Drift-eliminating comparison schedules and their physical assumptions predate this study.

10. H. Erik Swanson and Stephan Schlamminger (2010), "Removal of Zero-Point Drift from
    AB Data and the Statistical Cost", Measurement Science and Technology 21(11), 115104:
    https://arxiv.org/abs/1009.1894
    https://arxiv.org/pdf/1009.1894
    DOI 10.1088/0957-0233/21/11/115104.
    Polynomial drift removal and uncertainty tradeoffs are existing metrology.
    Its stochastic variance criterion is different from the new study's bounded-error contract.

11. SQLite, "Atomic Commit in SQLite" and "Transaction", accessed 24 October 2026:
    https://www.sqlite.org/atomiccommit.html
    https://www.sqlite.org/lang_transaction.html
    The former explicitly conditions durability on hardware/filesystem behavior and distinguishes
    rollback from WAL. The latter documents one simultaneous writer and busy/error handling.
    Cite the actual backend used; do not attribute SQLite guarantees to a different journal.

12. Umut A. Acar (2005), "Self-Adjusting Computation", CMU-CS-05-129 dissertation:
    https://www.csd.cmu.edu/academics/doctoral/degrees-conferred/umut-a-acar
    The institutional abstract establishes dependency tracking/change propagation as prior art.
    The large PDF fetch timed out; limit any attribution to that verified scope.

## Recommended novelty and evidence wording

The defensible contribution is a specific research-and-engineering contract for
turning bounded mission results into inspectable successor assets, plus an executed,
resource-accounted scientific construction that tests when that contract helps.
The experiment should identify the mechanism and its failure boundaries. It need not
win against a competent conventional implementation to be useful.

Avoid claiming novelty for:
- Event sourcing or durable workflows.
- Caches, dependency tracking, idempotency keys or transaction commits.
- Least squares, rank tests, drift cancellation or linear demodulation.
- Access controls, source hashes or ordinary test validation.
- Naming the stages or surrounding existing mechanisms with agents.

A strong result may instead establish:
- Which exact assets transfer and why.
- Which proof/authority state must be renewed.
- A useful new measurement requirement that is genuinely infeasible for the ancestor.
- Total cost/coverage regions where inheritance helps, ties, or loses.
- Recovery without erased history or duplicate modeled effects under stated assumptions.
- A failure invisible under false physical/model premises, preserved honestly.

