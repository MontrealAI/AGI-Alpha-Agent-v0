# Independent scientific and manuscript review

Reviewer role: source/literature agent, separate from the instrument implementation agent.
Date: 24 October 2026. This is a bounded code/manuscript review, not an external peer review,
organizationally independent validation, or physical instrument qualification.

## Reviewed artifacts

- `work/experiment/protocol.json`, original frozen SHA-256
  `cb3a71483ade02deb1c835b8a5358dc728d87ed29d7df48812d97940e586f263`.
- `work/experiment/instrument.py`, multiple pre-main development states.
- `work/experiment/run_experiments.py`, before main outcome inspection.
- `paper/sections/method.tex`, `harness.tex`, `instrument.tex`, `protocol.tex`.
- Canonical revised Out-Learn source and six other papers identified in `canonical_sources.json`.

## Scientific guarantee

For the declared world `y = g R s + V beta + e`, with one common positive gain in a
reference/sample pair, a known unit-amplitude reference in each channel, and
componentwise bounded additive error, the implementation's interval logic is sound.
Each demodulated reference coordinate bounds the same gain. Their intersection with
the declared gain range remains a valid interval when the model holds. Dividing the
sample contrast interval by the positive gain interval and clipping to the declared
signal range preserves coverage. Midpoint error is bounded by half the interval width.

The complete conservative scalar worst-case radius, for the unit signal range and
equal reference/query contrast bounds `e`, is

`min(1, max(2e/(g_min+2e), e/g_min))`.

The first implementation and draft displayed only `2e/(g_min+2e)`. That is sufficient
for every accepted design here because the .02 acceptance threshold implies
`e < g_min/2`; it is not the unrestricted formula. The implementation was corrected
before main evaluation to compute the complete expression. The manuscript proof
must either display that expression or explicitly restrict to `e <= g_min/2` and
cover the zero-straddling sample-interval case. In that case its radius is at most
`e/g_min <= 2e/(g_min+2e)`. This was not a discovered failure in the held-out sample.

For multiple outputs, applying the scalar bound coordinatewise remains conservative:
intersecting several compatible gain intervals can only narrow the scalar feasible
set. No independence assumption between demodulated errors is needed. The matrix
construction uses exact rational arithmetic; the claims do not establish floating
point stability or physical sensor admissibility.

The rank condition `rank([V,R]) = rank(V)+p` is established linear algebra. Its proof
in the manuscript is correct. The constructor is a finite search over specified
control patterns with a fixed least-squares left inverse for each; it is not a global
minimum over all possible schedules or over all left inverses of a nonsquare design.

## Artifact-admission findings, corrected before main evaluation

Initial `validate_capability` recomputed scientific identities but did not enforce
the admitted time grid or control library. Rehashing an out-of-library artifact could
therefore preserve its algebra while violating the declared permitted instrument.
The latest reviewed code checks the exact time grid and admitted controls. It also
checks the nuisance representation, unit/gain/noise/model metadata, independently
recomputed amplification and risk metadata, canonical schema, source identity, and
the explicitly noninheritable authority field. These findings were reported before
main experiments. The implementation agent reports tests for the corrected cases;
this review does not substitute that report for its retained test output.

The new parent nuisance recipe is actually parsed and evaluated at the successor's
new sampling times. This is stronger than a timeline label. However, its schema is
small and a direct expert can construct it independently. Reusing it adds verification
work; the first scalar-to-dual transition must not be claimed cheaper or causally
dependent on inheritance. The numerical solver is preexisting shared software, not
an artifact newly invented by the scalar mission. Repeated reuse of a newly built
dual decoder is a different, testable source of savings.

## Accounting review

The same `Counter` is threaded through all seven stages of primary campaigns. It
retains construction work before a budget exception and all ancestor costs. The
strong conventional policy uses the identical callbacks/cache/validators, so equality
of scientific operation counts is expected and correctly preserved. The expert
reference may stop at the first qualifying candidate and can beat exhaustive search.

Two pre-main implementation accounting details were flagged: an uncounted duplicate
nuisance-basis calculation in the constructor should use the counter; an integer
planning multiplication should not be labeled a rational operation without either
performing/counting that rational operation or clearly excluding it. The simulator's
generation and oracle-check arithmetic are separate from the declared counted
decoder/design kernels; they remain covered by measured wall/CPU time. The paper must
avoid calling this rational-operation counter total computation cost.

Scientific policy comparison uses ordinary in-memory compatible caching, with
capability artifacts written for evidence. The additional local load study measures
actual durable cache reads/writes and full source runtime callbacks separately.
It must not retroactively represent the science policy comparison as a production
workflow-engine throughput measurement.

## Causal interpretation and manuscript corrections

- The stage table should match computation. Out-Learn constructs/evaluates the nuisance
  representation and records calibration obligations; actual reference acquisition is
  in Out-Execute. Out-Strategise computes reading feasibility and execute/stop; the
  comparison of cache/rebuild policies occurs in the study, not as an online policy
  search inside that callback.
- The seven `stage_ablations` records are mostly stage-linked structural probes.
  The Out-Think probe still calls the solver, whose singular inverse fails closed.
  It does not establish causal necessity of a separately named Out-Think callback.
  The gain-change control violates within-pair common gain, rather than performing
  an independently designed historical-reference ablation.
- Response-only fitting without nuisance cancellation, sequential scalar acquisition
  under the joint cap, and discarded-cache reconstruction actually alter computation
  and support appropriately narrow ablation claims.
- Preserve the deliberate conventional equality, the expert's possible construction
  win, and the failure of signal-shaped interference detection. A signature or hash
  cannot distinguish that interference from a changed target amplitude.
- The sixteen-versus-twelve comparison is conditional on separately calibrated scalar
  procedures. A competent ordinary joint design is fully entitled to twelve readings.
- The corpus supplies theory/method examples, not results of this new experiment.
  The new work's contribution is an inspectable implementation and evidence of a
  capability transition, not novel drift cancellation, caching, or transaction theory.

## Runtime draft limits

The mission, WORLD/POLICY/PROOF/AUTHORITY separation, conditional duplicate-suppression
proposition, no-universal-exactly-once statement, and history-versus-current-authority
distinction are appropriately scoped. The released runtime source audit remains the
authority on exact API behavior; this review did not establish installed-package or
deployed behavior. Public fixture role signatures do not create independent witnesses.

## Review outcome

No remaining outcome-critical scientific defect was found in the latest reviewed
model/code before evaluation, subject to the stated assumptions and manuscript
corrections. This conclusion is limited to the finite local emulator, exact arithmetic
and intended internally generated mission inputs. It is not a universal parser audit,
security proof, physical calibration certificate, or claim of complete independent
replication. Subsequent changes and measurements must retain their own source hashes.
