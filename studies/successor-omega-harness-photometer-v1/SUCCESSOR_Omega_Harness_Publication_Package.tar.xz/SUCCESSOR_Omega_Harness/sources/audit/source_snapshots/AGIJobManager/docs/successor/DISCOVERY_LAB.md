# Discovery Lab route admission

Parent integration: [Alpha #4850](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/issues/4850). Repository tracking: [#1612](https://github.com/MontrealAI/AGIJobManager/issues/1612).

This additive work admits the shared six-stage Discovery Lab request on the separate **USDC (6 decimal places)** route. Alpha owns the finite mission, generated programs, independent checkers, artifacts and existing project history. This receiver owns admission and an inert commission record. It does not construct or evaluate the lab itself.

## Verified baseline and dependencies

- Main: `4d4c32685eebf23b0aa35dbb45abe23ac8a261cb`; tree: `3676cb41be9c5c5110cc266e0ff6f7c20bfbec86` (21 October 2026 observation).
- Current native TI intake accepts `transformational-intelligence/v1`, requiring installed native validation and a separately frozen context. It does not admit the proposed six-stage lab schema.
- Existing public-data project intake is a bounded CSV-oriented executor. It is not promoted into a general six-stage executor.
- The native transformation correction from #1607 is already present through merged #1608 in the qualified v1.19.5/main baseline. This addition preserves those exact adapter bytes; the stale open #1607 draft is not an integration dependency.

## Admission requirements

The installed Alpha inspector and independently selected current mission/source/evaluator context must be supplied by application code, never imported from JSON. Retain exact original UTF-8 bytes and bind one mission revision, one stage and one logical commission identifier to exactly one selected currency route. A different route is a separate branch of the same frozen mission, with no currency conversion or shared balance.

The initial synthetic mode permits zero currency caps, zero reservations, no submission, no transaction, no external execution and no settlement authority. Reject unsupported schema, altered artifacts, stale context, mismatched route, nonzero money and imported authority. Expose unsupported/unprovisioned states rather than simulating submission. Import does not grant fresh capability acceptance.

## Qualification checklist

- [x] Freeze exact shared schema, native inspector and source pins with Alpha at the commit below.
- [x] Implement additive `scripts/integrations/discovery-lab-work-request.mjs` and deterministic regressions.
- [x] Exercise all six stage discriminators, strict fields, source/context drift, unsupported receivers, route exclusivity and money/authority refusal.
- [x] Test against the actual pinned Alpha implementation, including a stronger successor and failed attempts.
- [ ] Obtain independent review and exact-source existing CI qualification.
- [ ] Reconcile current main and existing owner work; review any required new finite release profile explicitly.
- [ ] Publish through supported mechanisms and verify public entry point and source identity.

This document records work in progress. No checks, qualified release, executor competence, production approval or external operation are implied by the checklist.

## Current source checks

The new receiver calls an installed `inspectCampaign(payload, {request, limits})` checker and validates its exact `accepted`, `resourceUsed` and `reasons` report. The caller supplies current `expectedBindings` and `expectedCommission` independently of the imported request. All seven mission/source bindings plus the commission id, branch and route must match. Actual checker resource use is retained; excess use yields an inconclusive result. A locally checked result grants no imported capability acceptance, submission, payment or execution authority.

Fifty-six transport-policy regression cases pass per route on Node 22.23.3 and Node 24.19.0, including all six stages, stale identities, wrong route, nonzero money, unsupported schemas, unprovisioned execution, strict object data, checker mutation and resource overrun. Their deliberately non-semantic transport fixture and checker doubles do not qualify the native lab. Pinned actual Alpha compatibility and independent engineering review pass as described below; required exact-source CI and release qualification remain pending.

The shared contract is copied byte-for-byte from the in-development [Alpha #4851](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/pull/4851) source under Apache-2.0 (SPDX retained), SHA-256 `98c8de8ce2774b7650bf4ee11eeedfb0a69b75fa6d1b080ef823637d77d0ab47`. The native harness pins the complete catalog and inspector at immutable Alpha commit `0385df4c9728db19c396e039cd04678eebfddb9e`, tree `8340ffc1b0dc61ff02f55118c36cf412d68820b6`, generated source hash `46858f3b1e5e2b5cc00f0118b0ec3660d8d701cfa726e097475757efd141442a`. A newer source requires renewed qualification.

Independent engineering review found and verified correction of a trusted-context change during asynchronous inspection. The receiver now freezes checker inputs, snapshots current bindings/commission before suspension and refuses changed context. Budget-exhaustion/truncated/incomplete checker reasons stay inconclusive even at the cap. This scoped source review is not maintainer approval or native qualification.

## Explicit source-scope proposal (not a release selector)

`config/discovery-lab-source-candidate-v1.json`, `config/discovery-lab-source-baseline-v1.json` and `scripts/release/discovery-lab-profile.py` propose a separate nonpublishing source/package profile. Its immutable baseline is the exact main/tree above. The baseline inventory reconstructs that fixed Git tree. Every original blob and mode is preserved except the exact source-only dispatcher projection described below. The only admitted changes are nine explicit new paths: this guide, the shared contract, receiver, receiver tests, transport fixture, receiver-policy workflow, `scripts/release/test-discovery-lab-profile.py`, actual native harness and exact Alpha source-pin catalog. The three new profile-control files make twelve additions in total; no old path has an exemption.

The candidate profile refuses published qualification and always reports `sourcePackageOnly:true`, `releaseQualified:false`, `releaseIdentity:null`, `publicationApproved:false` and `executionApproved:false`. Nineteen adversarial profile tests cover missing/extra inventory, unauthorized rehashed additions, changed dependencies or baseline bytes, mode changes and false qualification claims. No historical release profile, source scanner, release workflow selector or publication mechanism is changed. The package dispatcher receives only the explicit nonpublishing branch described below. Explicit independent scope review precedes any selector switch. The pinned actual inspector is wired only in the native compatibility harness; normal receiver use still requires explicit installed context. A fresh release identity and final-source qualification remain required.

The fixed predecessor contains 1595 files; the proposed full source inventory contains 1607. These counts describe input custody, not native execution or release qualification.

The existing release gate correctly rejects the added inputs: [run 39663150935](https://github.com/MontrealAI/AGIJobManager/actions/runs/39663150935), job 119441141955, stopped at `Transformation source inventory has missing or extra inputs`. Compilation and subsequent release steps were skipped. This failure remains retained; the candidate proposal does not relabel or suppress it.

## Receiver resource reservation and failed attempts

Before calling the installed semantic checker, the receiver charges 10,000 declared admission checking units and counts the encoded raw input, parsed/canonical/frozen copies and expected-context copies. Memory byte units describe those encoded data footprints, not JavaScript heap measurements. It reserves a conservative `2 * inputBytes + 131072` bytes for the complete receipt, including escaped reasons, then supplies only the remaining resource vector to the checker. Insufficient reservation stops before semantic work and remains inconclusive. Actual receipt bytes and checker costs are retained; elapsed milliseconds are measured without charging native wall time twice.

Rejected context and other thrown failures retain their current receiver resource charge. If the installed inspector throws without a valid usage report, the native reservation remains explicitly unresolved; it must not be treated as zero-cost work or a completed negative result. Transport-policy doubles are not performance measurements.

Candidate-only CI derives the complete source path list independently from the actual Git index, refuses untracked source, checks every current byte/mode, and records the exact head/tree. The source-profile test also stages a real directory and verifies that an added rogue file fails default actual-directory enumeration. Package acceptance must enumerate the complete extracted/archive source; it must never supply the verifier's expected set as the observed inventory.

The frozen remaining native allowance is checked independently of the final total cap: unused conservative receipt reservation cannot retroactively enlarge checker memory or storage. All aggregate additions use exact integers before conversion; an unrepresentable total refuses admission while preserving safe receiver/checker components and exact decimal totals. Unsupported/unprovisioned probes and malformed requests retain current admission charges too. Independent review reproduced and verified these boundary corrections, including exact receipt byte counts across plain, control-character and Unicode reasons.

## Supported nonpublishing package selection

Manager also proposes exactly five bounded dispatcher insertions in `scripts/release/package-policy.py`: one named candidate constant, its loader, one additional CLI choice and two dispatch branches. Existing profile names, defaults, guards and branches remain byte-identical after reversing those insertions. The candidate verifier performs that exact projection back to the baseline Git blob, so a recomputed outer manifest cannot admit arbitrary changes to the old selectors. The single existing path has explicit before/after attribution; the twelve new files remain the only source additions.

The new branch supports the existing package builder/extractor's source-only API and refuses `published:true`. Checkout requires complete ancestry, the fixed predecessor, exact HEAD/tree/index/raw bytes, no replace/graft/hidden-index state, and the unchanged existing compiler dependency closure. Package metadata retains the unchanged v1.19.5 source version with no selected release identity or qualification; published v1.19.5 assets are never changed. Current release-gate selection remains unchanged and blocked pending separately reviewed Discovery v1.20.0 release preparation after the independently qualified maintenance v1.19.6 baseline, genuine native pins and final-source checks. The existing main TI baseline is already qualified and remains preserved.

## Actual pinned native compatibility evidence

`discovery-lab-native-test.mjs` authenticates all 26 files in the generated source catalog, the separately pinned installed inspector and the catalog itself against both immutable Git objects and SHA-256 identities. Bounded regular-file reads reject symlinks and changing bytes. It copies authenticated code into a private captured snapshot before import; an imported request cannot select code. Cold source-custody time and encoded input/copy bytes are recorded separately from each receiver attempt.

The harness constructs the actual mission through the native workspace/history APIs, runs native construction and current independent verification, then inspects each of the six typed-artifact prefixes with the installed inspector. It also rejects a rehashed invalid measurement, retains a rejected calibration and exhausted search attempt, preserves the accepted predecessor and checks a stronger accepted successor. Evidence includes the complete retained workspace and its digest, original requests, receipts, declared limits, current receiver/checker costs and export barriers. Explicit finite test envelopes allow 8,000,000 encoded memory/storage bytes to include ancestry and receipt copies; these are synthetic test resources and zero currency caps.

For a shared-route proof, supply the identical retained workspace as the optional third CLI argument to each route harness. Both then inspect the same frozen mission and logical commission id with alternative route-specific branches. Separate default runs create separate missions and establish per-route compatibility only. The policy workflow checks the independently enumerated repository inventory before creating its temporary Alpha checkout, captures the exact upstream commit, and retains the actual native evidence. These checks grant no submission, payment, release or external execution authority.

The final receiver elapsed sample includes complete receipt serialization and byte-count convergence. Safe integer/status/boolean digit reconciliation preserves exact receipt length without another expensive full serialization after that sample. Both supported admission and unsupported probes retain these current costs; a near-cap final serialization cannot leave `local-checked` authority. The shared-workspace proof also requires unique `campaignDigest` plus source-bound predecessor ancestry, monotone controls/memory/operation extension and actual preserved-purpose/retained-factor evidence before labeling a stronger successor.

Failed inspections now return receiver-owned errors with the exact original thrown value retained as `cause`. Frozen, sealed and opaque inspector/context failures cannot prevent resource/authority annotations, and diagnostic getters are never invoked. Raw strings with more than 2,000,000 UTF-16 code units reject before any UTF-8 traversal. Those failed attempts report a logical UTF-16 footprint with no UTF-8 scan or VM-heap claim. The parser enforces the 2 MB UTF-8 ceiling on remaining inputs. A stronger shared-workspace proof also requires distinct unique campaign commitments. These refusals preserve every previously admitted wire value.

The pinned inspector validates the complete committed request and a private snapshot of the separately supplied payload before replay. It requires each remaining limit to fit within the committed vector, and charges a distinct 10,000 declared inspection checking units plus encoded snapshot bytes and actual elapsed time. Native test envelopes derive that inspection reserve from the authenticated installed contract, adding it to the receiver's separate 10,000 admission units and ancestor charter caps. Zero or exceeded elapsed allowances remain incomplete; synchronous finite replay uses a measured soft deadline without a hard preemption claim. Historical 1665 evidence remains scoped to its original source and does not qualify this correction.

The shared parser now encodes only captured descriptor values and validates one inert frame before semantic checks or hash suspension. The receiver also validates and retains one inert checker-report snapshot, so a later report view cannot replace accepted fields or recorded costs. Callback-report regression cases cover property traps, negative late resource values and first-frame unknown authority fields. These are admission-policy checks; actual native compatibility remains separately source-pinned.


## Continue a mission containing a Jobs receipt (next-edition proposal)

The published v1.20.0 installed operator retains its original own-receiver-only behavior. The proposed correction permits one explicitly selected Jobs rc.20 context. It preserves the historical mission's Alpha source and the original v1.20.0 assets.

First independently authenticate the published Jobs rc.20 archive, its manifest and the exact receiver source against the accepted release provenance. Save the following exact record, including its final newline, as `jobs-rc20-counterpart.json`:

```json
{
  "schema": "manager/discovery-qualified-counterpart/v1",
  "id": "jobs-rc20-f7",
  "archiveSha256": "5ae312997ce3e2685760e621954828a82ded714cc245339fcfcdd5245373ccfa",
  "archiveBytes": 457348,
  "manifestSha256": "3ce7fe629f1f39800711dcd3be32f2c5c0b00aec67dbfd45b906a1f32c9d4606",
  "source": {
    "repository": "MontrealAI/AGIJobsv0",
    "commit": "f7c00e668fe31ce1ea907f0006b6c14dc9db5e01",
    "tree": "17c1cf5ccca47d427401e2832433e325d5e10563",
    "adapterSha256": "337fabca02ece2a25b8cc50e56fea5bf5338f2b6f18343eb4a3353a634aefec4",
    "contractSha256": "98c8de8ce2774b7650bf4ee11eeedfb0a69b75fa6d1b080ef823637d77d0ab47"
  }
}
```

Select this record by its independently reviewed SHA-256: `4c03da6f03b9361820d894b20914558a539b54cd566313150b8ece4fe9c03cf1`. Add its absolute path and that SHA-256 as the final two arguments to the existing installed operator command:

```sh
node source/scripts/integrations/discovery-installed-operator.mjs \
  /absolute/discovery-alpha /absolute/workspace-after-jobs.json \
  /absolute/original-usdc-request.json CAMPAIGN_DIGEST \
  /absolute/RELEASE_MANIFEST.json /absolute/new-inspection-output \
  /absolute/jobs-rc20-counterpart.json \
  4c03da6f03b9361820d894b20914558a539b54cd566313150b8ece4fe9c03cf1
```

Omitting the two optional arguments retains the own-receiver-only policy. Only the exact reviewed source/archive/manifest tuple is admitted. Missing, unknown, changed or extra fields refuse. Imported history cannot select trusted sources. Prior receipt sources are checked before producing a new receipt. The new Manager receipt is independently inspected against only Manager's own computed source; only complete-docket export and reopening use the explicitly selected Manager+Jobs context. Raw requests and receipts, event prefix, costs, duplicate refusal and separate zero-cap USDC/AGIALPHA routes remain intact.

This local proposal targets the next available patch after v1.20.0 (proposed v1.20.1, unreserved). Exact-source independent review, finite release-policy rebinding, all applicable checks and new publication/installed acceptance remain required. A local correction does not modify or qualify the original v1.20.0 release.
