# SUCCESSOR Ω Harness: current-source and authority audit

Audit date: 24 October 2026. This is a read-only audit for an independent research publication. Repository sources were fetched into isolated local directories; no repository ref, review, deployment, security setting, credential, financial state or contract was changed. Exact source hashes are in `source_manifest.json`; selected current coordination records and release-asset identities are in `repository_records.json`.

## Current source and publication identities

| Repository | Current main commit | Public product record observed | Meaning for this paper |
|---|---|---|---|
| AGI-Alpha-Agent-v0 | `031bdb5d055c8bad896daa076baea2b5e17b242c` | `v1.41.0`, published 2026-10-24 09:33:43 UTC, 106 assets | Released standalone Alpha source. Its package acceptance does not qualify the separately held Harness composition or Fleet. |
| AGIJobsv0 | `9983478d42c32fe399f28dd9b0e0173f904b8a11` | `discovery-v2.1.0-rc.20`, published 2026-10-23 21:39:36 UTC, seven assets; product source `f7c00e668fe31ce1ea907f0006b6c14dc9db5e01` | Tooling main differs from the accepted released product. Preserve both identities. |
| AGIJobManager | `c5958eae872458c2f3cac48fea0b4bbfadc6ac6c` | `v1.20.1`, published 2026-10-24 01:32:11 UTC, nine assets | USDC6 route with explicitly pinned Jobs counterpart; not a generic current-Alpha admission. |
| AGI-Fleet-Linux | `45759fb096faf8988f58ae5ea71248d0f35a97c7` | Historical `v1.1.4-qualification`, published 2026-10-15 20:20:41 UTC; separate `v0.1.0-local-skills-preview.5`, published 2026-10-16 10:31:59 UTC | Proposed operator 1.1.5 and Discovery preview 0.1.0-discovery-preview.1 are separate unaccepted packages. No current four-installed journey is established. |

These were read from actual Git HEADs and GitHub release resources. A release label alone is not a rerun of the package acceptance. This audit does not repeat historical installations or downloads.

## Active ownership and held operations

The current coordination thread is <https://github.com/MontrealAI/AGI-Alpha-Agent-v0/issues/4850>. Its 208 comments were fetched; the relevant records below were retained verbatim without HTML duplication.

- Source/ownership map: <https://github.com/MontrealAI/AGI-Alpha-Agent-v0/issues/4850#issuecomment-6383751400>.
- Retained permitted checks: <https://github.com/MontrealAI/AGI-Alpha-Agent-v0/issues/4850#issuecomment-6383881139>.
- Latest continuation: <https://github.com/MontrealAI/AGI-Alpha-Agent-v0/issues/4850#issuecomment-6384166924>.
- Research publication receiving boundary: <https://github.com/MontrealAI/AGI-Alpha-Agent-v0/issues/4850#issuecomment-6377105309>.

Harness PR #4863 has frozen original `c455ad4c`; dependent #4865 has `6bb361d5`. The current-main prepared composition is `f8772377887c722f9440a61d587eac88b0a3a61d`, tree `e24ffb0fe0d44465c7c4be49e617a31b5152935e`. The original configured review record 6345107482 still exposes RUNNING/null findings, with its terminal result unknown. A separate merge denial, <https://github.com/MontrealAI/AGI-Alpha-Agent-v0/pull/4863#issuecomment-6347342683>, remains. Existing task/restriction operators must expose the supported dispositions. The retained 39/39 local regression result is permitted development-source evidence, not canonical adoption, installed acceptance, merge, release or public execution. This study must not use a new actor, branch or generic green review to bypass that boundary.

Fleet's existing integration owner retains combined candidate `d0d4459b48a6cb45b0b6393be5099484ad8c6313`, tree `1595bfbb8339fa0c20599de833ac6c1c4eda6192`. Canonical PR heads remain #61 `2ceefbf1`, #64 `15a599d0`, #65 `904fce44`, #66 `4b2e57dd`. The original stopped target is `0b13d3ffb25381dc2ebf9c39abda24824660fd3b`; the public record refers to a possible-cybersecurity automatic approval rejection of peer/source review and a narrower stopped follow-up, without disclosing the full original decision payload. The original restriction/runtime operator must provide that supported scope before eligible source review, canonical adoption, saved-package x64/ARM64 qualification, merge or publication. This audit neither retriggers nor clears it.

The accepted API history remains **Alpha 1.39 + Jobs rc.20 + Manager 1.20.1**. Fleet's candidate still pins Alpha `61532fb8` / 1.38. There is no accepted Alpha 1.41 API tuple and no accepted four-installed tuple. The finite Jobs preparation `3c7d93f53483020bc0c16cf1f3a815cf43a06880` is proposed, not adopted; it must not silently replace historical sources.

The existing publication coordinator is the sole shared-index, merge and Pages owner. Independent preregistered research may continue in an isolated namespace. The concrete handoff is final PDF/TeX/archive identities plus source PR/commit, then receiving-owner acknowledgment of the actual current-main base before shared-catalogue edits. A branch attachment, draft PR or local HTML is not a deployed website.

## Released runtime extension seam

The appropriate seam for a new scientific research companion is the existing released Python job runtime at Alpha `031bdb5d`, not the held `harness.py` overlay:

`alpha_factory_v1.core.runtime.successor.jobs.JobDispatcher.execute_tool(job_id, tool=..., actor=..., invocation_id=..., handler=..., retain_result=True)`.

It invokes **locally installed, bounded, pure application code**. It is not a sandbox for imported arbitrary code. Consequential effects require the existing ActionGateway and its separate authorization. Suitable supporting released interfaces are Journal, SuccessorStore, TrustRegistry, MissionConstitution, CandidateReleaseManifest, JobContract, JobGraph, ExecutionAuthorization and JobResult. `tests/runtime/test_successor_jobs.py` and `test_successor_state.py` supply exact source-level examples.

The released workbench supports five fixed existing families (`reliability`, `performance`, `documentation`, `public-data`, `numerical`) and cannot simply import a new measurement program. The research adapter should therefore bind scientific computation through the installed JobDispatcher callback; keep the artifact and journal scope explicitly local. Do not present it as a newly supported Jobs/Fleet scientific family.

### Mechanisms already provided by released code

| Requirement | Actual implementation | Claim boundary |
|---|---|---|
| Mission, budget, actions, acceptance | `successor/protocol.py`: MissionConstitution (251), ResourceBudget (225), JobContract (389), JobGraph (429), ExecutionAuthorization (438), ProofReceipt (619), AuthorityEnvelope (660) | Typed declarations and runtime checks. Resource declaration is not a physical resource meter. |
| Durable attributable history | `runtime/store.py:264–440`: SQLite WAL; `transaction` uses `synchronous=FULL`; append binds sequence, previous digest, journal identity, mission and time; Ed25519 signature; verify checks every event | Tamper evidence relative to trusted key/head. A copied valid prefix is not detected without separately retained checkpoint/custody; not remote attestation. |
| Explicit job graph | `successor/jobs.py:74–141` | Requires seven lifecycle families, complete critical coverage, acyclic dependencies, distinct formation/challenge roles, resource reservations, compatible input/output ports. Seven labels by themselves do not establish useful stage contributions. |
| Dispatch | `successor/jobs.py:240–320` | Controller-signed exact terms, release and environment; current dependencies, source-bound evidence, attempt bound, unique reservation, shared resource ceiling. Production proof is not created by development dispatch. |
| Installed adapter invocation | `successor/jobs.py:356–436` | Durable invocation claim before handler; checks again immediately before and after handler; retained exact canonical output can close an interrupted handoff. Same invocation cannot replay. |
| Work acceptance | `successor/jobs.py:438–479` | Acceptance signer must be the frozen owner; exact attempt/terms/output types; charges max(reservation, actual); unknown actuals remain unknown; overrun stops institution. Acceptance of useful negative evidence is possible. |
| Recovery | `successor/jobs.py:481–514` | Exact institution/job/authorization and new controller decision; conservatively charges reservation; leaves uncertain run/tools in history; fresh authorized attempt required. Not universal external exactly-once. |
| Evidence revocation | `successor/jobs.py:516–536` | Transitive dependency revocation preserves accepted historical work while preventing reuse. |
| Proof scope | `successor/state.py:298–347` | Exact release, environment, institution, mission, current validity, evidence rights and verifier disclosure. Local role separation cannot be relabelled independent. Unknown economic costs prohibit an economic Alpha proof. |
| Authority and recovery | `successor/state.py:435–546,759–785` | Current separate signed grants and action checks; uncertain actions impair affected proof/admission/grants and stop the institution. Recovery does not restore expired authority. |
| Successor lineage | `successor/state.py:787–792` | New exact release registration; historical artifacts may be reused, but no automatic proof or grant inheritance. |

The pure adapter boundary plus durable claims gives at-most-once invocation identity within one trusted journal. If the process dies after computation but before retained completion, the runtime cannot infer whether the computation finished; it keeps uncertainty. A remote effect needs additional destination-side idempotency, receipt lookup or reconciliation assumptions. Avoid asserting universal exactly-once semantics.

`Journal.initialize` generates private local signing material and an API token. These are local runtime internals with no external account authority. They must never enter the research archive. Export public event bodies, signatures, public source keys and pinned head checkpoints only. Local producer/verifier/controller keys are distinct roles under one operator, not evidence of independent organizations.

## Five-contract Alpha suite: source-derived functions only

All paths below are relative to Alpha `031bdb5d055c8bad896daa076baea2b5e17b242c`. Public source URLs have the form `https://github.com/MontrealAI/AGI-Alpha-Agent-v0/blob/031bdb5d055c8bad896daa076baea2b5e17b242c/<path>`.

| Contract | Verified function and exact source ranges | Relation to the Harness | What it does not establish |
|---|---|---|---|
| AscensionAccess | `contracts/ascension/AscensionAccess.sol:24–32,39–77`: role roots; canonical single-label registration; live ENS ownership or unexpired wrapped ownership; governor-set expiring admission; eligible combines both | Eligibility and separately controlled admission before optional token route | Scientific competence, independent verification, authority to every task or ownership of opportunity |
| NovaSeed | `contracts/ascension/NovaSeed.sol:25–44`: seals nonzero capsule/plan/evidence commitments, 1–128 jobs, bounded URI, optional parent currently owned by caller; ERC721 identity and immutable genome fields | Portable commitment/lineage reference and bounded mission plan | Capsule truth, encryption correctness, demand, completed work, profit, validity of inherited capability |
| AscensionRiskOracle | `contracts/ascension/AscensionRiskOracle.sol:53–110`: eligible validator stake; explicit job availability/capacity; marketplace locks; seven-day owner-bound review; distinct staked validators; risk/policy/evidence attestations; current green decision | Optional bounded risk/admission decision and reviewer capacity | An evidence hash is not independent scientific adjudication; role/address difference is not independent organizational control |
| AscensionJobMarket | `contracts/ascension/AscensionJobMarket.sol:92–254`: exact spec hash; bounded post/bid/award; 3 distinct reserved validators; current worker eligibility; result hash and URI; 2 votes pay/fail; deadlines, refunds and bond consequences | Optional task commitment, escrow, assignment, validation and settlement interface | Objective truth, market demand, profitable execution, semantics of a scientific result |
| AscensionMark | `contracts/ascension/AscensionMark.sol:52–145`: green owner opens bounded linear-curve lots; funding buy/sell/transfer; threshold bloom; exact Merkle leaf and index for job routing; collect refunds; close and pro-rata reclaim | Optional plan-restricted funding/treasury and capital-return interface | Ownership of an entire opportunity, guaranteed return, work quality or economic value |

Access roots are precisely `*.alpha.agi.eth` for Business, `*.alpha.agent.agi.eth` for Agent and `*.alpha.club.agi.eth` for Validator. These must not be conflated with other projects' ENS policies. `setAdmission` permits revocation (`until=0`) or a future expiry at most 365 days; live name ownership is checked separately.

NovaSeed's optional parent is a token ownership relation at sealing time. Its evidenceHash and planRoot are commitments. Descendant proof status and production authority are not encoded as automatically transferable goods by this function.

RiskOracle binds each vote to a round and current seed owner. `green` rechecks owner identity and every positive signer's eligibility. Withheld or false attestations are not resolved by hashing. The on-chain time/identity checks are real source functions; the local research instrument remains unconnected to live chain state.

JobMarket reserves three eligible reviewers and uses two votes for a terminal verdict. The source rejects agent/client and agent/committee conflicts at the address level. On approval, worker and the two approving validators receive the specified payout shares; `_payout` burns one percent of each gross payment. A failed submitted review quorum after the deadline refunds without classifying missing review as worker failure; late execution is a separate slashing branch. These are code-derived semantics, not a result of live settlement in this study.

AscensionToken, the shared base rather than a sixth user-facing suite entry, binds `Constants.AGIALPHA`, requires **18 decimals**, checks exact received and paid token balances, and verifies actual supply destruction for burns (`contracts/ascension/AscensionToken.sol:13–37`). No USDC balance conversion or generic asset support is present here.

## Cross-repository adapter boundaries

Jobs `docs/successor/DISCOVERY_LAB.md:5–18` describes the **AGIALPHA18** admission route. Manager's corresponding file describes **USDC6**. Both require an installed Alpha inspector and independently selected mission/source/evaluator context supplied by application code; imported JSON cannot choose trusted code. They preserve raw UTF-8 request bytes and distinguish logical commission, mission revision, stage and route. Synthetic mode uses zero currency caps, no submission, no external execution and no settlement authority. A receiver receipt is not fresh capability qualification.

Current-source receiver behavior is tied to exact catalog/pins; the existing accepted shared API history uses the earlier authentic Alpha history. Source-level availability of an inspector is not proof that a new Alpha 1.41 research artifact is admitted by installed Jobs or Manager. A scientific companion may emit an inert handoff proposal, but must report those connections NOT_RUN/UNSUPPORTED unless genuinely exercised through the permitted exact source profile.

Fleet main's `successor/docs/ARCHITECTURE.md` describes existing authenticated installed handoff, Studio/Companion/ComputeWorker execution, local Agent and Node roles, one-minute preparation tickets, idempotency reservations, STOP and policy drift checks, and restored public project data with authority none. Its `local-runtime/supervisor/successor.mjs` explicitly returns `authority:'none'`, `runAuthorized:false` and `independentReview:false` for relevant portable/internal operations. These are inspected source features, not acceptance of the separately held Discovery candidate or this paper's scientific adapter.

## Evidence-level labels for publication

1. **Source-derived:** actual frozen source inspection, functions, hashes and references. This audit supplies that level.
2. **Local execution:** code was actually run in the stated host environment with recorded input/output/cost and observed failure behavior. The research experiment must supply this independently.
3. **Installed-package execution:** genuine separately identified released artifact installed in isolation and used for the run. A source checkout on PYTHONPATH does not meet this label.
4. **Local EVM:** actual contract tests on a local emulator, with stated fixtures and simulated assets. This audit performed none.
5. **Read-only deployed observation:** pinned network, address, block and exact read result. Deployment files alone do not meet this label. This audit performed none.
6. **Real settlement:** observed authorized financial transaction and terminal receipt. None is requested or performed.

The paper's useful result can be a source-pinned local capability-construction experiment through released interfaces even while the cross-product installation and publication decisions remain held. Preserve this boundary prominently; do not make every contract or repository perform an unnecessary role simply to claim complete utilization.
