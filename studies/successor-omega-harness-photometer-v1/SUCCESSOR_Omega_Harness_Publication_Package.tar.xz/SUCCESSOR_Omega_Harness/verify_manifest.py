#!/usr/bin/env python3
"""Verify the archived publication payload without executing its experiments."""
import argparse
import hashlib
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    root = args.root.resolve()
    manifest = json.loads((root / 'MANIFEST.json').read_text())
    failures = []
    for entry in manifest['files']:
        path = (root / entry['path']).resolve()
        if not path.is_relative_to(root) or not path.is_file():
            failures.append({'path': entry['path'], 'reason': 'missing or unsafe path'})
            continue
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        if digest != entry['sha256'] or path.stat().st_size != entry['bytes']:
            failures.append({'path': entry['path'], 'reason': 'bytes differ', 'actual_sha256': digest})
    print(json.dumps({'verified': not failures, 'files_checked': len(manifest['files']),
                      'failures': failures, 'scope': 'Payload bytes, not scientific truth or current authority.'}, indent=2))
    raise SystemExit(bool(failures))


if __name__ == '__main__':
    main()
