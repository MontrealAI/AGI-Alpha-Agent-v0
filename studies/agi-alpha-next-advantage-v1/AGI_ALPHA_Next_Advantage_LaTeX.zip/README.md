# Build the Next Advantage — manuscript source

The manuscript is `AGI_ALPHA_Build_the_Next_Advantage.tex`. The delivered PDF is the checked original generated from this source and the accompanying vector figures.

Compile from this directory with XeLaTeX twice:

```sh
xelatex -interaction=nonstopmode -halt-on-error AGI_ALPHA_Build_the_Next_Advantage.tex
xelatex -interaction=nonstopmode -halt-on-error AGI_ALPHA_Build_the_Next_Advantage.tex
```

Tested with XeTeX/TeX Live 2023 on Debian. Required OpenType fonts are Nimbus Roman Regular/Bold/Italic/BoldItalic, Nimbus Sans Regular/Bold/Italic/BoldItalic (URW Base35), and DejaVu Sans Mono. The source names the OTF files explicitly to avoid ambiguous Type1 font resolution. Standard TeX packages include fontspec, amsmath, microtype, graphicx, booktabs, tabularx, longtable, xcolor, TikZ, enumitem, titlesec, fancyhdr, caption, tcolorbox, listings, xurl and hyperref.

The LaTeX source archive includes all figures needed for compilation. Regenerating scientific figures requires the complete research companion, because `make_figures.py` reads its original results and economics data; runtime versions and input/output hashes are in `figures/figure-manifest.json`.

Original research data and criteria are unchanged. `evidence/PDF_QA.json` records the exact PDF/TeX hashes, 23 rendered pages, resolved references, no overfull boxes and visual review. PDF timestamps can differ on a fresh compilation; numerical content and sources are the reproducibility target.
