# Ecosystem audit for Build the Next Advantage

Read-only source and coordination audit, 25 October 2026. This document distinguishes source inspection, owner-reported test results and execution performed for the new study. No held operation was retried, no public reference was changed, and no contract or financial action was invoked by this audit.

## Exact current identities

The GitHub connector's current-main and release API reads establish these identities. A release listing is not new installed qualification.

| Repository | Current main | Public release observed | Meaning |
|---|---|---|---|
| AGI-Alpha-Agent-v0 | `95d1e97d4d1c0aaebd592767fc5e5d2da56f6aa7`, tree `486fd7bbefc57f23defc7c24339aba591f04d91d` | `v1.43.0`, published 2026-10-25 01:19:36 UTC, 109 assets | Main includes passive Economic Engine publication after the public software baseline. |
| AGI-Fleet-Linux | `45759fb096faf8988f58ae5ea71248d0f35a97c7`, tree `71a0ab1f0d2784ba552d0126903bd31d60262313` | `v0.1.0-local-skills-preview.5` and `v1.1.4-qualification`, both prereleases | Held proposed integration is not main. |
| AGIJobsv0 | `bc4abbd5c28f3672275b13300e40ea26c820b8ee`, tree `009f11b81c554d80eeddda882c8f91f2e89c8b2e` | `discovery-v2.1.0-rc.21`, published 2026-10-24 20:16:42 UTC, 7 assets | Pre-release bounded native review/continuation scope. |
| AGIJobManager | `5d5670df9dbbc79da115e0a44b71989f34df58c1`, tree `c880b32db076bd7a1d41bf344a1cd7cf8ecef5bc` | `v1.20.2`, published 2026-10-24 22:39:29 UTC, 9 assets | Advertised Alpha v1.41 compatibility is not automatic compatibility with newer Alpha. |

Sources: [Alpha main](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/commit/95d1e97d4d1c0aaebd592767fc5e5d2da56f6aa7), [Alpha release](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/releases/tag/v1.43.0), [Fleet main](https://github.com/MontrealAI/AGI-Fleet-Linux/commit/45759fb096faf8988f58ae5ea71248d0f35a97c7), [Fleet release](https://github.com/MontrealAI/AGI-Fleet-Linux/releases/tag/v1.1.4-qualification), [Jobs release](https://github.com/MontrealAI/AGIJobsv0/releases/tag/discovery-v2.1.0-rc.21), [Manager release](https://github.com/MontrealAI/AGIJobManager/releases/tag/v1.20.2).

## Existing owners and active boundaries

[Issue #4850](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/issues/4850) remains the coordinating record. Its 368 available comments were preserved as `coordination-comments.json`. The latest read has the source-assurance owner continuing their existing branch; it does not delegate their release authority to this research team.

- **Source assurance and common cost contract:** #4907 now points to `1d46b4d553ac84b5da174a427961d7b34ae8e1fb`, tree `e32d12fc87c3b94576e07d184b778f572b5774ae`. It normally merges prior owner source `2b442458` and current main `95d1e97d`, retains all 22 publication records, and is open/mergeable, not merged. Its owner reports 205 local tests, three local requests covering 66 source identities, 928 separate Python checks, and 240 arithmetic checks. These are prior-owner observations, not newly reproduced study results. Fresh exact-source review/hosted acceptance is separate. [PR](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/pull/4907), [latest handoff](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/issues/4850#issuecomment-6402801490).
- **Planning/runtime/scanner/release:** #4899 remains `2645d1980c83cbf10f6f648c703fc7b846648274`, tree `6a61eac6ab48722d22b262984a3b97a7025705d4`. Its mandatory official scan refuses 56 findings/exit 1 with zero findings admitted; the exception map is absent. Code-review clearance is not separate Security clearance. No new study can clear that gate. [PR](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/pull/4899), [current-source packet](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/issues/4850#issuecomment-6401177482).
- **Harness:** #4863 `c455ad4ce109c86df2fef09d19674810290b5185` and dependent #4865 `6bb361d522d80dc900cc2a480014531c6a44b66e` remain open/unmerged. The original configured review has unresolved terminal status and a separate original merge denial lacks a source-specific disposition. A fresh reviewer or changed SHA cannot replace those decisions.
- **Fleet:** combined candidate `d0d4459b48a6cb45b0b6393be5099484ad8c6313` is proposed/unadopted. Original restricted review source `0b13d3ffb25381dc2ebf9c39abda24824660fd3b` and P1s 4322083594/4323870690 retain their original action/review owners. No retry or alternate review route is part of this audit.
- **Publication:** the existing integration/publisher owner retains catalog reconciliation, qualified merge, releases and served-byte checks. Paper-only source publication is distinct from a software demo. The owner reports the newly merged Economic Engine PDF still website-404 because current main is mixed software relative to public v1.43; its Git file exists. This historical HTTP observation is not a new check by this audit.

The exact action map is [comment 6386746278](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/issues/4850#issuecomment-6386746278). Authenticated browser-to-approved-executor source assurance, persistent worker operation after browser closure, network recovery and exact approved-profile clean installation remain **NOT RUN**. The latest owner's local Chromium socket-EPERM refusal was not retried or bypassed here.

## Reusable local execution seam

The released `examples/successor-workbench/engine.mjs` exposes `createWorkbench(adapters)` with an existing extension example. An installed adapter has:

```js
{manifest:{id,version,en,fr,scope,artifact}, validate(input), execute(input,checkpoint)}
```

The returned workbench exposes `validate`, `run`, `plan`, and `inspectPack`. It uses the existing canonical source/mission identity, bounded checkpoint/cancellation mechanism, artifact hashes and seven-package unfunded AGI Jobs compilation. No second runtime, scheduler or journal is needed. New research can register an exact, locally reviewed adapter through this seam and report `PUBLIC_LOCAL_EXECUTION`, `independentProof:false`, `admission:HOLD`, `settlement:NOT_CONNECTED` truthfully. These are fixed existing output labels.

Important limitation: `inspectPack` checks schema, mission/hash/source bindings, artifact bounds and reconstructed job compilation. It is **not a complete independent semantic verifier** of the adapter's answers. Fresh scientific acceptance must separately recompute the deliverable's required semantics.

Sources: [workbench engine](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/blob/95d1e97d4d1c0aaebd592767fc5e5d2da56f6aa7/examples/successor-workbench/engine.mjs), [installed adapter example](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/blob/95d1e97d4d1c0aaebd592767fc5e5d2da56f6aa7/examples/successor-workbench/extension.mjs).

## Candidate foundations and unresolved limitation

| Foundation | What the inspected implementation does | Limitation relevant to a next experiment |
|---|---|---|
| Source assurance #4907 | Exact approved public Git manifest → declared/observed inventory, full differences, actions CSV, workspace, report and durable completion; 1–128 ordinary committed files; v3 expiry, lifetime reservations, CANCEL, STOP and stale-writer recovery. | Verifies file identities, not source behavior/security. Existing full-service comparison uses the incumbent exact-key/hash specialist. Current improvements were human-authored safety engineering, not autonomous capability construction. |
| TI guide | Existing CSV parser, exact join and discrepancy grouping; complete differences and action plan; source-bound portable workspace. | Only non-key columns with identical names are compared. Same semantics with different headers remain unshared. README expressly proposes explicit column mapping as a next useful improvement. |
| AWE quote comparison | Canonical item/offer objects; exact pack rounding, rational FX, deadlines and one-time supplier shipping; retained vendor-subset solver plus conventional MILP. | Canonical input schema is assumed. v1/v2 capabilities are emitted from fixed authored source strings. Emitting v2 after scope refusal adopts existing methods; autonomous discovery remains NOT RUN. |
| Planning/strategy worker | Bounded release plans, changes and repair; fixed grammar construction; retained specialist and independent Python checks; delivery versus improvement accounting. | Optional improvement was more expensive in the current measured six-job comparison, and constructed repair lost to the specialist. Existing runtime/security scope is held; the study should not use an alternative to bypass it. |

### Assessment of evidence-derived schema adapters

A bounded learner that derives an executable column/value transformation from mission examples addresses a documented gap without replacing the working comparison or quote optimizer. This would be an advance over AWE's preauthored capsule emission if the actual program is selected from examples and recorded without hand insertion after results. Appropriate claim: **program synthesis/adaptation within a declared grammar**, not algorithmic invention or open-ended autonomous research.

The meaningful deliverable is the complete checked comparison/quote package, with original-to-normalized provenance and refusal on ambiguity. Count ambiguity refusals separately from successful useful outputs. Preserve all duplicate-key multiplicities, original row identities and exact-value semantics unless a separately explicit normalization contract authorizes a change. Equal columns in development, unit/currency ambiguity, key collision after normalization, unseen malformed formats and mixed headers should not silently become accepted outputs.

Freeze task-family splits and construction/evaluation criteria before outcomes. Hold out whole schema/format families for a builder-transfer test, not only new rows from familiar formats. Ordinary scripts/caching, an equal-information bounded program-synthesis builder and the capable agent must receive the same examples, permitted primitives and resource opportunity. A conventional builder tie is evidence that the capability is reusable, not a unique Flywheel advantage. Keep preparation, verification, failures, artifact packaging and future maintenance in cost comparisons.

Sources: [TI guide README](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/blob/95d1e97d4d1c0aaebd592767fc5e5d2da56f6aa7/examples/ti-guide/README.md); [AWE archive guide](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/blob/3d27c18362ed8db90dca4e6b85589865712bdbc5/studies/agi-alpha-autonomous-work-economy-v1/README.md); extracted AWE `implementation/adapters.mjs`, `implementation/capability-sequence.mjs`, `extension/run.mjs`; [planning worker](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/blob/95d1e97d4d1c0aaebd592767fc5e5d2da56f6aa7/contrib/strategy_succession/worker/README.md).

## Shared accounting contract: reuse, do not replace

The #4907 owner source contains `examples/successor-alpha/automated-costs.mjs` (Git blob `91da2937ba129793b21652f68560e8bd4aa32f56`). Its `inspectAutomatedCosts` / `evaluateAutomatedCosts` API validates `alpha-automated-costs/v1`: precisely base/conservative/stress scenarios, eight operation stages, fact objects with measured/sourced/estimated/unknown provenance, money in integer micros, failure/attempt burden, residual attention, monthly costs and finite setup/development amortization. Unknowns remain null. Marginal accepted-output cost, recurring cost and fully loaded cost are separate.

`shadow-ledger.mjs` owns `alpha-shadow-ledger/v1`. `planMission`, `appendEvent`, `replayLedger` and `calculateInvestment` separate observed collections from assumed price, delivery/business/capability/maintenance costs, obligations and reliability reserves. Customer attention is a buyer opportunity cost, not automatically provider cash cost. Cash projections must not double-charge amortized construction plus the same cash investment. Scenario receipts cannot become observed earnings.

Sources: [cost specification](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/blob/1d46b4d553ac84b5da174a427961d7b34ae8e1fb/examples/successor-alpha/automated-costs.md), [ledger specification](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/blob/1d46b4d553ac84b5da174a427961d7b34ae8e1fb/examples/successor-alpha/SHADOW_LEDGER.md).

## Verified currency and ecosystem roles

Source inspection does not verify current deployed settings. No RPC or signing was done.

- Manager's `JobSettlement.complete` pays 30% and 10% recipients, the snapshotted validator budget and remaining agent reward through USDC accounting; failed transfers become claims. No automatic AGIALPHA conversion/buyback follows a USDC job.
- Jobs v0 `FeePool` binds immutable AGIALPHA, receives accounted fees, applies configured burns and distributes fees to eligible stakers. Conditional staker rewards are not a universal passive-holder right or enterprise-profit distribution.
- Alpha `runtime/chain.py` verifies configured invoice-linked AGIALPHA transfer receipts and records an earmark with `reinvestment_executed: false`. An earmark on a transfer is not reconciled surplus or an actual investment.
- Fleet's current `local-runtime/project/transfer.mjs` maps `manager-usdc` to USDC and `agijobsv0-jobregistry-v2` to AGIALPHA; results explicitly remain `authority:none`, `productionQualified:false`, `independentReview:false`, `settlement:not-connected`.
- The new research can actually use Alpha Workbench and its unfunded Jobs compilation. Fleet/Harness can be accurately represented as inspected, held receiving interfaces without executing unnecessary token transactions or claiming integration that has not run.

Sources: [Manager settlement](https://github.com/MontrealAI/AGIJobManager/blob/5d5670df9dbbc79da115e0a44b71989f34df58c1/contracts/utils/JobSettlement.sol), [Jobs FeePool](https://github.com/MontrealAI/AGIJobsv0/blob/bc4abbd5c28f3672275b13300e40ea26c820b8ee/contracts/v2/FeePool.sol), [Alpha receipt accounting](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/blob/95d1e97d4d1c0aaebd592767fc5e5d2da56f6aa7/alpha_factory_v1/core/runtime/chain.py), [Fleet route implementation](https://github.com/MontrealAI/AGI-Fleet-Linux/blob/45759fb096faf8988f58ae5ea71248d0f35a97c7/local-runtime/project/transfer.mjs), [full prior-owner token map](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/blob/1d46b4d553ac84b5da174a427961d7b34ae8e1fb/contrib/productive-capability-ledger/TOKEN_BOUNDARIES.md).
