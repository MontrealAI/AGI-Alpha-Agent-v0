# Auxiliary resource reporting amendment, v1.1

After the frozen economic run, review identified that `resourceMeasures()` in
the original `analyze.mjs` summed construction, production and verification CPU
while omitting the separately recorded packaging CPU. The descriptive name
`allAttemptCpuMs` also overstated its scope: Python verifier process-startup CPU
is not instrumented. The recorded verification wall span does cover process
launch.

The original frozen source and `results-v1` output are preserved unchanged.
`resource-report-v1.1.mjs` produces the additive `resources-v1.1.json` report from
the same immutable metric input. It adds the four recorded CPU spans, names the
quantity `recordedCpuMs`, and explicitly leaves complete execution CPU and
actual billing unknown. It also retains the four wall spans and their total.
Its illustrative CPU-price proration covers only recorded CPU and is not an
observed cost or a basis for capability promotion.

```sh
node economics/resource-report-v1.1.mjs --results economics/results-v1 --out economics/resources-v1.1.json
```

This is an auxiliary reporting correction discovered after results, not a
change to frozen acceptance criteria, assumptions, query counts, comparisons,
quality outcomes, cost tiers or financing paths. The economic scenario's
whole-session allowance already covers packaging and the complete verification
subprocess wall scope. Therefore all primary economic results remain exactly
as recorded in `results-v1`.

For publication, use `resources-v1.1.json` for CPU descriptions, and cite this
amendment when describing the preservation of prior outputs. Do not use the
original `allAttemptCpuMs` or `illustrativeProratedComputeUSD` fields as complete
resource or billing measurements.
