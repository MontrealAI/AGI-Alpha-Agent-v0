# Prospective economic analysis protocol

Version 1, written before any confirmatory outcome analysis. This protocol and
`assumptions.json` must be frozen with the study. Changes after that freeze require
an additive amendment; retain previous source, assumptions and outputs.

## A. Human-work economics

The output is a complete, independently checked quote-comparison report produced
from a permitted structured supplier export. Human duration at equivalent quality
is unknown. Primary tables report break-even minutes separately at USD36.73/hour
private office/administrative employer compensation, USD73.69/hour professional
employer compensation (June 2026 ECEC), and USD24.32/hour procurement-clerk median
wages (May 2025 OEWS, excluding benefits). Do not conflate these populations or
add benefits twice. Customer price plus customer attention is a distinct comparison
from enterprise resource cost. No market-size or observed savings claim is planned.

Use the unchanged `alpha-automated-costs/v1` implementation. Report execution-only
automated operating charges, shared marginal cost including residual human work,
recurring delivery, and fully loaded cost at declared monthly volume, utilization,
acceptance and amortization. All eight stages remain charged or explicitly
allocated to a paid shared runtime session. Model billing, authoring and original
setup are unknown actual values; nonzero assumed authoring/setup allowances appear
in the conditional model, without changing that unknown observed record.

The finite experiment's measured label queries are inputs to a conditional row-label
acquisition cost: reviewed example preparation minutes are assumptions. The labels
are synthetic oracle outputs in the experiment, not an observed human service.
Candidate evaluations, rejected constructions and their CPU/wall time remain in
the metrics. Runtime-session allowances cover every evaluated and rejected
candidate within the declared resource cap; they are not free omitted failures.
Compute-time prorating is a separate illustrative sensitivity, never an observed
invoice or substitute for the complete session price.

## B. Incremental Flywheel benefit

Import arm-level mission, acceptance/refusal/incorrect-acceptance, construction,
label-query, candidate-evaluation and CPU/wall counts from the frozen experiment.
Per-request label burden is total queried examples divided by all attempted
missions, including unsuccessful constructions. Repeated use is exactly the
declared four missions per held-out schema, not unlimited free reuse. Charge the
retained recipe's development-label acquisition and complete training execution
as additional development investment; maintenance and useful life are assumptions.

Show every arm, including ordinary reuse and active specialist. A capable current
LLM arm can have measured outcomes, but unexposed model tokens/billing stay unknown.
It cannot receive a zero-price model call or establish a matched-dollar advantage.
Complete observed costs remain unknown for every arm. The supplied cost model is
an assumption sensitivity, not an operational promotion. Compare complete bundles
at equivalent acceptance, retaining coverage and failures. A lower label count
with lower coverage or an incorrect acceptance is not a qualified saving.

For labels, show exact break-even acquisition minutes needed to repay added
training/setup expense at the tested reuse horizon; if the retained method uses
no fewer labels than the strongest complete incumbent, report no finite positive
label-time threshold. Unknown costs retain HOLD. Better task execution, better
construction and sustained acceleration remain separate verdicts.

## C. Financeable succession

Use the unchanged `alpha-shadow-ledger/v1` and `calculateInvestment` functions.
All actual collected-revenue entries remain unknown. The schema only permits an
`observed` collected category, so simulated receipts MUST NOT be entered there.
The scenario channel's `price` events represent explicitly labeled assumed
collection-adjusted face prices for matured simulated cohorts. An adjacent plain
projection table retains face invoices, pending receivables, simulated collections,
refunds, fees, external seed, period costs and cash conservation; it is a projection
of the existing ledger, not a replacement accounting contract. Every revenue
reference names this mapping. Enterprise observed surplus remains unknown.

The wrapper pays setup once in cash. It uses recurring costs and period capability
spending thereafter; it must not also cash-charge the amortization used in the
fully loaded unit table. Customer attention is opportunity cost for the buyer and
does not become a supplier cash charge. Reserve/obligation balances constrain
spendable cash and are not double-counted as costs. Uncollected invoices, external
seed, token issuance and customer savings never count as earned available funds.

Simulate six prespecified cases: conditional successful construction with delayed
benefit, adverse low demand, paid construction that fails, zero-saving rejection,
large reserves/obligations that prevent investment, and delayed collection/payback.
All use an explicitly hypothetical next capability; scenario success is not evidence
that the study constructed that future capability. Include 0/25/50/75/100 percent
allocation ceilings, never an automatic spending target. Admit a scenario purchase
only when collected and recovered scenario surplus, cash after protected balances,
finite-horizon payback, resource capacity and the ceiling all permit it. Retain idle
allocations and rejection reasons. Benefits start only after the declared delay;
all failed construction, verification, maintenance and original setup remain paid.

Expected-state demand and acceptance calculations are deterministic sensitivities,
not probability distributions or liquidity guarantees. The finite horizon gives no
salvage credit. Stop unaffordable new work; future fixed costs are explicitly
assumed suspendible, and outstanding liabilities remain protected. No financial
transaction or production authority is exercised.

## Reproduction and independence

`node economics/analyze.mjs --metrics <metrics.json> --out <new-directory>` will
validate exact vendor hashes, build native shared records and retain all outcomes.
Output directories must be new. No outcome analysis is run until the study freeze
and parent GO. API/syntax checks and schema validation of unknown records are
allowed before the freeze. Source and review agents share supervising context;
this is internal computational independence, not external peer review.
