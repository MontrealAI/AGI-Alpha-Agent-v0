# Economic adapter and financing projections

This directory reuses the exact existing Alpha cost and shadow-ledger modules at
`../vendor/shared/`. `SOURCE_PROVENANCE.json` binds their source commit and hashes.
The modules are unchanged. No new account, payment instruction, runtime, scheduler,
or accounting schema is introduced.

Read `PROTOCOL.md` and `assumptions.json` before interpreting any output. The former
was written before confirmatory analysis; the latter supplies transparent source
rates and scenario choices. Actual whole-organization cost, matched human duration,
LLM billing and customer collections remain unknown.

## Commands

An API/schema check performs no study outcome analysis:

```sh
node economics/analyze.mjs --protocol-check
```

After the experiment and economic protocol are frozen and execution is authorized:

```sh
node economics/analyze.mjs --metrics results/metrics.json --out economics/results-v1
```

The output directory must not exist. A second reproduction requires another new
directory, preserving the first. The only dependency is Node's standard library and
the two exact shared modules. Vendor digest mismatches refuse execution.

Expected metrics contain `arms.NAME` with integer `missions`, `accepted`, `refused`,
`incorrectAccepted`, `constructions`, `labelQueries`, `candidateEvaluations` and
measured CPU/wall fields. Retained-recipe development counts are under
`meta.training.labelQueries`; missing training cost propagates to unknown rather
than zero. Arms whose name includes `retained` or `meta` are charged the extra
retained construction; `llm` names retain unknown inference expense. Name matching
is interface mapping, not retrospective selection of favorable outcomes.

## Output interpretation

- `observed-cost-records.json`: native `alpha-automated-costs/v1` records with actual
  unknown monetary inputs preserved. The corresponding whole-cost outcomes are null.
- `modeled-cost-records.json` and `native-cost-summaries.json`: unchanged native
  validator/calculator inputs and outputs. All assumptions retain provenance.
- `observed-ledgers.json`: native shadow ledgers. No simulated proceeds enter the
  observed channel, so observed available surplus stays null.
- `summary.json`: separate A human-threshold, B incremental-construction and C
  conditional-financing conclusions. Neither an assumed low price nor fixture
  acceptance establishes real demand, equivalent human quality or measured profit.
- `finance-projections.json`: explicit invoice, collection, expense, reserve,
  obligation, capital and cash traces with conservation checks. Simulated candidate
  costs and gains describe a proposed future capability, not a newly observed
  success. A rejected or unaffordable candidate may leave funds idle.
- `finance-native-ledgers.json`: each period projected through the existing native
  shadow ledger. Since its collected category only admits observed evidence, the
  assumed scenario price represents the matured cohort's collection-adjusted face
  price. References declare this mapping; face invoices and pending receivables are
  distinct in the adjacent projection. No fake observed receipt is created.
- `REPRODUCTION.json` and `metrics-input.json`: input and source identities.

The shared marginal tier includes expected example acquisition and residual
human exceptions. The narrower execution-only column includes the charged automatic
operations. Recurring/full tiers add shared upkeep and amortized construction once.
Additional retained recipe-building integration, labels, failed proposals, training
session and maintenance are charged prospectively. Complete original development
cost is still unmetered, so conditional calculations cannot clear promotion HOLD.

Customer attention appears only in buyer/resource comparisons. Supplier operating
cash does not inherit a customer opportunity-cost expense. Setup is paid once in
cash and is not paid again as amortization. Source wages are prices for labor,
not durations, whole-job prices or guarantees that a worker did not use AI.

Financial paths are mean-state, finite-horizon scenarios. Each keeps the failed
construction component, applies benefit delay, tests time/cash/payback, and carries
uncollected invoices. Initial seed never contributes to earned surplus. Future
fixed commitments are assumed suspendible; tail-risk and notice liabilities are
not measured. No token issuance or speculative appreciation contributes revenue.
