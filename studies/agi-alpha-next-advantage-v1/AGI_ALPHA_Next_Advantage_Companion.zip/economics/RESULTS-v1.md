# Economic results: Build the Next Advantage

## Verdict for the paper

The new implementation establishes useful computational behavior, but it does not establish an observed dollar saving or a financeable autonomous enterprise. All four deterministic methods delivered 96 independently checked reports. Ordinary schema reuse reduced example queries from 244 to 61; the retained construction recipe reduced them to 29, exactly matching the active specialist. The retained method additionally required 31 development examples and method-specific engineering and maintenance. The strongest incumbent is therefore retained for the modeled operating configuration. The learned recipe is not economically promoted.

The human-work comparison is a transparent threshold analysis. Under the base assumptions, the active specialist's fully loaded modeled provider cost is **$1.211784 per accepted report**; with three assumed minutes of customer attention, complete modeled resource cost corresponds to **4.9795 minutes of office/administrative work** at the sourced $36.73 hourly employer-compensation rate. This is a threshold to investigate, not evidence that the matched human task takes that long. At a separately assumed $15 customer price, the buyer's break-even threshold is **27.5031 human minutes**, including the same attention. Provider cost and customer price answer different questions.

The nontransactional financing study tests a **hypothetical future capability**, not benefits demonstrated by the retained recipe. It finds feasible and infeasible regions without selecting a favorable allocation percentage: four of five allocation ceilings fund the conditional-success case; all low-demand, zero-saving, delayed-collection and protected-balance paths reject or defer construction. Paid failed construction loses its complete $422.17 cost. Actual collections, actual fully loaded cost, actual matched human duration and observed available enterprise surplus remain unknown throughout.

## Evidence and reproducibility

The frozen economic analyzer was run only after the study freeze and parent authorization:

```sh
node economics/analyze.mjs --metrics results/metrics.json --out economics/results-v1
python economics/audit_results.py --results economics/results-v1 --out economics/results-audit-v1.json
```

The first command writes immutable analysis inputs and outputs to a new directory. The second performs an independent Python rational-arithmetic and conservation audit of those outputs. It imports neither JavaScript accounting implementation, and it does not substitute a new ledger. All 12 cost rows, all 30 financial paths and all 360 monthly ledger snapshots passed. This computational review shares the supervising research session; it is not external peer review.

| Record | SHA-256 |
|---|---|
| Input metrics | `5f8ada6678eec037432bc0f9856c9031b49592398eb9cf4d1feb8d7b9c0f2009` |
| Frozen economic analyzer | `d6dff2b1c247ef76af3639bb524175702b4adfedb31a02d721b6692a5d082ab3` |
| Frozen assumptions | `f23929d76f5dbdf6f300a3e1e32dc45835994b4ec10932a4be6c4e07deb33776` |
| Frozen economic protocol | `28b3bab23e4b8d8a25291399d8292eeb05a47af533722aeb41909f5f2f1240a7` |
| Canonical automated costs | `0dfca3ae4e7ef1d17bc78521f91917ef068280cf832d3565c354de2085c52506` |
| Canonical shadow ledger | `cdc7c5a73593050a9af79b54589462e27f61b868e88ca6985d5cb639f3066d21` |

All reported figures below come from `results-v1/summary.json`, `native-cost-summaries.json` or `finance-projections.json`. The exact shared schema records are retained in `modeled-cost-records.json`, `observed-cost-records.json`, `finance-native-ledgers.json` and `observed-ledgers.json`. The audit receipt is `results-audit-v1.json`. The current LLM comparator is not part of this immutable four-arm economic input; any later supplemented analysis must use a new input and output directory. Unexposed LLM billing propagates as unknown, not zero.

An additive auxiliary resource-reporting correction is preserved in `RESOURCE_REPORTING_AMENDMENT-v1.1.md` and `resources-v1.1.json`. The original descriptive CPU total omitted packaging and overstated its completeness. The corrected report includes all four recorded CPU spans while leaving complete CPU unknown because Python process-startup CPU is unmeasured. The whole-session cost allowance already covered packaging and subprocess verification wall time; no acceptance, query, economic or financing result changes, and the frozen original analyzer and output remain untouched.

## What is measured, sourced and assumed

**Measured:** 96 accepted reports per deterministic arm; zero incorrect acceptances; construction, synthetic example-query and candidate-evaluation counts; local recorded wall and CPU spans; 31 training example queries. The three retained development executions made 93 query calls in total and consumed 49.312 ms recorded CPU. They repeat one 12-schema training episode: 31 unique required example queries, not 93 independent examples or three independent successes. Repeated engineering validation is covered by the nonzero modeled setup allowance; its actual billed resources and human attention remain unmeasured.

**Sourced:** BLS June 2026 private-industry office/administrative total compensation of $36.73/h and professional/related total compensation of $73.69/h; BLS May 2025 procurement-clerk median wage of $24.32/h. The third rate excludes benefits and must not be presented as the same cost concept. Source snapshots are in `audit/labor_snapshot_2026-10-25.json` and the lineage audit. Primary URLs are [the archived September 9, 2026 ECEC release](https://www.bls.gov/news.release/archives/ecec_09092026.htm), [ECEC Table 4](https://www.bls.gov/news.release/ecec.t04.htm) and [OEWS Table 1](https://www.bls.gov/news.release/ocwage.t01.htm). These sources do not provide a matched duration for this complete deliverable.

**Assumed:** operational demand and acceptance; human minutes per equivalent reviewed example; operator exception rates; all session, platform, maintenance, setup and authoring allowances; useful lifetimes; customer attention and prices; all future sales, collections, financing and capability benefits. The scenario names base/conservative/stress identify prespecified combinations, not measured confidence bounds or an estimated probability distribution.

### Cost-model assumptions

| Input | Base | Conservative | Stress |
|---|---:|---:|---:|
| Provisioned capacity, requests/month | 1,000 | 1,000 | 1,000 |
| Utilization | 50% | 10% | 1% |
| Requested deliveries/month | 500 | 100 | 10 |
| Operational acceptance assumption | 98% | 90% | 65% |
| Expected accepted deliveries/month | 490 | 90 | 6.5 |
| Attempts/request, including retries | 1.02 | 1.15 | 1.50 |
| Full runtime-session allowance/attempt | $0.03 | $0.10 | $0.30 |
| Equivalent reviewed-example minutes | 2 | 5 | 10 |
| Operator exception assumption | 1% × 10 min | 5% × 20 min | 20% × 45 min |
| Platform/archive/monitoring per month | $60 | $120 | $180 |
| Maintenance minutes/month at $73.69/h | 120 | 360 | 960 |
| Business minutes/month at $36.73/h | 60 | 180 | 480 |
| Common setup engineering/review minutes | 960 / 240 | 2,400 / 480 | 4,800 / 960 |
| Setup model-authoring allowance | $100 | $300 | $1,000 |
| Total common setup | $1,425.96 | $3,541.44 | $7,482.88 |
| Setup amortization, months | 12 | 6 | 3 |
| Retained-only extra engineering minutes | 30 | 120 | 480 |
| Retained-only extra upkeep minutes/month | 5 | 20 | 60 |
| Retained recipe lifetime, months | 6 | 3 | 1 |
| Customer attention minutes/accepted report | 3 | 5 | 15 |

The whole-session allowance covers the complete runtime and verification subprocess wall time; it is not a CPU-only price. It is allocated once across preparation 15%, planning 5%, execution 20%, verification 25%, correction 10%, packaging 10%, reporting 5% and recovery 10%. These are accounting allocations, not measured stage tariffs. Failed bounded search and candidate verification are inside the session; retries and operator exceptions are charged explicitly. Original authoring and validation are included through assumed engineering/review/model allowances. Actual full cost remains unknown.

Synthetic queries are converted to a hypothetical equivalent human example-preparation workload at `queries / 96 requests`. This extrapolates the study mix of four missions per new schema. It does not assume that identical already-cached schemas require new examples forever. Different rates of new-schema arrival, schema reuse or schema drift would change the economics and must be modeled explicitly.

### Exact cost tiers

The unchanged `alpha-automated-costs/v1` implementation calculates costs in integer micro-dollars with exact rational intermediates and upward rounding. Let `q` be requests/month, `a` the operational accepted fraction, `x` whole-session and residual human expense/request, `F` shared expense/month and `I/L` amortized setup and development expense/month. Then marginal cost is `x/a`, recurring cost `(q x + F)/(q a)`, and fully loaded cost `(q x + F + Σ I/L)/(q a)`. Execution-only includes automated sessions before residual human work. The tiers are cumulative and must not be added together.

| Arm | Scenario | Execution-only | Shared marginal | Recurring delivery | Fully loaded |
|---|---|---:|---:|---:|---:|
| Active specialist | Base | $0.031225 | $0.471090 | $0.969274 | $1.211784 |
| Ordinary reuse | Base | $0.031225 | $0.887530 | $1.385714 | $1.628224 |
| Rebuild | Base | $0.031225 | $3.269046 | $3.767229 | $4.009740 |
| Retained recipe | Base | $0.031225 | $0.471090 | $0.981806 | $1.249769 |
| Active specialist | Conservative | $0.127778 | $1.835329 | $9.305662 | $15.863884 |
| Ordinary reuse | Conservative | $0.127778 | $2.968970 | $10.439303 | $16.997525 |
| Rebuild | Conservative | $0.127778 | $9.451985 | $16.922318 | $23.480540 |
| Retained recipe | Conservative | $0.127778 | $1.835329 | $9.578588 | $17.034461 |
| Active specialist | Stress | $0.692308 | $12.013474 | $266.302704 | $650.040140 |
| Ordinary reuse | Stress | $0.692308 | $15.152787 | $269.442018 | $653.179453 |
| Rebuild | Stress | $0.692308 | $33.105752 | $287.394982 | $671.132418 |
| Retained recipe | Stress | $0.692308 | $12.013474 | $277.639628 | $781.314243 |

The active specialist is the least costly complete method in all three specified models. Low utilization and short capital recovery cause the stress case to be expensive despite cheap execution. The base model's favorable cost level is therefore conditional on utilization, workload mix, preparation effort and recovery assumptions, not a measured service price. Tiny recorded CPU differences do not change the modeled whole-session bill and do not justify promotion.

## A. Human-work economics

For the active specialist, human-duration break-even thresholds for **fully loaded provider resource cost** are:

| Scenario | Office/admin compensation, $36.73/h | Professional compensation, $73.69/h | Procurement wage only, $24.32/h |
|---|---:|---:|---:|
| Base | 1.980 min | 0.987 min | 2.990 min |
| Conservative | 25.914 min | 12.917 min | 39.138 min |
| Stress | 1,061.868 min | 529.277 min | 1,603.717 min |

Adding customer attention valued at $36.73/h gives base total-resource thresholds of 4.980, 2.482 and 7.520 minutes respectively. Customer attention stays outside provider costs. For a buyer, substitute a quoted price for provider cost: the base $15-price threshold is 27.503 min at the office/admin rate, 13.709 min at the professional rate, or 41.537 min at the procurement wage-only rate. Prices $1, $5, $15 and $50 are all retained in the machine-readable sensitivity table. No price is asserted to be observed, optimal or collectable.

No measured matched human duration is available. Consequently the defensible statement is that the executable service exposes a promising threshold under certain assumptions, while the existence and magnitude of actual equivalent-work savings remain unestablished.

## B. Incremental Flywheel benefit

| Comparator to retained | Production queries avoided | Retained training queries | Net queries avoided after training | Base additional nonlabel recipe cost over tested horizon | Break-even human minutes per equivalent example |
|---|---:|---:|---:|---:|---:|
| Active specialist | 0 | 31 | −31 | $43.015834 | No finite positive threshold |
| Ordinary reuse | 32 | 31 | 1 | $43.015834 | 70.268 |
| Rebuild | 215 | 31 | 184 | $43.015834 | 0.382 |

All comparisons preserve 96/96 accepted reports and zero incorrect acceptances. The base nonlabel recipe cost includes one $0.03 session, 30 engineering minutes at $73.69/h and one month's five-minute extra upkeep. At two assumed minutes/example, retained-versus-ordinary production labels have $39.178667 opportunity value; development labels cost $37.954333, leaving $1.224333 before the $43.015834 extra nonlabel cost. The tested-horizon conditional net is therefore approximately **−$41.79**. Against the active specialist it is approximately **−$80.97**. None is a measured monetary loss or saving.

The lower retained-versus-ordinary *amortized monthly* base unit cost above depends on extending the observed workload rate over a much larger assumed future volume and useful lifetime. It must not be used to claim that the observed 96-report episode repaid construction. The active specialist remains better in either presentation. Conservative break-even example time against ordinary reuse is 281.040 minutes; the stress case would need ten months to process the tested workload but assumes a one-month recipe life, so it cannot support that transfer calculation.

Ordinary reuse is commercially useful. The learned selection rule has evidence of transfer over an ordinary sequential query policy; it does not beat the established active selector on the primary resource measure. One retained training episode and repeated execution cannot establish sustained acceleration. The complete-cost promotion decision remains HOLD, and the modeling choice is to keep the active specialist.

## C. Financeable succession

All 30 paths are explicitly simulated, with a 12-month horizon and allocation ceilings 0%, 25%, 50%, 75% and 100%. Their common assumptions include $5,000 external seed; $15 price per accepted report; 95% collection, 2% refunds and 3% plus $0.30 collection processing; $500 reserve and $100 obligations; a finite construction time budget of 480 minutes/month. The usual monthly demand is 300 requested reports and the operational accepted fraction is 98%, giving 294 expected reports. Low demand is ten requests/month. Fixed costs are assumed suspendible if work is halted.

The active specialist's $1,425.96 setup is paid once in cash. Subsequent cash expense uses recurring operating expense; it does not charge amortization again. At 300 requested reports this is $382.62/month before the proposed improvement. The unit-cost table above uses 500 requested reports, so its fixed-cost denominator must not be copied unchanged into the financing path.

The future capability package costs **$422.17**, including **$336.69** proposed construction and **$85.48** prior failed construction. It consumes 387 assumed construction/review/example-preparation minutes. Conditional benefit is $0.50 per accepted reuse and maintenance is $0.20, so it needs **1,408 reuses** to repay its complete fixed cost. These inputs describe a hypothetical capability whose outcome is supplied by the scenario. They do not describe a demonstrated new gain from the retained recipe.

| Prespecified case | 0% ceiling | 25% ceiling | 50%, 75%, 100% ceilings | Net capability benefit at month 12 |
|---|---|---|---|---:|
| Conditional success, one-month collections delay and two-month benefit delay | No construction | Construct month 3; first benefit month 6; pay back month 10 | Construct month 2; first benefit month 5; pay back month 9 | $0 / $195.23 / $283.43 |
| Adverse demand, ten requests/month | No construction | No construction | No construction | $0; provider operation still loses money |
| Failed capability | No construction | Construct month 3; fail; no benefit | Construct month 2; fail; no benefit | $0 / −$422.17 / −$422.17 |
| Zero saving | No construction | No construction | No construction | $0 |
| Protected reserve $4,000 plus obligations $500 | Startup refused | Startup refused | Startup refused | $0 |
| Four-month collections delay and three-month benefit delay | No construction | No construction | No construction | $0 |

In the successful case, month 2 has $1,105.03 earned scenario surplus after complete paid costs and protected balances. The minimum allocation ceiling needed for construction then is 38.21%, so 50–100% constructs and 25% waits until month 3. This threshold is a consequence of the inputs, not a prescribed reinvestment ratio. Higher ceilings do not cause unnecessary extra construction.

In the delayed-collection case, the first four months have no collected scenario surplus even though projected future value could initially repay construction. By month 5, only 1,176 feasible reuses remain, below the 1,408 threshold; by month 6 there is earned surplus, but too little time remains. The window of economic value and the window of available funds do not overlap. In the low-demand case, final cash is $2,017.74 from the $5,000 external seed, with $147 still receivable: solvent within the assumed horizon does not mean profitable. In the protected-balance case, only $500 is spendable, below the $1,425.96 setup, so no operation starts.

The native ledger's observed `collected` entries stay null. Its assumed scenario-price entries hold explicitly labeled collection-adjusted face prices of matured hypothetical invoice cohorts; adjacent projection rows separately retain face invoices, receivables, gross collections, write-offs, refunds and fees. External seed never enters earned surplus; customer savings never enter provider revenue. Each period conserves cash and receivables, and preserves reserves and obligations. No simulated payment clears a production or authorization gate.

## Suggested figures and exact data

1. **Capability acquisition:** show production queries 244/61/29/29 for rebuild, ordinary reuse, retained and active specialist; add a visibly separate 31-example training segment only to retained. Display 96/96 quality above every arm. This makes the active tie and training burden immediately visible. Engineering reruns belong in an annotation, not as independent samples.
2. **Full cost, not just execution:** stack incremental components (execution; additional human preparation/exceptions; additional recurring overhead; additional capital recovery) for the four arms under base assumptions. Use a separate small panel or logarithmic plot for conservative/stress full costs. Do not stack the cumulative tier values themselves. Mark every monetary axis “modeled USD.”
3. **Financing windows:** use the 50% conditional-success and delayed-collection paths. Show available scenario surplus and remaining feasible reuses relative to the $422.17 construction and 1,408-reuse thresholds, with a separate net-capability-benefit panel. Label all panels “simulation; hypothetical future capability.” A 6-by-5 decision table can compactly show all cases and ceilings.
4. **Human threshold sensitivity:** show base/conservative/stress minutes at the three explicitly different labor bases, with a separate customer-price/attention view. A comparison of provider expense alone must not be titled customer savings.

`figure-data-v1.json` contains table-ready cost increments, label counts, thresholds and all monthly financing traces with their status labels. For primary statistical intervals on query differences, use the root's frozen stratified-family bootstrap output, not these descriptive economic tables.

## Remaining limitations and precise status

The schema workload is generated and scoped. Acceptance on its 96 cases is not production demand, acceptance probability, user willingness to pay or a measured human-time replacement. Costs vary with schema novelty, acquired example effort, drift, throughput, recovery work and useful capability life. Infrastructure and model billing are not observed. The financial exercise supplies deterministic expected demand and fractional expected acceptance, not tail-risk distributions. Its fixed costs can be suspended; real commitments may not behave that way. The retained recipe's training expense is not recovered over the observed episode under the modeled base example time and does not beat the active specialist.

Local cost analysis, independent arithmetic checks and all financial projections are EXECUTED. Actual customer payments, authenticated enterprise operation, measured complete delivery cost and measured matched human duration are NOT RUN or UNKNOWN as applicable. Economic capability promotion is HOLD. Better builder behavior relative to sequential ordinary reuse is supported within scope; superiority to the strong active selector and sustained acceleration are NOT ESTABLISHED.
