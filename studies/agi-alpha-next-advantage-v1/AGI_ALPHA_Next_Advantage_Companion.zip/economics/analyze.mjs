// SPDX-License-Identifier: Apache-2.0
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
import {AUTOMATED_STAGES, inspectAutomatedCosts, evaluateAutomatedCosts} from '../vendor/shared/automated-costs.mjs';
import {planMission, calculateInvestment} from '../vendor/shared/shadow-ledger.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.dirname(HERE);
const EXPECTED = {'automated-costs.mjs':'0dfca3ae4e7ef1d17bc78521f91917ef068280cf832d3565c354de2085c52506',
  'shadow-ledger.mjs':'cdc7c5a73593050a9af79b54589462e27f61b868e88ca6985d5cb639f3066d21'};
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const load = filename => JSON.parse(fs.readFileSync(filename, 'utf8'));
const clone = value => JSON.parse(JSON.stringify(value));
const fact = (value, reference, basis='estimated') => ({value, basis:value === null ? 'unknown' : basis, reference});
const unknown = reference => fact(null, reference);
const slug = value => String(value).replace(/[^A-Za-z0-9._:-]+/g, '-').slice(0,45);
const isRetained = name => /retained|meta/i.test(name);
const isLLM = name => /llm/i.test(name);
const microMinutes = (minutes, hourly) => Math.ceil(minutes * hourly / 60);
const toCentsUp = micros => Math.ceil(micros / 10000);
const monetaryKeys = ['marginalMicrosPerAccepted', 'recurringMicrosPerAccepted', 'fullyLoadedMicrosPerAccepted'];
const counts = ['missions','accepted','refused','incorrectAccepted','constructions','labelQueries','candidateEvaluations'];

export function validateVendor() {
  for (const [name,digest] of Object.entries(EXPECTED))
    assert.equal(hash(fs.readFileSync(path.join(ROOT,'vendor/shared',name))), digest, `Changed shared source ${name}`);
}

function checkedMetrics(metrics) {
  assert(metrics && metrics.arms && typeof metrics.arms === 'object' && !Array.isArray(metrics.arms));
  for (const [name,arm] of Object.entries(metrics.arms)) {
    for (const key of counts) {
      if (key === 'incorrectAccepted' && arm[key] === undefined) continue;
      assert(Number.isSafeInteger(arm[key]) && arm[key] >= 0, `${name}.${key} must be a measured nonnegative integer`);
    }
    assert(arm.missions > 0, 'No empirical denominator');
    assert(arm.accepted + arm.refused <= arm.missions, 'Outcomes exceed attempted missions');
  }
  return metrics;
}

export function makeObservedRecord(name='experiment', assumptions=load(path.join(HERE,'assumptions.json'))) {
  const scenarios = ['base','conservative','stress'].map(scenario => ({name:scenario,
    capacityRequestsPerMonth:unknown('No measured production monthly capacity or demand'),
    utilizationBps:unknown('Finite fixture execution is not production utilization'),
    acceptanceBps:unknown('Authored structural-case success is not production acceptance probability'),
    attemptsPerRequestPpm:unknown('Production retry rate is unmeasured'),
    operations:AUTOMATED_STAGES.map(stage => ({id:`actual-${stage}`,stage,frequency:'request',
      unitsPerOccurrencePpm:unknown('Complete production occurrence count remains unmeasured'),
      unitCostMicros:unknown('Actual full monetary stage cost and allocated host invoice are unmetered'),
      implementation:'implemented'})),
    residual:[{id:'actual-human-work',stage:'preparation',exceptionsPerRequestPpm:unknown('Synthetic labels are not measured human example acquisition'),
      minutesPerException:unknown('Actual human preparation, correction and operator attention unmeasured'),
      hourlyCostMicros:unknown('Actual paid provider labor rate unobserved')}],
    monthly:[{id:'actual-shared-cost',kind:'business',amountMicros:unknown('Actual hosting, upkeep and business expense unmetered'),
      allocationBps:unknown('Production allocation unknown')}],
    investments:[{id:'actual-construction',kind:'development',amountMicros:unknown('Authoring, model billing, failed construction and setup cost unmetered'),
      allocationBps:unknown('Research-versus-production allocation unknown'),amortizationMonths:unknown('Useful economic lifetime unobserved')}],
    humanBaseline:{minutesPerAccepted:unknown('No matched competent non-AI human trial'),hourlyCostMicros:clone(assumptions.sources.office_admin_hourly_micros)}}));
  return inspectAutomatedCosts({schema:'alpha-automated-costs/v1',offeringId:`observed-${slug(name)}`,currency:'USD',scenarios});
}

function trainedLabels(metrics) {
  const number = metrics.meta?.training?.labelQueries;
  return Number.isSafeInteger(number) && number >= 0 ? number : null;
}

function residualLabelRows(name, arm, scenario, rate) {
  const ratio = arm.labelQueries / arm.missions;
  const rows=[];
  for(let slot=0;slot<Math.ceil(ratio);slot++) rows.push({id:`example-acquisition-${slot+1}`,stage:'preparation',
    exceptionsPerRequestPpm:fact(Math.ceil(Math.min(1,Math.max(0,ratio-slot))*1000000),
      `${name}: ${arm.labelQueries} measured synthetic example queries / ${arm.missions} attempted jobs; repeating this four-mission/schema workload in production is assumed. Slot decomposition preserves schema probability bound.`),
    minutesPerException:fact(scenario.reviewed_example_minutes,'Assumed human minutes to create/check one equivalent labeled example; actual minutes unknown'),
    hourlyCostMicros:clone(rate)});
  if(!rows.length) rows.push({id:'example-acquisition-zero',stage:'preparation',
    exceptionsPerRequestPpm:fact(0,`${name}: zero example queries in the supplied trace; does not price any unexposed model inference`),
    minutesPerException:fact(scenario.reviewed_example_minutes,'Scenario duration would apply to an acquired example'),hourlyCostMicros:clone(rate)});
  return rows;
}

export function makeModeledRecord(name, arm, metrics, assumptions=load(path.join(HERE,'assumptions.json'))) {
  const office=assumptions.sources.office_admin_hourly_micros, professional=assumptions.sources.professional_hourly_micros;
  const scenarios=assumptions.scenarios.map(s => {
    const ref=`Prospective ${s.name} scenario; unmeasured operational assumption.`;
    const operations=AUTOMATED_STAGES.map(stage => ({id:`session-${stage}`,stage,frequency:'attempt',
      unitsPerOccurrencePpm:fact(assumptions.stage_session_allocation_ppm[stage],
        `${ref} Explicit non-overlapping allocation of one full session across all eight stages, including candidate verification, rejected work, packaging and recovery.`),
      unitCostMicros:fact(s.runtime_session_micros,`${ref} Whole-runtime-session price allowance; not observed invoice or provider tariff.`),implementation:'implemented'}));
    if(isLLM(name)) operations.push({id:'unmetered-agent-inference',stage:'preparation',frequency:'request',
      unitsPerOccurrencePpm:fact(1000000,'One additional aggregate for all unexposed LLM calls, including failed attempts'),
      unitCostMicros:unknown('Current LLM arm model token usage and billing unavailable; cannot price as zero'),implementation:'implemented'});
    const residual=residualLabelRows(name,arm,s,office);
    residual.push({id:'operator-exception',stage:'recovery',exceptionsPerRequestPpm:fact(s.operator_exceptions_ppm,`${ref} Exception rate is not inferred from fixture pass rate.`),
      minutesPerException:fact(s.operator_exception_minutes,`${ref} Residual human exception time.`),hourlyCostMicros:clone(office)});
    const monthly=[['platform-archive-monitoring','capacity',s.monthly_platform_micros],
      ['maintenance','maintenance',microMinutes(s.monthly_maintenance_minutes,professional.value)],
      ['business','business',microMinutes(s.monthly_business_minutes,office.value)]]
      .map(([id,kind,amount])=>({id,kind,amountMicros:fact(amount,`${ref} Shared ${id} allocation, separate from charged execution sessions.`),
        allocationBps:fact(10000,'Entire modeled one-offering configuration; allocated exactly once')}));
    const setup=microMinutes(s.setup_engineering_minutes,professional.value)+microMinutes(s.setup_review_minutes,office.value)+s.authoring_model_allowance_micros;
    const investments=[{id:'common-offering-setup',kind:'setup',amountMicros:fact(setup,
      `${ref} ${s.setup_engineering_minutes} engineering minutes + ${s.setup_review_minutes} review minutes + explicit model-authoring allowance; actual original authoring costs unknown.`),
      allocationBps:fact(10000,'Shared infrastructure charged once to this offering in all arms'),
      amortizationMonths:fact(s.setup_amortization_months,'Assumed finite setup-recovery horizon, not observed useful life')}];
    if(isRetained(name)) {
      const labels=trainedLabels(metrics);
      const amount=labels===null ? null : microMinutes(labels*s.reviewed_example_minutes,office.value)+s.runtime_session_micros+
        microMinutes(s.recipe_external_engineering_minutes,professional.value);
      investments.push({id:'retained-recipe-training',kind:'development',amountMicros:fact(amount,
        labels===null?'Training-label count missing; extra construction cost remains unknown':
          `${labels} measured development example queries at assumed ${s.reviewed_example_minutes} minutes each, one whole training session and ${s.recipe_external_engineering_minutes} assumed method-specific engineering minutes; all unsuccessful recipe proposals included.`),
        allocationBps:fact(10000,'Additional retained construction charged only to the method that uses it'),
        amortizationMonths:fact(s.recipe_life_months,'Assumed finite retained-recipe life')} );
      monthly.push({id:'recipe-upkeep',kind:'maintenance',amountMicros:fact(microMinutes(s.recipe_maintenance_minutes,professional.value),
        `${ref} Additional validation/upkeep of retained construction recipe.`),allocationBps:fact(10000,'Charge once to retained method')});
    }
    return {name:s.name,capacityRequestsPerMonth:fact(s.capacity_requests_monthly,`${ref} Provisioned request capacity, not demand`),
      utilizationBps:fact(s.utilization_bps,`${ref} Hypothetical used fraction`),acceptanceBps:fact(s.acceptance_bps,`${ref} Production acceptance assumption, separate from ${arm.accepted}/${arm.missions} experiment coverage`),
      attemptsPerRequestPpm:fact(s.attempts_per_request_ppm,`${ref} Initial pass plus retries, including failure burden`),
      operations,residual,monthly,investments,humanBaseline:{minutesPerAccepted:unknown('Matched competent non-AI human duration unobserved'),hourlyCostMicros:clone(office)}};
  });
  return inspectAutomatedCosts({schema:'alpha-automated-costs/v1',offeringId:`modeled-${slug(name)}`,currency:'USD',scenarios});
}

function nativeUnknownLedger(name) {
  return planMission({missionId:`actual-${slug(name)}`,currency:'USD',acceptance:'unknown',
    reference:'Finite local contract acceptance does not establish customer acceptance; actual collections, complete cost, reserves and obligations unknown',
    totalCollectedCents:null,priceAssumptionCents:null,totalOperatingCostCents:null,operatingCostsComplete:false,
    capabilityCostCents:null,reserveCents:null,obligationCents:null,costBasis:'assumed',reinvestmentBps:0,
    humanMinutes:null,humanHourlyCents:null,traditionalMinutes:null});
}

function comparisonRows(name, arm, report, assumptions) {
  return report.scenarios.map(r=>{
    const s=assumptions.scenarios.find(x=>x.name===r.name), accepted=s.acceptance_bps/10000;
    const automation=r.components.operations.some(x=>x.costMicrosPerRequest===null)?null:
      Math.ceil(r.components.operations.reduce((sum,x)=>sum+x.costMicrosPerRequest,0)/accepted);
    const cost=r.costs.fullyLoadedMicrosPerAccepted;
    const customerCost=microMinutes(s.customer_minutes_per_accepted,assumptions.sources.office_admin_hourly_micros.value);
    const thresholds=Object.fromEntries(Object.entries(assumptions.sources).map(([rateName,rate])=>[rateName,{
      hourlyRateUSD:rate.value/1e6,rateBasis:rate.basis,reference:rate.reference,humanMinutes:null,
      enterpriseCostBreakEvenMinutes:cost===null?null:cost*60/rate.value,
      totalResourceBreakEvenMinutes:cost===null?null:(cost+customerCost)*60/rate.value,
      customerPurchaseThresholds:assumptions.customer_prices_minor.map(price=>({assumedPriceUSD:price/100,
        customerAttentionUSD:customerCost/1e6,breakEvenHumanMinutes:(price*10000+customerCost)*60/rate.value}))}]));
    return {arm:name,scenario:r.name,status:'CONDITIONAL_MODEL_NOT_OBSERVED_COST',measuredCoverage:{accepted:arm.accepted,attempted:arm.missions,incorrectAccepted:arm.incorrectAccepted??null},
      executionOnlyMicrosPerAccepted:automation,...r.costs,volume:r.volume,residualHumanMinutesPerRequest:r.residualHumanMinutesPerRequest,
      customerAttentionMinutes:s.customer_minutes_per_accepted,customerAttentionMicros:customerCost,thresholds,
      explanation:'Execution-only uses paid automated operation allocations; shared marginal additionally includes example acquisition and human exceptions. Recurring/full are cumulative. Customer attention is not a provider cash expense.'};
  });
}

function addFinancialLedger(caseId, ceiling, period, totals, protectedReserve, obligations, constructionPaid) {
  const missionId=`${slug(caseId).slice(0,30)}-${ceiling}-${period}`;
  return planMission({missionId,currency:'USD',acceptance:'accepted',
    reference:'SIMULATED cohort: scenario price is collection-adjusted gross face price of matured assumed invoices; actual collected category is unknown. Acceptance is an explicit scenario, not a customer observation.',
    totalCollectedCents:null,priceAssumptionCents:totals.receipts,
    totalOperatingCostCents:totals.operating+totals.refunds+totals.fees,operatingCostsComplete:true,
    capabilityCostCents:constructionPaid,reserveCents:protectedReserve,obligationCents:obligations,
    costBasis:'assumed',reinvestmentBps:ceiling,humanMinutes:null,humanHourlyCents:null,traditionalMinutes:null});
}

function financeCase(c, ceiling, arm, report, record, assumptions) {
  const f=assumptions.finance, s=assumptions.scenarios.find(x=>x.name==='base');
  const office=assumptions.sources.office_admin_hourly_micros.value,professional=assumptions.sources.professional_hourly_micros.value;
  const row=report.scenarios.find(x=>x.name==='base'), source=record.scenarios.find(x=>x.name==='base');
  const constructions=toCentsUp(microMinutes(f.construction_engineering_minutes,professional)+microMinutes(f.construction_review_minutes,office)+
    microMinutes(f.construction_label_examples*s.reviewed_example_minutes,office))+f.construction_tool_minor;
  const failed=toCentsUp(microMinutes(f.failed_engineering_minutes,professional)+microMinutes(f.failed_review_minutes,office)+
    microMinutes(f.failed_label_examples*s.reviewed_example_minutes,office))+f.failed_tool_minor;
  const fixedConstruction=constructions+failed;
  const constructionMinutes=f.construction_engineering_minutes+f.construction_review_minutes+
    f.failed_engineering_minutes+f.failed_review_minutes+
    (f.construction_label_examples+f.failed_label_examples)*s.reviewed_example_minutes;
  const timeAffordable=constructionMinutes<=f.available_construction_minutes_per_month;
  const fullSetup=source.investments.reduce((sum,x)=>sum+x.amountMicros.value,0);
  const startup=toCentsUp(fullSetup),monthlyFixed=toCentsUp(row.costs.sharedMonthlyMicros), variable=row.costs.nextRequestMicros/10000;
  const reserve=f.reserve_minor*c.reserve_multiplier, obligations=f.obligation_minor*c.obligation_multiplier;
  const protectedCash=reserve+obligations;
  const startupAffordable=f.initial_external_seed_minor-protectedCash>=startup;
  let cash=f.initial_external_seed_minor-(startupAffordable?startup:0), cumulativeReceipts=0,operating=startupAffordable?startup:0, refundsTotal=0,feesTotal=0;
  let constructionMonth=null, constructionPaid=0, benefitStart=null, cumulativeSavings=0,cumulativeUpkeep=0,candidateSpent=false;
  let firstPaybackMonth=null, startupStatus=startupAffordable?'FUNDED':'REFUSED_PROTECTED_STARTUP';
  const pending=[],trace=[],ledgers=[];
  for(let month=1;month<=f.horizon_months;month++) {
    const opening=cash,openingReceivables=pending.reduce((sum,x)=>sum+x.face,0);
    const due=pending.filter(x=>x.due===month),remaining=pending.filter(x=>x.due!==month);
    pending.splice(0,pending.length,...remaining);
    const dueFace=due.reduce((sum,x)=>sum+x.face,0),dueCount=due.reduce((sum,x)=>sum+x.accepted,0);
    const receipts=Math.floor(dueFace*f.collection_bps/10000);
    const refunds=Math.ceil(receipts*f.refund_bps/10000);
    const fees=receipts===0?0:Math.ceil(receipts*f.processing_bps/10000+dueCount*f.collection_bps/10000*f.processing_fixed_minor);
    cash+=receipts-refunds-fees;cumulativeReceipts+=receipts;refundsTotal+=refunds;feesTotal+=fees;
    const maxRequests=Math.min(c.requested_per_month,Math.floor(row.volume.requestsPerMonth));
    const canFund=startupAffordable && cash-protectedCash>=monthlyFixed;
    const requested=canFund?Math.min(maxRequests,Math.max(0,Math.floor((cash-protectedCash-monthlyFixed)/variable))):0;
    const accepted=requested*s.acceptance_bps/10000;
    const ordinary=requested>0?monthlyFixed+Math.ceil(requested*variable):0;
    const active=candidateSpent && c.qualification==='assumed-pass' && month>=benefitStart;
    const savings=active?Math.floor(accepted*c.realized_saving_per_reuse_minor):0;
    const upkeep=active?Math.ceil(accepted*f.maintenance_per_reuse_minor):0;
    assert(savings<=ordinary,'Scenario savings exceed the complete current operating expense; scenario must be amended, not clipped');
    const periodOperating=ordinary-savings+upkeep;
    assert(periodOperating<=cash-protectedCash || periodOperating===0,'Operating spend consumes protected balances');
    cash-=periodOperating;operating+=periodOperating;cumulativeSavings+=savings;cumulativeUpkeep+=upkeep;
    const booked=Math.floor(accepted*f.customer_price_minor);
    if(booked) pending.push({due:month+c.collection_delay_months,face:booked,accepted});
    const totals={receipts:cumulativeReceipts,operating,refunds:refundsTotal,fees:feesTotal};
    const before=addFinancialLedger(c.id,ceiling,month,totals,reserve,obligations,constructionPaid);
    const remainingMonths=Math.max(0,f.horizon_months-month-c.benefit_delay_months);
    const remainingReuses=Math.floor(remainingMonths*maxRequests*s.acceptance_bps/10000);
    const investment=calculateInvestment({constructionCostMinor:constructions,failedConstructionCostMinor:failed,
      maintenancePerReuseMinor:f.maintenance_per_reuse_minor,expectedSavingPerReuseMinor:c.expected_saving_per_reuse_minor,remainingReuses});
    const expectedMonthlySaving=c.expected_saving_per_reuse_minor*maxRequests*s.acceptance_bps/10000;
    const expectedOrdinary=monthlyFixed+Math.ceil(maxRequests*variable);
    const physicallySized=expectedMonthlySaving<=expectedOrdinary;
    const available=before.summary.scenario.availableSurplus;
    const eligible=before.summary.scenario.eligibleInvestment;
    let decision=candidateSpent?'ALREADY_CONSTRUCTED':!startupAffordable?'REFUSED_PROTECTED_STARTUP':
      !physicallySized?'REJECT_SAVING_EXCEEDS_COST':!timeAffordable?'REJECT_CONSTRUCTION_TIME_CAP':!investment.paysBackWithinHorizon?'REJECT_FINITE_HORIZON_VALUE':
        eligible<fixedConstruction?'WAIT_EARNED_SURPLUS_OR_ALLOCATION':cash-protectedCash<fixedConstruction?'WAIT_LIQUIDITY':'CONSTRUCT_SIMULATED';
    let spentNow=0;
    if(decision==='CONSTRUCT_SIMULATED') {
      candidateSpent=true;constructionMonth=month;benefitStart=month+c.benefit_delay_months+1;
      spentNow=fixedConstruction;constructionPaid+=spentNow;cash-=spentNow;
    }
    const after=addFinancialLedger(c.id,ceiling,month,totals,reserve,obligations,constructionPaid);
    ledgers.push({month,...after});
    if(candidateSpent && firstPaybackMonth===null && cumulativeSavings-cumulativeUpkeep>=constructionPaid) firstPaybackMonth=month;
    const receivables=pending.reduce((sum,x)=>sum+x.face,0),badDebt=dueFace-receipts;
    assert.equal(openingReceivables+booked-dueFace,receivables,'Receivable identity');
    assert.equal(opening+receipts-refunds-fees-periodOperating-spentNow,cash,'Cash identity');
    assert.equal(f.initial_external_seed_minor+cumulativeReceipts-operating-refundsTotal-feesTotal-constructionPaid,cash,'Cumulative cash identity');
    assert(cash>=protectedCash || (!startupAffordable && cash===f.initial_external_seed_minor),'Protected cash invariant');
    assert.equal(after.summary.observed.availableSurplus,null,'Simulated receipts must never become observed surplus');
    trace.push({month,openingCashMinor:opening,requestedAttempts:requested,expectedAccepted:accepted,
      faceInvoicesMinor:booked,simulatedGrossCollectionsMinor:receipts,simulatedRefundsMinor:refunds,simulatedFeesMinor:fees,
      writtenOffMinor:badDebt,receivablesMinor:receivables,ordinaryOperatingMinor:ordinary,realizedAssumedSavingMinor:savings,
      upkeepMinor:upkeep,operatingCashPaidMinor:periodOperating,constructionCashPaidMinor:spentNow,
      cashMinor:cash,protectedReserveMinor:reserve,protectedObligationsMinor:obligations,
      earnedAvailableBeforeInvestmentMinor:available,allocationEligibleBeforeInvestmentMinor:eligible,
      minimumAllocationBps:available>0?Math.ceil(fixedConstruction*10000/available):null,
      decision,investment,constructionQualification:candidateSpent?c.qualification:'NOT_ATTEMPTED',
      cumulativeBenefitAfterConstructionMinor:cumulativeSavings-cumulativeUpkeep-constructionPaid,
      simulated:true,observedCollectionsMinor:null});
  }
  return {id:c.id,allocationCeilingBps:ceiling,operatingArm:arm,status:'SIMULATION_NO_CUSTOMER_PAYMENTS',
    externalSeedMinor:f.initial_external_seed_minor,startupStatus,quotedStartupMinor:startup,incurredStartupMinor:startupAffordable?startup:0,
    candidateBudget:{constructionCostMinor:constructions,failedConstructionCostMinor:failed,totalMinor:fixedConstruction,
      constructionMinutes,availableConstructionMinutes:f.available_construction_minutes_per_month},
    finalCashMinor:cash,finalReceivablesMinor:pending.reduce((sum,x)=>sum+x.face,0),constructionMonth,benefitStart,
    firstPaybackMonth,constructionPaidMinor:constructionPaid,cumulativeAssumedSavingMinor:cumulativeSavings,
    cumulativeUpkeepMinor:cumulativeUpkeep,netCapabilityBenefitMinor:cumulativeSavings-cumulativeUpkeep-constructionPaid,
    assumedQualification:c.qualification,trace,ledgers,
    scope:'A hypothetical future candidate with assumed benefits and costs; not the experimental candidate or a sale. Shared native ledger scenario channel only. Future fixed costs assumed suspendible. Expected-state finite horizon; no tail-risk guarantee.'};
}

function incremental(metrics, assumptions) {
  const rows=[];const names=Object.keys(metrics.arms),retained=names.find(isRetained);
  if(!retained) return {status:'NO_RETAINED_ARM',comparisons:[]};
  const r=metrics.arms[retained],training=trainedLabels(metrics);
  for(const name of names.filter(x=>x!==retained)) {
    const a=metrics.arms[name],qualified=(r.incorrectAccepted??null)===0 && (a.incorrectAccepted??null)===0 && r.accepted>=a.accepted;
    const productionSaved=a.labelQueries-r.labelQueries;
    rows.push({comparator:name,coverageNotLowerAndNoIncorrectAcceptance:qualified,
      productionLabelQueriesAvoided:productionSaved,trainingLabelQueries:training,
      netLabelQueriesAvoidedAfterTraining:training===null?null:productionSaved-training,
      conditionalLabelValue:assumptions.human_label_minutes_grid.map(minutes=>({assumedMinutesPerExample:minutes,
        grossLabelOpportunityCostDifferenceUSD:productionSaved*minutes*assumptions.sources.office_admin_hourly_micros.value/60/1e6,
        afterTrainingLabelDifferenceUSD:training===null?null:(productionSaved-training)*minutes*assumptions.sources.office_admin_hourly_micros.value/60/1e6})),
      conditionalLabelBreakEven:assumptions.scenarios.map(s=>{
        const monthlyRequests=s.capacity_requests_monthly*s.utilization_bps/10000;
        const months=Math.ceil(r.missions/monthlyRequests);
        const extra=s.runtime_session_micros+microMinutes(s.recipe_external_engineering_minutes,assumptions.sources.professional_hourly_micros.value)+
          Math.min(months,s.recipe_life_months)*microMinutes(s.recipe_maintenance_minutes,assumptions.sources.professional_hourly_micros.value);
        const net=training===null?null:productionSaved-training;
        return {scenario:s.name,testedHorizonMonthsAtAssumedVolume:months,recipeLifeMonths:s.recipe_life_months,
          extraNonlabelRecipeCostUSD:extra/1e6,labelTimeBreakEvenMinutes:qualified && net>0 && months<=s.recipe_life_months?
            extra*60/(net*assumptions.sources.office_admin_hourly_micros.value):null,
          status:!qualified?'NO_EQUAL_QUALITY_COMPARISON':net===null?'UNKNOWN_TRAINING':net<=0?'NO_POSITIVE_LABEL_SAVING':
            months>s.recipe_life_months?'HORIZON_EXCEEDS_ASSUMED_LIFE':'CONDITIONAL_THRESHOLD_ONLY'};
      }),
      observedDollarAdvantage:null,actualConstructionCost:null,
      decision:'HOLD_FULL_COST_AND_PRODUCTION_VALUE_UNMEASURED'});
  }
  return {retainedArm:retained,trainingLabelQueries:training,comparisons:rows,
    scope:'Counts are observed; human time and valuation are hypothetical. Coverage and accepted quality remain visible. This is not a claim of measured cash saving.'};
}

function resourceMeasures(metrics, assumptions) {
  return Object.fromEntries(Object.entries(metrics.arms).map(([name,arm])=>{
    const cpuFields=['constructionCpuMs','productionCpuMs','verificationCpuMs'];
    const values=Object.fromEntries(cpuFields.map(key=>[key,Number.isFinite(arm[key]) && arm[key]>=0?arm[key]:null]));
    const total=Object.values(values).some(x=>x===null)?null:Object.values(values).reduce((sum,x)=>sum+x,0);
    return [name,{...values,wallMs:Number.isFinite(arm.wallMs)?arm.wallMs:null,
      constructionCount:arm.constructions,labelQueries:arm.labelQueries,candidateEvaluations:arm.candidateEvaluations,
      allAttemptCpuMs:total,accepted:arm.accepted,attempted:arm.missions,
      illustrativeProratedComputeUSD:total===null?null:total/3600000*assumptions.compute_proration_usd_per_cpu_hour,
      assumedUSDPerCPUHour:assumptions.compute_proration_usd_per_cpu_hour,
      actualBilledComputeUSD:null,actualModelBillingUSD:null,
      scope:'Supplied disjoint construction/production/verification CPU spans retain failed work. Hypothetical continuous CPU pricing is separate from the full-session allowance and is not added to it.'}];
  }));
}

export function protocolCheck() {
  validateVendor();const a=load(path.join(HERE,'assumptions.json'));
  assert.equal(Object.values(a.stage_session_allocation_ppm).reduce((s,x)=>s+x,0),1000000);
  const r=evaluateAutomatedCosts(makeObservedRecord('protocol-check',a));
  for(const row of r.scenarios) for(const key of monetaryKeys) assert.equal(row.costs[key],null);
  const ledger=nativeUnknownLedger('protocol-check');assert.equal(ledger.summary.observed.availableSurplus,null);
  assert.equal(calculateInvestment({constructionCostMinor:100,failedConstructionCostMinor:50,maintenancePerReuseMinor:2,
    expectedSavingPerReuseMinor:0,remainingReuses:100}).paysBackWithinHorizon,false);
  return {status:'PASS',scope:'API/schema/unknown-propagation check only; no research outcomes or economics scenario analysis',vendorSHA256:EXPECTED};
}

export function runAnalysis(metricsPath,outDir) {
  validateVendor();assert(!fs.existsSync(outDir),'Output directory exists; preserve prior results');
  const bytes=fs.readFileSync(metricsPath),metrics=checkedMetrics(JSON.parse(bytes)),a=load(path.join(HERE,'assumptions.json'));
  const observed={},modeled={},summaries={},unknownLedgers={},tables=[];
  for(const [name,arm] of Object.entries(metrics.arms)) {
    observed[name]=makeObservedRecord(name,a);unknownLedgers[name]=nativeUnknownLedger(name);
    const actualReport=evaluateAutomatedCosts(observed[name]);
    for(const row of actualReport.scenarios) for(const key of monetaryKeys) assert.equal(row.costs[key],null);
    modeled[name]=makeModeledRecord(name,arm,metrics,a);summaries[name]=evaluateAutomatedCosts(modeled[name]);
    tables.push(...comparisonRows(name,arm,summaries[name],a));
  }
  const complete=Object.keys(metrics.arms).filter(name=>!isLLM(name) && metrics.arms[name].accepted===metrics.arms[name].missions && metrics.arms[name].incorrectAccepted===0 &&
    summaries[name].scenarios.find(x=>x.name==='base').costs.fullyLoadedMicrosPerAccepted!==null);
  complete.sort((left,right)=>summaries[left].scenarios.find(x=>x.name==='base').costs.recurringMicrosPerAccepted-
    summaries[right].scenarios.find(x=>x.name==='base').costs.recurringMicrosPerAccepted || left.localeCompare(right));
  const financialArm=complete[0]??null,finances=[];
  if(financialArm) for(const c of a.finance.cases) for(const ceiling of a.finance.allocation_ceilings_bps)
    finances.push(financeCase(c,ceiling,financialArm,summaries[financialArm],modeled[financialArm],a));
  const summary={status:'CONDITIONAL_ECONOMIC_ANALYSIS_NOT_OBSERVED_CASH',metricsSHA256:hash(bytes),
    assumptionsSHA256:hash(fs.readFileSync(path.join(HERE,'assumptions.json'))),protocolSHA256:hash(fs.readFileSync(path.join(HERE,'PROTOCOL.md'))),
    sourceHashes:EXPECTED,actualFullCostUSD:null,actualHumanDurationMinutes:null,actualCustomerCollectionsUSD:null,
    measuredResources:resourceMeasures(metrics,a),
    A:{status:'BREAK_EVEN_THRESHOLDS_ONLY',tables},B:incremental(metrics,a),
    C:{status:financialArm?'SIMULATED_FINANCEABILITY':'NO_COMPLETE_QUALITY_ARM_FOR_OPERATING_PROJECTION',operatingArm:financialArm,
      reason:'Select lowest modeled recurring expense among complete, zero-incorrect deterministic arms; no empirical monetary superiority is implied.',
      cases:finances.map(({trace,ledgers,...rest})=>rest)},
    executionStatus:{localCostArithmetic:'EXECUTED',localFinanceProjection:financialArm?'EXECUTED':'NOT_RUN_NO_QUALIFIED_OPERATING_ARM',
      authenticatedEnterprise:'NOT_RUN',customerPayments:'NOT_RUN',economicCapabilityPromotion:'HOLD',sustainedAcceleration:'NOT_ESTABLISHED'}};
  fs.mkdirSync(outDir,{recursive:false});
  const save=(name,data)=>fs.writeFileSync(path.join(outDir,name),JSON.stringify(data,null,2)+'\n');
  save('observed-cost-records.json',observed);save('observed-ledgers.json',unknownLedgers);
  save('modeled-cost-records.json',modeled);save('native-cost-summaries.json',summaries);save('summary.json',summary);
  save('finance-projections.json',finances.map(({ledgers,...rest})=>rest));
  save('finance-native-ledgers.json',finances.map(({id,allocationCeilingBps,ledgers})=>({id,allocationCeilingBps,ledgers})));
  fs.writeFileSync(path.join(outDir,'metrics-input.json'),bytes);
  save('REPRODUCTION.json',{command:'node economics/analyze.mjs --metrics <metrics-input.json> --out <new-directory>',
    nodeVersion:process.version,sourceSHA256:hash(fs.readFileSync(fileURLToPath(import.meta.url))),vendorSHA256:EXPECTED,
    metricsSHA256:hash(bytes),assumptionsSHA256:summary.assumptionsSHA256,protocolSHA256:summary.protocolSHA256,
    modeledArmCount:Object.keys(modeled).length,financialScenarioCount:finances.length,
    observedCostAndRevenue:'UNKNOWN: never inferred from synthetic labels, fixture acceptance or scenario cash'});
  return summary;
}

if(process.argv[1] && path.resolve(process.argv[1])===fileURLToPath(import.meta.url)) {
  const args=process.argv.slice(2);
  if(args.length===1 && args[0]==='--protocol-check') console.log(JSON.stringify(protocolCheck(),null,2));
  else {
    const at=key=>args.indexOf(key);
    assert(at('--metrics')>=0 && at('--out')>=0 && args.length===4,'Use --metrics FILE --out NEW_DIRECTORY, or --protocol-check');
    const summary=runAnalysis(path.resolve(args[at('--metrics')+1]),path.resolve(args[at('--out')+1]));
    console.log(JSON.stringify({status:summary.status,arms:summary.A.tables.length/3,financeCases:summary.C.cases.length,
      actualFullCostUSD:summary.actualFullCostUSD,actualCollectionsUSD:summary.actualCustomerCollectionsUSD},null,2));
  }
}
