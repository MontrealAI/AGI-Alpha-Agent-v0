#!/usr/bin/env python3
"""Export descriptive plotting data without changing frozen outcomes."""
import argparse
import hashlib
import json
from pathlib import Path


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    if args.out.exists():
        raise SystemExit("Preserve prior figure data; select a new filename")
    directory = args.results.resolve()
    summary = json.loads((directory / "summary.json").read_text())
    metrics = json.loads((directory / "metrics-input.json").read_text())
    financial = json.loads((directory / "finance-projections.json").read_text())
    cpu_file = Path(__file__).resolve().parent / "resources-v1.1.json"
    cpu = json.loads(cpu_file.read_text()) if cpu_file.exists() else None
    order = [name for name in ["rebuild", "ordinary_reuse", "retained", "active_specialist"] if name in metrics["arms"]]
    label_rows = []
    for name in order:
        arm = metrics["arms"][name]
        training = metrics["meta"]["training"]["labelQueries"] if name == "retained" else 0
        label_rows.append({"arm": name, "productionExampleQueries": arm["labelQueries"],
                           "additionalUniqueTrainingExamples": training,
                           "totalProductionAndTrainingExamples": arm["labelQueries"] + training,
                           "accepted": arm["accepted"], "attempted": arm["missions"],
                           "incorrectAccepted": arm["incorrectAccepted"],
                           "status": "MEASURED_SCOPED_EXPERIMENT"})
    costs = []
    thresholds = []
    for row in summary["A"]["tables"]:
        e, m, r, f = (row[x] for x in ["executionOnlyMicrosPerAccepted", "marginalMicrosPerAccepted", "recurringMicrosPerAccepted", "fullyLoadedMicrosPerAccepted"])
        components = None if any(x is None for x in [e, m, r, f]) else {
            "execution": e / 1e6, "additionalHumanPreparationAndExceptions": (m-e) / 1e6,
            "additionalRecurringOverhead": (r-m) / 1e6, "additionalCapitalRecovery": (f-r) / 1e6}
        costs.append({"arm": row["arm"], "scenario": row["scenario"],
                      "status": "MODELED_USD_NOT_OBSERVED_COST", "currency": "USD",
                      "cumulativeTiersUSD": dict(zip(["executionOnly", "sharedMarginal", "recurring", "fullyLoaded"],
                                                      [None if x is None else x/1e6 for x in [e,m,r,f]])),
                      "stackableIncrementsUSD": components,
                      "requestedMonthly": row["volume"]["requestsPerMonth"],
                      "expectedAcceptedMonthly": row["volume"]["acceptedPerMonth"]})
        if row["arm"] == "active_specialist":
            thresholds.extend({"arm": row["arm"], "scenario": row["scenario"], "laborBasis": name,
                               "hourlyRateUSD": threshold["hourlyRateUSD"],
                               "providerCostBreakEvenMinutes": threshold["enterpriseCostBreakEvenMinutes"],
                               "totalResourceBreakEvenMinutes": threshold["totalResourceBreakEvenMinutes"],
                               "purchaseThresholds": threshold["customerPurchaseThresholds"],
                               "matchedHumanDurationMinutes": None,
                               "status": "CONDITIONAL_THRESHOLD_WITH_UNMEASURED_HUMAN_DURATION"}
                              for name, threshold in row["thresholds"].items())
    finance_rows = []
    for case in financial:
        finance_rows.append({"case": case["id"], "allocationCeilingPercent": case["allocationCeilingBps"]/100,
                            "status": "SIMULATION_HYPOTHETICAL_FUTURE_CAPABILITY",
                            "constructionMonth": case["constructionMonth"],
                            "firstBenefitMonth": case["benefitStart"], "firstPaybackMonth": case["firstPaybackMonth"],
                            "startupStatus": case["startupStatus"],
                            "completeCandidateCostUSD": case["candidateBudget"]["totalMinor"]/100,
                            "netCapabilityBenefitUSD": case["netCapabilityBenefitMinor"]/100,
                            "trace": [{"month": r["month"], "decision": r["decision"],
                                       "earnedScenarioSurplusBeforeInvestmentUSD": r["earnedAvailableBeforeInvestmentMinor"]/100,
                                       "allocationEligibleBeforeInvestmentUSD": r["allocationEligibleBeforeInvestmentMinor"]/100,
                                       "remainingForecastReuses": r["investment"]["remainingReuses"],
                                       "breakEvenReuses": r["investment"]["breakEvenReuses"],
                                       "constructionPaidUSD": r["constructionCashPaidMinor"]/100,
                                       "netCapabilityBenefitToDateUSD": r["cumulativeBenefitAfterConstructionMinor"]/100,
                                       "grossScenarioCollectionsUSD": r["simulatedGrossCollectionsMinor"]/100,
                                       "endingCashIncludingSeedUSD": r["cashMinor"]/100,
                                       "protectedBalancesUSD": (r["protectedReserveMinor"]+r["protectedObligationsMinor"])/100,
                                       "faceReceivablesUSD": r["receivablesMinor"]/100,
                                       "actualCollectionsUSD": None} for r in case["trace"]]})
    exported = {"status": "DESCRIPTIVE_FIGURE_DATA_FROM_PRESERVED_FROZEN_RESULTS",
                "metricsSHA256": summary["metricsSHA256"],
                "summarySHA256": hashlib.sha256((directory/"summary.json").read_bytes()).hexdigest(),
                "labelCounts": label_rows, "costTiers": costs,
                "humanThresholds": thresholds, "financing": finance_rows,
                "correctedAuxiliaryResources": cpu,
                "notes": ["No outcome selection or additional model fitting occurs in this export.",
                          "Use the study's frozen stratified-family bootstrap intervals for statistical inference.",
                          "Stack cost increments; cumulative tier totals must not be stacked.",
                          "CPU is partial recorded CPU after the additive v1.1 reporting correction; complete CPU and actual billing remain unknown.",
                          "Dollar figures are conditional models; finance outcomes are simulations concerning a hypothetical future capability."]}
    args.out.write_text(json.dumps(exported, indent=2) + "\n")
    print(json.dumps({"status": "EXPORTED", "labelArms": len(label_rows), "costRows": len(costs), "financePaths": len(finance_rows)}))
