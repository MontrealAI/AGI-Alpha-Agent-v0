#!/usr/bin/env python3
"""Read-only, independent-arithmetic review of the frozen economics outputs.

This does not replace either shared accounting implementation and does not rerun
the experiment.  It checks their exported records using Python rational arithmetic.
"""
import argparse
import hashlib
import json
import math
from collections import Counter
from fractions import Fraction
from pathlib import Path


def read(path):
    return json.loads(path.read_text())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def exact(value):
    return Fraction(str(value))


def audit(root, result_dir):
    assumptions = read(root / "assumptions.json")
    metrics = read(result_dir / "metrics-input.json")
    summary = read(result_dir / "summary.json")
    records = read(result_dir / "modeled-cost-records.json")
    reports = read(result_dir / "native-cost-summaries.json")
    actual_ledgers = read(result_dir / "observed-ledgers.json")
    projections = read(result_dir / "finance-projections.json")
    finance_ledgers = read(result_dir / "finance-native-ledgers.json")
    reproduction = read(result_dir / "REPRODUCTION.json")
    checks = Counter()

    def check(condition, label):
        if not condition:
            raise AssertionError(label)
        checks[label.split(":", 1)[0]] += 1

    for name, filename in [("sourceSHA256", root / "analyze.mjs"),
                           ("assumptionsSHA256", root / "assumptions.json"),
                           ("protocolSHA256", root / "PROTOCOL.md"),
                           ("metricsSHA256", result_dir / "metrics-input.json")]:
        check(reproduction[name] == digest(filename), "source_hash:" + name)

    cost_rows = []
    for arm, record in records.items():
        for source in record["scenarios"]:
            scenario = source["name"]
            out = next(r for r in reports[arm]["scenarios"] if r["name"] == scenario)
            acceptance = Fraction(source["acceptanceBps"]["value"], 10_000)
            requests = source["capacityRequestsPerMonth"]["value"] * Fraction(source["utilizationBps"]["value"], 10_000)
            attempts = Fraction(source["attemptsPerRequestPpm"]["value"], 1_000_000)
            automated = Fraction()
            for row in source["operations"]:
                occurrence = attempts if row["frequency"] == "attempt" else acceptance if row["frequency"] == "accepted" else 1
                if row["unitCostMicros"]["value"] is None:
                    automated = None
                    break
                automated += occurrence * Fraction(row["unitsPerOccurrencePpm"]["value"], 1_000_000) * row["unitCostMicros"]["value"]
            human = sum(Fraction(r["exceptionsPerRequestPpm"]["value"], 1_000_000)
                        * r["minutesPerException"]["value"] * Fraction(r["hourlyCostMicros"]["value"], 60)
                        for r in source["residual"])
            fixed = sum(r["amountMicros"]["value"] * Fraction(r["allocationBps"]["value"], 10_000)
                        for r in source["monthly"])
            investment_unknown = any(r["amountMicros"]["value"] is None for r in source["investments"])
            amortization = None if investment_unknown else sum(r["amountMicros"]["value"] * Fraction(r["allocationBps"]["value"], 10_000)
                         / r["amortizationMonths"]["value"] for r in source["investments"])
            next_request = None if automated is None else automated + human
            variable_monthly = None if next_request is None else next_request * requests
            expected = {
                "nextRequestMicros": next_request,
                "marginalMicrosPerAccepted": None if next_request is None else next_request / acceptance,
                "recurringMicrosPerAccepted": None if variable_monthly is None else (variable_monthly + fixed) / (requests * acceptance),
                "fullyLoadedMicrosPerAccepted": None if variable_monthly is None or amortization is None else (variable_monthly + fixed + amortization) / (requests * acceptance),
                "variableMonthlyMicros": variable_monthly,
                "sharedMonthlyMicros": fixed,
                "amortizedMonthlyMicros": amortization,
            }
            for key, number in expected.items():
                check(out["costs"][key] == (None if number is None else math.ceil(number)), "native_cost_rational:" + arm + "/" + scenario + "/" + key)
            arow = next(r for r in summary["A"]["tables"] if r["arm"] == arm and r["scenario"] == scenario)
            check(arow["executionOnlyMicrosPerAccepted"] == (None if automated is None else math.ceil(automated / acceptance)), "execution_only:" + arm + "/" + scenario)
            check(out["humanBaselineMicrosPerAccepted"] is None, "unmeasured_human_duration:" + arm + "/" + scenario)
            for rate in arow["thresholds"].values():
                if arow["fullyLoadedMicrosPerAccepted"] is not None:
                    expected_minutes = arow["fullyLoadedMicrosPerAccepted"] / 1_000_000 * 60 / rate["hourlyRateUSD"]
                    check(abs(rate["enterpriseCostBreakEvenMinutes"] - expected_minutes) < 1e-10, "human_threshold:" + arm + "/" + scenario)
                check(rate["humanMinutes"] is None, "unmeasured_human_threshold_input:" + arm + "/" + scenario)
            cost_rows.append({"arm": arm, "scenario": scenario, "exactRationalArithmetic": "PASS"})

    for arm, ledger in actual_ledgers.items():
        check(all(v is None for v in ledger["summary"]["observed"].values()), "observed_unknown:" + arm)
        check(all(v is None for v in ledger["summary"]["scenario"].values()), "actual_scenario_unknown:" + arm)
    for key in ["actualFullCostUSD", "actualHumanDurationMinutes", "actualCustomerCollectionsUSD"]:
        check(summary[key] is None, "summary_unknown:" + key)

    native_by_case = {(x["id"], x["allocationCeilingBps"]): x for x in finance_ledgers}
    f = assumptions["finance"]
    cases = {c["id"]: c for c in f["cases"]}
    check(len(projections) == len(cases) * len(f["allocation_ceilings_bps"]) == 30, "all_finance_paths")
    check(len(native_by_case) == len(projections), "native_projection_pairing")
    decisions = Counter()
    financial_rows = []
    for projected in projections:
        case_id, ceiling = projected["id"], projected["allocationCeilingBps"]
        c = cases[case_id]
        key = (case_id, ceiling)
        native = native_by_case[key]["ledgers"]
        check(len(projected["trace"]) == len(native) == f["horizon_months"], "all_months:" + str(key))
        cash = projected["externalSeedMinor"] - projected["incurredStartupMinor"]
        receivable = 0
        gross = operating = fees = refunds = construction = savings = upkeep = 0
        operating = projected["incurredStartupMinor"]
        paid_months = []
        payback_months = []
        selected = records[projected["operatingArm"]]
        setup = next(s for s in selected["scenarios"] if s["name"] == "base")["investments"]
        check(projected["quotedStartupMinor"] == math.ceil(sum(x["amountMicros"]["value"] for x in setup) / 10_000), "startup_once:" + str(key))
        for row, ledger in zip(projected["trace"], native):
            month = row["month"]
            decisions[row["decision"]] += 1
            check(row["openingCashMinor"] == cash, "cash_opening:" + str(key))
            cash += row["simulatedGrossCollectionsMinor"] - row["simulatedRefundsMinor"] - row["simulatedFeesMinor"] - row["operatingCashPaidMinor"] - row["constructionCashPaidMinor"]
            check(cash == row["cashMinor"], "cash_conservation:" + str(key))
            receivable += row["faceInvoicesMinor"] - row["simulatedGrossCollectionsMinor"] - row["writtenOffMinor"]
            check(receivable == row["receivablesMinor"], "receivable_conservation:" + str(key))
            check(cash >= row["protectedReserveMinor"] + row["protectedObligationsMinor"], "protected_balances:" + str(key))
            check(row["operatingCashPaidMinor"] == row["ordinaryOperatingMinor"] - row["realizedAssumedSavingMinor"] + row["upkeepMinor"], "benefit_cost_separation:" + str(key))
            gross += row["simulatedGrossCollectionsMinor"]
            fees += row["simulatedFeesMinor"]
            refunds += row["simulatedRefundsMinor"]
            operating += row["operatingCashPaidMinor"]
            construction += row["constructionCashPaidMinor"]
            savings += row["realizedAssumedSavingMinor"]
            upkeep += row["upkeepMinor"]
            check(row["observedCollectionsMinor"] is None, "projection_actual_unknown:" + str(key))
            check(all(x is None for x in ledger["summary"]["observed"].values()), "native_observed_unknown:" + str(key))
            check(ledger["summary"]["scenario"]["revenue"] == gross, "native_matured_collection_mapping:" + str(key))
            check(ledger["summary"]["scenario"]["fullCost"] == operating + fees + refunds + construction, "native_full_cost_mapping:" + str(key))
            after = gross - operating - fees - refunds - construction - row["protectedReserveMinor"] - row["protectedObligationsMinor"]
            check(ledger["summary"]["scenario"]["availableSurplus"] == max(0, after), "native_surplus_no_seed:" + str(key))
            for event in ledger["ledger"]["events"]:
                if event.get("category") == "collected":
                    check(event["amountMinor"] is None and event["basis"] == "unknown", "no_simulation_in_observed_channel:" + str(key))
            if row["constructionCashPaidMinor"]:
                paid_months.append(month)
                check(row["decision"] == "CONSTRUCT_SIMULATED", "paid_decision:" + str(key))
                check(row["investment"]["paysBackWithinHorizon"], "finite_horizon_gate:" + str(key))
                check(row["allocationEligibleBeforeInvestmentMinor"] >= row["constructionCashPaidMinor"], "earned_surplus_allocation_gate:" + str(key))
                check(projected["candidateBudget"]["constructionMinutes"] <= projected["candidateBudget"]["availableConstructionMinutes"], "time_gate:" + str(key))
            if projected["constructionMonth"] is None or month < projected["benefitStart"] or c["qualification"] == "assumed-fail":
                check(row["realizedAssumedSavingMinor"] == row["upkeepMinor"] == 0, "no_early_or_failed_benefit:" + str(key))
            check(row["cumulativeBenefitAfterConstructionMinor"] == savings - upkeep - construction, "capability_benefit_balance:" + str(key))
            if construction > 0 and savings - upkeep - construction >= 0:
                payback_months.append(month)
        check(len(paid_months) <= 1, "one_candidate_package:" + str(key))
        check(projected["constructionMonth"] == (paid_months[0] if paid_months else None), "construction_summary:" + str(key))
        check(projected["firstPaybackMonth"] == (payback_months[0] if payback_months else None), "payback_summary:" + str(key))
        check(projected["finalCashMinor"] == cash and projected["finalReceivablesMinor"] == receivable, "final_projection_balances:" + str(key))
        check(projected["netCapabilityBenefitMinor"] == savings - upkeep - construction, "net_benefit_summary:" + str(key))
        check(projected["externalSeedMinor"] + gross - operating - fees - refunds - construction == cash, "lifetime_cash_conservation:" + str(key))
        financial_rows.append({"id": case_id, "ceilingBps": ceiling,
                               "constructionMonth": projected["constructionMonth"],
                               "firstPaybackMonth": projected["firstPaybackMonth"],
                               "netHypotheticalCapabilityBenefitUSD": projected["netCapabilityBenefitMinor"] / 100,
                               "checks": "PASS"})

    return {
        "status": "PASS",
        "scope": "Independent Python exact-rational arithmetic and conservation review of exported frozen outputs. Same supervising research session, not external peer review.",
        "metricsSHA256": reproduction["metricsSHA256"],
        "frozenSourceSHA256": reproduction["sourceSHA256"],
        "checksByFamily": dict(checks),
        "totalAssertions": sum(checks.values()),
        "costRows": cost_rows,
        "financialRows": financial_rows,
        "financialPeriodDecisions": dict(decisions),
        "actualMonetaryCost": None,
        "actualCollections": None,
        "limitations": [
            "Arithmetic validity does not validate assumed human minutes, demand, prices or costs.",
            "The 31 unique training examples are one learned episode; 93 calls across three development executions are engineering validation, not independent evidence.",
            "The modeled common setup allowance covers engineering and repeated validation; actual attention and billing remain unknown.",
            "Synthetic label queries are not measured human labeling effort; the proportional four-mission/schema workload extension is assumed.",
            "Finance paths concern a hypothetical future capability, not demonstrated benefits of the retained recipe.",
            "This audit does not clear deployment, authenticated-execution, finance or authority gates."
        ],
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists():
        raise SystemExit("Preserve prior audit; choose a new output file")
    result = audit(Path(__file__).resolve().parent, args.results.resolve())
    args.out.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"status": result["status"], "assertions": result["totalAssertions"],
                      "costRows": len(result["costRows"]), "financePaths": len(result["financialRows"])}))
