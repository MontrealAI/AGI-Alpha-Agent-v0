// SPDX-License-Identifier: Apache-2.0
// Additive reporting correction.  Does not change or rerun the frozen analysis.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';

const here=path.dirname(fileURLToPath(import.meta.url));
const digest=bytes=>createHash('sha256').update(bytes).digest('hex');
const read=file=>JSON.parse(fs.readFileSync(file,'utf8'));
const args=process.argv.slice(2);
assert(args.length===4 && args[0]==='--results' && args[2]==='--out',
  'Use --results ORIGINAL_RESULT_DIRECTORY --out NEW_FILE');
const input=path.resolve(args[1]),out=path.resolve(args[3]);
assert(!fs.existsSync(out),'Preserve prior reporting output; choose a new path');
const metricsBytes=fs.readFileSync(path.join(input,'metrics-input.json'));
const metrics=JSON.parse(metricsBytes),original=read(path.join(input,'summary.json'));
const reproduction=read(path.join(input,'REPRODUCTION.json'));
const assumptions=read(path.join(here,'assumptions.json'));
assert.equal(digest(metricsBytes),reproduction.metricsSHA256);
assert.equal(digest(fs.readFileSync(path.join(here,'analyze.mjs'))),reproduction.sourceSHA256,
  'Frozen original analyzer must remain unchanged');
assert.equal(digest(fs.readFileSync(path.join(here,'assumptions.json'))),reproduction.assumptionsSHA256);
const cpuKeys=['constructionCpuMs','productionCpuMs','verificationCpuMs','packagingCpuMs'];
const wallKeys=['constructionWallMs','productionWallMs','verificationWallMs','packagingWallMs'];
const sumOrUnknown=values=>values.every(x=>Number.isFinite(x)&&x>=0)?values.reduce((s,x)=>s+x,0):null;
const resources=Object.fromEntries(Object.entries(metrics.arms).map(([name,arm])=>{
  const recordedCpuMs=sumOrUnknown(cpuKeys.map(key=>arm[key]));
  const stageWallMs=sumOrUnknown(wallKeys.map(key=>arm[key]));
  if(stageWallMs!==null && Number.isFinite(arm.wallMs))
    assert(Math.abs(stageWallMs-arm.wallMs)<1e-6,'Whole mission wall scope must equal the supplied stage spans');
  return [name,{
    ...Object.fromEntries(cpuKeys.concat(wallKeys).map(key=>[key,Number.isFinite(arm[key])?arm[key]:null])),
    recordedCpuMs,
    completeExecutionCpuMs:null,
    unmeasuredCpuComponents:['Python verifier process startup and teardown, and work outside the recorded CPU spans'],
    wholeMissionWallMs:Number.isFinite(arm.wallMs)?arm.wallMs:null,
    wallScope:'Supplied complete construction, production, verification and packaging spans; verification wall includes Python process launch.',
    assumedUSDPerRecordedCPUHour:assumptions.compute_proration_usd_per_cpu_hour,
    illustrativeProratedRecordedCpuUSD:recordedCpuMs===null?null:recordedCpuMs/3600000*assumptions.compute_proration_usd_per_cpu_hour,
    actualBilledComputeUSD:null,
    actualModelBillingUSD:null,
    supersededOriginalAllAttemptCpuMs:original.measuredResources[name].allAttemptCpuMs,
    packagingCpuAddedMs:Number.isFinite(arm.packagingCpuMs)?arm.packagingCpuMs:null,
    interpretation:'Partial recorded CPU is not complete CPU or billed compute. Proration is illustrative and cannot promote a candidate. Whole-session modeled charges already cover all stages and subprocess verification wall, so no primary monetary outcome changes.'
  }];
}));
fs.writeFileSync(out,JSON.stringify({
  status:'ADDITIVE_AUXILIARY_REPORTING_CORRECTION_V1_1',
  correction:'Original descriptive resource totals omitted packaging CPU and were misleadingly named allAttemptCpuMs. This adds packaging and explicitly retains complete CPU as unknown because process-startup CPU is unmeasured.',
  originalResultsPreserved:true,primaryCriteriaOrOutcomesChanged:false,costAssumptionsChanged:false,
  costTiersChanged:false,financialPathsChanged:false,
  originalMetricsSHA256:reproduction.metricsSHA256,originalFrozenSourceSHA256:reproduction.sourceSHA256,
  reportingSourceSHA256:digest(fs.readFileSync(fileURLToPath(import.meta.url))),
  resources,
  usage:'Use this auxiliary resource report instead of results-v1/summary.json measuredResources for manuscript CPU descriptions. Continue using the original cost, incremental and financial results unchanged.'
},null,2)+'\n');
console.log(JSON.stringify({status:'ADDITIVE_AUXILIARY_REPORTING_CORRECTION_V1_1',arms:Object.keys(resources).length,
  primaryEconomicsUnchanged:true}));
