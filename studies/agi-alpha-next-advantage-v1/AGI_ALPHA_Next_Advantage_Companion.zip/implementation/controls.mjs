// SPDX-License-Identifier: Apache-2.0
import assert from 'node:assert/strict';
import {transform, synthesize, prepareRows} from './synthesis.mjs';
let checks = 0;
for (const [s, op, expected] of [['12.34', 'major-dot', 1234], ['12,34 EUR', 'major-comma', 1234], ['$ 0.05', 'major-dot', 5],
  ['12 pièces', 'units-suffix', 12], ['x6', 'units-prefix', 6], ['2 semaines', 'weeks-suffix', 14], ['7 jours', 'days-suffix', 7], [' usd ', 'currency', 'USD']]) {
  assert.equal(transform(s, op), expected); checks++;
}
for (const [s, op] of [['1,234.00', 'major-dot'], ['-1', 'minor'], ['1e3', 'minor'], ['12.345', 'major-dot'], ['01', 'integer'], ['5 weeksx', 'weeks-suffix']]) {
  assert.throws(() => transform(s, op)); checks++;
}
const task = {id: 'smoke', headers: ['a', 'b', 'c', 'd', 'e', 'f'], pool: [['K-1', 'V-1', 'x6', '12,34 EUR', 'EUR', '2 weeks']]};
const label = {item: 'K-1', vendor: 'V-1', pack_units: 6, pack_price_minor: 1234, currency: 'EUR', lead_days: 14};
const out = await synthesize(task, async () => label);
assert.equal(out.status, 'CONSTRUCTED'); checks++;
assert.deepEqual(prepareRows(out.program, task.headers, task.pool), [label]); checks++;
assert.throws(() => prepareRows(out.program, task.headers, [task.pool[0], task.pool[0]]), /DUPLICATE/); checks++;
assert.throws(() => prepareRows(out.program, task.headers, [['K-1', 'V-1', 'x6', '12,34 CAD', 'EUR', '2 weeks']]), /CURRENCY/); checks++;
const ambiguous = {...task, headers: [...task.headers, 'g'], pool: [task.pool[0].concat('K-1')]};
assert.equal((await synthesize(ambiguous, async () => label)).status, 'REFUSED'); checks++;
assert.equal((await synthesize(task, async () => label, {maxEvaluations: 1})).reason, 'CANDIDATE_BUDGET'); checks++;
assert.equal((await synthesize(task, async () => label, {signal: {aborted: true}})).reason, 'CANCELLED'); checks++;
console.log(JSON.stringify({checks, passed: checks, scope: 'Finite grammar and meaningful refusal controls; separate from held-out results.'}));
