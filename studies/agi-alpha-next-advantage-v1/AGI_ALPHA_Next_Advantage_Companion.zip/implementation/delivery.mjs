// SPDX-License-Identifier: Apache-2.0
import {createWorkbench, example} from '../vendor/alpha/examples/successor-workbench/engine.mjs';
import {quoteAdapter, normalizeQuotes, subsetSolve, enumerationSolve} from '../vendor/awe/adapters.mjs';
import {prepareRows, validateTable, validateProgram, stable, sha256} from './synthesis.mjs';

const json = (name, value) => ({name, type: 'application/json', content: JSON.stringify(value, null, 2) + '\n'});
export function makeAdapter(program) {
  return {manifest: {id: 'next-advantage-quotes', version: 1,
    en: 'Prepare and compare supplier quotes', fr: 'Préparer et comparer des devis',
    scope: 'Declared finite input transformations and the unchanged exact fixed-shipping quote solver.', artifact: 'quote-report.md'},
  validate(input) {
    if (!input || !input.context || !input.headers || !input.rows) throw Error('MISSION_INPUT');
    validateTable(input.headers, input.rows); validateProgram(program, input.headers);
    const offers = prepareRows(program, input.headers, input.rows);
    normalizeQuotes({...input.context, offers});
  },
  async execute(input, checkpoint) {
    await checkpoint('applying-constructed-adapter');
    const offers = prepareRows(program, input.headers, input.rows);
    const output = await quoteAdapter.execute({...input.context, offers}, checkpoint);
    return {...output, artifacts: [...output.artifacts, json('constructed-adapter.json', program), json('prepared-offers.json', offers)],
      evidence: {...output.evidence, preparation: {method: 'executed derived finite program', programHash: await sha256(stable(program)), rows: offers.length}},
      limits: [...output.limits, 'Input adapter identification is relative to the declared grammar and examples. Silent semantic drift requires renewed examples and can remain undetectable from syntax.']};
  }};
}
export async function deliver(mission, program, {sourceHash, signal, onProgress = () => {}} = {}) {
  const adapter = makeAdapter(program), runtime = createWorkbench([adapter]);
  const spec = {...example(), family: adapter.manifest.id, name: 'Build the Next Advantage', reviewMinutes: 10,
    rights: {dataClass: 'synthetic', source: 'Frozen independent synthetic quote fixture ' + mission.id, license: 'Apache-2.0'},
    inputs: {headers: mission.headers, rows: mission.rows, context: mission.context}};
  const pack = await runtime.run(spec, {sourceHash, signal, onProgress});
  const integrity = await runtime.inspectPack(pack);
  return {pack, integrity};
}
export function localCrosscheck(mission, program) {
  const offers = prepareRows(program, mission.headers, mission.rows);
  const n = normalizeQuotes({...mission.context, offers}), selected = subsetSolve(n), reference = enumerationSolve(n);
  return {scope: 'LOCAL_ALGORITHMIC_CROSSCHECK_NOT_INDEPENDENT_SCHEMA_TRUTH',
    correctOptimum: reference.total_minor === selected.total_minor,
    comparisons: reference.states_visited, totalMinor: selected.total_minor,
    limitation: 'Two algorithms share prepared inputs. The separate recorded Python audit also checks canonical input truth.'};
}
