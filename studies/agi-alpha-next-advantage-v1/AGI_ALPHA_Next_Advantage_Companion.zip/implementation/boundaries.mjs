// SPDX-License-Identifier: Apache-2.0
import {readFile, writeFile, mkdir, readdir} from 'node:fs/promises';
import {synthesize} from './synthesis.mjs';
import {deliver} from './delivery.mjs';
const read = async p => JSON.parse(await readFile(p, 'utf8'));
const recipe = await read('implementation/learned-recipe.json');
const sourceHash = (await read('results/confirmation-v1/raw-summary.json')).source.hash;
const rows = [];
for (const name of (await readdir('evaluation/sealed/boundaries')).sort()) {
  if (!name.endsWith('.json')) continue;
  const probe = await read('evaluation/sealed/boundaries/' + name);
  for (const strategy of ['sequential', 'active', 'retained']) {
    const start = performance.now();
    let refused = false, reason = null, metrics = null;
    try {
      if (probe.stage === 'construction') {
        const value = await synthesize(probe.task, async i => probe.labels[i], {strategy, weights: recipe.weights});
        refused = value.status === 'REFUSED'; reason = value.reason || null; metrics = value.metrics;
      } else {
        const task = await read('evaluation/sealed/confirmation/' + probe.mission.schema_id + '.task.json');
        const program = {schema: 'alpha-example-adapter/v1', headers: task.headers, fields: probe.program};
        await deliver(probe.mission, program, {sourceHash});
      }
    } catch (error) { refused = true; reason = error.message; }
    rows.push({id: probe.id, category: probe.category, stage: probe.stage, strategy, expected: probe.expected,
      refused, passed: refused === (probe.expected === 'REFUSE'), reason, metrics, wallMs: performance.now() - start});
  }
}
await mkdir('results/boundaries-v1');
await writeFile('results/boundaries-v1/results.json', JSON.stringify({uniqueProbes: new Set(rows.map(r => r.id)).size,
  repeatedEvaluations: rows.length, passed: rows.filter(r => r.passed).length, rows,
  scope: 'Finite declared boundary probes, separate from useful delivered jobs.'}, null, 2) + '\n');
console.log(JSON.stringify({probes: new Set(rows.map(r => r.id)).size, evaluations: rows.length, passed: rows.filter(r => r.passed).length, failures: rows.filter(r => !r.passed)}));
