// SPDX-License-Identifier: Apache-2.0
import {readFile, writeFile, mkdir} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
import {createWorkbench, example} from '../vendor/alpha/examples/successor-workbench/engine.mjs';
import {quoteAdapter} from '../vendor/awe/adapters.mjs';
import {appendEvent, replayLedger} from '../vendor/shared/shadow-ledger.mjs';
import {synthesize, sha256, stable} from './synthesis.mjs';
import {deliver} from './delivery.mjs';
const read = async p => JSON.parse(await readFile(p, 'utf8'));
const directory = process.argv[2] || 'results/connected-loop-v1';
if (!/^results\/[a-z0-9-]+$/.test(directory)) throw Error('OUTPUT_SCOPE');
await mkdir(directory);
const events = [], sourceHash = (await read('results/confirmation-v1/raw-summary.json')).source.hash;
const save = async (name, value) => writeFile(directory + '/' + name, JSON.stringify(value, null, 2) + '\n');
const event = (stage, action, artifact, status) => events.push({sequence: events.length + 1, atUtc: new Date().toISOString(), stage, action, artifact, status});
const initial = (await read('evaluation/development/D01.expected.json')).canonical;
const runtime = createWorkbench([quoteAdapter]);
const spec = {...example(), family: quoteAdapter.manifest.id, inputs: initial};
event('Identify', 'Select a bounded complete quote comparison using the established canonical input contract.', 'seed-input.json', 'EXECUTED');
const seed = await runtime.run(spec, {sourceHash});
await save('seed-input.json', initial); await save('seed-pack.json', seed);
const check = spawnSync('python3', ['evaluation/oracle.py', directory + '/seed-input.json', directory + '/seed-pack.json'], {encoding: 'utf8', timeout: 30000});
if (check.status !== 0 || !JSON.parse(check.stdout).accepted) throw Error('SEED_VERIFICATION');
await save('seed-independent-check.json', JSON.parse(check.stdout));
event('Out-Execute', 'Produce and independently verify the useful seed deliverable with the unchanged existing adapter.', 'seed-pack.json', 'ACCEPTED_LOCAL_RESEARCH');
const task = await read('evaluation/sealed/confirmation/H01.task.json'), labels = (await read('evaluation/sealed/confirmation/H01.truth.json')).labels;
const firstMission = await read('evaluation/sealed/production/H01-M1.input.json');
let limitation;
try { quoteAdapter.validate({...firstMission.context, headers: firstMission.headers, rows: firstMission.rows}); }
catch (error) { limitation = {reason: error.message, inputContract: 'Existing quote workflow requires canonical offers; raw table is unsupported.', notABenchmarkWin: true}; }
if (!limitation) throw Error('EXPECTED_EXISTING_INPUT_BOUNDARY');
await save('observed-limitation.json', limitation);
event('Out-Learn', 'Record the actual preparation boundary encountered by the existing workflow.', 'observed-limitation.json', 'LIMITATION_RECORDED');
event('Out-Think', 'Choose finite example-driven adapter construction; retain the exact quote specialist.', 'construction.json', 'BOUNDED_OPPORTUNITY');
const construction = await synthesize(task, async i => labels[i], {strategy: 'active'});
await save('construction.json', construction);
if (!construction.program) throw Error('NO_CAPABILITY');
await save('program.json', construction.program);
event('Out-Design', 'Execute the generic constructor on budgeted mission examples and emit a declarative program.', 'program.json', 'CONSTRUCTED');
event('Out-Strategise', 'Keep conventional active selection after the frozen recipe comparison tied; avoid additional recipe overhead.', 'construction.json', 'INCUMBENT_RETAINED');
let ledger = {schema: 'alpha-shadow-ledger/v1', currency: 'USD', events: []};
for (const [index, mission] of [firstMission, await read('evaluation/sealed/production/H01-M2.input.json')].entries()) {
  const name = index ? 'next' : 'qualification', result = await deliver(mission, construction.program, {sourceHash});
  await save(name + '-pack.json', result.pack);
  const validation = spawnSync('python3', ['implementation/evaluate_one.py', 'evaluation/sealed/production/' + mission.id + '.truth.json', directory + '/' + name + '-pack.json'], {encoding: 'utf8', timeout: 30000});
  if (validation.status !== 0) throw Error('CHECKER_ERROR');
  const accepted = JSON.parse(validation.stdout); await save(name + '-independent-check.json', accepted);
  if (!accepted.accepted) throw Error('QUALIFICATION_FAILED');
  event(index ? 'Out-Evolve' : 'Out-Execute', index ? 'Apply the admitted program to the next fresh mission and verify it.' : 'Run the first fresh qualification mission and verify every prepared value and complete report.', name + '-pack.json', 'ACCEPTED_LOCAL_RESEARCH');
  ledger = appendEvent(ledger, {id: mission.id + ':mission', type: 'mission', missionId: mission.id, reference: directory + '/' + name + '-pack.json', acceptance: 'accepted'});
  for (const [type, category] of [['revenue','collected'],['cost','delivery'],['reserve','reliability'],['obligation','unpaid']])
    ledger = appendEvent(ledger, {id: mission.id + ':' + type, type, missionId: mission.id, reference: 'Actual monetary amount unmeasured; no customer transaction occurred.', category, basis: 'unknown', amountMinor: null});
  ledger = appendEvent(ledger, {id: mission.id + ':capability', type: 'capability', missionId: mission.id,
    reference: 'Technical research scope only; economic promotion HOLD.', capabilityId: 'H01-input-adapter', action: index ? 'invoked' : 'admitted'});
  await save('ledger-after-' + name + '.json', {ledger, evaluation: replayLedger(ledger)});
}
event('Out-Evolve', 'Consult the shared ledger: actual available surplus is unknown; stop real financial succession. Keep hypothetical financing in the separately labeled scenario record.', 'ledger-after-next.json', 'FINANCIAL_HOLD');
await save('stage-events.json', events);
await save('execution-inventory.json', {seed: 'EXECUTED', construction: 'EXECUTED', qualification: 'EXECUTED', reuse: 'EXECUTED',
  realFinancialSuccession: 'NOT_RUN', modeledFinancialSuccession: 'economics/results-v1', persistentOperation: 'NOT_RUN',
  interpretation: 'Connected inspectable replay of frozen study cases, not an additional independent confirmatory sample or customer operation.', sourceHash});
console.log(JSON.stringify({stages: events.length, technicalLoop: 'EXECUTED', financialAction: 'NOT_RUN', directory}));
