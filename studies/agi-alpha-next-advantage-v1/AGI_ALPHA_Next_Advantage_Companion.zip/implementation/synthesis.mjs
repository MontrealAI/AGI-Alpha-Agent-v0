// SPDX-License-Identifier: Apache-2.0
// Generic finite program search. No schema-specific mapping is authored here.
export const FIELDS = Object.freeze(['item', 'vendor', 'pack_units', 'pack_price_minor', 'currency', 'lead_days']);
export const GRAMMAR = Object.freeze({item: ['text'], vendor: ['text'], pack_units: ['integer', 'units-suffix', 'units-prefix'],
  pack_price_minor: ['minor', 'major-dot', 'major-comma'], currency: ['currency'], lead_days: ['integer', 'days-suffix', 'weeks-suffix']});
export const LIMITS = Object.freeze({labels: 8, evaluations: 200000, pool: 16, rows: 160, headers: 10});
const integerPattern = '(0|[1-9][0-9]*)';
const own = (v, k) => Object.hasOwn(v, k);
export const stable = value => JSON.stringify(value, (_k, v) => v && typeof v === 'object' && !Array.isArray(v)
  ? Object.fromEntries(Object.keys(v).sort().map(k => [k, v[k]])) : v);
export async function sha256(value) {
  const bytes = typeof value === 'string' ? new TextEncoder().encode(value) : value;
  return [...new Uint8Array(await crypto.subtle.digest('SHA-256', bytes))].map(v => v.toString(16).padStart(2, '0')).join('');
}
function bounded(value, low, high) {
  if (!Number.isSafeInteger(value) || value < low || value > high) throw Error('VALUE_BOUNDS');
  return value;
}
function moneyCore(raw, separator) {
  if (/^[$€]/.test(raw) && /\s[A-Za-z]{3}$/.test(raw)) throw Error('DUAL_CURRENCY_AFFIX');
  const match = new RegExp('^(?:[$€]\\s*)?' + integerPattern + '\\' + separator + '([0-9]{2})(?:\\s+[A-Za-z]{3})?$').exec(raw);
  if (!match) throw Error('MONEY_FORMAT');
  return bounded(Number(match[1]) * 100 + Number(match[2]), 0, 100000000);
}
export function transform(raw, op) {
  if (typeof raw !== 'string' || raw.length > 240) throw Error('CELL_TYPE');
  const value = raw.trim();
  let match;
  if (op === 'text') { if (!value || value.length > 60 || /[\u0000-\u001f]/.test(value)) throw Error('TEXT_BOUNDS'); return value; }
  if (op === 'currency') { if (!/^[A-Za-z]{3}$/.test(value)) throw Error('CURRENCY_FORMAT'); return value.toUpperCase(); }
  if (op === 'integer' || op === 'minor') {
    if (!/^(0|[1-9][0-9]*)$/.test(value)) throw Error('INTEGER_FORMAT');
    return bounded(Number(value), 0, 100000000);
  }
  if (op === 'major-dot') return moneyCore(value, '.');
  if (op === 'major-comma') return moneyCore(value, ',');
  if (op === 'units-suffix') match = /^(0|[1-9][0-9]*)\s+(?:units?|pack|pcs|pièces)$/i.exec(value);
  else if (op === 'units-prefix') match = /^[xX](0|[1-9][0-9]*)$/.exec(value);
  else if (op === 'days-suffix') match = /^(0|[1-9][0-9]*)\s+(?:days?|jours?)$/i.exec(value);
  else if (op === 'weeks-suffix') match = /^(0|[1-9][0-9]*)\s+(?:weeks?|semaines?)$/i.exec(value);
  else throw Error('OP_NOT_ALLOWED');
  if (!match) throw Error('UNIT_FORMAT');
  return bounded(Number(match[1]) * (op === 'weeks-suffix' ? 7 : 1), 0, 100000000);
}
function fieldValue(value, field) {
  if (field === 'pack_units') return bounded(value, 1, 10000);
  if (field === 'lead_days') return bounded(value, 0, 365);
  if (field === 'pack_price_minor') return bounded(value, 0, 100000000);
  return value;
}
export function validateTable(headers, rows, pool = false) {
  if (!Array.isArray(headers) || headers.length < 6 || headers.length > LIMITS.headers || new Set(headers).size !== headers.length ||
      headers.some(h => typeof h !== 'string' || !h.trim() || h.length > 80 || /[\u0000-\u001f]/.test(h))) throw Error('HEADERS');
  if (!Array.isArray(rows) || !rows.length || rows.length > (pool ? LIMITS.pool : LIMITS.rows) ||
      rows.some(r => !Array.isArray(r) || r.length !== headers.length || r.some(c => typeof c !== 'string' || c.length > 240))) throw Error('ROWS');
}
export function validateProgram(program, headers) {
  if (!program || program.schema !== 'alpha-example-adapter/v1' || !program.fields ||
      Object.keys(program.fields).sort().join() !== [...FIELDS].sort().join() || !Array.isArray(program.headers) ||
      [...program.headers].sort().join('\0') !== [...headers].sort().join('\0')) throw Error('PROGRAM_SCHEMA');
  for (const field of FIELDS) {
    const expression = program.fields[field];
    if (!expression || Object.keys(expression).sort().join() !== 'column,op' || !headers.includes(expression.column) ||
        !GRAMMAR[field].includes(expression.op)) throw Error('PROGRAM_EXPRESSION');
  }
}
export function prepareRows(program, headers, rows) {
  validateTable(headers, rows); validateProgram(program, headers);
  const seen = new Set();
  return rows.map(row => {
    const offer = Object.fromEntries(FIELDS.map(field => {
      const expr = program.fields[field];
      return [field, fieldValue(transform(row[headers.indexOf(expr.column)], expr.op), field)];
    }));
    const price = row[headers.indexOf(program.fields.pack_price_minor.column)].trim();
    const affix = /\s([A-Za-z]{3})$/.exec(price);
    if ((affix && affix[1].toUpperCase() !== offer.currency) || (price.startsWith('$') && offer.currency !== 'USD') ||
        (price.startsWith('€') && offer.currency !== 'EUR')) throw Error('CURRENCY_AFFIX_CONFLICT');
    const key = stable([offer.item, offer.vendor]);
    if (seen.has(key)) throw Error('DUPLICATE_OFFER');
    seen.add(key);
    return offer;
  });
}
function labelValid(label) {
  if (!label || Object.keys(label).sort().join() !== [...FIELDS].sort().join()) throw Error('LABEL_SCHEMA');
  for (const field of FIELDS) {
    fieldValue(label[field], field);
    if (['item', 'vendor', 'currency'].includes(field) && typeof label[field] !== 'string') throw Error('LABEL_TYPE');
  }
}
export async function synthesize(task, oracle, {strategy = 'sequential', weights = {}, signal,
  maxLabels = LIMITS.labels, maxEvaluations = LIMITS.evaluations} = {}) {
  validateTable(task.headers, task.pool, true);
  if (!['sequential', 'active', 'retained'].includes(strategy)) throw Error('STRATEGY');
  const metrics = {labelQueries: 0, candidateEvaluations: 0, selectionOperations: 0, initialCandidates: 0};
  const trace = [], queried = new Set(), spaces = {}, start = performance.now();
  const tick = () => { if (signal?.aborted) throw Error('CANCELLED'); if (++metrics.candidateEvaluations > maxEvaluations) throw Error('CANDIDATE_BUDGET'); };
  try {
    for (const field of FIELDS) {
      spaces[field] = [];
      for (let columnIndex = 0; columnIndex < task.headers.length; columnIndex++) for (const op of GRAMMAR[field]) {
        const values = []; let valid = true;
        for (const row of task.pool) {
          tick();
          try { values.push(fieldValue(transform(row[columnIndex], op), field)); } catch { valid = false; break; }
        }
        if (valid) spaces[field].push({expression: {column: task.headers[columnIndex], op}, values});
      }
      metrics.initialCandidates += spaces[field].length;
    }
    trace.push({stage: 'typed-enumeration', remaining: Object.fromEntries(FIELDS.map(f => [f, spaces[f].length])),
      hypotheses: Object.fromEntries(FIELDS.map(f => [f, spaces[f].map(c => c.expression)]))});
    while (metrics.labelQueries < Math.min(maxLabels, task.pool.length)) {
      if (signal?.aborted) throw Error('CANCELLED');
      if (FIELDS.some(f => !spaces[f].length)) throw Error('CONTRADICTION_OR_UNSUPPORTED');
      if (FIELDS.every(f => spaces[f].length === 1) && metrics.labelQueries >= 1) break;
      let index = task.pool.findIndex((_r, i) => !queried.has(i));
      let best = -1;
      if (strategy !== 'sequential') for (let i = 0; i < task.pool.length; i++) {
        if (queried.has(i)) continue;
        let score = 0;
        for (const field of FIELDS) {
          const space = spaces[field], groups = new Map();
          for (const candidate of space) { const key = stable(candidate.values[i]); groups.set(key, (groups.get(key) || 0) + 1); metrics.selectionOperations++; }
          const disagreement = space.length * space.length - [...groups.values()].reduce((s, n) => s + n * n, 0);
          const weight = strategy === 'retained' ? (weights[field] ?? 1) : 1;
          if (!Number.isFinite(weight) || weight <= 0 || weight > 100) throw Error('RECIPE_WEIGHT');
          score += weight * disagreement / Math.max(1, space.length * space.length);
        }
        if (score > best) { best = score; index = i; }
      }
      const label = await oracle(index);
      labelValid(label); queried.add(index); metrics.labelQueries++;
      const before = Object.fromEntries(FIELDS.map(f => [f, spaces[f].length]));
      for (const field of FIELDS) spaces[field] = spaces[field].filter(candidate => {
        tick(); return candidate.values[index] === label[field];
      });
      trace.push({stage: 'worked-example', rowIndex: index, label, before,
        remaining: Object.fromEntries(FIELDS.map(f => [f, spaces[f].length])), eliminated: Object.fromEntries(FIELDS.map(f => [f, before[f] - spaces[f].length]))});
    }
    if (FIELDS.some(f => !spaces[f].length)) throw Error('CONTRADICTION_OR_UNSUPPORTED');
    if (FIELDS.some(f => spaces[f].length !== 1)) throw Error('AMBIGUOUS_WITHIN_BUDGET');
    const program = {schema: 'alpha-example-adapter/v1', headers: [...task.headers],
      fields: Object.fromEntries(FIELDS.map(f => [f, spaces[f][0].expression]))};
    return {status: 'CONSTRUCTED', program, programHash: await sha256(stable(program)), metrics, trace,
      wallMs: performance.now() - start, semantics: 'Finite typed example-driven construction; no algorithmic invention claim.'};
  } catch (error) {
    return {status: 'REFUSED', reason: error.message, program: null, metrics, trace, wallMs: performance.now() - start};
  }
}
export function deriveRecipe(developmentTraces) {
  const difficulty = Object.fromEntries(FIELDS.map(f => [f, 0]));
  for (const run of developmentTraces) for (const event of run.trace.filter(e => e.stage === 'worked-example'))
    for (const field of FIELDS) difficulty[field] += Math.max(0, event.remaining[field] - 1);
  const scale = Math.max(1, ...Object.values(difficulty));
  return {schema: 'alpha-construction-recipe/v1', construction: 'weights derived from observed unresolved field alternatives after development labels',
    weights: Object.fromEntries(FIELDS.map(f => [f, 1 + Math.round(7 * difficulty[f] / scale)])),
    evidenceCounts: difficulty, developmentTasks: developmentTraces.length,
    status: 'RESEARCH_CANDIDATE', algorithmicNovelty: false, inference: 'Emphasizes fields that consumed extra examples in development; transfer is tested, not presumed.'};
}
