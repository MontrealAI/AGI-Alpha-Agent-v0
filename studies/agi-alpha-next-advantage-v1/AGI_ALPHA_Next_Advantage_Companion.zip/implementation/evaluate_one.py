# SPDX-License-Identifier: Apache-2.0
import json, sys, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / 'evaluation'))
from oracle import verify_pack, verify_canonical

start = time.process_time_ns()
expected = json.loads(Path(sys.argv[1]).read_text())
pack = json.loads(Path(sys.argv[2]).read_text())
result = verify_pack(expected['canonical'], pack)
artifacts = {x['name']: x for x in pack['result']['artifacts']}
prepared = json.loads(artifacts['prepared-offers.json']['content']) if 'prepared-offers.json' in artifacts else None
result['findings'].extend(verify_canonical(expected['canonical']['offers'], prepared))
result['accepted'] = not result['findings']
result['verifierCpuMs'] = (time.process_time_ns() - start) / 1e6
result['scope'] = 'SEPARATE_PYTHON_CANONICAL_INPUT_AND_COMPLETE_CART_ARTIFACT_CHECK'
print(json.dumps(result))
