// SPDX-License-Identifier: Apache-2.0
// Additive reproduction only: never writes the frozen recipe or historical runs.
import assert from 'node:assert/strict';
import {readFile, readdir, mkdir, writeFile} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {synthesize, deriveRecipe, sha256, stable} from './synthesis.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const destination = 'results/development-replay-v2';
const read = async name => JSON.parse(await readFile(path.join(root, name), 'utf8'));
const save = async (name, value) => writeFile(path.join(root, destination, name), JSON.stringify(value, null, 2) + '\n');
const cpuMs = before => {const elapsed = process.cpuUsage(before); return (elapsed.user + elapsed.system) / 1000;};

await mkdir(path.join(root, destination));
const names = (await readdir(path.join(root, 'evaluation/development'))).filter(name => /^D\d{2}\.task\.json$/.test(name)).sort();
assert.equal(names.length, 12, 'Expected the twelve public development schemas');
const runs = [], measures = [];
for (const name of names) {
  const task = await read('evaluation/development/' + name);
  const labels = (await read('evaluation/development/' + name.replace('.task.', '.labels.'))).labels;
  const beforeCpu = process.cpuUsage(), beforeWall = performance.now();
  const value = await synthesize(task, async index => labels[index]);
  const measured = {value, cpuMs: cpuMs(beforeCpu), wallMs: performance.now() - beforeWall};
  runs.push(value);
  measures.push({id: task.id, ...value.metrics, cpuMs: measured.cpuMs, wallMs: measured.wallMs, status: value.status});
  await save(task.id + '.construction.json', measured);
}

// Derive directly from the newly produced traces, before reading any recipe.
const beforeCpu = process.cpuUsage(), beforeWall = performance.now();
const recipe = deriveRecipe(runs);
const recipeMeasurement = {cpuMs: cpuMs(beforeCpu), wallMs: performance.now() - beforeWall};
await save('derived-recipe.json', recipe);
const counters = Object.fromEntries(['labelQueries', 'candidateEvaluations', 'selectionOperations', 'initialCandidates']
  .map(key => [key, measures.reduce((sum, row) => sum + row[key], 0)]));
const normalizedRuns = runs.map(({wallMs, ...value}) => value);
const summary = {
  schema: 'development-construction-replay/v1',
  scope: 'Fresh execution of the frozen generic synthesizer and recipe derivation on public development data; additive replay, not a new independent episode.',
  schemas: runs.length, constructed: runs.filter(run => run.status === 'CONSTRUCTED').length,
  measures, counters, recipe, recipeMeasurement,
  training: {labelQueries: counters.labelQueries, candidateEvaluations: counters.candidateEvaluations,
    cpuMs: measures.reduce((sum, row) => sum + row.cpuMs, recipeMeasurement.cpuMs),
    wallMs: measures.reduce((sum, row) => sum + row.wallMs, recipeMeasurement.wallMs),
    selectedRecipe: recipe.weights, authoringCost: null,
    note: 'Development labels and all failed attempts charged; no measured human authoring time.'},
  replayProvenance: {
    synthesisSha256: await sha256(await readFile(path.join(root, 'implementation/synthesis.mjs'))),
    runnerSha256: await sha256(await readFile(fileURLToPath(import.meta.url))),
    learnedFrom: names,
    rawFreshInputTracesSha256: await sha256(stable(runs)),
    logicalFreshInputTracesSha256: await sha256(stable(normalizedRuns)),
    historicalProvenanceReplaced: false,
    explanation: 'Fresh wall times change the raw trace digest. The wrapper compares complete logical traces and the recipe body while preserving historical source/timing provenance.'
  }
};
await save('summary.json', summary);
console.log(JSON.stringify({schemas: summary.schemas, constructed: summary.constructed, ...counters, weights: recipe.weights}));
