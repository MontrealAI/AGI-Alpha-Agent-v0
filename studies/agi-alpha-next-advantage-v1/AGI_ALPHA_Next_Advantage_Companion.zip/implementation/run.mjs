// SPDX-License-Identifier: Apache-2.0
import {readFile, writeFile, mkdir, readdir, rename} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {synthesize, deriveRecipe, stable, sha256} from './synthesis.mjs';
import {deliver} from './delivery.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = async p => JSON.parse(await readFile(path.join(root, p), 'utf8'));
const save = async (p, value) => { const target = path.join(root, p); await mkdir(path.dirname(target), {recursive: true});
  await writeFile(target + '.tmp', JSON.stringify(value, null, 2) + '\n'); await rename(target + '.tmp', target); };
const elapsedCpu = before => { const t = process.cpuUsage(before); return (t.user + t.system) / 1000; };
const duration = async fn => { const c = process.cpuUsage(), s = performance.now(); const value = await fn();
  return {value, cpuMs: elapsedCpu(c), wallMs: performance.now() - s}; };
async function sourceIdentity() {
  const paths = ['implementation/synthesis.mjs', 'implementation/delivery.mjs', 'implementation/run.mjs', 'vendor/SOURCE_MANIFEST.json'];
  const records = [];
  for (const p of paths) records.push({path: p, sha256: await sha256(await readFile(path.join(root, p)))});
  return {files: records, hash: await sha256(stable(records))};
}
async function development() {
  const names = (await readdir(path.join(root, 'evaluation/development'))).filter(n => n.endsWith('.task.json')).sort();
  const runs = [], measures = [];
  for (const name of names) {
    const task = await read('evaluation/development/' + name), labels = (await read('evaluation/development/' + name.replace('.task.', '.labels.'))).labels;
    const m = await duration(() => synthesize(task, async i => labels[i]));
    runs.push(m.value); measures.push({id: task.id, ...m.value.metrics, cpuMs: m.cpuMs, wallMs: m.wallMs, status: m.value.status});
    await save('results/development/' + task.id + '.construction.json', m);
    if (m.value.program) {
      const mission = await read('evaluation/development/' + name.replace('.task.', '.mission.'));
      try { const out = await deliver(mission, m.value.program, {sourceHash: (await sourceIdentity()).hash});
        await save('results/development/' + task.id + '.pack.json', out.pack);
      } catch (error) { await save('results/development/' + task.id + '.delivery-failure.json', {error: error.message}); }
    }
  }
  const start = process.cpuUsage(), t = performance.now(), recipe = deriveRecipe(runs);
  const recipeCpuMs = elapsedCpu(start), recipeWallMs = performance.now() - t;
  recipe.provenance = {source: (await sourceIdentity()).hash, inputTraces: await sha256(stable(runs)), learnedFrom: names};
  await save('implementation/learned-recipe.json', recipe);
  await save('results/development/summary.json', {development: true, measures, recipe,
    training: {labelQueries: measures.reduce((s, r) => s + r.labelQueries, 0),
      candidateEvaluations: measures.reduce((s, r) => s + r.candidateEvaluations, 0),
      cpuMs: measures.reduce((s, r) => s + r.cpuMs, recipeCpuMs), wallMs: measures.reduce((s, r) => s + r.wallMs, recipeWallMs),
      selectedRecipe: recipe.weights, authoringCost: null, note: 'Development labels and all failed attempts charged; no measured human authoring time.'}});
  console.log(JSON.stringify({stage: 'development', schemas: measures.length, constructed: measures.filter(r => r.status === 'CONSTRUCTED').length, recipe: recipe.weights}));
}
async function validateFreeze() {
  const freeze = await read('protocol/FREEZE.json');
  for (const file of freeze.files) if (await sha256(await readFile(path.join(root, file.path))) !== file.sha256) throw Error('FREEZE_MISMATCH ' + file.path);
  return freeze;
}
async function confirmation(runName = 'confirmation-v1') {
  if (!/^[a-z][a-z0-9-]{0,59}$/.test(runName)) throw Error('RUN_NAME');
  await mkdir(path.join(root, 'results', runName));
  const freeze = await validateFreeze(), identity = await sourceIdentity(), recipe = await read('implementation/learned-recipe.json');
  const directory = 'evaluation/sealed/confirmation', production = 'evaluation/sealed/production';
  const names = (await readdir(path.join(root, directory))).filter(n => /^H\d+\.task\.json$/.test(n)).sort();
  if (names.length !== 24) throw Error('CONFIRMATION_COUNT_' + names.length);
  const arms = ['rebuild', 'ordinary_reuse', 'retained', 'active_specialist'];
  const caches = Object.fromEntries(arms.map(a => [a, new Map()])), outcomes = [], constructions = [];
  for (let taskIndex = 0; taskIndex < names.length; taskIndex++) {
    const name = names[taskIndex], task = await read(directory + '/' + name), labels = (await read(directory + '/' + name.replace('.task.', '.truth.'))).labels;
    const missionNames = (await readdir(path.join(root, production))).filter(n => n.startsWith(task.id + '-M') && n.endsWith('.input.json')).sort();
    if (missionNames.length !== 4) throw Error('MISSION_COUNT_' + task.id + '_' + missionNames.length);
    const key = await sha256(stable({headers: task.headers, pool: task.pool, grammarVersion: 1}));
    for (let missionIndex = 0; missionIndex < missionNames.length; missionIndex++) {
      const mission = await read(production + '/' + missionNames[missionIndex]);
      const rotation = (taskIndex + missionIndex) % arms.length;
      for (const arm of [...arms.slice(rotation), ...arms.slice(0, rotation)]) {
        let construction = caches[arm].get(key), reused = Boolean(construction);
        if (!construction || arm === 'rebuild') {
          const strategy = arm === 'retained' ? 'retained' : arm === 'active_specialist' ? 'active' : 'sequential';
          const measured = await duration(() => synthesize(task, async i => labels[i], {strategy, weights: recipe.weights}));
          construction = measured.value;
          constructions.push({arm, task: task.id, mission: mission.id, ...measured});
          await save(`results/${runName}/constructions/${arm}-${mission.id}.json`, {arm, taskId: task.id, missionId: mission.id, ...measured});
          reused = false;
        }
        let row = {arm, taskId: task.id, family: task.family, missionId: mission.id, reused,
          programHash: construction.programHash || null, status: 'REFUSED', reason: construction.reason || null,
          constructionMetrics: reused ? null : construction.metrics, productionCpuMs: 0, productionWallMs: 0,
          sourceHash: identity.hash, independentAcceptance: 'PENDING', fullMonetaryCost: null};
        if (construction.program) {
          const c = process.cpuUsage(), t = performance.now();
          try {
            const result = await deliver(mission, construction.program, {sourceHash: identity.hash});
            row = {...row, status: 'DELIVERED_PENDING_INDEPENDENT_CHECK', reason: null,
              productionCpuMs: elapsedCpu(c), productionWallMs: performance.now() - t,
              totalMinor: result.pack.result.summary.total_minor,
              packPath: `results/${runName}/packs/${arm}-${mission.id}.json`};
            const p = process.cpuUsage(), q = performance.now();
            await save(row.packPath, result.pack);
            row.packagingCpuMs = elapsedCpu(p); row.packagingWallMs = performance.now() - q;
            row.artifactBytes = result.pack.result.artifacts.reduce((s, a) => s + Buffer.byteLength(a.content), 0);
            const v = performance.now();
            const check = spawnSync('python3', [path.join(root, 'implementation/evaluate_one.py'),
              path.join(root, production, missionNames[missionIndex].replace('.input.', '.truth.')), path.join(root, row.packPath)],
              {encoding: 'utf8', timeout: 30000, maxBuffer: 2000000});
            if (check.status !== 0) throw Error('INDEPENDENT_VERIFIER_ERROR ' + check.stderr.slice(0, 300));
            const acceptance = JSON.parse(check.stdout);
            row.verificationWallMs = performance.now() - v; row.verificationCpuMs = acceptance.verifierCpuMs;
            row.independentAcceptance = acceptance.accepted ? 'PASS' : 'FAIL';
            row.status = acceptance.accepted ? 'ACCEPTED' : 'REJECTED_BY_INDEPENDENT_CHECK';
            row.findings = acceptance.findings;
            row.qualification = reused ? 'ADMITTED_PROGRAM_REUSED' : acceptance.accepted ? 'TECHNICAL_ADMISSION_RESEARCH_ONLY' : 'HOLD';
            await save(`results/${runName}/verification/${arm}-${mission.id}.json`, acceptance);
            if (arm !== 'rebuild') caches[arm].set(key, acceptance.accepted ? construction : {...construction, program: null, reason: 'QUALIFICATION_FAILED'});
          } catch (error) { row = {...row, status: 'REFUSED', reason: error.message, productionCpuMs: elapsedCpu(c), productionWallMs: performance.now() - t}; }
        }
        if (arm !== 'rebuild' && !caches[arm].has(key)) caches[arm].set(key, construction.program ? {...construction, program: null, reason: 'QUALIFICATION_FAILED'} : construction);
        outcomes.push(row);
        await save(`results/${runName}/journal/${arm}-${mission.id}.json`, row);
      }
    }
  }
  const summary = {schema: 'research-outcome-summary/v1', source: identity, freezeId: freeze.freezeId,
    operationalStatus: 'BOUNDED_LOCAL_RESEARCH_EXECUTED', providerModelCalls: 0, actualCollections: null,
    observedProviderSpend: 0, fullMonetaryCost: null, outcomes, constructions: constructions.map(({value, ...m}) => ({...m, ...value.metrics, status: value.status})),
    meta: (await read('results/development/summary.json')).training};
  await save(`results/${runName}/raw-summary.json`, summary);
  console.log(JSON.stringify({stage: 'confirmation', runName, records: outcomes.length,
    accepted: outcomes.filter(r => r.status === 'ACCEPTED').length,
    refused: outcomes.filter(r => r.status === 'REFUSED').length, source: identity.hash}));
}
const mode = process.argv[2];
if (mode === 'development') await development();
else if (mode === 'confirm') await confirmation(process.argv[3]);
else throw Error('Usage: node implementation/run.mjs development | confirm [run-name]');
