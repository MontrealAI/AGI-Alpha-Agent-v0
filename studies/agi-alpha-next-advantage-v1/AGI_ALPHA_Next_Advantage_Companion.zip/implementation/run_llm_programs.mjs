// SPDX-License-Identifier: Apache-2.0
import {readFile, writeFile, mkdir} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
import {deliver} from './delivery.mjs';
import {sha256, stable} from './synthesis.mjs';
const directory = 'results/current-llm-v1';
const read = async p => JSON.parse(await readFile(p, 'utf8'));
const bytes = await readFile('agent-baseline/programs.json');
if (await sha256(bytes) !== '804fcb6d229c52b56f5123b4f7c3f55935b095129a59a80958ed112c13132d9e') throw Error('LLM_FREEZE_MISMATCH');
const programs = JSON.parse(bytes), original = await read('results/metrics.json');
await mkdir(directory); await mkdir(directory + '/packs'); await mkdir(directory + '/verification');
const sourceHash = original.source.hash, outcomes = [];
for (const [id, candidate] of Object.entries(programs)) {
  let admitted = false;
  for (let index = 1; index <= 4; index++) {
    const mission = await read(`evaluation/sealed/production/${id}-M${index}.input.json`);
    const row = {arm: 'current_llm', taskId: id, missionId: mission.id, reused: index > 1,
      status: 'REFUSED', independentAcceptance: 'NOT_RUN', programHash: candidate.program ? await sha256(stable(candidate.program)) : null,
      productionCpuMs: 0, productionWallMs: 0, verificationCpuMs: 0, verificationWallMs: 0, packagingCpuMs: 0, packagingWallMs: 0};
    if (!candidate.program || (index > 1 && !admitted)) {row.reason = candidate.reason || 'NO_QUALIFIED_PROGRAM'; outcomes.push(row); continue;}
    const c = process.cpuUsage(), s = performance.now();
    try {
      const value = await deliver(mission, candidate.program, {sourceHash});
      const cpu = process.cpuUsage(c); row.productionCpuMs = (cpu.user + cpu.system) / 1000;
      row.productionWallMs = performance.now() - s;
      row.packPath = directory + '/packs/current_llm-' + mission.id + '.json';
      const pc = process.cpuUsage(), pt = performance.now();
      await writeFile(row.packPath, JSON.stringify(value.pack, null, 2) + '\n');
      const pcd = process.cpuUsage(pc);row.packagingCpuMs = (pcd.user + pcd.system) / 1000;row.packagingWallMs = performance.now() - pt;
      const vt = performance.now();
      const check = spawnSync('python3', ['implementation/evaluate_one.py', `evaluation/sealed/production/${id}-M${index}.truth.json`, row.packPath], {encoding: 'utf8', timeout: 30000});
      if (check.status !== 0) throw Error('VERIFIER_ERROR');
      const result = JSON.parse(check.stdout);row.verificationWallMs = performance.now() - vt;row.verificationCpuMs = result.verifierCpuMs;
      row.independentAcceptance = result.accepted ? 'PASS' : 'FAIL'; row.status = result.accepted ? 'ACCEPTED' : 'REJECTED_BY_INDEPENDENT_CHECK';row.findings = result.findings;
      if (index === 1) admitted = result.accepted;
      row.totalMinor = value.pack.result.summary.total_minor;
      row.qualification = index === 1 ? 'TECHNICAL_QUALIFICATION' : 'ADMITTED_PROGRAM_REUSE';
      await writeFile(directory + '/verification/' + mission.id + '.json', JSON.stringify(result, null, 2) + '\n');
    } catch (error) {row.reason = error.message;}
    outcomes.push(row);
  }
}
const all = Object.values(programs), sum = key => all.reduce((s, r) => s + (r.metrics[key] || 0), 0), sumRows = key => outcomes.reduce((s, r) => s + (r[key] || 0), 0);
const metrics = {missions: outcomes.length, accepted: outcomes.filter(r => r.status === 'ACCEPTED').length,
  refused: outcomes.filter(r => r.status === 'REFUSED').length, incorrectAccepted: 0,
  rejectedByIndependentCheck: outcomes.filter(r => r.status === 'REJECTED_BY_INDEPENDENT_CHECK').length,
  constructions: all.length, labelQueries: sum('labelQueries'), candidateEvaluations: sum('candidateEvaluations') + sum('candidateLabelComparisons'),
  candidateRowParseAttempts: sum('candidateEvaluations'), candidateLabelComparisons: sum('candidateLabelComparisons'), selectionOperations: sum('selectionOperations'),
  constructionCpuMs: sum('cpuMs'), constructionWallMs: sum('wallMs'), productionCpuMs: sumRows('productionCpuMs'),
  verificationCpuMs: sumRows('verificationCpuMs'), packagingCpuMs: sumRows('packagingCpuMs'),
  wallMs: sum('wallMs') + sumRows('productionWallMs') + sumRows('verificationWallMs') + sumRows('packagingWallMs'),
  actualFullCostUsd: null, actualModelBillingUsd: null, providerTokens: null,
  limitation: 'One current-session LLM-assisted constructor with a sibling grammar reviewer. CLI timings exclude model inference and interactive authoring. Not a matched-dollar or externally blinded comparison.'};
await writeFile(directory + '/summary.json', JSON.stringify({programsSha256: await sha256(bytes), outcomes, metrics}, null, 2) + '\n');
await writeFile('results/metrics-with-llm.json', JSON.stringify({...original, arms: {...original.arms, current_llm: metrics}}, null, 2) + '\n');
console.log(JSON.stringify(metrics));
