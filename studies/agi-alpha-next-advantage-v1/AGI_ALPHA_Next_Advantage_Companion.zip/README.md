# AGI ALPHA FLYWHEEL — BUILD THE NEXT ADVANTAGE

**From Useful Work to Expanding Productive Capability**  
SUCCESSOR Ω Harness · TRANSFORMATIONAL INTELLIGENCE ∞  
Study **NADV-2026-01**, 25 October 2026 · Vincent Boucher / MONTREAL.AI

## What this edition actually advances

The existing AGI ALPHA quote workflow requires canonical offers. This study adds a bounded, example-driven constructor that derives executable column/unit/money adapters, qualifies each on its first fresh mission, and reuses it on the next three. It uses the unchanged Alpha Workbench, AWE quote specialist, Jobs draft compiler and shared economic modules. It adds no scheduler, payment route or competing ledger.

The new contribution is the executable preparation-to-construction-to-qualification loop and its complete-cost admission experiment. Programming by example, active selection and the quote optimizer are established methods. No algorithmic invention, actual sale, persistent autonomous operation or self-financing enterprise is claimed.

## Start here

- Open `AGI_ALPHA_Build_the_Next_Advantage.html` for the self-contained English/French demonstration. Run one of the three actual examples, inspect the program and report, then inspect the next mission. No installation, network assets, credentials or transaction is required by the page.
- Read `AGI_ALPHA_Build_the_Next_Advantage.pdf` for the manuscript. `paper/` contains the complete LaTeX, figures and plotting source.
- Run the command below from the extracted directory to reproduce local research in a **new** destination. Original frozen outcomes are preserved.

```sh
python3 reproduce.py --output /absolute/path/to/new-reproduction
```

The HTML's document/companion links expect the PDF and downloaded companion ZIP beside the HTML. The complete archive includes the PDF beside the HTML; keep the downloaded ZIP there if using its local companion-download link. The PDF and original artifact downloads are also available independently in the research handoff.

## Primary result

| Method | Accepted on the same 96 fresh jobs | Production example queries | Additional learned-recipe training |
|---|---:|---:|---:|
| Rebuild ablation | 96/96 | 244 | 0 |
| Ordinary cached scripts | 96/96 | 61 | 0 |
| Retained construction recipe | 96/96 | 29 | 31 |
| Conventional active specialist | 96/96 | 29 | 0 |
| Current-session LLM-assisted constructor | 96/96 | 29 | Separate development/authoring; full cost unknown |

There are **96 unique jobs**, 24 held-out schemas and **480 repeated method–job evaluations**. The 24 independent boundary probes were run under sequential, active and retained selection, yielding 72 expected refusals. The LLM constructor was not evaluated on the four ambiguity-construction probes. Engineering replay/demo checks add no independent primary jobs.

Active selection uses 32 fewer production examples than ordinary reuse (52.46%). The learned recipe ties the active incumbent and adds training and upkeep. It is **not economically promoted**. Retaining a useful adapter is supported; superiority of the retained builder and sustained acceleration are not established.

## Three economic questions

**A — Human-work economics.** Base fully loaded provider cost is **modeled** at $1.211784 per accepted report, under 500 requests/month, 98% operational acceptance and explicit setup, preparation, exception and maintenance assumptions. It is not a measured bill. At sourced office/administrative compensation of $36.73/hour, this is a 1.9795-minute human threshold, or 4.9795 minutes including three assumed customer minutes. At an assumed $15 price, the buyer threshold is 27.5031 minutes. Matched human duration is unknown. Conservative/stress full costs rise to $15.863884/$650.040140.

**B — Incremental Flywheel benefit.** The learned recipe saves 32 production examples versus ordinary reuse but uses 31 development examples. Its one net example saved does not repay additional modeled nonlabel expense over the observed episode. Against active selection it saves no production examples. Keep the stronger active method; learned-recipe promotion stays HOLD. LLM complete cost is unknown and excluded from the four-arm monetary ranking.

**C — Financeable succession.** Thirty explicitly simulated paths explore a hypothetical $422.17 future capability, including failed construction, with assumed $0.50 saving and $0.20 upkeep per reuse. Some paths fund and repay; low demand, zero saving, protected balances and delayed collections refuse construction. These are not benefits measured for the rejected learned recipe. Actual collections, actual complete cost and actual available surplus remain null.

## Package map

| Directory/file | Contents |
|---|---|
| `protocol/` | Prospective interface, criteria and 371-file freeze |
| `implementation/` | Generic synthesizer, interpreter, actual Workbench adapter, runners and derived recipe |
| `vendor/` | Exact original runtime/quote/accounting modules, licenses and source manifest |
| `evaluation/` | Development tasks, held-out schemas and missions, boundary probes and separate Python oracle |
| `results/` | All original outputs, construction traces, journals, independent checks, metrics and connected replay |
| `agent-baseline/` | Actual LLM-assisted constructor, action/source history, oracle records, program freeze and replay |
| `economics/` | Frozen assumptions, native ledgers, all 30 finance paths, 5,118-assertion audit and reporting amendment |
| `demonstration/` | EN/FR source, data projection, exact runtime bundle, 36 Node integration checks and six semantic checks |
| `evidence/` | Independent 480-output audit, reporting corrections, manuscript review and reproduction receipt |
| `audit/` | Prior-edition/source/owner audit and primary labor-source snapshots |
| `paper/` | Manuscript, vector/PNG figures and figure generator |
| `publication/` | Existing-pipeline metadata and scope/status records |
| `REPRODUCIBILITY.md`, `environment.json` | Dependency and reproduction details |
| `SHA256SUMS`, `PACKAGE_MANIFEST.json` | Integrity of the distributed payload |

`evaluation/sealed/` retains the historical split name. Data are public in this reproducibility package after the prospective evaluation; no ongoing secret or withheld credential is implied.

## Execution and authority

Local construction, first-job qualification, reuse, independent semantic verification, cost modeling, finance simulation and Node interface tests are EXECUTED. The connected nine-event journey is a scripted after-outcome replay of frozen cases, not a new confirmatory sample or autonomous mission selection. The live demo starts from the previously established preparation boundary and constructs before delivery.

Browser rendering, authenticated Harness execution, persistent Fleet operation, approved-profile installation, real collections, contract execution and financial reinvestment are NOT RUN. Existing security, review and publication decisions are unchanged. Local evidence cannot clear them. The demo's local cross-check shares prepared inputs; archived independent Python acceptance does not transfer to user-edited inputs.

The source records distinguish applicable AGIALPHA receipt/fee/conditional staking mechanisms from the Manager's USDC route. There is no automatic buyback, universal holder right, token appreciation or executed reinvestment claim.

## Research lineage and publication

Coordination: [Alpha issue #4850](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/issues/4850). [Initial scope notice](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/issues/4850#issuecomment-6403108438).

The original Autonomous Work Economy, Productive Capital Engine, Economic Engine, capability-construction and earlier Harness/Flywheel files and URLs are preserved. `audit/lineage_economics.md` states their findings and limits. `vendor/SOURCE_MANIFEST.json` binds reused code. This edition's new publication ID is `agi-alpha-next-advantage-v1`.

The existing integration/publisher owner receives separate paper and software/demo review lanes. This archive does not assert a merged release, a live hosted page or operational qualification. Exact later publication receipts belong to the issue handoff and publication-status artifact.

## License and attribution

New research code is Apache-2.0, consistent with the reused repository. Original vendor files and their notices remain unchanged; see `LICENSE` and `vendor/`. The generated data are synthetic. AI-assisted authoring and same-session independent-review limits are disclosed in the manuscript and comparator provenance.
