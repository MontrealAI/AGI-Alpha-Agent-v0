#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Reproduce the bounded local study in a fresh, isolated output directory.

Only Python and Node standard libraries are required. Original evidence is read
but never rewritten. Saved LLM observations are replayed without model inference
or new label-oracle requests. Timings are remeasured, not expected to match.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import platform
import shutil
import subprocess
import sys
import time
import traceback

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
TIMING_KEYS = {
    "cpuMs", "wallMs", "verifierCpuMs", "constructionCpuMs", "constructionWallMs",
    "productionCpuMs", "productionWallMs", "verificationCpuMs", "verificationWallMs",
    "packagingCpuMs", "packagingWallMs", "allEngineeringValidationCpuMs",
    "atUtc", "checkedAtUtc",
}
EXTRA_INPUTS = (
    "protocol/FREEZE.json", "agent-baseline/FREEZE.json", "agent-baseline/oracle-events.jsonl",
    "implementation/analyze.py", "implementation/run_llm_programs.mjs",
    "implementation/boundaries.mjs", "implementation/connected_loop.mjs", "implementation/replay_development.mjs",
    "economics/audit_results.py", "economics/resource-report-v1.1.mjs",
    "evidence/final_independent_checks.py", "results/development/summary.json",
    "results/development-v0/summary.json", "results/development-v1/summary.json",
    "reproduce.py", "REPRODUCIBILITY.md", "environment.json",
)


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False, sort_keys=True) + "\n", encoding="utf-8")


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def object_digest(value) -> str:
    data = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(data).hexdigest()


def scoped_path(root: Path, relative: str) -> Path:
    name = PurePosixPath(relative)
    if name.is_absolute() or ".." in name.parts:
        raise ValueError("Unsafe package path: " + relative)
    target = root.joinpath(*name.parts)
    if not target.resolve().is_relative_to(root.resolve()):
        raise ValueError("Package path escapes its root: " + relative)
    return target


def verify_entries(root: Path, entries, label: str, expected_count: int | None = None) -> dict:
    if isinstance(entries, dict):
        entries = [{"path": path, "sha256": sha} for path, sha in entries.items()]
    if expected_count is not None and len(entries) != expected_count:
        raise AssertionError(f"{label}: expected {expected_count} entries, found {len(entries)}")
    mismatches = []
    for entry in entries:
        path = scoped_path(root, entry["path"])
        actual = digest(path) if path.is_file() else None
        if actual != entry["sha256"]:
            mismatches.append({"path": entry["path"], "expected": entry["sha256"], "actual": actual})
    if mismatches:
        raise AssertionError(label + ": " + json.dumps(mismatches[:10]))
    return {"name": label, "passed": True, "entries": len(entries), "mismatches": []}


def logical(value):
    """Remove only declared measurement fields, preserving duration constraints."""
    if isinstance(value, dict):
        return {key: logical(item) for key, item in value.items() if key not in TIMING_KEYS}
    if isinstance(value, list):
        return [logical(item) for item in value]
    return value


def pack_projection(pack: dict) -> dict:
    # createdAt affects work-order expiry and integrity digests; the fresh
    # runtime validates those bindings. Keep the complete semantic result,
    # including every artifact body/digest, plus its frozen source and authority.
    return {key: pack[key] for key in
            ("schema", "spec", "frozen", "releaseDigest", "result", "evaluation", "chronicle")}


def differences(actual, expected, prefix: str = "$", limit: int = 12) -> list[str]:
    found = []
    if type(actual) is not type(expected):
        return [prefix + ": different types"]
    if isinstance(actual, dict):
        if actual.keys() != expected.keys():
            found.append(prefix + ": different keys")
        for key in sorted(actual.keys() & expected.keys()):
            if len(found) >= limit:
                break
            found.extend(differences(actual[key], expected[key], prefix + "." + key, limit - len(found)))
    elif isinstance(actual, list):
        if len(actual) != len(expected):
            found.append(prefix + ": different lengths")
        for index, (left, right) in enumerate(zip(actual, expected)):
            if len(found) >= limit:
                break
            found.extend(differences(left, right, f"{prefix}[{index}]", limit - len(found)))
    elif actual != expected:
        found.append(prefix + ": different values")
    return found[:limit]


def compare(checks: list, name: str, actual, expected, detail=None) -> None:
    mismatch = differences(actual, expected)
    checks.append({"name": name, "passed": not mismatch, "differences": mismatch, "detail": detail})
    if mismatch:
        raise AssertionError(name + ": " + "; ".join(mismatch))


def environment() -> dict:
    if sys.version_info < (3, 10):
        raise RuntimeError("Python 3.10 or newer is required")
    if os.name != "posix":
        raise RuntimeError("The frozen comparator uses POSIX resource accounting; use Linux or macOS")
    node = shutil.which("node")
    child_python = shutil.which("python3")
    if node is None or child_python is None:
        raise RuntimeError("node and python3 must both be available on PATH")
    probe = subprocess.run([node, "--input-type=module", "-e",
        "console.log(JSON.stringify({node:process.version,versions:process.versions,"
        "webcrypto:!!globalThis.crypto?.subtle,structuredClone:typeof structuredClone,"
        "performance:typeof performance}))"], capture_output=True, text=True, check=True)
    node_info = json.loads(probe.stdout)
    if int(node_info["node"].lstrip("v").split(".")[0]) < 20 or not node_info["webcrypto"]:
        raise RuntimeError("Node 20+ with global Web Crypto is required; the recorded run uses Node 24.22.1")
    if node_info["structuredClone"] != "function" or node_info["performance"] != "object":
        raise RuntimeError("Node structuredClone/performance globals are unavailable")
    python_probe = subprocess.run([child_python, "-c",
        "import json,sys; print(json.dumps({'version':sys.version,'versionInfo':list(sys.version_info[:3]),'executable':sys.executable}))"],
        capture_output=True, text=True, check=True)
    child_info = json.loads(python_probe.stdout)
    if tuple(child_info["versionInfo"]) < (3, 10):
        raise RuntimeError("python3 used by frozen Node runners must be Python 3.10+")
    return {
        "python": {"version": sys.version, "executable": sys.executable,
                   "implementation": platform.python_implementation()},
        "childPython3": child_info, "node": {"executable": node, **node_info},
        "platform": platform.platform(), "machine": platform.machine(),
        "thirdPartyPythonPackages": [], "npmPackages": [],
        "networkRequired": False, "modelInferenceRequested": False,
    }


def copy_inputs(workspace: Path, source_hashes: dict) -> dict:
    primary = read_json(ROOT / "protocol/FREEZE.json")
    agent = read_json(ROOT / "agent-baseline/FREEZE.json")
    names = {entry["path"] for entry in primary["files"]}
    names.update(agent["artifacts"])
    names.update(agent["permittedInputs"])
    names.update(EXTRA_INPUTS)
    size = 0
    for name in sorted(names):
        source = scoped_path(ROOT, name)
        destination = scoped_path(workspace, name)
        if not source.is_file():
            raise FileNotFoundError(source)
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, destination)
        source_hashes[name] = digest(source)
        size += source.stat().st_size
    return {"files": len(names), "bytes": size, "selection": "manifest union plus explicit runner/history/dependency files"}


def snapshot_references(reference: Path, source_hashes: dict) -> dict:
    names = {
        "results/confirmation-v1/raw-summary.json", "results/current-llm-v1/summary.json",
        "results/metrics.json", "results/metrics-with-llm.json",
        "results/boundaries-v1/results.json", "economics/results-audit-v1.json",
    }
    for folder in ("results/confirmation-v1/constructions", "results/connected-loop-v1", "economics/results-v1"):
        names.update(str(path.relative_to(ROOT)) for path in (ROOT / folder).glob("*.json"))
    names.update(str(path.relative_to(ROOT)) for path in (ROOT / "results/development").glob("D*.construction.json"))
    for name in sorted(names):
        source, target = ROOT / name, reference / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        source_hashes[name] = digest(source)
    raw = read_json(reference / "results/confirmation-v1/raw-summary.json")
    llm = read_json(reference / "results/current-llm-v1/summary.json")
    semantic_packs = {}
    for row in raw["outcomes"] + llm["outcomes"]:
        if "packPath" not in row:
            continue
        path = scoped_path(ROOT, row["packPath"])
        source_hashes[row["packPath"]] = digest(path)
        semantic_packs[row["packPath"]] = object_digest(pack_projection(read_json(path)))
    write_json(reference / "pack-semantic-digests.json", {
        "projectionKeys": ["schema", "spec", "frozen", "releaseDigest", "result", "evaluation", "chronicle"],
        "count": len(semantic_packs), "digests": semantic_packs,
        "excluded": "createdAt, time-derived compilation expiry/digests, elapsed economics timing, whole-pack integrityDigest",
    })
    return {"copiedReferenceFiles": len(names), "originalPackSemanticDigests": len(semantic_packs)}


def run_step(name: str, argv: list[str], workspace: Path, output: Path, steps: list) -> dict:
    print("START " + name, flush=True)
    log_dir = output / "logs"
    log_dir.mkdir(exist_ok=True)
    start = time.perf_counter()
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", PYTHONHASHSEED="0", TZ="UTC")
    with (log_dir / (name + ".stdout.log")).open("w") as stdout, (log_dir / (name + ".stderr.log")).open("w") as stderr:
        result = subprocess.run(argv, cwd=workspace, env=env, stdout=stdout, stderr=stderr, timeout=1800)
    step = {"name": name, "argv": argv, "cwd": str(workspace), "returnCode": result.returncode,
            "elapsedSeconds": time.perf_counter() - start,
            "stdout": "logs/" + name + ".stdout.log", "stderr": "logs/" + name + ".stderr.log"}
    steps.append(step)
    write_json(output / "commands.json", steps)
    print(f"DONE {name}: exit {result.returncode}, {step['elapsedSeconds']:.3f}s", flush=True)
    if result.returncode:
        raise RuntimeError(f"Step {name} failed; inspect {step['stderr']}")
    return step


def replay_saved_labels(workspace: Path, output: Path, checks: list) -> dict:
    start = time.perf_counter()
    folder = workspace / "agent-baseline"
    source = folder / "runs/primary01/agent.source.py"
    spec = importlib.util.spec_from_file_location("frozen_current_session_comparator_replay", source)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    expected = read_json(folder / "programs.json")
    replay_dir = output / "recorded-label-replay"
    replay_dir.mkdir()
    replayed = {}
    for schema, original in sorted(expected.items()):
        task = read_json(folder / "public" / (schema + ".task.json"))
        observations = read_json(folder / "runs/primary01" / (schema + ".observations.json"))
        labels = {item["row"]: item["label"] for item in observations}
        constructor = module.Constructor(task, lambda task_id, row: labels[row], replay_dir / "actions.jsonl")
        actual = constructor.construct()
        compare(checks, "saved_label_replay:" + schema, logical(actual), logical(original))
        replayed[schema] = actual
    write_json(replay_dir / "programs.json", replayed)
    report = {"status": "PASS", "schemaCount": len(replayed), "newOracleRequests": 0,
              "modelInferenceCalls": 0, "recordedLabelSelections": sum(x["metrics"]["labelQueries"] for x in replayed.values()),
              "elapsedSeconds": time.perf_counter() - start,
              "scope": "Replay of frozen executable constructor and recorded labels; no reproduction of model inference or interactive authoring"}
    write_json(replay_dir / "summary.json", report)
    return report


def compare_outputs(workspace: Path, reference: Path, checks: list) -> dict:
    for name in ("results/confirmation-v1/raw-summary.json", "results/current-llm-v1/summary.json",
                 "results/metrics.json", "results/metrics-with-llm.json", "results/boundaries-v1/results.json"):
        compare(checks, "logical:" + name, logical(read_json(workspace / name)), logical(read_json(reference / name)))
    reference_builds = sorted((reference / "results/confirmation-v1/constructions").glob("*.json"))
    actual_builds = sorted((workspace / "results/confirmation-v1/constructions").glob("*.json"))
    compare(checks, "construction_file_set", [p.name for p in actual_builds], [p.name for p in reference_builds])
    for path in reference_builds:
        relative = path.relative_to(reference)
        compare(checks, "construction:" + path.stem, logical(read_json(workspace / relative)), logical(read_json(path)))
    pack_record = read_json(reference / "pack-semantic-digests.json")
    actual_digests = {name: object_digest(pack_projection(read_json(workspace / name))) for name in pack_record["digests"]}
    compare(checks, "complete_pack_semantic_projections", actual_digests, pack_record["digests"],
            {"packs": len(actual_digests), "everyArtifactBodyAndDigestIncluded": True})
    for path in sorted((reference / "results/connected-loop-v1").glob("*.json")):
        actual = read_json(workspace / path.relative_to(reference))
        expected = read_json(path)
        if path.name.endswith("-pack.json"):
            actual, expected = pack_projection(actual), pack_projection(expected)
        compare(checks, "connected_loop:" + path.name, logical(actual), logical(expected))
    for path in sorted((reference / "economics/results-v1").glob("*.json")):
        actual = read_json(workspace / path.relative_to(reference))
        expected = read_json(path)
        if path.name == "summary.json":
            for document in (actual, expected):
                document.pop("metricsSHA256", None)
                document.pop("measuredResources", None)
        elif path.name == "REPRODUCTION.json":
            for document in (actual, expected):
                document.pop("metricsSHA256", None)
                document.pop("nodeVersion", None)
        compare(checks, "economics:" + path.name, logical(actual), logical(expected))
    actual_audit = read_json(workspace / "economics/results-audit-v1.json")
    expected_audit = read_json(reference / "economics/results-audit-v1.json")
    actual_audit.pop("metricsSHA256", None)
    expected_audit.pop("metricsSHA256", None)
    compare(checks, "independent_financial_arithmetic", actual_audit, expected_audit)
    final = read_json(workspace / "evidence/FINAL_INDEPENDENT_CHECKS.json")
    compare(checks, "fresh_pack_independent_audit", final["status"], "PASS",
            {"checksPassed": final["checksPassed"], "checksTotal": final["checksTotal"]})
    metrics = read_json(workspace / "results/metrics-with-llm.json")
    boundaries = read_json(workspace / "results/boundaries-v1/results.json")
    return {
        "deterministicConstructionRecords": len(actual_builds),
        "semanticPackComparisons": len(actual_digests),
        "uniqueFreshMissions": metrics["uniqueFreshMissions"],
        "arms": {name: {key: row[key] for key in
                  ("missions", "accepted", "refused", "constructions", "labelQueries", "candidateEvaluations", "selectionOperations")}
                 for name, row in metrics["arms"].items()},
        "boundaryProbes": boundaries["uniqueProbes"], "boundaryEvaluations": boundaries["repeatedEvaluations"],
        "boundaryPassed": boundaries["passed"], "financialArithmeticAssertions": actual_audit["totalAssertions"],
        "independentAuditChecksPassed": final["checksPassed"],
        "sameProgramsCountsAndSemanticOutcomes": True,
        "timingsRequiredToMatch": False,
    }


def compare_development_replay(workspace: Path, reference: Path, checks: list) -> dict:
    directory = workspace / "results/development-replay-v2"
    fresh = read_json(directory / "summary.json")
    historical = read_json(workspace / "results/development/summary.json")
    frozen_recipe = read_json(workspace / "implementation/learned-recipe.json")
    provenance = frozen_recipe.pop("provenance")
    reference_builds = sorted((reference / "results/development").glob("D*.construction.json"))
    actual_builds = sorted(directory.glob("D*.construction.json"))
    compare(checks, "development_replay_file_set", [p.name for p in actual_builds], [p.name for p in reference_builds])
    for path in reference_builds:
        compare(checks, "development_replay:" + path.stem,
                logical(read_json(directory / path.name)), logical(read_json(path)))
    compare(checks, "development_logical_measures", logical(fresh["measures"]), logical(historical["measures"]))
    compare(checks, "development_logical_training", logical(fresh["training"]), logical(historical["training"]))
    compare(checks, "recipe_derived_from_fresh_traces", fresh["recipe"], frozen_recipe)
    compare(checks, "development_task_order", fresh["replayProvenance"]["learnedFrom"], provenance["learnedFrom"])
    compare(checks, "development_replay_expected_totals",
            {"schemas": fresh["schemas"], "constructed": fresh["constructed"], **fresh["counters"]},
            {"schemas": 12, "constructed": 12, "labelQueries": 31, "candidateEvaluations": 5499,
             "selectionOperations": 0, "initialCandidates": 265})
    compare(checks, "development_recipe_expected_weights", fresh["recipe"]["weights"],
            {"item": 5, "vendor": 1, "pack_units": 2, "pack_price_minor": 8, "currency": 1, "lead_days": 1})
    return {
        "status": "PASS", "schemas": fresh["schemas"], "constructed": fresh["constructed"],
        **fresh["counters"], "recipeWeights": fresh["recipe"]["weights"],
        "recipeEvidenceCounts": fresh["recipe"]["evidenceCounts"],
        "completeProgramsAndLogicalTracesMatched": True,
        "recipeBodyDerivedFromFreshTracesMatched": True,
        "frozenRecipeOverwritten": False,
        "historicalTrainingAccountingReplaced": False,
        "replayCpuMs": fresh["training"]["cpuMs"], "replayWallMs": fresh["training"]["wallMs"],
        "scope": "Fresh development synthesis and recipe-derivation replay; historical measurements and recipe provenance remain preserved inputs to the primary analysis",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True, help="Absolute path to a new, nonexistent directory")
    args = parser.parse_args()
    if not args.output.is_absolute():
        parser.error("--output must be an absolute path")
    output = args.output.resolve()
    if output.exists():
        parser.error("--output already exists; choose a fresh directory to preserve all prior evidence")
    if output == ROOT or ROOT.is_relative_to(output):
        parser.error("--output cannot be the package root or one of its ancestors")
    output.mkdir(parents=True, exist_ok=False)
    started, wall_start = utc_now(), time.perf_counter()
    checks, steps, protected = [], [], {}
    receipt = {"schema": "next-advantage-reproduction/v1", "status": "RUNNING", "startedUtc": started,
               "reproductionRevision": 2,
               "sourcePackage": str(ROOT), "outputDirectory": str(output), "modelInferenceReproduced": False,
               "newLLMOracleRequests": 0, "originalPrimaryFilesOverwritten": False, "steps": steps, "checks": checks}
    try:
        runtime = environment()
        receipt["environment"] = runtime
        write_json(output / "environment.json", runtime)
        primary = read_json(ROOT / "protocol/FREEZE.json")
        agent = read_json(ROOT / "agent-baseline/FREEZE.json")
        checks.append(verify_entries(ROOT, primary["files"], "source_primary_freeze", 371))
        checks.append(verify_entries(ROOT, agent["artifacts"], "source_comparator_artifacts"))
        checks.append(verify_entries(ROOT, agent["permittedInputs"], "source_comparator_inputs"))
        workspace, reference = output / "workspace", output / "reference"
        workspace.mkdir()
        reference.mkdir()
        receipt["inputCopy"] = copy_inputs(workspace, protected)
        receipt["referenceSnapshot"] = snapshot_references(reference, protected)
        write_json(output / "SOURCE_READ_MANIFEST.json", {"sourcePackage": str(ROOT), "files": protected})
        checks.append(verify_entries(workspace, primary["files"], "copied_primary_freeze", 371))
        oracle_before = digest(workspace / "agent-baseline/oracle-events.jsonl")
        node = runtime["node"]["executable"]
        python = sys.executable
        commands = [
            ("grammar-controls", [node, "implementation/controls.mjs"]),
            ("economic-protocol", [node, "economics/analyze.mjs", "--protocol-check"]),
            ("development-construction-replay", [node, "implementation/replay_development.mjs"]),
            ("deterministic-confirmation", [node, "implementation/run.mjs", "confirm", "confirmation-v1"]),
            ("deterministic-analysis", [python, "implementation/analyze.py"]),
            ("frozen-llm-program-evaluation", [node, "implementation/run_llm_programs.mjs"]),
            ("boundaries", [node, "implementation/boundaries.mjs"]),
            ("connected-loop", [node, "implementation/connected_loop.mjs", "results/connected-loop-v1"]),
            ("economic-analysis", [node, "economics/analyze.mjs", "--metrics", "results/metrics.json", "--out", "economics/results-v1"]),
            ("independent-economic-audit", [python, "economics/audit_results.py", "--results", "economics/results-v1", "--out", "economics/results-audit-v1.json"]),
            ("resource-report", [node, "economics/resource-report-v1.1.mjs", "--results", "economics/results-v1", "--out", "economics/resources-v1.1.json"]),
        ]
        for name, command in commands:
            run_step(name, command, workspace, output, steps)
            if name == "development-construction-replay":
                receipt["developmentReplay"] = compare_development_replay(workspace, reference, checks)
        controls = read_json(output / "logs/grammar-controls.stdout.log")
        compare(checks, "grammar_controls", (controls["checks"], controls["passed"]), (21, 21))
        protocol = read_json(output / "logs/economic-protocol.stdout.log")
        compare(checks, "economic_protocol", protocol["status"], "PASS")
        receipt["recordedLabelReplay"] = replay_saved_labels(workspace, output, checks)
        compare(checks, "no_new_llm_oracle_events", digest(workspace / "agent-baseline/oracle-events.jsonl"), oracle_before)
        run_step("independent-complete-audit", [python, "evidence/final_independent_checks.py"], workspace, output, steps)
        receipt["outcomes"] = compare_outputs(workspace, reference, checks)
        checks.append(verify_entries(workspace, primary["files"], "post_execution_primary_freeze", 371))
        checks.append(verify_entries(workspace, agent["artifacts"], "post_execution_comparator_artifacts"))
        checks.append(verify_entries(ROOT, protected, "original_inputs_and_evidence_unchanged"))
        receipt["status"] = "PASS"
    except Exception as error:
        receipt["status"] = "FAIL"
        receipt["error"] = {"type": type(error).__name__, "message": str(error)}
        (output / "failure-traceback.txt").write_text(traceback.format_exc(), encoding="utf-8")
    receipt["finishedUtc"] = utc_now()
    receipt["elapsedSeconds"] = time.perf_counter() - wall_start
    receipt["checksPassed"] = sum(check.get("passed", False) for check in checks)
    receipt["checksTotal"] = len(checks)
    receipt["reproducerSha256"] = digest(Path(__file__))
    receipt["limitations"] = [
        "Computational replay of the fixed synthetic study; no new independent sample or external peer review.",
        "Development syntheses and recipe derivation are freshly replayed and compared; historical accounting and frozen recipe provenance are preserved rather than replaced.",
        "LLM executable construction is replayed from saved labels; original interactive model construction is not reproduced.",
        "CPU, wall time, timestamps and time-derived work-order/integrity bindings can differ.",
        "Actual model billing, complete monetary costs, human durations and customer collections remain unknown.",
        "No networking, package installation, authenticated operation, deployment, payment or publishing is requested.",
    ]
    write_json(output / "REPRODUCTION_VALIDATION.json", receipt)
    print(json.dumps({"status": receipt["status"], "elapsedSeconds": receipt["elapsedSeconds"],
                      "checksPassed": receipt["checksPassed"], "checksTotal": receipt["checksTotal"],
                      "receipt": str(output / "REPRODUCTION_VALIDATION.json"), "error": receipt.get("error")}, indent=2))
    return 0 if receipt["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
