# Build the Next Advantage: frozen experiment interface

Status: prospective interface, before confirmatory outcomes. Version 1.

This study extends the existing AWE quote workflow through the unchanged Alpha
Workbench adapter interface. All data are synthetic nonpersonal quote records.
There are no purchases, provider calls, credentials, transactions or services.

## Preparation contract

A schema task has `id`, `family`, `headers` (6–10 unique nonempty strings),
`pool` (16 rows of strings, one cell per header), and a public description.
The builder may request a row's canonical six-field label through an oracle.
The label has exactly `item`, `vendor`, `pack_units`, `pack_price_minor`,
`currency`, `lead_days`. It is a synthetic stand-in for a reviewed worked
example; label counts are observed, human labeling time is unknown.

An executable program maps each canonical field to `{column, op}`. `column`
is an exact source header. Only these typed operations exist:

| Fields | Operations | Exact interpretation |
|---|---|---|
| item, vendor | text | Trim surrounding whitespace; preserve case and interior bytes. |
| currency | currency | Trim and uppercase exactly three ASCII letters. |
| pack_units | integer, units-suffix, units-prefix | Positive decimal integer; or `N units`, `N unit`, `N pack`, `N pcs`, `N pièces`; or `xN`/`XN`. |
| lead_days | integer, days-suffix, weeks-suffix | Nonnegative integer; or `N days`, `N day`, `N jours`, `N jour`; or `N weeks`, `N week`, `N semaines`, `N semaine`, multiplied by seven. |
| pack_price_minor | minor, major-dot, major-comma | Nonnegative decimal integer minor units; or a mandatory decimal point/comma with exactly two digits; optional leading `$`/`€` or trailing three-letter currency label. No thousands separator, sign, exponential notation, FX inference or rounding. |

Leading/trailing whitespace is permitted. Integers use `0` or a nonzero digit
followed by digits; no leading zeroes. `minor` is bounded to 100,000,000;
pack_units 1–10,000; lead_days 0–365. Text length is 1–60 for item/vendor.
Interior ASCII controls are rejected; declared unit suffixes are case-insensitive.
Leading currency symbols and trailing currency codes are mutually exclusive.
Malformed expressions reject. Currency affixes are syntax, not exchange
rates; production requires an explicit currency field and a consistent affix.
Every row must use a consistent column interpretation within a schema.

The generic builder enumerates all column/operation candidates and eliminates
them using only requested labels. It may emit a program only when each field
has exactly one surviving expression. Unresolved ambiguity, contradiction,
budget exhaustion or invalid data produces an explicit refusal. No executable
source or arbitrary expressions are evaluated from input. Programs are inert
JSON interpreted by an allowlist.

## Mission contract

A production mission includes `id`, `schema_id`, `headers`, `rows` and
`context`. Context is the existing AWE quote input without `offers`: title,
base_currency, deadline_days, items, shipping_minor, fx. Prepared rows become
the offers. The unchanged `normalizeQuotes` and `subsetSolve` produce the
basket; the unchanged Workbench creates the standard pack and unfunded Jobs
drafts. A separate Python oracle checks every normalized offer, all declared
quantities/currencies/deadlines, and the exact optimum by cart enumeration.
Only complete, independently correct report/cart/analysis bundles count as
accepted deliveries. Integrity-only Workbench checks are not semantic checks.

Duplicate `(item,vendor)` rows, header mismatches, unsupported currency,
contradictory price affixes and noncanonical IDs are refused. Equal-cost
alternative carts are accepted if exact minimum cost and constraints hold.

## Prospective split and arms

12 development schema tasks (four each in plain-minor, suffix/dot and prefix/comma);
24 held-out schema tasks (four each in all six structural families); four fresh
production missions per held-out task, 96 unique jobs. Weekly lead, currency
affixes and mixed alternative views are three held-out structural compositions
within the grammar disclosed to every builder.
Headers and exact schema configurations are disjoint across the split. Within
each task the constructor sees only its example pool and queried labels, never
production expected outputs. The evaluator owns canonical targets and separate
24 boundary probes. Family membership is not evidence of a sampled market.

All deterministic builders share the exact candidate grammar, 8-label budget
per construction, candidate evaluation ceiling 200,000 and production inputs.

1. Rebuild: ordinary sequential example-driven synthesis for every mission.
2. Ordinary reuse: the same builder, then a schema-keyed reusable-script cache.
3. Retained construction: a probe-weight recipe learned on development traces,
   followed by the same builder and schema-keyed program cache.
4. Active specialist: conventional maximum-disagreement selection, then cache.
5. Current LLM agent with standard tools: separate same-session construction
   from the same permitted examples and grammar. Model/token billing is not
   exposed; comparisons involving it cannot establish matched monetary cost.

The equal-resource construction comparison is retained versus ordinary reuse
and active specialist, with identical label and candidate ceilings. Rebuild is
an ablation, not the strongest alternative. Caches are keyed by complete schema
contract identity, not by an answer or mission result. Failed constructions
remain in all accounting.

## Primary criteria

Quality: all accepted outputs must pass the independent exact oracle; zero
false acceptances is a mandatory safety criterion. Refusals lower coverage and
cannot be counted as delivered work. Report all 96 cases for each arm, without
discarding difficult families. Report label queries, candidate evaluations,
construction CPU/wall, delivery/verification/packaging CPU/wall, bytes and
complete acceptance. CPU is host-specific and cannot itself imply billed money.

Task-capability admission requires unique program identification, all fresh
outputs correct and all applicable boundaries respected. Economic promotion
is separate: positive conservative full-cost benefit versus the best capable
incumbent and affordability after obligations/reserves. Unknown benefit gives
HOLD. Actual sales/collections/full lifecycle costs are unknown.

Meta-construction success requires retained construction to improve useful
capabilities produced or full construction cost on held-out schemas against
the matched active specialist after recipe construction and maintenance costs.
Better execution, better construction and sustained acceleration are separate.
No sustained acceleration claim can follow from this finite two-level study.

Recorded selection operations are charged to measured constructor CPU/wall but
are separate from the candidate-evaluation ceiling. Equal resource limits mean
the same candidate and label caps; they do not assert equal consumed CPU or
equal LLM token cost.

Frozen artifacts will include grammar, protocol, dataset commitments, source
hashes, implementation hash and economic assumptions before first outcomes.
Development traces are exploratory and are retained. Post-freeze fixes require
an explicit amendment and rerun; original failed runs remain preserved.

## Sequential qualification and uncertainty

The first fresh mission for each constructed program is a qualification trial.
Its output must pass the separate Python input-truth/cart/report verifier before
the runtime records technical admission and applies the cached program to the
three subsequent missions. A failure holds the program; no expected answer or
production failure is fed into its constructor. This admission is bounded
research qualification, not economic promotion or production authorization.

Primary incremental comparisons use paired per-schema outcomes and acquisition
counts for retained versus ordinary reuse and active specialist. Report the
finite experiment totals and a paired, schema-cluster bootstrap interval
(10,000 resamples, seed 20261025) for mean query differences. Family strata and
all four missions stay linked. Intervals characterize this synthetic sampling
design, not market demand. Small CPU timings are descriptive, include all
failures, and receive no claim of a general billing or latency advantage.
