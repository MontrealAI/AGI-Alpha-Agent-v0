#!/usr/bin/env python3
"""Package this research edition without recursive archives or original changes."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import zipfile

ROOT = Path(__file__).resolve().parent
DATE = (2026, 10, 25, 0, 0, 0)


def included(p):
    rel = p.relative_to(ROOT)
    if not p.is_file() or p.is_symlink():
        return False
    if any(x.startswith('.') or x in {'__pycache__', 'output'} for x in rel.parts):
        return False
    if p.name in {'PACKAGE_MANIFEST.json', 'SHA256SUMS'}:
        return False
    if p.suffix in {'.pyc', '.tmp', '.aux', '.toc', '.out', '.xdv'}:
        return False
    if rel.parts[0] == 'paper' and p.suffix == '.log':
        return False
    return True


def archive(destination, files, prefix=''):
    if destination.exists():
        raise FileExistsError(destination)
    with zipfile.ZipFile(destination, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p, name in files:
            info = zipfile.ZipInfo(prefix + name, DATE)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, p.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    with zipfile.ZipFile(destination) as z:
        assert z.testzip() is None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()
    output = args.output.resolve()
    if output == ROOT or ROOT in output.parents:
        raise ValueError('Output must be outside the source package to prevent recursive archives')
    output.mkdir(parents=True, exist_ok=True)
    files = sorted((p for p in ROOT.rglob('*') if included(p)), key=lambda p: p.relative_to(ROOT).as_posix())
    records = [{'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
    manifest = {'study':'NADV-2026-01','payloadFiles':len(records),'files':records,
                'excludes':['manifest and checksum list themselves','temporary TeX/bytecode/output files'],
                'priorEditions':'preserved at original source URLs; see audit/lineage_economics.md',
                'publication':'review handoff; no live-site claim'}
    (ROOT/'PACKAGE_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
    (ROOT/'SHA256SUMS').write_text(''.join(r['sha256']+'  '+r['path']+'\n' for r in records))
    full=[(p,p.relative_to(ROOT).as_posix()) for p in files]+[(ROOT/n,n) for n in ['PACKAGE_MANIFEST.json','SHA256SUMS']]
    companion=output/'AGI_ALPHA_Next_Advantage_Companion.zip'
    archive(companion,full)
    source=[(ROOT/'paper/AGI_ALPHA_Build_the_Next_Advantage.tex','AGI_ALPHA_Build_the_Next_Advantage.tex'),(ROOT/'paper/README.md','README.md')]
    source += [(p,'figures/'+p.name) for p in sorted((ROOT/'paper/figures').glob('*.pdf'))]
    source += [(ROOT/'paper/figures/figure-manifest.json','figures/figure-manifest.json')]
    latex=output/'AGI_ALPHA_Next_Advantage_LaTeX.zip';archive(latex,source)
    for name in ['AGI_ALPHA_Build_the_Next_Advantage.pdf','AGI_ALPHA_Build_the_Next_Advantage.html']:
        shutil.copy2(ROOT/name,output/name)
    receipt={'payloadFiles':len(records),'payloadBytes':sum(r['bytes'] for r in records),'artifacts':[]}
    for p in [companion,latex,output/'AGI_ALPHA_Build_the_Next_Advantage.pdf',output/'AGI_ALPHA_Build_the_Next_Advantage.html']:
        receipt['artifacts'].append({'file':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
    (output/'PACKAGE_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))


if __name__ == '__main__':
    main()
