"""Read-only final audit of preserved evidence; writes only its new audit receipt.

This is same-session evaluator review, not external peer review. It rechecks
existing packs with the already frozen evaluator; it does not rerun builders.
"""
import collections
import datetime
import hashlib
import importlib.util
import json
import sys
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
checks = []


def read(path):
    return json.loads((ROOT / path).read_text())


def digest(path):
    return hashlib.sha256((ROOT / path).read_bytes()).hexdigest()


def record(name, condition, detail=None):
    checks.append({"name": name, "passed": bool(condition), "detail": detail})


def manifest(path, key, prefix=""):
    entries = read(path)[key]
    if isinstance(entries, dict):
        entries = [{"path": p, "sha256": h} for p, h in entries.items()]
    mismatches = []
    for entry in entries:
        actual = digest(str(Path(prefix) / entry["path"]))
        if actual != entry["sha256"]:
            mismatches.append({"path": entry["path"], "actual": actual,
                               "expected": entry["sha256"]})
    record(f"hashes:{path}:{key}", not mismatches,
           {"entries": len(entries), "mismatches": mismatches})


manifest("protocol/FREEZE.json", "files")
manifest("evaluation/DATA_COMMITMENT.json", "files", "evaluation")
manifest("agent-baseline/FREEZE.json", "artifacts")
manifest("agent-baseline/FREEZE.json", "permittedInputs")

freeze = read("protocol/FREEZE.json")
raw = read("results/confirmation-v1/raw-summary.json")
llm = read("results/current-llm-v1/summary.json")
metrics = read("results/metrics-with-llm.json")
programs = read("agent-baseline/programs.json")
llm_freeze = read("agent-baseline/FREEZE.json")
record("primary_freeze_binding", raw["freezeId"] == freeze["freezeId"]
       == metrics["primaryFreeze"])
record("llm_program_binding", digest("agent-baseline/programs.json")
       == llm["programsSha256"] == llm_freeze["programsSha256"])

heldout = [read(f"evaluation/sealed/confirmation/H{i:02}.task.json")
           for i in range(1, 25)]
development = [read(f"evaluation/development/D{i:02}.task.json")
               for i in range(1, 13)]
family_counts = dict(collections.Counter(t["family"] for t in heldout))
dev_counts = dict(collections.Counter(t["family"] for t in development))
dev_headers = {h for t in development for h in t["headers"]}
test_headers = {h for t in heldout for h in t["headers"]}
record("split", len(family_counts) == 6 and set(family_counts.values()) == {4}
       and len(dev_counts) == 3 and set(dev_counts.values()) == {4}
       and not dev_headers.intersection(test_headers),
       {"developmentFamilies": dev_counts, "heldoutFamilies": family_counts,
        "headersDisjoint": not bool(dev_headers.intersection(test_headers))})
record("construction_pool_bounds", all(len(t["pool"]) == 16
       and 6 <= len(t["headers"]) <= 10 for t in heldout + development))

spec = importlib.util.spec_from_file_location("frozen_semantic_oracle", ROOT / "evaluation/oracle.py")
oracle = importlib.util.module_from_spec(spec)
spec.loader.exec_module(oracle)
rows = raw["outcomes"] + llm["outcomes"]
expected_missions = {f"H{i:02}-M{j}" for i in range(1, 25) for j in range(1, 5)}
per_arm = collections.defaultdict(list)
pack_failures, authority_failures = [], []
program_fields = collections.defaultdict(list)
created = collections.defaultdict(list)
for row in rows:
    per_arm[row["arm"]].append(row)
    truth = read(f"evaluation/sealed/production/{row['missionId']}.truth.json")["canonical"]
    pack = read(row["packPath"])
    result = oracle.verify_pack(truth, pack)
    artifacts = {a["name"]: a["content"] for a in pack["result"]["artifacts"]}
    prepared = json.loads(artifacts["prepared-offers.json"])
    findings = result["findings"] + oracle.verify_canonical(truth["offers"], prepared)
    if findings or row["status"] != "ACCEPTED" or row["independentAcceptance"] != "PASS":
        pack_failures.append({"arm": row["arm"], "mission": row["missionId"], "findings": findings})
    program = json.loads(artifacts["constructed-adapter.json"])
    program_fields[row["taskId"]].append(program["fields"])
    created[row["arm"]].append(pack["createdAt"])
    ev = pack["evaluation"]
    if not (ev["scope"] == "PUBLIC_LOCAL_EXECUTION" and ev["admission"] == "HOLD"
            and ev["independentProof"] is False and ev["authority"] == []
            and ev["settlement"] == "NOT_CONNECTED"):
        authority_failures.append({"arm": row["arm"], "mission": row["missionId"], "evaluation": ev})
record("480_preserved_pack_semantics", len(rows) == 480 and not pack_failures,
       {"methodEvaluations": len(rows), "uniqueJobs": len({r['missionId'] for r in rows}),
        "semanticFailures": pack_failures})
record("shared_runtime_authority_bounds", not authority_failures, authority_failures)
for arm, arm_rows in sorted(per_arm.items()):
    record(f"unique_jobs:{arm}", len(arm_rows) == 96
           and {r["missionId"] for r in arm_rows} == expected_missions)
    record(f"recorded_acceptance:{arm}", metrics["arms"][arm]["accepted"]
           == sum(r["status"] == "ACCEPTED" for r in arm_rows) == 96)
    cutoff = llm_freeze["frozenUtc"] if arm == "current_llm" else freeze["frozenAtUtc"]
    cutoff = datetime.datetime.fromisoformat(cutoff.replace("Z", "+00:00"))
    record(f"recorded_freeze_precedes_packs:{arm}", all(
        datetime.datetime.fromisoformat(t.replace("Z", "+00:00")) > cutoff for t in created[arm]),
        {"earliestRecordedPack": min(created[arm]), "note": "Local timestamps are not external timestamp attestations."})
record("all_five_methods_same_fields", all(all(p == ps[0] for p in ps)
       for ps in program_fields.values()), {"schemas": len(program_fields)})

for arm in sorted(set(per_arm) - {"current_llm"}):
    builds = [b for b in raw["constructions"] if b["arm"] == arm]
    counts = {k: sum(b[k] for b in builds) for k in
              ("labelQueries", "candidateEvaluations", "selectionOperations")}
    record(f"raw_counters:{arm}", all(counts[k] == metrics["arms"][arm][k]
           for k in counts) and len(builds) == metrics["arms"][arm]["constructions"], counts)
    record(f"construction_caps:{arm}", all(b["labelQueries"] <= 8
           and b["candidateEvaluations"] <= 200000 for b in builds))
record("retained_active_query_tie_each_schema", all(
    r["retained"]["labelQueries"] == r["active_specialist"]["labelQueries"]
    for r in metrics["perSchema"]))
events = [json.loads(line) for line in (ROOT / "agent-baseline/oracle-events.jsonl").read_text().splitlines() if line.strip()]
record("llm_oracle_request_count", len(events) == 29
       == sum(p["metrics"]["labelQueries"] for p in programs.values()))
record("llm_explicit_budget_audit", read("agent-baseline/BUDGET_AUDIT.json")["allWithinCaps"])

boundaries = read("results/boundaries-v1/results.json")
record("boundary_record_counts", boundaries["uniqueProbes"] == 24
       and len(boundaries["rows"]) == boundaries["repeatedEvaluations"] == 72
       and all(r["refused"] and r["passed"] for r in boundaries["rows"]),
       {"uniqueProbes": 24, "methodEvaluations": 72,
        "strategies": sorted({r['strategy'] for r in boundaries['rows']}),
        "currentLLMConstructorAmbiguityProbes": "NOT_RUN"})

for name, canonical in [("seed", read("results/connected-loop-v1/seed-input.json")),
                        ("qualification", read("evaluation/sealed/production/H01-M1.truth.json")["canonical"]),
                        ("next", read("evaluation/sealed/production/H01-M2.truth.json")["canonical"])]:
    pack = read(f"results/connected-loop-v1/{name}-pack.json")
    result = oracle.verify_pack(canonical, pack)
    if name != "seed":
        artifacts = {a["name"]: a["content"] for a in pack["result"]["artifacts"]}
        result["findings"] += oracle.verify_canonical(canonical["offers"], json.loads(artifacts["prepared-offers.json"]))
    record(f"connected_pack:{name}", not result["findings"], result["findings"])
ledger = read("results/connected-loop-v1/ledger-after-next.json")
record("connected_no_observed_cash_or_investment", all(v is None
       for v in ledger["evaluation"]["observed"].values())
       and not any(e["type"] == "investment" for e in ledger["ledger"]["events"]))

econ = read("economics/results-v1/summary.json")
record("economic_input_identity", digest("economics/results-v1/metrics-input.json")
       == econ["metricsSHA256"] == digest("results/metrics.json"))
record("economic_unknowns_preserved", all(econ[k] is None for k in
       ("actualFullCostUSD", "actualHumanDurationMinutes", "actualCustomerCollectionsUSD")))
record("economic_four_arm_scope", set(econ["measuredResources"]) == set(per_arm) - {"current_llm"})
financial_audit = read("economics/results-audit-v1.json")
record("prior_rational_finance_audit_receipt", financial_audit["status"] == "PASS"
       and financial_audit["totalAssertions"] == 5118,
       {"independentArithmeticAuditAssertions": financial_audit["totalAssertions"],
        "note": "Receipt inspected; this audit does not claim a new full financial recalculation."})
record("resource_correction_does_not_alter_primary", read("economics/resources-v1.1.json")["primaryCriteriaOrOutcomesChanged"] is False
       and read("economics/resources-v1.1.json")["originalResultsPreserved"] is True)

receipt = {"status": "PASS" if all(c["passed"] for c in checks) else "FAIL",
           "scope": "Same-session read-only evaluator audit; existing frozen oracle rerun on preserved packs, no candidate construction or production execution rerun.",
           "checkedAtUtc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
           "checks": checks, "checksPassed": sum(c["passed"] for c in checks),
           "checksTotal": len(checks), "candidateOutcomesChanged": False,
           "frozenFilesChanged": False,
           "scriptSHA256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
           "limitations": ["Same-session procedural separation, not external blinding.",
                           "480 report evaluations share 96 unique jobs and 24 schema clusters.",
                           "The LLM constructor's four construction-ambiguity boundary probes were not run.",
                           "Observed full monetary cost, model billing, human duration and customer collections remain unknown.",
                           "No deployed, authenticated, browser, RPC, contract or financial operation was attempted."]}
output = ROOT / "evidence/FINAL_INDEPENDENT_CHECKS.json"
with output.open("x") as f:
    json.dump(receipt, f, indent=2)
    f.write("\n")
print(json.dumps({k: receipt[k] for k in ("status", "checksPassed", "checksTotal")}, indent=2))
if receipt["status"] != "PASS":
    print(json.dumps([c for c in checks if not c["passed"]], indent=2))
    raise SystemExit(1)
