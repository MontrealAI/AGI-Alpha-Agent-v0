# SPDX-License-Identifier: Apache-2.0
import collections, csv, hashlib, json, random, statistics, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
raw = json.loads((ROOT / 'results/confirmation-v1/raw-summary.json').read_text())
arms = {}
for arm in sorted({r['arm'] for r in raw['outcomes']}):
    outcomes = [r for r in raw['outcomes'] if r['arm'] == arm]
    builds = [r for r in raw['constructions'] if r['arm'] == arm]
    arms[arm] = {'missions': len(outcomes), 'accepted': sum(r['status'] == 'ACCEPTED' for r in outcomes),
        'refused': sum(r['status'] == 'REFUSED' for r in outcomes),
        'incorrectAccepted': sum(r['status'] == 'ACCEPTED' and r['independentAcceptance'] != 'PASS' for r in outcomes),
        'rejectedByIndependentCheck': sum(r['status'] == 'REJECTED_BY_INDEPENDENT_CHECK' for r in outcomes),
        'constructions': len(builds), 'constructed': sum(r['status'] == 'CONSTRUCTED' for r in builds),
        'labelQueries': sum(r['labelQueries'] for r in builds), 'candidateEvaluations': sum(r['candidateEvaluations'] for r in builds),
        'selectionOperations': sum(r['selectionOperations'] for r in builds),
        'constructionCpuMs': sum(r['cpuMs'] for r in builds), 'constructionWallMs': sum(r['wallMs'] for r in builds),
        'productionCpuMs': sum(r['productionCpuMs'] for r in outcomes),
        'verificationCpuMs': sum(r.get('verificationCpuMs', 0) for r in outcomes),
        'packagingCpuMs': sum(r.get('packagingCpuMs', 0) for r in outcomes),
        'productionWallMs': sum(r['productionWallMs'] for r in outcomes),
        'verificationWallMs': sum(r.get('verificationWallMs', 0) for r in outcomes),
        'packagingWallMs': sum(r.get('packagingWallMs', 0) for r in outcomes),
        'wallMs': sum(r['wallMs'] for r in builds) + sum(r['productionWallMs'] + r.get('verificationWallMs', 0) + r.get('packagingWallMs', 0) for r in outcomes),
        'artifactBytes': sum(r.get('artifactBytes', 0) for r in outcomes),
        'reuseMissions': sum(r['reused'] for r in outcomes), 'actualFullCostUsd': None, 'actualCustomerMinutes': None}
per_schema = []
for task in sorted({r['taskId'] for r in raw['outcomes']}):
    row = {'schemaId': task, 'family': next(r['family'] for r in raw['outcomes'] if r['taskId'] == task)}
    for arm in arms:
        row[arm] = {'labelQueries': sum(r['labelQueries'] for r in raw['constructions'] if r['arm'] == arm and r['task'] == task),
            'accepted': sum(r['status'] == 'ACCEPTED' for r in raw['outcomes'] if r['arm'] == arm and r['taskId'] == task)}
    per_schema.append(row)
rng = random.Random(20261025)
comparisons = []
for left, right in [('retained', 'ordinary_reuse'), ('retained', 'active_specialist'), ('active_specialist', 'ordinary_reuse')]:
    diffs = [r[left]['labelQueries'] - r[right]['labelQueries'] for r in per_schema]
    samples = sorted(statistics.mean(rng.choices(diffs, k=len(diffs))) for _ in range(10000))
    comparisons.append({'left': left, 'right': right, 'metric': 'labelQueries_per_schema_left_minus_right',
        'meanDifference': statistics.mean(diffs), 'pairedBootstrap95': [samples[249], samples[9749]],
        'schemaUnits': 24, 'seed': 20261025, 'resamples': 10000})
training = raw['meta']
epochs = []
for folder in ['development-v0', 'development-v1', 'development']:
    item = json.loads((ROOT / 'results' / folder / 'summary.json').read_text())['training']
    epochs.append({'epoch': folder, **item})
metrics = {'edition': 'NADV-2026-01', 'primaryFreeze': raw['freezeId'], 'source': raw['source'], 'uniqueFreshMissions': 96,
    'schemaTasks': 24, 'arms': arms, 'perSchema': per_schema, 'pairedComparisons': comparisons,
    'meta': {'training': training, 'developmentEpochs': epochs,
        'allEngineeringValidationQueries': sum(e['labelQueries'] for e in epochs),
        'allEngineeringValidationCpuMs': sum(e['cpuMs'] for e in epochs),
        'interpretation': 'Only one12-schema episode defines the learned recipe. Two retained development reruns are engineering validation, not independent samples; complete actual authoring/setup remains unknown and nonzero modeled setup covers this work.'},
    'human': {'measuredMinutes': None}, 'actualCollections': None,
    'conclusions': {'A': 'CONDITIONAL_HUMAN_TIME_THRESHOLDS_ONLY',
        'B': 'NEW_INPUT_CAPABILITIES_QUALIFIED; ACTIVE_METHOD_BEATS_SEQUENTIAL_LABEL_USE; RETAINED_RECIPE_TIES_ACTIVE',
        'C': 'ACTUAL_FINANCEABILITY_UNKNOWN; SCENARIOS_REQUIRED',
        'metaConstruction': 'NO_BENEFIT_BEYOND_ACTIVE_SPECIALIST', 'sustainedAcceleration': 'NOT_ESTABLISHED'}}
(ROOT / 'results/metrics.json').write_text(json.dumps(metrics, indent=2) + '\n')
with (ROOT / 'results/outcomes.csv').open('w', newline='') as f:
    fields = ['arm','taskId','family','missionId','status','independentAcceptance','reused','programHash','totalMinor','productionCpuMs','verificationCpuMs','productionWallMs','verificationWallMs']
    writer = csv.DictWriter(f, fields, extrasaction='ignore');writer.writeheader();writer.writerows(raw['outcomes'])
with (ROOT / 'results/constructions.csv').open('w', newline='') as f:
    fields = ['arm','task','mission','status','labelQueries','candidateEvaluations','selectionOperations','cpuMs','wallMs']
    writer = csv.DictWriter(f, fields, extrasaction='ignore');writer.writeheader();writer.writerows(raw['constructions'])
print(json.dumps({'arms': arms, 'paired': comparisons}, indent=2))
