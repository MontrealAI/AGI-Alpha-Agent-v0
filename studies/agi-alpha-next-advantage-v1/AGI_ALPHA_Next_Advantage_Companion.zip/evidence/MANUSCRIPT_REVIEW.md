# Manuscript factual review

**Manuscript:** `paper/AGI_ALPHA_Build_the_Next_Advantage.tex`  
**Reviewed corrected snapshot SHA-256:** `93cd0da8deaf125caf05e86683c56f35440830ee1a8288a887e7fb396deb3177`  
**Date:** 25 October 2026  
**Scope:** factual, methodological, numerical, provenance and authority review. The reviewer did not edit the TeX, compile it, inspect rendered pages, rerun the experiment, or change frozen source or outcomes.

## Disposition

No remaining material scientific or numerical contradiction was identified in the corrected snapshot above. Three factual wording errors were reported to the manuscript author during review and were corrected by the author before this receipt. The latest read verifies all three corrections. The explicit boundary-coverage, after-outcome replay, demonstration-order, unknown-cost and source-authority qualifications are present.

This is the same-session evaluator review described in `FINAL_INDEPENDENT_REVIEW.md`, not external peer review. It checks the manuscript against the preserved protocol, implementation, result records, economic analysis and earlier source/lineage audits.

## Material corrections identified and verified

| Finding | Evidence | Corrected statement now present |
|---|---|---|
| The earlier text implied that both native accounting modules used microdollars. | `vendor/shared/automated-costs.mjs` uses micros; `shadow-ledger.mjs` uses `amountMinor`. `economics/analyze.mjs` converts with `Math.ceil(micros / 10000)`. | The cost contract uses integer microdollars and exact rational intermediates; the ledger uses integer currency minor units, USD cents here. Conversion rounds upward. |
| The earlier base-setup sentence priced four review hours at the professional rate. | The analyzer prices engineering at $73.69/hour and review at $36.73/hour. Both at the professional rate would total $1,573.80 rather than the recorded $1,425.96. | Sixteen engineering hours at $73.69/hour, four review hours at $36.73/hour, plus $100 authoring allowance: $1,425.96. |
| The earlier LLM timing sentence called 7.023 seconds a production-evaluation total although it included construction. | `current-llm-v1/summary.json`: construction wall 763.166087 ms; production 3,234.275258 ms; verification 2,951.220535 ms; packaging 73.880763 ms. | Combined recorded construction-and-delivery wall time is 7.023 seconds, comprising 0.763 seconds construction and 6.259 seconds delivery/verification/packaging. Model inference and interactive authoring remain excluded. |

These were reporting corrections; no primary criterion, source program, measurement, acceptance, economic calculation or financial path changed.

## Requested grammar and budget checks

The **eight-label limit is a cap per construction**, not a claim that every task consumes eight examples. It agrees with the frozen protocol, `LIMITS.labels`, recorded deterministic construction calls and the LLM budget audit. The 200,000 candidate-evaluation cap and separate selection-operation accounting are described correctly. The text correctly avoids equating equal caps with equal consumed CPU, instruction counts or monetary resources.

The revised price description now correctly separates **bare nonnegative integer minor units** from **decimal point/comma forms with exactly two fractional digits**. Only decimal forms allow a leading `$`/`€` or a trailing three-letter currency code; the two affixes are mutually exclusive. `$` requires USD and `€` requires EUR. The full companion grammar supplies exact ASCII syntax, no leading zeroes, text/unit limits, upper bounds and explicit currency consistency. The manuscript does not enlarge the executable grammar or promise arbitrary supplier-document interpretation.

The finite-program construction description, ambiguity refusal, first-fresh-job qualification and subsequent reuse are consistent with the implemented experimental route. These are experimental operating limits, not claims that a local JavaScript function constitutes an external access-control boundary.

## Counts, comparisons and economic results

The following manuscript claims agree with the preserved evidence:

- Twelve development schemas in three families, 24 held-out schemas in six families, four fresh missions per held-out schema, and **96 unique jobs**.
- Five methods each accept **96/96** nominal jobs. The **480 evaluations are repeated method–job evaluations**, not 480 independent jobs.
- Rebuild/ordinary/retained/active/current-LLM production labels are **244/61/29/29/29**. All six family totals match `metrics.json`.
- The retained recipe's additional **31-example episode** and **93 calls across three preserved engineering executions** are distinguished correctly. The LLM's own 15 selected development examples and validation against 192 public labels are also disclosed.
- Retained minus ordinary is −1.333 labels/schema, with recorded family-stratified interval [−1.833, −0.833]. Retained minus active is zero for every schema. No builder superiority over the active incumbent or sustained acceleration is claimed.
- Boundary coverage is **24 unique probes / 72 checks across three deterministic strategies**. The separate LLM constructor's missing four construction-ambiguity tests are explicit.
- The four-arm cost table, human-duration thresholds, $43.015834 extra recipe expense, approximately −$41.79 tested-episode retained-versus-ordinary modeled net, and unknown LLM full monetary cost are consistent with the economic record.
- The financing study has **30 simulated paths**, a hypothetical **$422.17** complete capability package and **1,408** break-even reuses. The 50% conditional-success path's **$42,124.56** final cash, **$4,410** receivables and **$283.43** net capability benefit match the machine record. Affordability, payback, delayed collection, failure and protected balances remain explicitly hypothetical.
- The independent economic audit's **5,118 assertions**, 12 cost rows, 30 paths and 360 monthly snapshots match its receipt. Its validity is not presented as validation of assumed demand or human duration.

The description does not turn zero external runtime provider calls into zero total research or service cost. Customer price, provider cost, customer attention, external seed, simulated collections and observed earned surplus remain separated.

## Sources, authorship, runtime and authority

The prior-edition lineage counts agree with the saved lineage audit. The paper distinguishes researcher-authored infrastructure and grammar from example-selected executable mappings, inherited optimizer adoption, and runtime integration. It does not claim new optimization-algorithm invention or researcher-independent scientific agenda selection.

Executed source identities match the prior audit: Alpha `95d1e97d…`, AWE `3d27c183…`, and the exact shared module extraction at source-assurance `2c5c393c…`. The paper correctly separates the latter from earlier owner-status snapshots. The existing Workbench, native accounting schemas and unfunded Jobs compilation remain the reused components; the work is not described as a replacement runtime or deployed scheduler.

The source-inspected $AGIALPHA mechanisms and Manager USDC route remain distinct. The text does not invent buybacks, token appreciation, universal holder rights, enterprise-profit distributions or executed reinvestment. It correctly distinguishes source inspection from current deployed configuration and preserves original security, Harness, Fleet and browser restrictions.

The connected sequence is expressly a **scripted after-outcome replay** of executed cases. The demo constructs its adapter before the first new raw-input delivery rather than pretending to rediscover the original limitation on every click. Its local crosschecks are not misrepresented as a browser-executed independent oracle, and archived acceptance does not transfer to user edits.

## Verification scope still outside this factual review

The paper says the edition's public website deployment is **NOT CLAIMED** and browser visual execution is **NOT RUN**. Those statements are consistent with the reviewed record. This review does not qualify final PDF layout, an assembled companion, actual public URLs, publication-owner acceptance or installed/authenticated operation.

At the final factual read, the root `reproduce.py` entry point referenced in the manuscript had not yet been written, and publication metadata was being assembled. These are pending package-completion checks for the author, not revised research findings. The advertised reproduction command and publication-pipeline status should be verified against the final delivered package before release. No replacement pipeline or held operation was invoked by this review.
