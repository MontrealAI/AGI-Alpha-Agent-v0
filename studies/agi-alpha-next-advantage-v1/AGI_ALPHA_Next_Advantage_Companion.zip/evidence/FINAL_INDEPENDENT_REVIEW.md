# Final independent evaluator review

**Edition:** AGI ALPHA FLYWHEEL — Build the Next Advantage, NADV-2026-01.  
**Review scope:** preserved local source, protocol, data, results, economics, and execution boundaries on 25 October 2026.  
**Disposition:** the bounded computational findings are supported. No frozen-file alteration, data-commitment mismatch, or incorrect accepted report was found. The economic and meta-construction null conclusions must remain prominent. This review grants no deployment, financial, or publication authority.

The reviewer owned the independent data generator and Python semantic oracle and did not author the candidate builders. The work shares the same supervising research session and filesystem. “Independent” here means separate implementation and evaluator responsibility, not external peer review, secure blinding, or organizational independence.

## 1. Checks performed

`FINAL_INDEPENDENT_CHECKS.json` records **47/47 grouped checks passed**. The reproducible audit source is `final_independent_checks.py`; it reads preserved evidence and writes only its own new receipt. It does not rerun capability construction, mutate results, or revise acceptance criteria. A second audit should use a new receipt filename or a clean copy; its exclusive output creation preserves the first review.

| Evidence | Direct check | Result |
|---|---|---|
| Primary protocol/source freeze | All 371 listed file digests | Match |
| Original data commitment | All 324 committed dataset file digests | Match |
| LLM comparator freeze | 187 authored/evidence artifacts and 50 permitted-input digests | Match |
| Primary reports | Recompute complete report/cart semantics and prepared six-field offers for all 480 saved method evaluations | All pass |
| Connected journey | Independently recompute seed, qualification, and next-mission packs | All three pass |
| Counts and scope | Unique missions, schema clusters, raw counters, acquisition caps, local authority labels, freeze-before-pack timestamps | Consistent |
| Economics | Input/source identities, unknown actual quantities, preserved correction, existing separate arithmetic-audit receipt | Consistent |

The 932 digest comparisons include overlapping evidence; they are not 932 independent experiments. The 480 report checks are **five evaluations of the same 96 unique jobs**, organized in 24 schema clusters. Rechecking saved reports adds no new customer deliveries or independent research observations. The locally recorded timestamps support the stated execution order but are not external timestamp attestations.

Primary freeze ID: `d0d0f94598c86f3b76e22c78ea50944c58df115ad2639cdfe02c6d9388c9e9e7`. Dataset-commitment SHA-256: `845c88965caca5cf398e10e3e6e91cfab5da46f9eed42bbb9de06feead17a53c`. Final LLM program-file SHA-256: `804fcb6d229c52b56f5123b4f7c3f55935b095129a59a80958ed112c13132d9e`.

## 2. Protocol and leakage review

The committed split is 12 development schemas in three families and 24 held-out schemas in six families, four schemas per family. Development and held-out header names are disjoint. Weekly lead, affixed currency, and mixed alternative views are held-out compositions of primitives already disclosed to every builder. The appropriate generalization claim is transfer within this finite grammar, including unseen compositions; it is not unrestricted understanding of arbitrary supplier documents.

Each construction task exposes 16 raw pool rows and permits at most eight canonical labels and 200,000 candidate evaluations. The deterministic counters and the LLM's conservative budget accounting remain within those caps. Equal caps do not establish equal consumed CPU, token cost, information-processing implementation, or complete authoring resources. The candidate-evaluation definitions are disclosed separately; the LLM conservative count includes parse attempts plus label comparisons.

The frozen deterministic source uses only requested labels for candidate elimination; production truth is supplied to the evaluator after output generation. The retained recipe is derived from development traces. The LLM record discloses its permitted reads, 29 explicit oracle requests, one primary acquisition, pre-production source correction, replay, sibling grammar advice, and incidental exposure to sibling summary metadata. No production answer leakage is evidenced by the inspected record. Hashes and a shared filesystem cannot prove that leakage was impossible. Preserve the explicit procedural-separation limitation.

Both post-outcome reporting corrections are disclosed and additive. `evidence/REPORTING_CORRECTION.json` retains the first pooled-bootstrap source/output and corrects the implementation to the frozen family-stratified paired design. `economics/RESOURCE_REPORTING_AMENDMENT-v1.1.md` retains the original economics and adds omitted packaging CPU while leaving complete CPU unknown. Neither changes primary outcomes, query counts, acceptance criteria, or economic assumptions. Use the corrected outputs for their respective descriptive claims.

## 3. Supported results and the null finding

| Method | Accepted reports / same 96 jobs | Constructions | Production label queries | Additional learned-recipe episode |
|---|---:|---:|---:|---|
| Rebuild each mission | 96/96 | 96 | 244 | None |
| Ordinary reuse | 96/96 | 24 | 61 | None |
| Retained construction recipe | 96/96 | 24 | 29 | 31 development queries; authoring/upkeep also required |
| Conventional active specialist | 96/96 | 24 | 29 | None |
| Current-session LLM-assisted constructor | 96/96 | 24 | 29 | Its own development/authoring process; complete inference and authoring cost unknown |

All five methods produced the same canonical field mappings for each of the 24 schemas. All accepted packs retained `PUBLIC_LOCAL_EXECUTION`, `independentProof:false`, `admission:HOLD`, empty authority, and `settlement:NOT_CONNECTED`. Technical acceptance by the separate study oracle does not alter these native operational labels.

The retained-versus-ordinary reduction is 32 production queries, or 1.333 queries per schema. The recorded paired, family-stratified 95% interval for retained minus ordinary is −1.833 to −0.833 queries per schema. Retained minus active is exactly zero for every schema and has interval [0, 0]. These describe this synthetic sampling design, not a population of market jobs. Ordinary reuse already supplies the large 244-to-61 reduction; that effect must not be attributed uniquely to the learned recipe.

One retained training episode uses 31 queries. The three preserved engineering executions repeat that same episode, totaling 93 calls; they are not three independent learning successes. Against ordinary reuse, one query remains saved after charging the 31-example episode, before extra engineering and upkeep. Against the active specialist, the episode creates additional cost with no measured query or coverage advantage. **Improvement of improvement beyond the strongest tested active comparator and sustained acceleration are not established.**

### Boundary coverage qualification

The preserved boundary result is **24 unique probes, 72 repeated evaluations, all refused as specified**, across sequential, active, and retained deterministic strategies. There are four construction-ambiguity probes and 20 production-boundary probes. The separate LLM constructor was not run on the four ambiguity probes. The production interpreter is common, and all five methods produced identical mappings on the nominal schemas, but this does not substitute for testing the separate constructor's ambiguity behavior. Do not state that all five constructors passed all 24 probes. This is a limitation to disclose, not a reason to silently expand or revise the frozen experiment.

The current LLM comparison is one actual same-session LLM-assisted tool-and-code construction process followed by a reproducible frozen Python constructor. It does not measure complete LLM-agent delivery latency, model inference cost, or a provider-billed matched-dollar comparison. Its 96 correct reports and 29 acquisition queries are supported; any economic ranking involving its unknown full cost is not.

## 4. Connected loop: what actually ran

`implementation/connected_loop.mjs` and `results/connected-loop-v1/` contain an executed local sequence: canonical seed deliverable; observed raw-table input refusal; example-driven program construction; independently verified qualification; program reuse on the next mission; and shared-ledger updates ending in financial HOLD. The seed and both subsequent packs pass the semantic oracle. The constructed program is selected from examples, not manually inserted as a task-specific solution after the outcomes.

This is a **scripted, after-outcome replay of frozen study cases**, as its execution inventory already states. The researcher supplied the mission choice, grammar, stage transitions, and prospective opportunity class. The runtime did not autonomously discover a customer market, invent the optimizer, negotiate prices, or start a persistent business. Its retained method choice reflects the observed active-specialist tie. The loop visibly connects useful execution, a preparation limitation, actual capability construction, qualification and reuse; it does not supply another independent confirmatory sample.

Actual seed/setup/construction monetary cost and customer receipts are not metered. Construction resource counters exist; full monetary amounts remain unknown. The native ledger has unknown actual revenue, full cost, obligations, reserves and available investment, and records no investment transaction. The final stop is therefore appropriate. The separate hypothetical financial projections do not convert this replay into observed resource-financed succession.

## 5. Economic interpretation

The three questions are kept separate in `economics/RESULTS-v1.md` and the native records:

**A — Human-work economics:** actual matched human duration is unmeasured. The base active-specialist scenario gives $1.211784 fully loaded modeled provider cost per accepted report, with 4.9795 minutes of office/administrative work as the total-resource threshold after three assumed customer-attention minutes. A $15 assumed customer price produces a different buyer threshold, 27.5031 minutes at the same compensation basis. Neither threshold demonstrates that competent unaided humans need that time, that customers pay that price, or that realized savings exist. Base, conservative and stress costs remain conditional on utilization, schema novelty, amortization and residual effort.

**B — Incremental Flywheel benefit:** the retained recipe is not promoted. The active specialist is the least expensive method within the four deterministic modeled scenarios. That conclusion excludes the LLM's unknown full cost. The 96-job base scenario yields approximately −$41.79 retained-versus-ordinary and −$80.97 retained-versus-active conditional net benefit after the declared additional recipe expense. These are modeled results, not measured cash losses. Preserve the distinction between amortized future-volume unit costs and payback over the observed finite episode.

**C — Financeable succession:** all 30 paths model a hypothetical future capability. None is a measured continuation of this recipe's benefit. The declared $422.17 package includes prior failed construction; 1,408 assumed reuses are needed at the stated net unit saving. Successful financing windows coexist with low demand, failed construction, zero saving, protected balances, and delayed-collection cases. Actual collections and observed available surplus remain null. Seed capital is not earned surplus, customer savings are not provider revenue, and no token issuance is booked as profit.

The existing independent rational-arithmetic audit reports 5,118 assertions over 12 cost rows, 30 paths and 360 monthly snapshots. This review inspected its receipt and bindings; it does not claim another complete financial recalculation. The unchanged shared cost and ledger modules are used. Publication must use `resources-v1.1.json` for partial CPU descriptions; even corrected recorded CPU is not complete CPU or a bill.

## 6. Paper-ready ecosystem and currency paragraph

> This edition executes the existing Alpha Workbench and Autonomous Work Economy quote adapter, retains the established quote optimizer, compiles unfunded Jobs drafts, and uses the unchanged shared cost and shadow-ledger contracts. TRANSFORMATIONAL INTELLIGENCE and earlier Harness editions motivate the workflow and provide foundations; held native Harness and Fleet operations are not newly qualified by this experiment. Source inspection distinguishes the applicable $AGIALPHA paths from the Manager's USDC settlement route. Jobs v0's FeePool binds $AGIALPHA and implements configured fee burns and conditional staker rewards; Alpha's receipt accounting can record a reinvestment earmark with execution explicitly false. The Manager's inspected settlement logic allocates USDC to its configured recipients, validator budget and agent remainder. These are implementation-specific mechanisms, not a claim of automatic cross-route buybacks, enterprise-profit distributions, token appreciation or universal holder rights. This study performs no token or financial transaction and verifies no current deployed configuration.

| Component | Actual contribution in this edition | Boundary / exact source |
|---|---|---|
| Alpha Workbench | Local adapter execution, artifact/mission/source binding, standard pack, unfunded Jobs compilation | Alpha `95d1e97d4d1c0aaebd592767fc5e5d2da56f6aa7`, `examples/successor-workbench/engine.mjs` |
| AWE quote workflow | Unchanged normalization, exact cart specialist and report artifacts | AWE archive at `3d27c18362ed8db90dca4e6b85589865712bdbc5`, copied `implementation/adapters.mjs` |
| Shared economic contracts | Native cost tiers and nontransactional shadow ledger | Executed copies are from source-assurance `2c5c393c1e5431c00d59d077c403739e789abd43`; open-candidate provenance, no runtime admission inherited |
| TI guide / SUCCESSOR Ω / Harness | Existing research and interface foundations; Workbench seam used | The experiment does not execute the held native Harness routes or resolve their original review/merge decisions |
| AGI Fleet Linux | Inspected receiving/route interface | `45759fb096faf8988f58ae5ea71248d0f35a97c7`, `local-runtime/project/transfer.mjs`; authority none, production unqualified, settlement not connected |
| AGI Jobs v0 | Existing unfunded compilation foundation; token implementation inspected | `bc4abbd5c28f3672275b13300e40ea26c820b8ee`, `contracts/v2/FeePool.sol`; conditional $AGIALPHA fee/staking mechanisms, not exercised |
| AGI Job Manager | Distinct USDC route inspected | `5d5670df9dbbc79da115e0a44b71989f34df58c1`, `contracts/utils/JobSettlement.sol`; no settlement executed |

The executed shared-module source commit above comes from `vendor/SOURCE_MANIFEST.json` and `economics/SOURCE_PROVENANCE.json`. Do not replace it with the earlier #4907 owner snapshot `1d46b4d…` in the ecosystem audit. The exact arithmetic bytes match the canonical hashes, but an owner-status snapshot and an extraction commit are different provenance facts.

Primary source links for the currency statements: [Manager settlement](https://github.com/MontrealAI/AGIJobManager/blob/5d5670df9dbbc79da115e0a44b71989f34df58c1/contracts/utils/JobSettlement.sol), [Jobs FeePool](https://github.com/MontrealAI/AGIJobsv0/blob/bc4abbd5c28f3672275b13300e40ea26c820b8ee/contracts/v2/FeePool.sol), [Alpha receipt accounting](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/blob/95d1e97d4d1c0aaebd592767fc5e5d2da56f6aa7/alpha_factory_v1/core/runtime/chain.py), and [Fleet route](https://github.com/MontrealAI/AGI-Fleet-Linux/blob/45759fb096faf8988f58ae5ea71248d0f35a97c7/local-runtime/project/transfer.mjs). These were source-inspected in the earlier audit; this final review rechecked the saved source excerpts and made no live service or deployment call.

## 7. Security, presentation and publication boundaries

The coordination snapshot in `../../audit/ecosystem.md` retains the source-assurance owner and publication coordinator. #4907's local source-assurance evidence is not authenticated hosted acceptance. #4899 at `2645d198…` retains its mandatory security refusal (56 findings, zero admitted); ordinary code review is not Security clearance. Original Harness #4863/#4865 and Fleet review/merge decisions remain unresolved under their original owners. No fresh writer, source hash or local simulation resets these gates. See the [original action map](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/issues/4850#issuecomment-6386746278).

The bilingual demonstration source states synthetic inputs, fresh local computation, archived same-session semantic evidence, modeled economics and unknown full costs. Its recorded QA distinguishes 30 Node DOM-shim checks and six Python-checked engineering packs from browser rendering. **Browser rendering/interaction is NOT RUN**, with the original socket-EPERM restriction preserved. Those six packs and the connected replay must not increase the 96 unique-job denominator.

This audit does not certify a final rendered manuscript, a finished publication archive, working public download URLs, authenticated installation, persistent operation, or a live business. Those statuses must follow their own actual evidence. A public Git file, a local page and a live served publication are different states. Preserve all prior editions and coordinate any publication through the existing owner.

## 8. Defensible original contribution

The supported advance is an executable, example-derived input-capability construction layer integrated into the existing useful quote-delivery workflow, with complete held-out deliverable verification, explicit refusal boundaries, ordinary-reuse and strong active/LLM-assisted comparators, and native accounting that separates technical qualification from economic promotion. It closes a documented preparation-contract gap without claiming a new optimizer. It also tests a retained builder recipe and exposes its failure to improve on the active incumbent after construction cost. The latter is a substantive negative result and should remain visible in the title-level interpretation, abstract, figures and demonstration.
