# SPDX-License-Identifier: Apache-2.0
import argparse, hashlib, json, re
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def build(data_path: Path, runtime_path: Path, output_path: Path) -> dict:
    data = json.loads(data_path.read_text())
    if not isinstance(data.get("examples"), list) or not data["examples"]:
        raise ValueError("Actual example data are required; no placeholder outputs are generated")
    for example in data["examples"]:
        if not all(key in example for key in ("id", "task", "labels", "missions")):
            raise ValueError("Each example needs id, task, labels and missions")
    runtime = runtime_path.read_text()
    if "NEXT_ADVANTAGE" not in runtime or "runExample" not in runtime:
        raise ValueError("Exact runtime must expose NEXT_ADVANTAGE.runExample")
    paths = [ROOT / "index.template.html", ROOT / "style.css", ROOT / "app.js", data_path, runtime_path]
    def logical_path(path: Path) -> str:
        return str(path.relative_to(ROOT.parent)) if path.is_relative_to(ROOT.parent) else path.name
    manifest = {"sources": [{"path": logical_path(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()} for path in paths]}
    manifest["sourceHash"] = hashlib.sha256(json.dumps(manifest, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    embedded = dict(data)
    embedded["sourceHash"] = manifest["sourceHash"]
    payload = json.dumps(embedded, ensure_ascii=False, separators=(",", ":")).replace("<", "\\u003c").replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")
    def safe_script(text: str) -> str:
        return re.sub(r"</script", r"<\\/script", text, flags=re.IGNORECASE)
    html = (ROOT / "index.template.html").read_text().replace("/*__STYLE__*/", (ROOT / "style.css").read_text()).replace("/*__DATA__*/", payload).replace("/*__RUNTIME__*/", safe_script(runtime)).replace("/*__APP__*/", safe_script((ROOT / "app.js").read_text()))
    if any(marker in html for marker in ("/*__STYLE__*/", "/*__DATA__*/", "/*__RUNTIME__*/", "/*__APP__*/")):
        raise ValueError("Unfilled template marker")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(html)
    manifest["output"] = str(output_path)
    manifest["html_sha256"] = hashlib.sha256(output_path.read_bytes()).hexdigest()
    manifest["bytes"] = output_path.stat().st_size
    manifest["browser_validation"] = "NOT RUN: original local Chromium socket EPERM restriction preserved"
    manifest["runtime_scope"] = "Pure local existing Workbench and quote adapter; no installed, persistent or financial execution"
    (ROOT / "build-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    return manifest


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=Path, default=ROOT / "demo_data.json")
    parser.add_argument("--runtime", type=Path, default=ROOT / "runtime_bundle.js")
    parser.add_argument("--output", type=Path, default=ROOT / "AGI_ALPHA_Build_the_Next_Advantage.html")
    args = parser.parse_args()
    result = build(args.data.resolve(), args.runtime.resolve(), args.output.resolve())
    print(json.dumps({key: result[key] for key in ("output", "bytes", "html_sha256", "sourceHash")}))
