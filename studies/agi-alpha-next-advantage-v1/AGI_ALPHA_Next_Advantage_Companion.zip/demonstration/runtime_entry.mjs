// SPDX-License-Identifier: Apache-2.0
import {synthesize, sha256, stable} from '../implementation/synthesis.mjs';
import {deliver, localCrosscheck} from '../implementation/delivery.mjs';

async function runExample({example, editedMission = null, signal, onStage = () => {}}) {
  const started = performance.now();
  const checkpoint = async name => { if (signal?.aborted) throw Error('CANCELLED'); onStage(name); await new Promise(resolve => setTimeout(resolve, 30)); };
  await checkpoint('identify');
  const sourceHash = globalThis.NEXT_ADVANTAGE_SOURCE;
  if (typeof sourceHash !== 'string' || !/^[a-f0-9]{64}$/.test(sourceHash)) throw Error('BUNDLE_SOURCE_IDENTITY_REQUIRED');
  await checkpoint('construct');
  const construction = await synthesize(example.task, async i => example.labels[i], {strategy: 'active', signal});
  if (construction.status !== 'CONSTRUCTED') return {construction, first: null, next: null,
    verification: {status: 'NOT_RUN', scope: 'NO_UNIQUE_PROGRAM'}, timing: {wallMs: performance.now() - started}};
  await checkpoint('execute');
  const firstMission = editedMission || example.missions[0];
  const first = await deliver(firstMission, construction.program, {sourceHash, signal});
  await checkpoint('verify');
  const check = localCrosscheck(firstMission, construction.program);
  if (!check.correctOptimum) throw Error('LOCAL_OPTIMALITY_CHECK_FAILED');
  await checkpoint('admit');
  await checkpoint('next');
  const next = await deliver(example.missions[1], construction.program, {sourceHash, signal});
  const second = localCrosscheck(example.missions[1], construction.program);
  if (!second.correctOptimum) throw Error('LOCAL_NEXT_OPTIMALITY_CHECK_FAILED');
  await checkpoint('complete');
  return {construction, first, next,
    verification: {status: 'LOCAL_CHECKS_PASSED', scope: 'LOCAL_ALGORITHMIC_CHECKS; ARCHIVED_PYTHON_INPUT_TRUTH_IS_SEPARATE',
      checks: [check, second], editedInputs: Boolean(editedMission), archivedAuditInherited: false},
    admission: {technical: 'FINITE_SCHEMA_PROGRAM_REUSED', economic: 'HOLD_ACTUAL_FULL_COST_AND_COLLECTIONS_UNKNOWN',
      metaRecipe: 'NOT_PROMOTED; CONVENTIONAL_ACTIVE_METHOD_RETAINED'},
    timing: {wallMs: performance.now() - started, providerModelCalls: 0, modelCost: 0, fullMonetaryCost: null}};
}
globalThis.NEXT_ADVANTAGE = Object.freeze({runExample});
