# Synthetic equipment quote comparison H13-M1

## Decision-ready quote comparison

Recommended eligible cart: **12811.11 USD**, including 54.99 USD of fixed supplier shipping. No purchase was made.

| Item | Supplier | Required units | Delivered units | Packs | Line cost | Delivery days |
|---|---|---:|---:|---:|---:|---:|
| Label roll 1 | SUP-58LVTRWVH | 21 | 24 | 4 | 767.14 USD | 7 |
| Mounting set 2 | SUP-UETNRH78F | 48 | 48 | 2 | 16.74 USD | 7 |
| Label roll 3 | SUP-58LVTRWVH | 50 | 51 | 17 | 10107.37 USD | 0 |
| Paper stock 4 | SUP-58LVTRWVH | 11 | 24 | 1 | 35.60 USD | 14 |
| Mounting set 5 | SUP-EG4H9ZPXD | 7 | 12 | 2 | 706.36 USD | 14 |
| Storage case 6 | SUP-UETNRH78F | 40 | 42 | 7 | 1122.91 USD | 14 |

## Verification and limits

All quantities, the delivery deadline and exact integer-currency totals pass the declared contract. The optimizer enumerates 7 supplier subsets. 5 late offers were excluded.

Prices, supplier names and exchange ratios in the included example are synthetic. For your own permitted quotes, the result is conditional on complete input prices, declared rates and fixed shipping. Taxes, uncertain inventory, quality differences, discounts and split-item purchases are outside this contract.
