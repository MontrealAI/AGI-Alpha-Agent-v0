# Rapport de comparaison des devis

## Présentation française du résultat original

Cette présentation traduit le résultat calculé et l’artéfact anglais original. Aucun nouvel algorithme, calcul de panier ni audit indépendant n’est exécuté lors de cette traduction. L’artéfact original `quote-report.md` reste disponible séparément.

**Mission :** Synthetic equipment quote comparison H13-M1

Panier admissible recommandé : **12 811,11 USD**, dont 54,99 USD de frais fixes de livraison. Aucun achat n’a été effectué.

| Article | Fournisseur | Unités demandées | Unités livrées | Lots | Coût de ligne | Délai en jours |
|---|---|---:|---:|---:|---:|---:|
| Label roll 1 | SUP-58LVTRWVH | 21 | 24 | 4 | 767,14 USD | 7 |
| Mounting set 2 | SUP-UETNRH78F | 48 | 48 | 2 | 16,74 USD | 7 |
| Label roll 3 | SUP-58LVTRWVH | 50 | 51 | 17 | 10 107,37 USD | 0 |
| Paper stock 4 | SUP-58LVTRWVH | 11 | 24 | 1 | 35,60 USD | 14 |
| Mounting set 5 | SUP-EG4H9ZPXD | 7 | 12 | 2 | 706,36 USD | 14 |
| Storage case 6 | SUP-UETNRH78F | 40 | 42 | 7 | 1 122,91 USD | 14 |

## Vérifications et limites

Les quantités, l’échéance déclarée et les totaux monétaires entiers sont contrôlés par le moteur dans le périmètre de ce résultat. L’optimiseur a examiné 7 sous-ensembles de fournisseurs. 5 offre(s) trop tardive(s) ont été exclues.

Les données de l’exemple sont synthétiques. Pour des devis autorisés, le résultat dépend de prix complets, de taux de change explicitement déclarés et de frais de livraison fixes. Taxes, stocks incertains, différences de qualité, remises et achats fractionnés d’un même article restent hors contrat.

La capacité d’entrée est identifiée dans une grammaire délimitée à partir d’exemples. Une dérive sémantique silencieuse peut nécessiter de nouveaux exemples et rester indétectable à partir de la syntaxe seule.

Les contrôles locaux ne constituent pas l’audit Python indépendant des données archivées. Des données modifiées n’héritent pas de cet audit. Coût complet réel, temps client et encaissements réels : inconnus. Promotion économique distincte de l’utilisation technique.

## Provenance

- Artéfact original : `quote-report.md`
- Empreinte de l’artéfact original : `130b7884c2e7831300170e2628a7233af0f6f3442828500846d0de48231323a0`
- Identité de source du moteur : `27f5c2888279663e06a25e6e8f0b5ed258987b6871b6fe306a9374400f646f10`
- Mission : `f8565b6fd21fc4a5ae746fc53b858c4d05898d41d6144fb31a8b328829f68ffa`
- Nature de ce fichier : présentation française dérivée, sans nouvelle qualification.
