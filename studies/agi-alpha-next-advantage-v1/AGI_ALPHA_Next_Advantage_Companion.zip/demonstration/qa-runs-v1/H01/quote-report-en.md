# Synthetic equipment quote comparison H01-M1

## Decision-ready quote comparison

Recommended eligible cart: **8585.59 USD**, including 25.00 USD of fixed supplier shipping. No purchase was made.

| Item | Supplier | Required units | Delivered units | Packs | Line cost | Delivery days |
|---|---|---:|---:|---:|---:|---:|
| Label roll 1 | SUP-8JNQHJHXJ | 34 | 36 | 3 | 1055.75 USD | 11 |
| Label roll 2 | SUP-R4EE65U64 | 20 | 24 | 1 | 409.34 USD | 14 |
| Label roll 3 | SUP-8JNQHJHXJ | 9 | 9 | 9 | 2421.57 USD | 3 |
| Label roll 4 | SUP-R4EE65U64 | 50 | 56 | 7 | 2205.91 USD | 12 |
| Mounting set 5 | SUP-R4EE65U64 | 19 | 24 | 1 | 780.39 USD | 9 |
| Storage case 6 | SUP-ZS6G7WFF7 | 15 | 16 | 2 | 1687.63 USD | 10 |

## Verification and limits

All quantities, the delivery deadline and exact integer-currency totals pass the declared contract. The optimizer enumerates 7 supplier subsets. 8 late offers were excluded.

Prices, supplier names and exchange ratios in the included example are synthetic. For your own permitted quotes, the result is conditional on complete input prices, declared rates and fixed shipping. Taxes, uncertain inventory, quality differences, discounts and split-item purchases are outside this contract.
