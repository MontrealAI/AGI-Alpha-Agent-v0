# Rapport de comparaison des devis

## Présentation française du résultat original

Cette présentation traduit le résultat calculé et l’artéfact anglais original. Aucun nouvel algorithme, calcul de panier ni audit indépendant n’est exécuté lors de cette traduction. L’artéfact original `quote-report.md` reste disponible séparément.

**Mission :** Synthetic equipment quote comparison H01-M1

Panier admissible recommandé : **8 585,59 USD**, dont 25,00 USD de frais fixes de livraison. Aucun achat n’a été effectué.

| Article | Fournisseur | Unités demandées | Unités livrées | Lots | Coût de ligne | Délai en jours |
|---|---|---:|---:|---:|---:|---:|
| Label roll 1 | SUP-8JNQHJHXJ | 34 | 36 | 3 | 1 055,75 USD | 11 |
| Label roll 2 | SUP-R4EE65U64 | 20 | 24 | 1 | 409,34 USD | 14 |
| Label roll 3 | SUP-8JNQHJHXJ | 9 | 9 | 9 | 2 421,57 USD | 3 |
| Label roll 4 | SUP-R4EE65U64 | 50 | 56 | 7 | 2 205,91 USD | 12 |
| Mounting set 5 | SUP-R4EE65U64 | 19 | 24 | 1 | 780,39 USD | 9 |
| Storage case 6 | SUP-ZS6G7WFF7 | 15 | 16 | 2 | 1 687,63 USD | 10 |

## Vérifications et limites

Les quantités, l’échéance déclarée et les totaux monétaires entiers sont contrôlés par le moteur dans le périmètre de ce résultat. L’optimiseur a examiné 7 sous-ensembles de fournisseurs. 8 offre(s) trop tardive(s) ont été exclues.

Les données de l’exemple sont synthétiques. Pour des devis autorisés, le résultat dépend de prix complets, de taux de change explicitement déclarés et de frais de livraison fixes. Taxes, stocks incertains, différences de qualité, remises et achats fractionnés d’un même article restent hors contrat.

La capacité d’entrée est identifiée dans une grammaire délimitée à partir d’exemples. Une dérive sémantique silencieuse peut nécessiter de nouveaux exemples et rester indétectable à partir de la syntaxe seule.

Les contrôles locaux ne constituent pas l’audit Python indépendant des données archivées. Des données modifiées n’héritent pas de cet audit. Coût complet réel, temps client et encaissements réels : inconnus. Promotion économique distincte de l’utilisation technique.

## Provenance

- Artéfact original : `quote-report.md`
- Empreinte de l’artéfact original : `6afbb3e4ed91a34256074e4db3ef5b7c0e67f739478c80782fab28cd74706cf1`
- Identité de source du moteur : `27f5c2888279663e06a25e6e8f0b5ed258987b6871b6fe306a9374400f646f10`
- Mission : `6ae046f9e33f2798dce7e5526f724e3f0ec63e343eda988ba9689997d9933647`
- Nature de ce fichier : présentation française dérivée, sans nouvelle qualification.
