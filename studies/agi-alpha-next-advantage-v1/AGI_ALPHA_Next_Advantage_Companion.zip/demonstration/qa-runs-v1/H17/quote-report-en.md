# Synthetic equipment quote comparison H17-M1

## Decision-ready quote comparison

Recommended eligible cart: **5004.40 USD**, including 25.49 USD of fixed supplier shipping. No purchase was made.

| Item | Supplier | Required units | Delivered units | Packs | Line cost | Delivery days |
|---|---|---:|---:|---:|---:|---:|
| Storage case 1 | SUP-7PF7VHH3N | 34 | 36 | 6 | 870.80 USD | 11 |
| Mounting set 2 | SUP-MA7R7XGX3 | 50 | 56 | 7 | 3566.19 USD | 6 |
| Mounting set 3 | SUP-MA7R7XGX3 | 7 | 24 | 1 | 541.92 USD | 4 |

## Verification and limits

All quantities, the delivery deadline and exact integer-currency totals pass the declared contract. The optimizer enumerates 7 supplier subsets. 4 late offers were excluded.

Prices, supplier names and exchange ratios in the included example are synthetic. For your own permitted quotes, the result is conditional on complete input prices, declared rates and fixed shipping. Taxes, uncertain inventory, quality differences, discounts and split-item purchases are outside this contract.
