# Rapport de comparaison des devis

## Présentation française du résultat original

Cette présentation traduit le résultat calculé et l’artéfact anglais original. Aucun nouvel algorithme, calcul de panier ni audit indépendant n’est exécuté lors de cette traduction. L’artéfact original `quote-report.md` reste disponible séparément.

**Mission :** Synthetic equipment quote comparison H17-M1

Panier admissible recommandé : **5 004,40 USD**, dont 25,49 USD de frais fixes de livraison. Aucun achat n’a été effectué.

| Article | Fournisseur | Unités demandées | Unités livrées | Lots | Coût de ligne | Délai en jours |
|---|---|---:|---:|---:|---:|---:|
| Storage case 1 | SUP-7PF7VHH3N | 34 | 36 | 6 | 870,80 USD | 11 |
| Mounting set 2 | SUP-MA7R7XGX3 | 50 | 56 | 7 | 3 566,19 USD | 6 |
| Mounting set 3 | SUP-MA7R7XGX3 | 7 | 24 | 1 | 541,92 USD | 4 |

## Vérifications et limites

Les quantités, l’échéance déclarée et les totaux monétaires entiers sont contrôlés par le moteur dans le périmètre de ce résultat. L’optimiseur a examiné 7 sous-ensembles de fournisseurs. 4 offre(s) trop tardive(s) ont été exclues.

Les données de l’exemple sont synthétiques. Pour des devis autorisés, le résultat dépend de prix complets, de taux de change explicitement déclarés et de frais de livraison fixes. Taxes, stocks incertains, différences de qualité, remises et achats fractionnés d’un même article restent hors contrat.

La capacité d’entrée est identifiée dans une grammaire délimitée à partir d’exemples. Une dérive sémantique silencieuse peut nécessiter de nouveaux exemples et rester indétectable à partir de la syntaxe seule.

Les contrôles locaux ne constituent pas l’audit Python indépendant des données archivées. Des données modifiées n’héritent pas de cet audit. Coût complet réel, temps client et encaissements réels : inconnus. Promotion économique distincte de l’utilisation technique.

## Provenance

- Artéfact original : `quote-report.md`
- Empreinte de l’artéfact original : `f3eac9428ff8b6debe8a1770d0e9b210f5f7104687e221eb4d93c84d27098be1`
- Identité de source du moteur : `27f5c2888279663e06a25e6e8f0b5ed258987b6871b6fe306a9374400f646f10`
- Mission : `f3d76d8cdedd295bf41aac77142ff39a216b512b65f9c19d439e3191e3a1cc81`
- Nature de ce fichier : présentation française dérivée, sans nouvelle qualification.
