// SPDX-License-Identifier: Apache-2.0
// Node-only integration check. This is a DOM shim, not browser qualification.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const {performance} = require('node:perf_hooks');
const root = __dirname;
const version = process.argv[3] || 'v1';
if (!/^v[0-9]+$/.test(version)) throw Error('QA version must be vN');

class Node {
  constructor(tag='div') {
    this.tagName=tag.toUpperCase();this.children=[];this.attributes={};this.dataset={};this.events={};this.value='';this.hidden=false;this.disabled=false;this._text='';this.className='';this.tabIndex=0;
    this.classList={add:(...names)=>{this.className=[...new Set([...this.className.split(' ').filter(Boolean),...names])].join(' ');},remove:(...names)=>{this.className=this.className.split(' ').filter(name=>!names.includes(name)).join(' ');},contains:name=>this.className.split(' ').includes(name)};
  }
  set textContent(value){this._text=String(value);this.children=[];}
  get textContent(){return this._text+this.children.map(child=>child.textContent||'').join('');}
  get options(){return this.children;}
  append(...nodes){this.children.push(...nodes);}
  replaceChildren(...nodes){this._text='';this.children=[...nodes];}
  setAttribute(name,value){this.attributes[name]=String(value);}
  getAttribute(name){return this.attributes[name]??null;}
  addEventListener(name,handler){(this.events[name]??=[]).push(handler);}
  dispatch(name,event={}){return Promise.all((this.events[name]||[]).map(handler=>handler(event)));}
  click(){return this.dispatch('click');}
  focus(){}
  scrollIntoView(){}
}

const template=fs.readFileSync(path.join(root,'index.template.html'),'utf8');
const nodes=[],byId={};
for(const match of template.matchAll(/<([A-Za-z][\w-]*)([^>]*?)>/g)){
  const node=new Node(match[1]),attrs=match[2];
  for(const attr of attrs.matchAll(/([\w-]+)="([^"]*)"/g)){
    const [,name,value]=attr;node.attributes[name]=value;
    if(name==='id'){node.id=value;assert.equal(byId[value],undefined,'Duplicate id '+value);byId[value]=node;}
    if(name==='class')node.className=value;
    if(name.startsWith('data-'))node.dataset[name.slice(5)]=value;
  }
  node.hidden=/\bhidden\b/.test(attrs);nodes.push(node);
}
const select=selector=>{
  const stage=/^\[data-stage="([^"]+)"\]$/.exec(selector);if(stage)return nodes.filter(n=>n.dataset.stage===stage[1]);
  if(selector==='[data-i18n]')return nodes.filter(n=>n.dataset.i18n);
  const classes=selector.split('.').filter(Boolean);return nodes.filter(n=>classes.every(c=>n.classList.contains(c)));
};
const document={documentElement:{lang:'en'},title:'',getElementById:id=>byId[id],createElement:tag=>new Node(tag),querySelectorAll:select,querySelector:selector=>select(selector)[0]};
const dataPath=process.argv[2]||path.join(root,'demo_data.json');
const data=JSON.parse(fs.readFileSync(dataPath,'utf8'));byId['research-data'].textContent=JSON.stringify(data);
const downloads=[];
class LocalURL extends URL{}
LocalURL.createObjectURL=blob=>{downloads.push(blob);return 'blob:node-only-'+downloads.length;};LocalURL.revokeObjectURL=()=>{};
const context={document,console,performance,crypto:crypto.webcrypto,TextEncoder,TextDecoder,Uint8Array,ArrayBuffer,AbortController,Blob,URL:LocalURL,setTimeout,clearTimeout,structuredClone};
context.window=context;context.globalThis=context;context.matchMedia=()=>({matches:true});
vm.createContext(context);
vm.runInContext(fs.readFileSync(path.join(root,'runtime_bundle.js'),'utf8'),context,{filename:'runtime_bundle.js'});
vm.runInContext(fs.readFileSync(path.join(root,'app.js'),'utf8'),context,{filename:'app.js'});

(async()=>{
  const report={scope:'Node runtime and DOM-shim integration; not a browser, rendering or installed-system test',engineeringValidation:true,primaryCustomerDeliveriesAdded:0,sourceSha256:crypto.createHash('sha256').update(fs.readFileSync(path.join(root,'app.js'))).digest('hex'),runtimeSha256:crypto.createHash('sha256').update(fs.readFileSync(path.join(root,'runtime_bundle.js'))).digest('hex'),dataSha256:crypto.createHash('sha256').update(fs.readFileSync(dataPath)).digest('hex'),checks:[],examples:[],browser:'NOT RUN; original socket EPERM restriction preserved'};
  const check=(name,condition)=>{assert.ok(condition,name);report.checks.push(name);};
  const ui=context.NEXT_ADVANTAGE_UI;
  const keys=[...new Set([...Object.keys(ui.i18n.en),...Object.keys(ui.i18n.fr)])];
  check('Complete English/French key parity',keys.every(key=>key in ui.i18n.en&&key in ui.i18n.fr));
  check('Every template string translated',select('[data-i18n]').every(n=>n.dataset.i18n in ui.i18n.en&&n.dataset.i18n in ui.i18n.fr));
  check('Exactly one executable primary action exists',typeof ui.run==='function'&&typeof context.NEXT_ADVANTAGE.runExample==='function');
  if(data.research?.metrics?.arms){
    const actual=data.research.metrics.arms,body=byId['evidence-table'].children.find(n=>n.tagName==='TBODY');
    check('Every measured comparison is represented',body.children.length===Object.keys(actual).length);
    check('Displayed quality denominators match actual metrics',body.children.every((line,i)=>line.children[1].textContent===String(Object.values(actual)[i].accepted)+' / '+String(Object.values(actual)[i].missions)));
  }
  if(data.economics?.financeView==='windows'){
    check('Economic view keeps six prespecified financing cases',data.economics.scenarios.length===6&&byId['economics-table'].children.find(n=>n.tagName==='TBODY').children.length===6);
    check('Provider expense remains modeled and actual money unknown',data.economics.basis.startsWith('SIMULATED')&&data.economics.actualFullCostUSD===null&&data.economics.actualCollectionsUSD===null&&data.economics.actualAvailableSurplusUSD===null);
    check('Finance display never substitutes ending cash for earned surplus',data.economics.scenarios.every(row=>!('availableSurplus' in row)&&!('finalCash' in row)));
    check('Reference full cost matches immutable shared accounting',data.economics.referenceCosts.fullyLoaded===data.economics.originalFourArmEconomicSummary.A.tables.find(row=>row.arm==='active_specialist'&&row.scenario==='base').fullyLoadedMicrosPerAccepted/1e6);
  }
  for(let i=0;i<data.examples.length;i++){
    byId['example-select'].value=String(i);await byId['example-select'].dispatch('change');await ui.run();
    const run=ui.getLastRun();
    if(!run.first?.pack||!run.next?.pack){const failure={scope:'Node-only DOM-shim integration; investigate before attributing to actual browser/runtime',example:data.examples[i].id,run};let serial=1;while(fs.existsSync(path.join(root,'QA_FAILURE_'+String(serial).padStart(3,'0')+'.json')))serial++;fs.writeFileSync(path.join(root,'QA_FAILURE_'+String(serial).padStart(3,'0')+'.json'),JSON.stringify(failure,null,2)+'\n');console.error(JSON.stringify(failure));}
    check(data.examples[i].id+' produces actual Workbench packs',Boolean(run.first?.pack&&run.next?.pack));
    check(data.examples[i].id+' fresh local crosschecks pass',run.verification.status==='LOCAL_CHECKS_PASSED'&&run.verification.archivedAuditInherited===false);
    const original=run.first.pack.result.artifacts.find(a=>a.name==='quote-report.md'),before=original.content;
    ui.setLanguage('fr');const translated=ui.deriveFrenchReport(run.first);
    check(data.examples[i].id+' French report preserves original artifact',original.content===before&&translated.includes(original.digest));
    check(data.examples[i].id+' French presentation states separate scope',translated.includes('sans nouvelle qualification')&&translated.includes('Aucun achat'));
    const total=run.first.pack.result.evidence.solution.total_minor;
    const value=new Intl.NumberFormat('fr-CA',{minimumFractionDigits:2,maximumFractionDigits:2}).format(total/100);
    check(data.examples[i].id+' French report total matches actual pack',translated.includes(value));
    check(data.examples[i].id+' original English artifact remains downloadable',!byId['download-original-report'].hidden&&!byId['download-original-report'].disabled);
    await byId['download-report'].click();check(data.examples[i].id+' French download derives from actual result',await downloads.at(-1).text()===translated);
    await byId['download-original-report'].click();check(data.examples[i].id+' English download is byte-preserved',await downloads.at(-1).text()===before);
    const runDir=path.join(root,'qa-runs-'+version,data.examples[i].id);fs.mkdirSync(runDir,{recursive:true});
    for(const name of ['first','next'])fs.writeFileSync(path.join(runDir,name+'.pack.json'),JSON.stringify(run[name].pack,null,2)+'\n');
    fs.writeFileSync(path.join(runDir,'quote-report-fr.md'),translated);fs.writeFileSync(path.join(runDir,'quote-report-en.md'),before);
    report.examples.push({id:data.examples[i].id,firstTotalMinor:total,nextTotalMinor:run.next.pack.result.evidence.solution.total_minor,currency:run.first.pack.result.summary.currency,labelQueries:run.construction.metrics.labelQueries,originalArtifactDigest:original.digest,frenchPresentationSha256:crypto.createHash('sha256').update(translated).digest('hex'),programHash:run.construction.programHash});
    ui.setLanguage('en');
  }
  byId['input-json'].value='{';await ui.run();check('Malformed edited JSON does not execute',byId['run-status-title'].textContent===ui.i18n.en.inputError);
  await byId['reset-input'].click();
  const pending=ui.run();await byId['cancel-button'].click();await pending;check('Cancellation does not become accepted delivery',byId['run-status-title'].textContent===ui.i18n.en.stopped);
  ui.setLanguage('fr');check('Document language changes to French',document.documentElement.lang==='fr');ui.setLanguage('en');
  report.translationKeys=keys.length;report.checksPassed=report.checks.length;report.successfulRuntimeInvocations=report.examples.length;report.freshRuntimePacks=report.examples.length*2;report.labelQueries=report.examples.reduce((sum,row)=>sum+row.labelQueries,0);report.interruptedRuntimeInvocations=1;
  fs.writeFileSync(path.join(root,'RUNTIME_UI_QA_'+version+'.json'),JSON.stringify(report,null,2)+'\n');
  console.log(JSON.stringify({checks:report.checksPassed,translationKeys:report.translationKeys,examples:report.examples,browser:report.browser},null,2));
})().catch(error=>{console.error(error);process.exitCode=1;});
