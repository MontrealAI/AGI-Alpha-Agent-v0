// SPDX-License-Identifier: Apache-2.0
(() => {
  'use strict';
  const DATA = JSON.parse(document.getElementById('research-data').textContent);
  const $ = id => document.getElementById(id);
  const copy = value => JSON.parse(JSON.stringify(value));
  const TEXT = {
    en: {
      skip:'Skip to the mission',edition:'RESEARCH EDITION',title:'Build the\nnext advantage.',deck:'A useful result today. A reusable capability for the next mission. Evidence for whether it was worth building.',manifesto:'From useful work to expanding productive capability.',run:'Run the example',inspect:'Inspect the evidence ↗',heroNote:'Synthetic quotes. Fresh computation in this page. No purchase is made.',orbitWork:'USEFUL WORK',orbitCapability:'RETAINED CAPABILITY',orbitNext:'THE NEXT MISSION',measured:'MEASURED',measuredNote:'Executable work and test outcomes',modeled:'MODELED',modeledNote:'Business costs and financing',unknown:'UNKNOWN',unknownNote:'Actual complete cost and customer receipts',missionEyebrow:'ONE USEFUL MISSION',missionTitle:'Make the quotes comparable.',synthetic:'SYNTHETIC, NONPERSONAL INPUTS',exampleLabel:'Choose a worked example',missionExplanation:'Different column names, pack formats and prices create preparation work. The system derives an explicit input adapter from reviewed examples, then keeps the existing quote optimizer.',showInputs:'Inspect or edit the inputs',downloadInputs:'Download inputs',tableTab:'Source table',jsonTab:'Edit mission JSON',editLabel:'First mission; the example’s construction evidence stays fixed',editNote:'Use permitted nonpersonal data in the declared format. Edited inputs do not inherit the archived independent audit. The program refuses unsupported or ambiguous inputs.',resetInput:'Restore the example',receiveEyebrow:'WHAT YOU RECEIVE',receiveTitle:'A complete basket,\nwith the workings.',deliverable1:'A recommended cart',deliverable1Note:'Declared quantities, deadlines and fixed shipping included.',deliverable2:'An inspectable report',deliverable2Note:'Source rows, exact arithmetic, exclusions and limits.',deliverable3:'A reusable input capability',deliverable3Note:'A small transformation program, learned from examples.',scopeNote:'The bounded contract excludes taxes, stock uncertainty, quality differences, discounts and split-item purchases.',journeyEyebrow:'THE EXECUTABLE LOOP',journeyTitle:'Follow the evidence.',cancel:'Stop this run',ready:'Ready when you are.',readyNote:'Run the example to construct and use the capability in this page.',step1:'The useful mission',step1Note:'Prepare varied supplier inputs for one comparable basket.',step2:'The result',step2Note:'Keep a usable cart, report and explicit scope.',step3:'The complete cost',step3Note:'Record execution; keep unknown human and business costs visible.',step4:'The limitation',step4Note:'The existing planner requires normalized inputs.',step5:'What was constructed',step5Note:'Eliminate inconsistent transformations until a unique program remains.',step6:'The fresh test',step6Note:'Apply the program to inputs it did not use for construction.',step7:'The admission decision',step7Note:'Correct output and worthwhile investment are separate gates.',step8:'The next mission',step8Note:'Reuse the retained program; check the next result.',freshEyebrow:'FRESH LOCAL COMPUTATION',resultTitle:'The result you can use.',downloadReport:'Download report',downloadCart:'Download cart',downloadRun:'Download this run',capabilityEyebrow:'THE CONSTRUCTED CAPABILITY',capabilityTitle:'Small enough to inspect.',capabilityNote:'The program records which column supplies each field and which declared transformation applies.',downloadProgram:'Download executable program',showTrace:'Show the construction trace',auditBoundary:'This page performs fresh local computation and runtime integrity checks. The independently generated Python audit below belongs to the archived study inputs. It does not certify your edits.',evidenceEyebrow:'THE RESEARCH RECORD',evidenceTitle:'Keep the strongest comparison.',archived:'ARCHIVED INDEPENDENT AUDIT',evidenceIntro:'Fresh schema families test whether constructed capabilities transfer. Ordinary reusable scripts and the established active-selection specialist receive the same examples, grammar and declared limits. Failures stay in the record.',showAudit:'Inspect the exact archived audit',questionA:'Human-work economics',questionANote:'How much competent human time would this complete deliverable need to replace? Report a threshold when duration is unknown.',questionB:'Incremental Flywheel benefit',questionBNote:'Does retained capability outperform the strongest practical alternative after construction and upkeep?',questionC:'Financeable succession',questionCNote:'Can available resources fund the next beneficial construction after obligations and reserves?',economicsEyebrow:'COST AND CONTINUATION',economicsTitle:'Can it earn its keep?',simulation:'SIMULATED ECONOMIC SCENARIOS',economicsIntro:'The executable components are measured. Prices, demand, collection timing and human attention below are explicit scenarios. Simulated receipts are not earned cash.',showEconomics:'Inspect assumptions and shared accounting',ambitionTitle:'The ambition is larger than this result.',ambitionNote:'Better task execution, better capability construction and sustained acceleration are three different findings. This bounded experiment cannot establish an unattended enterprise or sustained self-acceleration.',packageEyebrow:'OPEN THE WORKINGS',packageTitle:'Every claim has a trail.',packageNote:'Read the paper, reproduce the study, inspect the original inputs and keep the failures.',readPaper:'Read the paper',getCompanion:'Get the reproducible companion',downloadEvidence:'Download the evidence record',footerNote:'Research artifact. Persistent autonomous operation and authenticated installed execution: NOT RUN. Applicable $AGIALPHA utility and the Manager’s USDC route remain distinct; this demonstration executes neither.',items:'Items',offers:'Offer rows',currency:'Currency',deadline:'Deadline',days:'days',running:'Constructing and checking…',runningNote:'The same declared grammar and existing Workbench produce this fresh result.',complete:'The local run is complete.',completeNote:'Inspect the program, usable output and exact evidence below. Economic promotion remains a separate decision.',stopped:'This run was stopped.',stoppedNote:'An interrupted run is not an accepted delivery.',refused:'The program refused this input.',refusedNote:'No unsupported interpretation is silently accepted. The reason is preserved below.',unavailable:'The executable bundle is unavailable.',unavailableNote:'This file must include the exact study runtime before it can execute. No result is simulated.',inputError:'The edited mission is not valid JSON.',inputErrorNote:'Correct the input or restore the included example.',local:'LOCAL OUTPUT · REVIEW SCOPE',noCart:'No cart accepted',selectedOffers:'selected offers',suppliers:'suppliers',shipping:'fixed shipping',item:'Item',supplier:'Supplier',required:'Required',delivered:'Delivered',packs:'Packs',lineCost:'Line cost',delivery:'Days',firstMission:'First mission',nextMission:'Next mission',nextNote:'The retained input program is applied to fresh rows; no new adapter is authored.',noNext:'No next-mission output was produced.',noProgram:'No unique program was admitted.',labels:'reviewed examples queried',candidates:'candidate evaluations',runtime:'Local run',fullUnknown:'Actual complete cost: unknown',normalizedBoundary:'Normalization remains required.',constructionRefused:'Construction refused; no program retained.',localChecks:'Local checks completed; archived audit below.',economicHold:'Economic promotion: HOLD unless separately justified.',economicSeparate:'Technical use does not establish economic promotion.',reused:'Program reused on fresh work.',fresh:'Fresh result generated.',humanUnknown:'Human time not measured.',condition:'Conditional on the supplied input contract.',model:'Comparison',accepted:'Accepted / attempted',wrongAccepted:'Wrong accepted',labelQueries:'Label queries',constructionCpu:'Construction CPU (ms)',deliveryCpu:'Production CPU (ms)',noEvidence:'No archived result was supplied to this view.',heldoutSchemas:'Held-out schemas',freshMissions:'Fresh missions per arm',independentChecks:'Independent checks',executionOnly:'Execution-only cost',sharedMarginal:'Marginal delivery cost',recurring:'Recurring delivery cost',fullyLoaded:'Fully loaded cost',perAccepted:'modeled USD / accepted output',scenario:'Scenario',simulatedCollections:'Simulated collections',constructionCost:'Construction cost',availableSurplus:'Available surplus',decision:'Decision',noEconomics:'The full economic assumptions and results are supplied in the companion. Actual complete monetary cost remains unknown.',assumptionLabel:'Explicit scenario assumptions; not actual money.',zero:'0',unknownValue:'Unknown',notRun:'NOT RUN',source:'Source identity',evidenceSource:'Archived study data; same-session independent algorithmic checks.',edited:'Edited first mission · archived audit does not transfer',inputReady:'Permitted source rows captured.',priceCurrency:'Currency is explicit; no inferred exchange rate.',downloaded:'Download prepared.',runAgain:'Run again',arm_rebuild:'Rebuild each mission',arm_ordinary_reuse:'Ordinary reuse',arm_retained:'Retained construction',arm_active:'Active specialist',arm_llm:'Current LLM agent',arm_reuse:'Ordinary reuse',arm_retained_construction:'Retained construction',arm_active_specialist:'Active specialist',arm_current_llm:'Current LLM agent',unknownSource:'Exact source identity is recorded in the companion.',statementOriginal:'The study preserves prior results and extends the preparation boundary; it does not claim a new optimization algorithm.'
    },
    fr: {
      skip:'Aller à la mission',edition:'ÉDITION DE RECHERCHE',title:'Construire le\nprochain avantage.',deck:'Un résultat utile aujourd’hui. Une capacité réutilisable pour la prochaine mission. Des preuves pour savoir si sa construction en valait le coût.',manifesto:'Du travail utile à une capacité productive élargie.',run:'Lancer l’exemple',inspect:'Examiner les preuves ↗',heroNote:'Devis synthétiques. Calcul exécuté dans cette page. Aucun achat.',orbitWork:'TRAVAIL UTILE',orbitCapability:'CAPACITÉ CONSERVÉE',orbitNext:'PROCHAINE MISSION',measured:'MESURÉ',measuredNote:'Travail exécuté et résultats des essais',modeled:'MODÉLISÉ',modeledNote:'Coûts d’exploitation et financement',unknown:'INCONNU',unknownNote:'Coût complet réel et encaissements clients',missionEyebrow:'UNE MISSION UTILE',missionTitle:'Rendre les devis comparables.',synthetic:'DONNÉES SYNTHÉTIQUES, NON PERSONNELLES',exampleLabel:'Choisir un exemple expliqué',missionExplanation:'Des noms de colonnes, formats de lots et prix différents exigent un travail de préparation. Le système construit un adaptateur explicite à partir d’exemples vérifiés, puis conserve l’optimiseur de devis existant.',showInputs:'Examiner ou modifier les données',downloadInputs:'Télécharger les données',tableTab:'Tableau source',jsonTab:'Modifier la mission JSON',editLabel:'Première mission ; les exemples de construction restent fixes',editNote:'Utilisez des données non personnelles autorisées, dans le format déclaré. Les données modifiées ne bénéficient pas de l’audit indépendant archivé. Le programme refuse les données ambiguës ou non prises en charge.',resetInput:'Rétablir l’exemple',receiveEyebrow:'CE QUE VOUS RECEVEZ',receiveTitle:'Un panier complet,\navec ses justifications.',deliverable1:'Un panier recommandé',deliverable1Note:'Quantités déclarées, délais et frais fixes de livraison inclus.',deliverable2:'Un rapport vérifiable',deliverable2Note:'Lignes sources, calcul exact, exclusions et limites.',deliverable3:'Une capacité de préparation réutilisable',deliverable3Note:'Un petit programme de transformation construit à partir d’exemples.',scopeNote:'Le contrat délimité exclut les taxes, l’incertitude des stocks, les différences de qualité, les remises et les achats fractionnés d’un même article.',journeyEyebrow:'LA BOUCLE EXÉCUTABLE',journeyTitle:'Suivre les preuves.',cancel:'Arrêter cette exécution',ready:'Prêt à commencer.',readyNote:'Lancez l’exemple pour construire et utiliser la capacité dans cette page.',step1:'La mission utile',step1Note:'Préparer des données fournisseurs variées pour comparer un panier.',step2:'Le résultat',step2Note:'Conserver un panier utilisable, un rapport et un périmètre explicite.',step3:'Le coût complet',step3Note:'Mesurer l’exécution ; rendre visibles les coûts humains et d’exploitation inconnus.',step4:'La limite révélée',step4Note:'Le planificateur existant exige des données normalisées.',step5:'La capacité construite',step5Note:'Éliminer les transformations incompatibles jusqu’à obtenir un programme unique.',step6:'Le nouvel essai',step6Note:'Appliquer le programme à des données qui n’ont pas servi à sa construction.',step7:'La décision d’admission',step7Note:'Un résultat correct et un investissement justifié sont deux conditions distinctes.',step8:'La prochaine mission',step8Note:'Réutiliser le programme conservé ; vérifier le résultat suivant.',freshEyebrow:'NOUVEAU CALCUL LOCAL',resultTitle:'Un résultat utilisable.',downloadReport:'Télécharger le rapport',downloadCart:'Télécharger le panier',downloadRun:'Télécharger cette exécution',capabilityEyebrow:'LA CAPACITÉ CONSTRUITE',capabilityTitle:'Assez simple pour être inspectée.',capabilityNote:'Le programme indique quelle colonne fournit chaque champ et quelle transformation déclarée s’applique.',downloadProgram:'Télécharger le programme exécutable',showTrace:'Voir la trace de construction',auditBoundary:'Cette page effectue un nouveau calcul local et les contrôles d’intégrité du moteur. L’audit Python indépendant ci-dessous porte sur les données archivées de l’étude. Il ne certifie pas vos modifications.',evidenceEyebrow:'LE DOSSIER DE RECHERCHE',evidenceTitle:'Conserver la meilleure comparaison.',archived:'AUDIT INDÉPENDANT ARCHIVÉ',evidenceIntro:'De nouvelles familles de schémas vérifient le transfert des capacités construites. Les scripts réutilisables ordinaires et le spécialiste établi de sélection active disposent des mêmes exemples, de la même grammaire et des mêmes limites. Les échecs restent dans le dossier.',showAudit:'Examiner l’audit archivé exact',questionA:'Économie du travail humain',questionANote:'Quelle durée de travail humain compétent ce livrable complet doit-il remplacer ? Présenter un seuil lorsque la durée reste inconnue.',questionB:'Bénéfice additionnel du Flywheel',questionBNote:'La capacité conservée dépasse-t-elle la meilleure solution pratique après ses coûts de construction et d’entretien ?',questionC:'Succession finançable',questionCNote:'Les ressources disponibles peuvent-elles financer la prochaine construction utile après les obligations et les réserves ?',economicsEyebrow:'COÛT ET CONTINUATION',economicsTitle:'La capacité justifie-t-elle son coût ?',simulation:'SCÉNARIOS ÉCONOMIQUES SIMULÉS',economicsIntro:'Les composants exécutables sont mesurés. Les prix, la demande, les délais d’encaissement et l’attention humaine ci-dessous sont des scénarios explicites. Des recettes simulées ne sont pas des encaissements réels.',showEconomics:'Examiner les hypothèses et la comptabilité commune',ambitionTitle:'L’ambition dépasse ce résultat.',ambitionNote:'Une meilleure exécution, une meilleure construction de capacités et une accélération durable sont trois résultats différents. Cette expérience délimitée ne peut établir une entreprise sans surveillance ni une autoaccélération durable.',packageEyebrow:'OUVRIR LES JUSTIFICATIONS',packageTitle:'Chaque affirmation laisse une trace.',packageNote:'Lire l’article, reproduire l’étude, examiner les données originales et conserver les échecs.',readPaper:'Lire l’article',getCompanion:'Obtenir le dossier reproductible',downloadEvidence:'Télécharger le dossier de preuves',footerNote:'Artéfact de recherche. Fonctionnement autonome persistant et exécution installée authentifiée : NON EXÉCUTÉS. L’utilité applicable de $AGIALPHA et le parcours USDC du Manager restent distincts ; cette démonstration n’exécute aucun des deux.',items:'Articles',offers:'Lignes de devis',currency:'Devise',deadline:'Échéance',days:'jours',running:'Construction et vérification…',runningNote:'La même grammaire déclarée et le Workbench existant produisent ce nouveau résultat.',complete:'L’exécution locale est terminée.',completeNote:'Examinez le programme, le livrable et les preuves exactes ci-dessous. La promotion économique reste une décision distincte.',stopped:'Cette exécution a été arrêtée.',stoppedNote:'Une exécution interrompue ne constitue pas un livrable accepté.',refused:'Le programme a refusé ces données.',refusedNote:'Aucune interprétation non prise en charge n’est acceptée silencieusement. Le motif est conservé ci-dessous.',unavailable:'Le moteur exécutable est indisponible.',unavailableNote:'Ce fichier doit inclure le moteur exact de l’étude pour fonctionner. Aucun résultat n’est simulé.',inputError:'La mission modifiée ne contient pas de JSON valide.',inputErrorNote:'Corrigez les données ou rétablissez l’exemple inclus.',local:'RÉSULTAT LOCAL · PÉRIMÈTRE À VÉRIFIER',noCart:'Aucun panier accepté',selectedOffers:'offres sélectionnées',suppliers:'fournisseurs',shipping:'livraison fixe',item:'Article',supplier:'Fournisseur',required:'Demandé',delivered:'Livré',packs:'Lots',lineCost:'Coût de ligne',delivery:'Jours',firstMission:'Première mission',nextMission:'Prochaine mission',nextNote:'Le programme de préparation conservé traite de nouvelles lignes ; aucun nouvel adaptateur n’est écrit.',noNext:'Aucun résultat de prochaine mission n’a été produit.',noProgram:'Aucun programme unique n’a été admis.',labels:'exemples vérifiés demandés',candidates:'évaluations de candidats',runtime:'Exécution locale',fullUnknown:'Coût complet réel : inconnu',normalizedBoundary:'La normalisation reste nécessaire.',constructionRefused:'Construction refusée ; aucun programme conservé.',localChecks:'Contrôles locaux terminés ; audit archivé ci-dessous.',economicHold:'Promotion économique : EN ATTENTE sans justification distincte.',economicSeparate:'L’utilisation technique n’établit pas la promotion économique.',reused:'Programme réutilisé sur de nouvelles données.',fresh:'Nouveau résultat produit.',humanUnknown:'Temps humain non mesuré.',condition:'Sous réserve du contrat des données fournies.',model:'Comparaison',accepted:'Acceptés / tentés',wrongAccepted:'Acceptés à tort',labelQueries:'Exemples demandés',constructionCpu:'CPU de construction (ms)',deliveryCpu:'CPU de production (ms)',noEvidence:'Aucun résultat archivé n’a été fourni à cette vue.',heldoutSchemas:'Schémas réservés',freshMissions:'Nouvelles missions par méthode',independentChecks:'Contrôles indépendants',executionOnly:'Coût d’exécution seul',sharedMarginal:'Coût marginal de livraison',recurring:'Coût récurrent de livraison',fullyLoaded:'Coût complet',perAccepted:'USD modélisés / livrable accepté',scenario:'Scénario',simulatedCollections:'Encaissements simulés',constructionCost:'Coût de construction',availableSurplus:'Surplus disponible',decision:'Décision',noEconomics:'Les hypothèses et résultats économiques complets figurent dans le dossier reproductible. Le coût monétaire complet réel reste inconnu.',assumptionLabel:'Hypothèses explicites de scénario ; aucune somme réelle.',zero:'0',unknownValue:'Inconnu',notRun:'NON EXÉCUTÉ',source:'Identité de source',evidenceSource:'Données archivées de l’étude ; contrôles algorithmiques indépendants dans la même session.',edited:'Première mission modifiée · aucun transfert de l’audit archivé',inputReady:'Lignes sources autorisées capturées.',priceCurrency:'Devise explicite ; aucun taux de change déduit.',downloaded:'Téléchargement préparé.',runAgain:'Relancer',arm_rebuild:'Reconstruire à chaque mission',arm_ordinary_reuse:'Réutilisation ordinaire',arm_retained:'Construction conservée',arm_active:'Spécialiste actif',arm_llm:'Agent LLM actuel',arm_reuse:'Réutilisation ordinaire',arm_retained_construction:'Construction conservée',arm_active_specialist:'Spécialiste actif',arm_current_llm:'Agent LLM actuel',unknownSource:'L’identité exacte des sources figure dans le dossier reproductible.',statementOriginal:'L’étude préserve les résultats antérieurs et élargit la préparation ; elle ne revendique pas un nouvel algorithme d’optimisation.'
    }
  };
  Object.assign(TEXT.en,{
    neutralHeaders:'Column names are intentionally neutral in this experiment: construction must use worked examples rather than descriptive labels. Example answers are synthetic reference data; customer preparation time is not measured.',
    originalReport:'Original report (English)',
    translationNote:'The French report presents the same calculated result. The original English artifact is preserved; translation adds no new solver run or independent audit.',
    cartTotal:'RECOMMENDED BASKET · QUOTED GOODS',
    costTiersNote:'These cumulative cost tiers must not be added together. Human exceptions enter the marginal tier; customer attention is shown separately.',
    costScenarioTitle:'How the assumptions change the cost',fundingScenarioTitle:'When a future capability can be financed',
    constructionMonth:'Construction month',paybackMonth:'Payback month',netBenefit:'Net capability benefit',notConstructed:'Not constructed',notRepaid:'Not repaid',acceptedMonthly:'Expected accepted / month',independentChecks:'Output evaluations',technicalReuseHold:'Program reused locally · economic promotion HOLD.'
  });
  Object.assign(TEXT.fr,{
    neutralHeaders:'Les noms de colonnes sont volontairement neutres dans cette expérience : la construction doit utiliser les exemples expliqués plutôt que des intitulés descriptifs. Les réponses sont des références synthétiques ; le temps de préparation du client n’est pas mesuré.',
    originalReport:'Rapport original (anglais)',
    translationNote:'Le rapport français présente le même résultat calculé. L’artéfact anglais original est conservé ; la traduction n’ajoute ni nouvelle exécution de l’optimiseur ni audit indépendant.',
    cartTotal:'PANIER RECOMMANDÉ · BIENS DEVISÉS',
    costTiersNote:'Ces niveaux de coûts sont cumulatifs et ne doivent pas être additionnés. Les exceptions humaines entrent dans le coût marginal ; l’attention du client est présentée séparément.',
    costScenarioTitle:'L’effet des hypothèses sur le coût',fundingScenarioTitle:'Quand une capacité future peut être financée',
    constructionMonth:'Mois de construction',paybackMonth:'Mois de récupération',netBenefit:'Bénéfice net de la capacité',notConstructed:'Non construite',notRepaid:'Non récupéré',acceptedMonthly:'Acceptés prévus / mois',independentChecks:'Évaluations des résultats',technicalReuseHold:'Programme réutilisé localement · promotion économique EN ATTENTE.'
  });
  let language = 'en', selectedIndex = 0, lastRun = null, controller = null, currentStatus = 'ready', edited = false;
  const t = key => TEXT[language][key] || TEXT.en[key] || key;
  const local = value => typeof value === 'string' ? value : value?.[language] ?? value?.en ?? '';
  const number = (v, digits = 0) => typeof v === 'number' && Number.isFinite(v) ? v.toLocaleString(language === 'fr' ? 'fr-CA' : 'en-US',{maximumFractionDigits:digits}) : t('unknownValue');
  const money = (v, currency = 'USD', digits = 2) => typeof v === 'number' && Number.isFinite(v) ? new Intl.NumberFormat(language === 'fr' ? 'fr-CA' : 'en-US',{style:'currency',currency,maximumFractionDigits:digits,minimumFractionDigits:digits}).format(v) : t('unknownValue');
  const examples = Array.isArray(DATA.examples) ? DATA.examples : [];
  const selected = () => examples[selectedIndex];
  const element = (tag, text, className) => {const node = document.createElement(tag);if(text !== undefined)node.textContent = String(text);if(className)node.className = className;return node;};
  const clear = node => node.replaceChildren();
  const firstMission = example => example?.missions?.[0] ?? example?.mission ?? null;
  const json = value => JSON.stringify(value, null, 2);
  const output = record => record?.pack?.result ?? record?.result ?? record ?? {};
  const solution = record => output(record)?.evidence?.solution ?? output(record)?.solution ?? null;
  const currencyOf = record => output(record)?.summary?.currency ?? output(record)?.evidence?.normalized?.base_currency ?? 'USD';
  const artifact = (record, name) => output(record)?.artifacts?.find(item => item.name === name);
  function frenchReport(record) {
    const result=output(record),sol=solution(record),normalized=result.evidence?.normalized,original=artifact(record,'quote-report.md');
    if(!sol||!normalized||!original)throw Error('NO_REPORT_TO_TRANSLATE');
    const safe=value=>String(value??'').replaceAll('|','\\|').replace(/[\r\n]+/g,' ');
    const amount=value=>new Intl.NumberFormat('fr-CA',{minimumFractionDigits:2,maximumFractionDigits:2}).format(value/100)+' '+normalized.base_currency;
    const rows=(sol.selected||[]).map(row=>'| '+[row.label||row.item,row.vendor,row.quantity,row.delivered_units,row.packs,amount(row.landed_line_minor),row.lead_days].map(safe).join(' | ')+' |');
    return '# Rapport de comparaison des devis\n\n'+
      '## Présentation française du résultat original\n\n'+
      'Cette présentation traduit le résultat calculé et l’artéfact anglais original. Aucun nouvel algorithme, calcul de panier ni audit indépendant n’est exécuté lors de cette traduction. L’artéfact original `quote-report.md` reste disponible séparément.\n\n'+
      '**Mission :** '+safe(normalized.title)+'\n\n'+
      'Panier admissible recommandé : **'+amount(sol.total_minor)+'**, dont '+amount(sol.shipping_minor)+' de frais fixes de livraison. Aucun achat n’a été effectué.\n\n'+
      '| Article | Fournisseur | Unités demandées | Unités livrées | Lots | Coût de ligne | Délai en jours |\n|---|---|---:|---:|---:|---:|---:|\n'+rows.join('\n')+'\n\n'+
      '## Vérifications et limites\n\n'+
      'Les quantités, l’échéance déclarée et les totaux monétaires entiers sont contrôlés par le moteur dans le périmètre de ce résultat. L’optimiseur a examiné '+String(sol.states_visited)+' sous-ensembles de fournisseurs. '+String(normalized.excluded?.length||0)+' offre(s) trop tardive(s) ont été exclues.\n\n'+
      'Les données de l’exemple sont synthétiques. Pour des devis autorisés, le résultat dépend de prix complets, de taux de change explicitement déclarés et de frais de livraison fixes. Taxes, stocks incertains, différences de qualité, remises et achats fractionnés d’un même article restent hors contrat.\n\n'+
      'La capacité d’entrée est identifiée dans une grammaire délimitée à partir d’exemples. Une dérive sémantique silencieuse peut nécessiter de nouveaux exemples et rester indétectable à partir de la syntaxe seule.\n\n'+
      'Les contrôles locaux ne constituent pas l’audit Python indépendant des données archivées. Des données modifiées n’héritent pas de cet audit. Coût complet réel, temps client et encaissements réels : inconnus. Promotion économique distincte de l’utilisation technique.\n\n'+
      '## Provenance\n\n'+
      '- Artéfact original : `quote-report.md`\n'+
      '- Empreinte de l’artéfact original : `'+String(original.digest||'non fournie')+'`\n'+
      '- Identité de source du moteur : `'+String(record?.pack?.frozen?.sourceHash||'non fournie')+'`\n'+
      '- Mission : `'+String(record?.pack?.frozen?.missionDigest||'non fournie')+'`\n'+
      '- Nature de ce fichier : présentation française dérivée, sans nouvelle qualification.\n';
  }
  function download(name, value, type = 'application/json') {
    const body = typeof value === 'string' ? value : json(value) + '\n';
    const url = URL.createObjectURL(new Blob([body],{type:type+';charset=utf-8'}));
    const a = document.createElement('a');a.href = url;a.download = name;a.click();setTimeout(() => URL.revokeObjectURL(url),1000);
  }
  function table(node, headings, rows) {
    clear(node);const head = document.createElement('thead'),tr = document.createElement('tr');
    headings.forEach(heading=>{const th=element('th',heading);th.scope='col';tr.append(th);});head.append(tr);node.append(head);
    const body = document.createElement('tbody');rows.forEach(row=>{const line=document.createElement('tr');row.forEach(cell=>line.append(element('td',cell)));body.append(line);});node.append(body);
  }
  function status(state, detail) {
    currentStatus = state;
    $('run-status-title').textContent = t(state);
    $('run-status-description').textContent = detail || t(state+'Note');
    $('run-status-dot').className = 'status-dot'+(state==='running'?' running':state==='complete'?' complete':['refused','stopped','unavailable','inputError'].includes(state)?' error':'');
  }
  function stage(key, text, active = false, executed = true) {
    const card = document.querySelector('[data-stage="'+key+'"]');if(!card)return;
    card.classList.remove('done','active','skipped');card.classList.add(active?'active':executed?'done':'skipped');
    if(text)$('stage-'+key).textContent=text;
  }
  function stageEvent(event) {
    const raw = typeof event==='string'?event:event?.stage || event?.phase || '';
    const map={identify:'mission',planning:'mission',prepare:'mission',preparation:'mission',normalizing:'mission',synthesize:'construction',constructing:'construction',construct:'construction',building:'construction',verify:'verification',checking:'verification',first:'result',first_mission:'result',fresh:'verification',admit:'decision',next_mission:'next',reuse:'next',costs:'cost'};
    const key=map[raw]||raw;
    document.querySelectorAll('.journey-card.active').forEach(card=>{card.classList.remove('active');card.classList.add('done');});
    stage(key,local(event?.message)||'',true);
  }
  function renderSourceTable(mission) {
    table($('source-table'),mission?.headers||[],(mission?.rows||[]).slice(0,20));
  }
  function renderMissionStats(mission) {
    const context=mission?.context||{};
    clear($('mission-stats'));
    [[context.items?.length,t('items')],[mission?.rows?.length,t('offers')],[context.base_currency||'—',t('currency')],[context.deadline_days===undefined?'—':number(context.deadline_days)+' '+t('days'),t('deadline')]].forEach(([value,label])=>{const cell=element('div',undefined,'mini-stat');cell.append(element('b',typeof value==='number'?number(value):value),element('span',label));$('mission-stats').append(cell);});
  }
  function renderExample(resetEditor = true) {
    const example = selected();if(!example)return;
    $('example-description').textContent=local(example.description)||local({en:example.titleEn,fr:example.titleFr})||example.id;
    let mission=firstMission(example);
    if(!resetEditor){try{mission=JSON.parse($('input-json').value);}catch{}}
    renderMissionStats(mission);
    if(resetEditor){$('input-json').value=json(mission);edited=false;renderSourceTable(mission);}
  }
  function programRows(program) {
    if(!program)return [];
    const fields=program.fields||program.mapping||program.program||program;
    return Object.entries(fields).filter(([,value])=>value&&typeof value==='object'&&typeof value.column==='string'&&typeof value.op==='string');
  }
  function renderLive() {
    if(!lastRun)return;
    $('live-result').hidden=false;
    const first=lastRun.first,sol=solution(first),curr=currencyOf(first);
    clear($('result-summary'));
    if(sol&&typeof sol.total_minor==='number'){
      const main=element('div',money(sol.total_minor/100,curr),'result-total');$('result-summary').append(element('p',t('cartTotal'),'eyebrow'),main);
      const details=[number(sol.selected?.length)+' '+t('selectedOffers'),number(sol.used_vendors?.length)+' '+t('suppliers')];
      if(typeof sol.shipping_minor==='number')details.push(money(sol.shipping_minor/100,curr)+' '+t('shipping'));
      $('result-summary').append(element('p',details.join(' · '),'result-subtitle'));
      table($('cart-table'),[t('item'),t('supplier'),t('required'),t('delivered'),t('packs'),t('lineCost'),t('delivery')],(sol.selected||[]).map(row=>[row.label||row.item,row.vendor,number(row.quantity),number(row.delivered_units),number(row.packs),money(row.landed_line_minor/100,curr),number(row.lead_days)]));
    }else{
      $('result-summary').append(element('div',t('noCart'),'result-refusal'));
      const reason=first?.error||first?.reason||output(first)?.decision||lastRun.construction?.status||'';
      $('result-summary').append(element('p',reason,'result-subtitle'));clear($('cart-table'));
    }
    $('result-badge').textContent=edited?t('edited'):t('local');
    $('result-limits').textContent=t('scopeNote');
    ['report','cart'].forEach(name=>$('download-'+name).disabled=!artifact(first,name==='report'?'quote-report.md':'recommended-cart.csv'));
    $('download-original-report').hidden=language!=='fr';$('translation-note').hidden=language!=='fr';
    $('download-original-report').disabled=!artifact(first,'quote-report.md');
    const program=lastRun.construction?.program;clear($('program-table'));
    const rows=programRows(program);
    if(rows.length)rows.forEach(([field,value])=>{const row=element('div',undefined,'program-row');row.append(element('span',field,'program-field'),element('span',value.column+' → '+value.op,'program-transform'));$('program-table').append(row);});
    else $('program-table').append(element('p',t('noProgram'),'empty-state'));
    $('download-program').disabled=!program;
    $('construction-trace').textContent=json(lastRun.construction||{});
    const next=lastRun.next,nextSol=solution(next);clear($('next-result'));
    const explanation=element('div');explanation.append(element('p',t('nextMission'),'eyebrow'),element('h3',nextSol?t('reused'):t('noNext')),element('p',nextSol?t('nextNote'):(next?.error||next?.reason||t('condition'))));$('next-result').append(explanation);
    if(nextSol)$('next-result').append(element('div',money(nextSol.total_minor/100,currencyOf(next)),'next-value'));
    const construction=lastRun.construction||{},constructionMetrics=construction.metrics||construction;
    stage('mission',t('inputReady'));stage('result',sol?t('fresh'):t('noCart'),false,Boolean(sol));
    const timing=lastRun.timing||{};
    const wall=timing.wallMs??timing.totalWallMs??timing.elapsedMs;
    stage('cost',(typeof wall==='number'?number(wall,2)+' ms · ':'')+t('fullUnknown'));
    stage('limitation',t('normalizedBoundary'));
    stage('construction',program?number(constructionMetrics.labelQueries)+' '+t('labels')+' · '+number(constructionMetrics.candidateEvaluations)+' '+t('candidates'):t('constructionRefused'),false,Boolean(program));
    const verified=lastRun.verification?.status && !['NOT_RUN','NOT RUN','REFUSED','FAILED'].includes(lastRun.verification.status);
    stage('verification',verified?t('localChecks'):t('notRun'),false,Boolean(verified));
    stage('decision',program&&verified?t('technicalReuseHold'):t('economicSeparate'),false,false);
    stage('next',nextSol?t('reused'):t('noNext'),false,Boolean(nextSol));
  }
  function renderEvidence() {
    const research=DATA.research||{},metrics=research.metrics||DATA.metrics||{},arms=metrics.arms||research.arms||{};
    clear($('evidence-summary'));
    const counts=[[research.heldoutSchemas??research.schemaTasks,t('heldoutSchemas')],[research.missionsPerArm,t('freshMissions')],[research.independentChecks,t('independentChecks')]];
    counts.filter(([value])=>value!==undefined&&value!==null).forEach(([value,label])=>{const item=element('div',undefined,'evidence-stat');item.append(element('strong',number(value)),element('span',label));$('evidence-summary').append(item);});
    const entries=Array.isArray(arms)?arms.map((value,index)=>[value.id||String(index),value]):Object.entries(arms);
    const rows=entries.map(([id,value])=>[local(value.label)||t('arm_'+id),number(value.accepted)+' / '+number(value.missions??value.attempted),number(value.incorrectAccepted??value.wrongAccepted),number(value.labelQueries),number(value.constructionCpuMs,2),number(value.productionCpuMs,2)]);
    table($('evidence-table'),[t('model'),t('accepted'),t('wrongAccepted'),t('labelQueries'),t('constructionCpu'),t('deliveryCpu')],rows);
    $('evidence-conclusion').textContent=local(research.conclusion)||local(research.conclusions)||(rows.length?t('statementOriginal'):t('noEvidence'));
    $('audit-json').textContent=json(research.audit||research);
  }
  function renderEconomics() {
    const econ=DATA.economics||{},costs=econ.referenceCosts||{};
    $('reference-cost-context').textContent=local(econ.referenceContext)||'';
    clear($('cost-cards'));
    ['executionOnly','sharedMarginal','recurring','fullyLoaded'].forEach(key=>{if(!Object.hasOwn(costs,key))return;const card=element('div',undefined,'cost-card');card.append(element('span',t(key)),element('strong',money(costs[key],econ.currency||'USD',costs[key]!==null&&costs[key]<1?3:2)),element('small',t('perAccepted')));$('cost-cards').append(card);});
    table($('cost-scenario-table'),[t('scenario'),t('acceptedMonthly'),t('executionOnly'),t('sharedMarginal'),t('recurring'),t('fullyLoaded')],(econ.costScenarios||[]).map(value=>[local(value.name)||value.id,number(value.acceptedPerMonth,1),money(value.executionOnly,econ.currency||'USD',3),money(value.sharedMarginal,econ.currency||'USD',3),money(value.recurring,econ.currency||'USD',3),money(value.fullyLoaded,econ.currency||'USD',3)]));
    $('allocation-note').textContent=local(econ.allocationNote)||'';
    if(econ.financeView==='windows'){
      const rows=(econ.scenarios||[]).map(value=>[local(value.name)||value.id,value.constructionMonth===null?t('notConstructed'):number(value.constructionMonth),value.paybackMonth===null?t('notRepaid'):number(value.paybackMonth),money(value.netCapabilityBenefit,econ.currency||'USD'),local(value.decision)||'—']);
      table($('economics-table'),[t('scenario'),t('constructionMonth'),t('paybackMonth'),t('netBenefit'),t('decision')],rows);
    }else{
      const rows=(econ.scenarios||[]).map(value=>[local(value.name)||value.id,money(value.collections,econ.currency||'USD'),money(value.construction,econ.currency||'USD'),money(value.availableSurplus,econ.currency||'USD'),local(value.decision)||'—']);
      table($('economics-table'),[t('scenario'),t('simulatedCollections'),t('constructionCost'),t('availableSurplus'),t('decision')],rows);
    }
    $('economics-conclusion').textContent=local(econ.conclusion)||t('noEconomics');
    $('economics-json').textContent=json(econ);
  }
  function languageTo(next) {
    language=next;document.documentElement.lang=language;
    document.querySelectorAll('[data-i18n]').forEach(node=>{node.textContent=t(node.dataset.i18n);});
    $('lang-en').setAttribute('aria-pressed',String(language==='en'));$('lang-fr').setAttribute('aria-pressed',String(language==='fr'));
    document.title=language==='fr'?'Construire le prochain avantage · AGI ALPHA FLYWHEEL':'Build the Next Advantage · AGI ALPHA FLYWHEEL';
    [...$('example-select').options].forEach((option,index)=>{const item=examples[index];option.textContent=local({en:item.titleEn,fr:item.titleFr})||item.id;});
    renderExample(false);renderEvidence();renderEconomics();if(lastRun)renderLive();
    status(currentStatus);
    $('source-hash').textContent=DATA.sourceHash?t('source')+': '+DATA.sourceHash:t('unknownSource');
  }
  async function run() {
    if(controller)return;
    if(typeof window.NEXT_ADVANTAGE?.runExample!=='function'){status('unavailable');return;}
    let mission;
    try{mission=JSON.parse($('input-json').value);}catch{status('inputError');$('input-json').focus();return;}
    const example=selected();if(!example){status('unavailable');return;}
    edited=JSON.stringify(mission)!==JSON.stringify(firstMission(example));
    controller=new AbortController();lastRun=null;$('live-result').hidden=true;
    $('run-button').disabled=true;$('example-select').disabled=true;$('cancel-button').hidden=false;
    document.querySelectorAll('.journey-card').forEach(node=>node.classList.remove('active','done','skipped'));
    document.querySelectorAll('.step-outcome').forEach(node=>node.textContent='');
    status('running');stage('mission',t('inputReady'),true);
    try{
      const result=await window.NEXT_ADVANTAGE.runExample({example:copy(example),editedMission:edited?mission:null,signal:controller.signal,onStage:stageEvent});
      if(controller.signal.aborted){status('stopped');return;}
      lastRun=result;renderLive();status(result?.construction?.program?'complete':'refused',result?.construction?.program?undefined:(result?.construction?.reason||result?.construction?.status||undefined));
    }catch(error){
      const message=error instanceof Error?error.message:String(error);
      status(controller.signal.aborted?'stopped':'refused',controller.signal.aborted?undefined:message);
      lastRun={status:'REFUSED',reason:message,edited,construction:{status:'REFUSED',reason:message},verification:{status:'NOT_RUN'}};
      renderLive();
    }finally{
      controller=null;$('run-button').disabled=false;$('example-select').disabled=false;$('cancel-button').hidden=true;
      document.querySelectorAll('.journey-card.active').forEach(node=>node.classList.remove('active'));
      $('journey').scrollIntoView({behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth',block:'start'});
    }
  }
  function selectTab(kind) {
    ['table','json'].forEach(value=>{const active=value===kind;$(`${value}-tab`).setAttribute('aria-selected',String(active));$(`${value}-tab`).tabIndex=active?0:-1;$(`${value}-panel`).hidden=!active;});
  }
  examples.forEach((example,index)=>{const option=element('option',example.titleEn||example.id);option.value=String(index);$('example-select').append(option);});
  $('example-select').addEventListener('change',()=>{selectedIndex=Number($('example-select').value);lastRun=null;$('live-result').hidden=true;renderExample();status('ready');document.querySelectorAll('.journey-card').forEach(node=>node.classList.remove('active','done','skipped'));document.querySelectorAll('.step-outcome').forEach(node=>node.textContent='');});
  $('lang-en').addEventListener('click',()=>languageTo('en'));$('lang-fr').addEventListener('click',()=>languageTo('fr'));
  $('run-button').addEventListener('click',run);$('cancel-button').addEventListener('click',()=>controller?.abort());
  $('toggle-input').addEventListener('click',()=>{const expanded=$('input-details').hidden;$('input-details').hidden=!expanded;$('toggle-input').setAttribute('aria-expanded',String(expanded));});
  $('reset-input').addEventListener('click',()=>{renderExample();status('ready');});
  ['table','json'].forEach(kind=>{$(`${kind}-tab`).addEventListener('click',()=>selectTab(kind));$(`${kind}-tab`).addEventListener('keydown',event=>{if(['ArrowLeft','ArrowRight','Home','End'].includes(event.key)){event.preventDefault();const next=event.key==='Home'?'table':event.key==='End'?'json':kind==='table'?'json':'table';selectTab(next);$(`${next}-tab`).focus();}});});
  $('input-json').addEventListener('input',()=>{try{const mission=JSON.parse($('input-json').value);renderSourceTable(mission);renderMissionStats(mission);}catch{}});
  $('download-input').addEventListener('click',()=>{try{download('quote-mission-input.json',JSON.parse($('input-json').value));}catch{status('inputError');}});
  $('download-program').addEventListener('click',()=>{if(lastRun?.construction?.program)download('constructed-input-program.json',lastRun.construction.program);});
  $('download-run').addEventListener('click',()=>{if(lastRun)download('next-advantage-local-run.json',{scope:'FRESH_LOCAL_DEMONSTRATION',editedInputs:edited,archivedAuditTransferred:false,...lastRun});});
  $('download-report').addEventListener('click',()=>{const file=artifact(lastRun?.first,'quote-report.md');if(file)download(language==='fr'?'quote-report-fr.md':file.name,language==='fr'?frenchReport(lastRun.first):file.content,file.type);});
  $('download-original-report').addEventListener('click',()=>{const file=artifact(lastRun?.first,'quote-report.md');if(file)download(file.name,file.content,file.type);});
  $('download-cart').addEventListener('click',()=>{const file=artifact(lastRun?.first,'recommended-cart.csv');if(file)download(file.name,file.content,file.type);});
  $('download-evidence').addEventListener('click',()=>download('next-advantage-evidence.json',{research:DATA.research,economics:DATA.economics,sourceHash:DATA.sourceHash}));
  for(const [key,id] of [['paper','paper-link'],['companion','companion-link']]){const link=DATA.links?.[key];if(typeof link==='string'&&/^(?:https:\/\/|[A-Za-z0-9][A-Za-z0-9_.-]*$)/.test(link))$(id).href=link;}
  renderExample();languageTo('en');
  if(!examples.length||typeof window.NEXT_ADVANTAGE?.runExample!=='function'){$('run-button').disabled=true;status('unavailable');}
  window.NEXT_ADVANTAGE_UI={setLanguage:languageTo,getLanguage:()=>language,run,getLastRun:()=>lastRun,i18n:TEXT,deriveFrenchReport:frenchReport};
})();
