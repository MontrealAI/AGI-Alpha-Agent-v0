# Build the Next Advantage: English/French research journey

This directory provides the presentation layer for the existing Alpha Workbench
and AWE quote adapter, plus the new study's permitted input-program constructor.
It implements no optimizer, runtime scheduler, economic calculation or ledger.

## Build

Generate the exact data projection and bundle from their existing source paths,
then assemble the self-contained file:

```sh
python3 demonstration/bundle_runtime.py
python3 demonstration/make_demo_data.py
python3 demonstration/build_demo.py \
  --data demonstration/demo_data.json \
  --runtime demonstration/runtime_bundle.js
```

Output: `demonstration/AGI_ALPHA_Build_the_Next_Advantage.html`. It embeds all
styles, data and code; no external asset or network request is required. The
builder refuses absent actual examples or an absent runtime API. It never
substitutes fabricated outcomes. The accompanying build manifest binds source
bytes, embedded data, runtime and output. Logical source paths keep the embedded
identity independent of the extraction directory.

The final PDF and companion links are relative filenames by default. Place the
three final deliverables together, or provide exact verified URLs in `links`.

## Runtime interface owned by the research implementation

```js
window.NEXT_ADVANTAGE.runExample({
  example,
  editedMission,
  signal,
  onStage,
})
```

The promise resolves to:

```json
{
  "construction": {
    "status": "ACTUAL_STATUS",
    "program": {"fields": {"item": {"column": "actual header", "op": "text"}}},
    "labelQueries": 0,
    "candidateEvaluations": 0,
    "trace": []
  },
  "first": {"pack": "actual Workbench pack"},
  "next": {"pack": "actual Workbench pack"},
  "verification": {"status": "ACTUAL_STATUS", "scope": "LOCAL_CHECKS"},
  "timing": {"wallMs": 0}
}
```

The JSON above documents the interface, not a measured run. Counts and timings
must come from the implementation. A program may also use a direct six-field
mapping or `mapping`. Missing or refused outputs remain explicit.

`onStage` may receive a stage string or `{stage, message:{en,fr}}`. Stage names:
`mission`, `result`, `cost`, `limitation`, `construction`, `verification`,
`decision`, `next`. Common implementation aliases are handled.

## Data interface

`demo_data.json` contains:

- `examples`: real included examples, each with `id`, `titleEn`, `titleFr`,
  optional `description:{en,fr}`, `task`, `labels`, `missions:[first,next]`.
- `research`: `heldoutSchemas`, `missionsPerArm`, `independentChecks`,
  `metrics:{arms}`, `conclusion:{en,fr}`, and exact archived `audit`.
- Each metrics arm: actual `missions`, `accepted`, `incorrectAccepted`,
  `labelQueries`, `constructionCpuMs`, `productionCpuMs`; optional bilingual
  `label`. Missing measurements display as unknown, never zero.
- `economics`: an explicitly simulated display projection from the unchanged
  shared accounting. Optional `referenceCosts` fields `executionOnly`,
  `sharedMarginal`, `recurring`, `fullyLoaded` are dollars per accepted output.
  Scenario rows use `name:{en,fr}`, `collections`, `construction`,
  `availableSurplus`, `decision:{en,fr}`. Null means unknown.
- `economics.conclusion:{en,fr}` and complete assumptions/provenance are shown
  for inspection. This UI does not perform financial arithmetic.
- Optional `links:{paper,companion}`: relative safe filenames or verified HTTPS
  links. The UI never claims those links are publicly live.

## Evidence boundaries

The primary button invokes actual code. A local run and archived independent
Python audit have separate labels. Edited inputs never inherit an archived
audit. Constructed programs are allowed inert JSON, not dynamically evaluated
JavaScript. Each download comes from actual inputs, returned artifacts or
embedded research data.

Economic figures carry modeled/simulated labels. Actual complete monetary cost,
customer time and customer receipts stay unknown. Technical reuse is distinct
from economic promotion. Persistent autonomous operation, authenticated installed
execution and financial execution are not claimed.

## Presentation and validation

The interface includes 199 complete English/French strings, keyboard-operable
language and input tabs, focus outlines, live run status, an abort signal,
responsive layouts through 320 pixels, reduced motion and print styling. All
input-derived content is inserted with `textContent`; no `innerHTML`, arbitrary
code evaluation, fetch, socket or external font is used.

The French report download is a derived presentation of the same calculated
values. It records the original artifact digest and source identity; the original
English file remains downloadable byte-for-byte. Translation runs no solver or
independent audit.

Static syntax, translation-key parity and duplicate-ID checks passed during
scaffold authoring. A Node-only DOM shim then executes the actual runtime on the
H01, H13 and H17 fixtures, checks both languages/downloads, refusal of malformed
JSON and cancellation. The separately executed Python oracle verifies all six
fresh first/next Workbench packs. These are engineering validation, adding zero
primary customer deliveries. `RUNTIME_UI_QA_v1.json` and `SEMANTIC_UI_QA_v1.json`
record those checks. `QA_FAILURE_001.json` preserves the initial DOM-shim
typed-array cross-realm mismatch; only the shim's standard constructors changed,
and the runtime's strict `BYTES_REQUIRED` gate remained intact. A final-version
check should use the final embedded data with a new version suffix:

```sh
node demonstration/qa_static_runtime.cjs demonstration/demo_data.json v3
```

The final data projection uses all five evaluated methods: 480 evaluations of
96 unique missions. The immutable four-arm economic analysis stays separate
from the additive LLM comparator, whose model inference and authoring billing
are not observed. It displays all three cost scenarios and all six prespecified
financing cases at an explicitly illustrative 50% ceiling. All 30 financing
paths and their assumptions remain inspectable. The displayed financing table
reports construction/payback month and net capability benefit; it never labels
external seed or ending cash as earned surplus.

Final Node integration passed 36 checks, including full comparison coverage,
economic source correspondence, unknown-money preservation, both report
languages, exact original downloads, malformed JSON and cancellation. See
`RUNTIME_UI_QA_v3.json`. Six actual first/next packs passed the unchanged separate
Python semantic oracle; see `SEMANTIC_UI_QA_v3.json`. They are engineering checks,
not additional primary jobs. Original versioned checks and failure remain.

Browser rendering/interaction is **NOT RUN**: the original
Chromium socket `EPERM` restriction is preserved, and no alternative browser
execution or escalation is attempted by this contributor. Static checks do not
qualify installed or public browser operation.
