# SPDX-License-Identifier: Apache-2.0
import hashlib, json, re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
app = ROOT / 'demonstration/runtime_entry.mjs'
modules, order = {}, []
pattern = re.compile(r'^import\s+([\s\S]*?)\s+from\s+[\'\"]([^\'\"]+)[\'\"];', re.M)
def visit(path):
    path = path.resolve()
    if path in modules: return
    if not path.is_relative_to(ROOT): raise ValueError('Module outside study')
    text = path.read_text(); imports = list(pattern.finditer(text)); modules[path] = {'text': text, 'imports': imports}
    for match in imports: visit(path.parent / match[2])
    order.append(path)
visit(app)
manifest = {'method': 'Adaptation of the existing AWE static-module-to-IIFE bundler; no eval, network or competing runtime.',
    'pipeline_source': 'AWE demo/build.py from companion at3d27c18362ed8db90dca4e6b85589865712bdbc5',
    'files': [{'path': str(p.relative_to(ROOT)), 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in order]}
source_hash = hashlib.sha256(json.dumps(manifest, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
chunks = ['"use strict";\nconst __modules=Object.create(null);', 'globalThis.NEXT_ADVANTAGE_SOURCE=' + json.dumps(source_hash) + ';']
for path in order:
    text = modules[path]['text']
    def replace(match):
        dependency = str((path.parent / match[2]).resolve().relative_to(ROOT)); spec = match[1].strip()
        if spec.startswith('{'):
            bindings = re.sub(r'\b(\w+)\s+as\s+(\w+)\b', r'\1: \2', spec[1:-1])
            return 'const {' + bindings + '}=__modules[' + json.dumps(dependency) + '];'
        namespace = re.fullmatch(r'\*\s+as\s+(\w+)', spec)
        if namespace: return 'const ' + namespace[1] + '=__modules[' + json.dumps(dependency) + '];'
        raise ValueError('Unsupported static import')
    text = pattern.sub(replace, text)
    names = re.findall(r'^export\s+(?:async\s+)?(?:function|class|const|let|var)\s+(\w+)', text, re.M)
    text = re.sub(r'^export\s+(?=(?:async\s+)?(?:function|class|const|let|var)\b)', '', text, flags=re.M)
    if re.search(r'^\s*(?:import|export)\s', text, re.M): raise ValueError('Unhandled module ' + str(path))
    chunks.append('__modules[' + json.dumps(str(path.relative_to(ROOT))) + ']=(()=>{\n' + text + '\nreturn {' + ','.join(names) + '};\n})();')
bundle = '\n'.join(chunks)
(ROOT / 'demonstration/runtime_bundle.js').write_text(bundle)
manifest['sourceHash'] = source_hash
manifest['bundleSha256'] = hashlib.sha256(bundle.encode()).hexdigest()
(ROOT / 'demonstration/RUNTIME_BUNDLE_MANIFEST.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'modules': len(order), 'sourceHash': source_hash, 'bundleSha256': manifest['bundleSha256']}))
