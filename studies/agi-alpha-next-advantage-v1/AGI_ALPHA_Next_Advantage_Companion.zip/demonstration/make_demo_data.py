# SPDX-License-Identifier: Apache-2.0
import hashlib, json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "demonstration"
sources = []


def read(relative):
    path = ROOT / relative
    sources.append({"path": relative, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
    return json.loads(path.read_text())


metrics = read("results/metrics-with-llm.json")
economic = read("economics/results-v1/summary.json")
finance = read("economics/results-v1/finance-projections.json")
boundaries = read("results/boundaries-v1/results.json")
economics_audit = read("economics/results-audit-v1.json")
resource_amendment = read("economics/resources-v1.1.json")
assumptions = read("economics/assumptions.json")
examples = []
names = {
    "H01": {"en": "A quote basket with mixed column names", "fr": "Un panier de devis aux colonnes hétérogènes"},
    "H13": {"en": "Quotes with lead times expressed in weeks", "fr": "Des devis aux délais exprimés en semaines"},
    "H17": {"en": "Prices with explicit currency affixes", "fr": "Des prix avec des mentions explicites de devise"},
}
for identifier in ("H01", "H13", "H17"):
    task = read(f"evaluation/sealed/confirmation/{identifier}.task.json")
    truth = read(f"evaluation/sealed/confirmation/{identifier}.truth.json")
    missions = [read(f"evaluation/sealed/production/{identifier}-M{n}.input.json") for n in (1, 2)]
    audits = [read(f"results/confirmation-v1/verification/active_specialist-{identifier}-M{n}.json") for n in (1, 2)]
    examples.append({
        "id": identifier, "titleEn": names[identifier]["en"], "titleFr": names[identifier]["fr"],
        "description": {"en": f"Frozen example {identifier}. Construct one input program, then apply it to two distinct quote missions.", "fr": f"Exemple figé {identifier}. Construire un programme de préparation, puis l’appliquer à deux missions de devis distinctes."},
        "task": task, "labels": truth["labels"], "missions": missions,
        "archivedAudit": {"scope": "Original independent Python checks of frozen primary inputs; no transfer to edited inputs", "records": audits},
    })

tables = [row for row in economic["A"]["tables"] if row["arm"] == "active_specialist"]
base = next(row for row in tables if row["scenario"] == "base")
cost_names = {"base": {"en": "Base", "fr": "De base"}, "conservative": {"en": "Conservative", "fr": "Prudent"}, "stress": {"en": "Stress", "fr": "Défavorable"}}
cost_keys = {"executionOnly": "executionOnlyMicrosPerAccepted", "sharedMarginal": "marginalMicrosPerAccepted", "recurring": "recurringMicrosPerAccepted", "fullyLoaded": "fullyLoadedMicrosPerAccepted"}
case_names = {
    "conditional-success-delayed-payback": {"en": "Conditional success, delayed payback", "fr": "Succès conditionnel, récupération différée"},
    "adverse-low-demand": {"en": "Adverse low demand", "fr": "Faible demande défavorable"},
    "failed-capability": {"en": "Failed construction", "fr": "Échec de la construction"},
    "zero-saving-reject": {"en": "No incremental saving", "fr": "Aucune économie additionnelle"},
    "protected-balances-block": {"en": "Protected reserves and obligations", "fr": "Réserves et obligations protégées"},
    "delayed-collection-and-payback": {"en": "Collections arrive too late", "fr": "Encaissements trop tardifs"},
}
decisions = {
    "conditional-success-delayed-payback": {"en": "Conditional construction repays", "fr": "Construction conditionnelle amortie"},
    "adverse-low-demand": {"en": "Reject: insufficient finite-horizon value", "fr": "Refus : valeur insuffisante sur l’horizon"},
    "failed-capability": {"en": "Paid construction fails", "fr": "Construction payée, puis échec"},
    "zero-saving-reject": {"en": "Reject: no saving", "fr": "Refus : aucune économie"},
    "protected-balances-block": {"en": "Startup refused", "fr": "Démarrage refusé"},
    "delayed-collection-and-payback": {"en": "Wait, then reject: payback window closed", "fr": "Attente, puis refus : délai de récupération dépassé"},
}
financial_rows = [row for row in finance if row["allocationCeilingBps"] == 5000]
assert len(financial_rows) == 6
arm_order = ["rebuild", "ordinary_reuse", "retained", "active_specialist", "current_llm"]
ordered_metrics = {**metrics, "arms": {arm: metrics["arms"][arm] for arm in arm_order}}
data = {
    "edition": metrics["edition"],
    "examples": examples,
    "research": {
        "heldoutSchemas": metrics["schemaTasks"], "missionsPerArm": metrics["uniqueFreshMissions"],
        "independentChecks": sum(row["missions"] for row in metrics["arms"].values()),
        "metrics": ordered_metrics,
        "conclusion": {
            "en": "All five methods produced 96/96 independently accepted outputs, with zero incorrect acceptances: 480 evaluations of 96 unique missions, not 480 customer jobs. Ordinary reuse needed 61 example queries; the retained recipe, active specialist and current-session LLM constructor each needed 29. The retained recipe also required 31 development queries and did not beat the active specialist, so it is not promoted. LLM timing excludes model inference and interactive authoring; its full cost is unknown. Synthetic label queries are not measured human minutes.",
            "fr": "Les cinq méthodes ont produit 96/96 résultats acceptés indépendamment, sans acceptation erronée : 480 évaluations de 96 missions uniques, et non 480 missions clients. La réutilisation ordinaire a demandé 61 exemples ; la recette conservée, le spécialiste actif et le constructeur LLM de cette session en ont chacun demandé 29. La recette conservée a aussi exigé 31 exemples de développement sans dépasser le spécialiste actif ; elle n’est donc pas promue. Le chronométrage LLM exclut l’inférence et la rédaction interactive ; son coût complet est inconnu. Les exemples synthétiques demandés ne sont pas des minutes humaines mesurées.",
        },
        "audit": {
            "scope": "Archived local research and same-session independent algorithms; not externally blinded peer review or installed-operation qualification",
            "primaryFreeze": metrics["primaryFreeze"], "source": metrics["source"],
            "uniqueMissions": metrics["uniqueFreshMissions"], "repeatedEvaluations": sum(row["missions"] for row in metrics["arms"].values()),
            "outcomes": {arm: {key: row.get(key) for key in ("missions", "accepted", "incorrectAccepted", "refused", "labelQueries")} for arm, row in ordered_metrics["arms"].items()},
            "selectedDemoAudits": {example["id"]: example["archivedAudit"] for example in examples},
            "boundarySummary": {key: boundaries[key] for key in ("uniqueProbes", "repeatedEvaluations", "passed", "scope")},
            "limitations": {"actualHumanTimeMinutes": None, "actualCompleteCostUSD": None, "actualCollectionsUSD": None, "browserAndInstalledExecution": "NOT_RUN", "sustainedAcceleration": "NOT_ESTABLISHED"},
        },
    },
    "economics": {
        "currency": "USD", "basis": "SIMULATED_SCENARIOS; ACTUAL_MONEY_UNKNOWN", "financeView": "windows",
        "referenceContext": {"en": "Base operating scenario: active specialist; 500 requested and 490 expected accepted reports per month. These are modeled provider costs, not a customer quote or measured cash expense.", "fr": "Scénario d’exploitation de base : spécialiste actif ; 500 rapports demandés et 490 rapports acceptés attendus par mois. Il s’agit de coûts fournisseur modélisés, et non d’un prix client ni d’une dépense réelle mesurée."},
        "referenceCosts": {key: base[source] / 1_000_000 for key, source in cost_keys.items()},
        "costScenarios": [{"id": row["scenario"], "name": cost_names[row["scenario"]], "acceptedPerMonth": row["volume"]["acceptedPerMonth"], **{key: row[source] / 1_000_000 for key, source in cost_keys.items()}} for row in tables],
        "allocationNote": {"en": "Six prespecified cases at the illustrative 50% allocation ceiling. All 30 paths across 0%, 25%, 50%, 75% and 100% remain in the companion. This is a hypothetical future capability, not a measured gain from the retained recipe. External seed and ending cash are never labeled earned surplus.", "fr": "Six cas prédéfinis avec un plafond d’allocation illustratif de 50 %. Les 30 trajectoires à 0 %, 25 %, 50 %, 75 % et 100 % restent dans le dossier. Il s’agit d’une capacité future hypothétique, et non d’un gain mesuré de la recette conservée. Le capital initial externe et l’encaisse finale ne sont jamais présentés comme du surplus gagné."},
        "scenarios": [{"id": row["id"], "name": case_names[row["id"]], "constructionMonth": row["constructionMonth"], "paybackMonth": row["firstPaybackMonth"], "netCapabilityBenefit": row["netCapabilityBenefitMinor"] / 100, "decision": decisions[row["id"]], "allocationCeilingBps": row["allocationCeilingBps"], "evidenceBasis": row["status"]} for row in financial_rows],
        "conclusion": {
            "en": "Human-work economics remain conditional. At $36.73/hour sourced employer compensation and three assumed minutes of customer attention, the base provider-cost threshold is 4.980 human minutes; at a separately assumed $15 customer price, the buyer threshold is 27.503 minutes. Neither is an observed task duration. The hypothetical future capability costs $422.17, including failed construction, and needs 1,408 reuses to repay under its stated benefit/upkeep assumptions. Actual collections and available enterprise surplus remain unknown. Economic promotion: HOLD.",
            "fr": "L’économie du travail humain reste conditionnelle. Avec une rémunération patronale sourcée de 36,73 $/h et trois minutes supposées d’attention client, le seuil de ressources du scénario de base est de 4,980 minutes humaines ; à un prix client distinct supposé de 15 $, le seuil acheteur est de 27,503 minutes. Aucune de ces durées n’est observée. La capacité future hypothétique coûte 422,17 $, échecs de construction inclus, et exige 1 408 réutilisations pour se rembourser selon ses hypothèses de bénéfice et d’entretien. Les encaissements réels et le surplus disponible restent inconnus. Promotion économique : EN ATTENTE.",
        },
        "originalFourArmEconomicSummary": economic,
        "allThirtyFinanceCases": economic["C"]["cases"],
        "independentArithmeticAudit": economics_audit,
        "resourceReportingAmendment": resource_amendment,
        "assumptions": assumptions,
        "llmCostBoundary": "Current LLM comparator is an additive fifth evaluation; it is not silently inserted into the immutable four-arm economic analysis. Model inference, interactive authoring and actual complete billing are unknown.",
        "actualFullCostUSD": None, "actualCollectionsUSD": None, "actualAvailableSurplusUSD": None,
    },
    "links": {"paper": "AGI_ALPHA_Build_the_Next_Advantage.pdf", "companion": "AGI_ALPHA_Next_Advantage_Companion.zip"},
    "provenance": {"viewScope": "Display projection of actual frozen research and explicitly simulated shared accounting; no new accounting calculations or schema", "sources": sources},
}
assert data["research"]["independentChecks"] == 480
assert data["research"]["missionsPerArm"] == 96
assert data["economics"]["referenceCosts"]["fullyLoaded"] == 1.211784
(OUT / "demo_data.json").write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")
(OUT / "DATA_PROJECTION_MANIFEST.json").write_text(json.dumps({"sources": sources, "data_sha256": hashlib.sha256((OUT / "demo_data.json").read_bytes()).hexdigest(), "actual_collections": None, "observed_surplus": None, "finance_is_simulated": True}, indent=2) + "\n")
print(json.dumps({"examples": len(examples), "arms": len(metrics["arms"]), "uniqueMissions": data["research"]["missionsPerArm"], "repeatedEvaluations": data["research"]["independentChecks"], "bytes": (OUT / "demo_data.json").stat().st_size}))
