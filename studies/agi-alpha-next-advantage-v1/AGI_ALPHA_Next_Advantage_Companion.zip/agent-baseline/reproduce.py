#!/usr/bin/env python3
"""Reproduce the frozen mappings from recorded CLI labels, without an oracle."""
import importlib.util
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
SOURCE = HERE / "runs" / "primary01" / "agent.source.py"
spec = importlib.util.spec_from_file_location("frozen_comparator", SOURCE)
agent = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = agent
spec.loader.exec_module(agent)
directory = HERE / "runs" / "replay01"
directory.mkdir(exist_ok=False)
expected = json.loads((HERE / "runs" / "primary01" / "programs.json").read_text())
checks = {}
for schema, target in expected.items():
    task = json.loads((HERE / "public" / (schema + ".task.json")).read_text())
    observations = json.loads((HERE / "runs" / "primary01" / (schema + ".observations.json")).read_text())
    labels = {row["row"]: row["label"] for row in observations}
    constructor = agent.Constructor(task, lambda task_id, row: labels[row], directory / "actions.jsonl")
    result = constructor.construct()
    checks[schema] = {
        "programIdentical": result["program"] == target["program"],
        "statusIdentical": result["status"] == target["status"],
        "queriedRowsIdentical": result["queriedRows"] == target["queriedRows"],
        "logicalCountersIdentical": all(result["metrics"][key] == target["metrics"][key] for key in
                                         ("labelQueries", "candidateEvaluations", "candidateLabelComparisons", "selectionOperations", "poolConsistencyChecks")),
    }
    agent.save_json(directory / (schema + ".result.json"), result)
report = {"passed": all(all(check.values()) for check in checks.values()),
          "newOracleCalls": 0, "schemaCount": len(checks), "checks": checks}
agent.save_json(directory / "verification.json", report)
print(json.dumps(report, sort_keys=True))
raise SystemExit(0 if report["passed"] else 1)
