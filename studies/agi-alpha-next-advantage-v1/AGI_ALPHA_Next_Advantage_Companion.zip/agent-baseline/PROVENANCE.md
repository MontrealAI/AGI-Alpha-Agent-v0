# Current-session LLM comparator provenance

This is **one same-session LLM-assisted construction run** with standard local
tools. It is not an external blinded evaluation, a matched-dollar evaluation,
or a measurement of complete LLM construction cost. Provider token count and
provider billing are not exposed; both remain **unknown / null**. LLM inference
and interactive source-authoring time are not measured by the constructor CLI.

## Access and acquisition

The comparator read its task, the supplied interface, held-out public schema
pools, and public development tasks/labels. It did not open the parent
implementation, learned recipe, evaluator source, sealed truth/labels, or
production inputs/results. Held-out canonical labels entered only through
explicit executions of the supplied `label_oracle.py` CLI. That oracle was
executed but neither inspected nor modified. No network, credential, payment,
publishing, or external API operations were performed.

A collaboration-status inventory inadvertently returned sibling-agent summary
metadata. It included a boundary-syntax audit recommendation that a leading
currency symbol and trailing code must not be combined. The already-read
interface explicitly states the same rule. No referenced implementation or
result files were opened, and the returned summaries contained no production
targets or production outcomes. This exposure is recorded as a further reason
not to describe this run as externally blinded. A separate child reviewer was
given only the allowed task/interface/public inputs and supplied grammar and
accounting advice; it made no oracle calls.

There was one held-out acquisition run, `primary01`, from
2026-10-25T21:07:22.541984+00:00 to
2026-10-25T21:07:23.342185+00:00. It made **29 explicit label requests** across
24 schemas, with no repeated row requests. H01, H03, H07, H08, and H21 used two
labels each; every other schema used one. All requested stdout/stderr and exact
CLI arguments are preserved in `runs/primary01/`.

## Construction method

The constructor enumerates every allowed `(field, column, operation)` candidate:
12 candidates per header across the six fields. It does not remove candidates
using family names, SKU/vendor naming conventions, or unqueried inferred labels.
Literal candidate identities remain distinct even when their predictions agree.

For each possible next pool row, it groups the surviving candidates by their
valid predicted value. It selects the row minimizing the product of the largest
field buckets, then the summed worst-case ambiguity, then a uniform marginal
bucket-size heuristic, then original row index. This heuristic is not a claim
about the true distribution of labels. Price amounts share numerical buckets
for selection; retained affix metadata is checked against the actual queried
currency during elimination.

Only queried labels remove candidates. A program is emitted only after exactly
one literal expression survives for every field. The resulting program is then
checked against all public pool rows for syntax and explicit currency-affix
consistency. This last check can cause refusal; it cannot select a replacement
mapping or supply unqueried target labels. The comparator found a unique mapping
for all 24 schemas. **CONSTRUCTED does not mean admitted or verified on fresh
production missions.** No such production verification was available at freeze.

Text trimming preserves case and interior characters. Numeric syntax uses ASCII
digits and integer arithmetic. Both a leading symbol and trailing currency code
are rejected together. The interface does not enumerate every symbol-to-code
relationship: this matcher conservatively associates `$` with USD, as in the
public examples, and `€` with EUR. That is an interpretation of the examples,
not a universal currency-symbol rule. It could refuse a dollar-symbol row that
explicitly declared another currency. Symbols never infer exchange rates or
replace the required currency field. The final programs contain only the
declared finite JSON operations and are executed by the common parent runtime.

## Development, corrections, and reproducibility

One local development run, `dev01`, constructed all 12 public development
schemas using 15 selected examples. Every emitted development mapping matched
all 16 public labels for its schema. The complete run and source snapshot are
preserved. After this run and before held-out acquisition, the sole constructor
source correction narrowed dollar-symbol consistency from USD/CAD to USD. Both
source versions remain available in their run directories.

Thirty-nine literal parser/affix checks passed. There were no failed executable
development or held-out construction attempts. Logs, including empty stderr,
are retained. The held-out constructor source SHA-256 is
`8f8ecae0461950210b12f8adb526aec42cb8f2b038c4619b60473b64bb3f46e7`.

Before freeze, `reproduce.py` re-executed that exact source with only the saved
29 canonical observations. All 24 programs, statuses, selected-row sequences,
and logical counters reproduced identically. This replay made **zero new oracle
calls** and received no production feedback. Its timings are a separate replay,
not a replacement for the original acquisition measurements.

To review or reproduce, inspect `agent.py`, the source snapshots, and the raw
transcripts. In a clean copy without `runs/replay01/`, run:

```sh
python3 agent-baseline/reproduce.py
```

The acquisition command was:

```sh
python3 agent-baseline/agent.py heldout --run-id primary01
```

Run directories are created exclusively; the script refuses to overwrite an
existing run. Re-running acquisition would be a new run and must not be silently
substituted into this primary comparison.

## Counter and timing definitions

| Recorded metric | Definition and primary total |
|---|---|
| `labelQueries` | Explicit canonical row requests, including any failed request; **29**. |
| `candidateEvaluations` | First parse attempt for a `(schema, field, column, operation, row)` prediction, including invalid parses; **36,288**. The per-schema constructor owns its cache, so schema identity is implicit in cache ownership. |
| `candidateLabelComparisons` | Candidate predictions compared against requested canonical labels; **2,303**. |
| `selectionOperations` | One cached candidate prediction inspected for scoring, plus one completed row-score comparison; **37,272**. This is not a count of all machine instructions. |
| `poolConsistencyChecks` | Complete uniquely mapped raw pool rows checked after identification; **384**. Any new parses are charged to `candidateEvaluations`. |
| `cpuMs` | Parent process CPU plus waited-for child CPU from the start of each schema constructor through program determination; sum **766.132711 ms**. |
| `wallMs` | Elapsed per-schema CLI construction time, including subprocess startup and oracle waiting/I/O; sum **763.166087 ms**. |

The overall acquisition process measured **803.285452 ms CPU** and
**800.266826 ms wall**, including orchestration and output/checkpoint work.
Small CPU/wall differences are host-accounting effects. The overall measurement
ends before writing its own summary and excludes interactive authoring, model
inference, development, and subsequent replay/freeze work. These are descriptive
CLI timings, not complete economic costs or provider latency measurements.

The interface leaves some ambiguity about charging cached label comparisons.
For conservative verification, `BUDGET_AUDIT.json` additionally counts parses
plus label comparisons: **38,591** total, at most **2,047** per schema. Even if
all recorded selection units were charged as well, the maximum would be
**4,103** per schema, below the shared 200,000 ceiling. The maximum label use was
two, below the shared eight-label limit. No interpretation of these additional
counter charges changes any constructed program.

`programs.json` is copied byte-for-byte from the original acquisition result.
`FREEZE.json` binds the deliverables, source snapshots, transcripts, and permitted
inputs by SHA-256. Candidate outputs are final before any production-result
feedback. No source-specific post-production repair is authorized for this
primary comparator run.
