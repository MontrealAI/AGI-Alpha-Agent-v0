#!/usr/bin/env python3
"""Freeze original comparator output and measured-budget evidence."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent
results_path = HERE / "runs" / "primary01" / "programs.json"
raw = results_path.read_bytes()
results = json.loads(raw)
assert sorted(results) == ["H%02d" % i for i in range(1, 25)]
replay = json.loads((HERE / "runs" / "replay01" / "verification.json").read_text())
assert replay["passed"] and replay["newOracleCalls"] == 0
audit = {}
for schema, result in results.items():
    metrics = result["metrics"]
    labels = metrics["labelQueries"]
    parse_count = metrics["candidateEvaluations"]
    conservative_count = parse_count + metrics["candidateLabelComparisons"]
    all_counted = conservative_count + metrics["selectionOperations"]
    assert labels == len(result["queriedRows"]) == len(set(result["queriedRows"]))
    assert labels <= 8 and all_counted <= 200000
    if result["status"] == "CONSTRUCTED":
        assert all(len(value) == 1 for value in result["remainingCandidates"].values())
    audit[schema] = {
        "labelQueries": labels,
        "candidateRowParseAttempts": parse_count,
        "candidateLabelComparisons": metrics["candidateLabelComparisons"],
        "conservativeParsePlusLabelCharges": conservative_count,
        "parsePlusLabelPlusSelectionCharges": all_counted,
        "withinEightLabelAnd200000CandidateCaps": True,
    }
with (HERE / "programs.json").open("xb") as output:
    output.write(raw)
with (HERE / "BUDGET_AUDIT.json").open("x") as output:
    json.dump({"allWithinCaps": True, "schemas": audit}, output, indent=2, sort_keys=True)
    output.write("\n")

authored = [HERE / filename for filename in (
    "agent.py", "verify_parser.py", "reproduce.py", "freeze.py",
    "PROVENANCE.md", "ACTION_LOG.md", "programs.json", "BUDGET_AUDIT.json",
    "parser-checks.json", "parser-checks.stdout.log", "parser-checks.stderr.log",
    "development-dev01.stdout.log", "development-dev01.stderr.log",
    "heldout-primary01.stdout.log", "heldout-primary01.stderr.log",
    "replay.stdout.log", "replay.stderr.log",
)]
authored.extend(p for p in (HERE / "runs").rglob("*")
                if p.is_file() and p.suffix in (".py", ".json", ".jsonl", ".txt", ".log"))
inputs = [HERE / "TASK.md", PROJECT / "protocol" / "INTERFACE.md"]
inputs.extend(sorted((HERE / "public").glob("H*.task.json")))
inputs.extend(sorted((HERE / "public" / "development").glob("D*.task.json")))
inputs.extend(sorted((HERE / "public" / "development").glob("D*.labels.json")))
def hashes(paths):
    return {str(path.relative_to(PROJECT)): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted(set(paths))}
manifest = {
    "frozenUtc": datetime.now(timezone.utc).isoformat(),
    "primaryRun": "primary01",
    "programsSha256": hashlib.sha256(raw).hexdigest(),
    "noProductionInputsOrResultsBeforeFreeze": True,
    "sameSessionLLMAssistedConstruction": True,
    "externalBlindedEvaluation": False,
    "incidentalSiblingAuditMetadataExposureDisclosed": True,
    "providerTokenCount": None,
    "providerBilling": None,
    "artifacts": hashes(authored),
    "permittedInputs": hashes(inputs),
}
with (HERE / "FREEZE.json").open("x") as output:
    json.dump(manifest, output, indent=2, sort_keys=True)
    output.write("\n")
print(json.dumps({"frozenUtc": manifest["frozenUtc"], "programsSha256": manifest["programsSha256"],
                  "artifactCount": len(manifest["artifacts"]), "inputCount": len(manifest["permittedInputs"]),
                  "constructed": sum(row["status"] == "CONSTRUCTED" for row in results.values()),
                  "labelQueries": sum(row["metrics"]["labelQueries"] for row in results.values())}, sort_keys=True))
