#!/usr/bin/env python3
"""Small independent literal checks for the declared parser boundary rules."""
import json
from pathlib import Path
from agent import parse_value, consistent_affix


CASES = [
    ("item", "text", " \tAbC  Def\t ", "AbC  Def"),
    ("item", "text", "AbC\tDef", None),
    ("item", "text", "a" * 61, None),
    ("currency", "currency", " cad ", "CAD"),
    ("currency", "currency", "uſd", None),
    ("pack_units", "integer", "0", None),
    ("pack_units", "integer", "10000", 10000),
    ("pack_units", "integer", "10001", None),
    ("pack_units", "integer", "01", None),
    ("pack_units", "integer", "١", None),
    ("pack_units", "integer", "+1", None),
    ("pack_units", "units-suffix", "12 PIÈCES", 12),
    ("pack_units", "units-prefix", "X12", 12),
    ("pack_units", "units-prefix", "x 12", None),
    ("lead_days", "days-suffix", "0 jours", 0),
    ("lead_days", "weeks-suffix", "52 semaines", 364),
    ("lead_days", "weeks-suffix", "53 weeks", None),
    ("lead_days", "integer", "366", None),
    ("pack_price_minor", "minor", "100000000", 100000000),
    ("pack_price_minor", "minor", "100000001", None),
    ("pack_price_minor", "major-dot", "$1.01", 101),
    ("pack_price_minor", "major-comma", "€1,01", 101),
    ("pack_price_minor", "major-dot", "1.01 cad", 101),
    ("pack_price_minor", "major-dot", "$1.01 USD", None),
    ("pack_price_minor", "major-comma", "€1,01 EUR", None),
    ("pack_price_minor", "major-dot", ".50", None),
    ("pack_price_minor", "major-dot", "01.50", None),
    ("pack_price_minor", "major-dot", "1.5", None),
    ("pack_price_minor", "major-dot", "1,000.00", None),
    ("pack_price_minor", "major-dot", "1e2", None),
    ("pack_price_minor", "major-dot", "-1.00", None),
    ("pack_price_minor", "major-dot", "$$1.00", None),
]

results = []
for field, op, raw, expected in CASES:
    parsed = parse_value(field, op, raw)
    actual = None if parsed is None else parsed.value
    results.append({"field": field, "op": op, "raw": raw, "expected": expected,
                    "actual": actual, "passed": actual == expected})
for affix, currency, expected in [
    ("USD", "USD", True), ("CAD", "USD", False),
    ("€", "EUR", True), ("€", "USD", False),
    ("$", "USD", True), ("$", "EUR", False), (None, "CAD", True),
]:
    actual = consistent_affix(affix, currency)
    results.append({"affix": affix, "currency": currency, "expected": expected,
                    "actual": actual, "passed": actual == expected})
report = {"passed": all(result["passed"] for result in results), "cases": results}
path = Path(__file__).resolve().parent / "parser-checks.json"
path.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n")
print(json.dumps({"passed": report["passed"], "caseCount": len(results), "report": str(path)}))
raise SystemExit(0 if report["passed"] else 1)
