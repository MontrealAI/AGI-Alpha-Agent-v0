# Observable comparator action log

This log records observable actions and results, not internal reasoning.
Detailed construction events with UTC timestamps are in each run's
`actions.jsonl`.

1. Read `agent-baseline/TASK.md` with `cat`.
2. Read `protocol/INTERFACE.md` and inventoried the permitted public input paths
   with `rg --files agent-baseline/public`.
3. Read public H01 and development D01 task/labels; emitted a Python summary of
   IDs, families, headers, and first/last public pool rows for H01–H24.
4. Requested a collaboration status inventory. The returned sibling summaries
   included limited audit metadata. No listed source/result files were opened;
   this incidental exposure is disclosed in `PROVENANCE.md`.
5. Delegated read-only grammar review restricted to the allowed task, interface,
   and public inputs. The reviewer made no oracle calls and wrote no files.
6. Wrote `agent.py`, a standalone finite-grammar enumerator, cached parser,
   active selector, CLI label client, and measured event logger. It imports no
   parent implementation or evaluator modules.
7. Executed:
   `python3 agent-baseline/agent.py development --run-id dev01`, redirecting
   stdout/stderr to preserved development logs. Result: 12 constructed schemas,
   15 selected examples, and all 192 public development labels matched by the
   corresponding programs.
8. Narrowed the authored parser's dollar consistency check from USD/CAD to USD
   before any held-out oracle acquisition. Development and primary source
   snapshots preserve both versions.
9. Wrote and executed `verify_parser.py`. Result: 39/39 literal parser and affix
   checks passed; detailed cases and stdout/stderr are preserved.
10. Executed:
    `python3 agent-baseline/agent.py heldout --run-id primary01`, redirecting
    stdout/stderr to preserved primary logs. Result: 24 CONSTRUCTED, 0 REFUSED;
    29 explicit oracle requests, maximum two per schema. The only held-out label
    reads were these CLI requests. Raw stdout/stderr, exact arguments, individual
    results, observations, and measured counters are retained.
11. Wrote and executed `reproduce.py`, which imported only the exact saved
    comparator source and replayed the recorded labels. Result: all 24 programs,
    statuses, selected rows and logical counters reproduced identically; zero
    new oracle calls.
12. Wrote provenance, this action log, and `freeze.py`. The freeze copies the
    original primary `programs.json` without modification, audits the recorded
    caps, and hashes the allowed inputs and authored deliverables. No production
    mission, expected answer, or production outcome was seen before freeze.

No executable attempt failed. Source corrections before production are retained;
the primary acquisition is not replaced by a later timing or repaired result.
