# Current-session LLM agent comparator

Construct reusable input adapters for 24 synthetic supplier-table schema tasks.
You are the separate current-LLM-with-standard-tools comparator. You may write
and execute your own analysis or reusable scripts. Choose the strongest method
you can under the limits; no particular algorithm or favorable result is
required. Return one program or explicit refusal per task.

Read only this task, `protocol/INTERFACE.md` and `agent-baseline/public/` for
the task specification and raw pools. Do not read parent implementation,
learned recipe, results, evaluator code, sealed labels/truth or other files.
You may execute, but must not inspect or alter, the budgeted label service:

`python3 agent-baseline/label_oracle.py H01 0`

It returns the canonical output of one pool row. Use at most eight distinct
labels per task; all calls are recorded. You receive the same 16-row pools,
grammar and 200,000 candidate-evaluation ceiling per task as the deterministic
builders. Any development examples needed are public under
`agent-baseline/public/development/`. Do not use network tools or API services.
No confirmation production rows or expected answers are permitted before your
programs are final. Do not change the grammar, oracle or limits.

The finite program is JSON:

```
{"schema":"alpha-example-adapter/v1","headers":["..."],"fields":{
  "item":{"column":"...","op":"text"},
  "vendor":{"column":"...","op":"text"},
  "pack_units":{"column":"...","op":"integer"},
  "pack_price_minor":{"column":"...","op":"minor"},
  "currency":{"column":"...","op":"currency"},
  "lead_days":{"column":"...","op":"integer"}}}
```

The operation alternatives and exact syntax are in the interface document.
Only emit a unique identifiable mapping. Refuse ambiguities or contradictions.
Preserve case in item/vendor text. Currency symbols must be consistent with
the currency field; a price may have a leading symbol or a trailing currency
code, never both. No conversion rates may be inferred from a symbol.

Write only within `agent-baseline/`, preserving public inputs and the oracle.
Produce `programs.json` as a map from schema ID to
`{status,program,metrics,reason?}`, where status is CONSTRUCTED or REFUSED.
Metrics include labelQueries, candidateEvaluations, selectionOperations,
cpuMs and wallMs where measured. Preserve your executable code, raw outputs,
failed attempts and a concise action log. In `PROVENANCE.md`, state that this is
one same-session LLM-assisted construction run; its provider token count and
billing are not exposed and remain unknown. Do not describe it as an external
blinded or matched-dollar evaluation. Do not reveal internal reasoning; record
observable commands, code and results only.

The parent evaluator will run your frozen programs on unseen production
missions through the same existing Workbench/optimizer and acceptance checker.
No source-specific feedback or repairs after those results are allowed in the
primary comparison. Your own pre-production corrections remain visible.
