#!/usr/bin/env python3
"""Finite adapter construction from public pools and explicitly queried labels.

No imports from the parent implementation. No reading of hidden data. The only
held-out label interface is the separately executed budgeted oracle CLI.
"""
from __future__ import annotations

import argparse
from collections import Counter
from dataclasses import dataclass
from datetime import datetime, timezone
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import re
import resource
import subprocess
import sys
import time


HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent
FIELDS = ("item", "vendor", "pack_units", "pack_price_minor", "currency", "lead_days")
OPERATIONS = {
    "item": ("text",),
    "vendor": ("text",),
    "pack_units": ("integer", "units-suffix", "units-prefix"),
    "pack_price_minor": ("minor", "major-dot", "major-comma"),
    "currency": ("currency",),
    "lead_days": ("integer", "days-suffix", "weeks-suffix"),
}
INTEGER = r"(?:0|[1-9][0-9]*)"
CONTROL = re.compile(r"[\x00-\x1f\x7f]")
CAP_LABELS = 8
CAP_EVALUATIONS = 200000


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def cpu_seconds():
    children = resource.getrusage(resource.RUSAGE_CHILDREN)
    return time.process_time() + children.ru_utime + children.ru_stime


def save_json(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False, sort_keys=True) + "\n")


@dataclass(frozen=True)
class Expression:
    column: str
    index: int
    op: str

    def program(self):
        return {"column": self.column, "op": self.op}


@dataclass(frozen=True)
class Parsed:
    value: object
    affix: str | None = None


def parse_value(field, op, raw):
    """Return None for malformed input; never execute source-cell contents."""
    if not isinstance(raw, str):
        return None
    value = raw.strip()
    if CONTROL.search(value):
        return None
    if op == "text":
        return Parsed(value) if 1 <= len(value) <= 60 else None
    if op == "currency":
        return Parsed(value.upper()) if re.fullmatch(r"[A-Za-z]{3}", value) else None
    if op in ("minor", "major-dot", "major-comma"):
        symbol = None
        code = None
        if value.startswith(("$", "€")):
            symbol, value = value[0], value[1:].strip()
        tail = re.fullmatch(r"(.*?)\s+([A-Za-z]{3})", value)
        if tail:
            value, code = tail.group(1), tail.group(2).upper()
        if symbol is not None and code is not None:
            return None
        if op == "minor":
            if not re.fullmatch(INTEGER, value):
                return None
            number = int(value)
        else:
            separator = "." if op == "major-dot" else ","
            match = re.fullmatch(r"(" + INTEGER + r")" + re.escape(separator) + r"([0-9]{2})", value)
            if not match:
                return None
            number = 100 * int(match.group(1)) + int(match.group(2))
        return Parsed(number, symbol or code) if number <= 100000000 else None
    factor = 1
    if op == "integer":
        match = re.fullmatch(r"(" + INTEGER + r")", value)
    elif op == "units-suffix":
        match = re.fullmatch(r"(" + INTEGER + r") (?:units|unit|pack|pcs|pièces)", value, re.IGNORECASE)
    elif op == "units-prefix":
        match = re.fullmatch(r"[xX](" + INTEGER + r")", value)
    elif op == "days-suffix":
        match = re.fullmatch(r"(" + INTEGER + r") (?:days|day|jours|jour)", value, re.IGNORECASE)
    elif op == "weeks-suffix":
        match = re.fullmatch(r"(" + INTEGER + r") (?:weeks|week|semaines|semaine)", value, re.IGNORECASE)
        factor = 7
    else:
        raise ValueError("Operation outside grammar: " + op)
    if not match:
        return None
    number = int(match.group(1)) * factor
    low, high = (1, 10000) if field == "pack_units" else (0, 365)
    return Parsed(number) if low <= number <= high else None


def consistent_affix(affix, currency):
    if affix is None:
        return True
    if affix == "€":
        return currency == "EUR"
    if affix == "$":
        # The public symbol examples associate '$' with USD. Keep this
        # consistency test conservative; never infer an exchange rate.
        return currency == "USD"
    return affix == currency


def matches_label(field, parsed, label):
    if parsed is None or type(parsed.value) is not type(label[field]):
        return False
    if parsed.value != label[field]:
        return False
    return field != "pack_price_minor" or consistent_affix(parsed.affix, label["currency"])


class Constructor:
    def __init__(self, task, query, event_log):
        self.task = task
        self.query = query
        self.event_log = event_log
        self.metrics = {
            "labelQueries": 0,
            "candidateEvaluations": 0,
            "selectionOperations": 0,
            "candidateLabelComparisons": 0,
            "poolConsistencyChecks": 0,
            "providerTokenCount": None,
            "providerBilling": None,
        }
        self.survivors = {
            field: [Expression(header, index, op)
                    for index, header in enumerate(task["headers"])
                    for op in OPERATIONS[field]]
            for field in FIELDS
        }
        self.cache = {}
        self.used = []
        self.observations = []

    def event(self, event, **extra):
        record = {"utc": utc_now(), "schema": self.task["id"], "event": event, **extra}
        with self.event_log.open("a") as output:
            output.write(json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n")

    def evaluate(self, field, candidate, row_index):
        key = (field, candidate, row_index)
        if key not in self.cache:
            if self.metrics["candidateEvaluations"] >= CAP_EVALUATIONS:
                raise RuntimeError("candidate-evaluation budget exhausted")
            self.metrics["candidateEvaluations"] += 1
            self.cache[key] = parse_value(field, candidate.op, self.task["pool"][row_index][candidate.index])
        return self.cache[key]

    def select(self):
        """Minimize worst-case candidate ambiguity over valid answer buckets.

        Unknown labels never enter this ranking. Expressions remain distinct,
        including when their values coincide. Invalid parses cannot be labels.
        Tie breaks use expected bucket size under a stated uniform candidate
        heuristic and then the original row index; neither removes a candidate.
        """
        best = None
        choice = None
        detail = None
        for row_index in range(len(self.task["pool"])):
            if row_index in self.used:
                continue
            worst_product = 1
            worst_ambiguity = 0
            expected_product = Fraction(1)
            field_counts = {}
            for field in FIELDS:
                counts = Counter()
                for candidate in self.survivors[field]:
                    self.metrics["selectionOperations"] += 1
                    parsed = self.evaluate(field, candidate, row_index)
                    if parsed is not None:
                        # Currency consistency is checked against the queried
                        # label. Numeric price buckets conservatively merge
                        # different affixes during selection only.
                        counts[(type(parsed.value).__name__, parsed.value)] += 1
                if not counts:
                    # Query this row to obtain evidence of contradiction.
                    worst = 0
                    expected = Fraction(0)
                else:
                    worst = max(counts.values())
                    expected = Fraction(sum(n*n for n in counts.values()), sum(counts.values()))
                worst_product *= worst
                worst_ambiguity += max(0, worst - 1)
                expected_product *= expected
                field_counts[field] = {"validBuckets": len(counts), "largestBucket": worst}
            score = (worst_product, worst_ambiguity, expected_product, row_index)
            self.metrics["selectionOperations"] += 1
            if best is None or score < best:
                best, choice, detail = score, row_index, field_counts
        return choice, detail

    def construct(self):
        wall_start, cpu_start = time.perf_counter(), cpu_seconds()
        outcome = None
        reason = None
        program = None
        self.event("construction_started", initialCandidates={f: len(v) for f, v in self.survivors.items()})
        try:
            headers, pool = self.task["headers"], self.task["pool"]
            if not 6 <= len(headers) <= 10 or len(set(headers)) != len(headers) or any(not isinstance(h, str) or not h for h in headers):
                raise ValueError("invalid header contract")
            if len(pool) != 16 or any(len(row) != len(headers) for row in pool):
                raise ValueError("invalid pool dimensions")
            for _ in range(CAP_LABELS):
                row_index, detail = self.select()
                if row_index is None:
                    outcome, reason = "REFUSED", "no unqueried pool rows remain"
                    break
                self.event("row_selected", row=row_index, selectorBuckets=detail)
                self.used.append(row_index)
                self.metrics["labelQueries"] += 1
                label = self.query(self.task["id"], row_index)
                if not isinstance(label, dict) or set(label) != set(FIELDS):
                    raise ValueError("oracle returned an invalid label shape")
                self.observations.append({"row": row_index, "label": label})
                for field in FIELDS:
                    remaining = []
                    for candidate in self.survivors[field]:
                        self.metrics["candidateLabelComparisons"] += 1
                        if matches_label(field, self.evaluate(field, candidate, row_index), label):
                            remaining.append(candidate)
                    self.survivors[field] = remaining
                counts = {f: len(v) for f, v in self.survivors.items()}
                self.event("label_applied", row=row_index, remainingCandidates=counts)
                if any(n == 0 for n in counts.values()):
                    outcome, reason = "REFUSED", "queried label contradicts the finite grammar"
                    break
                if all(n == 1 for n in counts.values()):
                    program = {
                        "schema": "alpha-example-adapter/v1",
                        "headers": list(headers),
                        "fields": {f: self.survivors[f][0].program() for f in FIELDS},
                    }
                    # Check the uniquely identified program against raw pool
                    # syntax and explicit currency; do not infer new targets.
                    for pool_index in range(len(pool)):
                        parsed = {f: self.evaluate(f, self.survivors[f][0], pool_index) for f in FIELDS}
                        self.metrics["poolConsistencyChecks"] += 1
                        if any(value is None for value in parsed.values()):
                            raise ValueError("unique program rejects public pool syntax")
                        if not consistent_affix(parsed["pack_price_minor"].affix, parsed["currency"].value):
                            raise ValueError("unique program has a contradictory currency affix")
                    outcome = "CONSTRUCTED"
                    break
            if outcome is None:
                outcome, reason = "REFUSED", "eight-label budget exhausted with multiple surviving expressions"
        except Exception as error:
            outcome, reason, program = "REFUSED", type(error).__name__ + ": " + str(error), None
            self.event("construction_exception", errorType=type(error).__name__, message=str(error))
        self.metrics["cpuMs"] = round(1000 * (cpu_seconds() - cpu_start), 6)
        self.metrics["wallMs"] = round(1000 * (time.perf_counter() - wall_start), 6)
        result = {
            "status": outcome,
            "program": program,
            "metrics": self.metrics,
            "queriedRows": list(self.used),
            "remainingCandidates": {f: [c.program() for c in cs] for f, cs in self.survivors.items()},
        }
        if reason is not None:
            result["reason"] = reason
        self.event("construction_finished", status=outcome, reason=reason, metrics=self.metrics)
        return result


def run_development(directory):
    results = {}
    validations = {}
    for task_path in sorted((HERE / "public" / "development").glob("D*.task.json")):
        task = json.loads(task_path.read_text())
        labels = json.loads(task_path.with_name(task["id"] + ".labels.json").read_text())["labels"]
        constructor = Constructor(task, lambda schema, row: labels[row], directory / "actions.jsonl")
        result = constructor.construct()
        results[task["id"]] = result
        issues = []
        if result["status"] == "CONSTRUCTED":
            program = result["program"]
            for index, (row, label) in enumerate(zip(task["pool"], labels)):
                for field, expression in program["fields"].items():
                    raw = row[task["headers"].index(expression["column"])]
                    parsed = parse_value(field, expression["op"], raw)
                    if not matches_label(field, parsed, label):
                        issues.append({"row": index, "field": field})
        else:
            issues.append({"status": result["status"], "reason": result.get("reason")})
        validations[task["id"]] = {"all16PublicLabelsMatch": not issues, "issues": issues}
        print(json.dumps({"id": task["id"], "status": result["status"], "metrics": result["metrics"], "validation": validations[task["id"]]}, sort_keys=True), flush=True)
    save_json(directory / "programs.json", results)
    save_json(directory / "validation.json", validations)
    return results


def run_heldout(directory):
    results = {}
    def query(schema, row):
        stem = directory / (schema + "-row-" + str(row))
        command = [sys.executable, str(HERE / "label_oracle.py"), schema, str(row)]
        stamp = utc_now()
        started = time.perf_counter()
        completed = subprocess.run(command, cwd=PROJECT, text=True, capture_output=True, check=False)
        stem.with_suffix(".stdout.txt").write_text(completed.stdout)
        stem.with_suffix(".stderr.txt").write_text(completed.stderr)
        save_json(stem.with_suffix(".command.json"), {
            "utc": stamp, "argv": command, "returnCode": completed.returncode,
            "wallMs": 1000 * (time.perf_counter() - started),
        })
        if completed.returncode:
            raise RuntimeError("label oracle returned status " + str(completed.returncode))
        response = json.loads(completed.stdout)
        if isinstance(response, dict) and "label" in response:
            return response["label"]
        return response

    paths = [HERE / "public" / ("H%02d.task.json" % index) for index in range(1, 25)]
    for path in paths:
        task = json.loads(path.read_text())
        constructor = Constructor(task, query, directory / "actions.jsonl")
        result = constructor.construct()
        results[task["id"]] = result
        save_json(directory / (task["id"] + ".result.json"), result)
        save_json(directory / (task["id"] + ".observations.json"), constructor.observations)
        # Checkpoint each finished schema, preserving the raw CLI transcript.
        save_json(directory / "programs.json", results)
        print(json.dumps({"id": task["id"], "status": result["status"], "metrics": result["metrics"], "queriedRows": result["queriedRows"], "reason": result.get("reason")}, sort_keys=True), flush=True)
    return results


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("development", "heldout"))
    parser.add_argument("--run-id", required=True)
    args = parser.parse_args()
    if not re.fullmatch(r"[A-Za-z0-9_-]+", args.run_id):
        raise SystemExit("Invalid run identifier")
    directory = HERE / "runs" / args.run_id
    directory.mkdir(parents=True, exist_ok=False)
    started_utc = utc_now()
    wall_start, cpu_start = time.perf_counter(), cpu_seconds()
    source = Path(__file__).read_bytes()
    (directory / "agent.source.py").write_bytes(source)
    results = run_development(directory) if args.mode == "development" else run_heldout(directory)
    totals = {key: sum(result["metrics"][key] for result in results.values()) for key in
              ("labelQueries", "candidateEvaluations", "selectionOperations", "candidateLabelComparisons", "poolConsistencyChecks", "cpuMs", "wallMs")}
    summary = {
        "mode": args.mode,
        "runId": args.run_id,
        "startedUtc": started_utc,
        "finishedUtc": utc_now(),
        "sourceSha256": hashlib.sha256(source).hexdigest(),
        "tasks": len(results),
        "constructed": sum(result["status"] == "CONSTRUCTED" for result in results.values()),
        "refused": sum(result["status"] == "REFUSED" for result in results.values()),
        "perTaskMetricSums": totals,
        "runCpuMs": 1000 * (cpu_seconds() - cpu_start),
        "runWallMs": 1000 * (time.perf_counter() - wall_start),
        "providerTokenCount": None,
        "providerBilling": None,
        "authoringAndLLMInferenceWallMs": None,
    }
    save_json(directory / "summary.json", summary)
    print(json.dumps(summary, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
