# SPDX-License-Identifier: Apache-2.0
import json, re, sys, time
from pathlib import Path

root = Path(__file__).resolve().parent.parent
schema, row = sys.argv[1], int(sys.argv[2])
if not re.fullmatch(r'H[0-9]{2}', schema) or not 0 <= row < 16: raise SystemExit('BAD_REQUEST')
events_path = root / 'agent-baseline' / 'oracle-events.jsonl'
events = [json.loads(x) for x in events_path.read_text().splitlines()] if events_path.exists() else []
prior = [e for e in events if e['schema'] == schema]
indices = {e['row'] for e in prior}
if row not in indices and len(indices) >= 8: raise SystemExit('LABEL_BUDGET_EXHAUSTED')
label = json.loads((root / 'evaluation' / 'sealed' / 'confirmation' / f'{schema}.truth.json').read_text())['labels'][row]
event = {'schema': schema, 'row': row, 'cached': row in indices, 'label': label, 'timeNs': time.time_ns()}
with events_path.open('a') as stream: stream.write(json.dumps(event, sort_keys=True) + '\n')
print(json.dumps(label, sort_keys=True))
