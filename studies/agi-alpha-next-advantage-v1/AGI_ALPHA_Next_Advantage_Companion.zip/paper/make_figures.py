#!/usr/bin/env python3
"""Publication figures from preserved AGI ALPHA Next Advantage result records.

No experiment, inference, economic model or accounting input is modified here.
Reproduce from project root with: python paper/make_figures.py
Outputs: four vector PDFs, four PNGs and a source/caption manifest.
"""
from __future__ import annotations

import hashlib
import json
import os
import platform
import tempfile
from collections import OrderedDict
from pathlib import Path

os.environ.setdefault("MPLCONFIGDIR", str(Path(tempfile.gettempdir()) / "agi-alpha-nadv-mpl"))
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import numpy as np
from matplotlib.lines import Line2D
from matplotlib.patches import Patch, Rectangle

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "paper" / "figures"
METRICS_PATH = ROOT / "results" / "metrics-with-llm.json"
ECON_PATH = ROOT / "economics" / "figure-data-v1.json"
METRICS = json.loads(METRICS_PATH.read_text())
ECON = json.loads(ECON_PATH.read_text())
OUT.mkdir(parents=True, exist_ok=True)

INK = "#2B173D"
PURPLE = "#58208A"
LAVENDER = "#A493C4"
TEAL = "#007D82"
BLUE = "#4666A6"
ORANGE = "#AF5700"
GREY = "#68717C"
PALE = "#E7E0EE"
GRID = "#E8E4ED"
LABEL = "#514B5B"
COLORS = {"rebuild": GREY, "ordinary_reuse": BLUE, "retained": PURPLE,
          "active_specialist": TEAL, "current_llm": "#556A75"}
ARM_ORDER = ["rebuild", "ordinary_reuse", "retained", "active_specialist", "current_llm"]
SHORT = {"rebuild": "Rebuild", "ordinary_reuse": "Ordinary reuse", "retained": "Retained recipe",
         "active_specialist": "Active specialist", "current_llm": "LLM-assisted†"}

plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 9.2, "axes.labelsize": 9.2,
    "axes.titlesize": 10, "axes.titleweight": "bold", "axes.titlepad": 8,
    "axes.labelcolor": LABEL, "text.color": INK, "xtick.color": LABEL, "ytick.color": LABEL,
    "xtick.labelsize": 8.8, "ytick.labelsize": 9.2, "legend.fontsize": 8.6,
    "axes.edgecolor": "#B8AFBF", "axes.linewidth": 0.7,
    "grid.color": GRID, "grid.linewidth": 0.65,
    "pdf.fonttype": 42, "ps.fonttype": 42,
    "figure.facecolor": "white", "axes.facecolor": "white", "savefig.facecolor": "white",
    "hatch.linewidth": 0.7, "lines.linewidth": 1.7,
    "axes.unicode_minus": True, "text.parse_math": False,
})


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def framing(fig, title, subtitle):
    fig.text(0.035, 0.967, title, va="top", fontsize=12.4, weight="bold", color=INK)
    fig.text(0.035, 0.919, subtitle, va="top", fontsize=8.8, color=LABEL)
    fig.add_artist(Line2D([0.035, 0.965], [0.893, 0.893], transform=fig.transFigure,
                          color=PURPLE, linewidth=1.4))


def clean(ax, axis="y"):
    for side in ["top", "right"]:
        ax.spines[side].set_visible(False)
    ax.set_axisbelow(True)
    ax.grid(axis=axis)
    ax.tick_params(length=3, width=0.6)


def save(fig, stem, caption, data):
    # Text-bound check is a layout check, not an experimental/statistical test.
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    fb = fig.bbox
    bad = []
    for artist in fig.findobj(match=matplotlib.text.Text):
        if not artist.get_visible() or not artist.get_text():
            continue
        box = artist.get_window_extent(renderer)
        if box.width and box.height and (box.x0 < fb.x0-1 or box.x1 > fb.x1+1 or box.y0 < fb.y0-1 or box.y1 > fb.y1+1):
            bad.append(artist.get_text())
    if bad:
        raise ValueError(f"Text extends beyond {stem}: {bad}")
    meta = {"Title": caption.split(".")[0], "Author": "AGI ALPHA Research",
            "Subject": "Preserved Next Advantage research results; modeled economics explicitly labeled",
            "CreationDate": None, "ModDate": None}
    fig.savefig(OUT / f"{stem}.pdf", metadata=meta)
    fig.savefig(OUT / f"{stem}.png", dpi=240, metadata={"Software": "AGI ALPHA research companion"})
    plt.close(fig)
    return {"stem": stem, "caption": caption, "exactCaptionData": data,
            "pdf": f"paper/figures/{stem}.pdf", "png": f"paper/figures/{stem}.png",
            "pdfSHA256": digest(OUT / f"{stem}.pdf"), "pngSHA256": digest(OUT / f"{stem}.png")}


def capability_queries():
    arms = METRICS["arms"]
    training = METRICS["meta"]["training"]["labelQueries"]
    for row in ECON["labelCounts"]:
        assert arms[row["arm"]]["labelQueries"] == row["productionExampleQueries"]
    assert all(arms[a]["accepted"] == 96 and arms[a]["incorrectAccepted"] == 0 for a in ARM_ORDER)
    fig = plt.figure(figsize=(6.3, 4.0))
    framing(fig, "Useful reports at lower example-query burden",
            "MEASURED  ·  96 accepted reports per arm  ·  0 incorrect acceptances")
    ax = fig.add_axes([0.235, 0.315, 0.455, 0.465])
    train = fig.add_axes([0.765, 0.315, 0.19, 0.465], sharey=ax)
    y = np.arange(len(ARM_ORDER))
    queries = [arms[a]["labelQueries"] for a in ARM_ORDER]
    ax.barh(y, queries, height=0.53, color=[COLORS[a] for a in ARM_ORDER], zorder=3)
    for yy, value in zip(y, queries):
        ax.text(value+5, yy, f"{value}", va="center", fontsize=10, weight="bold")
    ax.set(yticks=y, yticklabels=[SHORT[a] for a in ARM_ORDER], xlim=(0, 275), ylim=(4.6, -0.6))
    ax.set_xticks([0, 60, 120, 180, 240])
    ax.set_xlabel("Production example queries", labelpad=8)
    ax.set_title("A  Production", loc="left")
    clean(ax, "x")
    ax.spines["left"].set_visible(False)
    ax.tick_params(axis="y", length=0, pad=8)
    train.barh([2], [training], height=0.53, facecolor="#F5ECDF", edgecolor=ORANGE,
               hatch="///", linewidth=1.0, zorder=3)
    train.text(training+1.3, 2, str(training), va="center", fontsize=10, weight="bold", color=ORANGE)
    for yy in [0, 1, 3, 4]:
        train.text(1, yy, "—", va="center", color="#AAA2AF", fontsize=11)
    train.set_xlim(0, 40)
    train.set_xticks([0, 20, 40])
    train.set_xlabel("Recipe examples", labelpad=8)
    train.set_title("B  Training", loc="left")
    train.tick_params(axis="y", left=False, labelleft=False)
    clean(train, "x")
    train.spines["left"].set_visible(False)
    fig.text(0.035, 0.153, "Retained, active and LLM-assisted methods tie at 29 production queries.",
             fontsize=9.2, weight="bold", color=PURPLE)
    fig.text(0.035, 0.106, "31 recipe-training examples remain charged; development reruns are not independent trials.",
             fontsize=8.2, color=LABEL)
    fig.text(0.035, 0.062, "†Current-session LLM-assisted constructor: inference, tokens and authoring cost unmetered.", fontsize=8.2, color=LABEL)
    fig.text(0.035, 0.027, "Actual complete costs are unknown. Dashes: no additional study recipe-training episode.", fontsize=8.2, color=LABEL)
    caption = ("Production query use and separately charged recipe training. Rebuild, ordinary reuse, retained recipe, active specialist and the current-session LLM-assisted constructor use 244, 61, 29, 29 and 29 production example queries, respectively, while each accepts 96 of 96 reports with zero incorrect acceptances. The retained method additionally uses 31 development examples. The LLM comparison has unmetered model inference and authoring and is not matched by monetary resource use; actual complete costs are unknown for all arms. Dashes denote no additional study recipe-training episode, not free authoring.")
    return save(fig, "capability_queries", caption, {
        "productionQueries": {a: arms[a]["labelQueries"] for a in ARM_ORDER},
        "acceptedReports": {a: arms[a]["accepted"] for a in ARM_ORDER},
        "incorrectAcceptances": {a: arms[a]["incorrectAccepted"] for a in ARM_ORDER},
        "retainedUniqueTrainingExamples": training,
        "retainedEngineeringValidationQueryCalls": METRICS["meta"]["allEngineeringValidationQueries"],
        "actualFullCostsUSD": None, "actualLLMBillingUSD": None})


def complete_costs():
    order = ARM_ORDER[:-1]
    indexed = {(r["arm"], r["scenario"]): r for r in ECON["costTiers"]}
    fig = plt.figure(figsize=(6.3, 6.3))
    framing(fig, "Full delivery cost depends on operating conditions",
            "MODELED USD  ·  Explicit volume, labor, retry and capital-recovery assumptions")
    ax = fig.add_axes([0.13, 0.565, 0.815, 0.245])
    components = [("execution", "Execution", INK, None),
                  ("additionalHumanPreparationAndExceptions", "Human preparation / exceptions", "#8D6BB0", None),
                  ("additionalRecurringOverhead", "Recurring overhead", "#C3B7D5", None),
                  ("additionalCapitalRecovery", "Capital recovery", "#E8D4B7", "///")]
    bottom = np.zeros(len(order))
    x = np.arange(len(order))
    handles = []
    for key, label, color, hatch in components:
        values = np.array([indexed[(a, "base")]["stackableIncrementsUSD"][key] for a in order])
        ax.bar(x, values, bottom=bottom, width=0.55, color=color, edgecolor="white" if hatch is None else ORANGE,
               linewidth=0.4, hatch=hatch, zorder=3)
        bottom += values
        handles.append(Patch(facecolor=color, edgecolor="white" if hatch is None else ORANGE, hatch=hatch, label=label))
    for xx, total in zip(x, bottom):
        ax.text(xx, total+0.10, f"${total:.3f}", ha="center", va="bottom", fontsize=9.7, weight="bold")
    ax.set_xticks(x, ["Rebuild", "Ordinary\nreuse", "Retained\nrecipe", "Active\nspecialist"])
    ax.tick_params(axis="x", length=0)
    ax.set_ylim(0, 4.7)
    ax.set_yticks([0, 1, 2, 3, 4])
    ax.set_ylabel("Modeled USD / report")
    ax.set_title("A  Base: 500 requests / 490 expected accepted reports per month", loc="left", fontsize=9.6)
    clean(ax)
    fig.legend(handles=handles, loc="upper center", bbox_to_anchor=(0.53, 0.495), ncol=2,
               frameon=False, columnspacing=1.8, handlelength=1.6, fontsize=8.5)
    bx = fig.add_axes([0.13, 0.15, 0.815, 0.245])
    markers = {"rebuild": "s", "ordinary_reuse": "D", "retained": "o", "active_specialist": "^"}
    styles = {"rebuild": (0, (2, 2)), "ordinary_reuse": (0, (5, 2)), "retained": "-", "active_specialist": (0, (5, 1, 1, 1))}
    for arm in order:
        values = [indexed[(arm, s)]["cumulativeTiersUSD"]["fullyLoaded"] for s in ["base", "conservative", "stress"]]
        bx.plot([0, 1, 2], values, color=COLORS[arm], marker=markers[arm], markersize=5.5,
                markerfacecolor="white" if arm in ["ordinary_reuse", "active_specialist"] else COLORS[arm],
                linestyle=styles[arm], label=SHORT[arm], zorder=3)
    bx.set_yscale("log")
    bx.set_ylim(0.7, 1100)
    bx.set_yticks([1, 10, 100, 1000], ["1", "10", "100", "1,000"])
    bx.yaxis.set_minor_locator(mticker.NullLocator())
    bx.set_xlim(-0.12, 2.12)
    bx.set_xticks([0, 1, 2], ["Base\n500 requests / month", "Conservative\n100 requests / month", "Stress\n10 requests / month"])
    bx.set_ylabel("Fully loaded modeled USD\nper accepted report · log scale")
    bx.set_title("B  Prespecified utilization and cost sensitivities", loc="left")
    clean(bx)
    bx.legend(loc="upper left", ncol=2, frameon=False, columnspacing=1.0, handlelength=2, fontsize=8.1)
    fig.text(0.035, 0.047, "Model sensitivities, not observed bills. Active specialist is least costly in all three profiles.",
             fontsize=8.2, color=LABEL)
    fig.text(0.035, 0.021, "LLM full cost is unknown and unranked. Customer attention is priced separately.",
             fontsize=8.2, color=LABEL)
    caption = ("Complete modeled cost of accepted quote reports. Panel A stacks incremental components whose sum is the base fully loaded cost; cumulative tiers must not be added together. Fully loaded base costs are $4.009740 for rebuild, $1.628224 for ordinary reuse, $1.249769 for retained and $1.211784 for the active specialist. For the active specialist the cumulative execution-only, shared-marginal, recurring and fully loaded costs are $0.031225, $0.471090, $0.969274 and $1.211784. Panel B shows all three prespecified profiles on a logarithmic axis. Active-specialist full costs are $1.211784, $15.863884 and $650.040140; retained full costs are $1.249769, $17.034461 and $781.314243. Monthly requested volume is 500, 100 and 10, with operational acceptance assumptions 98%, 90% and 65%. All dollars are modeled; actual complete cost and LLM billing remain unknown. Amortization assumes future use and is not proof that the observed 96-report episode repaid construction.")
    return save(fig, "complete_costs", caption, {"costTiers": ECON["costTiers"], "monetaryStatus": "MODELED_USD"})


def financing_windows():
    lookup = {(r["case"], r["allocationCeilingPercent"]): r for r in ECON["financing"]}
    success = "conditional-success-delayed-payback"
    fig = plt.figure(figsize=(6.3, 6.9))
    framing(fig, "Financeable construction depends on value and timing",
            "SIMULATION  ·  Hypothetical future capability  ·  No observed receipts")
    ax = fig.add_axes([0.15, 0.585, 0.80, 0.23])
    lines = [
        (success, 25, "Success · ceiling 25%", "#8E6BB1", "--", "s"),
        (success, 50, "Success · ceilings 50–100%", PURPLE, "-", "o"),
        ("failed-capability", 50, "Failure · ceiling 50%", ORANGE, "-.", "X"),
        (success, 0, "No construction · ceiling 0%", GREY, ":", None),
    ]
    for case, ceiling, label, color, style, marker in lines:
        rows = lookup[(case, ceiling)]["trace"]
        ax.step([r["month"] for r in rows], [r["netCapabilityBenefitToDateUSD"] for r in rows],
                where="post", color=color, linestyle=style, marker=marker, markersize=4,
                label=label, zorder=3)
    ax.axhline(0, color="#AEA5B8", linewidth=0.7, zorder=1)
    ax.set_xlim(0.7, 12.3)
    ax.set_ylim(-485, 510)
    ax.set_xticks([1, 3, 6, 9, 12])
    ax.set_yticks([-400, -200, 0, 200, 400])
    ax.set_xlabel("Month", labelpad=3)
    ax.set_ylabel("Capability net benefit\n(simulated USD)")
    ax.set_title("A  Benefits after complete construction cost and upkeep", loc="left", fontsize=9.7)
    clean(ax)
    ax.legend(loc="upper left", ncol=1, frameon=False, fontsize=8.2, handlelength=2.3,
              labelspacing=0.28, borderpad=0.1)
    fig.text(0.15, 0.502, "$422.17 construction package, including failed work; $0.30 net benefit per reuse.",
             fontsize=8.5, color=LABEL)
    fig.text(0.15, 0.477, "Complete-cost payback requires 1,408 reuses. A funded failure earns no benefit.",
             fontsize=8.5, color=LABEL)
    mx = fig.add_axes([0.28, 0.095, 0.67, 0.31])
    case_order = [success, "adverse-low-demand", "failed-capability", "zero-saving-reject",
                  "protected-balances-block", "delayed-collection-and-payback"]
    case_labels = ["Conditional\nsuccess", "Low\ndemand", "Failed\ncapability", "Zero\nsaving", "Protected\nbalances", "Delayed\ncollections"]
    ceilings = [0, 25, 50, 75, 100]
    for yy, case in enumerate(case_order):
        for xx, ceiling in enumerate(ceilings):
            cell = lookup[(case, ceiling)]
            net = cell["netCapabilityBenefitUSD"]
            if cell["constructionMonth"] is None:
                face, color = ("#ECE8F0", LABEL)
                text = "No start" if cell["startupStatus"].startswith("REFUSED") else "No buy"
            elif net < 0:
                face, color = ("#F8E5D1", "#8D4300")
                text = f"−${abs(net):.2f}\nM{cell['constructionMonth']} → fail"
            else:
                face, color = ("#E8DCF2", PURPLE)
                text = f"+${net:.2f}\nM{cell['constructionMonth']} → M{cell['firstPaybackMonth']}"
            mx.add_patch(Rectangle((xx-0.5, yy-0.5), 1, 1, facecolor=face, edgecolor="white", linewidth=2))
            mx.text(xx, yy, text, ha="center", va="center", color=color, fontsize=8.0,
                    weight="bold" if cell["constructionMonth"] is not None else "normal", linespacing=1.25)
    mx.set_xlim(-0.5, 4.5)
    mx.set_ylim(5.5, -0.5)
    mx.set_xticks(range(5), [f"{c}%" for c in ceilings])
    mx.xaxis.tick_top()
    mx.set_yticks(range(6), case_labels)
    mx.tick_params(axis="both", length=0, pad=6)
    for spine in mx.spines.values():
        spine.set_visible(False)
    fig.text(0.035, 0.437, "B  All 30 paths: year-end net benefit and construction → payback month",
             fontsize=9.6, weight="bold")
    fig.text(0.035, 0.046, "Columns are allocation ceilings, not spending targets. Values are simulated USD; M denotes month.",
             fontsize=8.3, color=LABEL)
    fig.text(0.035, 0.021, "Low demand, zero saving, delayed collections and protected balances block construction.",
             fontsize=8.3, color=LABEL)
    caption = ("Simulated financeability of a hypothetical future capability. The $422.17 construction package includes $336.69 proposed construction and $85.48 failed construction; assumed gross saving and upkeep are $0.50 and $0.20 per reuse, requiring 1,408 reuses to repay fixed costs. Panel A shows net capability benefit after construction and upkeep. At 25% allocation, conditional success constructs in month 3, benefits start in month 6, payback occurs in month 10, and year-end net benefit is $195.23. Ceilings of 50–100% construct in month 2, benefits start in month 5, pay back in month 9, and end at $283.43. The funded failure loses $422.17. Panel B retains all 30 cases: zero allocation never constructs; low demand, zero saving, delayed collections and protected balances yield no construction at every ceiling. Protected balances block startup entirely. The four-month collection delay yields no overlap between available earned funds and the remaining 1,408-reuse payback requirement. All receipts, costs, future benefits and finance outcomes are simulated; no actual payment or experimental-capability promotion is established.")
    return save(fig, "financing_windows", caption, {
        "constructionCostUSD": 336.69, "failedConstructionCostUSD": 85.48,
        "completeCandidateCostUSD": lookup[(success, 50)]["completeCandidateCostUSD"],
        "breakEvenReuses": lookup[(success, 50)]["trace"][0]["breakEvenReuses"],
        "outcomes": [{k: r[k] for k in ["case", "allocationCeilingPercent", "constructionMonth", "firstBenefitMonth", "firstPaybackMonth", "startupStatus", "netCapabilityBenefitUSD"]} for r in ECON["financing"]],
        "status": "SIMULATION_HYPOTHETICAL_FUTURE_CAPABILITY"})


def capability_progression():
    families = OrderedDict()
    for row in METRICS["perSchema"]:
        f = families.setdefault(row["family"], {"schemaCount": 0, "accepted": 0, "ordinary": 0, "retained": 0, "active": 0})
        f["schemaCount"] += 1
        f["accepted"] += row["retained"]["accepted"]
        f["ordinary"] += row["ordinary_reuse"]["labelQueries"]
        f["retained"] += row["retained"]["labelQueries"]
        f["active"] += row["active_specialist"]["labelQueries"]
    assert len(families) == 6
    assert sum(r["schemaCount"] for r in families.values()) == METRICS["arms"]["retained"]["constructions"] == 24
    assert sum(r["accepted"]-r["schemaCount"] for r in families.values()) == METRICS["arms"]["retained"]["reuseMissions"] == 72
    assert all(r["retained"] == r["active"] for r in families.values())
    labels = {"plain-minor": "Plain minor-unit", "suffix-dot": "Suffix / dot", "prefix-comma": "Prefix / comma",
              "weekly-lead": "Weekly lead time", "affixed-currency": "Currency affixes", "mixed-views": "Mixed views"}
    fig = plt.figure(figsize=(6.3, 4.6))
    framing(fig, "Retained adapters support subsequent fresh work",
            "MEASURED  ·  24 constructed schema adapters  ·  72 subsequent accepted reports")
    ax = fig.add_axes([0.235, 0.265, 0.32, 0.525])
    bx = fig.add_axes([0.66, 0.265, 0.295, 0.525], sharey=ax)
    y = np.arange(len(families))
    first = [r["schemaCount"] for r in families.values()]
    subsequent = [r["accepted"]-r["schemaCount"] for r in families.values()]
    ax.barh(y, first, color=PURPLE, height=0.55, zorder=3)
    ax.barh(y, subsequent, left=first, color="#B4D4D3", height=0.55, zorder=3)
    for yy, (n, rest) in enumerate(zip(first, subsequent)):
        ax.text(n/2, yy, str(n), color="white", ha="center", va="center", fontsize=9, weight="bold")
        ax.text(n+rest/2, yy, str(rest), color="#174B50", ha="center", va="center", fontsize=9, weight="bold")
    ax.set(yticks=y, yticklabels=[labels[f] for f in families], xlim=(0, 17), ylim=(5.6, -0.6))
    ax.set_xticks([0, 4, 8, 12, 16])
    ax.set_xlabel("Accepted reports", labelpad=8)
    ax.set_title("A  Construction → reuse", loc="left", fontsize=9.5)
    ax.tick_params(axis="y", length=0, pad=8)
    clean(ax, "x")
    ax.spines["left"].set_visible(False)
    for yy, values in enumerate(families.values()):
        lo, hi = values["retained"], values["ordinary"]
        bx.plot([lo, hi], [yy, yy], color="#B3A6C1", linewidth=2, zorder=2)
        bx.scatter([hi], [yy], s=32, marker="D", color=BLUE, zorder=4)
        bx.scatter([lo], [yy], s=44, marker="o", color=PURPLE, zorder=5)
        bx.scatter([lo], [yy], s=78, marker="o", facecolors="none", edgecolors=TEAL, linewidths=1.3, zorder=6)
        if lo == hi:
            bx.text(lo+0.7, yy, str(lo), va="center", fontsize=9, color=LABEL)
        else:
            bx.text(lo-0.8, yy-0.18, str(lo), va="center", ha="right", fontsize=8.7, color=PURPLE)
            bx.text(hi+0.7, yy, str(hi), va="center", fontsize=8.7, color=BLUE)
    bx.set_xlim(0, 19)
    bx.set_xticks([0, 6, 12, 18])
    bx.set_xlabel("Production example queries", labelpad=8)
    bx.set_title("B  Queries by family", loc="left", fontsize=9.5)
    clean(bx, "x")
    bx.tick_params(axis="y", left=False, labelleft=False)
    bx.spines["left"].set_visible(False)
    h = [Patch(facecolor=PURPLE, label="First mission / construction"),
         Patch(facecolor="#B4D4D3", label="Subsequent fresh missions"),
         Line2D([], [], color=BLUE, marker="D", linestyle="none", markersize=5, label="Ordinary reuse queries"),
         Line2D([], [], color=PURPLE, marker="o", markeredgecolor=TEAL, markeredgewidth=1.4, linestyle="none", markersize=6,
                label="Retained = active queries")]
    fig.legend(handles=h, loc="upper center", bbox_to_anchor=(0.51, 0.165), ncol=2,
               frameon=False, columnspacing=1.25, handlelength=1.4, fontsize=8.4)
    fig.text(0.035, 0.045, "Four schemas per family, sixteen complete reports; every report passes the independent oracle.",
             fontsize=8.2, color=LABEL)
    fig.text(0.035, 0.019, "Useful repeat delivery is demonstrated. Active-selector superiority and acceleration are not.",
             fontsize=8.2, color=LABEL)
    comparison = next(c for c in METRICS["pairedComparisons"] if c["left"] == "retained" and c["right"] == "ordinary_reuse")
    caption = ("Construction and subsequent useful work across all six held-out format families. In the retained arm each family contains four fresh schemas, four first reports using newly constructed adapters, and twelve subsequent accepted reports using admitted adapters, totaling 24 constructions and 72 reused-capability reports. All 96 reports pass the independent oracle. Ordinary-reuse production example totals are 14, 12, 4, 6, 8 and 17 across plain-minor, suffix-dot, prefix-comma, weekly-lead, affixed-currency and mixed-views families; retained and active-specialist totals are identically 6, 6, 4, 4, 4 and 5. The paired mean difference for retained minus ordinary is −1.333333 queries per schema, with the frozen within-family stratified-bootstrap 95% interval [−1.833333, −0.833333]; the retained-minus-active difference and interval are both zero. Counts establish scoped reuse on subsequent missions, not sustained acceleration, out-of-grammar support or economic promotion.")
    return save(fig, "capability_progression", caption, {
        "families": families, "constructedAdapters": 24, "subsequentAcceptedReports": 72,
        "allAcceptedReports": 96, "pairedComparison": comparison,
        "retainedVsActiveMeanDifference": 0, "retainedVsActive95Interval": [0, 0]})


if __name__ == "__main__":
    outputs = [capability_queries(), complete_costs(), financing_windows(), capability_progression()]
    manifest = {
        "status": "PUBLICATION_FIGURES_FROM_PRESERVED_RESULTS",
        "widthInches": 6.3,
        "source": {str(p.relative_to(ROOT)): digest(p) for p in [METRICS_PATH, ECON_PATH, Path(__file__)]},
        "runtime": {"python": platform.python_version(), "matplotlib": matplotlib.__version__, "numpy": np.__version__},
        "font": "DejaVu Sans; embedded TrueType in vector PDFs",
        "monetaryLabels": "All USD are modeled; all financing is a simulation of a hypothetical future capability.",
        "outputs": outputs,
    }
    (OUT / "figure-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps({"status": manifest["status"], "figures": [x["stem"] for x in outputs], "widthInches": 6.3}))
