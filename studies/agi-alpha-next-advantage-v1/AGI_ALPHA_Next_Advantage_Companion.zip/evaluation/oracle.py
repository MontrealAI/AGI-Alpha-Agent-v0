import csv, io, itertools, json, sys
from fractions import Fraction
from pathlib import Path

FIELDS = ('item', 'vendor', 'pack_units', 'pack_price_minor', 'currency', 'lead_days')

def integer(value, lower, upper, name):
    if type(value) is not int or not lower <= value <= upper: raise ValueError(name)
    return value

def half_up(value):
    quotient, remainder = divmod(value.numerator, value.denominator)
    return quotient + int(remainder * 2 >= value.denominator)

def normalize_truth(mission):
    items = mission['items']; offers = mission['offers']; shipping = mission['shipping_minor']
    if not 1 <= len(items) <= 18 or len({x['id'] for x in items}) != len(items): raise ValueError('ITEMS')
    if not 1 <= len(offers) <= 160 or not 1 <= len(shipping) <= 12: raise ValueError('SCOPE')
    integer(mission['deadline_days'], 0, 365, 'DEADLINE')
    by_id = {x['id']: x for x in items}
    for x in items: integer(x['quantity'], 1, 10000, 'QUANTITY')
    for value in shipping.values(): integer(value, 0, 100000000, 'SHIPPING')
    eligible = []; excluded = []
    for index, offer in enumerate(offers):
        if set(offer) != set(FIELDS): raise ValueError('OFFER_FIELDS')
        if offer['item'] not in by_id or offer['vendor'] not in shipping: raise ValueError('UNKNOWN_ID')
        integer(offer['pack_units'], 1, 10000, 'PACK')
        integer(offer['pack_price_minor'], 0, 100000000, 'PRICE')
        integer(offer['lead_days'], 0, 365, 'LEAD')
        rate = mission['fx'][offer['currency']]
        integer(rate['num'], 1, 1000000, 'FX_NUM'); integer(rate['den'], 1, 1000000, 'FX_DEN')
        item = by_id[offer['item']]; packs, remainder = divmod(item['quantity'], offer['pack_units'])
        packs += int(remainder > 0)
        cost = half_up(Fraction(packs * offer['pack_price_minor'] * rate['num'], rate['den']))
        row = {'index': index, 'item': item['id'], 'label': item['label'], 'vendor': offer['vendor'],
            'quantity': item['quantity'], 'pack_units': offer['pack_units'], 'packs': packs,
            'delivered_units': packs * offer['pack_units'], 'source_currency': offer['currency'],
            'source_pack_price_minor': offer['pack_price_minor'], 'landed_line_minor': cost,
            'lead_days': offer['lead_days'], 'fx_source': rate['source']}
        if offer['lead_days'] > mission['deadline_days']: excluded.append({**row, 'reason': 'DELIVERY_DEADLINE'})
        else: eligible.append(row)
    if any(not any(o['item'] == item['id'] for o in eligible) for item in items): raise ValueError('NO_ELIGIBLE_OFFER')
    return {'title': mission['title'], 'base_currency': mission['base_currency'], 'deadline_days': mission['deadline_days'],
        'items': items, 'vendors': sorted(shipping), 'shipping': shipping, 'offers': eligible, 'excluded': excluded}

def exact_cart(mission):
    normal = normalize_truth(mission)
    choices = [[x for x in normal['offers'] if x['item'] == item['id']] for item in normal['items']]
    count = 1
    for options in choices: count *= len(options)
    if count > 100000: raise ValueError('ORACLE_CART_BUDGET')
    best = None; optima = 0; visited = 0
    for selected in itertools.product(*choices):
        visited += 1
        vendors = {x['vendor'] for x in selected}
        total = sum(x['landed_line_minor'] for x in selected) + sum(normal['shipping'][v] for v in vendors)
        if best is None or total < best: best, optima = total, 1
        elif total == best: optima += 1
    return {'total_minor': best, 'optimal_carts': optima, 'enumerated_carts': visited, 'normalized': normal}

def verify_canonical(expected, actual):
    findings = []
    if not isinstance(actual, list): return ['CANONICAL_OFFERS_NOT_LIST']
    if len(actual) != len(expected): findings.append('CANONICAL_ROW_COUNT')
    for i, (a, b) in enumerate(zip(expected, actual)):
        if not isinstance(b, dict) or set(b) != set(FIELDS): findings.append(f'CANONICAL_FIELDS:{i}'); continue
        for key in FIELDS:
            if type(a[key]) is not type(b[key]) or a[key] != b[key]: findings.append(f'CANONICAL_VALUE:{i}:{key}')
    return findings

def verify_solution(mission, solution):
    expected = exact_cart(mission); findings = []; normal = expected['normalized']
    if not isinstance(solution, dict): return {'accepted': False, 'findings': ['SOLUTION_TYPE'], 'oracle': expected}
    selected = solution.get('selected')
    if not isinstance(selected, list): return {'accepted': False, 'findings': ['SELECTION_TYPE'], 'oracle': expected}
    if len(selected) != len(normal['items']): findings.append('SELECTION_COUNT')
    selected_ids = [x.get('item') for x in selected if isinstance(x, dict)]
    if sorted(selected_ids) != sorted(x['id'] for x in normal['items']): findings.append('SELECTION_ITEMS')
    eligible = {x['index']: x for x in normal['offers']}
    for row in selected:
        if not isinstance(row, dict) or type(row.get('index')) is not int or row.get('index') not in eligible:
            findings.append('SELECTION_INDEX'); continue
        if row != eligible[row['index']]: findings.append(f'SELECTION_FIELDS:{row["index"]}')
    if not findings:
        used = sorted({x['vendor'] for x in selected}); line = sum(x['landed_line_minor'] for x in selected)
        shipping = sum(normal['shipping'][vendor] for vendor in used)
        for field, value in [('line_total_minor', line), ('shipping_minor', shipping), ('total_minor', line + shipping), ('used_vendors', used)]:
            if solution.get(field) != value: findings.append('TOTAL_FIELD:' + field)
        if line + shipping != expected['total_minor']: findings.append('SUBOPTIMAL_CART')
    return {'accepted': not findings, 'findings': findings, 'oracle': expected}

def verify_pack(mission, pack):
    findings = []; result = pack.get('result', {}); evidence = result.get('evidence', {})
    solution = evidence.get('solution'); checked = verify_solution(mission, solution)
    findings.extend(checked['findings']); normal = checked['oracle']['normalized']
    if evidence.get('normalized') != normal: findings.append('NORMALIZED_EVIDENCE')
    if result.get('summary', {}).get('total_minor') != checked['oracle']['total_minor']: findings.append('SUMMARY_TOTAL')
    artifacts = {x.get('name'): x for x in result.get('artifacts', [])}
    for name in ('quote-report.md', 'recommended-cart.csv', 'quote-analysis.json'):
        if name not in artifacts: findings.append('ARTIFACT_MISSING:' + name)
    if 'quote-analysis.json' in artifacts:
        try:
            analysis = json.loads(artifacts['quote-analysis.json']['content'])
            if analysis.get('normalized') != normal or analysis.get('solution') != solution: findings.append('ANALYSIS_ARTIFACT')
        except (ValueError, TypeError, KeyError): findings.append('ANALYSIS_INVALID')
    if 'quote-report.md' in artifacts:
        amount = checked['oracle']['total_minor']; expected_text = f'**{amount // 100}.{amount % 100:02d} {mission["base_currency"]}**'
        if expected_text not in artifacts['quote-report.md'].get('content', ''): findings.append('REPORT_TOTAL')
    if 'recommended-cart.csv' in artifacts and isinstance(solution, dict) and isinstance(solution.get('selected'), list):
        try:
            rows = list(csv.DictReader(io.StringIO(artifacts['recommended-cart.csv']['content'])))
            selected = solution['selected']
            if len(rows) != len(selected): findings.append('CSV_COUNT')
            for raw, row in zip(rows, selected):
                amount = row['landed_line_minor']
                target = {'item': row['label'], 'supplier': row['vendor'], 'required_units': str(row['quantity']),
                    'delivered_units': str(row['delivered_units']), 'packs': str(row['packs']),
                    'line_cost': f'{amount // 100}.{amount % 100:02d} {mission["base_currency"]}', 'delivery_days': str(row['lead_days'])}
                if raw != target: findings.append('CSV_ROW')
        except (ValueError, TypeError, KeyError): findings.append('CSV_INVALID')
    return {'accepted': not findings, 'findings': findings, 'optimal_total_minor': checked['oracle']['total_minor'],
        'oracle_carts': checked['oracle']['enumerated_carts'], 'optimal_carts': checked['oracle']['optimal_carts']}

if __name__ == '__main__':
    mission = json.loads(Path(sys.argv[1]).read_text())
    output = verify_pack(mission, json.loads(Path(sys.argv[2]).read_text())) if len(sys.argv) > 2 else exact_cart(mission)
    print(json.dumps(output, ensure_ascii=False, sort_keys=True))
