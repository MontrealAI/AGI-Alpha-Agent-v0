import copy, hashlib, json, random
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SEED = 'AGI-ALPHA-BUILD-NEXT-ADVANTAGE-DATA-20261025-v1'
FIELDS = ['item', 'vendor', 'pack_units', 'pack_price_minor', 'currency', 'lead_days']
FAMILIES = ['plain-minor', 'suffix-dot', 'prefix-comma', 'weekly-lead', 'affixed-currency', 'mixed-views']
records = []

def rng_for(label):
    return random.Random(int.from_bytes(hashlib.sha256((SEED + ':' + label).encode()).digest(), 'big'))

def write(relative, obj):
    path = ROOT / relative
    if path.exists(): raise FileExistsError(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    data = (json.dumps(obj, ensure_ascii=False, indent=2, sort_keys=True) + '\n').encode()
    path.write_bytes(data)
    records.append({'path': relative, 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)})

def code(rng, prefix='C'):
    alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
    return prefix + ''.join(rng.choice(alphabet) for _ in range(9))

def configuration(split, family, index):
    r = rng_for(f'{split}:{family}:{index}:config')
    headers = []; mapping = {}
    while len(headers) < (10 if family == 'mixed-views' else r.randint(6, 10)):
        value = code(r)
        if value not in headers: headers.append(value)
    assignments = r.sample(headers, 6)
    ops = {'item': 'text', 'vendor': 'text', 'pack_units': 'integer', 'pack_price_minor': 'minor', 'currency': 'currency', 'lead_days': 'integer'}
    if family == 'suffix-dot': ops.update(pack_units='units-suffix', pack_price_minor='major-dot', lead_days='days-suffix')
    if family == 'prefix-comma': ops.update(pack_units='units-prefix', pack_price_minor='major-comma', lead_days='days-suffix')
    if family == 'weekly-lead': ops.update(pack_units='units-suffix', pack_price_minor='major-comma', lead_days='weeks-suffix')
    if family == 'affixed-currency': ops.update(pack_units='units-prefix', pack_price_minor='major-dot', lead_days='days-suffix')
    if family == 'mixed-views': ops.update(pack_units='units-suffix', pack_price_minor='major-dot', lead_days='integer')
    for field, header in zip(FIELDS, assignments): mapping[field] = {'column': header, 'op': ops[field]}
    r.shuffle(headers)
    config = {'family': family, 'split': split, 'index': index, 'headers': headers, 'program': mapping,
        'unit_suffix': (['unit', 'units', 'pack', 'pcs'][index % 4] if split == 'development' else ['pièces', 'pcs', 'units', 'pack'][index % 4]),
        'day_suffix': (['day', 'days', 'day', 'days'][index % 4] if split == 'development' else ['jour', 'jours', 'days', 'jour'][index % 4]),
        'week_suffix': ['weeks', 'semaine', 'week', 'semaines'][index % 4],
        'units_prefix': 'x' if split == 'development' else 'X',
        'padding': ['', ' ', '\t', '  '][index % 4] if split == 'development' else [' \t', '\t ', '   ', '\t\t'][index % 4],
        'currency_case': ['upper', 'lower', 'mixed', 'upper'][index % 4],
        'price_affix': 'none', 'decoy_columns': [x for x in headers if x not in assignments]}
    if family == 'affixed-currency': config['price_affix'] = ['symbol', 'suffix-upper', 'suffix-lower', 'symbol'][index % 4]
    if family == 'mixed-views': config['price_affix'] = 'suffix-upper' if index % 2 else 'none'
    return config

def render(field, value, offer, cfg):
    op = cfg['program'][field]['op']
    if op in ('text', 'integer', 'minor'): result = str(value)
    elif op == 'currency': result = value if cfg['currency_case'] == 'upper' else value.lower() if cfg['currency_case'] == 'lower' else value[0] + value[1:].lower()
    elif op == 'units-suffix': result = f'{value} {cfg["unit_suffix"]}'
    elif op == 'units-prefix': result = cfg['units_prefix'] + str(value)
    elif op == 'days-suffix': result = f'{value} {cfg["day_suffix"]}'
    elif op == 'weeks-suffix':
        if value % 7: raise ValueError('NONWEEK_LEAD')
        result = f'{value // 7} {cfg["week_suffix"]}'
    elif op in ('major-dot', 'major-comma'):
        separator = '.' if op == 'major-dot' else ','
        result = f'{value // 100}{separator}{value % 100:02d}'
        if cfg['price_affix'] == 'symbol':
            if offer['currency'] not in ('USD', 'EUR'): raise ValueError('UNSUPPORTED_SYMBOL')
            result = ('$' if offer['currency'] == 'USD' else '€') + result
        elif cfg['price_affix'].startswith('suffix'): result += ' ' + (offer['currency'].lower() if cfg['price_affix'] == 'suffix-lower' else offer['currency'])
    else: raise ValueError(op)
    return cfg['padding'] + result + cfg['padding']

def make_offer(rng, item, vendor, cfg):
    price = rng.randint(100, 80000)
    lead = rng.randint(0, 5) * 7 if cfg['program']['lead_days']['op'] == 'weeks-suffix' else rng.randint(0, 24)
    return {'item': item, 'vendor': vendor, 'pack_units': rng.choice([1, 2, 3, 4, 6, 8, 12, 24]),
        'pack_price_minor': price, 'currency': rng.choice(['USD', 'EUR'] if cfg['price_affix'] == 'symbol' else ['USD', 'CAD', 'EUR']), 'lead_days': lead}

def raw_rows(offers, cfg, rng, pool=False):
    row_maps = [{cfg['program'][f]['column']: render(f, o[f], o, cfg) for f in FIELDS} for o in offers]
    for j, header in enumerate(cfg['decoy_columns']):
        kind = ['price-view', 'item-alias', 'count-view', 'note'][j % 4]
        coincident = set(rng.sample(range(len(offers)), rng.randint(max(1, len(offers) // 4), max(2, len(offers) - 2))))
        for i, offer in enumerate(offers):
            if kind == 'price-view':
                value = offer['pack_price_minor'] if i in coincident else offer['pack_price_minor'] + rng.randint(1, 500)
                raw = str(value) if cfg['program']['pack_price_minor']['op'] != 'minor' else f'{value // 100}.{value % 100:02d}'
            elif kind == 'item-alias': raw = offer['item'] if i in coincident else 'ALT-' + offer['item']
            elif kind == 'count-view': raw = str(offer['pack_units'] if i in coincident else rng.randint(30, 80))
            else: raw = rng.choice(['quote supplied', 'stock unverified', 'liste indicative', 'public synthetic fixture'])
            row_maps[i][header] = cfg['padding'] + raw + cfg['padding']
    return [[row[header] for header in cfg['headers']] for row in row_maps]

def task(split, family, index, number):
    identifier = ('D' if split == 'development' else 'H') + f'{number:02d}'
    cfg = configuration(split, family, index)
    r = rng_for(identifier + ':pool')
    items = ['SKU-' + code(r, '') for _ in range(5)]; vendors = ['V-' + code(r, '') for _ in range(3)]
    labels = [make_offer(r, r.choice(items), r.choice(vendors), cfg) for _ in range(16)]
    raw = raw_rows(labels, cfg, r, pool=True)
    permutation = r.sample(range(16), 16); raw = [raw[i] for i in permutation]; labels = [labels[i] for i in permutation]
    public = {'id': identifier, 'family': family, 'headers': cfg['headers'], 'pool': raw,
        'description': 'Synthetic vendor export with neutral column codes, permitted finite-format fields and optional nonauthoritative alternate views. Infer only from budgeted worked-example labels. No real supplier quotes or purchases.'}
    truth = {'id': identifier, 'labels': labels, 'expected_program': cfg['program'], 'configuration': cfg,
        'data_class': 'synthetic', 'source': SEED, 'construction_examples': 16, 'candidate_outcomes': 'NOT_RUN'}
    return public, truth

def mission(identifier, cfg, index):
    mid = identifier + '-M' + str(index + 1); r = rng_for(mid)
    items = [{'id': 'I-' + code(r, ''), 'label': r.choice(['Cable kit', 'Storage case', 'Adapter pack', 'Mounting set', 'Paper stock', 'Label roll']) + f' {j + 1}', 'quantity': r.randint(1, 50)} for j in range(r.randint(3, 6))]
    vendors = ['SUP-' + code(r, '') for _ in range(3)]
    shipping = {vendor: r.choice([0, 499, 750, 1200, 1799, 2500]) for vendor in vendors}
    offers = [make_offer(r, item['id'], vendor, cfg) for item in items for vendor in vendors]
    deadline = 21 if cfg['program']['lead_days']['op'] == 'weeks-suffix' else 14
    for item in items:
        candidates = [o for o in offers if o['item'] == item['id']]
        if all(o['lead_days'] > deadline for o in candidates): r.choice(candidates)['lead_days'] = 7
    r.shuffle(offers)
    context = {'title': 'Synthetic equipment quote comparison ' + mid, 'base_currency': 'USD', 'deadline_days': deadline, 'items': items,
        'shipping_minor': shipping, 'fx': {'USD': {'num': 1, 'den': 1, 'source': 'Synthetic identity'},
        'CAD': {'num': 73, 'den': 100, 'source': 'Explicit synthetic scenario; not a current exchange rate'},
        'EUR': {'num': 109, 'den': 100, 'source': 'Explicit synthetic scenario; not a current exchange rate'}}}
    public = {'id': mid, 'schema_id': identifier, 'headers': cfg['headers'], 'rows': raw_rows(offers, cfg, r), 'context': context}
    truth = {'id': mid, 'schema_id': identifier, 'canonical': {**context, 'offers': offers}, 'expected': 'accepted-complete-deliverable', 'data_class': 'synthetic'}
    return public, truth

def boundaries(tasks, truths, missions):
    probes = []
    for offset, identifier in enumerate(['H01', 'H05', 'H09', 'H13']):
        public = copy.deepcopy(tasks[identifier]); truth = truths[identifier]; source = truth['expected_program']['item']['column']
        removable = truth['configuration']['decoy_columns']
        if len(public['headers']) == 10:
            j = public['headers'].index(removable[-1]); public['headers'].pop(j)
            for row in public['pool']: row.pop(j)
        alias = 'AMBIGUOUS_ALIAS_' + str(offset); source_index = public['headers'].index(source)
        public['headers'].append(alias)
        for row in public['pool']: row.append(row[source_index])
        public['id'] = 'B' + f'{len(probes) + 1:02d}'
        probes.append({'id': public['id'], 'category': 'unidentifiable-columns', 'stage': 'construction', 'task': public,
            'labels': truth['labels'], 'expected': 'REFUSE', 'reason': 'Two distinct item-column expressions agree on every permitted example; no unique program exists.'})
    for offset, identifier in enumerate(['H17', 'H18', 'H19', 'H20']):
        public = copy.deepcopy(missions[identifier][0][0]); program = truths[identifier]['expected_program']
        pi = public['headers'].index(program['pack_price_minor']['column']); ci = public['headers'].index(program['currency']['column'])
        public['rows'][0][pi] = '$12.34'; public['rows'][0][ci] = 'EUR'
        probes.append({'id': 'B' + f'{len(probes) + 1:02d}', 'category': 'conflicting-currency-affix', 'stage': 'production', 'mission': public,
            'program': program, 'expected': 'REFUSE', 'reason': 'USD dollar affix conflicts with explicit EUR currency field.'})
    for offset, identifier in enumerate(['H02', 'H06', 'H10', 'H14']):
        public = copy.deepcopy(missions[identifier][0][0]); program = truths[identifier]['expected_program']
        duplicate = public['rows'][0].copy()
        for field in ['item', 'vendor']:
            position = public['headers'].index(program[field]['column']); duplicate[position] = ' ' + duplicate[position].strip() + '\t'
        public['rows'].append(duplicate)
        probes.append({'id': 'B' + f'{len(probes) + 1:02d}', 'category': 'normalized-identity-collision', 'stage': 'production', 'mission': public,
            'program': program, 'expected': 'REFUSE', 'reason': 'Distinct raw rows normalize to the same prohibited item/vendor pair.'})
    for offset, identifier in enumerate(['H03', 'H07', 'H11', 'H15']):
        public = copy.deepcopy(missions[identifier][0][0]); program = truths[identifier]['expected_program']
        field = 'pack_price_minor' if offset != 3 else 'pack_units'; pi = public['headers'].index(program[field]['column'])
        public['rows'][0][pi] = ['1e3', '1,234.56', '12,345', '0 units'][offset]
        probes.append({'id': 'B' + f'{len(probes) + 1:02d}', 'category': 'invalid-format', 'stage': 'production', 'mission': public,
            'program': program, 'expected': 'REFUSE', 'reason': 'Input violates the declared numeric grammar or positive pack-unit bound.'})
    for offset, identifier in enumerate(['H04', 'H08', 'H12', 'H16']):
        public = copy.deepcopy(missions[identifier][0][0]); program = truths[identifier]['expected_program']; col = program['vendor']['column']
        public['headers'][public['headers'].index(col)] = 'UNAPPROVED_HEADER_' + str(offset)
        probes.append({'id': 'B' + f'{len(probes) + 1:02d}', 'category': 'schema-drift', 'stage': 'production', 'mission': public,
            'program': program, 'expected': 'REFUSE', 'reason': 'A required bound column is absent after a changed input header.'})
    for offset, identifier in enumerate(['H21', 'H22', 'H23', 'H24']):
        public = copy.deepcopy(missions[identifier][0][0]); program = truths[identifier]['expected_program']
        field = 'currency' if offset < 2 else 'item'; col = public['headers'].index(program[field]['column'])
        public['rows'][0][col] = 'JPY' if offset < 2 else 'UNKNOWN-ITEM'
        probes.append({'id': 'B' + f'{len(probes) + 1:02d}', 'category': 'unsupported-semantic-identity', 'stage': 'production', 'mission': public,
            'program': program, 'expected': 'REFUSE', 'reason': 'Currency has no declared conversion or item is absent from mission context.'})
    return probes

def main():
    all_tasks = {}; all_truth = {}; all_missions = {}
    count = 0
    for family in FAMILIES[:3]:
        for i in range(4):
            count += 1; public, truth = task('development', family, i, count)
            write('development/' + public['id'] + '.task.json', public)
            write('development/' + public['id'] + '.labels.json', {'id': public['id'], 'labels': truth['labels']})
            write('sealed/development-specs/' + public['id'] + '.truth.json', truth)
            example, expected = mission(public['id'], truth['configuration'], 0)
            write('development/' + public['id'] + '.mission.json', example)
            write('development/' + public['id'] + '.expected.json', expected)
    count = 0
    for family in FAMILIES:
        for i in range(4):
            count += 1; public, truth = task('confirmation', family, i, count); identifier = public['id']
            all_tasks[identifier] = public; all_truth[identifier] = truth; all_missions[identifier] = []
            write('sealed/confirmation/' + identifier + '.task.json', public)
            write('sealed/confirmation/' + identifier + '.truth.json', truth)
            for m in range(4):
                example, expected = mission(identifier, truth['configuration'], m); all_missions[identifier].append((example, expected))
                write('sealed/production/' + example['id'] + '.input.json', example)
                write('sealed/production/' + example['id'] + '.truth.json', expected)
    probes = boundaries(all_tasks, all_truth, all_missions)
    for probe in probes: write('sealed/boundaries/' + probe['id'] + '.json', probe)
    write('DATA_COMMITMENT.json', {'schema': 'next-advantage-data-commitment/v1', 'seed': SEED,
        'development_schemas': 12, 'confirmation_schemas': 24, 'production_missions': 96, 'boundary_probes': 24,
        'pool_rows': 16, 'families': FAMILIES, 'development_families': FAMILIES[:3], 'heldout_only_families': FAMILIES[3:],
        'labels': 'Synthetic worked examples; human labeling duration unknown',
        'preparation_status': 'DATA_FROZEN_BEFORE_CANDIDATE_OUTCOMES', 'custody': 'Procedural same-session separation; shared filesystem, not secure blinding',
        'files': records.copy()})
    print(json.dumps({'files': len(records), 'development_schemas': 12, 'confirmation_schemas': 24, 'production_missions': 96, 'boundaries': len(probes)}))

if __name__ == '__main__': main()
