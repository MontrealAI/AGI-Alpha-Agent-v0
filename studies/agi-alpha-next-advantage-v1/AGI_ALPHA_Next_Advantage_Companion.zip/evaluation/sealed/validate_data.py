import hashlib, json, re, sys
from pathlib import Path
from fractions import Fraction

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from oracle import exact_cart, half_up, FIELDS

OPS = {'item': ['text'], 'vendor': ['text'], 'pack_units': ['integer', 'units-suffix', 'units-prefix'],
    'pack_price_minor': ['minor', 'major-dot', 'major-comma'], 'currency': ['currency'], 'lead_days': ['integer', 'days-suffix', 'weeks-suffix']}

def parse(raw, op):
    value = raw.strip(); number = '(0|[1-9][0-9]*)'
    if op == 'text':
        if not 1 <= len(value) <= 60: raise ValueError('TEXT')
        return value
    if op == 'currency':
        if not re.fullmatch('[A-Za-z]{3}', value): raise ValueError('CURRENCY')
        return value.upper()
    if op in ('integer', 'minor'):
        if not re.fullmatch(number, value): raise ValueError('INTEGER')
        return int(value)
    if op == 'units-prefix': expression = '[xX]' + number
    elif op == 'units-suffix': expression = number + r'\s+(?:unit|units|pack|pcs|pièces)'
    elif op == 'days-suffix': expression = number + r'\s+(?:day|days|jour|jours)'
    elif op == 'weeks-suffix': expression = number + r'\s+(?:week|weeks|semaine|semaines)'
    else:
        separator = '\\.' if op == 'major-dot' else ','
        match = re.fullmatch(r'([$€])?' + number + separator + r'([0-9]{2})(?:\s+([A-Za-z]{3}))?', value)
        if not match or (match[1] and match[4]): raise ValueError('PRICE')
        return int(match[2]) * 100 + int(match[3])
    match = re.fullmatch(expression, value)
    if not match: raise ValueError('UNIT')
    return int(match[1]) * (7 if op == 'weeks-suffix' else 1)

def admissible(raw, op, field):
    result = parse(raw, op)
    bounds = {'pack_units': (1, 10000), 'pack_price_minor': (0, 100000000), 'lead_days': (0, 365)}
    if field in bounds and not bounds[field][0] <= result <= bounds[field][1]: raise ValueError('BOUND')
    return result

def main():
    commitment = json.loads((ROOT / 'DATA_COMMITMENT.json').read_text()); checks = 0
    for file in commitment['files']:
        data = (ROOT / file['path']).read_bytes()
        assert len(data) == file['bytes'] and hashlib.sha256(data).hexdigest() == file['sha256']; checks += 1
    previous_headers = set(); details = []; counts = {'development': 0, 'confirmation': 0}; production_count = 0
    for split, folder in [('development', ROOT / 'sealed/development-specs'), ('confirmation', ROOT / 'sealed/confirmation')]:
        for path in sorted(folder.glob('*.truth.json')):
            truth = json.loads(path.read_text()); identifier = truth['id']
            taskpath = ROOT / ('development/' if split == 'development' else 'sealed/confirmation/') / (identifier + '.task.json')
            task = json.loads(taskpath.read_text()); headers = task['headers']; pool = task['pool']; labels = truth['labels']
            assert 6 <= len(headers) <= 10 and len(set(headers)) == len(headers)
            assert not previous_headers.intersection(headers); previous_headers.update(headers); checks += 3
            assert len(pool) == len(labels) == 16 and all(len(row) == len(headers) for row in pool); checks += 1
            for row, label in zip(pool, labels):
                assert set(label) == set(FIELDS)
                for field, expression in truth['expected_program'].items():
                    actual = admissible(row[headers.index(expression['column'])], expression['op'], field)
                    assert type(actual) is type(label[field]) and actual == label[field]; checks += 1
            unique = {}
            for field in FIELDS:
                survivors = []
                for column in headers:
                    for operation in OPS[field]:
                        try:
                            values = [admissible(row[headers.index(column)], operation, field) for row in pool]
                            if all(type(v) is type(label[field]) and v == label[field] for v, label in zip(values, labels)):
                                survivors.append({'column': column, 'op': operation})
                        except ValueError: pass
                assert survivors == [truth['expected_program'][field]], (identifier, field, survivors)
                unique[field] = len(survivors); checks += 1
            counts[split] += 1; details.append({'id': identifier, 'family': task['family'], 'full_pool_unique': unique})
            if split == 'confirmation':
                for mp in sorted((ROOT / 'sealed/production').glob(identifier + '-*.truth.json')):
                    expected = json.loads(mp.read_text()); mission = json.loads(mp.with_name(mp.name.replace('.truth.', '.input.')).read_text())
                    assert mission['headers'] == headers
                    canonical = expected['canonical']; assert 3 <= len(canonical['items']) <= 6 and len(canonical['shipping_minor']) == 3
                    assert len(mission['rows']) == len(canonical['offers']) == 3 * len(canonical['items'])
                    assert len({(o['item'], o['vendor']) for o in canonical['offers']}) == len(canonical['offers']); checks += 4
                    for raw, offer in zip(mission['rows'], canonical['offers']):
                        for field, expression in truth['expected_program'].items():
                            actual = admissible(raw[headers.index(expression['column'])], expression['op'], field)
                            assert type(actual) is type(offer[field]) and actual == offer[field]; checks += 1
                    result = exact_cart(canonical); assert result['enumerated_carts'] <= 729 and result['total_minor'] >= 0
                    production_count += 1; checks += 2
    probes = [json.loads(p.read_text()) for p in sorted((ROOT / 'sealed/boundaries').glob('*.json'))]
    assert len(probes) == 24 and len({p['id'] for p in probes}) == 24 and all(p['expected'] == 'REFUSE' for p in probes); checks += 3
    for fraction, expected in [(Fraction(0), 0), (Fraction(1, 2), 1), (Fraction(3, 2), 2), (Fraction(49, 100), 0), (Fraction(50, 100), 1), (Fraction(51, 100), 1), (Fraction(7, 3), 2)]:
        assert half_up(fraction) == expected; checks += 1
    report = {'status': 'PASS', 'scope': 'Pre-outcome synthetic dataset/grammar/oracle integrity, not candidate outcomes',
        'checks': checks, 'development_schemas': counts['development'], 'confirmation_schemas': counts['confirmation'],
        'production_missions': production_count, 'boundary_cases': len(probes), 'all_nominal_schemas_unique_after_full_16_label_pool': True,
        'full_pool_is_not_the_8_label_experiment_budget': True, 'headers_globally_disjoint': True,
        'candidate_builder_execution': 'NOT_RUN', 'data_seed_selection': 'One declared seed, no outcome-driven selection',
        'quote_oracle': 'Independent Python cart enumeration; exact rational half-up arithmetic; no candidate/JS solver import',
        'commitment_sha256': hashlib.sha256((ROOT / 'DATA_COMMITMENT.json').read_bytes()).hexdigest()}
    (ROOT / 'DATA_VALIDATION.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    (ROOT / 'sealed/data-validation-details.json').write_text(json.dumps(details, indent=2, sort_keys=True) + '\n')
    print(json.dumps(report))

if __name__ == '__main__': main()
