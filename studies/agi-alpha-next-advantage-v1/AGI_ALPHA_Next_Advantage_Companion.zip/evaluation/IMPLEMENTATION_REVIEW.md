# Prospective implementation review

Same-session evaluator review before confirmation freeze. No held-out candidate
or production outcomes were inspected or executed. No candidate builder was
written by this evaluator. Development results remain exploratory.

## Reviewed source identities

| File | SHA-256 |
|---|---|
| `implementation/synthesis.mjs` | `dfc6196d6458b8416d9b21a2ca6c255e734c75c81310d87de7c256c3ccd7c1bc` |
| `implementation/delivery.mjs` | `c78c18d8d895297f6beafbc34fd8f77ddf3a942cd444a1e31d69eb254572938f` |
| `implementation/run.mjs` | `2c4b7df74f0cc6c8c49340e8bef6902b922795258b2eb192f140d25cc14bafbb` |
| `protocol/INTERFACE.md` | `badf8eebdf199aee4175edc81e6989d131be28510904e60246f64a772c4390ab` |

## Concrete corrections required before freeze

1. **Confirmation paths are wrong.** The runner currently scans the immediate
   `evaluation/sealed/` directory, expects `.labels.json`, and expects `.mission.json`.
   Actual paths are `sealed/confirmation/Hnn.task.json`,
   `sealed/confirmation/Hnn.truth.json` with `.labels`, and
   `sealed/production/Hnn-Mm.input.json`. Expected answers are in the corresponding
   `Hnn-Mm.truth.json`, field `.canonical`; the builder must never receive them.
   This is a filename-routing correction, not a dataset change.
2. **Existing confirmation outputs can be overwritten.** `save()` writes a fixed
   temporary filename and renames over the destination. Reject an occupied
   `results/<runName>` before running confirmation, and use a fresh run name for
   repetition. Preserve prior development epochs when rebuilding after a source
   correction. This protects evidence rather than changing an acceptance result.
3. **Money grammar currently accepts both affixes.** A direct primitive probe
   shows `$12.34 USD` and `€12,34 EUR` are accepted. The declared grammar describes
   an optional leading symbol **or** trailing currency, and the independent
   evaluator treats simultaneous affixes as outside that syntax. Reject simultaneous
   affixes in `moneyCore`, or explicitly amend the grammar prospectively before
   freeze. The data does not rely on simultaneous affixes. Ordinary `$12.34`
   and `12.34 USD` both remain valid.
4. **The protocol's split sentence is stale.** Record 12 development schemas in
   the first three families, four each; 24 confirmation schemas in all six,
   four each, with three held-out structural compositions. No data change is needed.

## No observed answer leakage in the reviewed builder

The synthesis function receives only the raw construction task and a callable row
label oracle. It enumerates the same typed column/operation space for all arms;
the label is used only after an explicit oracle call. Confirmation expected
canonical offers and optimal baskets do not enter `synthesize` or `deriveRecipe`.
The retained recipe derives weights from development trace ambiguity, not manually
selected held-out mappings. Cache keys depend on schema headers, raw pool and
grammar version; they do not cache a mission answer. Failed cached constructions
remain refusals. The rebuild arm intentionally repeats construction and is clearly
an ablation; ordinary reusable scripts and active selection remain strong controls.

The runner loads full labels in its trusted evaluation host but passes them to
the builder only through a closure. This is procedural API separation within
one process, not a secure isolated oracle. The LLM comparator needs an equally
bounded logged oracle and must not read these ground-truth files directly.

## Scope and fairness qualifications to retain

- Initial type checking examines the full **unlabeled** 16-row pool. This is
  legitimate information supplied equally to every deterministic arm. The actual
  eight-label limit remains separate.
- `selectionOperations` is recorded but is not included in the candidate-evaluation
  ceiling. Report both and include measured selection CPU in construction cost;
  do not describe a candidate-count limit as a strict equal CPU envelope.
- Recipe cost must include all development construction calls and its derivation,
  not only emitting the final weight JSON. The current development summary charges
  the 12 construction calls, 31 labels and derivation CPU; original model-assisted
  infrastructure authoring and future maintenance remain unknown.
- `sourceIdentity()` hashes the source-manifest file but does not itself verify
  each vendored body. The prospective `FREEZE.json` must include actual vendor
  implementation bodies (or verify every manifest leaf) as well as the manifest,
  dataset commitment, recipe, protocol and evaluator source.
- The local algorithmic cross-check intentionally shares prepared inputs and
  cannot detect a wrong schema mapping. Its label correctly says this. Independent
  canonical truth must decide complete acceptance.
- `validateTable`/`validateProgram` are used on parsed local JSON here, not arbitrary
  JavaScript object graphs. Do not generalize this bounded research validator into
  a security-qualified imported-program service.
- The implementation rejects interior ASCII control characters in text and
  accepts unit suffixes case-insensitively. Clarify those finite grammar details
  prospectively; no current dataset depends on the difference.

## Independent acceptance API

From Python, using the file `evaluation/oracle.py`:

```python
truth = json.loads(Path('evaluation/sealed/production/H01-M1.truth.json').read_text())
pack = json.loads(Path('results/RUN/packs/ARM-H01-M1.json').read_text())
report = verify_pack(truth['canonical'], pack)
```

Also compare the actual prepared-offers artifact to exact target offers:

```python
prepared = json.loads(next(a['content'] for a in pack['result']['artifacts'] if a['name'] == 'prepared-offers.json'))
findings = verify_canonical(truth['canonical']['offers'], prepared)
accepted = report['accepted'] and not findings
```

The CLI expects a **canonical mission object**, not the surrounding `.truth.json`:
`python evaluation/oracle.py CANONICAL.json PACK.json`. The callable API avoids an
unnecessary intermediate file. Full reports preserve every finding and per-case
acceptance; do not count `DELIVERED_PENDING_INDEPENDENT_CHECK` as accepted work.

## Boundary runner interface, usable only after freeze

Each `evaluation/sealed/boundaries/Bnn.json` contains `id`, `category`, `stage`,
`expected:'REFUSE'` and a reason. Construction controls contain `.task` and `.labels`;
call the same `synthesize` with its ordinary eight-label limit. Production controls
contain `.mission` and a bare `.program` field map. Wrap the map in
`{schema:'alpha-example-adapter/v1', headers: ORIGINAL_SCHEMA_HEADERS, fields: probe.program}`
and invoke the normal preparation/delivery path. Original schema headers come
from `sealed/confirmation/<mission.schema_id>.task.json`; do not redefine the
contract from drifted boundary headers. A successful delivery on a registered
refusal probe is a failed control, not accepted work. These are 24 unique boundary
probes, regardless of repetition across arms. Fixed-interpreter probes do not
constitute 24 new customer jobs or protection against arbitrary semantic drift.

## Decision

The design has a concrete existing-system connection and no observed held-out
answer path in the reviewed deterministic constructor. Finish the four stated
pre-freeze corrections, include the complete source/data freeze, then proceed
without tuning on confirmation outcomes. This review is not external blinded
review, operational Security clearance or production acceptance.
