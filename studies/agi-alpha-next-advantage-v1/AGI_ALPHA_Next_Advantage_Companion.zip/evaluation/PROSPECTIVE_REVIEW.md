# Independent data and acceptance review

Status: prospective design review before candidate construction or confirmation outcomes.
Owner: same-session sibling evaluator; separate code/data custody from the builder author,
not organizationally independent review or a secure blinded evaluation service.

## Intended experiment

The existing Alpha Workbench remains the execution wrapper and the existing AWE
quote normalizer and vendor-subset solver remain unchanged. The new object of study
is deriving a bounded input transformation from paired examples: heterogeneous raw
vendor tables become the exact canonical offer schema required by those components.
The complete customer deliverable is a checked quote comparison, recommended cart,
CSV and source-to-output provenance. Schema reconstruction alone is not acceptance.

The data owner constructs 12 excluded development schemas in the first three
declared families (four each), and 24 fresh confirmation construction schemas in
six declared structural families (four each). Each fresh
schema has four independent production missions, giving 96 unique fresh missions.
Every mission has three to six items and three synthetic suppliers. Amounts, supplier
names, demand and formats are synthetic; none are customer observations. Matched
repetition across comparators does not increase independent task breadth.

Held-out schemas use different header names and formatting configurations from
development. The finite grammar is public and fixed before generation. Sharing
primitive operations is legitimate transfer within the grammar, not generalization
to an unconstrained data-cleaning language. Weekly lead-time formatting, affixed
currency prices and mixed alternative views occur only in confirmation. The
paper may describe these as unseen structural compositions/families within the
fully declared grammar; it must not imply new primitive invention.

## Leakage controls

1. The builder sees raw construction rows and may request canonical row labels
   only through the budgeted, logged label oracle. Every arm receives identical
   permitted information and query limits.
2. Fresh production rows and their canonical answers are not part of the label
   pool. No fresh production failure may trigger a construction label or candidate
   revision in the frozen primary experiment.
3. `evaluation/sealed/` holds ground truth, generation recipes and fresh inputs
   until the source/protocol freeze. The evaluator exports hashes and counts first.
   This is procedural separation in a shared filesystem, not cryptographic access
   isolation; all files become inspectable in the final companion.
4. Candidate source, admitted schema programs, query traces and the prespecified
   decision must be frozen before the fresh missions are exposed to execution.
5. All schema IDs, failed construction/refusals, labels requested, candidate checks,
   and all 96 mission outcomes remain in the report. No retrospective favorable
   family selection or replacement of a difficult input is permitted.

## Semantic acceptance

The evaluator does not import the candidate builder or the existing JavaScript
quote solver. A separate Python oracle checks all canonical fields and enumerates
every cart (at most 3^6 supplier choices for nominal missions). It independently
computes required pack counts, rational currency conversion, delivery eligibility,
once-per-used-supplier shipping and minimal total. Currency conversion follows the
existing AWE half-up integer-minor-unit contract; it is not a ceiling or floating
point approximation. Tied optimal carts are acceptable if all constraints and the
optimal total hold; identical tie-breaking is not required.

An accepted mission requires:

- Every emitted offer matches its held-out canonical target in all six fields,
  with no dropped, duplicated or silently re-keyed row.
- All intended items/suppliers are represented as declared; original raw row
  identities and exact normalization provenance are inspectable.
- The actual existing Workbench path runs and its integrity-bound artifact pack
  is produced; pack inspection alone is insufficient semantic acceptance.
- The selected cart is feasible and independently optimal within the declared
  fixed-shipping quote model; totals, CSV and report agree.
- Refused/unknown inputs cannot be represented as accepted or clean results.

Synthesis or mission refusal is a visible coverage failure for nominal cases.
For registered unsafe/ambiguous boundary cases, refusal is the intended outcome
and counts in a separate safety-boundary table, not as additional delivered work.
No tolerance is allowed for wrong accepted canonical values or monetary totals.

## Boundary probes

The separate 24-case boundary set should include ambiguous source columns,
conflicting currency evidence, item-identity collisions, invalid or unsupported
number/format syntax, and out-of-range/unknown-key conditions. A learner that cannot
identify a unique supported mapping must refuse or explicitly request permitted
additional labels within its existing budget. It cannot silently guess a mapping
that happens to work on the revealed fresh target. These probes measure the stated
finite boundary only; they do not constitute universal adversarial assurance.

## Comparators and economic claims

The same-format ordinary saved script receives legitimate reuse opportunities.
The equally resourced builder receives the same grammar, raw examples, labels and
verification standard. A conventional information-gain learner is an appropriate
strong comparator. An existing specialist supplied the correct canonical data
measures the value of the solver, but its input-normalization labor cannot be
treated as free when comparing complete delivery workflows.

Report useful accepted outputs, wrong acceptances, refusals, queries, construction
CPU/wall, whole-delivery CPU/wall, checker work, retained-program size and failures.
Primitive evaluation counts are computational measurements, not dollars. Actual
provider billing, authored infrastructure labor, future maintenance and customer
attention remain unknown unless measured or explicitly modeled. Builder improvement
requires fresh construction problems and equal-resource comparisons; one faster
cached production mission does not establish it. No sustained acceleration can be
inferred from a single successful succession.

## Prospective interface amendment

The root supplied `protocol/INTERFACE.md` before generation: 16 raw construction
rows, eight canonical-label queries, a 200,000 candidate-evaluation ceiling,
exact column/operation programs and six canonical fields. Before any outcomes,
the split was refined to reserve three structural families for confirmation.
This amendment changes the design prospectively; it does not replace a result.

The data generator and `DATA_COMMITMENT.json` record one deterministic generation.
There is no selection across seeds based on builder performance. Synthetic
exchange ratios are explicit scenario data, not sourced market exchange rates.
Dollar signs are used only with USD and euro signs only with EUR. CAD uses bare
numeric prices or explicit currency-code suffixes. Decoy column correlations
and pool order are deterministically randomized, with no privileged first row.

Registered primary comparisons and uncertainty treatment remain the root
protocol owner's responsibility. Development outcomes must not alter the
sealed confirmation data or their acceptance standard.

No experimental result is present in this review.
