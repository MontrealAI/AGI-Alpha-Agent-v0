"""Project only the two publication download URLs through the existing builder.

The frozen offline HTML, data, sources and build manifest are never written.
The existing builder runs from byte-identical copies in temporary storage so
its manifest side effect cannot alter the offline edition.
"""
import hashlib
import importlib.util
import json
import re
import shutil
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
DEMO = ROOT / "demonstration"
EXPECTED_OFFLINE = "eb1b24bc1b9b904bdd2b32e8595fe1efcebe36957660240eae6d73d9d7d0c1a9"
URLS = {
    "paper": "https://raw.githubusercontent.com/MontrealAI/AGI-Alpha-Agent-v0/ae37ea705b0df5e806b0553ada27c4cedba58c94/docs/papers/agi-alpha-next-advantage-v1.pdf",
    "companion": "https://raw.githubusercontent.com/MontrealAI/AGI-Alpha-Agent-v0/research/next-advantage-companion-v1/studies/agi-alpha-next-advantage-v1/AGI_ALPHA_Next_Advantage_Companion.zip",
}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def embedded(html):
    match = re.search(r'(<script id="research-data" type="application/json">)(.*?)(</script>)', html, re.S)
    if not match:
        raise AssertionError("Expected embedded research data not found")
    return json.loads(match[2]), html[:match.start(2)] + "__EMBEDDED_DATA__" + html[match.end(2):]


def main():
    offline = DEMO / "AGI_ALPHA_Build_the_Next_Advantage.html"
    original_data = DEMO / "demo_data.json"
    source_names = ["index.template.html", "style.css", "app.js", "runtime_bundle.js", "build_demo.py"]
    protected = [offline, original_data, DEMO / "build-manifest.json"] + [DEMO / name for name in source_names]
    before = {str(path.relative_to(ROOT)): sha(path) for path in protected}
    assert sha(offline) == EXPECTED_OFFLINE, "Offline edition no longer matches the authorized hash"
    data = json.loads(original_data.read_text())
    changes = [{"path": "/links/" + key, "before": data["links"][key], "after": value} for key, value in URLS.items()]
    data["links"] = URLS
    hosted_data = HERE / "demo_data.json"
    hosted_data.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")
    output = HERE / "index.html"

    with tempfile.TemporaryDirectory(prefix="next-advantage-hosted-") as temporary:
        stage = Path(temporary)
        stage_demo = stage / "demonstration"
        stage_hosted = stage / "publication" / "hosted-demo"
        stage_demo.mkdir()
        stage_hosted.mkdir(parents=True)
        for name in source_names:
            shutil.copyfile(DEMO / name, stage_demo / name)
        shutil.copyfile(hosted_data, stage_hosted / hosted_data.name)
        spec = importlib.util.spec_from_file_location("existing_demo_builder", stage_demo / "build_demo.py")
        builder = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(builder)
        manifest = builder.build(stage_hosted / hosted_data.name, stage_demo / "runtime_bundle.js", stage_hosted / "index.html")
        shutil.copyfile(stage_hosted / "index.html", output)
    manifest["output"] = str(output)
    (HERE / "build-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")

    original = json.loads(original_data.read_text())
    projected = json.loads(hosted_data.read_text())
    projected["links"] = original["links"]
    assert projected == original, "Projection changed something other than download links"
    old_embedded, old_body = embedded(offline.read_text())
    new_embedded, new_body = embedded(output.read_text())
    assert old_body == new_body, "Template, style, runtime or application changed"
    old_source_hash = old_embedded.pop("sourceHash")
    new_source_hash = new_embedded.pop("sourceHash")
    new_embedded["links"] = old_embedded["links"]
    assert old_embedded == new_embedded, "Embedded evidence or research changed"
    after = {str(path.relative_to(ROOT)): sha(path) for path in protected}
    assert before == after, "A protected offline file was changed"
    receipt = {
        "kind": "hosted-download-link-projection-v1",
        "publicationStatus": "GitHub draft source publication; no website or live deployment claim",
        "changes": changes,
        "onlySemanticDataChanges": ["/links/paper", "/links/companion"],
        "derivedMetadataChange": {"sourceHash": {"offline": old_source_hash, "hosted": new_source_hash}},
        "checks": {
            "offlineHtmlExactAuthorizedSha256": True,
            "allProtectedOfflineFilesUnchanged": True,
            "dataIdenticalExceptTwoDownloadLinks": True,
            "htmlIdenticalExceptEmbeddedDataAndDerivedSourceHash": True,
            "templateCssRuntimeAndApplicationByteIdentical": True,
            "externalUrlsAreUserClickedDownloadsOnly": True,
        },
        "protectedOfflineFiles": before,
        "hostedFiles": {name: {"sha256": sha(HERE / name), "bytes": (HERE / name).stat().st_size} for name in ["index.html", "demo_data.json", "build-manifest.json", "build_hosted.py"]},
        "browserValidation": "NOT RUN; original Chromium socket EPERM restriction preserved",
        "downloadUrlAvailability": "NOT VERIFIED by this projection; supplied publication destinations only",
        "installedAuthenticatedExecution": "NOT RUN",
        "persistentOperation": "NOT RUN",
        "publicWebsiteDeployment": "NOT RUN",
    }
    (HERE / "PROJECTION_RECEIPT.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"output": str(output), "sha256": sha(output), "bytes": output.stat().st_size, "data_sha256": sha(hosted_data), "receipt_sha256": sha(HERE / "PROJECTION_RECEIPT.json"), "offline_sha256": sha(offline)}, indent=2))


if __name__ == "__main__":
    main()
