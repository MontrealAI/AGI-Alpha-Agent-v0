// Link-binding QA using the existing Node DOM shim. This is not a browser test.
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '../../demonstration');
const source = fs.readFileSync(path.join(root, 'qa_static_runtime.cjs'), 'utf8');
const prefix = source.slice(0, source.indexOf('(async()=>{'));
if (!prefix || prefix === source) throw Error('Existing DOM-shim entry point not found');
const checks = `
const hostedDir=path.resolve(root,'../publication/hosted-demo');
const hostedHtml=fs.readFileSync(path.join(hostedDir,'index.html'),'utf8');
const embedded=JSON.parse(hostedHtml.match(/<script id="research-data" type="application\\/json">([\\s\\S]*?)<\\/script>/)[1]);
const passed=[];
for(const language of ['en','fr']){
  context.NEXT_ADVANTAGE_UI.setLanguage(language);
  for(const [key,id] of [['paper','paper-link'],['companion','companion-link']]){
    assert.equal(byId[id].href,embedded.links[key]);
    assert.ok(byId[id].href.startsWith('https://raw.githubusercontent.com/MontrealAI/AGI-Alpha-Agent-v0/'));
    passed.push(language+' '+key+' user-clicked download resolves to supplied publication URL');
  }
}
assert.equal(Object.keys(data.links).length,2);
passed.push('Exactly two publication download destinations');
assert.equal(embedded.examples.length,3);
passed.push('All original examples preserved');
const result={scope:'Node DOM-shim link assignment only; no browser, website deployment, URL availability or authenticated runtime test',checksPassed:passed.length,checks:passed,primaryCustomerDeliveriesAdded:0,htmlSha256:crypto.createHash('sha256').update(hostedHtml).digest('hex'),dataSha256:crypto.createHash('sha256').update(fs.readFileSync(dataPath)).digest('hex'),browser:'NOT RUN; original socket EPERM restriction preserved'};
fs.writeFileSync(path.join(hostedDir,'LINK_QA.json'),JSON.stringify(result,null,2)+'\\n');
console.log(JSON.stringify(result,null,2));
`;
new Function('require', '__dirname', 'process', prefix + checks)(require, root, {argv: ['node', __filename, path.join(__dirname, 'demo_data.json')]});
