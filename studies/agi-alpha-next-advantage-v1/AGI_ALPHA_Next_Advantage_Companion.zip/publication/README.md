# Publication scope and preservation

This is a new immutable research edition, `agi-alpha-next-advantage-v1`. It uses the repository's existing `scripts.research_papers` import/check workflow. The paper lane contains the original PDF, its TeX, the catalog record and existing generated publication views; the software/demo companion remains a separate review lane.

The package's technical evidence is complete and preserved. At package assembly, publication is a review handoff, not a live-site claim. The existing integration/publisher owner retains reconciliation, merge, release and served-byte verification. Source assurance, official security, original Harness/Fleet reviews and authenticated execution gates retain their existing decisions and owners.

No previous paper, source artifact, result, URL, tag, deployed contract or release archive is replaced. No real transaction, credential, service installation or persistent access is created. A public GitHub draft/source link is not evidence that the website or enterprise is live.

The final coordination handoff records exact PR/commit URLs and public source-byte checks. It may be distributed separately from this content-addressed research archive to avoid circular archive/commit hashes.
