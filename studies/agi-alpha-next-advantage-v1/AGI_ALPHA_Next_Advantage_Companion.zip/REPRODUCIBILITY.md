# Reproduce the local study

Run this command from the package root, choosing an absolute output directory
that does not exist:

```sh
python3 reproduce.py --output /absolute/path/to/new-reproduction
```

The command refuses an existing output directory. It preserves the original
source, frozen data, learned recipe, primary results, and comparator evidence.
All new executions and logs stay under the requested directory. It exits zero
only after the fresh results pass independent checks and match the preserved
programs, logical counts, and semantic outcomes.

The recorded execution receipt is
`evidence/REPRODUCTION_VALIDATION.json`. Each new invocation also produces its
own `REPRODUCTION_VALIDATION.json`, `commands.json`, runtime `environment.json`,
and per-command stdout/stderr logs under its output directory. A failure leaves
its directory and error receipt intact; choose a new output path for a later
attempt.

The v1 receipt is preserved as `evidence/REPRODUCTION_VALIDATION-v1.json`, with
its prior wrapper and instructions under `evidence/reproduction-v1/`. Revision 2
adds fresh development synthesis and recipe derivation to the same reproduction
workflow; it does not change the frozen study or replace its historical costs.

## Dependencies

`environment.json` records the reference environment and dependency scope.
The completed package uses **Python 3.12.14** and **Node v24.22.1** on Linux.
The computational reproduction needs only Python and Node standard libraries
plus the JavaScript source already vendored in this package. No pip or npm
installation, browser, Docker daemon, model service, network connection, or API
credential is required.

The wrapper checks Python 3.10+ and Node 20+ with global Web Crypto,
`structuredClone`, and `performance`; the reference versions above are the
tested combination. The upstream vendored project's broader contributor guide
recommends Python 3.11–3.13. Use a POSIX platform such as Linux or macOS because
the frozen comparator imports Python's `resource` module. Both `node` and
`python3` must be on `PATH`: the unchanged JavaScript runners invoke `python3`
for their independent checks. The wrapper records that child interpreter as
well as its own interpreter.

The larger upstream framework's optional packages and deployment dependencies
are outside this reproduction's import and execution paths. This command does
not launch that framework or build the presentation, paper, or browser demo.

## What the command executes

1. Verify all **371 primary freeze entries**, all **187 comparator artifact
   entries**, and its **50 permitted-input entries** against their SHA-256
   digests. Hash mismatches stop the run before construction.
2. Copy the union of those manifests plus an explicit list of runners,
   dependency records, and three historical development summaries into
   `OUTPUT/workspace`. This selection excludes the output tree itself, the
   paper, the demonstration, and old generated confirmation/economic outputs.
3. Snapshot the preserved reference outcomes and programs into
   `OUTPUT/reference`. For the 480 original packs, retain hashes of complete
   semantic projections rather than duplicating their large time-bound wrappers.
4. Run the finite-grammar controls and the frozen economic protocol check.
5. Run the frozen generic synthesizer independently on all 12 public development
   schemas, then call `deriveRecipe` on those new traces. Compare complete
   programs and logical traces against the preserved development constructions,
   require 31 labels and 5,499 candidate evaluations, and compare the entire
   derived recipe body with the frozen recipe. Write this additive replay under
   `results/development-replay-v2`; never overwrite `learned-recipe.json`.
6. Reconstruct and execute all four deterministic arms on the same 24 schemas
   and 96 missions per arm, including their unchanged Python acceptance checks.
7. Rerun the analysis, including the fixed-seed, family-stratified paired
   bootstrap. Historical development costs remain its recorded inputs. The fresh
   replay verifies recipe construction without substituting new timings into
   historical accounting.
8. Execute the frozen current-session LLM programs on the same 96 missions,
   including fresh Python acceptance checks.
9. Run all 24 boundary probes across the three deterministic strategies,
   producing 72 probe evaluations, and rerun the three-pack connected-loop
   demonstration.
10. Rerun the frozen four-arm economic analyzer, its independent Python rational
   arithmetic audit, and the additive resource-reporting correction.
11. Replay the frozen LLM constructor executable using only its 29 recorded
    labels. Write separate replay evidence outside the frozen comparator run
    directories. Make no new label-oracle request and verify that the recorded
    oracle-event ledger remains byte-identical.
12. Run the unchanged final independent audit against the newly generated
    outputs. Compare logical results against the reference snapshot, recheck
    frozen source hashes, and verify that every original input and evidence file
    read by the wrapper remains unchanged.

The original `agent-baseline/reproduce.py` is preserved but not invoked: it
would try to recreate the already-frozen `runs/replay01` directory. The root
wrapper instead instantiates the frozen constructor with a recorded-label
callback and writes to `OUTPUT/recorded-label-replay`.

## What must match

The comparison retains complete derived programs, candidate traces, queried
rows, logical counters, refusals, qualification decisions, independent
acceptance, exact quote totals, and all report/cart/analysis artifact bodies
and digests. It also checks the unchanged source and grammar identities,
per-schema comparisons, paired intervals, connected-loop program and ledgers,
economic A/B/C conclusions, costs, financing paths, and preserved unknown
actual monetary quantities.

The expected scoped outcomes are:

| Arm | Missions accepted | Constructions | Label queries | Candidate evaluations | Selection operations |
|---|---:|---:|---:|---:|---:|
| Rebuild | 96 | 96 | 244 | 44,420 | 0 |
| Ordinary reuse | 96 | 24 | 61 | 11,105 | 0 |
| Retained | 96 | 24 | 29 | 10,866 | 9,053 |
| Active specialist | 96 | 24 | 29 | 10,866 | 9,053 |
| Frozen current LLM programs | 96 | 24 recorded | 29 recorded | 38,591 recorded | 37,272 recorded |

The LLM evaluation counter includes 36,288 original parse attempts and 2,303
original candidate-to-label comparisons. Its saved-label replay reproduces the
same logical acquisition counts without reacquiring labels. These five arms
share 96 unique jobs; they are not 480 independent jobs.

The independent economic audit should repeat 5,118 assertions over 12 cost
rows and 30 hypothetical finance paths. The boundary suite should repeat 72
passes from 24 unique probes.

The development replay derives these recipe weights from new traces:

| Field | Unresolved-alternative evidence count | Derived weight |
|---|---:|---:|
| `item` | 9 | 5 |
| `vendor` | 0 | 1 |
| `pack_units` | 3 | 2 |
| `pack_price_minor` | 15 | 8 |
| `currency` | 0 | 1 |
| `lead_days` | 0 | 1 |

Its 31 development label selections are replay work, not a new independent
training episode or a replacement for the recorded 93 engineering-validation
queries across three historical executions. The historical recipe provenance
contains an earlier source identity and a trace hash that includes measured wall
time. Those historical metadata are preserved. The new replay records its own
source and trace identities and compares complete logical traces plus the full
derived recipe body, excluding only the historical provenance attachment.

## What is deliberately remeasured or remains unreproduced

CPU and wall time are host-dependent measurements. The wrapper retains fresh
measurements but does not require them to match the original timings.
Creation timestamps change work-order expiry times and their compilation and
integrity digests. The unchanged runtime validates those new bindings; the
reference comparison retains the complete semantic result and frozen authority
fields. It does not discard meaningful limits such as `budget.maxDurationMs`.

This is a computational replay of the fixed synthetic study. It supplies no
new independently sampled mission, market evidence, matched human duration,
provider bill, customer collection, or external peer review. It does **not**
reproduce the LLM's model inference, interactive source authoring, or initial
oracle acquisition. The original same-session construction and access
limitations remain documented in `agent-baseline/PROVENANCE.md`.

The economic replay uses the original four deterministic arms to preserve its
recorded scope. The LLM remains included in the separate technical comparison;
its unobserved model billing is not filled with zero or inferred from CLI CPU.
No deployment, authenticated service, payment, purchase, or publishing occurs.
