# SPDX-License-Identifier: Apache-2.0
"""Generate manuscript tables from the unchanged, independently audited outputs."""
from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PAPER = ROOT / "paper"
OUT = PAPER / "generated"
OUT.mkdir(exist_ok=True)
RESULT = ROOT / "outputs/run-001/results.json"
data = json.loads(RESULT.read_text())
audit = json.loads((ROOT / "evaluation/INDEPENDENT_AUDIT.json").read_text())
assert audit["status"] == "PASS" and not audit["failures"]
assert hashlib.sha256(RESULT.read_bytes()).hexdigest() == audit["results_sha256"]
freeze = json.loads((ROOT / "FREEZE.json").read_text())
for item in freeze["files"]:
    assert hashlib.sha256((ROOT / item["path"]).read_bytes()).hexdigest() == item["sha256"]
inputs = json.loads((ROOT / "inputs.json").read_text())
cores = {(r["price_basis"], r["scenario"]): r for r in data["core_scenarios"]}
base = cores["US_office", "base"]
summary = list(csv.DictReader((ROOT / "outputs/run-001/results_summary.csv").open()))


def n(value, digits=2):
    return "--" if value is None else f"{float(value):,.{digits}f}"


def money(value):
    return r"\$" + n(value)


def put(name, text):
    (OUT / name).write_text(text.strip() + "\n")


def comp(row, minutes=30):
    return next(x for x in row["traditional_comparisons"] if x["productive_minutes"] == minutes)


def summ(basis, scenario, minutes=30):
    return next(x for x in summary if x["price_basis"] == basis and x["scenario"] == scenario
                and float(x["productive_human_minutes_assumed"]) == minutes)


human30 = comp(base)["traditional"]
hybrid30 = comp(base)["hybrid"]
ca = base["capacity"]["feasible_admitted_cohort"]
ch = human30["capacity"]["feasible_admitted_cohort"]
cy = hybrid30["capacity"]["feasible_admitted_cohort"]
put("abstract_results.tex", rf"""
In the base U.S. office-work case, the declared 1,000-request allocation costs
{money(base['declared_demand_cost_per_expected_accepted'])} per expected accepted
Agent output, versus {money(human30['annual_at_demand']['cost_per_expected_accepted'])}
for an assumed 30-minute traditional production task with its ancillary work.
That volume exceeds the example \$25,000 resource budget. At the aggregate
expected-use admission limits, costs are {money(ca['cost_per_expected_accepted'])}
for Agent-accepted work, {money(ch['cost_per_expected_accepted'])} for traditional
completion and {money(cy['cost_per_expected_accepted'])} for complete-demand
human fallback. These are planning ceilings with unvalidated daily scheduling,
not hard stochastic budget guarantees. Conservative and stress cases cannot fund
their fixed resource commitments within the stated budget.
""")

put("freeze.tex", r"""
The 16-file economic freeze was created at 13:29:21.657977 UTC on 25 October 2026.
Its public source commit is
\artifact{4d1d2af3e77a5346e3dc1a574f509d5c67c0aef7}; the
\href{https://github.com/MontrealAI/AGI-Alpha-Agent-v0/issues/4850#issuecomment-6398263719}{public prospective notice}
preceded the 13:30:40 UTC authorization to calculate. Independent pre-calculation
review passed 61 specification, identity and source checks. Manifest SHA-256:
\begin{center}\artifact{54bc70fec9bb635b473193d966d36ed5bf445460a58255f025cbed4a30854d8b}\end{center}
The actual native outcomes were already known. The amendment therefore cannot
serve as a preregistration of those outcomes, and it is not described as one.
""")

scenario_order = ["base", "conservative", "stress"]
rows = []
parameters = [
    ("Requested jobs in annual illustration", lambda s: s["requested_demand"], 0),
    ("Delivery token multiplier", lambda s: s["delivery_multipliers"]["model_tokens"], 1),
    ("Delivery human-effort multiplier", lambda s: s["delivery_multipliers"]["human_minutes"], 1),
    ("Executor occupancy multiplier", lambda s: s["delivery_multipliers"]["executor_occupancy"], 1),
    ("External-wait multiplier", lambda s: s["delivery_multipliers"]["external_wait"], 1),
    ("Initial provider engineering hours", lambda s: sum(s["initial_provider_hours"].values()), 0),
    ("Recurring provider hours per month", lambda s: sum(s["monthly_provider_hours"].values()), 0),
    ("Initial employer onboarding hours", lambda s: sum(s["initial_employer_hours"].values()), 0),
    ("Employer governance hours per month", lambda s: sum(s["monthly_employer_hours"].values()), 0),
    ("Assumed setup workdays", lambda s: s["setup_elapsed_workdays"], 0),
    ("Available-resource utilization", lambda s: s["resource_utilization"], 2),
]
for label, getter, digits in parameters:
    rows.append(label + " & " + " & ".join(n(getter(inputs['scenarios'][s]), digits) for s in scenario_order) + r" \\")
put("inputs.tex", r"""
\subsection{Published price basis and explicit planning budgets}

The primary administrative-brief comparator is U.S. private-industry office and
administrative compensation of \$35.96 per hour in December 2025, comprising
\$24.79 in wages and \$11.17 in benefits. Provider engineering/support uses
professional compensation of \$72.19, comprising \$50.10 in wages and \$22.09 in
benefits. Neither is a contractor quote or a matched worker observation.\cite{blsecec}
Ontario technical writers have a CAD\,34.98 hourly median in the 2023--2024
Labour Force Survey, published through Job Bank; the 1.30 employer multiplier
is assumed. The EU example uses EUR\,34.90 covered-economy employer cost for 2025,
which is not an occupation-matched wage.\cite{jobbank,eurostat}

All four price bases across three geographies retain their scope differences.
USD technology/provider costs are nominally translated using 23 October 2026
ECB references: EUR\,1 = USD\,1.1193 and CAD\,1.5665. These are reference
conversions, not purchasing-power parity or local cloud-SKU invoices.\cite{ecb}
Mixed labor-price vintages remain visible; no undisclosed wage-growth adjustment
turns them into 2026 wage observations.

The hypothetical first-party Sonnet 5.5 route costs \$2 per million input tokens
and \$10 per million output tokens; Opus 5.5 costs \$4 and \$20. Successful search
is \$10 per thousand uses. Declared token totals include context, tool/history
and generated reasoning. No cache, batch or free-tier discount is claimed.\cite{anthropic}
Cloud Run request-billed Iowa rates are \$0.000024 per allocated vCPU-second,
\$0.0000025 per GiB-second and \$0.40 per million requests, with 100-ms rounding.
The assumed executor has two separate one-vCPU, two-GiB instances with one
request per instance. Standard regional storage is \$0.000027397 per GiB-hour;
operations/egress have explicit separate allowances.\cite{cloudrun,cloudstorage}
All prices were retrieved on 25 October 2026. No provider was called or deployed
to validate the assumed usage, latency or quality.

\begin{table}[htbp]\centering\small
\caption{Joint operational assumptions. ``Base'' is an illustration, not an
estimated most-likely case. Every value in this table is assumed.}
\begin{tabularx}{\linewidth}{@{}Yrrr@{}}\toprule
Parameter & Base & Conservative & Stress \\\midrule
""" + "\n".join(rows) + r"""
\bottomrule\end{tabularx}\end{table}

The initial base budget includes 16 hours of useful capability construction,
16 hours of unsuccessful construction and 8 hours of qualification, in addition
to 8 hours of requirements, 8 of deployment and 16 of executor integration.
Recurring base provider work is eight hours per month across support, runtime
maintenance, recovery upkeep, capability checks, refresh and unsuccessful search.
These are inspectable engineering allowances, not estimates of historical
authoring time. The monetary resource budget is USD\,25,000 in all primary
examples. Employer and provider pools each reserve 120 minutes per workday;
traditional production has a separate 480-minute worker pool. The year has
240 eight-hour workdays. Token pools and utilization are assumed planning
resources, not verified provider quotas.
""")

arm_rows = []
for label, bundle, cap in [("Agent-accepted", base["annual_at_demand"], base["capacity"]),
                           ("Traditional, $t=30$", human30["annual_at_demand"], human30["capacity"]),
                           ("Agent + human fallback", hybrid30["annual_at_demand"], hybrid30["capacity"])]:
    cohort = cap["feasible_admitted_cohort"]
    arm_rows.append(label + " & " + n(cap["requested_capacity"],0) + " & " + n(cap["expected_accepted_capacity"]) +
                    " & " + money(cohort["cost_per_expected_accepted"]) + " & " + n(cohort["human_minutes_per_expected_accepted"]["employer_minutes"]) + r" \\")
scenario_rows = []
for s in scenario_order:
    r = cores["US_office", s]; t = comp(r)
    scenario_rows.append(s.title() + " & " + n(r["scenario_inputs"]["requested_demand"],0) + " & " +
                         n(100*r["expected_acceptance_probability"],0) + r"\% & " +
                         money(r["declared_demand_cost_per_expected_accepted"]) + " & " +
                         money(t["traditional"]["annual_at_demand"]["cost_per_expected_accepted"]) + " & " +
                         money(t["hybrid"]["annual_at_demand"]["cost_per_expected_accepted"]) + r" \\")
geo_rows = []
labels = {"US_office":"U.S. office/admin", "US_professional":"U.S. professional", "Ontario":"Ontario technical writer", "EU":"EU covered economy"}
for basis in labels:
    r = cores[basis,"base"]; t = comp(r)
    geo_rows.append(labels[basis] + " & " + r["currency"] + " & " + n(r["declared_demand_cost_per_expected_accepted"]) +
                    " & " + n(t["traditional"]["annual_at_demand"]["cost_per_expected_accepted"]) + " & " +
                    n(r["human_break_even_productive_minutes"]) + r" \\")
put("results.tex", rf"""
\textbf{{The primary base case does not establish a cost or attention win.}}
At the example budget's aggregate expected-use limits, Agent-accepted work costs
{money(ca['cost_per_expected_accepted'])}, traditional completion at assumed
$t=30$ productive minutes costs {money(ch['cost_per_expected_accepted'])}, and the
complete-demand hybrid costs {money(cy['cost_per_expected_accepted'])} per output.
Their admitted cohorts differ because each pays its own fixed and variable costs.
The Agent-only cohort still has unresolved requests; the hybrid explicitly
finishes all requests it admits using assumed competent-human rescue.

\begin{{table}}[htbp]\centering\small
\caption{{Base U.S. office-work example under a USD\,25,000 economic budget.
These are aggregate expected-use planning ceilings, not a validated schedule
or a hard budget guarantee. Productive human time is assumed 30 minutes.}}
\begin{{tabularx}}{{\linewidth}}{{@{{}}Yrrrr@{{}}}}\toprule
Route & Requested & \shortstack{{Expected\\completed}} & \shortstack{{Cost per\\accepted}} & \shortstack{{Employer\\min/output}} \\\midrule
""" + "\n".join(arm_rows) + r"""
\bottomrule\end{tabularx}\end{table}

\begin{figure}[htbp]\centering
\includegraphics[width=\linewidth]{../figures/full_cost_comparison.pdf}
\caption{Complete cost and accepted capacity at the aggregate resource limits.
The incomplete-demand Agent route and complete-demand fallback are different
offerings. This is simulated service economics, not a live invoice.}
\end{figure}

The original 1,000-request allocation would cost USD\,27,469.20 for the Agent,
above the USD\,25,000 budget, and would produce only 950 expected accepted outputs.
Its accepted-normalized USD\,28.91 is therefore not the attainable unit cost under
that example budget. At the same declared volume, the traditional route costs
USD\,28.42 per completed job and the hybrid USD\,29.73. All three fail to fit the
entire 1,000-request demand within the example budget. Cost and capacity must be
read together.

\begin{table}[htbp]\centering\small
\caption{Complete U.S. office-work costs at declared annual demand. The human
column assumes 30 productive minutes plus its ancillary work. The Agent columns
are conditional calculations at volumes that are not feasible within the stated
budget; conservative/stress fixed commitments alone block admission.}
\begin{tabularx}{\linewidth}{@{}Yrrrrr@{}}\toprule
Scenario & Requests & Agent $Q$ & Agent & Traditional & Hybrid \\\midrule
""" + "\n".join(scenario_rows) + rf"""
\bottomrule\end{{tabularx}}\end{{table}}

The base Agent's annual fixed account is
{money(base['annual_at_demand']['fixed_account']['total'])}. The full annual
declared-volume account separates {money(base['service_improvement_totals']['service_and_employer'])}
of service/employer resources, {money(base['service_improvement_totals']['identified_improvement'])}
of identified improvement work and {money(base['service_improvement_totals']['joint_service_improvement_unallocated'])}
of shared service/improvement resources. Shared costs remain in the total even
when attribution between service and improvement is unresolved. This avoids
making either account look cheaper through an arbitrary favorable allocation.

The first commission is a different decision. Its initial investment is
{money(base['fixed_agent']['initial']['total'])}, its one-month operating reserve
is {money(base['fixed_agent']['monthly']['total'])}, and its probability-weighted
request cost is {money(base['agent_variable']['account']['total'])}. Combined,
it costs {money(base['first_commission_total_cost'])} per requested commission,
or {money(base['first_commission_cost_per_expected_accepted'])} normalized by
assumed acceptance. This is a modeled service-construction investment, not an
invoice or a claim that a customer should pay thousands for four passages.
A new service built for one brief is economically different from using an
already available, frequently reused capability.

At declared annual volume, Agent employer attention is
{n(base['employer_minutes_per_expected_accepted'])} minutes per accepted output,
versus {n(human30['annual_at_demand']['human_minutes_per_expected_accepted']['employer_minutes'])}
for traditional work. Yet total human labor is
{n(base['all_human_minutes_per_expected_accepted'])} versus
{n(human30['annual_at_demand']['all_human_minutes_per_expected_accepted'])} minutes.
Higher-priced provider effort and fixed construction explain how less total
labor can coexist with greater employer attention and slightly greater cost.
Neither released labor nor faster computation is automatically a payroll saving.

Successful Agent requests have an assumed mean turnaround of
{n(base['accepted_conditional_turnaround_minutes'])} minutes, median
{n(base['accepted_turnaround_median_minutes'])} and p95
{n(base['accepted_turnaround_p95_minutes'])}; traditional mean turnaround at
$t=30$ is {n(human30['variable']['latency']['accepted_conditional_minutes'])} minutes, and hybrid
mean turnaround is {n(hybrid30['variable']['latency']['accepted_conditional_minutes'])} minutes.
These are event-path elapsed-time assumptions, not measurements of provider
service. The native 0.111703-second component cannot replace those clocks.

\begin{{table}}[htbp]\centering\small
\caption{{Base scenario price illustrations at the same declared 1,000-request
allocation, which is budget-infeasible for all four price bases. Values are in
each row's currency. Thresholds concern productive human minutes, not all-in
human effort. No geography-specific performance inference is made.}}
\begin{{tabularx}}{{\linewidth}}{{@{{}}Ylrrr@{{}}}}\toprule
Labor price basis & Currency & Agent & Human $t=30$ & $t^*$ min \\\midrule
""" + "\n".join(geo_rows) + r"""
\bottomrule\end{tabularx}\end{table}

\begin{figure}[htbp]\centering
\includegraphics[width=\linewidth]{../figures/cost_and_attention_accounts.pdf}
\caption{Money, remaining employer attention and total human labor answer
different questions. These declared-volume accounts include fixed costs;
the 1,000-request illustration exceeds the example resource budget.}
\end{figure}
""")

sens_rows = []
for item in data['one_way_sensitivities']:
    r = item['result']
    name = item['driver'].replace('_',' ')
    if len(name)>39:
        name = {"recurring support and upkeep multiplier":"Support/upkeep multiplier",
                "unsuccessful initial construction multiplier":"Unsuccessful-construction multiplier",
                "native delivery no model or paid search":"Native delivery; no model/search"}.get(name,name)
    value = item['value']
    if isinstance(value,(dict,list)):
        value = 'enabled'
    sens_rows.append((item['driver'], str(value),r['declared_demand_cost_per_expected_accepted'],r['feasible_cost_per_expected_accepted']))
driver_ranges = []
for driver in dict.fromkeys(x[0] for x in sens_rows):
    vals=[x for x in sens_rows if x[0]==driver]
    name={"requested_reuse_volume":"Requested volume", "delivery_model_token_multiplier":"Delivery tokens", "employer_review_effort_multiplier":"Employer review effort", "unsuccessful_initial_construction_multiplier":"Unsuccessful initial construction", "recurring_support_and_upkeep_multiplier":"Recurring support/upkeep", "native_delivery_no_model_or_paid_search":"Native route; no delivery model/search"}.get(driver,driver.replace('_',' '))
    values=', '.join(x[1] for x in vals)
    costs=[x[2] for x in vals if x[2] is not None]
    driver_ranges.append(name+' & '+values+' & '+n(min(costs))+'--'+n(max(costs))+r' \\')
put('sensitivity.tex',rf"""
At the declared 1,000-request base allocation, the Agent-only productive-time
threshold is {n(base['human_break_even_productive_minutes'])} minutes. Complete-demand
fallback needs {n(base['hybrid_break_even_productive_minutes'])} minutes. These
thresholds preserve human ancillary and fixed costs; neither means the four-passage
brief has been observed to require that long. The 1,000-request allocation remains
outside the example budget.

\begin{{figure}}[htbp]\centering
\includegraphics[width=\linewidth]{{../figures/duration_sensitivity.pdf}}
\caption{{Prespecified human-duration sensitivities at each route's aggregate
expected-use admission limit. Agent assumptions stay fixed while hypothetical
human time changes. This does not demonstrate a harder task at constant Agent
cost; no matched human duration has been observed.}}
\end{{figure}}

\begin{{table}}[htbp]\centering\small
\caption{{All one-way sensitivity families around the U.S. office base. The final
column is declared-volume cost per expected accepted output in USD; feasibility
must be read from the full output. These are assumption ranges, not confidence
intervals or probabilities.}}
\begin{{tabularx}}{{\linewidth}}{{@{{}}Yp{{.31\linewidth}}r@{{}}}}\toprule
Driver & Frozen values & Cost range \\\midrule
"""+'\n'.join(driver_ranges)+r"""
\bottomrule\end{tabularx}\end{table}

Removing all hypothetical delivery model calls and paid search leaves the
declared-volume cost at USD\,28.72. That sensitivity retains positive setup,
integration, construction, review, occupancy and upkeep budgets. It is not
evidence that the untested full service has identical quality without those
calls. It shows that token prices are a small part of this assumed service's
cost. The native route's actual zero task-time model calls do not erase the
unmeasured cost of authoring and operating the capability.

A separately labeled post-result algebraic diagnostic solves for reuse volume
using the same fixed/variable accounts, with no new parameter search. At the
U.S. office $t=30$ baseline, Agent-only parity requires 1,040 requests; complete-
demand fallback requires 1,113. The corresponding aggregate admission limits are
829 and 703. Thus neither payback volume fits the configured resource plan.
The formulas and independent substitution checks are supplied in
\artifact{outputs/post_result_reuse_diagnostic.json}. This is not a retroactively
preregistered primary endpoint. None of the four price bases' parity thresholds
fits both arms' same-request-cohort resource bounds.

\begin{samepage}
The apparently attractive USD\,16.57 cost at 10,000 requested uses is also outside
the resource plan. Its admitted Agent volume remains 829 and its admitted unit
cost USD\,31.74. Unlimited amortization would therefore create an unsupported
commercial claim. A real decision needs adequate demand and the money, human
time and infrastructure to serve it.\par
\end{samepage}
""")

cap_rows=[]
for minutes in inputs['traditional']['productive_minutes']:
    t=comp(base,minutes); h=t['traditional']['capacity']; y=t['hybrid']['capacity']
    cap_rows.append(n(minutes,0)+' & '+n(base['capacity']['expected_accepted_capacity'])+' & '+n(h['expected_accepted_capacity'],0)+' & '+n(y['expected_accepted_capacity'],0)+' & '+n(h['feasible_admitted_cohort']['cost_per_expected_accepted'])+' & '+n(y['feasible_admitted_cohort']['cost_per_expected_accepted'])+r' \\')
put('capacity.tex',r"""
\begin{table}[htbp]\centering\small
\caption{Base U.S. office expected accepted capacity at USD\,25,000, with
each route constrained separately. Human time is an assumption. Agent admitted
cost is USD\,31.74 throughout this duration sensitivity. Capacity is not guaranteed.}
\begin{tabularx}{\linewidth}{@{}Yrrrrr@{}}\toprule
Human productive min & Agent & Human & Hybrid & Human cost & Hybrid cost \\\midrule
"""+'\n'.join(cap_rows)+r"""
\bottomrule\end{tabularx}\end{table}

Longer hypothetical conventional production can produce conditional gains. It
does not establish that this small source pack takes 60 or 120 minutes, nor that
Agent costs and acceptance would remain fixed on a more difficult job. At the
30-minute U.S. professional price basis, the separate-cohort aggregate comparison
is 435.10 expected Agent-accepted outputs versus 426 traditional outputs, but
only 362 hybrid completions. Those modest conditional differences do not support
a broad claim of autonomous enterprise superiority.

\textbf{The capacity equations do not validate a staffing schedule or a hard
spending cap.} A post-result consistency check found that the assumed Agent
setup windows of 10, 30 and 60 workdays require at least 45, 160 and 490 provider
workdays under uniform daily availability and utilization. Frontloading an
annual-average labor pool is a different scheduling assumption, not an observed
deployment. The traditional stress setup also fails its uniform employer-time
limit (five days needed versus four declared). Frozen values remain unchanged
and the diagnostic is published separately. Declared first-commission setup
latency must therefore not be promised as achievable.

Moreover, admission is sized against probability-weighted resource use. Actual
costly failure paths could exceed a budget that is nearly exhausted at its mean.
No chance constraint, tail-risk reserve or paid-call spending enforcement is
validated here. The original study's real local STOP/work-unit controls remain
separate. Prospective paid operation would need its own measured, authorized
resource guards and staffing validation.
""")

put('reproduction.tex',rf"""
The independent arithmetic implementation reconciled {n(audit['checks_total'],0)}
checks across all 12 core scenarios, 60 human-duration and corresponding hybrid
comparisons, and 23 one-way sensitivities. A separate derivative audit checked
the reuse equations and all 5,064 component-ledger rows. These are accounting
checks, not additional empirical jobs or human observations. The first audit
adapter's enum/reference-selection errors and their correction remain recorded;
no producer arithmetic or frozen input was changed to clear them. A clean
producer rerun reproduced all five primary output files byte for byte.

The full source contains the model, its independent Decimal implementation,
the six event paths, price/source registers, observed native artifacts, frozen
specification, CSV ledgers and all output JSON. From the extracted project root:
\begin{{verbatim}}
python economics_amendment_v1/src/model.py --help
python economics_amendment_v1/paper/build_content.py
make -C economics_amendment_v1/paper
\end{{verbatim}}
\artifact{{MODEL_GUIDE.md}} gives the exact model/audit invocation and output
directory safeguards. The preserved native study has its own reproduction
instructions and unchanged complete LaTeX archive. Figures retain editable
Matplotlib source and SVG/PDF/PNG exports. The browser's download panel includes
the source-linked economic inputs, model and audited results.

Canonical scenario-result SHA-256:
\begin{{center}}\artifact{{{audit['results_sha256']}}}\end{{center}}
The separately reviewed PDF and final archive manifests bind the delivered
bytes. A public draft is inspectable research material; peer review, repository
merge, website publication and live operating admission remain separate.
""")

manifest={"schema":"operational-economics-paper-data/v1","results_sha256":audit['results_sha256'],
          "model_sha256":audit['producer_source_sha256'],"input_freeze_sha256":audit['input_freeze_sha256'],
          "audit_sha256":hashlib.sha256((ROOT/'evaluation/INDEPENDENT_AUDIT.json').read_bytes()).hexdigest(),
          "generated":[{"path":str(p.relative_to(ROOT)),"sha256":hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(OUT.glob('*.tex'))],
          "note":"All values are conditional model outputs except explicitly identified native measurements and cited published prices."}
(OUT/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({"generated_sections":len(manifest['generated']),"results_sha256":manifest['results_sha256']}))
