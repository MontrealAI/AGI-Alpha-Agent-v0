# SPDX-License-Identifier: Apache-2.0
"""Publication figures from the audited operational economics result, without new scenarios."""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.text import Text
import numpy as np


RESULTS_SHA = "cba5f2cf284e27f7097fc3f4cebe0bf985952cd64bfcabee78af51ca0c17ac9d"
AUDIT_SHA = "cc11e0ddbe7a71ac2cd3d1ef30d0009c793f37a0f8d6df460038ccce99c1a4f5"
NAVY, TEAL, AMBER, MUTED = "#13263D", "#087F8C", "#A05A16", "#556575"
GRAY, LIGHT = "#DCE3E8", "#F1F4F6"
COLORS = [TEAL, NAVY, AMBER]
FIXED_DATE = dt.datetime(2026, 10, 25, 13, 30, 40, tzinfo=dt.timezone.utc)


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 10,
    "text.color": NAVY, "axes.labelcolor": NAVY, "axes.edgecolor": GRAY,
    "xtick.color": MUTED, "ytick.color": NAVY,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.spines.left": False, "axes.linewidth": 0.7,
    "axes.titleweight": "bold", "axes.titlesize": 10.5,
    "axes.labelsize": 10, "xtick.labelsize": 9, "ytick.labelsize": 10,
    "grid.color": GRAY, "grid.linewidth": 0.65,
    "pdf.fonttype": 42, "ps.fonttype": 42,
    "svg.fonttype": "none", "svg.hashsalt": "AGIALPHA-operational-economics-amendment-v1",
    "savefig.facecolor": "white", "figure.facecolor": "white",
})


def title(fig, main: str, sub: str, subtitle_color: str = MUTED) -> None:
    fig.text(0.04, 0.958, main, ha="left", va="top", fontsize=12.8, weight="bold")
    fig.text(0.04, 0.897, sub, ha="left", va="top", fontsize=9.5, color=subtitle_color)


def save(fig, name: str, out: Path, records: list) -> None:
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    width, height = fig.canvas.get_width_height()
    overflows = []
    for text in fig.findobj(Text):
        if text.get_visible() and text.get_text().strip():
            bounds = text.get_window_extent(renderer)
            if bounds.x0 < -1 or bounds.y0 < -1 or bounds.x1 > width + 1 or bounds.y1 > height + 1:
                overflows.append(text.get_text())
    if overflows:
        raise ValueError("Text outside figure canvas: " + repr(overflows))
    description = "Modeled economics; primary result SHA256 " + RESULTS_SHA + "; independent audit SHA256 " + AUDIT_SHA
    fig.savefig(out / (name + ".pdf"), metadata={
        "Title": name, "Author": "AGI ALPHA research evidence", "Subject": description,
        "Creator": "Matplotlib; editable build_figures.py", "CreationDate": FIXED_DATE, "ModDate": FIXED_DATE,
    })
    fig.savefig(out / (name + ".svg"), metadata={
        "Title": name, "Description": description, "Creator": "Matplotlib; editable build_figures.py",
        "Date": FIXED_DATE.isoformat(),
    })
    fig.savefig(out / (name + ".png"), dpi=220, metadata={"Title": name, "Description": description})
    records.append({"figure": name, "canvas_inches": list(fig.get_size_inches()),
                    "text_overflow_check": "PASS", "visual_review": "PENDING",
                    "files": [{"path": name + "." + ext, "sha256": sha(out / (name + "." + ext))}
                              for ext in ("pdf", "svg", "png")]})
    plt.close(fig)


def labels(values, decimals=2):
    return [f"{value:,.{decimals}f}" for value in values]


def build(root: Path, out: Path) -> None:
    result_path = root / "outputs/run-001/results.json"
    audit_path = root / "evaluation/INDEPENDENT_AUDIT.json"
    if sha(result_path) != RESULTS_SHA or sha(audit_path) != AUDIT_SHA:
        raise ValueError("Audited economic evidence identity differs")
    raw = json.loads(result_path.read_text())
    audit = json.loads(audit_path.read_text())
    if audit["status"] != "PASS" or audit["results_sha256"] != RESULTS_SHA:
        raise ValueError("Missing matching independent audit")
    case = next(row for row in raw["core_scenarios"] if row["scenario"] == "base" and row["price_basis"] == "US_office")
    comparison = next(row for row in case["traditional_comparisons"] if row["productive_minutes"] == 30)
    caps = [case["capacity"], comparison["traditional"]["capacity"], comparison["hybrid"]["capacity"]]
    arm_names = ["Agent-only", "Traditional", "Hybrid"]
    cost = [cap["feasible_admitted_cohort"]["cost_per_expected_accepted"] for cap in caps]
    accepted = [cap["expected_accepted_capacity"] for cap in caps]
    requested = [cap["requested_capacity"] for cap in caps]
    out.mkdir(parents=True, exist_ok=True)
    records = []
    plotted = {"schema": "audited-economic-figure-data/v1", "primary_results_sha256": RESULTS_SHA,
               "independent_audit_sha256": AUDIT_SHA, "units": "USD; minutes; requested jobs; expected accepted outputs",
               "comparison": {"arm": arm_names, "requested": requested, "expected_accepted": accepted,
                              "cost_per_expected_accepted": cost}, "duration": [], "accounts": {}}

    # Figure 1: the attainable denominator under the common expected-use budget.
    fig, axes = plt.subplots(1, 2, figsize=(6.3, 4.1), gridspec_kw={"width_ratios": [1, 1.18]})
    fig.subplots_adjust(left=0.23, right=0.96, top=0.74, bottom=0.29, wspace=0.26)
    title(fig, "What the same $25,000 can support", "U.S. office/admin base; 30 productive human minutes assumed")
    y = np.arange(3)
    for ax in axes:
        ax.set_axisbelow(True); ax.grid(axis="x"); ax.tick_params(axis="y", length=0)
        ax.set_ylim(2.65, -0.65)
    axes[0].barh(y, cost, color=COLORS, height=0.55)
    axes[0].set_yticks(y, [f"{name}\n{n:,} requests" for name, n in zip(arm_names, requested)])
    axes[0].set_xlim(0, 42); axes[0].set_xticks([0, 20, 40])
    axes[0].set_title("Cost per accepted output", loc="left", pad=10)
    axes[0].set_xlabel("USD", labelpad=7)
    for i, value in enumerate(cost):
        axes[0].text(value - 1.3, i, f"{value:.2f}", ha="right", va="center", color="white", weight="bold", fontsize=9.5)
    axes[1].barh(y, accepted, color=COLORS, height=0.55)
    unresolved = requested[0] - accepted[0]
    axes[1].barh(0, unresolved, left=accepted[0], color="white", edgecolor=TEAL, hatch="////", height=0.55, linewidth=0.8)
    axes[1].set_yticks(y, ["", "", ""])
    axes[1].set_xlim(0, 1000); axes[1].set_xticks([0, 500, 1000])
    axes[1].set_title("Expected accepted outputs", loc="left", pad=10)
    axes[1].set_xlabel("Finite annual cohort", labelpad=7)
    for i, value in enumerate(accepted):
        label = f"{value:.2f}" if i == 0 else f"{value:.0f}"
        axes[1].text(value - 32, i, label, ha="right", va="center", color="white", weight="bold", fontsize=9.5)
    fig.text(0.04, 0.19, f"Agent-only leaves {unresolved:.2f} expected requests unresolved (hatched).", fontsize=9, color=MUTED)
    fig.text(0.04, 0.14, "Hybrid pays for full traditional fallback; its final acceptance is assumed.", fontsize=9, color=MUTED)
    fig.text(0.04, 0.065, "Expected-use planning ceilings; setup and daily scheduling unvalidated.", fontsize=9, color=MUTED)
    save(fig, "full_cost_comparison", out, records)

    # Figure 2: every frozen productive-time value, with Agent inputs held fixed.
    duration = case["traditional_comparisons"]
    times = [row["productive_minutes"] for row in duration]
    cost_curves, output_curves = [], []
    for arm in ("agent", "traditional", "hybrid"):
        arm_caps = [case["capacity"] if arm == "agent" else row[arm]["capacity"] for row in duration]
        cost_curves.append([cap["feasible_admitted_cohort"]["cost_per_expected_accepted"] for cap in arm_caps])
        output_curves.append([cap["expected_accepted_capacity"] for cap in arm_caps])
    plotted["duration"] = [{"productive_human_minutes": t,
                            "arms": {name: {"cost_per_expected_accepted": cost_curves[j][i],
                                             "expected_accepted_outputs": output_curves[j][i]}
                                     for j, name in enumerate(arm_names)}} for i, t in enumerate(times)]
    fig, axes = plt.subplots(2, 1, figsize=(6.3, 5.6), sharex=True)
    fig.subplots_adjust(left=0.16, right=0.95, top=0.78, bottom=0.27, hspace=0.24)
    title(fig, "When conventional work takes longer", "Prespecified human-time sensitivity; same $25,000 resource budget")
    handles = []
    for ax, curves in zip(axes, (cost_curves, output_curves)):
        ax.grid(axis="y"); ax.set_axisbelow(True)
        ax.axvline(30, color=GRAY, linestyle="--", linewidth=1.1)
        for name, color, values, marker in zip(arm_names, COLORS, curves, ("o", "s", "D")):
            line, = ax.plot(times, values, color=color, linewidth=2, marker=marker, markersize=4.7, label=name)
            if ax is axes[0]: handles.append(line)
        ax.set_xlim(0, 125)
    axes[0].set_ylabel("USD per expected\naccepted output", labelpad=12)
    axes[0].set_ylim(0, max(max(curve) for curve in cost_curves) * 1.12)
    axes[1].set_ylabel("Expected accepted\noutputs", labelpad=12)
    axes[1].set_ylim(0, 1100); axes[1].set_yticks([0, 500, 1000])
    axes[1].set_xticks(times); axes[1].set_xlabel("Assumed productive human minutes per brief", labelpad=8)
    fig.legend(handles, arm_names, loc="upper left", bbox_to_anchor=(0.14, 0.854), ncol=3,
               frameon=False, fontsize=9.5, columnspacing=1.8, handlelength=2.1)
    fig.text(0.04, 0.145, "Human time varies; Agent path assumptions stay fixed for the same brief.", fontsize=9, color=MUTED)
    fig.text(0.04, 0.105, "Four preselected passages; no matched human duration was observed.", fontsize=9, color=MUTED)
    fig.text(0.04, 0.055, "Expected-use ceilings; setup and daily scheduling remain unvalidated.", fontsize=9, color=MUTED)
    save(fig, "duration_sensitivity", out, records)

    # Figure 3: full declared-volume accounting, conspicuously infeasible.
    annual = [case["annual_at_demand"], comparison["traditional"]["annual_at_demand"], comparison["hybrid"]["annual_at_demand"]]
    accounts = case["service_improvement_totals"]
    accepted_declared = case["annual_at_demand"]["expected_accepted"]
    account_keys = ["service_and_employer", "identified_improvement", "joint_service_improvement_unallocated"]
    account_values = [accounts[key] / accepted_declared for key in account_keys]
    resource_keys = ["employer_minutes", "provider_minutes", "traditional_worker_minutes"]
    efforts = [[cohort["human_minutes_per_expected_accepted"][key] for cohort in annual] for key in resource_keys]
    plotted["accounts"] = {"expected_accepted_denominator": accepted_declared,
                           "account_costs_per_expected_accepted": dict(zip(account_keys, account_values)),
                           "human_effort_per_expected_accepted": {name: dict(zip(resource_keys, [efforts[j][i] for j in range(3)]))
                                                                  for i, name in enumerate(arm_names)},
                           "declared_demand_feasible": False}
    fig = plt.figure(figsize=(6.3, 5.15))
    title(fig, "Where complete cost and human effort sit", "Declared 1,000 requests: infeasible under the $25,000 budget", AMBER)
    ax1 = fig.add_axes([0.18, 0.63, 0.76, 0.13])
    left = 0
    for value, color in zip(account_values, (NAVY, TEAL, AMBER)):
        ax1.barh([0], [value], left=left, color=color, height=0.5)
        if value > 1:
            ax1.text(left + value / 2, 0, f"${value:.2f}", ha="center", va="center", color="white", weight="bold", fontsize=10)
        left += value
    ax1.set_xlim(0, 34); ax1.set_yticks([]); ax1.set_ylim(-0.6, 0.6)
    ax1.set_xticks([0, 10, 20, 30]); ax1.tick_params(axis="x", length=0)
    ax1.text(left + 0.5, 0, f"${left:.2f}", ha="left", va="center", fontsize=10, weight="bold")
    fig.text(0.04, 0.799, "a. Agent cost per expected accepted output (USD)", weight="bold", fontsize=10)
    fig.legend([Patch(color=color) for color in (NAVY, TEAL, AMBER)],
               ["Service + employer", "Identified improvement", f"Joint ${account_values[2]:.2f}"],
               loc="upper left", bbox_to_anchor=(0.045, 0.608), ncol=3, frameon=False,
               fontsize=8.9, handlelength=1.2, columnspacing=1.2)
    ax2 = fig.add_axes([0.23, 0.235, 0.71, 0.245])
    lefts = np.zeros(3)
    for values, color in zip(efforts, (NAVY, TEAL, AMBER)):
        ax2.barh(y, values, left=lefts, color=color, height=0.57)
        for i, (value, offset) in enumerate(zip(values, lefts)):
            if value >= 6:
                ax2.text(offset + value / 2, i, f"{value:.1f}", ha="center", va="center", color="white", fontsize=9.3)
        lefts += np.array(values)
    ax2.set_yticks(y, arm_names); ax2.tick_params(axis="y", length=0)
    ax2.set_ylim(2.6, -0.6); ax2.set_xlim(0, 53); ax2.set_xticks([0, 15, 30, 45])
    ax2.set_xlabel("Human minutes per expected accepted output", labelpad=7)
    for i, value in enumerate(lefts):
        ax2.text(value + 0.7, i, f"{value:.1f}", va="center", fontsize=9.3, weight="bold")
    fig.text(0.04, 0.515, "b. Employer attention and all human work", weight="bold", fontsize=10)
    fig.legend([Patch(color=color) for color in (NAVY, TEAL, AMBER)],
               ["Employer", "Provider/operator", "Traditional worker"],
               loc="upper left", bbox_to_anchor=(0.15, 0.156), ncol=3, frameon=False,
               fontsize=9, handlelength=1.2, columnspacing=1.5)
    fig.text(0.04, 0.072, "Fixed setup and twelve upkeep reserves are included; all timings assumed.", fontsize=9, color=MUTED)
    fig.text(0.04, 0.032, "Resource costs and released labor are not invoices or cash savings.", fontsize=9, color=MUTED)
    save(fig, "cost_and_attention_accounts", out, records)

    data_path = out / "figure_data.json"
    data_path.write_text(json.dumps(plotted, indent=2) + "\n")
    manifest = {"schema": "audited-economic-figures/v1", "primary_results_sha256": RESULTS_SHA,
                "independent_audit_sha256": AUDIT_SHA, "source_sha256": sha(Path(__file__)),
                "figure_data_sha256": sha(data_path), "matplotlib_version": matplotlib.__version__,
                "metadata_timestamp": FIXED_DATE.isoformat(), "figures": records}
    (out / "FIGURE_MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps({"output": str(out), "figures": len(records), "figure_data_sha256": sha(data_path)}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--output", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    build(args.root.resolve(), args.output.resolve())
