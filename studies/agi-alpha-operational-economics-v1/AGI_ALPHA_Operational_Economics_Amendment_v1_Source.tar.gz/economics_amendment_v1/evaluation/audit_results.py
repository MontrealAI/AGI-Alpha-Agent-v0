# SPDX-License-Identifier: Apache-2.0
"""Audit the analyst's JSON using the separate Decimal oracle.

Producer arithmetic is never imported. Failures and every audit attempt are
preserved. A numeric PASS certifies consistency with frozen assumptions only.
"""

from __future__ import annotations

import argparse
import json
import re
import traceback
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path

from oracle import (
    EXPECTED_FREEZE,
    ROOT,
    Oracle,
    json_value,
    merged,
    n,
    scaled,
    sha,
    total,
    transformed,
    validate_freeze,
)

OUT = Path(__file__).resolve().parent
ZERO = Decimal(0)
RESOURCE_MAP = {
    "employer_minutes": "employer_minutes",
    "provider_minutes": "provider_minutes",
    "traditional_worker_minutes": "worker_minutes",
    "executor_seconds": "occupied_seconds",
    "input_tokens": "input_tokens",
    "output_tokens": "output_tokens",
}
LIMIT_MAP = dict(RESOURCE_MAP, economic_budget="money", demand="demand")


class Audit:
    def __init__(self):
        self.checks = 0
        self.failures = []
        self.groups = {}
        self.group = "identities"

    def check(self, path, actual, expected, numeric=False):
        self.checks += 1
        group = self.groups.setdefault(
            self.group,
            {"checks": 0, "failures": 0, "maximum_absolute_numeric_difference": ZERO},
        )
        group["checks"] += 1
        difference = None
        if numeric and actual is not None and expected is not None:
            difference = abs(n(actual) - n(expected))
            tolerance = Decimal("1e-9") + Decimal("1e-11") * abs(n(expected))
            good = difference <= tolerance
            group["maximum_absolute_numeric_difference"] = max(
                group["maximum_absolute_numeric_difference"], difference
            )
        else:
            good = actual == expected
        if not good:
            group["failures"] += 1
            self.failures.append(
                {
                    "group": self.group,
                    "path": path,
                    "actual": actual,
                    "expected": expected,
                    "absolute_difference": difference,
                }
            )

    def num(self, path, actual, expected):
        self.check(path, actual, expected, numeric=True)

    @staticmethod
    def coarse_independent(components):
        answer = {}
        for key, value in components.items():
            if key.startswith("labor/employer/"):
                key = "labor/employer"
            elif key.startswith("labor/provider/"):
                key = "labor/provider"
            elif key == "labor/handoff":
                key = "labor/employer"
            answer[key] = answer.get(key, ZERO) + n(value)
        return answer

    def coarse_producer(self, path, components):
        answer = {}
        for label, value in components.items():
            route = re.search(r"\.model\.(.+)\.(input|output)$", label)
            if ".employer." in label:
                key = "labor/employer"
            elif ".provider." in label:
                key = "labor/provider"
            elif ".traditional_worker." in label:
                key = "labor/worker"
            elif route:
                key = "model_" + route.group(2) + "/" + route.group(1)
            elif label.endswith(".successful_search"):
                key = "search"
            elif label.endswith(
                (".executor_cpu", ".executor_memory", ".executor_requests")
            ):
                key = label.rsplit(".", 1)[1]
            elif label.endswith(".storage_at_rest"):
                if label.startswith("monthly."):
                    key = "shared_storage"
                elif label.startswith("delivery.request_retention."):
                    key = "artifact_storage"
                else:
                    self.num(path + "/explicit_zero_storage/" + label, value, ZERO)
                    continue
            elif label.endswith(".cash_allowance.operations_and_egress"):
                key = "operations_egress"
            elif label.endswith(".cash_allowance.ordinary_software_IT"):
                key = "ordinary_software_IT"
            elif ".cash_allowance." in label:
                key = "allowance/" + label.split(".cash_allowance.", 1)[1]
            elif label.endswith(".nonlabor_tax_allowance"):
                key = "tax_allowance"
            else:
                self.check(
                    path + "/recognized_component/" + label,
                    label,
                    "RECOGNIZED_COMPONENT",
                )
                continue
            answer[key] = answer.get(key, ZERO) + n(value)
        return answer

    def account(self, path, actual, components, resources):
        observed = self.coarse_producer(path, actual["components"])
        expected = self.coarse_independent(components)
        for key in set(observed) | set(expected):
            self.num(
                path + "/cost_category/" + key,
                observed.get(key, ZERO),
                expected.get(key, ZERO),
            )
        self.num(path + "/total", actual["total"], total(components.values()))
        self.num(
            path + "/component_sum",
            total(n(v) for v in actual["components"].values()),
            actual["total"],
        )
        for key, other in RESOURCE_MAP.items():
            self.num(
                path + "/resource/" + key,
                actual["resources"][key],
                resources.get(other, ZERO),
            )
        self.check(
            path + "/ownership_complete",
            set(actual["ownership"]),
            set(actual["components"]),
        )
        ownership_totals = {}
        for key, value in actual["components"].items():
            owner = actual["ownership"][key]
            ownership_totals[owner] = ownership_totals.get(owner, ZERO) + n(value)
        for owner in set(ownership_totals) | set(actual["account_totals"]):
            self.num(
                path + "/owned_total/" + owner,
                actual["account_totals"].get(owner, ZERO),
                ownership_totals.get(owner, ZERO),
            )
        identified = total(
            v for k, v in ownership_totals.items() if k.startswith("improvement_")
        )
        joint = ownership_totals.get("joint_service_improvement_unallocated", ZERO)
        split = actual["service_improvement_totals"]
        self.num(
            path + "/identified_improvement",
            split["identified_improvement"],
            identified,
        )
        self.num(
            path + "/joint_service_improvement",
            split["joint_service_improvement_unallocated"],
            joint,
        )
        self.num(
            path + "/service_employer",
            split["service_and_employer"],
            total(components.values()) - identified - joint,
        )

    def cohort(self, path, actual, expected, volume, months):
        volume, months = n(volume), n(months)
        q = expected["acceptance"]
        fixed = Oracle.combined_fixed(expected["initial"], expected["monthly"], months)
        components = merged(
            fixed["components"], scaled(expected["per_request"]["components"], volume)
        )
        resources = merged(
            fixed["resources"], scaled(expected["per_request"]["resources"], volume)
        )
        accepted = volume * q
        cost = total(components.values())
        values = {
            "requested": volume,
            "expected_accepted": accepted,
            "expected_unresolved": volume * (1 - q),
            "acceptance_probability": q,
            "operating_months_reserved": months,
            "total_cost": cost,
            "cost_per_requested": cost / volume if volume else None,
            "cost_per_expected_accepted": cost / accepted if accepted else None,
        }
        for key, value in values.items():
            self.num(path + "/" + key, actual[key], value)
        self.check(
            path + "/denominator_status",
            actual["accepted_denominator_status"],
            "DEFINED" if accepted else "NO_EXPECTED_ACCEPTED_OUTPUTS",
        )
        self.account(
            path + "/fixed",
            actual["fixed_account"],
            fixed["components"],
            fixed["resources"],
        )
        self.account(path + "/total", actual["total_account"], components, resources)
        for key, other in RESOURCE_MAP.items():
            if key not in (
                "employer_minutes",
                "provider_minutes",
                "traditional_worker_minutes",
            ):
                continue
            val = resources.get(other, ZERO)
            self.num(
                path + "/human_requested/" + key,
                actual["human_minutes_per_requested"][key],
                val / volume if volume else None,
            )
            self.num(
                path + "/human_accepted/" + key,
                actual["human_minutes_per_expected_accepted"][key],
                val / accepted if accepted else None,
            )
        all_human = total(
            resources.get(k, ZERO)
            for k in ("employer_minutes", "provider_minutes", "worker_minutes")
        )
        self.num(
            path + "/all_human",
            actual["all_human_minutes_per_expected_accepted"],
            all_human / accepted if accepted else None,
        )
        for key, share in actual["cost_shares"].items():
            self.num(
                path + "/cost_share/" + key,
                share,
                (
                    n(actual["total_account"]["account_totals"][key]) / cost
                    if cost
                    else None
                ),
            )

    def latency(self, path, actual, expected, agent=False):
        all_summary = expected["latency_all"]
        accepted = expected["latency_accepted"] if agent else all_summary
        failed = expected["latency_failed"]["mean_minutes"] if agent else None
        mapping = {
            "accepted_conditional_minutes": accepted["mean_minutes"],
            "all_request_minutes": all_summary["mean_minutes"],
            "failed_conditional_minutes": failed,
            "accepted_median_minutes": accepted["median_minutes"],
            "accepted_p95_minutes": accepted["p95_minutes"],
            "worst_declared_path_minutes": all_summary["worst_minutes"],
        }
        for key, value in mapping.items():
            self.num(path + "/" + key, actual[key], value)
        self.num(path + "/atom_count", len(actual["atoms"]), len(all_summary["atoms"]))
        actual_atoms = sorted(
            actual["atoms"], key=lambda z: (n(z["seconds"]), n(z["probability"]))
        )
        expected_atoms = sorted(
            all_summary["atoms"], key=lambda z: (n(z["minutes"]), n(z["probability"]))
        )
        for index, (one, two) in enumerate(zip(actual_atoms, expected_atoms)):
            self.num(path + f"/atom/{index}/time", one["seconds"], two["minutes"] * 60)
            self.num(
                path + f"/atom/{index}/mass", one["probability"], two["probability"]
            )

    def capacity(self, path, actual, expected):
        cap = expected["capacity"]
        self.num(
            path + "/requested", actual["requested_capacity"], cap["admitted_requests"]
        )
        self.num(
            path + "/accepted",
            actual["expected_accepted_capacity"],
            cap["expected_accepted"],
        )
        self.num(
            path + "/unresolved",
            actual["expected_unresolved_capacity"],
            n(cap["admitted_requests"]) * (1 - expected["acceptance"]),
        )
        self.check(
            path + "/declared_feasible",
            actual["declared_demand_feasible"],
            cap["declared_demand_feasible"],
        )
        self.check(
            path + "/binding",
            sorted(LIMIT_MAP[k] for k in actual["binding_constraints"]),
            sorted(cap["binding_constraints"]),
        )
        self.check(
            path + "/fixed_shortfalls",
            sorted(LIMIT_MAP[k] for k in actual["fixed_resource_shortfalls"]),
            sorted(cap["fixed_infeasible_resources"]),
        )
        for key, limit in actual["limits"].items():
            mapped = LIMIT_MAP[key]
            if key == "demand":
                self.num(
                    path + "/limit/demand",
                    limit["request_limit"],
                    expected["requested"],
                )
                continue
            if mapped in cap["time_pool_details"]:
                detail = cap["time_pool_details"][mapped]
                self.num(
                    path + "/limit/" + key + "/annual",
                    limit["annual_residual"],
                    detail["annual"],
                )
                self.num(
                    path + "/limit/" + key + "/postdeployment",
                    limit["postdeployment_residual"],
                    detail["postdeployment"],
                )
            else:
                self.num(
                    path + "/limit/" + key + "/annual",
                    limit["annual_residual"],
                    cap["raw_residuals_after_fixed"][mapped],
                )
            self.num(
                path + "/limit/" + key + "/effective",
                limit["effective_residual"],
                max(ZERO, cap["raw_residuals_after_fixed"][mapped]),
            )
            per = (
                expected["per_request"]["cost"]
                if mapped == "money"
                else expected["per_request"]["resources"].get(mapped, ZERO)
            )
            self.num(path + "/limit/" + key + "/usage", limit["per_request"], per)
            self.num(
                path + "/limit/" + key + "/ratio",
                limit["request_limit"],
                cap["request_ceilings"].get(mapped),
            )
        self.cohort(
            path + "/feasible_cohort",
            actual["feasible_admitted_cohort"],
            expected,
            cap["admitted_requests"],
            12,
        )
        self.check(
            path + "/scope",
            actual["scope"].startswith("AGGREGATE_RESOURCE_FEASIBLE_UPPER_BOUND"),
            True,
        )

    def arm(self, path, actual, expected, agent=False):
        variable = actual["agent_variable"] if agent else actual["variable"]
        fixed = (
            actual["fixed_agent"]
            if agent
            else actual.get("fixed", variable.get("fixed"))
        )
        self.account(
            path + "/variable",
            variable["account"],
            expected["per_request"]["components"],
            expected["per_request"]["resources"],
        )
        self.latency(path + "/latency", variable["latency"], expected, agent=agent)
        for phase in ("initial", "monthly"):
            self.account(
                path + "/fixed/" + phase,
                fixed[phase],
                expected[phase]["components"],
                expected[phase]["resources"],
            )
        self.cohort(
            path + "/annual",
            actual["annual_at_demand"],
            expected,
            expected["requested"],
            12,
        )
        self.cohort(path + "/first", actual["first_commission"], expected, 1, 1)
        self.num(
            path + "/first_setup",
            actual["first_commission"]["setup_delay_minutes"],
            expected["setup_elapsed_minutes"],
        )
        latency = (
            expected["latency_accepted"]["mean_minutes"]
            if agent
            else expected["latency_all"]["mean_minutes"]
        )
        self.num(
            path + "/first_elapsed",
            actual["first_commission"][
                "accepted_conditional_turnaround_minutes_including_setup"
            ],
            expected["setup_elapsed_minutes"] + latency,
        )
        self.capacity(path + "/capacity", actual["capacity"], expected)

    def core(self, path, actual, engine, basis, scenario):
        t = engine.x["traditional"]["reference_productive_minutes"]
        expected = engine.scenario(basis, scenario, t)
        self.check(path + "/basis", actual["price_basis"], basis["id"])
        self.check(path + "/scenario", actual["scenario"], scenario)
        self.check(path + "/currency", actual["currency"], basis["currency"])
        self.check(
            path + "/evidence",
            actual["evidence_class"],
            "MODELED_OPERATIONAL_ECONOMICS",
        )
        for field in (
            "actual_end_to_end_field_cost",
            "actual_historical_authoring_cost",
            "downstream_liability_expected_loss",
        ):
            self.check(path + "/" + field, actual[field], None)
        for one, two in (
            ("employer_worker_per_hour", "employer_hour"),
            ("provider_per_hour_in_reporting_currency", "provider_hour"),
            ("USD_to_reporting_currency", "usd_local"),
        ):
            self.num(
                path + "/rate/" + one,
                actual["labor_prices"][one],
                expected["rates"][two],
            )
        self.arm(path + "/agent", actual, expected["agent"], agent=True)
        self.num(
            path + "/branch_count",
            len(actual["agent_variable"]["branches"]),
            len(expected["paths"]),
        )
        for branch in actual["agent_variable"]["branches"]:
            bid = branch["branch"]
            other = expected["paths"][bid]
            bpath = path + "/branch/" + bid
            self.num(
                bpath + "/probability", branch["probability"], other["probability"]
            )
            self.check(bpath + "/accepted", branch["accepted"], other["accepted"])
            self.num(
                bpath + "/attempts",
                branch["attempts"],
                other["resources"]["production_attempts"],
            )
            self.num(
                bpath + "/elapsed",
                branch["elapsed_seconds"],
                other["elapsed_minutes"] * 60,
            )
            self.account(
                bpath + "/account",
                branch["account"],
                other["components"],
                other["resources"],
            )
            self.num(
                bpath + "/occurrence_count",
                len(branch["events"]),
                len(other["event_occurrences"]),
            )
            for index, (event, target) in enumerate(
                zip(branch["events"], other["event_occurrences"])
            ):
                epath = bpath + f"/event/{index}"
                self.check(epath + "/identity", event["event"], target["event_id"])
                tax_components = engine.apply_tax(
                    target["components_before_tax"], engine.x["scenarios"][scenario]
                )
                self.account(
                    epath, event["account"], tax_components, target["resources"]
                )
                self.num(
                    epath + "/elapsed",
                    event["elapsed_seconds"],
                    target["elapsed_minutes"] * 60,
                )
                self.num(
                    epath + "/attempts",
                    event["production_attempts"],
                    target["resources"]["production_attempts"],
                )
                self.num(
                    epath + "/native_calls",
                    event["native_invocations"],
                    target["resources"]["native_invocations"],
                )
                self.num(
                    epath + "/model_calls",
                    total(n(v) for v in event["model_calls"].values()),
                    target["resources"]["model_calls"],
                )
                anchor = json.loads((ROOT / "observed/ANCHOR.json").read_text())
                self.num(
                    epath + "/included_native_time",
                    event["included_native_seconds"],
                    n(anchor["native_delivery_wall_seconds"])
                    * target["resources"]["native_invocations"],
                )
                meters = event["account"]["meters"]
                for key, otherkey in (
                    ("raw_occupied_seconds", "occupied_seconds"),
                    ("billed_allocated_seconds", "billed_seconds"),
                    ("executor_requests", "executor_requests"),
                    ("successful_search_calls", "search_calls"),
                ):
                    self.num(
                        epath + "/meter/" + key,
                        meters[key],
                        target["resources"][otherkey],
                    )
        a = expected["agent"]
        b = expected["break_even"]
        full_human = total(
            a["resources_per_accepted"].get(k, ZERO)
            for k in ("employer_minutes", "provider_minutes", "worker_minutes")
        )
        aliases = {
            "expected_acceptance_probability": a["acceptance"],
            "expected_attempts": a["per_request"]["resources"]["production_attempts"],
            "first_commission_total_cost": a["first_commission_total_cost"],
            "first_commission_cost_per_expected_accepted": a[
                "first_commission_cost_per_expected_accepted"
            ],
            "declared_demand_cost_per_expected_accepted": a["cost_per_accepted"],
            "employer_minutes_per_requested": a["per_request"]["resources"][
                "employer_minutes"
            ],
            "employer_minutes_per_expected_accepted": a["resources_per_accepted"][
                "employer_minutes"
            ],
            "provider_human_minutes_per_expected_accepted": a["resources_per_accepted"][
                "provider_minutes"
            ],
            "all_human_minutes_per_expected_accepted": full_human,
            "accepted_conditional_turnaround_minutes": a["latency_accepted"][
                "mean_minutes"
            ],
            "all_request_turnaround_minutes": a["latency_all"]["mean_minutes"],
            "failed_conditional_turnaround_minutes": a["latency_failed"][
                "mean_minutes"
            ],
            "accepted_turnaround_median_minutes": a["latency_accepted"][
                "median_minutes"
            ],
            "accepted_turnaround_p95_minutes": a["latency_accepted"]["p95_minutes"],
            "worst_declared_path_minutes": a["latency_all"]["worst_minutes"],
            "capacity_requested": a["capacity"]["admitted_requests"],
            "capacity_expected_accepted": a["capacity"]["expected_accepted"],
            "feasible_cost_per_expected_accepted": a["capacity"][
                "cost_per_accepted_at_feasible_volume"
            ],
            "human_break_even_productive_minutes": b["pure_agent_productive_minutes"],
            "human_break_even_all_in_minutes": b["pure_agent_human_all_in_minutes"],
            "hybrid_break_even_productive_minutes": b["hybrid_productive_minutes"],
        }
        for key, value in aliases.items():
            self.num(path + "/alias/" + key, actual[key], value)
        self.check(
            path + "/alias/declared_feasible",
            actual["declared_demand_feasible"],
            a["capacity"]["declared_demand_feasible"],
        )
        self.check(
            path + "/break_even_positive_slope",
            actual["break_even_slope_status"],
            "POSITIVE_DIFFERENCE",
        )
        self.num(
            path + "/break_even_substitution/agent",
            b["pure_agent_substitution_residual"],
            ZERO,
        )
        self.num(
            path + "/break_even_substitution/hybrid",
            b["hybrid_substitution_residual"],
            ZERO,
        )
        expected_durations = (
            [t]
            if path.startswith("sensitivity/")
            else engine.x["traditional"]["productive_minutes"]
        )
        self.check(
            path + "/duration_values",
            [c["productive_minutes"] for c in actual["traditional_comparisons"]],
            expected_durations,
        )
        for comparison in actual["traditional_comparisons"]:
            duration = comparison["productive_minutes"]
            data = engine.scenario(basis, scenario, duration)
            cpath = path + "/duration/" + str(duration)
            self.arm(cpath + "/human", comparison["traditional"], data["human"])
            self.arm(cpath + "/hybrid", comparison["hybrid"], data["hybrid"])
            self.num(
                cpath + "/hybrid_break_even",
                comparison["hybrid"]["break_even_productive_minutes"],
                data["break_even"]["hybrid_productive_minutes"],
            )
            ca, ch, cy = (
                data[k]["cost_per_accepted"] for k in ("agent", "human", "hybrid")
            )
            for key, value in {
                "modeled_human_to_agent_unit_cost_ratio": ch / ca,
                "modeled_human_to_hybrid_unit_cost_ratio": ch / cy,
                "modeled_human_minus_agent_unit_cost": ch - ca,
                "modeled_human_minus_hybrid_unit_cost": ch - cy,
            }.items():
                self.num(cpath + "/" + key, comparison[key], value)

    def flat(self, path, row, expected):
        a, h, y = (expected[k] for k in ("agent", "human", "hybrid"))

        def allhuman(arm):
            return total(
                arm["resources_per_accepted"].get(k, ZERO)
                for k in ("employer_minutes", "provider_minutes", "worker_minutes")
            )

        values = {
            "productive_human_minutes_assumed": expected["t"],
            "requested_demand": a["requested"],
            "agent_acceptance_probability_assumed": a["acceptance"],
            "agent_expected_accepted": a["expected_accepted"],
            "agent_expected_unresolved": a["unresolved_expected"],
            "agent_cost_per_expected_accepted": a["cost_per_accepted"],
            "traditional_cost_per_completed": h["cost_per_accepted"],
            "hybrid_cost_per_completed": y["cost_per_accepted"],
            "agent_first_commission_total_cost": a["first_commission_total_cost"],
            "agent_first_commission_per_expected_accepted": a[
                "first_commission_cost_per_expected_accepted"
            ],
            "traditional_first_commission_total_cost": h["first_commission_total_cost"],
            "hybrid_first_commission_total_cost": y["first_commission_total_cost"],
            "traditional_employer_minutes_per_completed": h["resources_per_accepted"][
                "employer_minutes"
            ],
            "hybrid_employer_minutes_per_completed": y["resources_per_accepted"][
                "employer_minutes"
            ],
            "agent_employer_minutes_per_expected_accepted": a["resources_per_accepted"][
                "employer_minutes"
            ],
            "agent_provider_minutes_per_expected_accepted": a["resources_per_accepted"][
                "provider_minutes"
            ],
            "agent_all_human_minutes_per_expected_accepted": allhuman(a),
            "traditional_all_human_minutes_per_completed": allhuman(h),
            "hybrid_all_human_minutes_per_completed": allhuman(y),
            "agent_accepted_turnaround_minutes": a["latency_accepted"]["mean_minutes"],
            "agent_first_accepted_turnaround_minutes_including_setup": a[
                "latency_accepted"
            ]["mean_minutes"]
            + a["setup_elapsed_minutes"],
            "traditional_turnaround_minutes": h["latency_all"]["mean_minutes"],
            "hybrid_turnaround_minutes": y["latency_all"]["mean_minutes"],
            "agent_break_even_productive_human_minutes": expected["break_even"][
                "pure_agent_productive_minutes"
            ],
            "hybrid_break_even_productive_human_minutes": expected["break_even"][
                "hybrid_productive_minutes"
            ],
            "agent_admitted_requests": a["capacity"]["admitted_requests"],
            "agent_capacity_expected_accepted": a["capacity"]["expected_accepted"],
            "agent_feasible_cost_per_expected_accepted": a["capacity"][
                "cost_per_accepted_at_feasible_volume"
            ],
            "human_capacity_completed": h["capacity"]["admitted_requests"],
            "hybrid_capacity_completed": y["capacity"]["admitted_requests"],
            "human_to_agent_unit_cost_ratio_modeled": h["cost_per_accepted"]
            / a["cost_per_accepted"],
            "human_to_hybrid_unit_cost_ratio_modeled": h["cost_per_accepted"]
            / y["cost_per_accepted"],
        }
        for key, value in values.items():
            self.num(path + "/" + key, row[key], value)
        for prefix, arm in (("agent", a), ("hybrid", y)):
            self.check(
                path + "/" + prefix + "_feasible",
                row[prefix + "_declared_demand_feasible"],
                arm["capacity"]["declared_demand_feasible"],
            )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", default="outputs/run-001/results.json")
    args = parser.parse_args()
    path = ROOT / args.results
    attempt = {
        "started_utc": datetime.now(timezone.utc).isoformat(),
        "audit_source_sha256": sha(Path(__file__)),
        "results_path": args.results,
    }
    audit = Audit()
    report = {}
    try:
        freeze, auth = validate_freeze()
        x = json.loads((ROOT / "inputs.json").read_text())
        labor = json.loads((ROOT / "sources/labor_rates.json").read_text())
        result = json.loads(path.read_text())
        source = ROOT / "src/model.py"
        engine = Oracle(x, labor)
        audit.check("input_manifest", result["input_manifest_sha256"], EXPECTED_FREEZE)
        audit.check("producer_identity", result["model_source_sha256"], sha(source))
        audit.check(
            "observed_anchor",
            result["observed_anchor"],
            json.loads((ROOT / "observed/ANCHOR.json").read_text()),
        )
        audit.num("core_count", len(result["core_scenarios"]), 12)
        audit.num("duration_count", len(result["human_duration_comparison"]), 60)
        audit.num("hybrid_count", len(result["hybrid_complete_demand"]), 60)
        audit.num("sensitivity_count", len(result["one_way_sensitivities"]), 23)
        bases = {b["id"]: b for b in x["price_bases"]}
        declared_core = {(b["id"], s) for b in x["price_bases"] for s in x["scenarios"]}
        reported_core = {
            (r["price_basis"], r["scenario"]) for r in result["core_scenarios"]
        }
        audit.check("core_portfolio_coverage", reported_core, declared_core)
        schema = json.loads((ROOT / "output_schema.json").read_text())
        for field in schema["required_top_level"]:
            audit.check("required_top/" + field, field in result, True)
        for row in result["core_scenarios"]:
            audit.group = "core/" + row["price_basis"] + "/" + row["scenario"]
            for field in schema["core_row_fields"]:
                audit.check("required_core/" + field, field in row, True)
            audit.core(
                audit.group, row, engine, bases[row["price_basis"]], row["scenario"]
            )
        for row in result["one_way_sensitivities"]:
            audit.group = "sensitivity/" + row["driver"] + "/" + str(row["value"])
            revised = transformed(
                x, row["driver"], None if row["value"] is True else row["value"]
            )
            varied_engine = Oracle(revised, labor)
            audit.core(
                audit.group, row["result"], varied_engine, bases["US_office"], "base"
            )
        for row in result["human_duration_comparison"]:
            audit.group = (
                "flat_duration/"
                + row["price_basis"]
                + "/"
                + row["scenario"]
                + "/"
                + str(row["productive_human_minutes_assumed"])
            )
            data = engine.scenario(
                bases[row["price_basis"]],
                row["scenario"],
                row["productive_human_minutes_assumed"],
            )
            audit.flat(audit.group, row, data)
        for row in result["hybrid_complete_demand"]:
            audit.group = (
                "flat_hybrid/"
                + row["price_basis"]
                + "/"
                + row["scenario"]
                + "/"
                + str(row["traditional_productive_minutes"])
            )
            data = engine.scenario(
                bases[row["price_basis"]],
                row["scenario"],
                row["traditional_productive_minutes"],
            )
            y = data["hybrid"]
            values = {
                "completed_demand_probability_assumed": 1,
                "human_fallback_probability": 1 - data["agent"]["acceptance"],
                "traditional_worker_minutes": y["resources_per_accepted"][
                    "worker_minutes"
                ],
                "total_human_minutes": total(
                    y["resources_per_accepted"].get(k, ZERO)
                    for k in ("employer_minutes", "provider_minutes", "worker_minutes")
                ),
                "hybrid_break_even_productive_minutes": data["break_even"][
                    "hybrid_productive_minutes"
                ],
                "annual_cost_per_completed_request": y["cost_per_accepted"],
                "aggregate_resource_capacity": y["capacity"]["admitted_requests"],
            }
            for key, value in values.items():
                audit.num(audit.group + "/" + key, row[key], value)
        report = {
            "schema": "independent-operational-economics-audit/v1",
            "status": "PASS" if not audit.failures else "FAIL",
            "created_utc": datetime.now(timezone.utc).isoformat(),
            "input_freeze_sha256": EXPECTED_FREEZE,
            "results_path": args.results,
            "results_sha256": sha(path),
            "producer_source_path": "src/model.py",
            "producer_source_sha256": sha(source),
            "independent_oracle_path": "evaluation/oracle.py",
            "independent_oracle_sha256": sha(OUT / "oracle.py"),
            "audit_source_path": "evaluation/audit_results.py",
            "audit_source_sha256": sha(Path(__file__)),
            "producer_arithmetic_imported": False,
            "numeric_tolerance": "absolute1e-9 plus relative1e-11; zero and null have distinct meaning",
            "checks_total": audit.checks,
            "failures": audit.failures,
            "groups": audit.groups,
            "coverage": {
                "core_rows": 12,
                "core_terminal_paths": 72,
                "human_duration_rows": 60,
                "hybrid_summary_rows": 60,
                "one_way_sensitivity_rows": 23,
                "included": "Every primary and sensitivity branch/event category, model-route token cost, fixed account, all three arms' first/annual/feasible cohorts, latency atoms/quantiles, resource pools, capacity limits, and human-duration summary.",
            },
            "validity_flags": [
                {
                    "code": "EXPECTED_BUDGET_NOT_HARD_ENFORCEMENT",
                    "severity": "limitation",
                    "detail": "Capacity divides residual pools by expected path consumption. Realized expensive outcomes can exceed a nearly exhausted mean budget. This is an expected-use planning ceiling, not a stochastic budget guarantee; no paid-call enforcement is deployed and the original native work-unit controls do not establish it.",
                },
                {
                    "code": "SCENARIO_NOT_EMPIRICAL_COST",
                    "severity": "scope",
                    "detail": "Arithmetic consistency with frozen assumed quantities and published prices is not an observed invoice, field reliability, full-system cost or new human trial.",
                },
                {
                    "code": "SETUP_SCHEDULING_UNVALIDATED",
                    "severity": "limitation",
                    "detail": "Aggregate capacity does not prove a daily staffing schedule. The post-result uniform-allocation diagnostic preserves frozen setup assumptions and reports incompatible windows.",
                    "evidence": "evaluation/SCHEDULING_DIAGNOSTIC.json",
                },
                {
                    "code": "UNMEASURED_MATERIAL_CONSEQUENCES",
                    "severity": "scope",
                    "detail": "Downstream liability remains unknown, not zero; high-consequence uses remain unsupported.",
                },
                {
                    "code": "DECLARED_DEMAND_NOT_ALWAYS_FEASIBLE",
                    "severity": "result",
                    "detail": "Unattainable declared-demand allocation is not used as feasible unit cost. Zero-capacity cases keep fixed losses and null accepted-normalized feasible cost.",
                },
                {
                    "code": "CALL_COUNT_SCOPE",
                    "severity": "scope",
                    "detail": "Delivery model calls are itemized; fixed construction/upkeep token budgets are priced but fixed call counts are unspecified. No actual provider usage is observed.",
                },
            ],
            "authorization_record": auth,
        }
        attempt["status"] = report["status"]
        attempt["checks_total"] = audit.checks
        attempt["failures_count"] = len(audit.failures)
    except Exception as exc:
        attempt.update(
            status="ERROR",
            error_type=type(exc).__name__,
            error=str(exc),
            traceback=traceback.format_exc(),
        )
        report = {
            "status": "ERROR",
            "error": attempt,
            "checks_total": audit.checks,
            "failures": audit.failures,
            "groups": audit.groups,
        }
    finally:
        attempt["finished_utc"] = datetime.now(timezone.utc).isoformat()
        directory = OUT / "audit_attempts"
        directory.mkdir(exist_ok=True)
        serial = len(list(directory.glob("attempt-*.json"))) + 1
        target = directory / f"attempt-{serial:03d}.json"
        target.write_text(
            json.dumps(json_value({"attempt": attempt, "report": report}), indent=2)
            + "\n"
        )
        (OUT / "INDEPENDENT_AUDIT.json").write_text(
            json.dumps(json_value(report), indent=2) + "\n"
        )
        print(json.dumps(attempt, indent=2))
        if audit.failures:
            print(json.dumps(json_value(audit.failures[:12]), indent=2))
    raise SystemExit(0 if report["status"] == "PASS" else 1)


if __name__ == "__main__":
    main()
