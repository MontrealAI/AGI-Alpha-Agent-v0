# SPDX-License-Identifier: Apache-2.0
"""Recompute every plotted quantity from frozen inputs with the Decimal oracle."""

import json
from datetime import datetime, timezone
from pathlib import Path

from audit_results import Audit
from oracle import ROOT, Oracle, json_value, sha, total, validate_freeze


def main():
    validate_freeze()
    inputs = json.loads((ROOT / "inputs.json").read_text())
    labor = json.loads((ROOT / "sources/labor_rates.json").read_text())
    engine = Oracle(inputs, labor)
    basis = next(z for z in inputs["price_bases"] if z["id"] == "US_office")
    path = ROOT / "figures/figure_data.json"
    figures = json.loads(path.read_text())
    audit = Audit()
    audit.group = "figure_data"
    audit.check(
        "results_hash",
        figures["primary_results_sha256"],
        sha(ROOT / "outputs/run-001/results.json"),
    )
    audit.check(
        "audit_hash",
        figures["independent_audit_sha256"],
        sha(ROOT / "evaluation/INDEPENDENT_AUDIT.json"),
    )
    base = engine.scenario(basis, "base", 30)
    arms = [("Agent-only", "agent"), ("Traditional", "human"), ("Hybrid", "hybrid")]
    for index, (_, key) in enumerate(arms):
        cap = base[key]["capacity"]
        for actual, expected in (
            ("requested", "admitted_requests"),
            ("expected_accepted", "expected_accepted"),
            ("cost_per_expected_accepted", "cost_per_accepted_at_feasible_volume"),
        ):
            audit.num(
                f"comparison/{key}/{actual}",
                figures["comparison"][actual][index],
                cap[expected],
            )
    for row in figures["duration"]:
        result = engine.scenario(basis, "base", row["productive_human_minutes"])
        for label, key in arms:
            cap = result[key]["capacity"]
            audit.num(
                f"duration/{row['productive_human_minutes']}/{key}/accepted",
                row["arms"][label]["expected_accepted_outputs"],
                cap["expected_accepted"],
            )
            audit.num(
                f"duration/{row['productive_human_minutes']}/{key}/cost",
                row["arms"][label]["cost_per_expected_accepted"],
                cap["cost_per_accepted_at_feasible_volume"],
            )
    audit.num(
        "accounts/denominator",
        figures["accounts"]["expected_accepted_denominator"],
        base["agent"]["expected_accepted"],
    )
    audit.check(
        "accounts/feasible",
        figures["accounts"]["declared_demand_feasible"],
        base["agent"]["capacity"]["declared_demand_feasible"],
    )
    for label, key in arms:
        for actual, expected in (
            ("employer_minutes", "employer_minutes"),
            ("provider_minutes", "provider_minutes"),
            ("traditional_worker_minutes", "worker_minutes"),
        ):
            audit.num(
                f"effort/{key}/{actual}",
                figures["accounts"]["human_effort_per_expected_accepted"][label][
                    actual
                ],
                base[key]["resources_per_accepted"][expected],
            )
    initial = base["agent"]["initial"]["components"]
    monthly = base["agent"]["monthly"]["components"]
    identified = total(
        initial["labor/provider/" + key]
        for key in (
            "successful_capability_construction",
            "unsuccessful_capability_construction",
            "independent_qualification",
        )
    )
    identified += 12 * total(
        monthly["labor/provider/" + key]
        for key in (
            "capability_revalidation",
            "successful_refresh",
            "unsuccessful_improvement",
        )
    )
    joint = total(
        value for key, value in initial.items() if not key.startswith("labor/")
    )
    joint += 12 * total(
        value for key, value in monthly.items() if not key.startswith("labor/")
    )
    components = {
        "identified_improvement": identified,
        "joint_service_improvement_unallocated": joint,
        "service_and_employer": base["agent"]["cohort_total_cost"] - identified - joint,
    }
    for key, value in components.items():
        audit.num(
            "accounts/" + key,
            figures["accounts"]["account_costs_per_expected_accepted"][key],
            value / base["agent"]["expected_accepted"],
        )
    report = {
        "schema": "independent-figure-data-audit/v1",
        "status": "PASS" if not audit.failures else "FAIL",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "source_sha256": sha(Path(__file__)),
        "figure_data_sha256": sha(path),
        "primary_results_sha256": figures["primary_results_sha256"],
        "independent_audit_sha256": figures["independent_audit_sha256"],
        "checks_total": audit.checks,
        "failures": audit.failures,
        "groups": audit.groups,
        "scope": "All plotted quantities recomputed using the independent Decimal oracle; layout is a separate visual review.",
    }
    target = Path(__file__).with_name("FIGURE_DATA_AUDIT.json")
    target.write_text(json.dumps(json_value(report), indent=2) + "\n")
    print(
        json.dumps(
            {"status": report["status"], "checks": audit.checks, "sha256": sha(target)}
        )
    )
    raise SystemExit(1 if audit.failures else 0)


if __name__ == "__main__":
    main()
