# SPDX-License-Identifier: Apache-2.0
"""Verify CSV exports and the separately labeled post-result reuse diagnostic."""

from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from decimal import ROUND_CEILING, Decimal
from pathlib import Path

from audit_results import Audit
from oracle import (
    EXPECTED_FREEZE,
    ROOT,
    Oracle,
    json_value,
    n,
    sha,
    transformed,
    validate_freeze,
)

OUT = Path(__file__).resolve().parent


def owner(label):
    if label.startswith("delivery."):
        return "delivery_service"
    if label.startswith("initial.employer."):
        return "employer_enablement"
    if label.startswith("initial.provider."):
        role = label.removeprefix("initial.provider.")
        return {
            "requirements_setup": "service_enablement",
            "deployment_configuration": "service_enablement",
            "approved_executor_integration": "service_enablement",
            "successful_capability_construction": "improvement_successful_construction",
            "unsuccessful_capability_construction": "improvement_unsuccessful_construction",
            "independent_qualification": "improvement_qualification",
        }[role]
    if label.startswith("monthly.employer."):
        return "employer_governance"
    if label.startswith("monthly.provider."):
        role = label.removeprefix("monthly.provider.")
        return {
            "support": "service_support",
            "runtime_dependency_maintenance": "runtime_maintenance",
            "recovery_security_upkeep": "runtime_maintenance",
            "capability_revalidation": "improvement_capability_upkeep",
            "successful_refresh": "improvement_successful_refresh",
            "unsuccessful_improvement": "improvement_unsuccessful_search",
        }[role]
    if label.startswith(("initial.", "monthly.")):
        return "joint_service_improvement_unallocated"
    raise ValueError(label)


def csv_rows(path):
    with path.open() as stream:
        return list(csv.DictReader(stream))


def compare_export(audit, path, actual, target):
    audit.check(path + "/fields", set(actual), set(target))
    for key, expected in target.items():
        value = actual[key]
        if expected is None:
            audit.check(path + "/" + key, value, "")
        elif isinstance(expected, bool):
            audit.check(path + "/" + key, value, str(expected))
        elif isinstance(expected, (int, float, Decimal)):
            audit.num(path + "/" + key, value, expected)
        else:
            audit.check(path + "/" + key, value, str(expected))


def main():
    validate_freeze()
    audit = Audit()
    x = json.loads((ROOT / "inputs.json").read_text())
    labor = json.loads((ROOT / "sources/labor_rates.json").read_text())
    result_path = ROOT / "outputs/run-001/results.json"
    results = json.loads(result_path.read_text())
    engine = Oracle(x, labor)
    bases = {b["id"]: b for b in x["price_bases"]}
    indexed = {(r["price_basis"], r["scenario"]): r for r in results["core_scenarios"]}
    file_hashes = {}
    audit.group = "csv/primary_summary"
    path = ROOT / "outputs/run-001/results_summary.csv"
    file_hashes[str(path.relative_to(ROOT))] = sha(path)
    summary = csv_rows(path)
    audit.num("summary/count", len(summary), len(results["human_duration_comparison"]))
    for index, (row, target) in enumerate(
        zip(summary, results["human_duration_comparison"])
    ):
        compare_export(audit, f"summary/{index}", row, target)
    audit.group = "csv/component_ledger"
    path = ROOT / "outputs/run-001/component_ledger.csv"
    file_hashes[str(path.relative_to(ROOT))] = sha(path)
    ledger = csv_rows(path)
    expected_ledger = {}
    for (basis, scenario), row in indexed.items():
        accounts = {
            "variable_per_requested_job": row["agent_variable"]["account"],
            "initial_investment": row["fixed_agent"]["initial"],
            "monthly_reserve": row["fixed_agent"]["monthly"],
            "annual_at_declared_demand": row["annual_at_demand"]["total_account"],
        }
        for period, account in accounts.items():
            for component, cost in account["components"].items():
                expected_ledger[(basis, scenario, period, component)] = (
                    row["currency"],
                    cost,
                    owner(component),
                )
    audit.num("ledger/count", len(ledger), len(expected_ledger))
    keys_seen = set()
    for index, row in enumerate(ledger):
        key = (row["price_basis"], row["scenario"], row["period"], row["component"])
        audit.check(f"ledger/{index}/unique", key not in keys_seen, True)
        keys_seen.add(key)
        currency, cost, ownership = expected_ledger[key]
        audit.check(f"ledger/{index}/currency", row["currency"], currency)
        audit.check(f"ledger/{index}/owner", row["ownership"], ownership)
        audit.num(f"ledger/{index}/cost", row["cost"], cost)
    audit.check("ledger/coverage", keys_seen, set(expected_ledger))
    audit.group = "csv/sensitivities"
    path = ROOT / "outputs/run-001/sensitivities.csv"
    file_hashes[str(path.relative_to(ROOT))] = sha(path)
    sensitivity_rows = csv_rows(path)
    audit.num(
        "sensitivities/count",
        len(sensitivity_rows),
        len(results["one_way_sensitivities"]),
    )
    bool_keys = {
        k
        for k, v in results["human_duration_comparison"][0].items()
        if isinstance(v, bool)
    }
    string_keys = {
        k
        for k, v in results["human_duration_comparison"][0].items()
        if isinstance(v, str)
    }
    for index, (raw, declared) in enumerate(
        zip(sensitivity_rows, results["one_way_sensitivities"])
    ):
        audit.check(f"sensitivities/{index}/driver", raw["driver"], declared["driver"])
        audit.check(
            f"sensitivities/{index}/value", raw["value"], str(declared["value"])
        )
        converted = {}
        for key, value in raw.items():
            if key in ("driver", "value"):
                continue
            if key in bool_keys:
                converted[key] = value == "True"
            elif key in string_keys:
                converted[key] = value
            else:
                converted[key] = n(value) if value else None
        varied = transformed(
            x,
            declared["driver"],
            None if declared["value"] is True else declared["value"],
        )
        data = Oracle(varied, labor).scenario(bases["US_office"], "base", 30)
        audit.flat(f"sensitivities/{index}", converted, data)
        source = declared["result"]
        split = source["annual_at_demand"]["total_account"][
            "service_improvement_totals"
        ]
        for field, ownerkey in (
            ("agent_annual_service_and_employer_cost", "service_and_employer"),
            ("agent_annual_identified_improvement_cost", "identified_improvement"),
            (
                "agent_annual_joint_service_improvement_unallocated_cost",
                "joint_service_improvement_unallocated",
            ),
        ):
            audit.num(
                f"sensitivities/{index}/" + field, converted[field], split[ownerkey]
            )
    diagnostic_path = ROOT / "outputs/post_result_reuse_diagnostic.json"
    file_hashes[str(diagnostic_path.relative_to(ROOT))] = sha(diagnostic_path)
    diagnostic = json.loads(diagnostic_path.read_text())
    audit.group = "post_result/reuse_identity"
    audit.check(
        "diagnostic/result_identity",
        diagnostic["primary_results_sha256"],
        sha(result_path),
    )
    audit.check(
        "diagnostic/freeze_identity", diagnostic["input_freeze_sha256"], EXPECTED_FREEZE
    )
    audit.check(
        "diagnostic/source_identity",
        diagnostic["source_sha256"],
        sha(ROOT / "src/reuse_diagnostic.py"),
    )
    audit.num("diagnostic/row_count", len(diagnostic["rows"]), 8)
    independent_thresholds = []
    for row in diagnostic["rows"]:
        audit.group = (
            "post_result/reuse/" + row["price_basis"] + "/" + row["comparison"]
        )
        data = engine.scenario(bases[row["price_basis"]], "base", 30)
        a, h, y = (data[key] for key in ("agent", "human", "hybrid"))
        q = a["acceptance"]
        if row["comparison"] == "agent_only_expected_accepted_cost":
            fixed_diff = a["annual_fixed"]["cost"] / q - h["annual_fixed"]["cost"]
            variable_saving = h["per_request"]["cost"] - a["per_request"]["cost"] / q
            candidate = a
        else:
            audit.check("comparison", row["comparison"], "complete_demand_hybrid")
            fixed_diff = y["annual_fixed"]["cost"] - h["annual_fixed"]["cost"]
            variable_saving = h["per_request"]["cost"] - y["per_request"]["cost"]
            candidate = y
        # All eight declared base comparisons have positive differences; no
        # unexecuted sign case is asserted to have been empirically tested.
        audit.check("positive_fixed_difference", fixed_diff > 0, True)
        audit.check("positive_variable_saving", variable_saving > 0, True)
        threshold = fixed_diff / variable_saving
        integer = int(threshold.to_integral_value(rounding=ROUND_CEILING))
        common = min(
            candidate["capacity"]["admitted_requests"],
            h["capacity"]["admitted_requests"],
        )
        numeric = {
            "productive_human_minutes_assumed": 30,
            "Q_assumed": q,
            "annual_agent_fixed_cost": a["annual_fixed"]["cost"],
            "annual_human_fixed_cost": h["annual_fixed"]["cost"],
            "annual_hybrid_fixed_cost": y["annual_fixed"]["cost"],
            "agent_variable_per_request": a["per_request"]["cost"],
            "human_variable_per_request": h["per_request"]["cost"],
            "hybrid_variable_per_request": y["per_request"]["cost"],
            "fixed_difference": fixed_diff,
            "per_request_saving": variable_saving,
            "continuous_equality_requests": threshold,
            "minimum_integer_payback_requests": integer,
            "candidate_resource_admitted_requests": candidate["capacity"][
                "admitted_requests"
            ],
            "traditional_resource_admitted_requests": h["capacity"][
                "admitted_requests"
            ],
            "common_aggregate_admitted_requests": common,
            "algebraic_equality_residual": Decimal(0),
        }
        for key, value in numeric.items():
            audit.num(key, row[key], value)
        audit.check("status", row["status"], "FINITE_MINIMUM_REUSE_THRESHOLD")
        audit.check(
            "maximum_integer_requests", row["maximum_integer_economical_requests"], None
        )
        audit.check(
            "within_both_bounds",
            row["minimum_threshold_within_both_primary_aggregate_bounds"],
            integer <= common,
        )
        audit.check(
            "within_demand",
            row["minimum_threshold_within_declared_demand"],
            integer <= a["requested"],
        )
        audit.num(
            "independent_equality_substitution",
            fixed_diff - threshold * variable_saving,
            Decimal(0),
        )
        audit.check(
            "integer_is_economical", fixed_diff <= n(integer) * variable_saving, True
        )
        audit.check(
            "preceding_integer_is_not_economical",
            fixed_diff > n(integer - 1) * variable_saving,
            True,
        )
        independent_thresholds.append(
            {
                "price_basis": row["price_basis"],
                "comparison": row["comparison"],
                "continuous": threshold,
                "integer": integer,
                "common_resource_bound": common,
                "within_both_bounds": integer <= common,
            }
        )
    report = {
        "schema": "operational-economics-derivative-audit/v1",
        "status": "PASS" if not audit.failures else "FAIL",
        "checked_utc": datetime.now(timezone.utc).isoformat(),
        "primary_result_sha256": sha(result_path),
        "primary_audit_sha256": sha(OUT / "INDEPENDENT_AUDIT.json"),
        "input_freeze_sha256": EXPECTED_FREEZE,
        "source_sha256": sha(Path(__file__)),
        "audited_file_hashes": file_hashes,
        "checks_total": audit.checks,
        "failures": audit.failures,
        "groups": audit.groups,
        "independent_reuse_thresholds": independent_thresholds,
        "classification": "CSV transcription/coverage and post-result algebraic diagnostics; no changed primary endpoint, input or scenario.",
    }
    target = OUT / "DERIVATIVE_AUDIT.json"
    target.write_text(json.dumps(json_value(report), indent=2) + "\n")
    print(
        json.dumps(
            {
                "status": report["status"],
                "checks": audit.checks,
                "failures": json_value(audit.failures),
                "sha256": sha(target),
            },
            indent=2,
        )
    )
    raise SystemExit(0 if not audit.failures else 1)


if __name__ == "__main__":
    main()
