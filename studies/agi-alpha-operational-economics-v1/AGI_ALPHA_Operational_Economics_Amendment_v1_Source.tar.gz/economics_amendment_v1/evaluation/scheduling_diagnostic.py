# SPDX-License-Identifier: Apache-2.0
"""Post-result staffing consistency diagnostic; no primary inputs are changed."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from decimal import Decimal, ROUND_CEILING
from pathlib import Path

from oracle import Oracle, ROOT, json_value, n, sha, validate_freeze


def main():
    validate_freeze()
    x = json.loads((ROOT / "inputs.json").read_text())
    labor = json.loads((ROOT / "sources/labor_rates.json").read_text())
    engine = Oracle(x, labor)
    rates = engine.rates(next(b for b in x["price_bases"] if b["id"] == "US_office"))
    rows = []
    for sid, scenario in x["scenarios"].items():
        for arm in ("agent", "traditional"):
            fixed = (
                engine.agent_fixed(scenario, rates, "initial")
                if arm == "agent"
                else engine.human_fixed(scenario, rates, "initial")
            )
            setup = n(
                scenario[
                    (
                        "setup_elapsed_workdays"
                        if arm == "agent"
                        else "human_setup_elapsed_workdays"
                    )
                ]
            )
            roles = {}
            for role, availability in (
                ("employer_minutes", "employer_available_minutes_per_workday"),
                ("provider_minutes", "provider_available_minutes_per_workday"),
                ("worker_minutes", "traditional_worker_available_minutes_per_workday"),
            ):
                initial = fixed["resources"].get(role, Decimal(0))
                uniform = n(x["resources"][availability]) * n(
                    scenario["resource_utilization"]
                )
                roles[role] = {
                    "initial_minutes": initial,
                    "implied_initial_minutes_per_declared_setup_day": initial / setup,
                    "uniform_available_minutes_per_day": uniform,
                    "minimum_setup_days_under_uniform_allocation": initial / uniform,
                    "fits_declared_setup_if_uniform": initial <= setup * uniform,
                }
            lower_bound = max(
                r["minimum_setup_days_under_uniform_allocation"] for r in roles.values()
            )
            rows.append(
                {
                    "scenario": sid,
                    "arm": arm,
                    "declared_setup_workdays": setup,
                    "role_checks": roles,
                    "minimum_workdays_uniform_role_lower_bound": lower_bound,
                    "whole_workday_lower_bound": int(
                        lower_bound.to_integral_value(rounding=ROUND_CEILING)
                    ),
                    "fits_uniform_daily_allocation": all(
                        r["fits_declared_setup_if_uniform"] for r in roles.values()
                    ),
                }
            )
    report = {
        "schema": "operational-economics-scheduling-consistency-diagnostic/v1",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "classification": "POST_RESULT_CONSISTENCY_DIAGNOSTIC_NOT_PREREGISTERED_ENDPOINT_OR_NEW_SCENARIO",
        "inputs_sha256": sha(ROOT / "inputs.json"),
        "source_sha256": sha(Path(__file__)),
        "rows": rows,
        "primary_results_changed": False,
        "interpretation": [
            "The frozen core capacity intersects annual and postdeployment aggregate resource pools. It is an aggregate resource upper bound, not a demonstrated daily staffing schedule.",
            "Treating stated minutes per workday as uniform hard daily availability exposes initial staffing requirements that exceed the declared setup calendar in the Agent arm.",
            "Treating those quantities as annual-average budgets permits frontloading only as an additional operational assumption. That frontloading policy and feasibility were not measured.",
            "First-commission setup and turnaround remain assumed and unvalidated. They must not be advertised as deliverable commitments.",
            "These role-based lower bounds ignore dependency ordering and other queues; satisfying them would not prove that a schedule exists.",
            "Traditional setup is checked by the same rule. Hybrid readiness is sequential under the frozen specification and inherits both routes' limitations.",
            "No frozen setup day, economic output, demand assumption, capacity endpoint, or prior study artifact has been altered.",
        ],
    }
    target = Path(__file__).with_name("SCHEDULING_DIAGNOSTIC.json")
    target.write_text(json.dumps(json_value(report), indent=2) + "\n")
    print(json.dumps({"path": str(target), "rows": len(rows), "sha256": sha(target)}))


if __name__ == "__main__":
    main()
