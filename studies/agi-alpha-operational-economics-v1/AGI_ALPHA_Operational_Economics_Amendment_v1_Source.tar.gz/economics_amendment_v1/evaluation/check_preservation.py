#!/usr/bin/env python3
"""Read-only integrity audit of the two earlier scientific editions.

Only this amendment's evaluation report is written. No scenario is evaluated.
"""

from __future__ import annotations

import hashlib
import json
import zipfile
from datetime import datetime, timezone
from pathlib import Path

WORKSPACE = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    checks = []

    def check(name: str, passed: bool, detail=None):
        checks.append({"check": name, "passed": bool(passed), "detail": detail})

    for name, count in (("work_economics", 69), ("capability_study", 110)):
        root = WORKSPACE / name
        freeze_path = root / "protocol/FREEZE.json"
        freeze = json.loads(freeze_path.read_text())
        check(name + "/frozen_file_count", len(freeze["files"]) == count)
        for entry in freeze["files"]:
            p = root / entry["path"]
            check(
                name + "/" + entry["path"],
                p.is_file() and sha(p) == entry["sha256"],
                {"expected_sha256": entry["sha256"]},
            )

    old_dir = WORKSPACE / "work_economics/deliverables"
    old_manifest_path = old_dir / "AGI_ALPHA_Work_Economics_SHA256SUMS.json"
    old_manifest = json.loads(old_manifest_path.read_text())
    for item in old_manifest["files"]:
        path = old_dir / item["filename"]
        check(
            "old_deliverable/" + item["filename"],
            path.is_file()
            and path.stat().st_size == item["bytes"]
            and sha(path) == item["sha256"],
            {"expected_sha256": item["sha256"]},
        )

    new_dir = WORKSPACE / "deliverables"
    new_manifest_path = new_dir / "SHA256SUMS.json"
    new_manifest = json.loads(new_manifest_path.read_text())
    for item in new_manifest["files"]:
        path = new_dir / item["path"]
        check(
            "new_deliverable/" + item["path"],
            path.is_file()
            and path.stat().st_size == item["bytes"]
            and sha(path) == item["sha256"],
            {"expected_sha256": item["sha256"]},
        )

    archive_path = new_dir / "AGI_ALPHA_Flywheel_Capability_Construction_Companion.zip"
    with zipfile.ZipFile(archive_path) as archive:
        manifest = json.loads(archive.read("SHA256SUMS.json"))
        for entry in manifest["members"]:
            if not entry["path"].startswith("capability_study/"):
                continue
            path = WORKSPACE / entry["path"]
            check(
                "sealed_source/" + entry["path"],
                path.is_file() and sha(path) == entry["sha256"],
                {"expected_sha256": entry["sha256"]},
            )

    failures = [c for c in checks if not c["passed"]]
    report = {
        "schema": "economics-amendment-preservation-audit/v1",
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "scope": "Earlier freezes, original delivery manifests and every sealed capability-study source member. Additional files do not change archived member identities.",
        "passed": not failures,
        "checks_total": len(checks),
        "failures": failures,
        "old_manifest_sha256": sha(old_manifest_path),
        "new_manifest_sha256": sha(new_manifest_path),
        "scenario_evaluation_run": False,
        "checks": checks,
    }
    (OUT / "PRESERVATION_AUDIT.json").write_text(json.dumps(report, indent=2) + "\n")
    print(
        json.dumps(
            {"passed": not failures, "checks": len(checks), "failures": failures},
            indent=2,
        )
    )
    raise SystemExit(1 if failures else 0)


if __name__ == "__main__":
    main()
