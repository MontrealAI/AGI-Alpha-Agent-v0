#!/usr/bin/env python3
"""Independent Decimal accounting primitives for the prospective amendment.

Definitions only: importing this module does not load inputs or evaluate a
scenario. The final adapter will supply independently expanded event records
after the coordinator's published-freeze execution signal.
"""

from __future__ import annotations

from decimal import Decimal, localcontext
from typing import Iterable

ZERO = Decimal(0)
ONE = Decimal(1)
PROBABILITY_TOLERANCE = Decimal("1e-12")


def number(value) -> Decimal:
    if value is None or isinstance(value, bool):
        raise ValueError("A numeric quantity cannot be null or boolean")
    result = value if isinstance(value, Decimal) else Decimal(str(value))
    if not result.is_finite():
        raise ValueError("A numeric input must be finite")
    return result


def nonnegative(value) -> Decimal:
    result = number(value)
    if result < ZERO:
        raise ValueError("A quantity, probability or price cannot be negative")
    return result


def add(values: Iterable[Decimal]) -> Decimal:
    return sum(values, ZERO)


def event_cost(events: list[dict]) -> tuple[Decimal, dict[str, Decimal]]:
    """Cost an independently expanded list of quantity × unit-price events.

    Every event has quantity, unit_price_usd and account. The adapter must use
    prices from the frozen source records, rather than producer cost subtotals.
    """
    accounts: dict[str, Decimal] = {}
    identifiers = set()
    for event in events:
        identifier = event["id"]
        if identifier in identifiers:
            raise ValueError(f"Duplicate cost-event identity: {identifier}")
        identifiers.add(identifier)
        cost = nonnegative(event["quantity"]) * nonnegative(event["unit_price_usd"])
        account = event["account"]
        accounts[account] = accounts.get(account, ZERO) + cost
    return add(accounts.values()), accounts


def complete_account(
    requested_volume,
    paths: list[dict],
    fixed_events: list[dict],
    fixed_resources: dict | None = None,
) -> dict:
    """Expand each terminal path before taking probability-weighted moments.

    Path records contain probability, accepted, events, human_minutes,
    elapsed_minutes and resources. Accepted-only latency and total resource
    burden per accepted output are deliberately distinct outputs.
    """
    with localcontext() as context:
        context.prec = 50
        volume = nonnegative(requested_volume)
        probabilities = [nonnegative(p["probability"]) for p in paths]
        if any(p > ONE for p in probabilities):
            raise ValueError("Probability exceeds one")
        if abs(add(probabilities) - ONE) > PROBABILITY_TOLERANCE:
            raise ValueError("Terminal-path probabilities must sum to one")
        accepted = []
        for p in paths:
            if not isinstance(p["accepted"], bool):
                raise ValueError("Accepted-path indicator must be boolean")
            accepted.append(ONE if p["accepted"] else ZERO)
        costs = [event_cost(p["events"])[0] for p in paths]
        labor = [nonnegative(p["human_minutes"]) for p in paths]
        elapsed = [nonnegative(p["elapsed_minutes"]) for p in paths]
        q = add(p * a for p, a in zip(probabilities, accepted))
        expected_cost = add(p * c for p, c in zip(probabilities, costs))
        expected_labor = add(p * h for p, h in zip(probabilities, labor))
        expected_elapsed = add(p * t for p, t in zip(probabilities, elapsed))
        accepted_elapsed = add(
            p * a * t for p, a, t in zip(probabilities, accepted, elapsed)
        )
        fixed_cost, fixed_accounts = event_cost(fixed_events)
        deliveries = volume * q
        total = volume * expected_cost + fixed_cost
        resource_names = sorted({k for p in paths for k in p["resources"]})
        fixed_resources = fixed_resources or {}
        expected_resources = {
            name: add(
                prob * nonnegative(path["resources"].get(name, ZERO))
                for prob, path in zip(probabilities, paths)
            )
            for name in resource_names
        }
        result = {
            "qualified_probability": q,
            "expected_variable_cost_per_request": expected_cost,
            "expected_human_minutes_per_request": expected_labor,
            "unconditional_elapsed_minutes_per_request": expected_elapsed,
            "accepted_conditional_elapsed_minutes": accepted_elapsed / q if q else None,
            "fixed_cost": fixed_cost,
            "fixed_cost_accounts": fixed_accounts,
            "requested_volume": volume,
            "expected_accepted_deliveries": deliveries,
            "total_cost": total,
            "cost_per_accepted_deliverable": total / deliveries if deliveries else None,
            "variable_cost_per_accepted_deliverable": expected_cost / q if q else None,
            "fixed_cost_per_accepted_deliverable": (
                fixed_cost / deliveries if deliveries else None
            ),
            "total_variable_human_minutes_per_accepted": (
                expected_labor / q if q else None
            ),
            "expected_resources_per_request": expected_resources,
            "total_resources": {
                name: volume * expected_resources.get(name, ZERO)
                + nonnegative(fixed_resources.get(name, ZERO))
                for name in sorted(set(expected_resources) | set(fixed_resources))
            },
            "path_costs": costs,
        }
        if deliveries:
            assert result["cost_per_accepted_deliverable"] == (
                result["variable_cost_per_accepted_deliverable"]
                + result["fixed_cost_per_accepted_deliverable"]
            ) or abs(
                result["cost_per_accepted_deliverable"]
                - result["variable_cost_per_accepted_deliverable"]
                - result["fixed_cost_per_accepted_deliverable"]
            ) < Decimal(
                "1e-40"
            )
        return result


def break_even_human_minutes(agent_cost, human_intercept, human_slope) -> dict:
    """Solve alpha*t + beta = Agent cost without rounding/clamping the root."""
    agent = nonnegative(agent_cost)
    intercept = nonnegative(human_intercept)
    slope = nonnegative(human_slope)
    if not slope:
        return {
            "minutes": None,
            "status": "HUMAN_COST_INDEPENDENT_OF_DURATION",
            "agent_minus_human": agent - intercept,
        }
    root = (agent - intercept) / slope
    return {
        "minutes": root,
        "nonnegative_threshold_minutes": max(ZERO, root),
        "status": "NEGATIVE_ALGEBRAIC_ROOT" if root < ZERO else "FINITE_THRESHOLD",
        "substitution_residual": slope * root + intercept - agent,
    }


def finite_capacity(
    demand_requests,
    qualified_probability,
    budget_usd,
    fixed_cost_usd,
    variable_cost_per_request_usd,
    available_resources: dict,
    fixed_resources: dict,
    resources_per_request: dict,
) -> dict:
    """Intersect resource constraints; output is expected divisible throughput.

    The caller retains each resource's unit and pool owner. Fixed consumption
    comes from the same pool only when that ownership is explicitly declared.
    """
    demand = nonnegative(demand_requests)
    q = nonnegative(qualified_probability)
    if q > ONE:
        raise ValueError("Qualified probability exceeds one")
    budget = nonnegative(budget_usd)
    fixed_cost = nonnegative(fixed_cost_usd)
    variable_cost = nonnegative(variable_cost_per_request_usd)
    ceilings = {"demand": demand}
    infeasible_fixed = []
    if fixed_cost > budget:
        infeasible_fixed.append("budget_usd")
        ceilings["budget_usd"] = ZERO
    elif variable_cost:
        ceilings["budget_usd"] = (budget - fixed_cost) / variable_cost
    for resource, available in available_resources.items():
        available = nonnegative(available)
        fixed = nonnegative(fixed_resources.get(resource, ZERO))
        per_request = nonnegative(resources_per_request.get(resource, ZERO))
        if fixed > available:
            infeasible_fixed.append(resource)
            ceilings[resource] = ZERO
        elif per_request:
            ceilings[resource] = (available - fixed) / per_request
    request_capacity = min(ceilings.values())
    binding = [
        name for name, ceiling in ceilings.items() if ceiling == request_capacity
    ]
    return {
        "expected_request_capacity": request_capacity,
        "expected_accepted_capacity": request_capacity * q,
        "binding_constraints": binding,
        "constraint_request_ceilings": ceilings,
        "fixed_resource_infeasible": infeasible_fixed,
        "unused_budget_usd": budget - fixed_cost - request_capacity * variable_cost,
        "scope": "Expected resource-constrained capacity, not a guaranteed integer service commitment",
    }
