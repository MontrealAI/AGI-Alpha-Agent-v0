# Independent evaluation of the operational economics amendment

The primary numerical audit passed **157,435 checks** with no remaining
discrepancies. The derivative audit passed **24,125 checks**, including all
5,064 component-ledger CSV rows and the eight separately labeled reuse
threshold diagnostics. These checks establish consistency with the frozen
scenario specification. They do not establish observed field costs,
commercial acceptance probabilities, human completion times or provider bills.

## Evidence and timing

`EVALUATION_PLAN.md` and `PREFREEZE_REVIEW.json` were included in the separate
16-file prospective freeze. The prefreeze review performed 61 structural,
identity and source checks, with no scenario results. The earlier editions
were also checked against their original freezes, delivery manifests and
sealed source archive: 5,102 preservation checks passed.

The public freeze is recorded in `../FREEZE.json`; the execution signal is
recorded in `../AUTHORIZATION.json`. The independent numerical expansion
started after that signal. `oracle.py` uses Decimal arithmetic at precision
50, reads the frozen specification directly, and does not import or call the
analyst's model.

`INDEPENDENT_RESULTS.json` retains the independently calculated event costs,
branch outcomes, fixed accounts, human-duration comparisons, latency atoms,
capacity pools and one-way sensitivities. Numeric strings retain Decimal
precision. `INDEPENDENT_AUDIT.json` binds the exact producer results and source
hashes to the independent comparison, with checks grouped by case.
`DERIVATIVE_AUDIT.json` binds the CSV exports and post-result reuse diagnostic
to their checked identities.

## Findings that constrain interpretation

The primary U.S. office/administrative base scenario, at the declared annual
volume of 1,000 requests, gives approximately $28.91 per expected accepted
Agent output, $28.42 per completed traditional output at the assumed
30-minute productive duration, and $29.73 per completed hybrid output.
These values include fixed enablement and improvement costs and all
unsuccessful paths. The traditional productive duration is an assumption,
not a newly observed human result.

That declared volume exceeds the $25,000 expected-cost resource budget.
The Agent admits 829 requests, corresponding to 787.55 expected accepted
outputs and about $31.74 per expected accepted output. The traditional arm
admits 876 requests and the complete-demand hybrid 703. Conservative and
stress Agent scenarios retain their fixed losses and admit no requests
under the specified budget and provider-time pools. These unfavorable
results remain in the data.

At the declared base volume, the Agent's total modeled human labor is
33.20 minutes per expected accepted output, comprising 19.3263 employer
minutes and 13.8737 provider minutes. The traditional arm uses 47.10 total
minutes, including 15.82 employer minutes. Reduced total human labor
therefore does not imply reduced employer attention in this scenario.

The post-result `SCHEDULING_DIAGNOSTIC.json` is a consistency check, not a
new preregistered scenario or a change to the primary analysis. Under a
uniform interpretation of the stated daily availability, initial provider
work requires at least 45, 160 and 490 workdays in the three Agent scenarios,
against declared setup calendars of 10, 30 and 60. Treating daily quantities
as annual averages may permit frontloading, but no actual staffing schedule
or frontloading policy was demonstrated. Traditional setup is checked by
the same rule; its stress case also exceeds its uniform employer-allocation
window. First-commission setup delays remain assumed and unvalidated.

Capacity uses expected path consumption. A cohort close to the mean budget
can exceed it when realized requests follow more expensive paths. The
capacity values are expected-use aggregate planning ceilings, not hard
stochastic budget guarantees or deployed executor throughput. No paid-call
budget enforcement was deployed. Previously tested native work-unit
controls do not establish a financial guard for this prospective service.

The post-result reuse diagnostic solves the fixed-plus-variable equality
algebraically for the existing base cases. None of its eight integer reuse
thresholds fits both arms' same-request-cohort resource bounds. This does
not negate comparisons at different admitted cohort sizes; it prevents
assuming a common reuse volume that one of the compared arms cannot serve
within the specified resource budget.

Historical authoring costs, actual field attention, actual complete Agent
costs and downstream losses remain unknown. High-consequence decisions are
outside the supported scope. The audit never converts these unknowns to zero.

## Reproduction

Run from the amendment directory in a working copy:

```bash
python evaluation/oracle.py --run
python evaluation/audit_results.py --results outputs/run-001/results.json
python evaluation/audit_derivatives.py
python evaluation/scheduling_diagnostic.py
```

The scripts require only the Python standard library. They verify the frozen
input hashes and authorization before calculating. Reproduction writes new
timestamped audit evidence; preserve the released evidence when exact archive
identities are required. The independent oracle's numeric content is
deterministic, while report timestamps are intentionally not constant.

`check_preservation.py` is optional and requires the separately supplied
earlier editions in their original workspace-relative locations. It is not
needed to reproduce the amendment's scenario arithmetic.

## Preserved development and corrections

`ORACLE_ATTEMPTS.jsonl` records the independent calculation. The first full
producer comparison is preserved in `audit_attempts/attempt-001.json`.
It flagged 73 evaluator-adapter mismatches: 50 truthful null-status labels
used a different enum spelling, and 23 frozen one-way sensitivities correctly
used only the reference 30-minute duration rather than all five durations.
No economic or resource arithmetic discrepancy was found. The corrected
adapter and successful second audit are preserved alongside
`AUDIT_CORRECTIONS.json`; neither producer results nor frozen inputs changed.

`equations.py` is an unselected prefreeze prototype containing generic
accounting definitions. It was not used to produce any reported scenario
result. The executed implementation is `oracle.py`.
