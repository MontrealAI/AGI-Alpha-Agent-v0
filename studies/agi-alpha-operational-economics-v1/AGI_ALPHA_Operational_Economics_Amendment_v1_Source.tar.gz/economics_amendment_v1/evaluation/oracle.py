# SPDX-License-Identifier: Apache-2.0
"""Independent Decimal expansion of the frozen operational-cost specification.

This implementation reads inputs, prices, and authorization only. It never
imports or calls the analyst's model. All outputs remain scenario calculations.
Run only after the published freeze; every run records its source identity.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import traceback
from datetime import datetime, timezone
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR, getcontext
from pathlib import Path

getcontext().prec = 50
D = Decimal
ZERO, ONE = D(0), D(1)
ROOT = Path(__file__).resolve().parents[1]
OUT = Path(__file__).resolve().parent
EXPECTED_FREEZE = "54bc70fec9bb635b473193d966d36ed5bf445460a58255f025cbed4a30854d8b"
RESOURCES = (
    "employer_minutes",
    "provider_minutes",
    "worker_minutes",
    "occupied_seconds",
    "input_tokens",
    "output_tokens",
    "billed_seconds",
    "executor_requests",
    "search_calls",
    "model_calls",
    "production_attempts",
    "native_invocations",
)


def n(value):
    if isinstance(value, bool) or value is None:
        raise ValueError("Null/boolean is not a numeric quantity")
    return value if isinstance(value, D) else D(str(value))


def total(values):
    return sum(values, ZERO)


def scaled(items, factor):
    return {k: n(v) * n(factor) for k, v in items.items()}


def merged(*items):
    answer = {}
    for item in items:
        for k, v in item.items():
            answer[k] = answer.get(k, ZERO) + n(v)
    return answer


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def json_value(value):
    if isinstance(value, D):
        # Precision is retained in Decimal strings in the independent evidence.
        return str(value)
    if isinstance(value, dict):
        return {k: json_value(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_value(v) for v in value]
    return value


def validate_freeze():
    freeze_path = ROOT / "FREEZE.json"
    assert sha(freeze_path) == EXPECTED_FREEZE, "Unexpected frozen manifest"
    freeze = json.loads(freeze_path.read_text())
    auth = json.loads((ROOT / "AUTHORIZATION.json").read_text())
    assert auth["freeze_sha256"] == EXPECTED_FREEZE
    assert auth["status"] == "GO_FOR_LOCAL_SCENARIO_CALCULATION_AND_INDEPENDENT_AUDIT"
    assert len(freeze["files"]) == 16
    for entry in freeze["files"]:
        assert sha(ROOT / entry["path"]) == entry["sha256"], entry["path"]
    return freeze, auth


def quantile(atoms, percentile):
    mass = total(a["probability"] for a in atoms)
    if mass == 0:
        return None
    cumulative = ZERO
    for atom in sorted(atoms, key=lambda z: z["minutes"]):
        cumulative += atom["probability"]
        if cumulative >= n(percentile) * mass:
            return atom["minutes"]
    raise AssertionError("Quantile mass is inconsistent")


def latency_summary(atoms):
    mass = total(a["probability"] for a in atoms)
    return {
        "mean_minutes": (
            total(a["probability"] * a["minutes"] for a in atoms) / mass
            if mass
            else None
        ),
        "median_minutes": quantile(atoms, "0.5"),
        "p95_minutes": quantile(atoms, "0.95"),
        "worst_minutes": max((a["minutes"] for a in atoms), default=None),
        "atoms": atoms,
    }


class Oracle:
    def __init__(self, inputs, labor):
        self.x = inputs
        self.labor = {r["id"]: r for r in labor["rates"]}

    def rates(self, basis):
        currency = basis["currency"]
        eur_usd = n(self.x["fx"]["USD_per_EUR"])
        cad_eur = n(self.x["fx"]["CAD_per_EUR"])
        usd_local = {"USD": ONE, "EUR": ONE / eur_usd, "CAD": cad_eur / eur_usd}[
            currency
        ]
        rate = self.labor[basis["labor_rate_id"]]
        assert rate["currency"] == currency
        employer = n(rate["rate_per_hour"]) * n(basis["employer_load_multiplier"])
        p = self.x["provider_labor"]
        provider = (
            n(self.labor[p["labor_rate_id"]]["rate_per_hour"])
            * n(p["employer_load_multiplier"])
            * usd_local
        )
        return {
            "usd_local": usd_local,
            "employer_hour": employer,
            "worker_hour": employer,
            "provider_hour": provider,
        }

    def model_money(self, usages, factor, usd_local):
        components = {}
        inputs = outputs = calls = ZERO
        for route, usage in usages.items():
            inp = n(usage["input_tokens"]) * factor
            out = n(usage["output_tokens"]) * factor
            prices = self.x["model_prices"][route]
            components["model_input/" + route] = (
                inp * n(prices["input_usd_per_million"]) * usd_local / D(1000000)
            )
            components["model_output/" + route] = (
                out * n(prices["output_usd_per_million"]) * usd_local / D(1000000)
            )
            inputs += inp
            outputs += out
            calls += n(usage.get("calls", 0))
        return components, inputs, outputs, calls

    def compute_money(self, occupied, requests, usd_local):
        cloud = self.x["cloud"]
        if not requests:
            assert occupied == 0
            billed = ZERO
        else:
            quantum = n(cloud["billing_rounding_seconds"])
            billed = (
                (occupied / requests / quantum).to_integral_value(
                    rounding=ROUND_CEILING
                )
                * quantum
                * requests
            )
        return {
            "executor_cpu": billed
            * n(cloud["vcpus"])
            * n(cloud["active_vcpu_second_usd"])
            * usd_local,
            "executor_memory": billed
            * n(cloud["memory_gib"])
            * n(cloud["active_gib_second_usd"])
            * usd_local,
            "executor_requests": requests
            * n(cloud["requests_per_million_usd"])
            * usd_local
            / D(1000000),
        }, billed

    @staticmethod
    def apply_tax(components, s):
        nonlabor = total(v for k, v in components.items() if not k.startswith("labor/"))
        return merged(
            components,
            {
                "tax_allowance": nonlabor
                * n(s["nonrecoverable_nontechnical_tax_allowance_fraction"])
            },
        )

    def event(self, event_id, s, rates):
        event = self.x["events"][event_id]
        mult = s["delivery_multipliers"]
        employer = total(n(v) for v in event["employer_minutes"].values()) * n(
            mult["human_minutes"]
        )
        provider = n(event["provider_operator_minutes"]) * n(mult["human_minutes"])
        occupied = n(event["executor_occupied_seconds"]) * n(mult["executor_occupancy"])
        requests = n(event["executor_requests"])
        model, inp, out, calls = self.model_money(
            event["model_usage"], n(mult["model_tokens"]), rates["usd_local"]
        )
        compute, billed = self.compute_money(occupied, requests, rates["usd_local"])
        search = n(event["successful_web_search_calls"])
        components = merged(
            model,
            compute,
            {
                "labor/employer": employer * rates["employer_hour"] / D(60),
                "labor/provider": provider * rates["provider_hour"] / D(60),
                "search": search
                * n(self.x["web_search_usd_per_1000"])
                * rates["usd_local"]
                / D(1000),
            },
        )
        resources = {
            "employer_minutes": employer,
            "provider_minutes": provider,
            "worker_minutes": ZERO,
            "occupied_seconds": occupied,
            "billed_seconds": billed,
            "executor_requests": requests,
            "input_tokens": inp,
            "output_tokens": out,
            "model_calls": calls,
            "search_calls": search,
            "production_attempts": n(event["production_attempts"]),
            "native_invocations": n(event["native_invocations"]),
        }
        elapsed = (
            employer
            + provider
            + (occupied + n(event["external_wait_seconds"]) * n(mult["external_wait"]))
            / D(60)
        )
        return {
            "event_id": event_id,
            "components_before_tax": components,
            "resources": resources,
            "elapsed_minutes": elapsed,
        }

    def branches(self, s, rates):
        storage = self.x["storage"]
        artifact = (
            n(s["artifact_gib_per_request"])
            * n(storage["artifact_copies"])
            * n(storage["artifact_retention_days"])
            * n(storage["hours_per_day"])
            * n(storage["gib_hour_usd"])
            * rates["usd_local"]
        )
        per_request = {
            "artifact_storage": artifact,
            "operations_egress": n(s["operations_egress_allowance_usd_per_request"])
            * rates["usd_local"],
        }
        answer = {}
        for bid, b in self.x["branches"].items():
            reached = [self.event(e, s, rates) for e in b["events"]]
            costs = self.apply_tax(
                merged(per_request, *(e["components_before_tax"] for e in reached)), s
            )
            resources = merged(*(e["resources"] for e in reached))
            answer[bid] = {
                "accepted": b["accepted"],
                "probability": n(s["branch_weights"][bid]),
                "event_occurrences": reached,
                "components": costs,
                "cost": total(costs.values()),
                "resources": resources,
                "elapsed_minutes": total(e["elapsed_minutes"] for e in reached),
            }
        return answer

    def agent_fixed(self, s, rates, prefix):
        provider = {
            "labor/provider/" + key: n(hours) * rates["provider_hour"]
            for key, hours in s[prefix + "_provider_hours"].items()
        }
        employer = {
            "labor/employer/" + key: n(hours) * rates["employer_hour"]
            for key, hours in s[prefix + "_employer_hours"].items()
        }
        model, inp, out, calls = self.model_money(
            s[prefix + "_model_tokens"], ONE, rates["usd_local"]
        )
        occupied = n(s[prefix + "_executor_seconds"])
        requests = n(s[prefix + "_executor_requests"])
        compute, billed = self.compute_money(occupied, requests, rates["usd_local"])
        search = n(s[prefix + "_search_calls"])
        components = merged(
            provider,
            employer,
            model,
            compute,
            {
                "search": search
                * n(self.x["web_search_usd_per_1000"])
                * rates["usd_local"]
                / D(1000)
            },
        )
        if prefix == "monthly":
            storage = self.x["storage"]
            components = merged(
                components,
                {
                    "allowance/" + k: n(v) * rates["usd_local"]
                    for k, v in s["monthly_cash_allowances_usd"].items()
                },
                {
                    "shared_storage": n(s["shared_storage_gib"])
                    * n(storage["calendar_days_per_operating_month"])
                    * n(storage["hours_per_day"])
                    * n(storage["gib_hour_usd"])
                    * rates["usd_local"]
                },
            )
        components = self.apply_tax(components, s)
        return {
            "components": components,
            "cost": total(components.values()),
            "resources": {
                "provider_minutes": D(60)
                * total(n(v) for v in s[prefix + "_provider_hours"].values()),
                "employer_minutes": D(60)
                * total(n(v) for v in s[prefix + "_employer_hours"].values()),
                "worker_minutes": ZERO,
                "input_tokens": inp,
                "output_tokens": out,
                "occupied_seconds": occupied,
                "billed_seconds": billed,
                "executor_requests": requests,
                "search_calls": search,
            },
        }

    def human_fixed(self, s, rates, prefix):
        if prefix == "initial":
            worker = n(s["human_initial_worker_setup_hours"]) * D(60)
            employer = n(s["human_initial_employer_onboarding_hours"]) * D(60)
            components = {}
        else:
            worker = n(s["human_monthly_worker_template_support_hours"]) * D(60)
            employer = n(s["human_monthly_employer_governance_hours"]) * D(60)
            components = {
                "ordinary_software_IT": n(s["human_monthly_software_IT_allowance_usd"])
                * rates["usd_local"]
            }
        components = self.apply_tax(
            merged(
                components,
                {
                    "labor/worker": worker * rates["worker_hour"] / D(60),
                    "labor/employer": employer * rates["employer_hour"] / D(60),
                },
            ),
            s,
        )
        return {
            "components": components,
            "cost": total(components.values()),
            "resources": {
                "worker_minutes": worker,
                "employer_minutes": employer,
                "provider_minutes": ZERO,
                "occupied_seconds": ZERO,
                "input_tokens": ZERO,
                "output_tokens": ZERO,
            },
        }

    def human_variable(self, s, rates, t):
        traditional = self.x["traditional"]
        hm = n(s["delivery_multipliers"]["human_minutes"])
        employer_common = (
            total(n(v) for v in traditional["common_employer_minutes"].values()) * hm
        )
        rereview = n(traditional["rereview_employer_minutes_if_correction"]) * hm
        prob = n(s["human_correction_probability"])
        correction = n(s["human_correction_minutes"])
        employer = employer_common + prob * rereview
        worker = n(t) + prob * correction
        components = {
            "labor/employer": employer * rates["employer_hour"] / D(60),
            "labor/worker": worker * rates["worker_hour"] / D(60),
        }
        queue = (
            n(traditional["queue_wait_seconds"])
            * n(s["delivery_multipliers"]["external_wait"])
            / D(60)
        )
        atoms = [
            {
                "label": "no_correction",
                "probability": ONE - prob,
                "minutes": employer_common + n(t) + queue,
            },
            {
                "label": "correction",
                "probability": prob,
                "minutes": employer_common + n(t) + correction + rereview + queue,
            },
        ]
        return {
            "components": components,
            "cost": total(components.values()),
            "resources": {
                "worker_minutes": worker,
                "employer_minutes": employer,
                "provider_minutes": ZERO,
                "occupied_seconds": ZERO,
                "input_tokens": ZERO,
                "output_tokens": ZERO,
            },
            "latency": latency_summary(atoms),
        }

    @staticmethod
    def combined_fixed(initial, monthly, months):
        components = merged(
            initial["components"], scaled(monthly["components"], months)
        )
        return {
            "cost": total(components.values()),
            "components": components,
            "resources": merged(
                initial["resources"], scaled(monthly["resources"], months)
            ),
        }

    def capacity(
        self, s, rates, demand, per, fixed_initial, fixed_monthly, fixed_annual, setup
    ):
        x = self.x
        r = x["resources"]
        utilization = n(s["resource_utilization"])
        days = n(x["horizons"]["working_days"])
        months = n(x["horizons"]["annual_operating_months"])
        postdays = max(ZERO, days - n(setup))
        perday = {
            "employer_minutes": n(r["employer_available_minutes_per_workday"]),
            "provider_minutes": n(r["provider_available_minutes_per_workday"]),
            "worker_minutes": n(r["traditional_worker_available_minutes_per_workday"]),
            "occupied_seconds": n(x["horizons"]["working_hours_per_day"])
            * D(3600)
            * n(x["cloud"]["parallel_executor_instances"]),
        }
        residual = {
            "money": n(r["annual_full_economic_budget_usd"]) * rates["usd_local"]
            - fixed_annual["cost"]
        }
        details = {}
        for key, amount in perday.items():
            annual = (
                days * amount * utilization
                - fixed_initial["resources"].get(key, ZERO)
                - months * fixed_monthly["resources"].get(key, ZERO)
            )
            post = postdays * amount * utilization - months * fixed_monthly[
                "resources"
            ].get(key, ZERO)
            residual[key] = min(annual, post)
            details[key] = {
                "annual": annual,
                "postdeployment": post,
                "raw_effective": residual[key],
            }
        for key, budget_key in (
            ("input_tokens", "annual_input_token_budget"),
            ("output_tokens", "annual_output_token_budget"),
        ):
            residual[key] = n(r[budget_key]) * utilization - fixed_annual[
                "resources"
            ].get(key, ZERO)
        ceilings = {"demand": n(demand)}
        usage = dict(per["resources"], money=per["cost"])
        for key, remain in residual.items():
            if remain < 0:
                ceilings[key] = ZERO
            elif usage.get(key, ZERO) > 0:
                ceilings[key] = remain / usage[key]
        minimum = min(ceilings.values())
        admitted = int(max(ZERO, minimum).to_integral_value(rounding=ROUND_FLOOR))
        return {
            "admitted_requests": admitted,
            "binding_constraints": [k for k, v in ceilings.items() if v == minimum],
            "request_ceilings": ceilings,
            "raw_residuals_after_fixed": residual,
            "time_pool_details": details,
            "fixed_infeasible_resources": [k for k, v in residual.items() if v < 0],
            "residuals_after_admission": {
                k: v - n(admitted) * usage.get(k, ZERO) for k, v in residual.items()
            },
            "declared_demand_feasible": admitted >= demand,
        }

    def account(self, s, rates, demand, q, per, initial, monthly, setup):
        annual = self.combined_fixed(
            initial, monthly, n(self.x["horizons"]["annual_operating_months"])
        )
        first_fixed = self.combined_fixed(
            initial, monthly, n(self.x["horizons"]["first_commission_operating_months"])
        )
        volume = n(demand)
        accepted = volume * q
        cohort = annual["cost"] + volume * per["cost"]
        resources = merged(annual["resources"], scaled(per["resources"], volume))
        cap = self.capacity(s, rates, demand, per, initial, monthly, annual, setup)
        admitted = n(cap["admitted_requests"])
        cap.update(
            {
                "expected_accepted": admitted * q,
                "total_cost_at_feasible_volume": annual["cost"]
                + admitted * per["cost"],
                "cost_per_accepted_at_feasible_volume": (
                    (annual["cost"] + admitted * per["cost"]) / (admitted * q)
                    if admitted * q
                    else None
                ),
            }
        )
        first = first_fixed["cost"] + per["cost"]
        return {
            "acceptance": q,
            "requested": volume,
            "expected_accepted": accepted,
            "unresolved_expected": volume * (ONE - q),
            "per_request": per,
            "initial": initial,
            "monthly": monthly,
            "annual_fixed": annual,
            "cohort_total_cost": cohort,
            "cost_per_requested": cohort / volume if volume else None,
            "cost_per_accepted": cohort / accepted if accepted else None,
            "marginal_cost_per_accepted": per["cost"] / q if q else None,
            "fixed_cost_per_accepted": annual["cost"] / accepted if accepted else None,
            "cohort_resources": resources,
            "resources_per_accepted": (
                {k: v / accepted for k, v in resources.items()} if accepted else None
            ),
            "first_commission_total_cost": first,
            "first_commission_cost_per_expected_accepted": first / q if q else None,
            "first_commission_resources": merged(
                first_fixed["resources"], per["resources"]
            ),
            "setup_elapsed_minutes": n(setup)
            * n(self.x["horizons"]["working_hours_per_day"])
            * D(60),
            "capacity": cap,
        }

    def scenario(self, basis, scenario_id, t):
        s = self.x["scenarios"][scenario_id]
        rates = self.rates(basis)
        paths = self.branches(s, rates)
        q = total(b["probability"] for b in paths.values() if b["accepted"])
        components = merged(
            *(scaled(b["components"], b["probability"]) for b in paths.values())
        )
        resources = merged(
            *(scaled(b["resources"], b["probability"]) for b in paths.values())
        )
        per = {
            "components": components,
            "cost": total(components.values()),
            "resources": resources,
        }
        ai = self.agent_fixed(s, rates, "initial")
        am = self.agent_fixed(s, rates, "monthly")
        hi = self.human_fixed(s, rates, "initial")
        hm = self.human_fixed(s, rates, "monthly")
        human_per = self.human_variable(s, rates, t)
        agent = self.account(
            s, rates, s["requested_demand"], q, per, ai, am, s["setup_elapsed_workdays"]
        )
        human = self.account(
            s,
            rates,
            s["requested_demand"],
            ONE,
            human_per,
            hi,
            hm,
            s["human_setup_elapsed_workdays"],
        )
        failure = ONE - q
        handoff = n(s["hybrid_handoff_employer_minutes"])
        handoff_cost = handoff * rates["employer_hour"] / D(60)
        hybrid_per = {
            "components": merged(
                per["components"],
                scaled(human_per["components"], failure),
                {"labor/handoff": failure * handoff_cost},
            ),
            "resources": merged(
                per["resources"],
                scaled(human_per["resources"], failure),
                {"employer_minutes": failure * handoff},
            ),
        }
        hybrid_per["cost"] = total(hybrid_per["components"].values())
        hybrid_initial = {
            "components": merged(ai["components"], hi["components"]),
            "resources": merged(ai["resources"], hi["resources"]),
            "cost": ai["cost"] + hi["cost"],
        }
        hybrid_monthly = {
            "components": merged(am["components"], hm["components"]),
            "resources": merged(am["resources"], hm["resources"]),
            "cost": am["cost"] + hm["cost"],
        }
        hybrid = self.account(
            s,
            rates,
            s["requested_demand"],
            ONE,
            hybrid_per,
            hybrid_initial,
            hybrid_monthly,
            n(s["setup_elapsed_workdays"]) + n(s["human_setup_elapsed_workdays"]),
        )
        atoms = [
            {
                "label": bid,
                "probability": b["probability"],
                "minutes": b["elapsed_minutes"],
            }
            for bid, b in paths.items()
        ]
        accepted_atoms = [a for a in atoms if paths[a["label"]]["accepted"]]
        failed_atoms = [a for a in atoms if not paths[a["label"]]["accepted"]]
        hybrid_atoms = []
        for a in atoms:
            if paths[a["label"]]["accepted"]:
                hybrid_atoms.append(a)
            else:
                for h in human_per["latency"]["atoms"]:
                    hybrid_atoms.append(
                        {
                            "label": a["label"] + "/" + h["label"],
                            "probability": a["probability"] * h["probability"],
                            "minutes": a["minutes"] + handoff + h["minutes"],
                        }
                    )
        agent["latency_all"] = latency_summary(atoms)
        agent["latency_accepted"] = latency_summary(accepted_atoms)
        agent["latency_failed"] = latency_summary(failed_atoms)
        human["latency_all"] = human_per["latency"]
        hybrid["latency_all"] = latency_summary(hybrid_atoms)
        failure_cost = total(
            b["probability"] * b["cost"] for b in paths.values() if not b["accepted"]
        )
        agent["failed_cost_per_request"] = failure_cost
        agent["failed_cost_per_accepted"] = failure_cost / q if q else None
        agent["failed_share_of_variable_cost"] = (
            failure_cost / per["cost"] if per["cost"] else None
        )
        hzero = self.human_variable(s, rates, ZERO)
        human_intercept = (
            human["annual_fixed"]["cost"] / n(s["requested_demand"]) + hzero["cost"]
        )
        slope = rates["worker_hour"] / D(60)
        agent_star = (agent["cost_per_accepted"] - human_intercept) / slope
        hybrid_intercept = (
            hybrid["annual_fixed"]["cost"] / n(s["requested_demand"])
            + per["cost"]
            + failure * (handoff_cost + hzero["cost"])
        )
        hybrid_slope = failure * slope
        hybrid_star = (
            (hybrid_intercept - human_intercept) / (slope - hybrid_slope)
            if slope > hybrid_slope
            else None
        )
        ancillary_human_minutes = total(
            human["annual_fixed"]["resources"].get(k, ZERO)
            for k in ("employer_minutes", "worker_minutes")
        ) / n(s["requested_demand"]) + total(
            hzero["resources"].get(k, ZERO)
            for k in ("employer_minutes", "worker_minutes")
        )
        break_even = {
            "human_intercept": human_intercept,
            "human_cost_slope_per_productive_minute": slope,
            "pure_agent_productive_minutes": agent_star,
            "pure_agent_human_all_in_minutes": ancillary_human_minutes + agent_star,
            "pure_agent_substitution_residual": human_intercept
            + slope * agent_star
            - agent["cost_per_accepted"],
            "hybrid_intercept": hybrid_intercept,
            "hybrid_slope": hybrid_slope,
            "hybrid_productive_minutes": hybrid_star,
            "hybrid_human_all_in_minutes": (
                ancillary_human_minutes + hybrid_star
                if hybrid_star is not None
                else None
            ),
            "hybrid_substitution_residual": (
                human_intercept
                + slope * hybrid_star
                - hybrid_intercept
                - hybrid_slope * hybrid_star
                if hybrid_star is not None
                else None
            ),
        }
        return {
            "basis": basis["id"],
            "scenario": scenario_id,
            "currency": basis["currency"],
            "t": n(t),
            "rates": rates,
            "paths": paths,
            "agent": agent,
            "human": human,
            "hybrid": hybrid,
            "break_even": break_even,
        }


def transformed(inputs, name, factor=None):
    x = copy.deepcopy(inputs)
    s = x["scenarios"]["base"]
    f = n(factor) if factor is not None else ONE
    if name == "requested_reuse_volume":
        s["requested_demand"] = factor
    elif name == "delivery_model_token_multiplier":
        s["delivery_multipliers"]["model_tokens"] = (
            n(s["delivery_multipliers"]["model_tokens"]) * f
        )
    elif name == "employer_review_effort_multiplier":
        fields = {
            "independent_review",
            "independent_rereview",
            "challenge_adjudication",
            "rejection_review",
            "refusal_review",
        }
        for e in x["events"].values():
            for key in e["employer_minutes"]:
                if key in fields:
                    e["employer_minutes"][key] = n(e["employer_minutes"][key]) * f
        x["traditional"]["common_employer_minutes"]["independent_review"] = (
            n(x["traditional"]["common_employer_minutes"]["independent_review"]) * f
        )
        x["traditional"]["rereview_employer_minutes_if_correction"] = (
            n(x["traditional"]["rereview_employer_minutes_if_correction"]) * f
        )
    elif name == "unsuccessful_initial_construction_human_hours_multiplier":
        key = "unsuccessful_capability_construction"
        s["initial_provider_hours"][key] = n(s["initial_provider_hours"][key]) * f
    elif name == "recurring_support_and_upkeep_multiplier":
        for key in (
            "monthly_provider_hours",
            "monthly_employer_hours",
            "monthly_cash_allowances_usd",
        ):
            s[key] = scaled(s[key], f)
        for tokens in s["monthly_model_tokens"].values():
            for key in tokens:
                tokens[key] = n(tokens[key]) * f
        for key in (
            "monthly_search_calls",
            "monthly_executor_seconds",
            "monthly_executor_requests",
        ):
            s[key] = n(s[key]) * f
    elif name == "native_delivery_no_model_or_paid_search":
        for e in x["events"].values():
            e["successful_web_search_calls"] = 0
            for usage in e["model_usage"].values():
                for key in usage:
                    usage[key] = 0
    else:
        raise KeyError(name)
    return x


def run():
    freeze, auth = validate_freeze()
    x = json.loads((ROOT / "inputs.json").read_text())
    labor = json.loads((ROOT / "sources/labor_rates.json").read_text())
    oracle = Oracle(x, labor)
    core = [
        oracle.scenario(b, s, x["traditional"]["reference_productive_minutes"])
        for b in x["price_bases"]
        for s in x["scenarios"]
    ]
    humans = [
        oracle.scenario(b, s, t)
        for b in x["price_bases"]
        for s in x["scenarios"]
        for t in x["traditional"]["productive_minutes"]
    ]
    base = next(b for b in x["price_bases"] if b["id"] == "US_office")
    sensitivities = []
    for key, factors in x["one_way_sensitivities"].items():
        if not isinstance(factors, list):
            continue
        for factor in factors:
            altered = transformed(x, key, factor)
            result = Oracle(altered, labor).scenario(
                base, "base", x["traditional"]["reference_productive_minutes"]
            )
            sensitivities.append({"driver": key, "value": factor, "result": result})
    native = transformed(x, "native_delivery_no_model_or_paid_search")
    sensitivities.append(
        {
            "driver": "native_delivery_no_model_or_paid_search",
            "value": True,
            "result": Oracle(native, labor).scenario(
                base, "base", x["traditional"]["reference_productive_minutes"]
            ),
        }
    )
    result = {
        "schema": "independent-operational-economics-oracle/v1",
        "status": "INDEPENDENT_CALCULATION_NOT_YET_PRODUCER_COMPARISON",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "freeze_sha256": EXPECTED_FREEZE,
        "authorization": auth,
        "source_sha256": sha(Path(__file__)),
        "arithmetic": "Decimal, precision50. Numeric outputs stored as strings to preserve precision.",
        "producer_arithmetic_imported": False,
        "core": core,
        "human_duration": humans,
        "sensitivities": sensitivities,
        "observed_full_cost": None,
        "scope": "Forward operational-cost scenarios; not invoices, new acceptance observations or field reliability.",
    }
    (OUT / "INDEPENDENT_RESULTS.json").write_text(
        json.dumps(json_value(result), indent=2) + "\n"
    )
    return {
        "core": len(core),
        "human_rows": len(humans),
        "sensitivity_rows": len(sensitivities),
        "output_sha256": sha(OUT / "INDEPENDENT_RESULTS.json"),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", action="store_true", required=True)
    parser.parse_args()
    attempt = {
        "started_utc": datetime.now(timezone.utc).isoformat(),
        "source_sha256": sha(Path(__file__)),
        "freeze_sha256": EXPECTED_FREEZE,
    }
    try:
        attempt.update(status="PASS", result=run())
    except Exception as exc:
        attempt.update(
            status="FAIL",
            error_type=type(exc).__name__,
            error=str(exc),
            traceback=traceback.format_exc(),
        )
        raise
    finally:
        attempt["finished_utc"] = datetime.now(timezone.utc).isoformat()
        with (OUT / "ORACLE_ATTEMPTS.jsonl").open("a") as stream:
            stream.write(json.dumps(attempt) + "\n")
        print(json.dumps(attempt, indent=2))


if __name__ == "__main__":
    main()
