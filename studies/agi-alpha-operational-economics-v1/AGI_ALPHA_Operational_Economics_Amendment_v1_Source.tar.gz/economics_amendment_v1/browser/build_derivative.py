# SPDX-License-Identifier: Apache-2.0
"""Build a separate full-operating-cost companion without editing the sealed study."""
from __future__ import annotations

import argparse
import base64
import hashlib
import gzip
import io
import json
import re
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
HERE = ROOT / 'browser'
SEALED = ROOT.parent / 'capability_study/browser/AGI_ALPHA_Capability_Construction_Demo.html'
SEALED_SHA = 'e5a0ddd0f34199952b532a9eac7ea336186818fa6b922da98f0db08cfede65cd'
FREEZE_SHA = '54bc70fec9bb635b473193d966d36ed5bf445460a58255f025cbed4a30854d8b'


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def read(path: Path):
    return json.loads(path.read_text())


def live_functions(text: str) -> dict[str, str]:
    boundaries = [
        ('run', 'async function run(spec,parentIndex=null)', 'function loadAndRun(index)'),
        ('successor', 'function loadAndRun(index)', 'async function restore(raw)'),
        ('recovery', 'async function restore(raw)', 'for(const tab of document.querySelectorAll'),
        ('module_resolution', 'function normalize(path)', 'function status(text,error=false)'),
    ]
    return {name: sha(text.split(start, 1)[1].split(end, 1)[0].encode()) for name, start, end in boundaries}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--results', type=Path, required=True)
    parser.add_argument('--audit', type=Path, required=True)
    args = parser.parse_args()
    result_path = args.results.resolve()
    audit_path = args.audit.resolve()
    result_path.relative_to(ROOT)
    audit_path.relative_to(ROOT)
    sealed_bytes = SEALED.read_bytes()
    if sha(sealed_bytes) != SEALED_SHA:
        raise ValueError('Sealed companion identity changed')
    freeze_bytes = (ROOT / 'FREEZE.json').read_bytes()
    if sha(freeze_bytes) != FREEZE_SHA:
        raise ValueError('Economic freeze identity changed')
    freeze = json.loads(freeze_bytes)
    for item in freeze['files']:
        raw = (ROOT / item['path']).read_bytes()
        if sha(raw) != item['sha256'] or len(raw) != item['bytes']:
            raise ValueError('Frozen input mismatch: ' + item['path'])
    authorization = read(ROOT / 'AUTHORIZATION.json')
    if authorization['freeze_sha256'] != FREEZE_SHA or not authorization['public_readback_exact']:
        raise ValueError('Public freeze authorization mismatch')
    results = read(result_path)
    audit = read(audit_path)
    model_path = ROOT / 'src/model.py'
    model_bytes = model_path.read_bytes()
    # Exact audit field names are supplied by the independent evaluator before final build.
    audit_pass = audit.get('status') == 'PASS'
    if not audit_pass:
        raise ValueError('Final independent audit must explicitly pass')
    result_sha = sha(result_path.read_bytes())
    model_sha = sha(model_bytes)
    if results.get('input_manifest_sha256') != FREEZE_SHA or results.get('model_source_sha256') != model_sha:
        raise ValueError('Result does not bind exact frozen inputs and model source')
    if audit.get('results_sha256') != result_sha or audit.get('producer_source_sha256') != model_sha or audit.get('input_freeze_sha256') != FREEZE_SHA:
        raise ValueError('Independent audit must bind the exact result and model identities')
    files = [ROOT / item['path'] for item in freeze['files']]
    files += [ROOT / 'FREEZE.json', ROOT / 'AUTHORIZATION.json', result_path, audit_path, model_path]
    scheduling_path = ROOT / 'evaluation/SCHEDULING_DIAGNOSTIC.json'
    if not scheduling_path.exists():
        raise ValueError('Post-result scheduling diagnostic must be retained')
    files.append(scheduling_path)
    evidence = io.BytesIO()
    evidence_manifest = []
    with zipfile.ZipFile(evidence, 'w', zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(set(files)):
            relative = path.relative_to(ROOT).as_posix()
            raw = path.read_bytes()
            evidence_manifest.append({'path': relative, 'bytes': len(raw), 'sha256': sha(raw)})
            info = zipfile.ZipInfo(relative, (2026, 10, 25, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, raw)
        notes = {
            'MANIFEST.json': json.dumps(evidence_manifest, indent=2) + '\n',
            'README.txt': (
                'Separately frozen complete operating-cost scenarios. The observed native anchor is preserved; '
                'all prospective operating economics remain modeled. No provider or authenticated executor was invoked.\n'
                'From the extracted directory, reproduce into a new directory with:\n'
                'python src/model.py --root . --output outputs/reproduction-001\n'
                'The producer preserves existing output directories. The included independent audit is a separately '
                'bound numerical-consistency receipt, not evidence of empirical field performance.\n'
                'Capacity is an aggregate expected-use planning ceiling, not validated daily staffing or hard '
                'dollar-spend enforcement. Original work-unit controls are separate.\n'
            ),
        }
        for name, content in notes.items():
            info = zipfile.ZipInfo(name, (2026, 10, 25, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, content)
    payload = {
        'schema': 'operational-economics-browser/v1',
        'inputs': read(ROOT / 'inputs.json'),
        'labor': read(ROOT / 'sources/labor_rates.json'),
        'prices': read(ROOT / 'sources/pricing_register.json'),
        'anchor': read(ROOT / 'observed/ANCHOR.json'),
        'anchorTask': read(ROOT / 'observed/task.json'),
        'anchorBrief': (ROOT / 'observed/output/brief.html').read_text(),
        'anchorSlides': (ROOT / 'observed/output/slides.html').read_text(),
        'resultsCompressed': base64.b64encode(gzip.compress(result_path.read_bytes(), mtime=0)).decode(),
        'resultsBytes': result_path.stat().st_size,
        'inputsRaw': (ROOT / 'inputs.json').read_text(),
        'audit': audit,
        'schedulingDiagnostic': read(scheduling_path),
        'auditRaw': audit_path.read_text(),
        'model': model_bytes.decode(),
        'identity': {
            'sealedCompanionSha256': SEALED_SHA,
            'freezeSha256': FREEZE_SHA,
            'inputSha256': sha((ROOT / 'inputs.json').read_bytes()),
            'modelSha256': model_sha,
            'resultsSha256': result_sha,
            'auditSha256': sha(audit_path.read_bytes()),
            'resultsPath': result_path.relative_to(ROOT).as_posix(),
            'auditPath': audit_path.relative_to(ROOT).as_posix(),
            'publicSourceCommit': authorization['public_source_commit'],
            'authority': [],
            'authenticatedExecutor': 'NOT_RUN',
        },
        'bundle': {'base64': base64.b64encode(evidence.getvalue()).decode(),
                   'sha256': sha(evidence.getvalue()), 'bytes': len(evidence.getvalue())},
    }
    original = sealed_bytes.decode()
    html = original.replace('Build the capability<br>that builds what comes next.', 'Useful work.<br>The complete operating cost.')
    html = html.replace('Receive useful work. Keep the method. See exactly what the next mission inherits—and whether that inheritance earns its cost.', 'Inspect the delivered brief. Compare the complete human and Agent workflows. Keep reusable methods only when their measured contribution and full cost justify them.')
    html = html.replace('Research companion, 25 October 2026', 'Operational economics amendment · 25 October 2026')
    navigation = '<nav class="tabs" aria-label="Demonstration modes"><div class="wrap"><button role="tab" aria-selected="true" data-tab="economics">Work & full operating cost</button><button role="tab" aria-selected="false" data-tab="live">Successive missions · live local</button><button role="tab" aria-selected="false" data-tab="recorded">Original study · recorded</button><button role="tab" aria-selected="false" data-tab="executor">Executor & boundaries</button></div></nav>'
    html, count = re.subn(r'<nav class="tabs".*?</nav>', lambda _: navigation, html, count=1, flags=re.S)
    if count != 1:
        raise ValueError('Original navigation marker missing')
    panel = (HERE / 'operational_panel.html').read_text()
    html, count = re.subn(r'<section class="panel" id="economics" hidden>.*?</section>', lambda _: panel, html, count=1, flags=re.S)
    if count != 1:
        raise ValueError('Original economics panel marker missing')
    html = html.replace('<section class="panel" id="live">', '<section class="panel" id="live" hidden>')
    start = html.index('function model(){')
    end = html.index('window.CAPABILITY_DEMO=', start)
    html = html[:start] + '// The original illustrative calculator is superseded here by separately frozen complete-cost results.\n' + html[end:]
    html = html.replace('</head>', '<style>' + (HERE / 'operational_style.css').read_text() + '</style></head>', 1)
    script = (HERE / 'operational_ui.mjs').read_text()
    extra = '<script id="operational-payload" type="application/json">' + json.dumps(payload, ensure_ascii=False, separators=(',', ':')).replace('<', '\\u003c') + '</script>\n<script type="module">\n' + script + '\n</script>\n'
    html = html.replace('</body>', extra + '</body>', 1)
    if live_functions(original) != live_functions(html):
        raise ValueError('Original live invocation or recovery code changed')
    destination = HERE / 'AGI_ALPHA_Complete_Operating_Economics_Demo.html'
    destination.write_text(html)
    manifest = {
        'schema': 'operational-economics-browser-build/v1',
        'path': destination.name,
        'bytes': destination.stat().st_size,
        'sha256': sha(destination.read_bytes()),
        **payload['identity'],
        'live_function_hashes': live_functions(html),
        'evidence_bundle_sha256': payload['bundle']['sha256'],
        'evidence_files': evidence_manifest,
        'external_runtime_requests': [],
        'original_companion_unchanged': sha(SEALED.read_bytes()) == SEALED_SHA,
        'publication': 'PREPARED_OFFLINE_DERIVATIVE_NOT_DEPLOYED',
    }
    (HERE / 'BUILD_MANIFEST.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({key: value for key, value in manifest.items() if key not in ['evidence_files', 'live_function_hashes']}, indent=2))


if __name__ == '__main__':
    main()
