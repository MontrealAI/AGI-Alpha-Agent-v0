// SPDX-License-Identifier: Apache-2.0
// Presentation only. Economic arithmetic is the independently audited Python model.
const OP = JSON.parse(document.querySelector('#operational-payload').textContent);
const oq = selector => document.querySelector(selector);
let RESULTS = null, RESULTS_RAW = '', activeRows = [];
const SCENARIOS = ['base', 'conservative', 'stress'];
const title = value => value.replaceAll('_', ' ').replace(/\b\w/g, c => c.toUpperCase());
const pointer = (...parts) => '/' + parts.map(x => String(x).replaceAll('~', '~0').replaceAll('/', '~1')).join('/');
function at(path) { return path.slice(1).split('/').reduce((value, key) => value[key.replaceAll('~1', '/').replaceAll('~0', '~')], RESULTS); }
function node(tag, text, className = '') { const el = document.createElement(tag); if (text !== undefined) el.textContent = text; if (className) el.className = className; return el; }
function bound(path, kind = 'number', currency = '', decimals = 2) {
  const el = node('span'); const value = at(path);
  el.dataset.modelPath = path; el.dataset.format = kind; el.dataset.decimals = String(decimals); el.dataset.currency = currency;
  if (value === null) { el.textContent = 'Unavailable'; el.dataset.null = 'true'; return el; }
  if (typeof value !== 'number' || !Number.isFinite(value)) throw Error('Non-numeric audited field: ' + path);
  const scale = kind === 'percent' ? 100 : 1;
  const number = new Intl.NumberFormat('en-US', {minimumFractionDigits:decimals, maximumFractionDigits:decimals}).format(value * scale);
  if (kind === 'money') {
    el.append(node('span', currency + ' ', 'op-currency'), node('span', number, 'op-amount'));
  } else {
    el.textContent = number + (kind === 'minutes' ? ' min' : kind === 'percent' ? '%' : kind === 'ratio' ? '×' : '');
  }
  return el;
}
function fact(list, label, entries, metricId = '') {
  const row = node('div'); const dt = node('dt', label); const dd = node('dd');
  if (metricId) dd.dataset.metric = metricId;
  entries.forEach((entry, index) => { if (index) dd.append(document.createTextNode(' · ')); if (typeof entry === 'string') dd.append(document.createTextNode(entry)); else dd.append(entry); });
  row.append(dt, dd); list.append(row);
}
function download(name, raw, type='application/json') {
  const blob = new Blob([raw], {type}); const url = URL.createObjectURL(blob); const link = document.createElement('a');
  link.href=url; link.download=name; document.body.append(link); link.click(); link.remove(); setTimeout(()=>URL.revokeObjectURL(url),30000);
}
function preview(raw) { return raw.replace('</head>', '<style>body{overflow-wrap:anywhere}table{max-width:100%;display:block;overflow:auto}@media(max-width:500px){main{padding:20px 12px!important}body{padding:12px!important}h1{font-size:27px!important;overflow-wrap:anywhere}h2{font-size:21px!important}article{padding:12px!important}blockquote{font-size:16px!important}}</style></head>'); }
async function shaBytes(bytes) { return [...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(x=>x.toString(16).padStart(2,'0')).join(''); }
function cohortPath(base, horizon) { return horizon==='first' ? base+'/first_commission' : horizon==='feasible' ? base+'/capacity/feasible_admitted_cohort' : base+'/annual_at_demand'; }
function latencyPath(base, variableBase, horizon) { return horizon==='first' ? base+'/first_commission/accepted_conditional_turnaround_minutes_including_setup' : variableBase+'/latency/accepted_conditional_minutes'; }
function moneyTile(parent, label, path, currency, metricId) {
  const box=node('div'); const strong=node('strong'); strong.dataset.metric=metricId; strong.append(bound(path,'money',currency));
  box.append(strong,node('span',label));parent.append(box);
}
function renderCard(index, productive, horizon) {
  const row=RESULTS.core_scenarios[index], base=pointer('core_scenarios',index), comparisonIndex=row.traditional_comparisons.findIndex(x=>x.productive_minutes===productive);
  if(comparisonIndex<0)throw Error('Duration not preregistered');
  const cb=base+'/traditional_comparisons/'+comparisonIndex, hb=cb+'/traditional', yb=cb+'/hybrid';
  const ac=cohortPath(base,horizon),hc=cohortPath(hb,horizon),yc=cohortPath(yb,horizon), c=row.currency;
  const card=node('article',undefined,'op-scenario '+row.scenario);card.dataset.scenario=row.scenario;card.dataset.rowIndex=String(index);card.dataset.comparisonIndex=String(comparisonIndex);
  card.append(node('h3',title(row.scenario)),node('p',OP.inputs.scenarios[row.scenario].label,'small'));
  const costs=node('div',undefined,'op-pair');
  moneyTile(costs,'Agent / expected accepted output',ac+'/cost_per_expected_accepted',c,'agent-cost');
  moneyTile(costs,'Traditional / completed output',hc+'/cost_per_expected_accepted',c,'traditional-cost');
  moneyTile(costs,'Agent + human fallback / completed output',yc+'/cost_per_expected_accepted',c,'hybrid-cost');
  moneyTile(costs,'Agent total cost in this horizon',ac+'/total_cost',c,'agent-total');card.append(costs);
  const list=node('dl',undefined,'op-facts');
  fact(list,'Agent requests → expected accepted → unresolved',[bound(ac+'/requested','number','',0),bound(ac+'/expected_accepted','number','',2),bound(ac+'/expected_unresolved','number','',2)],'output-volume');
  fact(list,'Assumed request acceptance / expected attempts',[bound(base+'/expected_acceptance_probability','percent','',1),bound(base+'/expected_attempts','number','',2)],'acceptance-attempts');
  fact(list,'Employer attention per accepted output',['Agent ',bound(ac+'/human_minutes_per_expected_accepted/employer_minutes','minutes'),'Traditional ',bound(hc+'/human_minutes_per_expected_accepted/employer_minutes','minutes')],'employer-attention');
  fact(list,'All human time per accepted output',['Agent ',bound(ac+'/all_human_minutes_per_expected_accepted','minutes'),'Traditional ',bound(hc+'/all_human_minutes_per_expected_accepted','minutes')],'all-human-time');
  fact(list,'Provider human time within Agent total',[bound(ac+'/human_minutes_per_expected_accepted/provider_minutes','minutes')],'provider-attention');
  fact(list,horizon==='first'?'First-commission wait, including assumed setup':'Accepted-request turnaround after setup',['Agent ',bound(latencyPath(base,base+'/agent_variable',horizon),'minutes'),'Traditional ',bound(latencyPath(hb,hb+'/variable',horizon),'minutes')],'turnaround');
  fact(list,'Service turnaround p95 / worst declared path',[bound(base+'/accepted_turnaround_p95_minutes','minutes'),bound(base+'/worst_declared_path_minutes','minutes')],'tail-turnaround');
  fact(list,'Annual expected-use accepted-output ceilings',['Agent ',bound(base+'/capacity/expected_accepted_capacity'),'Traditional ',bound(hb+'/capacity/expected_accepted_capacity'),'Hybrid ',bound(yb+'/capacity/expected_accepted_capacity')],'capacity');
  if(horizon==='annual'){
    fact(list,'Modeled traditional ÷ Agent cost / ÷ hybrid cost',[bound(cb+'/modeled_human_to_agent_unit_cost_ratio','ratio'),bound(cb+'/modeled_human_to_hybrid_unit_cost_ratio','ratio')],'cost-ratios');
    fact(list,'Break-even traditional productive time',['Agent ',bound(base+'/human_break_even_productive_minutes','minutes'),'Hybrid ',bound(base+'/hybrid_break_even_productive_minutes','minutes')],'break-even');
  }
  card.append(list);
  const feasible=row.capacity.declared_demand_feasible;
  const flag=node('p',feasible?'Declared demand fits aggregate expected-use bounds. Staffing and hard dollar-budget enforcement remain unvalidated.':'Declared demand exceeds aggregate expected-use bounds. The conditional amortized cost is not a demonstrated service price.','op-feasibility');flag.dataset.metric='aggregate-feasibility';flag.dataset.feasible=String(feasible);card.append(flag);
  if(horizon==='feasible'&&row.capacity.requested_capacity===0)card.append(node('p','No Agent output fits these aggregate assumptions; a finite cost per accepted output is unavailable. Fixed obligations are still charged.','flag bad'));
  card.append(node('p',horizon==='first'?'Setup calendars are assumed and staffing schedules unvalidated. The reported wait is not an achievable-delivery promise.':'Pure Agent leaves unresolved demand. The hybrid account pays all Agent failures and full traditional fallback; human completion is assumed.','small'));
  const extras=node('details');extras.append(node('summary','Service, improvement and shared accounts'));const accountList=node('dl',undefined,'op-facts');
  for(const key of Object.keys(at(ac+'/total_account/service_improvement_totals')))fact(accountList,title(key),[bound(ac+'/total_account/service_improvement_totals/'+key,'money',c)]);
  extras.append(accountList);card.append(extras);return card;
}
function componentRows(target,base,currency){target.replaceChildren();for(const [key,value]of Object.entries(at(base))){if(value===0)continue;const tr=node('tr');tr.append(node('td',key.replaceAll('.',' / ').replaceAll('_',' ')));const td=node('td');td.append(bound(base+'/'+key,'money',currency));tr.append(td,node('td','Assumed quantity × sourced price, or stated allowance'));target.append(tr);}}
function renderDetails(){const price=oq('#opPriceBasis').value,scenario=oq('#opDetailScenario').value,horizon=oq('#opHorizon').value;const index=RESULTS.core_scenarios.findIndex(x=>x.price_basis===price&&x.scenario===scenario);if(index<0)throw Error('Missing audited scenario');const row=RESULTS.core_scenarios[index],base=pointer('core_scenarios',index),cohort=cohortPath(base,horizon);componentRows(oq('#opVariableRows'),base+'/variable_cost_by_component',row.currency);componentRows(oq('#opFixedRows'),cohort+'/fixed_account/components',row.currency);oq('#opFixedHeading').textContent=horizon==='first'?'Initial construction and one month of reserved upkeep':'Initial construction and twelve months of reserved upkeep';oq('#opBranchRows').replaceChildren();row.agent_variable.branches.forEach((branch,i)=>{const tr=node('tr');tr.append(node('td',title(branch.branch)));const weight=node('td');weight.append(bound(base+'/agent_variable/branches/'+i+'/probability','percent','',1));tr.append(weight,node('td',branch.accepted?'Assumed accepted':'Unresolved; cost retained'),node('td',branch.events.map(x=>typeof x==='string'?x:x.event).join(' → ')));oq('#opBranchRows').append(tr);});oq('#opCapacityDetail').textContent=JSON.stringify({scenario,price_basis:price,scope:row.capacity.scope,requested_capacity:row.capacity.requested_capacity,expected_accepted_capacity:row.capacity.expected_accepted_capacity,binding_constraints:row.capacity.binding_constraints,fixed_resource_shortfalls:row.capacity.fixed_resource_shortfalls,setup_window_fits_uniform_daily_limits:row.capacity.setup_window_fits_uniform_daily_limits,setup_scheduling_diagnostic:row.capacity.setup_scheduling_diagnostic,setup_scheduling_caveat:row.capacity.setup_scheduling_caveat,resource_limits:row.capacity.limits},null,2);}
function render(){if(!RESULTS)return;const price=oq('#opPriceBasis').value,productive=Number(oq('#opProductive').value),horizon=oq('#opHorizon').value;activeRows=SCENARIOS.map(s=>RESULTS.core_scenarios.findIndex(x=>x.price_basis===price&&x.scenario===s));if(activeRows.some(x=>x<0))throw Error('Incomplete core scenario matrix');const cards=oq('#opScenarioCards');cards.replaceChildren(...activeRows.map(i=>renderCard(i,productive,horizon)));const first=RESULTS.core_scenarios[activeRows[0]],base=pointer('core_scenarios',activeRows[0]);const rate=OP.labor.rates.find(x=>x.id===first.price_basis_metadata.labor_rate_id);const note=oq('#opPriceNote');note.replaceChildren(document.createTextNode('Employer and traditional worker price: '),bound(base+'/labor_prices/employer_worker_per_hour','money',first.currency),document.createTextNode('/hour. Provider professional time: '),bound(base+'/labor_prices/provider_per_hour_in_reporting_currency','money',first.currency),document.createTextNode('/hour. '+rate.reference_period+'; '+rate.benefits_coverage+' '+first.price_basis_metadata.scope_limit+' '));const link=node('a','Official labor source');link.href=rate.source_url;link.target='_blank';link.rel='noopener';note.append(link);oq('#opHorizonNote').textContent=horizon==='annual'?'Declared annual demand: charge initial work and all twelve monthly reserves, then divide by the expected accepted outputs at the scenario’s declared request volume. This figure remains conditional when demand is not aggregate-resource feasible.':horizon==='first'?'First commission: one requested job bears initial construction, qualification, deployment and one month of recurring reserves. Cost per expected accepted output includes the possibility of refusal or rejection. Setup delay is assumed; staffing remains unvalidated.':'Aggregate annual capacity bound: admit only the integer number of requests that fits expected aggregate consumption and demand. Initial work and all twelve monthly reserves remain charged. This is an expected-use planning ceiling, not proven daily schedulability, measured throughput, or hard dollar-spend enforcement. Realized expensive paths can exceed a mean budget.';renderDetails();}
window.OPERATIONAL_ECONOMICS={ready:false,data:OP,results:null,state:()=>({priceBasis:oq('#opPriceBasis').value,productiveMinutes:Number(oq('#opProductive').value),horizon:oq('#opHorizon').value,activeRows:[...activeRows]}),render};
try{
  oq('#opScenarioCards').textContent='Loading the audited economic results…';
  const compressed=Uint8Array.from(atob(OP.resultsCompressed),c=>c.charCodeAt(0));const stream=new Blob([compressed]).stream().pipeThrough(new DecompressionStream('gzip'));const bytes=new Uint8Array(await new Response(stream).arrayBuffer());
  if(bytes.length!==OP.resultsBytes||await shaBytes(bytes)!==OP.identity.resultsSha256)throw Error('Result bytes differ from the independently audited file');
  RESULTS_RAW=new TextDecoder().decode(bytes);RESULTS=JSON.parse(RESULTS_RAW);
  if(RESULTS.input_manifest_sha256!==OP.identity.freezeSha256||RESULTS.model_source_sha256!==OP.identity.modelSha256||OP.audit.status!=='PASS'||OP.audit.results_sha256!==OP.identity.resultsSha256||OP.audit.producer_source_sha256!==OP.identity.modelSha256)throw Error('Audit or frozen input binding failed');
  for(const basis of OP.inputs.price_bases){const option=node('option',basis.id==='US_office'?'U.S. office/admin · USD':basis.id==='US_professional'?'U.S. professional · USD':basis.id==='Ontario'?'Ontario technical writer · CAD':'European Union employer cost · EUR');option.value=basis.id;oq('#opPriceBasis').append(option);}oq('#opPriceBasis').value='US_office';
  for(const minutes of OP.inputs.traditional.productive_minutes){const option=node('option',minutes+' productive minutes');option.value=String(minutes);oq('#opProductive').append(option);}oq('#opProductive').value=String(OP.inputs.traditional.reference_productive_minutes);
  oq('#anchorBrief').textContent=OP.anchorTask.brief;oq('#anchorPreview').srcdoc=preview(OP.anchorBrief);oq('#anchorRead').onclick=()=>oq('#anchorPreview').srcdoc=preview(OP.anchorBrief);oq('#anchorSlides').onclick=()=>oq('#anchorPreview').srcdoc=preview(OP.anchorSlides);
  oq('#anchorFacts').textContent='Observed job '+OP.anchor.task+' · '+OP.anchor.native_delivery_wall_seconds.toFixed(3)+' seconds for the recorded local delivery boundary · '+OP.anchor.task_time_model_calls+' task-time model calls. Actual human attention, historical construction effort and full observed Agent cost remain unknown.';
  oq('#downloadAnchorBrief').onclick=()=>download('source-synthesis-01-brief.html',OP.anchorBrief,'text/html');oq('#downloadAnchorSlides').onclick=()=>download('source-synthesis-01-slides.html',OP.anchorSlides,'text/html');
  oq('#opDownloadInputs').onclick=()=>download('AGI_ALPHA_Operating_Economics_Frozen_Inputs.json',OP.inputsRaw);oq('#opDownloadResults').onclick=()=>download('AGI_ALPHA_Operating_Economics_Results.json',RESULTS_RAW);oq('#opDownloadModel').onclick=()=>download('model.py',OP.model,'text/x-python');oq('#opDownloadAudit').onclick=()=>download('INDEPENDENT_AUDIT.json',OP.auditRaw);oq('#opDownloadBundle').onclick=()=>download('AGI_ALPHA_Operating_Economics_Evidence.zip',Uint8Array.from(atob(OP.bundle.base64),c=>c.charCodeAt(0)),'application/zip');
  oq('#opProvenance').textContent='Independent numerical audit: PASS; empirical operating performance remains unestablished. Frozen inputs '+OP.identity.freezeSha256+' · Model '+OP.identity.modelSha256+' · Results '+OP.identity.resultsSha256+' · Evidence ZIP '+OP.bundle.sha256+'.';
  oq('#opIdentities').textContent=JSON.stringify({identities:OP.identity,validity_flags:OP.audit.validity_flags,scheduling_diagnostic:OP.schedulingDiagnostic,limitations:RESULTS.limitations,interpretation:RESULTS.interpretation},null,2);
  for(const id of ['opPriceBasis','opProductive','opHorizon'])oq('#'+id).onchange=render;oq('#opDetailScenario').onchange=renderDetails;render();window.OPERATIONAL_ECONOMICS.results=RESULTS;window.OPERATIONAL_ECONOMICS.ready=true;
}catch(error){oq('#opScenarioCards').textContent='Comparison unavailable: '+error.message+'. No unverified economic result is substituted.';window.OPERATIONAL_ECONOMICS.error=error.message;}
