# SPDX-License-Identifier: Apache-2.0
"""Offline presentation/integration QA, separate from scientific confirmation."""
from __future__ import annotations

import hashlib
import json
import re
import traceback
import zipfile
from datetime import datetime, timezone
from pathlib import Path

from playwright.sync_api import sync_playwright

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
QA = HERE / 'qa'
QA.mkdir(exist_ok=True)
MANIFEST = json.loads((HERE / 'BUILD_MANIFEST.json').read_text())
RESULTS = json.loads((ROOT / MANIFEST['resultsPath']).read_text())
checks: list[dict] = []
errors: list[str] = []
requests: list[str] = []
numeric_count = 0
state_count = 0


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check(name: str, passed: bool, detail=None) -> None:
    checks.append({'check': name, 'passed': bool(passed), 'detail': detail})
    if not passed:
        raise AssertionError(name + ': ' + str(detail))


def at(pointer: str):
    value = RESULTS
    for part in pointer.lstrip('/').split('/'):
        part = part.replace('~1', '/').replace('~0', '~')
        value = value[int(part)] if isinstance(value, list) else value[part]
    return value


def validate_numbers(page, scope='#economics') -> int:
    records = page.locator(scope + ' [data-model-path]').evaluate_all('els=>els.map(e=>({path:e.dataset.modelPath,kind:e.dataset.format,currency:e.dataset.currency,decimals:Number(e.dataset.decimals),null:e.dataset.null,text:e.textContent}))')
    for item in records:
        wanted = at(item['path'])
        if wanted is None:
            assert item['text'] == 'Unavailable' and item['null'] == 'true', item
            continue
        text = item['text']
        if item['kind'] == 'money':
            assert text.startswith(item['currency'] + ' '), item
        number = float(re.sub(r'[^0-9.\-]', '', text))
        expected = wanted * (100 if item['kind'] == 'percent' else 1)
        assert abs(number - expected) <= (0.5 * 10 ** -item['decimals'] + abs(expected) * 1e-12), (item, wanted)
    return len(records)


def cohort(base: str, horizon: str) -> str:
    return base + ('/first_commission' if horizon == 'first' else '/capacity/feasible_admitted_cohort' if horizon == 'feasible' else '/annual_at_demand')


def run() -> None:
    global numeric_count, state_count
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True, executable_path='/tmp/successor-chrome/chrome-headless-shell-linux64/chrome-headless-shell', args=['--no-sandbox'])
        context = browser.new_context(viewport={'width': 1440, 'height': 1050}, accept_downloads=True, offline=True)
        page = context.new_page()
        page.on('pageerror', lambda e: errors.append(str(e)))
        page.on('request', lambda r: requests.append(r.url) if r.url.startswith(('http:', 'https:')) else None)
        page.goto((HERE / MANIFEST['path']).as_uri())
        page.wait_for_function('window.OPERATIONAL_ECONOMICS?.ready || window.OPERATIONAL_ECONOMICS?.error', timeout=60000)
        check('Audited economics initialized', page.evaluate('OPERATIONAL_ECONOMICS.ready'), page.evaluate('OPERATIONAL_ECONOMICS.error || null'))
        page.wait_for_function('window.CAPABILITY_DEMO?.ready === true', timeout=20000)
        check('Default economics tab is visible', page.locator('#economics').is_visible() and not page.locator('#live').is_visible())
        check('Result and audit identities bound', page.evaluate('OPERATIONAL_ECONOMICS.data.identity.resultsSha256') == MANIFEST['resultsSha256'])
        check('Scheduling and expected-budget caveats visible', all(text in page.locator('#economics').inner_text() for text in ['Scheduling remains unvalidated', 'expected branch consumption', 'hard dollar-spend enforcement', 'NOT RUN']))
        check('Original useful artifact preview rendered', page.frame_locator('#anchorPreview').locator('h1').count() == 1)
        page.screenshot(path=str(QA / 'desktop-opening.png'), full_page=True)
        for price in ['US_office', 'US_professional', 'Ontario', 'EU']:
            for minutes in [5, 15, 30, 60, 120]:
                for horizon in ['annual', 'first', 'feasible']:
                    page.locator('#opPriceBasis').select_option(price)
                    page.locator('#opProductive').select_option(str(minutes))
                    page.locator('#opHorizon').select_option(horizon)
                    cards = page.locator('#opScenarioCards article.op-scenario')
                    assert cards.count() == 3
                    for card_index, scenario in enumerate(['base', 'conservative', 'stress']):
                        idx = next(i for i, x in enumerate(RESULTS['core_scenarios']) if x['scenario'] == scenario and x['price_basis'] == price)
                        row = RESULTS['core_scenarios'][idx]
                        ci = next(i for i, x in enumerate(row['traditional_comparisons']) if x['productive_minutes'] == minutes)
                        card = cards.nth(card_index)
                        assert card.get_attribute('data-row-index') == str(idx)
                        assert card.get_attribute('data-comparison-index') == str(ci)
                        base = f'/core_scenarios/{idx}'
                        cp = base + f'/traditional_comparisons/{ci}'
                        expected_paths = {
                            'agent-cost': cohort(base, horizon) + '/cost_per_expected_accepted',
                            'traditional-cost': cohort(cp + '/traditional', horizon) + '/cost_per_expected_accepted',
                            'hybrid-cost': cohort(cp + '/hybrid', horizon) + '/cost_per_expected_accepted',
                            'agent-total': cohort(base, horizon) + '/total_cost',
                        }
                        for metric, expected_path in expected_paths.items():
                            shown = card.locator('[data-metric="' + metric + '"] [data-model-path]')
                            assert shown.get_attribute('data-model-path') == expected_path, (price, minutes, horizon, scenario, metric)
                        flag = card.locator('[data-metric="aggregate-feasibility"]')
                        assert flag.get_attribute('data-feasible') == str(row['capacity']['declared_demand_feasible']).lower()
                        if horizon == 'feasible' and row['capacity']['requested_capacity'] == 0:
                            assert card.locator('[data-metric="agent-cost"]').inner_text() == 'Unavailable'
                            assert 'Fixed obligations are still charged' in card.inner_text()
                    count = validate_numbers(page)
                    numeric_count += count
                    state_count += 1
                    check(f'Audited display {price}/{minutes}/{horizon}', True, {'rounded_fields': count, 'scenario_cards': 3})
                    if minutes == 30:
                        for scenario in ['conservative', 'stress']:
                            page.locator('#opDetailScenario').select_option(scenario)
                            numeric_count += validate_numbers(page)
                            check(f'Detailed accounts {price}/{horizon}/{scenario}', True)
                        page.locator('#opDetailScenario').select_option('base')
        page.locator('#opPriceBasis').select_option('US_office')
        page.locator('#opProductive').select_option('30')
        page.locator('#opHorizon').select_option('annual')
        page.locator('#anchorSlides').click()
        check('Original presentation renders', page.frame_locator('#anchorPreview').locator('article.slide').count() > 0)
        page.locator('#anchorRead').click()
        downloads = [
            ('downloadAnchorBrief', ROOT / 'observed/output/brief.html'),
            ('downloadAnchorSlides', ROOT / 'observed/output/slides.html'),
            ('opDownloadInputs', ROOT / 'inputs.json'),
            ('opDownloadResults', ROOT / MANIFEST['resultsPath']),
            ('opDownloadModel', ROOT / 'src/model.py'),
            ('opDownloadAudit', ROOT / MANIFEST['auditPath']),
        ]
        for button, original in downloads:
            with page.expect_download(timeout=30000) as pending:
                page.locator('#' + button).click()
            saved = QA / (button + '-' + original.name)
            pending.value.save_as(saved)
            check('Exact download ' + button, sha(saved) == sha(original))
        with page.expect_download(timeout=30000) as pending:
            page.locator('#opDownloadBundle').click()
        bundle = QA / 'economics-evidence.zip'
        pending.value.save_as(bundle)
        check('Exact embedded evidence ZIP', sha(bundle) == MANIFEST['evidence_bundle_sha256'])
        with zipfile.ZipFile(bundle) as archive:
            embedded = json.loads(archive.read('MANIFEST.json'))
            for item in embedded:
                raw = archive.read(item['path'])
                assert len(raw) == item['bytes'] and hashlib.sha256(raw).hexdigest() == item['sha256'], item['path']
            check('Every downloaded evidence file bound', True, len(embedded))
        page.locator('[data-tab=live]').click()
        page.locator('#first').click()
        page.wait_for_function('CAPABILITY_DEMO.state().history.length===1 && !CAPABILITY_DEMO.state().busy')
        state = page.evaluate('CAPABILITY_DEMO.state()')
        check('Inherited first useful brief accepted', state['history'][0]['checks']['exact_contract'] and state['history'][0]['pack']['result']['summary']['claims'] == 4)
        page.locator('#changed').click()
        page.wait_for_function('CAPABILITY_DEMO.state().history.length===2 && !CAPABILITY_DEMO.state().busy')
        state = page.evaluate('CAPABILITY_DEMO.state()')
        lineage = json.loads(next(x['content'] for x in state['history'][1]['pack']['result']['artifacts'] if x['name'] == 'lineage.json'))
        check('Actual parent executable invoked for changed source', state['retainedInvocations'] == 1 and bool(lineage['changed_source_ids']) and bool(lineage['reused_claim_ids']) and bool(lineage['recompiled_claim_ids']), lineage)
        page.locator('#transfer').click()
        page.wait_for_function('CAPABILITY_DEMO.state().history.length===3 && !CAPABILITY_DEMO.state().busy')
        state = page.evaluate('CAPABILITY_DEMO.state()')
        lineage = json.loads(next(x['content'] for x in state['history'][2]['pack']['result']['artifacts'] if x['name'] == 'lineage.json'))
        check('Fresh transfer invokes retained module', state['retainedInvocations'] == 2 and lineage['cross_family'] and len(lineage['reused_claim_ids']) == 4, lineage)
        with page.expect_download() as pending:
            page.get_by_role('button', name='repair-tool.mjs', exact=True).click()
        module_path = QA / 'repair-tool.mjs'
        pending.value.save_as(module_path)
        check('Downloaded retained module remains exact', sha(module_path) == sha(ROOT.parent / 'capability_study/src/evidence.mjs'))
        workspace = page.evaluate('CAPABILITY_DEMO.exportWorkspace()')
        page.locator('#rollback').click()
        state = page.evaluate('CAPABILITY_DEMO.state()')
        check('Rollback preserves prior artifacts', state['selected'] == 1 and len(state['history']) == 3)
        page.locator('#stopNext').check()
        page.locator('#first').click()
        page.wait_for_function('!CAPABILITY_DEMO.state().busy')
        state = page.evaluate('CAPABILITY_DEMO.state()')
        check('STOP prevents local execution', len(state['history']) == 3 and any(x['kind'] == 'failed-or-stopped' and x['detail']['error'] == 'CANCELLED' for x in state['events']))
        page.evaluate('raw=>CAPABILITY_DEMO.restore(raw)', workspace)
        check('Workspace recovery restores three outputs', page.evaluate('CAPABILITY_DEMO.state().history.length') == 3)
        corrupt = json.loads(workspace)
        corrupt['history'][0]['pack']['result']['summary']['claims'] = 999
        refusal = page.evaluate('async raw=>{try{await CAPABILITY_DEMO.restore(raw);return null;}catch(e){return e.message}}', json.dumps(corrupt))
        check('Tampered workspace refused without losing prior outputs', refusal == 'PACK_INTEGRITY' and page.evaluate('CAPABILITY_DEMO.state().history.length') == 3)
        page.locator('[data-tab=recorded]').click()
        check('Recorded study retained', page.locator('#recordedMetrics').inner_text().startswith('42/42') and page.locator('#familyRows tr').count() == 7)
        page.locator('[data-tab=executor]').click()
        check('Authenticated executor remains NOT RUN', 'NOT RUN in this research session' in page.locator('#executor').inner_text())
        for width, height, label in [(1440, 1050, 'desktop'), (390, 844, 'mobile')]:
            page.set_viewport_size({'width': width, 'height': height})
            for tab in ['economics', 'live', 'recorded', 'executor']:
                page.locator('[data-tab=' + tab + ']').click()
                page.evaluate('window.scrollTo(0,0)')
                check(f'{label} horizontal containment {tab}', page.evaluate('document.documentElement.scrollWidth<=window.innerWidth+1'))
                page.screenshot(path=str(QA / (label + '-' + tab + '.png')), full_page=True)
        for frame_id, tab in [('anchorPreview', 'economics'), ('preview', 'live'), ('planningPreview', 'recorded')]:
            page.locator('[data-tab=' + tab + ']').click()
            page.locator('#' + frame_id).scroll_into_view_if_needed()
            page.frame_locator('#' + frame_id).locator('h1').wait_for()
            check('Mobile iframe containment ' + frame_id, page.frame_locator('#' + frame_id).locator('body').evaluate('e=>e.scrollWidth<=e.ownerDocument.documentElement.clientWidth+1'))
            page.screenshot(path=str(QA / ('mobile-iframe-' + frame_id + '.png')))
        page.locator('[data-tab=economics]').click()
        page.set_viewport_size({'width': 1440, 'height': 1050})
        page.locator('#opScenarioCards').scroll_into_view_if_needed()
        page.screenshot(path=str(QA / 'desktop-model-values.png'))
        check('No script errors', not errors, errors)
        check('No external runtime requests', not requests, requests)
        check('Sealed original companion still exact', sha(ROOT.parent / 'capability_study/browser/AGI_ALPHA_Capability_Construction_Demo.html') == MANIFEST['sealedCompanionSha256'])
        browser.close()


started = datetime.now(timezone.utc).isoformat()
try:
    run()
    status, failure = 'PASS', None
except Exception:
    status, failure = 'FAIL', traceback.format_exc()
finally:
    report = {
        'schema': 'operational-economics-browser-qa/v1', 'status': status,
        'mode': 'OFFLINE_LOCAL_BROWSER_ENGINEERING_QA',
        'created_utc': datetime.now(timezone.utc).isoformat(), 'started_utc': started,
        'html_sha256': MANIFEST['sha256'], 'results_sha256': MANIFEST['resultsSha256'],
        'audit_sha256': MANIFEST['auditSha256'],
        'checks': checks, 'passed': sum(x['passed'] for x in checks), 'attempted': len(checks),
        'selector_combinations': state_count, 'scenario_views': 3 * state_count,
        'rounded_numeric_bindings_checked': numeric_count,
        'page_errors': errors, 'external_requests': requests, 'failure': failure,
        'scientific_confirmation_rerun': False, 'authenticated_executor': 'NOT_RUN',
        'screenshots': 'Internal visual QA only; excluded from publication evidence bundles',
    }
    (HERE / 'QA_REPORT.json').write_text(json.dumps(report, indent=2) + '\n')
    with (HERE / 'BUILD_ATTEMPTS.jsonl').open('a') as history:
        history.write(json.dumps({key: value for key, value in report.items() if key != 'checks'}) + '\n')
    print(json.dumps({key: value for key, value in report.items() if key not in ['checks', 'failure']}))
    if failure:
        print(failure)
        raise SystemExit(1)
