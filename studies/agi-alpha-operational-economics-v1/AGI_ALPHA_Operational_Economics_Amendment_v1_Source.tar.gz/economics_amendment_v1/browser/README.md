# Complete operating economics — derivative companion

Open **AGI_ALPHA_Complete_Operating_Economics_Demo.html** in a current browser supporting JavaScript modules, Web Crypto and `DecompressionStream` (tested with the existing Chromium environment). This is one self-contained offline file. It makes no runtime network request and needs no credentials, account, installation or approved executor.

The companion starts with the actual accepted `source-synthesis-01` brief and presentation. Those original downloadable artifacts are unchanged. Its acceptance contract covers exact requested passages, source bindings and usable structure; it does not establish source truth, independent human approval, or free-form research quality. The observed 0.112-second local delivery boundary is distinct from the prospective full operating model.

## Economic comparison

The operating model is a separately preregistered amendment to the preserved capability study. It uses the public freeze `54bc70fec9bb635b473193d966d36ed5bf445460a58255f025cbed4a30854d8b`, source commit `4d1d2af3e77a5346e3dc1a574f509d5c67c0aef7`, and [prospective public notice](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/issues/4850#issuecomment-6398263719).

The UI reads exact audited outputs; it does not recalculate the economic model. Choose four labor-price bases, five assumed traditional productive durations, and three accounting horizons. All three scenarios remain visible:

- **Declared annual demand:** initial construction plus twelve months of reserved costs, divided by expected accepted outputs at declared demand. Infeasible demand stays labeled conditional.
- **First commission:** initial construction plus one month of reserved costs allocated to one requested job, retaining rejection/refusal costs. Setup elapsed time is assumed and its staffing schedule unvalidated.
- **Aggregate annual capacity bound:** the modeled integer request volume permitted by expected aggregate resource consumption, retaining all initial and annual reserved costs. Zero accepted capacity produces an unavailable unit cost, not a zero cost.

This is an **aggregate expected-use planning ceiling**. It is neither proof of a feasible daily staffing schedule nor a hard dollar-spend guarantee. Realized expensive failure paths can exceed a mean budget. No chance constraint, tail-risk guarantee, provider-call spending enforcement, revenue, margin or cash reinvestment has been demonstrated. The original native work-unit controls are separate.

Published compensation prices employer and worker time; it does not establish a matched human duration or quality. The assumed traditional workflow includes ordinary non-AI tools, separate intake and employer review, correction and delivery. Source workers’ AI usage is unknown. Provider professional time is charged separately using the frozen price basis; existing benefits are not counted twice. Agent costs retain review, setup, unsuccessful work, retries, construction and recurring maintenance. The hybrid comparison charges all failed Agent work plus complete assumed traditional rescue.

The original exact-passage native component required no task-time model call. Prospective provider-orchestration usage is hypothetical. A sensitivity removing delivery model and paid-search usage remains in the downloaded complete results. The result file’s creation-time “pending audit” status is preserved; the separate exact-hash-bound independent audit records its subsequent PASS for numerical consistency only.

## Preserved working functions

The “Successive missions · live local” tab retains the sealed companion’s actual frozen module and maintained workbench. The first mission creates a useful brief; the changed-source successor imports the actual parent’s retained executable; the distinct presentation task imports it again. Invocation and contribution are shown in lineage artifacts, with downloadable original inputs and outputs. Local STOP, rollback, export and recovery remain available.

The builder verifies byte-identical selected live invocation, successor, recovery and module-resolution function bodies. It also requires the original complete HTML hash `e5a0ddd0f34199952b532a9eac7ea336186818fa6b922da98f0db08cfede65cd`. This derivative never edits the original sealed companion. Its live example is separate from the recorded `source-synthesis-01` economic anchor.

“Original study · recorded” preserves historical evidence and its unfavorable capability results. “Executor & boundaries” records the existing approved executor route and constraints. **Authenticated browser-to-approved-executor execution is NOT RUN.** Local computation, recorded execution and hypothetical economics are labeled separately.

## Build and verify

From the workspace root:

```sh
python economics_amendment_v1/browser/build_derivative.py \
  --results economics_amendment_v1/outputs/run-001/results.json \
  --audit economics_amendment_v1/evaluation/INDEPENDENT_AUDIT.json
python economics_amendment_v1/browser/qa_derivative.py
```

The builder fails closed unless all sixteen frozen inputs, authorization, original companion, model, result and independent audit identities agree. The final result is embedded as exact gzipped bytes and verified in the browser before parsing. Downloading results preserves the original JSON bytes. The evidence ZIP has fixed timestamps and an internal per-file manifest. A new result or model requires a new matching independent audit.

The offline QA checks 60 selector combinations and the corresponding 180 scenario views. It compares displayed rounded fields directly with audited JSON pointers, verifies independent semantic paths for primary metrics, checks zero-capacity nulls, and verifies exact downloaded files and archive members. It also invokes the inherited three-mission sequence and retained module, STOP, rollback, recovery and corruption refusal. These engineering checks are not additional scientific samples or a human trial.

`BUILD_MANIFEST.json` records final identities. `QA_REPORT.json` records completed automated checks. `BUILD_ATTEMPTS.jsonl` preserves attempted QA runs, including unsuccessful development attempts. `VISUAL_QA.json` records final visual inspection. Internal `qa/` screenshots and downloaded duplicates are excluded from distributed evidence; the complete shareable deliverable remains the standalone HTML and its source/receipts.

To reproduce the economics independently after extracting its downloaded evidence ZIP:

```sh
python src/model.py --root . --output outputs/reproduction-001
```

The output directory must be new. This calculation performs no provider request, deployment or financial transaction. Exact final identities and the recorded original study are authoritative; browser responsiveness and finite local previews are not continuously operating enterprise performance.
