# SPDX-License-Identifier: Apache-2.0
"""Build a separately labelled replay; never modify production-frozen code."""
import hashlib
import json
from pathlib import Path

study = Path(__file__).resolve().parents[1]
original = study / 'src/skills_graph.mjs'
source = original.read_text()
replacements = [
    ("buildGraphEpoch,verifyEpochInclusion}", "buildGraphEpoch,verifyEpochInclusion,ZERO_ROOT}"),
    ("new URL('./cleaner.py',import.meta.url)", "new URL('../src/cleaner.py',import.meta.url)"),
    ("const rootAuth=authorizeRoot(rootRecord,contexts[0],resolver);", """// Post-freeze diagnostic: bind the independent initial root state and the
// verified fixture lifecycle evidence required by the unchanged authority API.
const originalRootAuth=authorizeRoot(rootRecord,contexts[0],resolver);
const lifecycle={mode:'FIXTURE_ONLY',revokedSkills:[],supersededSkills:[],revokedRoots:[],
  evidence:'All frozen source identities, fresh acceptance, current authority, and expiry checks passed.',
  liveLifecycle:'NOT_RUN'};
const admissionsVerified=admission.every(x=>x.ok&&x.currentReuseAllowed);
const lifecycleEvidenceVerified=admissionsVerified&&skills.every(s=>s.expiresAt>contexts[0].now)&&
  attestations.every(a=>a.expiresAt>contexts[0].now);
const rootContext={...contexts[0],...lifecycle,expectedPreviousRoot:ZERO_ROOT,expectedEpoch:1,
  expectedGraphRoot:packet.graphRoot,admissionsVerified,lifecycleEvidenceVerified};
const rootAuth=authorizeRoot(rootRecord,rootContext,resolver);
const adverseRootChecks={
  missingAdmission:authorizeRoot(rootRecord,{...rootContext,admissionsVerified:false},resolver),
  missingLifecycle:authorizeRoot(rootRecord,{...rootContext,lifecycleEvidenceVerified:false},resolver),
  staleEpoch:authorizeRoot(rootRecord,{...rootContext,expectedEpoch:2},resolver),
  revokedRoot:authorizeRoot(rootRecord,{...rootContext,revokedRoots:[packet.graphRoot]},resolver)
};
if(originalRootAuth.ok||Object.values(adverseRootChecks).some(x=>x.ok))throw Error('DIAGNOSTIC_ADVERSE_CONTROL_FAILED');"""),
    ("const result={schema:'human-market-skills-graph/v1',", "const result={schema:'human-market-skills-graph/v1',status:'POST_FREEZE_DIAGNOSTIC',originalRootAuth,rootContext,adverseRootChecks,"),
    ("resolve(folder,'skills-graph.json')", "resolve(folder,'skills-graph-diagnostic.json')"),
]
for old, new in replacements:
    if source.count(old) != 1:
        raise ValueError('Unexpected source; transformation not applied: '+old)
    source = source.replace(old, new)
target = study / 'recovery/skills_graph_context_replay.mjs'
with target.open('x') as f:
    f.write(source)
record = {
    'status': 'POST_FREEZE_DIAGNOSTIC_NOT_PRIMARY_GRAPH_SUCCESS',
    'original': str(original.relative_to(study)),
    'original_sha256': hashlib.sha256(original.read_bytes()).hexdigest(),
    'replay': str(target.relative_to(study)),
    'replay_sha256': hashlib.sha256(target.read_bytes()).hexdigest(),
    'reason': 'Frozen graph driver omitted required root compare-and-swap, admissions, and lifecycle context. The unchanged authority implementation correctly refused it.',
    'transformations': [{'old': a, 'new': b} for a, b in replacements],
    'authority_or_fixture_changed': False,
    'production_changed': False,
    'live_authentication': 'NOT_RUN',
}
with (study / 'recovery/graph-diagnostic-transformation.json').open('x') as f:
    json.dump(record, f, indent=2)
    f.write('\n')
print(json.dumps({k:v for k,v in record.items() if k!='transformations'}, indent=2))
