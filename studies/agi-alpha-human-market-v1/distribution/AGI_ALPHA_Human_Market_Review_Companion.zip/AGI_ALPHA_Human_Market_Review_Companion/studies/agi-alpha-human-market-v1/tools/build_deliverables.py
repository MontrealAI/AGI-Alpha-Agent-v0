# SPDX-License-Identifier: Apache-2.0
"""Assemble user-facing research artifacts without changing frozen evidence."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import shutil
import zipfile

STUDY = Path(__file__).resolve().parents[1]
WORKSPACE = STUDY.parents[1]
OUTPUT = WORKSPACE / 'output/human_market'
PREFIX = 'studies/agi-alpha-human-market-v1/'


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def encoded(value: object) -> bytes:
    return (json.dumps(value, indent=2, ensure_ascii=False, sort_keys=True)+'\n').encode()


def put(archive: zipfile.ZipFile, name: str, data: bytes) -> None:
    entry = zipfile.ZipInfo(name, date_time=(2026,10,26,0,0,0))
    entry.external_attr = 0o100644 << 16
    entry.compress_type = zipfile.ZIP_STORED if name.endswith('.gz') else zipfile.ZIP_DEFLATED
    archive.writestr(entry, data, compresslevel=7)


VERIFY = b'''# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
manifest=json.loads((root/'COMPANION_MANIFEST.json').read_text())
for item in manifest['files']:
    p=(root/item['path']).resolve()
    if not p.is_relative_to(root):raise SystemExit('UNSAFE_PATH')
    b=p.read_bytes()
    if len(b)!=item['bytes'] or hashlib.sha256(b).hexdigest()!=item['sha256']:
        raise SystemExit('IDENTITY_MISMATCH:'+item['path'])
print(json.dumps({'status':'PASS','verified_files':len(manifest['files']),
    'bytes':sum(i['bytes'] for i in manifest['files']),'new_experiment_run':False}))
'''


def make_archive(name: str, root: str, files: dict[str, bytes], kind: str) -> dict:
    files = dict(files)
    files['verify_companion.py'] = VERIFY
    manifest = {'schema':'agi-alpha-human-market-artifact/v1','kind':kind,
                'created_date':'2026-10-26','actual_collections_usd':0,
                'files':[{'path':p,'bytes':len(b),'sha256':sha(b)} for p,b in sorted(files.items())]}
    files['COMPANION_MANIFEST.json'] = encoded(manifest)
    target=OUTPUT/name
    with zipfile.ZipFile(target,'w') as z:
        for p,b in sorted(files.items()):put(z,root+'/'+p,b)
    with zipfile.ZipFile(target) as z:
        bad=z.testzip()
        if bad:raise RuntimeError('ZIP_CRC:'+bad)
        for item in manifest['files']:
            if sha(z.read(root+'/'+item['path']))!=item['sha256']:
                raise RuntimeError('ZIP_PAYLOAD_IDENTITY:'+item['path'])
    return {'file':name,'bytes':target.stat().st_size,'sha256':sha(target.read_bytes()),
            'members':len(files),'payload_bytes':sum(len(b) for b in files.values()),
            'manifest_sha256':sha(encoded(manifest)),'crc_and_every_payload_identity':'PASS'}


def full_files() -> dict[str,bytes]:
    result={}
    for parent in [STUDY,WORKSPACE/'upstream']:
        for p in parent.rglob('*'):
            if not p.is_file():continue
            rel=p.relative_to(WORKSPACE)
            if '__pycache__' in rel.parts or 'reproductions' in rel.parts:continue
            if rel.as_posix().startswith(PREFIX+'publication/'):continue
            if rel.as_posix().startswith(PREFIX+'paper/build/'):continue
            if p.suffix in {'.pyc','.pyo'}:continue
            result[rel.as_posix()]=p.read_bytes()
    result['START_HERE.md']=('''# AGI ALPHA Human-Market Advantage: complete companion

Start with studies/agi-alpha-human-market-v1/README.md and the 20-page paper.
Open the self-contained English/French HTML in the demo directory offline.
The paper, code, upstream source, frozen protocols, synthetic inputs and released
answer keys, complete production packets, all simulated cash histories, reviews,
corrections and negative findings are included. Actual collections are zero.

Verify every archived payload with: python3 verify_companion.py
Then verify scientific source/protocol/output identities with:
python3 studies/agi-alpha-human-market-v1/tools/reproduce.py verify

All monetary outcomes are explicitly simulated. Actual complete money and buyer
demand remain unknown. A replay of archived work is not new confirmation.
No credentials, network, paid API or infrastructure restart is required.
''').encode()
    return result


def main() -> None:
    OUTPUT.mkdir(parents=True,exist_ok=True)
    records=[]
    for source,name in [
        (STUDY/'paper/AGI_ALPHA_Human_Market_Advantage.pdf','AGI_ALPHA_Human_Market_Advantage.pdf'),
        (STUDY/'demo/AGI_ALPHA_Human_Market_Demonstration.html','AGI_ALPHA_Human_Market_Demonstration.html')]:
        target=OUTPUT/name;shutil.copyfile(source,target)
        records.append({'file':name,'bytes':target.stat().st_size,'sha256':sha(target.read_bytes())})

    paper={}
    for rel in ['AGI_ALPHA_Human_Market_Advantage.tex','verification_note.tex','build_figures.py']:
        paper[rel]=(STUDY/'paper'/rel).read_bytes()
    for p in (STUDY/'paper/figures').glob('*'):
        if p.is_file():paper['figures/'+p.name]=p.read_bytes()
    paper['README.txt']=b'''Publication-ready LaTeX source, English paper with French summary.
Run latexmk -pdf -interaction=nonstopmode -halt-on-error AGI_ALPHA_Human_Market_Advantage.tex
using existing standard TeX packages. The figures are already supplied; regenerating
them with build_figures.py requires the complete companion's saved study data.
No new simulation is run by the paper. The original French Babel dependency failure
was resolved without installing packages; the French text uses standard T1 fonts.
'''
    records.append(make_archive('AGI_ALPHA_Human_Market_LaTeX_Source.zip','AGI_ALPHA_Human_Market_LaTeX',paper,'LaTeX and figures'))

    packet={p.name:p.read_bytes() for p in (STUDY/'results/primary/main-versioned-01/G2').iterdir() if p.is_file()}
    packet['ACCEPTANCE_CONTEXT.txt']=b'''Actual synthetic accepted delivery: main-versioned-01/G2.
1288 source records:303 clean,384 quarantined,343 duplicates,258 superseded.
Independent exact factual/package acceptance; not external customer acceptance.
Review READ_ME.txt. Import clean.csv with explicit text types for identifiers.
No missing source fact was guessed. Original data and every disposition are retained.
Actual collections USD0; native HOLD, authority[], settlement NOT_CONNECTED.
'''
    records.append(make_archive('AGI_ALPHA_Accepted_CSV_Packet.zip','AGI_ALPHA_Accepted_CSV_Packet',packet,'Actual synthetic accepted customer-facing packet'))

    offering={}
    for p in (STUDY/'src').glob('*'):
        if p.is_file() and p.suffix in {'.py','.mjs'}:offering[PREFIX+'src/'+p.name]=p.read_bytes()
    offering[PREFIX+'protocol/DELIVERY_CONTRACT.md']=(STUDY/'protocol/DELIVERY_CONTRACT.md').read_bytes()
    for p in (WORKSPACE/'upstream').rglob('*'):
        if p.is_file() and '__pycache__' not in p.parts:offering[p.relative_to(WORKSPACE).as_posix()]=p.read_bytes()
    case=STUDY/'acceptance/execution_layout/main-versioned-01'
    for p in case.iterdir():
        if p.is_file():offering[PREFIX+'example/'+p.name]=p.read_bytes()
    for name,content in packet.items():offering['accepted-example/'+name]=content
    offering['START_HERE.md']=b'''# Working bounded CSV offering

This small archive supplies the exact frozen delivery implementation, upstream
source/licenses, one synthetic input, and its accepted output. It is not the full
scientific companion: complete freezes, oracle corpus and economics are separate.

Requirements: existing Python3 and Node. Original versions3.12.14 and24.22.1.
No pip/npm install, credentials, paid calls or infrastructure startup is required.

From this archive root:
python3 verify_companion.py
python3 studies/agi-alpha-human-market-v1/src/deliver.py --job studies/agi-alpha-human-market-v1/example/job.json --generation 2 --out replay-output

Use a new output directory. Inspect summary.json for COMPLETED, then compare
semantic.json with accepted-example/semantic.json. The output is a clean-and-
exception packet, not a guarantee that every input row is import-ready.
Read the supplied DELIVERY_CONTRACT.md before supplying other permitted inputs.
The runner verifies the declared source SHA256; no confidential data is authorized.
The other source files preserve the source identity; study/graph/campaign commands
need the complete companion and are not the delivery entry point for this archive.

Runtime model calls0. Actual complete research/delivery money unknown; collections0.
HOLD, no execution authority, no settlement. Research reproduction only.
'''
    records.append(make_archive('AGI_ALPHA_CSV_Offering.zip','AGI_ALPHA_CSV_Offering',offering,'Executable bounded service with exact accepted example'))

    records.append(make_archive('AGI_ALPHA_Human_Market_Full_Companion.zip','AGI_ALPHA_Human_Market_Companion',full_files(),'Complete scientific evidence companion'))
    (OUTPUT/'ARTIFACTS.json').write_bytes(encoded({'schema':'human-market-delivery-artifacts/v1','artifacts':records}))
    print(json.dumps(records,indent=2))


if __name__=='__main__':main()
