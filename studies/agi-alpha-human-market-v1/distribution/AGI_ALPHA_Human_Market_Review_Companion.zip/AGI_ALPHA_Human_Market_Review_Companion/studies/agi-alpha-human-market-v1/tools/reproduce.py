# SPDX-License-Identifier: Apache-2.0
"""Verify archived identities or replay frozen work into a new output directory."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
from datetime import datetime, timezone

STUDY = Path(__file__).resolve().parents[1]
WORKSPACE = STUDY.parents[1]


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify() -> dict:
    checked = []
    for name, base in [
        ('protocol/production-freeze.json', WORKSPACE),
        ('protocol/economics-source-freeze.json', STUDY),
        ('review/transfer/source-freeze.json', WORKSPACE),
    ]:
        freeze = json.loads((STUDY / name).read_text())
        for item in freeze['files']:
            path = (base / item['path']).resolve()
            if not path.is_relative_to(WORKSPACE) or sha(path) != item['sha256']:
                raise ValueError('Frozen identity mismatch: ' + item['path'])
        checked.append({'manifest': name, 'sha256': sha(STUDY / name), 'files': len(freeze['files'])})
    for edition in ['primary', 'boundary']:
        folder = STUDY / ('results/economics-' + edition + '-01')
        completion = json.loads((folder / 'completion.json').read_text())
        if completion['complete'] is not True:
            raise ValueError('Archived economic campaign incomplete')
        for artifact in completion['artifacts']:
            if sha(folder / artifact['path']) != artifact['sha256']:
                raise ValueError('Economic output mismatch: ' + artifact['path'])
    return {'status': 'PASS', 'frozen_manifests': checked,
            'economic_output_hashes_checked': True, 'new_experiment_run': False,
            'actual_collections_usd': 0}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['verify', 'delivery', 'production-replay', 'market-primary', 'market-diagnostic'])
    parser.add_argument('--out', type=Path)
    args = parser.parse_args()
    receipt = verify()
    if args.action == 'verify':
        print(json.dumps(receipt, indent=2))
        return
    default = STUDY / 'reproductions' / (args.action + '-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ'))
    out = (args.out or default).resolve()
    if out.exists():
        raise SystemExit('Output exists; choose a new directory to preserve evidence')
    out.parent.mkdir(parents=True, exist_ok=True)
    node = os.environ.get('CODEX_PRIMARY_RUNTIME_NODE') or shutil.which('node')
    if args.action == 'delivery':
        command = [sys.executable, str(STUDY/'src/deliver.py'), '--job',
                   str(STUDY/'acceptance/execution_layout/main-versioned-01/job.json'),
                   '--generation', '2', '--out', str(out)]
    elif args.action == 'production-replay':
        if not out.is_relative_to(STUDY):
            raise SystemExit('The frozen campaign requires output inside the study; use its default')
        command = [sys.executable, str(STUDY/'src/campaign.py'), '--inputs',
                   str(STUDY/'acceptance/execution_layout'), '--out', str(out)]
    else:
        if node is None:
            raise SystemExit('Node is required; no dependency installation is attempted')
        edition = 'primary' if args.action == 'market-primary' else 'boundary'
        command = [node, str(STUDY/'economics/run-campaign.mjs'),
                   str(STUDY/('protocol/economics-primary/campaign-'+edition+'.json')),
                   str(STUDY/'protocol/economics-source-freeze.json'), str(out)]
    print(json.dumps({'kind': 'ARCHIVED_INPUT_REPRODUCTION_NOT_FRESH_CONFIRMATION',
                      'command': command, 'output': str(out)}), flush=True)
    completed = subprocess.run(command, cwd=STUDY, check=False)
    if completed.returncode:
        raise SystemExit(completed.returncode)
    if args.action == 'delivery':
        summary = json.loads((out / 'summary.json').read_text())
        expected = STUDY / 'results/primary/main-versioned-01/G2/semantic.json'
        if summary.get('status') != 'COMPLETED' or sha(out / 'semantic.json') != sha(expected):
            raise SystemExit('Delivery reproduction did not match the archived accepted semantics')
    elif args.action == 'production-replay':
        command = [sys.executable, str(STUDY/'acceptance/verify_results.py'),
                   '--index', str(out/'index.json'), '--sealed-index-sha256', sha(out/'index.json'),
                   '--keys', str(STUDY/'acceptance/private_keys'), '--inputs', str(STUDY/'acceptance/inputs'),
                   '--base', str(STUDY), '--out', str(out/'acceptance.json')]
        verdict_run = subprocess.run(command, cwd=STUDY, check=False)
        verdict = json.loads((out/'acceptance.json').read_text())
        if verdict_run.returncode or not verdict.get('all_checks_passed'):
            raise SystemExit('Production reproduction failed independent acceptance')
    verify()
    print(json.dumps({'status': 'REPRODUCTION_COMPLETED', 'output': str(out)}))


if __name__ == '__main__':
    main()
