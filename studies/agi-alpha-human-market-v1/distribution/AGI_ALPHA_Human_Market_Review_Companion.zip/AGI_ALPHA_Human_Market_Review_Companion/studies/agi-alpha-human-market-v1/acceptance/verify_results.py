import argparse
import csv
import hashlib
import json
from collections import Counter
from pathlib import Path

PARTS = ("clean", "quarantine", "duplicates", "superseded", "disposition")


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def resolve(base, value):
    p = Path(value)
    return p if p.is_absolute() else base / p


def compare_semantic(expected, actual):
    if not isinstance(actual, dict) or set(actual) != set(PARTS):
        return [{"kind": "semantic_top_level", "expected": list(PARTS), "actual_type": type(actual).__name__,
                 "actual_keys": sorted(actual) if isinstance(actual, dict) else None}]
    problems = []
    for part in PARTS:
        if not isinstance(actual[part], list):
            problems.append({"kind": "part_type", "part": part})
            continue
        if len(expected[part]) != len(actual[part]):
            problems.append({"kind": "length", "part": part, "expected": len(expected[part]), "actual": len(actual[part])})
        changes = []
        for i, (e, a) in enumerate(zip(expected[part], actual[part])):
            if canonical(e) != canonical(a):
                changes.append({"index": i, "expected": e, "actual": a})
                if len(changes) == 3:
                    break
        if changes:
            problems.append({"kind": "content", "part": part, "first_mismatches": changes})
    return problems


def verify_package(outdir, expected, source_hash):
    problems = []
    layouts = {
        "clean.csv": (["record_id", "category", "date", "amount", "updated_at", "source_row"], expected["clean"]),
        "exceptions.csv": (["source_row", "reasons"], [{"source_row": x["source_row"], "reasons": "|".join(x["reasons"])} for x in expected["quarantine"]]),
        "duplicates.csv": (["source_row", "kept_source_row"], expected["duplicates"]),
        "superseded.csv": (["source_row", "kept_source_row"], expected["superseded"]),
        "disposition.csv": (["source_row", "status"], expected["disposition"]),
    }
    for name, (fields, rows) in layouts.items():
        path = outdir / name
        if not path.is_file():
            problems.append({"kind": "missing_package_file", "name": name})
            continue
        with path.open(encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            actual = list(reader)
            wanted = [{k: str(row[k]) for k in fields} for row in rows]
            if reader.fieldnames != fields or actual != wanted:
                problems.append({"kind": "package_csv_mismatch", "name": name, "actual_rows": len(actual), "expected_rows": len(wanted)})
    original = outdir / "original.csv"
    if not original.is_file() or sha(original) != source_hash:
        problems.append({"kind": "original_source_identity"})
    job = load(outdir / "job.json")
    if job.get("source", {}).get("sha256") != source_hash:
        problems.append({"kind": "packaged_job_source_identity"})
    manifest = load(outdir / "delivery-manifest.json")
    listed = set()
    for entry in manifest.get("files", []):
        name = entry.get("name")
        if not isinstance(name, str) or Path(name).name != name or name in listed:
            problems.append({"kind": "invalid_manifest_member", "name": name})
            continue
        listed.add(name)
        path = outdir / name
        if not path.is_file() or path.stat().st_size != entry.get("bytes") or sha(path) != entry.get("sha256"):
            problems.append({"kind": "manifest_member_identity", "name": name})
    required = set(layouts) | {"semantic.json", "original.csv", "job.json", "quality.json", "READ_ME.txt"}
    if not required.issubset(listed):
        problems.append({"kind": "manifest_coverage", "missing": sorted(required - listed)})
    pack = load(outdir / "workbench-pack.json")
    evaluation = pack.get("evaluation", {})
    expected_evaluation = {"scope": "PUBLIC_LOCAL_EXECUTION", "independentProof": False, "admission": "HOLD", "authority": [], "settlement": "NOT_CONNECTED"}
    for key, value in expected_evaluation.items():
        if canonical(evaluation.get(key)) != canonical(value):
            problems.append({"kind": "native_boundary", "field": key, "expected": value, "actual": evaluation.get(key)})
    if canonical(pack.get("spec", {}).get("inputs")) != canonical(manifest):
        problems.append({"kind": "native_manifest_binding"})
    if not isinstance(pack.get("integrityDigest"), str) or len(pack["integrityDigest"]) != 64:
        problems.append({"kind": "native_integrity_digest_missing"})
    load(outdir / "ti-summary.json")
    return problems


def verify_one(key, record, base, inputs):
    job_id, generation = record["job_id"], str(record["generation"])
    expected = key["expected_status"][generation]
    status = record["status"]
    outdir = resolve(base, record["output_dir"])
    problems = []
    actual_source = inputs / f"{job_id}.csv"
    if not actual_source.is_file() or sha(actual_source) != key["actual_source_sha256"]:
        problems.append({"kind": "source_bytes_changed"})
    if record.get("source_sha256") != key["actual_source_sha256"]:
        problems.append({"kind": "index_source_identity"})
    summary_path = outdir / "summary.json"
    if summary_path.is_file():
        summary = load(summary_path)
        if (summary.get("status"), str(summary.get("generation")), summary.get("job_id")) != (status, generation, job_id):
            problems.append({"kind": "summary_index_disagreement"})
    else:
        problems.append({"kind": "missing_summary"})
    if status != expected:
        problems.append({"kind": "status", "expected": expected, "actual": status})
    semantic_path = outdir / "semantic.json"
    if status == "COMPLETED":
        if not semantic_path.is_file():
            problems.append({"kind": "missing_semantic"})
        else:
            actual_hash = sha(semantic_path)
            if record.get("semantic_sha256") != actual_hash:
                problems.append({"kind": "semantic_hash"})
            if expected == "COMPLETED":
                problems.extend(compare_semantic(key["semantic"], load(semantic_path)))
                problems.extend(verify_package(outdir, key["semantic"], key["actual_source_sha256"]))
            else:
                problems.append({"kind": "unsupported_or_malformed_completion"})
    elif record.get("semantic_sha256") is not None:
        problems.append({"kind": "refusal_has_semantic_hash"})
    return {"job_id": job_id, "generation": int(generation), "panel": key["panel"], "case_class": key["case_class"],
            "expected_status": expected, "actual_status": status, "checks_pass": not problems,
            "accepted_completed_delivery": not problems and expected == "COMPLETED",
            "expected_safe_refusal": not problems and expected == "REFUSED", "problems": problems}


def batch(index_path, sealed_hash, keys, inputs, base):
    if sha(index_path) != sealed_hash:
        raise SystemExit("Prediction index differs from the pre-assessment sealed identity")
    data = load(index_path)
    records = data["records"]
    key_files = {p.stem: p for p in keys.glob("*.json") if p.name != "generation_receipt.json"}
    if len(key_files) != 30:
        raise SystemExit(f"Expected 30 frozen answer keys; found {len(key_files)}")
    expected_pairs = {(key, gen) for key in key_files for gen in range(3)}
    pairs = [(r.get("job_id"), r.get("generation")) for r in records]
    counts = Counter(pairs)
    structural = []
    receipt = load(keys / "generation_receipt.json")
    contract = keys.parent.parent / "protocol" / "DELIVERY_CONTRACT.md"
    if sha(contract) != receipt["contract_sha256"]:
        structural.append({"kind": "contract_changed_after_generation"})
    if len(records) != 90:
        structural.append({"kind": "prediction_count", "expected": 90, "actual": len(records)})
    if set(pairs) != expected_pairs:
        structural.append({"kind": "campaign_coverage", "missing": sorted(expected_pairs - set(pairs)), "extra": sorted(set(pairs) - expected_pairs)})
    if any(count != 1 for count in counts.values()):
        structural.append({"kind": "duplicate_prediction_pairs", "pairs": [list(k) for k, v in counts.items() if v != 1]})
    key_seals_path = keys.parent / "key_seals.json"
    if key_seals_path.is_file():
        for entry in load(key_seals_path)["keys"]:
            if sha(keys / (entry["job_id"] + ".json")) != entry["sha256"]:
                structural.append({"kind": "answer_key_changed", "job_id": entry["job_id"]})
    else:
        structural.append({"kind": "missing_answer_key_seals"})
    outcomes = []
    for record in records:
        if (record.get("job_id"), record.get("generation")) not in expected_pairs:
            continue
        try:
            outcomes.append(verify_one(load(key_files[record["job_id"]]), record, base, inputs))
        except Exception as exc:
            outcomes.append({"job_id": record["job_id"], "generation": record["generation"], "checks_pass": False,
                             "accepted_completed_delivery": False, "expected_safe_refusal": False,
                             "problems": [{"kind": "verification_exception", "type": type(exc).__name__, "message": str(exc)}]})
    summary = []
    for panel in ("primary", "stress"):
        for gen in range(3):
            selected = [x for x in outcomes if x.get("panel") == panel and x["generation"] == gen]
            summary.append({"panel": panel, "generation": gen, "records": len(selected),
                            "accepted_completed": sum(x["accepted_completed_delivery"] for x in selected),
                            "expected_safe_refusals": sum(x["expected_safe_refusal"] for x in selected),
                            "failed_checks": sum(not x["checks_pass"] for x in selected)})
    all_checks = not structural and all(x["checks_pass"] for x in outcomes)
    accepted = {f"G{g}": sum(x["accepted_completed_delivery"] for x in outcomes if x.get("panel") == "primary" and x["generation"] == g) for g in range(3)}
    accepted_by_class = {f"G{g}": {c: sum(x["accepted_completed_delivery"] for x in outcomes if x.get("panel") == "primary" and x["generation"] == g and x.get("case_class") == c)
                                  for c in ("simple", "locale", "versioned")} for g in range(3)}
    return {"schema": "independent-acceptance-audit/v1", "sealed_index_sha256": sealed_hash,
            "production_freeze_sha256": receipt["production_freeze_sha256"], "contract_sha256": receipt["contract_sha256"],
            "independence": "Same-session separate test author; no external customer/professional acceptance",
            "all_checks_passed": all_checks, "all_planned_checks_pass": all_checks,
            "accepted_primary_by_generation": accepted, "accepted_primary_by_generation_and_class": accepted_by_class,
            "structural_problems": structural, "summary": summary, "outcomes": outcomes}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--index", type=Path, required=True)
    parser.add_argument("--sealed-index-sha256", required=True)
    parser.add_argument("--keys", type=Path, default=Path(__file__).parent / "private_keys")
    parser.add_argument("--inputs", type=Path, default=Path(__file__).parent / "inputs")
    parser.add_argument("--base", type=Path, default=Path.cwd())
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    verdict = batch(args.index, args.sealed_index_sha256, args.keys, args.inputs, args.base)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(verdict, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"all_planned_checks_pass": verdict["all_planned_checks_pass"], "summary": verdict["summary"],
                      "structural_problems": verdict["structural_problems"]}))
    raise SystemExit(0 if verdict["all_planned_checks_pass"] else 1)
