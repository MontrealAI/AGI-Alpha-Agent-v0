# Separately authored synthetic confirmation corpus

This acceptance lane was authored in the same session by a separate contributor who read the
delivery contract and did not inspect production implementation source. It is an independent
factual check within this study, not external customer or professional acceptance.

The generator first constructs canonical latent records, their intended group roles and seeded
faults. A renderer produces CSV text independently. Expected results come from latent facts:
selected version roles, deliberately conflicting groups, explicitly authored invalid-field codes,
and first source occurrence after a random shuffle. The answer key is not produced by running the
delivery normalizer. Parsed-record count is checked with Python's ordinary CSV parser only in
developmental encoder checks; it does not derive the primary oracle.

The protocol fixes 24 primary jobs (eight simple, eight locale, eight versioned) containing 800–1600
data records, and six separate stresses: 50,000 records, quoting/newlines, latest-version ties with
missing or invalid fields, wrong source hash, duplicate headings and invalid UTF-8. Case identifiers
and classes are fixed in generator source; record details are determined by postfreeze entropy.
Inputs are synthetic and nonpersonal. Dispositions do not infer professional judgment or demand.

Primary cases deliberately include exact normalized duplicates whose first representative can be
quarantined or superseded. Duplicate links stay attached to that first representative. They also
include valid and invalid calendar boundaries, exact amount bounds, negative zero, original-case
and leading-zero identifiers, Unicode normalization, quoted separators/newlines, category maps,
map-to-missing cases and multiple reason codes. Locale and versioned capabilities are new support
coverage in these particular executable versions, not evidence that a competent agent cannot
reconstruct them.

## Sequence

1. Freeze production source, contract and generator before generating confirmation bytes.
2. Supply postfreeze entropy and the exact production-freeze identity to the generator.
3. Keep `private_keys/` outside delivery prompts and inputs. Do not inspect them during production.
4. Run each job once per generation, preserving failures and safe refusals.
5. Seal the complete prediction index and all semantic-output hashes before answer-key disclosure.
6. Run the separate verifier using the previously sealed index identity. Preserve the verdict even
   if it fails; any repair requires a newly declared exploratory campaign and fresh cases.

`generate_fresh_jobs.py --self-test` checks developmental encoder and partition invariants and emits
no confirmation data. Full generation refuses to overwrite existing `inputs/` or `private_keys/`.
`verify_results.py` checks exact semantic equality, source and prediction identities, answer-key
seals, status agreement and coverage of all 90 planned generation/job pairs. Correct refusals are
reported separately and never counted as accepted completed deliveries.

The recorded creation time, generator identity, freeze identity, private seed, public source
manifest and answer-key seals permit replay and audit after predictions are sealed. They do not
claim cryptographic independence from the study owner or live identity authentication.
