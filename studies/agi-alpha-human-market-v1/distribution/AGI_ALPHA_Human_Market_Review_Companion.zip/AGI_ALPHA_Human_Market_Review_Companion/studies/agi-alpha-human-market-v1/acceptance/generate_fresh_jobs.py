import argparse
import csv
import hashlib
import io
import json
import random
import unicodedata
from collections import defaultdict
from datetime import date, datetime, timezone
from pathlib import Path

FIELDS = ["record_id", "category", "date", "amount", "updated_at"]
VERSION = "independent-latent-oracle/v1"


def dump(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")


def digest(data):
    return hashlib.sha256(data).hexdigest()


def amount_text(cents, locale, rng):
    if cents == 0 and rng.random() < 0.5:
        return rng.choice(["-0", "-0.00" if locale == "dot" else "-0,00"])
    sign = "-" if cents < 0 else ""
    whole, fractional = divmod(abs(cents), 100)
    integer = str(whole)
    if locale == "comma" and whole >= 1000 and rng.random() < 0.6:
        integer = f"{whole:,}".replace(",", ".")
    separator = "," if locale == "comma" else "."
    if fractional == 0 and rng.random() < 0.4:
        return sign + integer
    if fractional % 10 == 0 and rng.random() < 0.4:
        return f"{sign}{integer}{separator}{fractional // 10}"
    return f"{sign}{integer}{separator}{fractional:02d}"


def canonical_amount(cents):
    whole, fractional = divmod(abs(cents), 100)
    return f"{'-' if cents < 0 else ''}{whole}.{fractional:02d}"


def render(canonical, rules, rng, cents, category_alias):
    raw = dict(canonical)
    raw["amount"] = amount_text(cents, rules["amount_locale"], rng)
    d = date.fromisoformat(canonical["date"])
    raw["date"] = d.strftime("%d/%m/%Y") if rules["date_format"] == "dmy" else d.isoformat()
    raw["category"] = category_alias
    if canonical["updated_at"] == "":
        raw["updated_at"] = rng.choice(["", "NA", "null"])
    for key in FIELDS:
        if rng.random() < 0.32:
            raw[key] = "  " + raw[key] + "\t"
        if rng.random() < 0.25:
            raw[key] = unicodedata.normalize("NFD", raw[key])
    return raw


def build_case(rng, row_count, rules, rich_quotes=False):
    rows = []
    decisions = {}
    n = 0
    categories = [(" general ", "General"), ("R&D", "Research"), ("Cafe\u0301", "Café"),
                  ("Unmapped", "Unmapped"), ("=NO_EXECUTION()", "=NO_EXECUTION()"),
                  ('Parts, "quoted"; série\ncontinued', 'Parts, "quoted"; série\ncontinued')]
    if rich_quotes:
        categories = categories[4:] + categories[2:4]

    def emit(group, token, canonical, cents, alias, faults=None):
        raw = render(canonical, rules, rng, cents, alias)
        reasons = []
        for field, value, reason in faults or []:
            raw[field] = value
            reasons.append(reason)
        rows.append({"group": group, "token": token, "canonical": canonical,
                     "raw": raw, "reasons": sorted(set(reasons))})

    while len(rows) < row_count:
        n += 1
        prefix = "" if n % 13 == 0 else ("É" if n % 17 == 0 else ("k" if n % 7 == 0 else "K"))
        key = f"{prefix}{n:07d}"
        alias, normalized = rng.choice(categories)
        cents = rng.choice([0, -0, 1, -1, 99, -99, 100, -100, 123456, -987654321,
                            999999999999, -999999999999, rng.randrange(-100000000, 100000000)])
        day = date(rng.choice([1900, 2000, 2024, 2025, 2026, 2099, 2100]), rng.randrange(1, 13), rng.randrange(1, 28))
        if rng.random() < 0.1:
            day = rng.choice([date(2000, 2, 29), date(2024, 2, 29), date(1900, 1, 1), date(2100, 12, 31)])
        canonical = {"record_id": key, "category": normalized, "date": day.isoformat(),
                     "amount": canonical_amount(cents), "updated_at": "2026-04-08" if rules["key_policy"] == "latest" else ""}
        remaining = row_count - len(rows)
        pattern = n % 11
        if remaining < 5:
            pattern = 0
        if pattern in (0, 1, 2):
            decisions[key] = {"kind": "select", "token": "v0"}
            emit(key, "v0", canonical, cents, alias)
            if pattern == 1:
                emit(key, "v0", canonical, cents, alias)
                emit(key, "v0", canonical, cents, alias)
            continue
        if pattern in (3, 4, 5):
            invalid = [
                [("record_id", " NA ", "MISSING_RECORD_ID")],
                [("category", "missing-alias", "MISSING_CATEGORY")],
                [("date", "null", "MISSING_DATE"), ("amount", "", "MISSING_AMOUNT")],
                [("date", "2026-02-30" if rules["date_format"] == "iso" else "30/02/2026", "INVALID_DATE")],
                [("date", "20260201" if rules["date_format"] == "iso" else "1/2/2026", "INVALID_DATE")],
                [("amount", "1e3", "INVALID_AMOUNT")],
                [("amount", "1.234" if rules["amount_locale"] == "dot" else "1,234", "INVALID_AMOUNT")],
                [("amount", "+12.00", "INVALID_AMOUNT"), ("updated_at", "2026-13-01", "INVALID_UPDATED_AT")],
                [("date", "1899-12-31" if rules["date_format"] == "iso" else "31/12/1899", "INVALID_DATE")],
                [("date", "2101-01-01" if rules["date_format"] == "iso" else "01/01/2101", "INVALID_DATE")],
                [("date", "1900-02-29" if rules["date_format"] == "iso" else "29/02/1900", "INVALID_DATE")],
                [("amount", "10000000000.00" if rules["amount_locale"] == "dot" else "10000000000,00", "INVALID_AMOUNT")],
                [("record_id", "", "MISSING_RECORD_ID"), ("category", "NA", "MISSING_CATEGORY"),
                 ("date", "invalid", "INVALID_DATE"), ("amount", "$50", "INVALID_AMOUNT")],
                [("updated_at", "1899-12-31", "INVALID_UPDATED_AT")],
                [("updated_at", "20260817", "INVALID_UPDATED_AT")],
            ]
            if rules["amount_locale"] == "comma":
                invalid += [[("amount", "12.34,56", "INVALID_AMOUNT")], [("amount", "1,234.56", "INVALID_AMOUNT")]]
            if rules["key_policy"] == "latest":
                invalid += [[("updated_at", "NA", "MISSING_UPDATED_AT")], [("updated_at", "", "MISSING_UPDATED_AT")]]
            faults = rng.choice(invalid)
            emit(key, "invalid", canonical, cents, alias, faults)
            if pattern == 5:
                decisions[key] = {"kind": "select", "token": "v0"}
                emit(key, "v0", canonical, cents, alias)
            continue
        if rules["key_policy"] == "hold":
            decisions[key] = {"kind": "conflict", "reason": "CONFLICTING_KEY"}
            other = dict(canonical, amount=canonical_amount(cents - 1 if cents == 999999999999 else cents + 1))
            other_cents = cents - 1 if cents == 999999999999 else cents + 1
            emit(key, "v0", canonical, cents, alias)
            emit(key, "v1", other, other_cents, alias)
            if pattern in (6, 8):
                emit(key, "v0", canonical, cents, alias)
        else:
            old = dict(canonical, updated_at="2025-12-01")
            newer = dict(canonical, updated_at="2026-08-17")
            if pattern in (6, 7, 8):
                decisions[key] = {"kind": "select", "token": "v2"}
                emit(key, "v0", old, cents, alias)
                emit(key, "v1", canonical, cents, alias)
                emit(key, "v2", newer, cents, alias)
                emit(key, "v0", old, cents, alias)
                if pattern == 8:
                    emit(key, "v2", newer, cents, alias)
            else:
                decisions[key] = {"kind": "conflict", "reason": "CONFLICTING_LATEST"}
                other_cents = cents - 1 if cents == 999999999999 else cents + 1
                tied = dict(newer, amount=canonical_amount(other_cents))
                emit(key, "v0", old, cents, alias)
                emit(key, "v1", newer, cents, alias)
                emit(key, "v2", tied, other_cents, alias)
                emit(key, "v1", newer, cents, alias)
    rng.shuffle(rows)
    result = {"clean": [], "quarantine": [], "duplicates": [], "superseded": [], "disposition": []}
    first = {}
    representatives = defaultdict(dict)
    for number, row in enumerate(rows, 1):
        row["source_row"] = number
        if not row["reasons"]:
            identity = (row["group"], row["token"])
            first.setdefault(identity, number)
            if first[identity] == number:
                representatives[row["group"]][row["token"]] = number
    for row in rows:
        number = row["source_row"]
        if row["reasons"]:
            status = "QUARANTINE"
            result["quarantine"].append({"source_row": number, "reasons": row["reasons"]})
        elif first[(row["group"], row["token"])] != number:
            status = "DUPLICATE_EXACT"
            result["duplicates"].append({"source_row": number, "kept_source_row": first[(row["group"], row["token"])]})
        else:
            decision = decisions[row["group"]]
            if decision["kind"] == "conflict":
                status = "QUARANTINE"
                result["quarantine"].append({"source_row": number, "reasons": [decision["reason"]]})
            elif row["token"] == decision["token"]:
                status = "CLEAN"
                result["clean"].append(dict(row["canonical"], source_row=number))
            else:
                status = "SUPERSEDED"
                result["superseded"].append({"source_row": number, "kept_source_row": representatives[row["group"]][decision["token"]]})
        result["disposition"].append({"source_row": number, "status": status})
    result["clean"].sort(key=lambda x: x["record_id"])
    assert len(rows) == row_count
    assert sum(len(result[k]) for k in ("clean", "quarantine", "duplicates", "superseded")) == row_count
    assert len({x["record_id"] for x in result["clean"]}) == len(result["clean"])
    return rows, result


def rules_for(data_class, index):
    locale, date_format, key = "dot", "iso", "hold"
    if data_class == "locale":
        locale, date_format = "comma", "dmy"
    elif data_class == "versioned":
        locale, date_format, key = ("dot" if index % 2 == 0 else "comma"), ("iso" if index % 4 < 2 else "dmy"), "latest"
    return {"delimiter": ";" if index % 2 else ",", "amount_locale": locale, "date_format": date_format,
            "key_policy": key, "missing_markers": ["", "NA", "null"],
            "category_map": {"general": "General", "R&D": "Research", "missing-alias": "NA"}}


def encode(rows, rules, bom, duplicate_heading=False, bad_utf8=False):
    out = io.StringIO(newline="")
    writer = csv.writer(out, delimiter=rules["delimiter"], lineterminator="\r\n")
    writer.writerow(FIELDS if not duplicate_heading else ["record_id", "category", "date", "amount", "record_id"])
    writer.writerows([[row["raw"][field] for field in FIELDS] for row in rows])
    data = ("\ufeff" if bom else "") + out.getvalue()
    encoded = data.encode("utf-8")
    if bad_utf8:
        encoded += b"\xff\xfe\n"
    assert len(encoded) <= 10 * 1024 * 1024
    return encoded


def generate(seed, output, production_freeze):
    root_rng = random.Random(seed)
    specs = [(f"main-{c}-{i + 1:02d}", "primary", c, i, root_rng.randint(800, 1600), None)
             for c in ("simple", "locale", "versioned") for i in range(8)]
    specs.extend([
        ("stress-01-scale", "stress", "simple", 0, 50000, "scale"),
        ("stress-02-quoted", "stress", "simple", 1, 1000, "quoted"),
        ("stress-03-ties", "stress", "versioned", 3, 1000, "ties"),
        ("stress-04-bad-hash", "stress", "simple", 0, 800, "bad_hash"),
        ("stress-05-headings", "stress", "simple", 0, 800, "duplicate_headings"),
        ("stress-06-utf8", "stress", "simple", 0, 800, "invalid_utf8"),
    ])
    if (output / "inputs").exists() or (output / "private_keys").exists():
        raise SystemExit("Refusing to replace existing confirmation inputs or answer keys")
    public = []
    key_seals = []
    for job_id, panel, data_class, index, count, stress in specs:
        rng = random.Random(root_rng.getrandbits(128))
        rules = rules_for(data_class, index)
        rows, result = build_case(rng, count, rules, stress == "quoted")
        data = encode(rows, rules, bool(index % 3 == 0), stress == "duplicate_headings", stress == "invalid_utf8")
        source_hash = digest(data)
        job = {"schema": "csv-clean-job/v1", "id": job_id, "data_class": "synthetic",
               "source": {"file": job_id + ".csv", "sha256": "0" * 64 if stress == "bad_hash" else source_hash}, "rules": rules}
        source_path = output / "inputs" / (job_id + ".csv")
        source_path.parent.mkdir(parents=True, exist_ok=True)
        source_path.write_bytes(data)
        dump(output / "inputs" / (job_id + ".json"), job)
        malformed = stress in ("bad_hash", "duplicate_headings", "invalid_utf8")
        expected = {}
        for gen in range(3):
            supported = (gen >= 1 or (rules["amount_locale"] == "dot" and rules["date_format"] == "iso")) and (gen >= 2 or rules["key_policy"] == "hold")
            expected[str(gen)] = "REFUSED" if malformed or not supported else "COMPLETED"
        key = {"schema": VERSION, "job_id": job_id, "panel": panel, "case_class": data_class, "data_class": "synthetic",
               "actual_source_sha256": source_hash, "source_record_count": count, "expected_status": expected,
               "malformed_stress": malformed, "semantic": None if malformed else result,
               "latent_recipe": {"decisions_derive_from": "designed canonical group roles, not a CSV parser",
                                 "faults_derive_from": "seeded field replacements with authored reason sets"}}
        key_path = output / "private_keys" / (job_id + ".json")
        dump(key_path, key)
        key_seals.append({"job_id": job_id, "sha256": digest(key_path.read_bytes())})
        public.append({"job_id": job_id, "panel": panel, "case_class": data_class, "data_class": "synthetic", "job_file": str(source_path.with_suffix(".json").relative_to(output)),
                       "source_file": str(source_path.relative_to(output)), "source_sha256": source_hash, "source_record_count": count})
    dump(output / "inputs_manifest.json", {"schema": VERSION, "records": public})
    dump(output / "private_keys" / "generation_receipt.json", {"seed": seed, "production_freeze_sha256": production_freeze,
         "contract_sha256": digest((Path(__file__).parent.parent / "protocol" / "DELIVERY_CONTRACT.md").read_bytes()),
         "generated_at_utc": datetime.now(timezone.utc).isoformat(), "generator_sha256": digest(Path(__file__).read_bytes()), "key_seals": key_seals})
    dump(output / "key_seals.json", {"schema": VERSION, "keys": key_seals})
    print(json.dumps({"jobs_generated": len(public), "primary": 24, "stress": 6, "inputs_manifest_sha256": digest((output / "inputs_manifest.json").read_bytes()),
                      "key_seals_sha256": digest((output / "key_seals.json").read_bytes())}))


def self_test():
    for cls in ("simple", "locale", "versioned"):
        for i in range(4):
            rows, result = build_case(random.Random(1000 + i), 133, rules_for(cls, i))
            data = encode(rows, rules_for(cls, i), True)
            parsed = list(csv.reader(io.StringIO(data.decode("utf-8-sig")), delimiter=rules_for(cls, i)["delimiter"]))
            assert len(parsed) == 134
            assert [x["source_row"] for x in result["disposition"]] == list(range(1, 134))
            assert all(len(row) == 5 for row in parsed)
    print("12 developmental generator partition/encoding checks passed; no confirmation inputs emitted")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--seed")
    parser.add_argument("--output", type=Path, default=Path(__file__).parent)
    parser.add_argument("--production-freeze-sha256")
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        self_test()
    else:
        if not args.seed or not args.production_freeze_sha256 or len(args.production_freeze_sha256) != 64:
            parser.error("Generation requires postfreeze seed and exact production freeze SHA-256")
        generate(args.seed, args.output, args.production_freeze_sha256)
