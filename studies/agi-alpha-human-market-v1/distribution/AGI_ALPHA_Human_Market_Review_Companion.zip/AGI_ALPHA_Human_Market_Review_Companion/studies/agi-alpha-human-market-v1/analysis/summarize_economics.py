# SPDX-License-Identifier: Apache-2.0
import argparse,csv,gzip,hashlib,json,math,statistics,datetime
from pathlib import Path
from collections import defaultdict

ROOT=Path(__file__).resolve().parents[1]
HISTORY_REFERENCE='upfront historical R&D cost stress; paid from seed if affordable, never labeled earned financing'
SELECTED=('p9900-d1000-base-base',26001)

def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for chunk in iter(lambda:f.read(1048576),b''):h.update(chunk)
 return h.hexdigest()

def save(path,data):
 with path.open('x') as f:json.dump(data,f,indent=2,sort_keys=True);f.write('\n')

def stats(values):
 v=sorted(x for x in values if x is not None)
 if not v:return {'n':0,'mean':None,'sd':None,'minimum':None,'p10':None,'median':None,'p90':None,'maximum':None}
 def percentile(p):
  at=(len(v)-1)*p;i=int(at);return v[i]+(v[min(i+1,len(v)-1)]-v[i])*(at-i)
 return {'n':len(v),'mean':statistics.mean(v),'sd':statistics.stdev(v) if len(v)>1 else 0,
  'minimum':v[0],'p10':percentile(.1),'median':statistics.median(v),'p90':percentile(.9),'maximum':v[-1]}

def write_csv(path,rows):
 if not rows:return
 with path.open('x',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def group_metrics(worlds):
 out={'worlds':len(worlds),'full_cycles':sum(w['connectedCycle']['fullCycleWithinModel'] for w in worlds),
  'first_funded':sum(w['connectedCycle']['firstInvestmentFunded'] for w in worlds),
  'second_funded':sum(w['connectedCycle']['secondInvestmentFunded'] for w in worlds),
  'first_repaid':sum(w['connectedCycle']['firstRepaysInPairedModel'] for w in worlds),
  'second_repaid':sum(w['connectedCycle']['secondRepaysInPairedModel'] for w in worlds),
  'full_project_positive':sum(w['summaries'][2]['fullProjectProfitCents']>0 for w in worlds),
  'full_project_negative':sum(w['summaries'][2]['fullProjectProfitCents']<0 for w in worlds),
  'full_project_zero':sum(w['summaries'][2]['fullProjectProfitCents']==0 for w in worlds),
  'insolvent':sum(w['summaries'][2]['insolvent'] for w in worlds)}
 for key in ['firstRepaymentWeek','secondRepaymentWeek','firstCapabilityAcceptedUses','secondCapabilityAcceptedUses',
             'secondIncrementalProjectValueCents','secondIncrementalProtectedCashCents','finalOperatingGeneratedSurplusCents']:
  out[key]=stats([w['connectedCycle'][key] for w in worlds])
 for i in range(3):
  out[f'policy_{i}']={key:stats([w['summaries'][i][key] for w in worlds]) for key in
   ['accepted','rejected','grossCollectionsCents','accruedCostsCents','fullProjectProfitCents','finalCashCents',
    'operatingGeneratedAvailableCents','perAcceptedMarginalExecutionCents','perAcceptedDeliveryAndSupportCents',
    'perAcceptedRecurringCents','perAcceptedFullyAllocatedCents','fiscalReserveCents','investmentCount']}
 for i in range(2):
  out[f'policy_{i+1}_minus_0']={key:stats([w['comparisons'][i][key] for w in worlds]) for key in
   ['deltaProjectProfitCents','deltaProtectedCashCents','deltaAccepted']}
 return out

def assert_equal(a,b,label):
 if a!=b:raise AssertionError(f'{label}: {a} != {b}')

def fiscal(c,collections,costs):
 return math.floor(max(0,collections-sum(v for k,v in costs.items() if k!='capability'))*c['fiscalReserveBps']/10000+.5)

def audit_run(run):
 c=run['config'];h=run['histories'];s=run['summary'];bills=h['bills'];invoices=h['invoices'];events=h['cash']
 bmap={b['id']:b for b in bills};imap={i['id']:i for i in invoices}
 assert_equal(len(bmap),len(bills),'unique bills');assert_equal(len(imap),len(invoices),'unique invoices')
 cash=c['initialCashCents'];seen=set()
 for e in events:
  ident=(e['type'],e['reference']);assert ident not in seen,'duplicate cash event';seen.add(ident)
  if e['type']=='simulated_collection':assert_equal(e['amountCents'],imap[e['reference']]['amountCents'],'collection amount')
  elif e['type'] in ['expense_payment','refund']:assert_equal(e['amountCents'],-bmap[e['reference']]['amountCents'],'payment amount')
  else:raise AssertionError('unexpected cash event type')
  cash+=e['amountCents'];assert cash>=0,'negative cash';assert_equal(cash,e['cashAfterCents'],'cash replay')
 costs=defaultdict(int)
 for b in bills:costs[b['category']]+=b['amountCents']
 for k,v in s['costCategoriesCents'].items():assert_equal(costs[k],v,'category '+k)
 collections=sum(i['amountCents'] for i in invoices if i['status']=='collected')
 paid=sum(b['amountCents'] for b in bills if b['paid']);unpaid=sum(b['amountCents'] for b in bills if not b['paid'])
 receivables=sum(i['amountCents'] for i in invoices if i['status']=='pending')
 assert_equal(c['initialCashCents']+collections-paid,cash,'cash funding equation')
 assert_equal(cash,s['finalCashCents'],'terminal cash');assert_equal(collections,s['grossCollectionsCents'],'collections')
 assert_equal(unpaid,s['obligationsCents'],'obligations');assert_equal(receivables,s['receivablesCents'],'receivables')
 assert_equal(sum(costs.values()),s['accruedCostsCents'],'accrued costs');assert_equal(paid,s['paidCostsCents'],'paid costs')
 assert_equal(cash+receivables-unpaid-c['initialCashCents'],s['fullProjectProfitCents'],'project profit')
 reserve=fiscal(c,collections,costs);assert_equal(reserve,s['fiscalReserveCents'],'fiscal reserve')
 seed_history=sum(b['amountCents'] for b in bills if b['reference']==HISTORY_REFERENCE and b['paid'] and b['paidWeek']==0)
 available=max(0,min(cash-unpaid-c['reserveCents']-reserve,collections-sum(costs.values())+seed_history-reserve))
 assert_equal(available,s['operatingGeneratedAvailableCents'],'operating generated available')
 assert_equal(run['actualCustomerCollectionsCents'],0,'actual revenue');assert_equal(run['canonical']['cash']['summary']['observed']['revenue'],0,'canonical actual revenue')
 accepted=[j for j in h['jobs'] if j['accepted']]
 assert_equal(len(accepted),s['accepted'],'accepted count');assert_equal(len(h['jobs'])-len(accepted),s['rejected'],'rejected count')
 assert all(j['accepted'] or not j['invoiceCreated'] for j in h['jobs']),'rejected invoice'
 for i in invoices:
  if i['status']=='collected' and i['refund']:
   bs=[b for b in bills if b['category']=='refund' and b['reference']==i['id']];assert_equal(len(bs),1,'refund bill count')
   assert_equal(bs[0]['amountCents'],i['amountCents'],'refund amount');assert_equal(bs[0]['week'],i['collectedWeek'],'refund accrual timing')
 invest_audit=[];used_bills=set()
 for invest in h['investments']:
  matches=[(k,b) for k,b in enumerate(bills) if b['id'] not in used_bills and b['category']=='capability' and
   b['reference']==invest['sourceSHA256'] and b['week']==invest['week'] and b['amountCents']==invest['fullCostCents']]
  assert_equal(len(matches),1,'investment bill identity');bi,bill=matches[0];used_bills.add(bill['id'])
  ei=next(k for k,e in enumerate(events) if e['reference']==bill['id'] and e['type']=='expense_payment')
  prior_events=events[:ei];prior_bills=bills[:bi]
  before_cash=c['initialCashCents']+sum(e['amountCents'] for e in prior_events)
  before_col=sum(e['amountCents'] for e in prior_events if e['type']=='simulated_collection')
  before_paid=-sum(e['amountCents'] for e in prior_events if e['type'] in ['expense_payment','refund'])
  before_costs=defaultdict(int)
  for b in prior_bills:before_costs[b['category']]+=b['amountCents']
  before_accrued=sum(before_costs.values());before_unpaid=before_accrued-before_paid
  paid_ids={e['reference'] for e in prior_events if e['type']=='expense_payment'}
  before_history=sum(b['amountCents'] for b in prior_bills if b['reference']==HISTORY_REFERENCE and b['id'] in paid_ids and b['paidWeek']==0)
  before_reserve=fiscal(c,before_col,before_costs)
  before_liquid=before_cash-before_unpaid-c['reserveCents']-before_reserve
  before_generated=max(0,min(before_liquid,before_col-before_accrued+before_history-before_reserve))
  assert_equal(before_liquid,invest['liquidAfterObligationsAndReserveCents'],'investment liquidity')
  assert_equal(before_generated,invest['operatingGeneratedCents'],'investment generated funding')
  assert before_generated>=invest['fullCostCents'],'investment cannot be financed by generated funds'
  invest_audit.append({'week':invest['week'],'id':invest['capabilityId'],'costCents':invest['fullCostCents'],
   'cashBeforeCents':before_cash,'obligationsBeforeCents':before_unpaid,'fixedReserveCents':c['reserveCents'],
   'fiscalReserveBeforeCents':before_reserve,'generatedBeforeCents':before_generated})
 breakdown=defaultdict(int)
 for b in bills:
  r=b['reference'];cat=b['category']
  if r==HISTORY_REFERENCE:key='historical_research'
  elif r.startswith('Shared service setup'):key='shared_setup'
  elif r.startswith('Recurring service business'):key='fixed_operating'
  elif r.startswith('opportunity-acquisition:'):key='prospect_acquisition'
  elif r.startswith('opportunity-screen:'):key='screening'
  elif r.startswith('provider-onboarding:'):key='provider_onboarding'
  elif r.startswith('collection-fee:'):key='collection_fees'
  elif cat=='delivery':key='delivery_execution_and_review'
  elif cat=='business':key='support_correction_revision'
  elif cat=='maintenance':key='maintenance'
  elif cat=='refund':key='refunds'
  elif cat=='capability':key='capability_investment'
  else:raise AssertionError('Unclassified cost '+str(b))
  breakdown[key]+=b['amountCents']
 marginal=sum(j['marginalExecutionCostCents'] for j in h['jobs'])
 breakdown['marginal_execution_with_infrastructure']=marginal
 breakdown['delivery_review']=breakdown.pop('delivery_execution_and_review',0)-marginal
 assert_equal(sum(breakdown.values()),s['accruedCostsCents'],'complete cost classification')
 return {'investments':invest_audit,'costBreakdownCents':dict(breakdown)}

def break_even(c):
 rows=[]
 for k,cap in enumerate(c['capabilities']):
  before=c['profiles'][k];after=c['profiles'][k+1]
  full=sum(cap[x] for x in ['constructionCents','validationCents','failedDiscoveryCents','integrationCents'])
  lifetime_cost=full+cap['weeklyMaintenanceCents']*cap['lifetimeWeeks']
  for item in c['classes']:
   a=before['classes'][item['id']];b=after['classes'][item['id']]
   if a['supported'] or not b['supported']:continue
   q=b['acceptanceProbability']*c['fieldReliabilityMultiplier'];price=math.floor(item['humanReferenceCents']*(1-c['discountBps']/10000)+.5)
   contribution=price*c['paymentProbability']*(1-c['refundProbability']-c['paymentFeeBps']/10000)-(b['deliveryCostCents']+b['businessCostCents'])/q if q else None
   after_reserve=contribution*(1-c['fiscalReserveBps']/10000) if contribution is not None else None
   new_buyer=after_reserve-c['providerOnboardingCents']*(1-c['fiscalReserveBps']/10000) if after_reserve is not None else None
   need=lambda margin:math.ceil(lifetime_cost/margin) if margin is not None and margin>0 else None
   rows.append({'scenario':c['id'],'capability':cap['id'],'new_supported_class':item['id'],'priceCents':price,
    'constructionCompleteCents':full,'declaredLifetimeWeeks':cap['lifetimeWeeks'],'fullDeclaredLifetimeMaintenanceCents':cap['weeklyMaintenanceCents']*cap['lifetimeWeeks'],
    'incrementalContributionPerNewAcceptedCents':contribution,'afterFiscalReserveContributionCents':after_reserve,
    'breakEvenAcceptedReusesExistingBuyer':need(after_reserve),'breakEvenAcceptedReusesNewBuyerEveryUse':need(new_buyer),
    'requiredWeeklyReuseExistingBuyer':need(after_reserve)/cap['lifetimeWeeks'] if need(after_reserve) is not None else None,
    'scope':'Analytic condition using declared costs, collections/refund/fee risks and whole declared maintenance life. Acquisition/screening/fixed overhead are common to paired policies; this is not full service unit cost. Buyer choice and liquidity can still prevent all sales. No new simulation or parameter tuning.'})
 return rows

def run(campaign_dir,protocol_path,out_dir):
 out_dir.mkdir(parents=True,exist_ok=False)
 completion=json.loads((campaign_dir/'completion.json').read_text());assert completion['complete'],'Campaign incomplete'
 for a in completion['artifacts']:assert_equal(sha(campaign_dir/a['path']),a['sha256'],'campaign artifact '+a['path'])
 protocol=json.loads(protocol_path.read_text());config={c['id']:c for c in protocol['scenarios']}
 summary=json.loads((campaign_dir/'summary.json').read_text());worlds=[];cells=[];flat=[];by=defaultdict(lambda:defaultdict(list))
 for group in summary['groups']:
  ident=group['scenarioId'];c=config[ident];cost=ident.split('-')[2];condition='-'.join(ident.split('-')[3:]);price=c['classes'][0]['humanReferenceCents'];discount=c['discountBps']
  metrics=group_metrics(group['seeds']);cells.append({'scenario':ident,'priceCents':price,'discountBps':discount,'costSchedule':cost,'condition':condition,'metrics':metrics})
  for w in group['seeds']:
   worlds.append(w)
   for key,value in [('price',str(price)),('discount',str(discount)),('cost',cost),('condition',condition)]:by[key][value].append(w)
  for arm in range(3):
   p=metrics[f'policy_{arm}'];delta=metrics[f'policy_{arm}_minus_0'] if arm else None
   flat.append({'scenario':ident,'human_reference_usd':price/100,'discount_percent':discount/100,'cost_schedule':cost,'condition':condition,'maximum_investments':arm,
    'worlds':metrics['worlds'],'cycles':metrics['full_cycles'],'first_funded':metrics['first_funded'],'second_funded':metrics['second_funded'],
    'accepted_mean':p['accepted']['mean'],'project_profit_mean_usd':p['fullProjectProfitCents']['mean']/100,
    'project_profit_min_usd':p['fullProjectProfitCents']['minimum']/100,'project_profit_max_usd':p['fullProjectProfitCents']['maximum']/100,
    'project_profit_sd_usd':p['fullProjectProfitCents']['sd']/100,'project_profit_p10_usd':p['fullProjectProfitCents']['p10']/100,'project_profit_p90_usd':p['fullProjectProfitCents']['p90']/100,
    'generated_available_mean_usd':p['operatingGeneratedAvailableCents']['mean']/100,
    'full_cost_per_accepted_mean_usd':p['perAcceptedFullyAllocatedCents']['mean']/100 if p['perAcceptedFullyAllocatedCents']['mean'] is not None else None,
    'delta_profit_mean_usd':delta['deltaProjectProfitCents']['mean']/100 if delta else 0,
    'delta_protected_cash_mean_usd':delta['deltaProtectedCashCents']['mean']/100 if delta else 0})
 aggregate={'schema':'human-market-implementer-aggregation/v1','edition':protocol['edition'],'basis':'SIMULATED',
  'warning':'Designed scenario counts are not probabilities of real commercial success. This is implementer analysis, not independent audit.',
  'campaignProtocolSHA256':sha(protocol_path),'completionSHA256':sha(campaign_dir/'completion.json'),'overall':group_metrics(worlds),
  'groups':{key:{value:group_metrics(rows) for value,rows in groups.items()} for key,groups in by.items()},'cells':cells}
 save(out_dir/'aggregation.json',aggregate);write_csv(out_dir/'cell-summary.csv',flat)
 break_rows=[r for c in protocol['scenarios'] for r in break_even(c)];save(out_dir/'analytic-break-even.json',break_rows)
 write_csv(out_dir/'analytic-break-even.csv',[{k:v for k,v in r.items() if k!='scope'} for r in break_rows])
 errors=[];costrows=[];investrows=[];audited=0;selected=None;cost_aggregate=defaultdict(int)
 with gzip.open(campaign_dir/'histories.jsonl.gz','rt') as f:
  for line in f:
   world=json.loads(line);ident=world['configId'];seed=world['seed'];is_selected=(ident,seed)==SELECTED
   audits=[]
   for arm,enterprise in enumerate(world['runs']):
    try:
     audit=audit_run(enterprise);audits.append(audit);audited+=1
     for category,value in audit['costBreakdownCents'].items():
      costrows.append({'scenario':ident,'seed':seed,'maximum_investments':arm,'category':category,'amount_cents':value})
      cost_aggregate[(arm,category)]+=value
     for inv in audit['investments']:
      investrows.append({'scenario':ident,'seed':seed,'maximum_investments':arm,**inv})
    except Exception as e:errors.append({'scenario':ident,'seed':seed,'policy':arm,'error':str(e)})
   if is_selected:
    selected={'world':world,'implementerReconciliation':audits,'selection':'Declared before output inspection: seed26001, p9900-d1000-base-base. Upper detailed matched human-price reference, middle cost,10% discount; not representative.'}
 assert_equal(audited+len(errors),completion['completedHistories'],'all histories considered')
 save(out_dir/'implementer-reconciliation.json',{'schema':'human-market-implementer-reconciliation/v1','status':'PASS' if not errors else 'FAIL',
  'scope':'Independent arithmetic equations and event-level reconciliation written by economic implementation owner; not an independent reviewer assessment.',
  'auditedHistories':audited,'errors':errors,'sourceHistoriesSHA256':sha(campaign_dir/'histories.jsonl.gz'),
  'checks':['Cash/event/invoice/bill identities','Complete cost-category totals','Observed collections remain zero',
   'Immediate refund accrual','Seed-paid history separated','Reserve and generated funding independently recomputed at each actual modeled investment']})
 write_csv(out_dir/'cost-category-ledger.csv',costrows);write_csv(out_dir/'investment-finance-ledger.csv',investrows)
 write_csv(out_dir/'cost-category-totals.csv',[{'maximum_investments':arm,'category':category,'total_cents':value} for (arm,category),value in sorted(cost_aggregate.items())])
 if selected:
  save(out_dir/'preselected-world.json',selected)
  timeline=[]
  for arm,r in enumerate(selected['world']['runs']):
   for b in r['histories']['balances']:timeline.append({'maximum_investments':arm,**b})
  write_csv(out_dir/'preselected-cash-timeline.csv',timeline)
  detailed=[]
  for arm,r in enumerate(selected['world']['runs']):
   for inv in r['histories']['investments']:detailed.append({'maximum_investments':arm,**inv})
  save(out_dir/'preselected-investments.json',detailed)
 save(out_dir/'analysis-completion.json',{'schema':'human-market-postoutcome-analysis/v1','createdUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),
  'authorRole':'Economic implementer analysis','campaignsRerun':False,'frozenSourcesModified':False,'scenarios':len(cells),'worlds':len(worlds),
  'cycles':aggregate['overall']['full_cycles'],'auditedHistories':audited,'reconciliationErrors':errors,
  'selectedCasePresent':selected is not None,'scriptSHA256':sha(Path(__file__))})
 print(json.dumps({'edition':protocol['edition'],'scenarios':len(cells),'worlds':len(worlds),'cycles':aggregate['overall']['full_cycles'],
  'auditedHistories':audited,'reconciliationErrors':len(errors),'output':str(out_dir)}))

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('campaign');parser.add_argument('protocol');parser.add_argument('output');args=parser.parse_args()
 run(Path(args.campaign).resolve(),Path(args.protocol).resolve(),Path(args.output).resolve())
