# SPDX-License-Identifier: Apache-2.0
"""Postoutcome implementer interpretation. Reads, but never reruns, frozen worlds."""
import csv
import datetime
import hashlib
import json
import math
from collections import defaultdict
from pathlib import Path

from summarize_economics import stats, write_csv

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'analysis' / 'interpretation'


def read(path):
    return json.loads(path.read_text())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(name, value):
    with (OUT / name).open('x') as f:
        json.dump(value, f, indent=2, sort_keys=True)
        f.write('\n')


def protected(summary):
    return summary['finalCashCents'] - summary['obligationsCents'] - summary['totalProtectedReservesCents']


def main():
    OUT.mkdir(exist_ok=False)
    identities = []
    editions = []
    all_stages = []
    all_worlds = []
    changed_analytic_rows = []
    corrected_break_even = []
    for edition, suffix in [('primary', 'primary'), ('diagnostic', 'boundary')]:
        analysis = ROOT / 'analysis' / f'{suffix}-final'
        campaign = ROOT / 'results' / f'economics-{suffix}-01'
        protocol_path = ROOT / 'protocol' / 'economics-primary' / f'campaign-{suffix}.json'
        protocol = read(protocol_path)
        configs = {c['id']: c for c in protocol['scenarios']}
        aggregate = read(analysis / 'aggregation.json')
        completion = read(campaign / 'completion.json')
        assert completion['complete']
        assert read(analysis / 'implementer-reconciliation.json')['status'] == 'PASS'
        for path in [protocol_path, campaign / 'completion.json', campaign / 'summary.json',
                     analysis / 'aggregation.json', analysis / 'implementer-reconciliation.json',
                     analysis / 'investment-finance-ledger.csv']:
            identities.append({'path': str(path.relative_to(ROOT)), 'sha256': digest(path)})
        investment_map = {}
        with (analysis / 'investment-finance-ledger.csv').open() as f:
            for row in csv.DictReader(f):
                key = (row['scenario'], int(row['seed']), int(row['maximum_investments']), row['id'])
                investment_map[key] = {k: int(v) if k not in ('scenario', 'id') else v for k, v in row.items()}
        world_rows, stage_rows = [], []
        for group in read(campaign / 'summary.json')['groups']:
            ident = group['scenarioId']
            config = configs[ident]
            cost = ident.split('-')[2]
            condition = '-'.join(ident.split('-')[3:])
            for world in group['seeds']:
                cycle = world['connectedCycle']
                summaries = world['summaries']
                row = {'edition': edition, 'scenario': ident, 'seed': world['seed'],
                       'human_reference_cents': config['classes'][0]['humanReferenceCents'],
                       'discount_bps': config['discountBps'], 'cost_schedule': cost, 'condition': condition,
                       'accepted': summaries[2]['accepted'], 'zero_accepted': summaries[2]['accepted'] == 0,
                       'complete_project_cost_cents': summaries[2]['accruedCostsCents'],
                       'project_profit_cents': summaries[2]['fullProjectProfitCents'],
                       'all_history_recovered': cycle['historicalAndFullProjectCostRecovered'],
                       'cycle': cycle['fullCycleWithinModel'], 'first_funded': cycle['firstInvestmentFunded'],
                       'second_funded': cycle['secondInvestmentFunded'],
                       'first_terminal_repaid': cycle['firstRepaysInPairedModel'],
                       'second_terminal_repaid': cycle['secondRepaysInPairedModel'],
                       'first_useful_accepted_uses': cycle['firstCapabilityAcceptedUses'],
                       'second_useful_accepted_uses': cycle['secondCapabilityAcceptedUses'],
                       'first_project_gain_cents': world['comparisons'][0]['deltaProjectProfitCents'],
                       'first_protected_gain_cents': world['comparisons'][0]['deltaProtectedCashCents'],
                       'second_project_gain_cents': cycle['secondIncrementalProjectValueCents'],
                       'second_protected_gain_cents': cycle['secondIncrementalProtectedCashCents'],
                       'protected_cash_policy_0_cents': protected(summaries[0]),
                       'protected_cash_policy_1_cents': protected(summaries[1]),
                       'protected_cash_policy_2_cents': protected(summaries[2]),
                       'generated_available_cents': summaries[2]['operatingGeneratedAvailableCents'],
                       'insolvent': summaries[2]['insolvent']}
                if row['cycle']:
                    assert row['protected_cash_policy_1_cents'] > 0
                    assert row['protected_cash_policy_2_cents'] > 0
                    assert row['first_terminal_repaid'] and row['second_terminal_repaid']
                world_rows.append(row)
                for stage, word, arm in [(1, 'first', 1), (2, 'second', 2)]:
                    if not cycle[f'{word}InvestmentFunded']:
                        continue
                    cap = config['capabilities'][stage - 1]
                    investment = investment_map[(ident, world['seed'], arm, cap['id'])]
                    available = investment['week'] + cap['constructionWeeks']
                    expiry = available + cap['lifetimeWeeks']
                    if stage == 2:
                        previous = investment_map[(ident, world['seed'], 2, config['capabilities'][0]['id'])]
                        previous_cap = config['capabilities'][0]
                        expiry = min(expiry, previous['week'] + previous_cap['constructionWeeks'] + previous_cap['lifetimeWeeks'])
                    active = max(0, min(config['weeks'], expiry) - available)
                    payback = cycle[f'{word}RepaymentWeek']
                    accrued_payback = cycle[f'{word}AccruedValueRepaymentWeek']
                    stage_rows.append({'edition': edition, 'scenario': ident, 'seed': world['seed'],
                        'stage': stage, 'cost_schedule': cost, 'condition': condition,
                        'human_reference_cents': row['human_reference_cents'], 'discount_bps': row['discount_bps'],
                        'investment_week': investment['week'], 'available_week': available,
                        'declared_lifetime_weeks': cap['lifetimeWeeks'],
                        'effective_active_weeks_in_service_horizon': active,
                        'complete_investment_cost_cents': investment['costCents'],
                        'generated_funds_before_cents': investment['generatedBeforeCents'],
                        'generated_funds_after_investment_cents': investment['generatedBeforeCents'] - investment['costCents'],
                        'useful_accepted_uses': cycle[f'{word}CapabilityAcceptedUses'],
                        'useful_reuses_per_active_week': cycle[f'{word}CapabilityAcceptedUses'] / active if active else None,
                        'protected_cash_first_crossing_week': payback,
                        'protected_cash_first_crossing_elapsed_weeks': payback - investment['week'] if payback is not None else None,
                        'accrued_value_first_crossing_week': accrued_payback,
                        'accrued_value_first_crossing_elapsed_weeks': accrued_payback - investment['week'] if accrued_payback is not None else None,
                        'terminal_project_gain_cents': row[f'{word}_project_gain_cents'],
                        'terminal_protected_gain_cents': row[f'{word}_protected_gain_cents'],
                        'terminal_repaid': row[f'{word}_terminal_repaid'], 'connected_cycle': row['cycle']})
        stage_aggregates = {}
        for stage in [1, 2]:
            rows = [r for r in stage_rows if r['stage'] == stage]
            stage_aggregates[str(stage)] = {'funded': len(rows),
                'terminal_repaid': sum(r['terminal_repaid'] for r in rows),
                'no_useful_accepted_reuse': sum(r['useful_accepted_uses'] == 0 for r in rows),
                'accrued_gain_positive_protected_gain_nonpositive': sum(r['terminal_project_gain_cents'] > 0 and r['terminal_protected_gain_cents'] <= 0 for r in rows),
                'first_crossed_but_terminal_not_repaid': sum(r['protected_cash_first_crossing_week'] is not None and not r['terminal_repaid'] for r in rows)}
            for key in ['investment_week', 'complete_investment_cost_cents', 'generated_funds_before_cents',
                        'effective_active_weeks_in_service_horizon', 'useful_accepted_uses', 'useful_reuses_per_active_week',
                        'protected_cash_first_crossing_elapsed_weeks', 'accrued_value_first_crossing_elapsed_weeks',
                        'terminal_project_gain_cents', 'terminal_protected_gain_cents']:
                stage_aggregates[str(stage)][key] = stats([r[key] for r in rows])
        negatives = [r for r in world_rows if r['second_funded'] and not r['cycle']]
        save(f'{edition}-funded-second-stage-failures.json', negatives)
        write_csv(OUT / f'{edition}-world-outcomes.csv', world_rows)
        write_csv(OUT / f'{edition}-stage-outcomes.csv', stage_rows)
        save(f'{edition}-stage-summary.json', stage_aggregates)
        editions.append({'edition': edition, 'worlds': len(world_rows), 'cycles': sum(r['cycle'] for r in world_rows),
                         'zeroAccepted': sum(r['zero_accepted'] for r in world_rows),
                         'profitableButNoConnectedCycle': sum(r['project_profit_cents'] > 0 and not r['cycle'] for r in world_rows),
                         'connectedCycleButHistoricalResearchNotRecovered': [r for r in world_rows if r['cycle'] and not r['all_history_recovered']],
                         'allQualifyingCyclesRetainPositiveProtectedCashInBothStages': True,
                         'stageSummary': stage_aggregates})
        all_stages.extend(stage_rows)
        all_worlds.extend(world_rows)

        # Correct only the postoutcome analytic calculation. The frozen simulation
        # already charges onboarding on a new buyer's first attempt, including failure.
        for old in read(analysis / 'analytic-break-even.json'):
            row = dict(old)
            c = configs[row['scenario']]
            k = next(i for i, x in enumerate(c['capabilities']) if x['id'] == row['capability'])
            profile = c['profiles'][k + 1]['classes'][row['new_supported_class']]
            acceptance = profile['acceptanceProbability'] * c['fieldReliabilityMultiplier']
            onboarding_per_accepted = c['providerOnboardingCents'] / acceptance if acceptance else None
            margin = row['afterFiscalReserveContributionCents']
            fresh_buyer_margin = margin - onboarding_per_accepted * (1 - c['fiscalReserveBps'] / 10000) if margin is not None else None
            lifetime_budget = row['constructionCompleteCents'] + row['fullDeclaredLifetimeMaintenanceCents']
            corrected = math.ceil(lifetime_budget / fresh_buyer_margin) if fresh_buyer_margin is not None and fresh_buyer_margin > 0 else None
            if corrected != row['breakEvenAcceptedReusesNewBuyerEveryUse']:
                changed_analytic_rows.append({'edition': edition, 'scenario': row['scenario'], 'capability': row['capability'],
                                             'old': row['breakEvenAcceptedReusesNewBuyerEveryUse'], 'corrected': corrected})
            row.update({'edition': edition, 'acceptance_probability_scenario': acceptance,
                        'providerOnboardingPerAcceptedNewBuyerEveryAttemptCents': onboarding_per_accepted,
                        'afterFiscalContributionNewBuyerEveryAttemptCents': fresh_buyer_margin,
                        'breakEvenAcceptedReusesNewBuyerEveryUse': corrected,
                        'analyticVersion': 2,
                        'scope': 'Postoutcome algebra over frozen parameters only; no simulated worlds rerun. New-buyer stress means every attempt belongs to a new buyer, so failed attempts also incur onboarding. The numerator conservatively budgets complete construction plus maintenance for the entire declared lifetime without taking a maintenance reserve credit. Existing-buyer and fresh-buyer formulas omit only costs common to paired policies. Neither is a full-service cost or proof of buyer acceptance. The actual horizon and predecessor expiry can shorten useful life.'})
            corrected_break_even.append(row)
    save('analytic-break-even-v2.json', corrected_break_even)
    write_csv(OUT / 'analytic-break-even-v2.csv', [{k: v for k, v in r.items() if k != 'scope'} for r in corrected_break_even])
    save('analytic-correction.json', {'schema': 'human-market-postoutcome-analytic-correction/v1',
        'reason': 'The earlier every-new-buyer analytic bound subtracted one onboarding cost per accepted delivery. With declared field acceptance below one, every-attempt-new-buyer stress requires onboarding cost divided by acceptance probability. Frozen cash simulation already charges the correct first-attempt onboarding. All earlier analysis artifacts are preserved.',
        'campaignsRerun': False, 'economicOutcomeChanges': 0,
        'changedIntegerBreakEvenRows': changed_analytic_rows,
        'sourceScriptSHA256': digest(Path(__file__))})
    save('financial-findings.json', {'basis': 'SIMULATED', 'authorRole': 'Economic implementer analysis',
        'countsAreNotMarketProbabilities': True, 'editions': editions,
        'createdUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'sources': identities, 'sourceScriptSHA256': digest(Path(__file__)),
        'frozenFilesModified': False, 'campaignsRerun': False})
    print(json.dumps({'output': str(OUT), 'editions': [{k: e[k] for k in ['edition', 'worlds', 'cycles', 'zeroAccepted']} for e in editions],
                      'stageRecords': len(all_stages), 'correctedAnalyticRows': len(changed_analytic_rows)}))


if __name__ == '__main__':
    main()
