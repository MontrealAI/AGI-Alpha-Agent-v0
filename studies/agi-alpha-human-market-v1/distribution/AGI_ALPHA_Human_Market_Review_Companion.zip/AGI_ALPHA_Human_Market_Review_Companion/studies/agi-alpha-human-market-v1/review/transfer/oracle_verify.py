import argparse
import hashlib
import importlib.util
import json
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BASE_VERIFIER = ROOT / "acceptance" / "verify_results.py"
BASE_VERIFIER_SHA = "519085f444941855cb74516a73ab4009332c6e801854abe23eaf1fba835b2b3a"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def resolve(base, value):
    path = Path(value)
    return path if path.is_absolute() else base / path


def main(index, sealed_sha, base, oracle_root, output):
    if sha(index) != sealed_sha or sha(BASE_VERIFIER) != BASE_VERIFIER_SHA:
        raise SystemExit("Prediction index or frozen verifier identity changed")
    spec = importlib.util.spec_from_file_location("frozen_acceptance", BASE_VERIFIER)
    verifier = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(verifier)
    manifest = load(oracle_root / "inputs_manifest.json")
    receipt = load(oracle_root / "private_keys" / "generation_receipt.json")
    seals = load(oracle_root / "key_seals.json")
    records = load(index)["records"]
    problems = []
    class_counts = Counter(x["case_class"] for x in manifest["records"])
    if len(manifest["records"]) != 6 or class_counts != {"simple": 2, "locale": 2, "versioned": 2}:
        problems.append({"kind": "input_case_count", "class_counts": dict(class_counts)})
    if len(seals["keys"]) != 6 or len(records) != 12:
        problems.append({"kind": "key_or_prediction_count", "keys": len(seals["keys"]), "predictions": len(records)})
    if sha(ROOT / "protocol" / "DELIVERY_CONTRACT.md") != receipt["contract_sha256"]:
        problems.append({"kind": "contract_changed"})
    for entry in seals["keys"]:
        if sha(oracle_root / "private_keys" / (entry["job_id"] + ".json")) != entry["sha256"]:
            problems.append({"kind": "answer_key_changed", "job_id": entry["job_id"]})
    for entry in manifest["records"]:
        if sha(oracle_root / entry["job_file"]) != entry["job_sha256"] or sha(oracle_root / entry["source_file"]) != entry["source_sha256"]:
            problems.append({"kind": "input_changed", "job_id": entry["job_id"]})
    expected_pairs = {(x["job_id"], method) for x in manifest["records"] for method in ("recipient", "donor_g2")}
    counts = Counter((r.get("job_id"), r.get("method")) for r in records)
    if set(counts) != expected_pairs or any(c != 1 for c in counts.values()):
        problems.append({"kind": "campaign_coverage", "missing": sorted(expected_pairs - set(counts)), "extra": sorted(set(counts) - expected_pairs),
                         "duplicate_pairs": [list(k) for k, v in counts.items() if v != 1]})
    outcomes = []
    for record in records:
        if (record.get("job_id"), record.get("method")) not in expected_pairs:
            continue
        key = load(oracle_root / "private_keys" / (record["job_id"] + ".json"))
        errors = []
        try:
            if record["status"] != "COMPLETED":
                errors.append({"kind": "status", "actual": record["status"]})
            path = resolve(base, record["semantic_path"])
            if not path.is_file() or sha(path) != record["semantic_sha256"]:
                errors.append({"kind": "semantic_identity"})
            else:
                errors.extend(verifier.compare_semantic(key["semantic"], load(path)))
            if record.get("source_sha256") != key["actual_source_sha256"]:
                errors.append({"kind": "source_identity"})
            if record["method"] == "donor_g2" and record["status"] == "COMPLETED":
                errors.extend(verifier.verify_package(resolve(base, record["output_dir"]), key["semantic"], key["actual_source_sha256"]))
        except Exception as exc:
            errors.append({"kind": "verification_exception", "type": type(exc).__name__, "message": str(exc)})
        outcomes.append({"job_id": record["job_id"], "method": record["method"], "case_class": key["case_class"],
                         "semantic_and_required_package_accepted": not errors, "problems": errors})
    accepted = {method: sum(x["semantic_and_required_package_accepted"] for x in outcomes if x["method"] == method)
                for method in ("recipient", "donor_g2")}
    verdict = {"schema": "fresh-transfer-acceptance/v1", "sealed_predictions_sha256": sealed_sha,
               "transfer_freeze_sha256": receipt["transfer_freeze_sha256"], "contract_sha256": receipt["contract_sha256"],
               "all_checks_passed": not problems and all(x["semantic_and_required_package_accepted"] for x in outcomes),
               "accepted_by_method": accepted, "structural_problems": problems, "outcomes": outcomes,
               "scope": "Recipient semantic correctness and donor semantic plus package correctness. Same-session independent oracle; no external customer acceptance.",
               "claim_limit": "Recipient reconstruction preceded donor access. A donor invocation does not establish scarce-skill acquisition or an unsupported recipient."}
    output.write_text(json.dumps(verdict, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"all_checks_passed": verdict["all_checks_passed"], "accepted_by_method": accepted, "structural_problems": problems}))
    return 0 if verdict["all_checks_passed"] else 1


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--index", type=Path, required=True)
    parser.add_argument("--sealed-sha256", required=True)
    parser.add_argument("--base", type=Path, default=ROOT)
    parser.add_argument("--oracle-root", type=Path, default=Path(__file__).parent)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    raise SystemExit(main(args.index, args.sealed_sha256, args.base, args.oracle_root, args.out))
