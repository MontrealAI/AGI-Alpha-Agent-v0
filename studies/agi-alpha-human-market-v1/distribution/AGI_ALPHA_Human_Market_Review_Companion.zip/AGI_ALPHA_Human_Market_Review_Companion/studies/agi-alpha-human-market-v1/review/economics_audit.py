import argparse
import csv
import gzip
import hashlib
import json
import math
import re
import time
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
HISTORICAL = "upfront historical R&D cost stress; paid from seed if affordable, never labeled earned financing"
SETUP = "Shared service setup and discovery: charged once"
CATEGORIES = ("delivery", "business", "capability", "maintenance", "refund")


def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1048576), b""):
            h.update(block)
    return h.hexdigest()


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def rounded(value):
    return math.floor(value + 0.5)


def profile_index(week, investments):
    count = 0
    for investment in investments:
        if investment["availableWeek"] > week or investment["expiresWeek"] <= week:
            break
        count += 1
    return count


def cap_cost(cap):
    return sum(cap[k] for k in ("constructionCents", "validationCents", "failedDiscoveryCents", "integrationCents"))


def recurring(profile):
    return profile["deliveryCostCents"] + profile["businessCostCents"]


def choose(offers, value, error):
    kept = []
    for offer in offers:
        dominated = False
        for other in offers:
            if other["id"] == offer["id"]:
                continue
            q = other["quality"] >= offer["quality"]
            costs = [other[k] <= offer[k] for k in ("priceCents", "effortCents", "delayCents", "switchCents")]
            strict = other["quality"] > offer["quality"] or any(other[k] < offer[k] for k in ("priceCents", "effortCents", "delayCents", "switchCents"))
            if q and all(costs) and strict:
                dominated = True
                break
        if not dominated:
            utility = offer["quality"] * value - offer["priceCents"] - offer["effortCents"] - offer["delayCents"] - offer["switchCents"] - (1 - offer["quality"]) * error
            kept.append((utility, offer["id"]))
    positive = [x for x in kept if x[0] > 0]
    return sorted(positive, key=lambda x: (-x[0], x[1]))[0] if positive else (0, "defer")


class Audit:
    def __init__(self):
        self.checks = Counter()
        self.failures = Counter()
        self.examples = []
        self.context = {}
        self.totals = Counter()
        self.campaigns = []

    def check(self, kind, actual, expected=True, detail=None):
        self.checks[kind] += 1
        equal = actual == expected
        if isinstance(actual, float) or isinstance(expected, float):
            equal = actual is not None and expected is not None and math.isclose(actual, expected, rel_tol=1e-12, abs_tol=1e-7)
        if not equal:
            self.failures[kind] += 1
            if len(self.examples) < 100:
                item = {**self.context, "check": kind, "actual": actual, "expected": expected, "detail": detail}
                self.examples.append(item)
                if len(self.examples) <= 8:
                    print("AUDIT_DISCREPANCY " + json.dumps(item, default=str)[:2500], flush=True)
        return equal

    def fields(self, kind, actual, expected):
        for key, value in expected.items():
            self.check(kind + "." + key, actual.get(key), value)

    def identities(self):
        freeze_path = ROOT / "protocol/economics-source-freeze.json"
        freeze = load(freeze_path)
        self.context = {"phase": "frozen-identities"}
        for entry in freeze["files"]:
            path = ROOT / entry["path"]
            self.check("frozen_source_sha256", sha(path), entry["sha256"], entry["path"])
            self.check("frozen_source_bytes", path.stat().st_size, entry["bytes"], entry["path"])
        registration = load(ROOT / "protocol/economics-primary/registration-ready.json")
        for entry in registration["artifacts"]:
            self.check("registered_artifact_sha256", sha(ROOT / entry["path"]), entry["sha256"], entry["path"])
        return sha(freeze_path), len(freeze["files"])

    def run_history(self, run):
        c, h, reported = run["config"], run["histories"], run["summary"]
        jobs, bills, invoices, events = h["jobs"], h["bills"], h["invoices"], h["cash"]
        choices, investments, balances = h["choices"], h["investments"], h["balances"]
        self.totals["histories"] += 1
        for name, items in (("jobs", jobs), ("bills", bills), ("invoices", invoices), ("cash_events", events), ("balances", balances), ("decisions", h["decisions"]), ("investments", investments)):
            self.totals[name] += len(items)
        self.check("simulation_basis", run["basis"], "SIMULATED")
        self.check("zero_actual_collections", run["actualCustomerCollectionsCents"], 0)
        self.check("assumed_money", c["allMoneyIsAssumed"])
        self.check("assumed_demand", c["demandIsAssumed"])
        self.check("deterministic_buyer_panel", c["choiceModel"], "deterministic")
        bmap = {x["id"]: x for x in bills}
        imap = {x["id"]: x for x in invoices}
        jmap = {x["id"]: x for x in jobs}
        self.check("unique_bill_ids", len(bmap), len(bills))
        self.check("unique_invoice_ids", len(imap), len(invoices))
        self.check("unique_job_ids", len(jmap), len(jobs))
        costs = {k: 0 for k in CATEGORIES}
        paid = {k: 0 for k in CATEGORIES}
        cash = c["initialCashCents"]
        event_refs = Counter()
        collections = 0
        prior_week = -1
        paid_refs = set()
        cash_by_week, receipts_by_week, paid_by_week = defaultdict(int), defaultdict(int), defaultdict(int)
        for event in events:
            week = event["week"]
            self.check("cash_event_chronology", week >= prior_week)
            prior_week = week
            value = event["amountCents"]
            self.check("integer_cash_event", isinstance(value, int) and not isinstance(value, bool))
            cash += value
            self.check("cash_event_balance", event["cashAfterCents"], cash)
            self.check("finite_nonnegative_cash", cash >= 0)
            event_refs[(event["type"], event["reference"])] += 1
            cash_by_week[week] += value
            if event["type"] == "simulated_collection":
                inv = imap[event["reference"]]
                self.fields("collection_event", event, {"amountCents": inv["amountCents"], "week": inv["collectedWeek"]})
                self.check("collected_invoice_status", inv["status"], "collected")
                collections += value
                receipts_by_week[week] += value
            else:
                bill = bmap[event["reference"]]
                self.fields("payment_event", event, {"amountCents": -bill["amountCents"], "week": bill["paidWeek"], "type": "refund" if bill["category"] == "refund" else "expense_payment"})
                self.check("payment_for_paid_bill", bill["paid"])
                paid[bill["category"]] += -value
                paid_by_week[week] += -value
                paid_refs.add(bill["id"])
        accrued_by_week, noncap_by_week = defaultdict(int), defaultdict(int)
        for bill in bills:
            self.check("positive_integer_bill", isinstance(bill["amountCents"], int) and bill["amountCents"] > 0)
            self.check("bill_due_after_accrual", bill["dueWeek"] >= bill["week"])
            self.check("known_cost_category", bill["category"] in costs)
            costs[bill["category"]] += bill["amountCents"]
            accrued_by_week[bill["week"]] += bill["amountCents"]
            if bill["category"] != "capability":
                noncap_by_week[bill["week"]] += bill["amountCents"]
            event_type = "refund" if bill["category"] == "refund" else "expense_payment"
            self.check("bill_payment_once", event_refs[(event_type, bill["id"])], 1 if bill["paid"] else 0)
            if bill["paid"]:
                self.check("bill_paid_after_due", bill["paidWeek"] >= bill["dueWeek"])
        accepted = [j for j in jobs if j["accepted"]]
        self.check("invoice_denominator", len(invoices), len(accepted))
        accepted_ids = {j["id"] for j in accepted}
        self.check("invoice_job_bijection", {i["mission"] for i in invoices}, accepted_ids)
        new_inv, cleared_inv = defaultdict(int), defaultdict(int)
        expected_bills = Counter()

        def expect(week, due, category, value, reference):
            if value:
                expected_bills[(week, due, category, value, reference)] += 1

        expect(0, 0, "capability", c["historicalResearchCents"], HISTORICAL)
        expect(0, 0, "business", c["initialSetupCents"], SETUP)
        for invoice in invoices:
            job = jmap[invoice["mission"]]
            self.fields("invoice_terms", invoice, {"week": job["week"], "dueWeek": job["week"] + c["paymentDelayWeeks"], "amountCents": job["priceCents"]})
            status = "collected" if invoice["pays"] else "defaulted"
            self.check("invoice_terminal_status", invoice["status"], status)
            new_inv[invoice["week"]] += invoice["amountCents"]
            cleared_inv[invoice["dueWeek"]] += invoice["amountCents"]
            self.check("invoice_collection_once", event_refs[("simulated_collection", invoice["id"])], 1 if status == "collected" else 0)
            if status == "collected":
                self.check("collection_due_week", invoice["collectedWeek"], invoice["dueWeek"])
                self.check("collection_fee_recorded", invoice["feeRecorded"])
                expect(invoice["dueWeek"], invoice["dueWeek"], "business", rounded(invoice["amountCents"] * c["paymentFeeBps"] / 10000), "collection-fee:" + invoice["id"])
                if invoice["refund"]:
                    expect(invoice["dueWeek"], invoice["dueWeek"] + c["refundDelayWeeks"], "refund", invoice["amountCents"], invoice["id"])
        seen_buyers = set()
        profiles = {p["id"]: p for p in c["profiles"]}
        classes = {p["id"]: p for p in c["classes"]}
        for job in jobs:
            p = profiles[job["profileId"]]["classes"][job["classId"]]
            price = rounded(classes[job["classId"]]["humanReferenceCents"] * (1 - c["discountBps"] / 10000))
            onboard = 0 if job["buyer"] in seen_buyers else c["providerOnboardingCents"]
            seen_buyers.add(job["buyer"])
            self.fields("job_terms", job, {"priceCents": price, "humanReferenceCents": classes[job["classId"]]["humanReferenceCents"],
                "recurringCostCents": recurring(p), "marginalExecutionCostCents": p["marginalExecutionCostCents"],
                "allocatedSetupCents": p["setupAllocationCents"], "actualAttempts": p["attemptsPerJob"], "customerMinutes": p["customerMinutes"],
                "providerOnboardingCents": onboard, "invoiceCreated": job["accepted"],
                "customerNominalSavingsCents": classes[job["classId"]]["humanReferenceCents"] - price if job["accepted"] else 0,
                "profileSourceSHA256": profiles[job["profileId"]]["sourceSHA256"]})
            self.check("job_supported", p["supported"])
            self.check("job_active_generation", job["profileId"], c["profiles"][profile_index(job["week"], investments)]["id"])
            expect(job["week"], job["week"] + c["expenseDelayWeeks"], "delivery", p["deliveryCostCents"], job["id"])
            expect(job["week"], job["week"] + c["expenseDelayWeeks"], "business", p["businessCostCents"], job["id"])
            expect(job["week"], job["week"] + c["expenseDelayWeeks"], "business", onboard, f"provider-onboarding:b{job['buyer']}")
        acquisition = {b["reference"]: b for b in bills if b["reference"].startswith("opportunity-acquisition:")}
        screening = {b["reference"]: b for b in bills if b["reference"].startswith("opportunity-screen:")}
        choice_ids = {f"w{x['week']}-b{x['buyer']}" for x in choices}
        self.check("enterprise_choice_job_bijection", {f"w{x['week']}-b{x['buyer']}" for x in choices if x["choice"] == "enterprise"}, set(jmap))
        spent, used, last = defaultdict(int), set(), {}
        slots = Counter()
        for choice in choices:
            week, buyer = choice["week"], choice["buyer"]
            item = classes[choice["classId"]]
            self.check("buyer_budget_before_choice", choice["remainingBuyerBudgetCents"], c["buyerProcurementBudgetCents"] - spent[buyer])
            self.check("buyer_onboarding_state", choice["providerOnboardingDue"], buyer not in used)
            switch = (c["buyerIntegrationCents"] if buyer not in used else 0) + (c["buyerSwitchingCents"] if last.get(buyer) not in (None, "enterprise") else 0)
            self.check("buyer_switch_cost", choice["enterpriseSwitchCostCents"], switch)
            self.check("buyer_value", choice["buyerValueCents"], rounded(item["humanReferenceCents"] * c["buyerValueMultiplier"]))
            utility, selected = choose(choice["offers"], choice["buyerValueCents"], c["buyerErrorLossCents"])
            self.check("buyer_choice_from_recorded_offers", choice["choice"], selected)
            self.check("buyer_selected_utility", choice["utilityCents"], utility)
            for offer in choice["offers"]:
                q = c["humanQuality"] if offer["id"] == "human" else c["enterprisePerceivedQuality"]
                price = item["humanReferenceCents"] if offer["id"] == "human" else rounded(item["humanReferenceCents"] * (1 - c["discountBps"] / 10000))
                self.fields("buyer_offer", offer, {"quality": q, "priceCents": price})
                self.check("offer_within_buyer_budget", price <= choice["remainingBuyerBudgetCents"])
                self.check("offer_set_scope", offer["id"] in ("human", "enterprise"))
            ref = f"w{week}-b{buyer}"
            acquired = "opportunity-acquisition:" + ref in acquisition
            screened = "opportunity-screen:" + ref in screening
            if c["opportunityAcquisitionCents"] and c["opportunityScreeningCents"]:
                self.check("screening_acquisition_pair", acquired, screened)
            if acquired:
                expect(week, week + c["expenseDelayWeeks"], "business", c["opportunityAcquisitionCents"], "opportunity-acquisition:" + ref)
            if screened:
                expect(week, week + c["expenseDelayWeeks"], "business", c["opportunityScreeningCents"], "opportunity-screen:" + ref)
            if not balances[week]["insolvent"]:
                self.check("every_active_opportunity_acquired", acquired or c["opportunityAcquisitionCents"] == 0)
                self.check("every_active_opportunity_screened", screened or c["opportunityScreeningCents"] == 0)
            if choice["choice"] == "human":
                spent[buyer] += item["humanReferenceCents"]
            elif choice["choice"] == "enterprise":
                used.add(buyer)
                slots[week] += 1
                job = jmap[ref]
                if job["accepted"]:
                    spent[buyer] += job["priceCents"]
            if choice["choice"] != "defer":
                last[buyer] = choice["choice"]
            self.check("buyer_finite_spending", spent[buyer] <= c["buyerProcurementBudgetCents"])
        for count in slots.values():
            self.check("weekly_capacity", count <= c["enterpriseSlotsPerWeek"])
        for ref in acquisition:
            self.check("acquisition_has_opportunity", ref.split(":", 1)[1] in choice_ids)
        for ref in screening:
            self.check("screening_has_opportunity", ref.split(":", 1)[1] in choice_ids)
        for week in range(c["weeks"]):
            overhead = [b for b in bills if b["week"] == week and b["reference"] == "Recurring service business costs"]
            self.check("overhead_once_per_week", len(overhead) <= 1)
            if not balances[week]["insolvent"]:
                self.check("overhead_active_week", len(overhead), 1 if c["weeklyOverheadCents"] else 0)
            if week and balances[week - 1]["insolvent"]:
                self.check("no_overhead_after_insolvency", len(overhead), 0)
            if overhead:
                expect(week, week + c["expenseDelayWeeks"], "business", c["weeklyOverheadCents"], "Recurring service business costs")
            active = profile_index(week, investments)
            actual = Counter((b["amountCents"], b["reference"]) for b in bills if b["week"] == week and b["category"] == "maintenance")
            wanted = Counter((c["capabilities"][i]["weeklyMaintenanceCents"], c["capabilities"][i]["sourceSHA256"]) for i in range(active) if c["capabilities"][i]["weeklyMaintenanceCents"])
            if not balances[week]["insolvent"]:
                self.check("maintenance_active_lifetime", actual, wanted)
            for pair, count in actual.items():
                self.check("maintenance_within_active_chain", count <= wanted[pair])
                for _ in range(count):
                    expect(week, week + c["expenseDelayWeeks"], "maintenance", pair[0], pair[1])
        self.check("investment_limit", len(investments) <= run["maximumInvestments"])
        self.check("investment_decision_bijection", [d for d in h["decisions"] if d["action"] == "invest"], investments)
        for i, inv in enumerate(investments):
            cap = c["capabilities"][i]
            self.fields("investment_terms", inv, {"capabilityId": cap["id"], "sourceSHA256": cap["sourceSHA256"], "fullCostCents": cap_cost(cap),
                "availableWeek": inv["week"] + cap["constructionWeeks"], "expiresWeek": inv["week"] + cap["constructionWeeks"] + cap["lifetimeWeeks"],
                "predecessor": c["capabilities"][i - 1]["id"] if i else c["profiles"][0]["id"], "beforeProfile": c["profiles"][i]["id"], "afterProfile": c["profiles"][i + 1]["id"]})
            expect(inv["week"], inv["week"], "capability", cap_cost(cap), cap["sourceSHA256"])
            self.check("capability_paid_from_generated_funds", inv["operatingGeneratedCents"] >= cap_cost(cap))
            self.check("capability_liquid_after_reserves", inv["liquidAfterObligationsAndReserveCents"] >= cap_cost(cap))
        actual_bills = Counter((b["week"], b["dueWeek"], b["category"], b["amountCents"], b["reference"]) for b in bills)
        self.check("all_bill_origins_and_once_only_costs", actual_bills, expected_bills)
        historical = sum(b["amountCents"] for b in bills if b["reference"] == HISTORICAL and b["paid"] and b.get("paidWeek") == 0)
        first_collection = next((i for i, e in enumerate(events) if e["type"] == "simulated_collection"), len(events))
        for b in bills:
            if b["reference"] == HISTORICAL and b["paid"]:
                payment_position = next(i for i, e in enumerate(events) if e["reference"] == b["id"])
                self.check("historical_seed_paid_before_collections", payment_position < first_collection)
        self.check("historical_addback_within_seed", historical <= c["initialCashCents"])
        terminal = c["weeks"] + max(c["paymentDelayWeeks"] + c["refundDelayWeeks"], c["expenseDelayWeeks"]) + 1
        self.check("weekly_balance_coverage", [b["week"] for b in balances], list(range(terminal + 1)))
        running_cash, gross, accrued, paid_total, noncap, outstanding = c["initialCashCents"], 0, 0, 0, 0, 0
        own_balances, own_funding = [], []
        for b in balances:
            w = b["week"]
            running_cash += cash_by_week[w]
            gross += receipts_by_week[w]
            accrued += accrued_by_week[w]
            paid_total += paid_by_week[w]
            noncap += noncap_by_week[w]
            outstanding += new_inv[w] - cleared_inv[w]
            obligations = accrued - paid_total
            liquid = running_cash - obligations - c["reserveCents"]
            fiscal = rounded(max(0, gross - noncap) * c["fiscalReserveBps"] / 10000)
            protected = liquid - fiscal
            gen = max(0, min(protected, gross - accrued + historical - fiscal))
            own = {"week": w, "cashCents": running_cash, "receivablesCents": outstanding, "obligationsCents": obligations,
                   "reserveCents": c["reserveCents"], "availableCashCents": liquid, "earnedAvailableCents": min(liquid, gross - accrued - c["reserveCents"]),
                   "fiscalReserveCents": fiscal, "protectedCashCents": protected, "generatedAvailableCents": gen,
                   "cumulativeCollectionsCents": gross, "accruedCostsCents": accrued, "paidCostsCents": paid_total,
                   "profileIndex": profile_index(w, investments)}
            self.fields("weekly_reconciliation", b, own)
            self.check("weekly_nonnegative_obligations", obligations >= 0)
            self.check("weekly_nonnegative_receivables", outstanding >= 0)
            if w and balances[w - 1]["insolvent"]:
                self.check("insolvency_latched", b["insolvent"])
            own_balances.append(own)
            funding = {"week": w, "cashCents": running_cash, "unpaidObligationsCents": obligations, "reserveCents": c["reserveCents"],
                       "collectedCents": gross, "allAccruedCostsCents": accrued, "explicitlySeedPaidOpeningHistoricalRDCents": historical,
                       "prospectiveAccruedCostsToRecoverCents": accrued - historical, "cashCapBeforeEarmarksCents": liquid,
                       "generatedBeforeEarmarksCents": gross - accrued + historical, "outstandingUnaccruedEarmarksCents": 0,
                       "cashCapAfterEarmarksCents": liquid, "generatedAfterEarmarksCents": gross - accrued + historical,
                       "fundingCeilingBeforeUnpricedDiscoveryCents": max(0, min(liquid, gross - accrued + historical)),
                       "fullCostRecoveryCeilingBeforeUnpricedDiscoveryCents": max(0, min(liquid, gross - accrued)),
                       "originalStrictEarnedAvailableCents": min(liquid, gross - accrued - c["reserveCents"])}
            self.fields("legacy_funding_attribution", run["fundingAttribution"]["weekly"][w], funding)
            own_funding.append(funding)
        self.audit_decisions(c, h, historical)
        last_balance = own_balances[-1]
        full_cost = sum(costs.values())
        obligations = full_cost - sum(paid.values())
        receivable = sum(i["amountCents"] for i in invoices if i["status"] == "pending")
        profit = collections + receivable - full_cost
        n = len(accepted)
        operating = full_cost - costs["capability"] - c["initialSetupCents"]
        derived = {"opportunities": len(choices), "buyerDeclines": sum(x["choice"] == "defer" for x in choices),
                   "humanChosen": sum(x["choice"] == "human" for x in choices), "attempts": len(jobs), "accepted": n, "rejected": len(jobs) - n,
                   "totalExecutionAttempts": sum(j["actualAttempts"] for j in jobs), "grossInvoicesCents": sum(i["amountCents"] for i in invoices),
                   "grossCollectionsCents": collections, "refundsCents": costs["refund"], "defaultsCents": sum(i["amountCents"] for i in invoices if i["status"] == "defaulted"),
                   "finalCashCents": cash, "obligationsCents": obligations, "receivablesCents": receivable, "reserveCents": c["reserveCents"],
                   "fiscalReserveCents": last_balance["fiscalReserveCents"], "totalProtectedReservesCents": c["reserveCents"] + last_balance["fiscalReserveCents"],
                   "accruedCostsCents": full_cost, "paidCostsCents": sum(paid.values()), "costCategoriesCents": costs,
                   "fullProjectProfitCents": profit, "fullProjectCostRecovered": profit >= 0,
                   "deploymentValueBeforeHistoricalCostCents": profit + c["historicalResearchCents"],
                   "operatingGeneratedAvailableCents": last_balance["generatedAvailableCents"], "investmentCount": len(investments),
                   "perAcceptedMarginalExecutionCents": sum(j["marginalExecutionCostCents"] for j in jobs) / n if n else None,
                   "perAcceptedDeliveryAndSupportCents": sum(j["recurringCostCents"] for j in jobs) / n if n else None,
                   "recurringOperatingCostsCents": operating, "perAcceptedRecurringCents": operating / n if n else None,
                   "setupAllocationPerAcceptedCents": c["initialSetupCents"] / n if n else None,
                   "historicalAllocationPerAcceptedCents": c["historicalResearchCents"] / n if n else None,
                   "capabilityInvestmentCents": sum(cap_cost(c["capabilities"][i]) for i in range(len(investments))),
                   "perAcceptedFullyAllocatedCents": full_cost / n if n else None,
                   "nominalCustomerSavingsCents": sum(j["customerNominalSavingsCents"] for j in accepted)}
        self.fields("terminal_summary", reported, derived)
        self.check("terminal_cash_identity", cash, c["initialCashCents"] + collections - sum(paid.values()))
        self.check("accrual_cash_bridge", profit, cash + receivable - obligations - c["initialCashCents"])
        self.fields("funding_terminal", run["fundingAttribution"]["terminal"], own_funding[-1])
        funding = run["fundingAttribution"]
        funding_amounts = [x["fundingCeilingBeforeUnpricedDiscoveryCents"] for x in own_funding]
        service_amounts = [x for x in own_funding if x["week"] < c["weeks"]]
        self.fields("funding_summary", funding, {"historicalRDCentsExcluded": historical,
            "firstPositiveFundingCeilingWeek": next((x["week"] for x in own_funding if x["fundingCeilingBeforeUnpricedDiscoveryCents"] > 0), None),
            "maximumFundingCeilingBeforeUnpricedDiscoveryCents": max(funding_amounts),
            "maximumDuringServiceFundingCeilingBeforeUnpricedDiscoveryCents": max(x["fundingCeilingBeforeUnpricedDiscoveryCents"] for x in service_amounts),
            "firstPositiveDuringServiceFundingCeilingWeek": next((x["week"] for x in service_amounts if x["fundingCeilingBeforeUnpricedDiscoveryCents"] > 0), None),
            "additionalPrudentialFiscalReserveCents": last_balance["fiscalReserveCents"],
            "finalAvailableAfterPrudentialReserveCents": last_balance["generatedAvailableCents"],
            "financialAuthority": "NONE", "unpricedIncrementalDiscoveryCostCents": None, "allInSpendableResourcesIdentified": False})
        for kind, revenue, expense, reserve, debt in (("economic", collections + receivable, full_cost, 0, 0),
            ("cash", collections, sum(paid.values()), derived["totalProtectedReservesCents"], obligations)):
            ledger = run["canonical"][kind]
            scenario = ledger["summary"]["scenario"]
            margin = revenue - expense
            self.fields("canonical_" + kind, scenario, {"revenue": revenue, "fullCost": expense, "operatingMargin": margin,
                "reserve": reserve, "unpaidObligations": debt, "afterReserves": margin - reserve - debt,
                "availableSurplus": max(0, margin - reserve - debt), "eligibleInvestment": 0})
            self.fields("canonical_observed", ledger["summary"]["observed"], {"revenue": 0, "fullCost": None, "operatingMargin": None, "availableSurplus": None})
            le = ledger["ledger"]["events"]
            self.check("canonical_cost_events", sum(x["amountMinor"] for x in le if x["type"] == "cost"), expense)
            self.check("canonical_assumed_revenue_events", sum(x["amountMinor"] for x in le if x["type"] == "revenue" and x["basis"] == "assumed"), revenue)
            self.check("canonical_observed_revenue_events", sum(x["amountMinor"] for x in le if x["type"] == "revenue" and x["basis"] == "observed"), 0)
        return {"summary": derived, "balances": own_balances, "jobs": jobs, "investments": investments, "config": c}

    def audit_decisions(self, c, h, historical):
        cap_ids = {cap["id"]: i for i, cap in enumerate(c["capabilities"])}
        imap = {i["id"]: i for i in h["invoices"]}
        classes = {x["id"]: x for x in c["classes"]}
        for decision in h["decisions"]:
            week, next_index = decision["week"], cap_ids[decision["capabilityId"]]
            cap = c["capabilities"][next_index]
            previous = [i for i in h["investments"] if i["week"] < week]
            self.check("decision_after_earliest_week", week >= c["investmentEarliestWeek"])
            self.check("decision_uses_available_predecessors", profile_index(week, previous), next_index)
            prefix = []
            for bill in h["bills"]:
                if bill["week"] > week:
                    break
                ref = bill["reference"]
                post = bill["category"] in ("capability", "delivery") or ref.startswith(("opportunity-", "provider-onboarding:")) or re.fullmatch(r"w\d+-b\d+", ref)
                if ref.startswith("collection-fee:"):
                    post = imap[ref.split(":", 1)[1]]["week"] >= week
                if bill["category"] == "refund":
                    post = imap[ref]["week"] >= week
                if bill["week"] == week and post:
                    break
                prefix.append(bill)
            allowed = {b["id"] for b in prefix}
            prior_cash = []
            for event in h["cash"]:
                if event["week"] > week:
                    break
                if event["week"] == week:
                    if event["type"] == "simulated_collection" and imap[event["reference"]]["week"] >= week:
                        break
                    if event["type"] != "simulated_collection" and event["reference"] not in allowed:
                        break
                prior_cash.append(event)
            collected = sum(e["amountCents"] for e in prior_cash if e["type"] == "simulated_collection")
            paid = -sum(e["amountCents"] for e in prior_cash if e["type"] != "simulated_collection")
            accrued = sum(b["amountCents"] for b in prefix)
            noncap = sum(b["amountCents"] for b in prefix if b["category"] != "capability")
            cash = c["initialCashCents"] + collected - paid
            fiscal = rounded(max(0, collected - noncap) * c["fiscalReserveBps"] / 10000)
            liquid = cash - (accrued - paid) - c["reserveCents"] - fiscal
            generated = max(0, min(liquid, collected - accrued + historical - fiscal))
            self.fields("decision_funding_reconciliation", decision, {"operatingGeneratedCents": generated, "liquidAfterObligationsAndReserveCents": liquid})
            remaining = min(i["expiresWeek"] for i in previous) - week - cap["constructionWeeks"] if next_index else c["weeks"]
            lifetime = min(cap["lifetimeWeeks"], c["weeks"] - week - cap["constructionWeeks"], remaining)
            window = min(c["forecastWindowWeeks"], week)
            recent = [x for x in h["choices"] if week - window <= x["week"] < week]
            weekly_benefit = 0.0
            for prior in recent:
                item = classes[prior["classId"]]
                price = rounded(item["humanReferenceCents"] * (1 - c["discountBps"] / 10000))
                values = []
                for profile in (c["profiles"][next_index], c["profiles"][next_index + 1]):
                    p = profile["classes"][item["id"]]
                    contribution = 0.0
                    if p["supported"] and price <= prior["remainingBuyerBudgetCents"]:
                        offer = {"id": "enterprise", "priceCents": price, "quality": c["enterprisePerceivedQuality"],
                                 "effortCents": rounded(p["customerMinutes"] * c["buyerHourlyCents"] / 60),
                                 "delayCents": c["enterpriseDays"] * c["delayCentsPerDay"], "switchCents": prior["enterpriseSwitchCostCents"]}
                        offers = [o for o in prior["offers"] if o["id"] == "human"] + [offer]
                        if choose(offers, prior["buyerValueCents"], c["buyerErrorLossCents"])[1] == "enterprise":
                            receipts = price * p["acceptanceProbability"] * c["fieldReliabilityMultiplier"] * c["paymentProbability"] * (1 - c["refundProbability"] - c["paymentFeeBps"] / 10000)
                            contribution = (receipts - recurring(p) - (c["providerOnboardingCents"] if prior["providerOnboardingDue"] else 0)) * (1 - c["fiscalReserveBps"] / 10000)
                    values.append(contribution)
                weekly_benefit += (values[1] - values[0]) / window
            benefit = math.floor(weekly_benefit * max(0, lifetime) * c["forecastDiscount"])
            maintenance = max(0, lifetime) * cap["weeklyMaintenanceCents"]
            full = cap_cost(cap)
            self.fields("past_only_forecast", decision, {"fullCostCents": full, "forecastBenefitCents": benefit,
                "forecastMaintenanceCents": maintenance, "forecastNetCents": benefit - maintenance - full,
                "forecastWeeks": max(0, lifetime), "recentObservedScenarioOpportunities": len(recent)})
            should_invest = lifetime > 0 and benefit > full + maintenance and generated >= full and liquid >= full
            self.check("investment_decision_rule", decision["action"], "invest" if should_invest else "hold")

    def paired(self, world, runs):
        base, first, full = runs
        protected = lambda r: r["summary"]["finalCashCents"] - r["summary"]["obligationsCents"] - r["summary"]["totalProtectedReservesCents"]
        comparison = []
        for i, r in enumerate((first, full), 1):
            expected = {"maximumInvestments": i, "deltaProjectProfitCents": r["summary"]["fullProjectProfitCents"] - base["summary"]["fullProjectProfitCents"],
                        "deltaCashCents": r["summary"]["finalCashCents"] - base["summary"]["finalCashCents"],
                        "deltaProtectedCashCents": protected(r) - protected(base), "deltaAccepted": r["summary"]["accepted"] - base["summary"]["accepted"],
                        "operatingFinancedInvestments": len(r["investments"]), "allInvestmentsOperatingFinanced": all(x["operatingGeneratedCents"] >= x["fullCostCents"] for x in r["investments"])}
            self.fields("paired_comparison", world["comparisons"][i - 1], expected)
            comparison.append(expected)
        def repayment(invested, control, index, protected_basis):
            if len(invested["investments"]) <= index:
                return None
            available = invested["investments"][index]["availableWeek"]
            value = (lambda b: b["cashCents"] - b["obligationsCents"] - b["reserveCents"] - b["fiscalReserveCents"]) if protected_basis else (lambda b: b["cashCents"] + b["receivablesCents"] - b["obligationsCents"])
            return next((a["week"] for a, b in zip(invested["balances"], control["balances"]) if a["week"] >= available and value(a) > value(b)), None)
        def uses(run, index, only_changed):
            profiles = run["config"]["profiles"]
            ids = {p["id"]: i for i, p in enumerate(profiles)}
            count = 0
            for job in run["jobs"]:
                if not job["accepted"] or ids[job["profileId"]] < index + 1:
                    continue
                a, b = profiles[index]["classes"][job["classId"]], profiles[index + 1]["classes"][job["classId"]]
                if not only_changed or a["supported"] != b["supported"] or a["acceptanceProbability"] != b["acceptanceProbability"] or recurring(a) != recurring(b):
                    count += 1
            return count
        first_uses, second_uses = uses(first, 0, True), uses(full, 1, True)
        second_profit = full["summary"]["fullProjectProfitCents"] - first["summary"]["fullProjectProfitCents"]
        second_cash = protected(full) - protected(first)
        first_ok = len(first["investments"]) >= 1 and first_uses > 0 and comparison[0]["deltaProjectProfitCents"] > 0 and comparison[0]["deltaProtectedCashCents"] > 0
        second_ok = len(full["investments"]) >= 2 and second_uses > 0 and second_profit > 0 and second_cash > 0
        expected = {"firstInvestmentFunded": len(first["investments"]) >= 1, "firstCapabilityAcceptedUses": first_uses,
                    "secondCapabilityAcceptedUses": second_uses, "firstProfileTotalAcceptedUses": uses(first, 0, False),
                    "secondProfileTotalAcceptedUses": uses(full, 1, False), "firstRepaymentWeek": repayment(first, base, 0, True),
                    "secondRepaymentWeek": repayment(full, first, 1, True), "firstAccruedValueRepaymentWeek": repayment(first, base, 0, False),
                    "secondAccruedValueRepaymentWeek": repayment(full, first, 1, False), "firstRepaysInPairedModel": first_ok,
                    "secondInvestmentFunded": len(full["investments"]) >= 2, "secondIncrementalProjectValueCents": second_profit,
                    "secondIncrementalProtectedCashCents": second_cash, "finalOperatingGeneratedSurplusCents": full["summary"]["operatingGeneratedAvailableCents"],
                    "historicalAndFullProjectCostRecovered": full["summary"]["fullProjectCostRecovered"], "secondRepaysInPairedModel": second_ok,
                    "fullCycleWithinModel": first_ok and second_ok and comparison[1]["deltaProjectProfitCents"] > 0 and full["summary"]["operatingGeneratedAvailableCents"] > 0}
        self.fields("connected_cycle", world["connectedCycle"], expected)
        return expected

    def campaign(self, name, protocol_file, freeze_sha):
        folder = ROOT / "results" / name
        protocol_path = ROOT / "protocol/economics-primary" / protocol_file
        protocol = load(protocol_path)
        start, completion, summary = (load(folder / x) for x in ("STARTED.json", "completion.json", "summary.json"))
        self.context = {"campaign": name, "phase": "identity"}
        for item in (protocol, start, summary):
            self.check("campaign_source_freeze_identity", item["sourceFreezeSHA256"], freeze_sha)
        for item in (start, summary):
            self.check("campaign_protocol_identity", item["protocolSHA256"], sha(protocol_path))
        for artifact in completion["artifacts"]:
            self.check("output_artifact_hash", sha(folder / artifact["path"]), artifact["sha256"], artifact["path"])
            self.check("output_artifact_bytes", (folder / artifact["path"]).stat().st_size, artifact["bytes"], artifact["path"])
        self.check("campaign_completed", completion["complete"])
        self.check("campaign_no_failures", completion["failures"], [])
        self.check("summary_zero_actual_collections", summary["actualCollectionsCents"], 0)
        config = {s["id"]: s for s in protocol["scenarios"]}
        compact = {(g["scenarioId"], s["seed"]): s for g in summary["groups"] for s in g["seeds"]}
        with (folder / "outcomes.csv").open(newline="") as f:
            csv_rows = {(r["scenario"], int(r["seed"]), int(r["maximumInvestments"])): r for r in csv.DictReader(f)}
        expected_worlds = {(s, seed) for s in config for seed in protocol["seeds"]}
        seen = set()
        cycles = profitable_full = two_investments = 0
        accepted_totals = Counter()
        count = 0
        with gzip.open(folder / "histories.jsonl.gz", "rt", encoding="utf-8") as f:
            for line in f:
                world = json.loads(line)
                key = (world["configId"], world["seed"])
                self.context = {"campaign": name, "scenario": key[0], "seed": key[1]}
                self.check("world_identity_registered", key in expected_worlds)
                self.check("world_not_replaced", key not in seen)
                seen.add(key)
                self.check("three_policy_histories", len(world["runs"]), 3)
                own_runs = []
                identities = []
                for i, run in enumerate(world["runs"]):
                    self.context["maximumInvestments"] = i
                    self.check("run_config_frozen", run["config"], config[key[0]])
                    self.check("run_seed", run["seed"], key[1])
                    self.check("policy_arm", run["maximumInvestments"], i)
                    own = self.run_history(run)
                    own_runs.append(own)
                    accepted_totals[i] += own["summary"]["accepted"]
                    identities.append([(x["week"], x["buyer"], x["classId"], x["forecastChoiceDraw"]) for x in run["histories"]["choices"]])
                    self.check("summary_copy", compact[key]["summaries"][i], run["summary"])
                self.context.pop("maximumInvestments", None)
                self.check("paired_world_opportunities", identities[0], identities[1])
                self.check("paired_world_opportunities", identities[0], identities[2])
                cycle = self.paired(world, own_runs)
                self.check("summary_cycle_copy", compact[key]["connectedCycle"], world["connectedCycle"])
                self.check("summary_comparison_copy", compact[key]["comparisons"], world["comparisons"])
                for i, own in enumerate(own_runs):
                    csv_row = csv_rows[(key[0], key[1], i)]
                    for field in ("attempts", "accepted", "grossCollectionsCents", "accruedCostsCents", "fullProjectProfitCents", "finalCashCents", "obligationsCents", "totalProtectedReservesCents", "operatingGeneratedAvailableCents", "investmentCount"):
                        self.check("csv_summary_copy", int(csv_row[field]), own["summary"][field], field)
                    self.check("csv_own_policy_delta", int(csv_row["deltaProjectProfitCents"]), own["summary"]["fullProjectProfitCents"] - own_runs[0]["summary"]["fullProjectProfitCents"])
                    self.check("csv_second_increment", int(csv_row["secondIncrementalProjectValueCents"]), cycle["secondIncrementalProjectValueCents"])
                    self.check("csv_cycle", csv_row["fullCycleWithinModel"], str(cycle["fullCycleWithinModel"]).lower())
                cycles += cycle["fullCycleWithinModel"]
                profitable_full += own_runs[2]["summary"]["fullProjectProfitCents"] >= 0
                two_investments += len(own_runs[2]["investments"]) == 2
                count += 1
                if count % 128 == 0:
                    print(json.dumps({"campaign": name, "worlds_audited": count, "histories_audited": count * 3, "failed_assertions": sum(self.failures.values())}), flush=True)
        self.context = {"campaign": name, "phase": "coverage"}
        self.check("complete_registered_worlds", seen, expected_worlds)
        self.check("complete_summary_worlds", set(compact), expected_worlds)
        self.check("complete_csv_histories", len(csv_rows), count * 3)
        self.check("completed_world_count", completion["completedWorlds"], count)
        self.check("completed_history_count", completion["completedHistories"], count * 3)
        result = {"campaign": name, "worlds": count, "histories": count * 3, "connected_cycles": cycles,
                  "full_policy_nonnegative_project_value": profitable_full, "full_policy_two_investments": two_investments,
                  "accepted_work_by_policy": dict(accepted_totals), "protocol_sha256": sha(protocol_path),
                  "history_archive_sha256": sha(folder / "histories.jsonl.gz"), "completion_sha256": sha(folder / "completion.json")}
        self.campaigns.append(result)
        print("CAMPAIGN_AUDIT " + json.dumps(result), flush=True)


def main(output):
    started = time.perf_counter()
    auditor = Audit()
    freeze_sha, frozen_files = auditor.identities()
    for folder, protocol in (("economics-primary-01", "campaign-primary.json"), ("economics-boundary-01", "campaign-boundary.json")):
        auditor.campaign(folder, protocol, freeze_sha)
    auditor.check("total_exhaustive_histories", auditor.totals["histories"], 9072)
    result = {"schema": "independent-exhaustive-economic-audit/v1", "created_at_utc": datetime.now(timezone.utc).isoformat(),
              "audit_source_sha256": sha(Path(__file__)), "source_freeze_sha256": freeze_sha, "frozen_files_checked": frozen_files,
              "all_checks_passed": not auditor.failures, "assertions": sum(auditor.checks.values()),
              "checks_by_family": dict(auditor.checks), "failed_assertions": sum(auditor.failures.values()),
              "failures_by_family": dict(auditor.failures), "first_failure_examples": auditor.examples,
              "exhaustive_event_counts": dict(auditor.totals), "campaigns": auditor.campaigns, "wall_seconds": time.perf_counter() - started,
              "independence": "Separately authored Python audit; simulator and accounting modules were read for schema/formulas but never invoked or imported. Every raw recorded history was audited, without sampling or data repair.",
              "controls": ["Frozen protocol/source/output hashes and complete paired-world coverage", "Every cash event and paid/unpaid bill linkage",
                  "Accepted-job invoice bijection, collections/defaults, payment fees and refund obligations", "Once-only setup/historical/capability construction and all attempt costs",
                  "Finite buyer procurement budgets, recorded-offer choice and nominal savings separation", "Every weekly cash/accrual/receivable/reserve balance",
                  "Operating-generated funding at each investment decision before that week's new jobs", "Past-only forecast arithmetic, prerequisite lifetime and affordability",
                  "Legacy fixed-reserve attribution and additional fiscal reserve separately", "Canonical observed/scenario separation", "All paired repayment/use/cycle predicates and summary/CSV copies"],
              "limits": ["Internal accounting consistency does not validate assumed demand, costs, human-price scope equivalence or future field reliability.",
                  "Actual research/model/review monetary cost remains unknown and actual customer collections remain zero.",
                  "No external buyer acceptance or paid commercial transaction is certified.",
                  "Random arrival/outcome draws are not regenerated; paired opportunity identities, recorded invoice outcomes and financial consequences are reconciled.",
                  "Recorded-offer buyer choices are checked; market adoption and trust calibration are not empirical observations.",
                  "The inherited funding-view unknown-discovery qualification remains visible; its fixed-reserve ceiling is not the adapter's final protected amount."]}
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2, sort_keys=True, default=lambda x: dict(x) if isinstance(x, Counter) else list(x)) + "\n", encoding="utf-8")
    print("AUDIT_FINAL " + json.dumps({"all_checks_passed": result["all_checks_passed"], "assertions": result["assertions"], "failed_assertions": result["failed_assertions"], "histories": auditor.totals["histories"], "receipt_sha256": sha(output)}), flush=True)
    return 0 if result["all_checks_passed"] else 1


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, default=ROOT / "review/economics_audit_receipt.json")
    args = parser.parse_args()
    raise SystemExit(main(args.out))
