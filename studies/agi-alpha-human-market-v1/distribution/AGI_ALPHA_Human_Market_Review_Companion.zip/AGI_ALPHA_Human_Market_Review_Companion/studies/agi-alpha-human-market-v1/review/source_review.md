# Independent recipient reconstruction and production review

This review was performed by a separate AI agent. It is an engineering review of the bounded synthetic/public CSV service, not professional customer acceptance, market demand evidence, or a monetary cost measurement. Primary fresh inputs, primary acceptance expectations, and private keys were not inspected.

## Contract-only reconstruction before donor access

The recipient read the delivery contract and the parent's explicit contract clarifications, then implemented `independent_recipient.py` using ordinary Python standard-library tools. It implemented the three declared generations, including locale normalization and latest-version reconciliation. Ten manually specified synthetic control groups passed before the donor implementation was opened. `recipient_freeze.json` records the source and control hashes and the access boundary.

The recorded authoring-and-tools interval was 108 seconds, from 2026-10-26 21:21:02 UTC to 21:22:50 UTC. The control execution took approximately 1.51 ms CPU and 1.51 ms wall time in that single development observation. These are measurements of this AI-assisted reconstruction and control run, not estimates of a competent human's labor. Model tokens, monetary cost, and human attention were not metered and remain unknown.

The recipient therefore did not demonstrably lack an equivalent parsing/reconciliation capability before transfer. An absent donor file would have been a misleading proxy for missing capability. Later fresh transfer tests must retain this negative result and may establish only measured reuse, reliability, or reconstruction-effort differences. They cannot claim a scarce-skill feasibility unlock on the strength of these controls.

The frozen independent recipient used the pre-final-review contract. Subsequent explicit contract restrictions include a minimum of one data row, bounded grouped amounts, and additional input-schema bounds. The frozen recipient is preserved unchanged. A fresh comparison must disclose this version distinction and restrict any equivalence claim to the actual jobs tested; adaptation after donor access cannot be described as pre-transfer ignorance.

## Material findings and corrections

| Finding | Consequence | Correction reviewed |
|---|---|---|
| Packaged job retained the incoming filename while the packaged source was renamed `original.csv`. | A customer could not rerun the advertised revision job as packaged. | A distinct `revision-job.json` now names `original.csv`; the incoming job remains retained. Revision lineage is the exact prior manifest digest, with matching source identity. |
| A child timeout escaped the campaign loop. | One failed job could stop the bounded campaign without preserving all attempted work. | Timeout output is recorded, exit code 124 is retained, no retry is inserted, and later jobs continue. An attempts checkpoint is saved after each child. |
| Source identities were checked only once before the campaign. | A mid-campaign source change could mix implementations. | Frozen identities are checked immediately before and after each child. A drift stops the campaign with the attempted-work checkpoint retained. |
| Header normalization, Unicode digit matching, and under-specified input bounds differed from the intended contract. | Acceptance could depend on implicit parser choices. | Headings are now exact, digits ASCII, date years bounded, amount groups and integer digits bounded, data-row count explicit, and input-schema bounds documented before fresh confirmation. |
| Graph scope used a contract filename, and the generation-two dependency omitted the admitted generation-one implementation and scope. | A root could commit to insufficiently identified claims. | Scope now includes the actual contract SHA-256; the dependency binds the full generation-one skill record. The environment derives from the production-freeze record. |

Earlier implementation snapshots remain preserved by the parent in `history/pre_review_source`. These findings arose during development/review; completed experiments were not rewritten.

## Executed control evidence

`source_review_corrected_parser.json` records eleven passing control groups against the corrected production parser: normalization and negative zero; required and invalid values; monetary boundaries; calendar boundaries; hold conflicts; latest-version ties and link destinations; category mapping before missingness; quoted multiline record numbering; format refusals; exact headings; and ASCII-only dates. These are separate development controls, not primary fresh-work observations.

`revision_pack_review.json` records an independent check of the saved development parent/revision pair. Both completed; the packaged revision job names the retained source; the parent manifest digest is correct; the retained source hash matches the manifest; and all eleven declared package files have matching byte lengths and SHA-256 hashes.

The campaign and package review also checked that failed attempts retain process output, no confirmation retry is introduced, the source-frozen boundary is checked around execution, package artifact identities are verified, and the portable Workbench result remains `HOLD` with no execution or settlement authority. This is source inspection rather than an executed timeout or live authority test.

## Graph boundary and remaining check

The graph layer uses explicit identity fixtures. It records no live ENS authentication, no live cryptographic authentication, and no execution authority. The creator, validation signer, and root signer are separate roles. It leaves existing Jobs club roles and settlement unchanged. Merkle inclusion establishes the stated commitment and does not establish usefulness.

The reviewed graph requires the independent verdict's all-checks-passed flag, scoped acceptance counts, exact contract and production-freeze digests, and the sealed production-index digest. One final narrow review check remains: the current cleaner implementation hash must equal its frozen file identity before a graph record uses the frozen verdict as evidence. The closing machine-readable review record will state whether that check was resolved.

## Limits and accounting

The finite set of synthetic controls is not exhaustive and does not establish performance on confidential, arbitrary, or out-of-contract data. No customer bought or independently accepted these review controls. No primary confirmatory result was inspected as part of this review. Review model use and monetary cost are unmetered; they must remain disclosed as unknown historical research/development cost, not silently treated as zero delivery cost. The independent recipient source, controls, and freeze record are evidence of one reconstructing agent's demonstrated ability only.
