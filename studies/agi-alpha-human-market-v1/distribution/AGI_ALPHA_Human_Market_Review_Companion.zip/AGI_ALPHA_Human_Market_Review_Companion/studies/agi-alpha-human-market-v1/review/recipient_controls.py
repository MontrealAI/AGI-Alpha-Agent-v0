# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import csv
import hashlib
import io
import json
import platform
import resource
import tempfile
import time
from pathlib import Path
from typing import Any, Callable

import independent_recipient as recipient

BASE = {'delimiter': ',', 'amount_locale': 'dot', 'date_format': 'iso',
        'key_policy': 'hold', 'missing_markers': ['', 'NA'], 'category_map': {}}


def payload(rows: list[list[str]], delimiter: str = ',', bom: bool = False) -> bytes:
    out = io.StringIO(newline='')
    writer = csv.writer(out, delimiter=delimiter, lineterminator='\r\n')
    writer.writerow(recipient.FIELDS)
    writer.writerows(rows)
    return (('\ufeff' if bom else '') + out.getvalue()).encode('utf-8')


def statuses(result: dict[str, Any]) -> list[str]:
    return [row['status'] for row in result['disposition']]


def must_refuse(function: Callable[[], Any]) -> None:
    try:
        function()
    except (ValueError, UnicodeError, csv.Error):
        return
    raise AssertionError('input unexpectedly accepted')


def normalization() -> None:
    rules = dict(BASE, category_map={'Cafe\u0301': ' Cafe\u0301 items '})
    data = payload([[' 0007 ', ' Café ', '2024-02-29', '-0.0', 'NA'],
                    ['0007', 'Cafe\u0301', '2024-02-29', '0', '']], bom=True)
    actual = recipient.semantic(data, rules)
    assert actual['clean'] == [{'record_id':'0007','category':'Café items','date':'2024-02-29',
                               'amount':'0.00','updated_at':'','source_row':1}]
    assert actual['duplicates'] == [{'source_row':2,'kept_source_row':1}]
    assert statuses(actual) == ['CLEAN','DUPLICATE_EXACT']


def validation() -> None:
    data = payload([['x','','2024-02-30','1e3','2101-01-01'],['NA','NA','NA','NA','']])
    actual = recipient.semantic(data, BASE)
    assert actual['quarantine'] == [
        {'source_row':1,'reasons':['INVALID_AMOUNT','INVALID_DATE','INVALID_UPDATED_AT','MISSING_CATEGORY']},
        {'source_row':2,'reasons':['MISSING_AMOUNT','MISSING_CATEGORY','MISSING_DATE','MISSING_RECORD_ID']}]


def money_boundaries() -> None:
    good = {'0':'0.00','-0,00':'0.00','9.999.999.999,99':'9999999999.99',
            '000.001,2':'1.20','-1.234,56':'-1234.56','12':'12.00'}
    for raw, expected in good.items():
        assert recipient.money(raw,'comma') == expected, raw
    for bad in ('10.000.000.000,00','1.23,00','1.2345,00','1,234','+1,00','1e2','١٢,٠٠'):
        must_refuse(lambda raw=bad: recipient.money(raw,'comma'))
    for bad in ('1.','+1','1,00','00000000000.00','1.234','1e2','1 000.00'):
        must_refuse(lambda raw=bad: recipient.money(raw,'dot'))


def calendar_boundaries() -> None:
    assert recipient.iso_day('29/02/2000','dmy') == '2000-02-29'
    assert recipient.iso_day('31/12/2100','dmy') == '2100-12-31'
    for bad in ('29/02/1900','29/02/2100','01/01/1899','1/1/2024','2024-01-01'):
        must_refuse(lambda raw=bad: recipient.iso_day(raw,'dmy'))


def hold_conflicts() -> None:
    data = payload([['a','X','2024-01-01','1',''],['a','X','2024-01-01','1.00',''],
                    ['a','X','2024-01-01','2',''],['B','X','2024-01-01','2','']])
    actual = recipient.semantic(data,BASE)
    assert actual['quarantine'] == [{'source_row':1,'reasons':['CONFLICTING_KEY']},
                                     {'source_row':3,'reasons':['CONFLICTING_KEY']}]
    assert actual['duplicates'] == [{'source_row':2,'kept_source_row':1}]
    assert [v['record_id'] for v in actual['clean']] == ['B']
    assert statuses(actual) == ['QUARANTINE','DUPLICATE_EXACT','QUARANTINE','CLEAN']


def latest_reconciliation() -> None:
    rules = dict(BASE, key_policy='latest')
    data = payload([['a','X','2024-01-01','1','2024-01-02'],
                    ['a','X','2024-01-01','1.00','2024-01-02'],
                    ['a','Y','2024-01-01','2','2024-01-03'],
                    ['b','X','2024-01-01','2',''],
                    ['c','X','2024-01-01','2','2024-01-01'],
                    ['c','Y','2024-01-01','2','2024-01-01'],
                    ['c','X','2024-01-01','1','2023-12-31']])
    actual = recipient.semantic(data,rules)
    assert actual['superseded'] == [{'source_row':1,'kept_source_row':3}]
    assert actual['duplicates'] == [{'source_row':2,'kept_source_row':1}]
    assert [v['reasons'] for v in actual['quarantine']] == [
        ['MISSING_UPDATED_AT'],['CONFLICTING_LATEST'],['CONFLICTING_LATEST'],['CONFLICTING_LATEST']]
    assert statuses(actual) == ['SUPERSEDED','DUPLICATE_EXACT','CLEAN','QUARANTINE',
                                'QUARANTINE','QUARANTINE','QUARANTINE']


def category_mapping_then_missing() -> None:
    rules = dict(BASE, category_map={'NA':'North America','hidden':'NA'})
    data = payload([['1','NA','2024-01-01','1',''],['2','hidden','2024-01-01','1','']])
    actual = recipient.semantic(data,rules)
    assert actual['clean'][0]['category'] == 'North America'
    assert actual['quarantine'] == [{'source_row':2,'reasons':['MISSING_CATEGORY']}]
    must_refuse(lambda: recipient.semantic(data,dict(rules,missing_markers=['NA'])))


def quoted_record_numbers() -> None:
    data = payload([['=not_a_formula','one;two\r\n"three"','29/02/2024','1.234,50',''],
                    ['Z','x','01/01/2024','0','']],delimiter=';')
    actual = recipient.semantic(data,dict(BASE,delimiter=';',amount_locale='comma',date_format='dmy'))
    assert actual['clean'][0]['record_id'] == '=not_a_formula'
    assert actual['clean'][0]['category'] == 'one;two\r\n"three"'
    assert [row['source_row'] for row in actual['disposition']] == [1,2]


def format_refusals() -> None:
    good = payload([['1','x','2024-01-01','1','']])
    for bad in (b'\xff',b'record_id,category,date,amount,amount\n',
                payload([['1','x','2024-01-01','1']]),payload([['1','x'*257,'2024-01-01','1','']])):
        must_refuse(lambda value=bad: recipient.semantic(value,BASE))
    must_refuse(lambda: recipient.semantic(good,dict(BASE,key_policy='latest'),generation=1))
    must_refuse(lambda: recipient.semantic(good,dict(BASE,date_format='dmy'),generation=0))


def source_binding() -> None:
    data = payload([['1','x','2024-01-01','1','']])
    with tempfile.TemporaryDirectory(prefix='recipient-review-') as location:
        root = Path(location)
        (root/'input.csv').write_bytes(data)
        job = {'schema':'csv-clean-job/v1','id':'review','data_class':'synthetic',
               'source':{'file':'input.csv','sha256':hashlib.sha256(data).hexdigest()},'rules':BASE}
        assert len(recipient.deliver(job,root)['clean']) == 1
        must_refuse(lambda: recipient.deliver(dict(job,source=dict(job['source'],sha256='0'*64)),root))
        must_refuse(lambda: recipient.deliver(dict(job,source=dict(job['source'],file='../input.csv')),root))
        must_refuse(lambda: recipient.deliver(dict(job,data_class='private'),root))


def main() -> None:
    start_cpu, start_wall = time.process_time_ns(),time.perf_counter_ns()
    checks = []
    for fn in (normalization,validation,money_boundaries,calendar_boundaries,hold_conflicts,
               latest_reconciliation,category_mapping_then_missing,quoted_record_numbers,format_refusals,source_binding):
        started = time.perf_counter_ns()
        try:
            fn()
            checks.append({'name':fn.__name__,'passed':True,'wall_ns':time.perf_counter_ns()-started})
        except Exception as error:
            checks.append({'name':fn.__name__,'passed':False,'error':repr(error),
                           'wall_ns':time.perf_counter_ns()-started})
    result = {'kind':'contract_only_reconstruction_development_controls','primary_observation':False,
              'checks':checks,'cpu_ns':time.process_time_ns()-start_cpu,
              'wall_ns':time.perf_counter_ns()-start_wall,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
              'python':platform.python_version(),'passed':all(item['passed'] for item in checks)}
    destination = Path(__file__).with_name('recipient_control_results.json')
    destination.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
    if not result['passed']:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
