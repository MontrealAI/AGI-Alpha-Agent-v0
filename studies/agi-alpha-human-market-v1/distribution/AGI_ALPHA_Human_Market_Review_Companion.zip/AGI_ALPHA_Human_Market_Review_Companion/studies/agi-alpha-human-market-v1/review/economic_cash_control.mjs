// SPDX-License-Identifier: Apache-2.0
// Independently specified arithmetic control; never a primary economic world.
import assert from 'node:assert/strict';
import {readFile, writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {fixture} from '../economics/development-fixture.mjs';
import {simulateHumanMarket} from '../economics/human-market.mjs';

const config = fixture();
Object.assign(config, {id: 'INDEPENDENT_DEVELOPMENT_ARITHMETIC', weeks: 2, buyers: 1,
  arrivalProbability: 1, initialCashCents: 100000, reserveCents: 100,
  initialSetupCents: 100, historicalResearchCents: 200, weeklyOverheadCents: 10,
  opportunityScreeningCents: 2, opportunityAcquisitionCents: 20,
  paymentDelayWeeks: 0, paymentProbability: 1, expenseDelayWeeks: 0,
  refundDelayWeeks: 1, refundProbability: 0, discountBps: 1000,
  paymentFeeBps: 1000, fiscalReserveBps: 2000});
config.classes = [{id: 'simple', weight: 1, humanReferenceCents: 10000,
  priceEvidenceReference: 'Independent arithmetic control, not market evidence'}];
config.profiles.forEach(p => {p.classes = {simple: p.classes.simple};});
const result = simulateHumanMarket(config, 990001, {maximumInvestments: 0});
// Two accepted $90 invoices, $2 recurring per job, $9 fee per invoice,
// $1 setup, $2 historical research, and 2 * ($.10 + $.02 + $.20) weekly costs.
const expectedCosts = 400 + 1800 + 100 + 200 + 2 * (10 + 2 + 20);
const expectedProfit = 18000 - expectedCosts;
const expectedFiscalReserve = Math.round((18000 - expectedCosts + 200) * 0.20);
const expectedGenerated = 18000 - expectedCosts + 200 - expectedFiscalReserve;
assert.equal(result.summary.attempts, 2);
assert.equal(result.summary.accepted, 2);
assert.equal(result.summary.grossCollectionsCents, 18000);
assert.equal(result.summary.accruedCostsCents, expectedCosts);
assert.equal(result.summary.fullProjectProfitCents, expectedProfit);
assert.equal(result.summary.finalCashCents, 100000 + expectedProfit);
assert.equal(result.summary.fiscalReserveCents, expectedFiscalReserve);
assert.equal(result.summary.operatingGeneratedAvailableCents, expectedGenerated);
assert.equal(result.actualCustomerCollectionsCents, 0);
assert.equal(result.summary.obligationsCents, 0);
assert.equal(result.summary.investmentCount, 0);
const paths = ['economics/human-market.mjs', 'economics/development-fixture.mjs',
  'economics/upstream/market/upstream/src/cash-core.mjs'];
const sourceHashes = {};
for (const path of paths) sourceHashes[path] = createHash('sha256')
  .update(await readFile(new URL('../' + path, import.meta.url))).digest('hex');
const receipt = {schema: 'independent-economic-arithmetic-review/v1',
  primaryObservation: false, status: 'PASS', seed: 990001,
  expectationsDeclaredInSource: true, expectedCostsCents: expectedCosts,
  expectedProfitCents: expectedProfit, expectedFiscalReserveCents: expectedFiscalReserve,
  expectedGeneratedAvailableCents: expectedGenerated, observedSummary: result.summary,
  actualCustomerCollectionsCents: 0, sourceHashes,
  limitation: 'One deliberately simple arithmetic control; not customer demand or full-campaign validation.'};
await writeFile(new URL('./economic_cash_control.json', import.meta.url),
  JSON.stringify(receipt, null, 2) + '\n', {flag: 'wx'});
console.log(JSON.stringify(receipt, null, 2));
