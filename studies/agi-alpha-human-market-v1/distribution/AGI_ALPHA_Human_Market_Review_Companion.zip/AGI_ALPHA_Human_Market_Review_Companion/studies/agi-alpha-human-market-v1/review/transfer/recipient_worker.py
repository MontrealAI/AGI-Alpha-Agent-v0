# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.util
import json
import resource
import time
from pathlib import Path


def dump(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--job", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists():
        raise SystemExit("OUTPUT_EXISTS")
    args.out.mkdir(parents=True)
    start, cpu_start = time.perf_counter(), time.process_time()
    outcome = {"schema": "independent-recipient-route/v1", "method": "recipient", "generation": 2,
               "status": "FAILED", "scope": "SEMANTIC_ONLY", "actual_collections_usd": 0,
               "actual_complete_cost": None, "human_attention_minutes": None, "runtime_model_calls": 0}
    try:
        source = Path(__file__).resolve().parents[1] / "independent_recipient.py"
        spec = importlib.util.spec_from_file_location("contract_only_recipient", source)
        assert spec is not None and spec.loader is not None
        recipient = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(recipient)
        job = json.loads(args.job.read_text(encoding="utf-8"))
        result = recipient.deliver(job, args.job.parent, generation=2)
        dump(args.out / "semantic.json", result)
        outcome.update(status="COMPLETED", source_sha256=job["source"]["sha256"],
                       semantic_sha256=hashlib.sha256((args.out / "semantic.json").read_bytes()).hexdigest(),
                       counts={name: len(rows) for name, rows in result.items()},
                       source_code_sha256=hashlib.sha256(source.read_bytes()).hexdigest())
    except (ValueError, UnicodeError, csv.Error, KeyError, TypeError, OSError, RuntimeError) as exc:
        outcome["reason"] = repr(exc)
        outcome["status"] = "REFUSED" if isinstance(exc, (ValueError, UnicodeError, csv.Error)) else "FAILED"
    outcome.update(elapsed_seconds=time.perf_counter() - start, cpu_seconds=time.process_time() - cpu_start,
                   max_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    dump(args.out / "summary.json", outcome)
    print(json.dumps(outcome, sort_keys=True))


if __name__ == "__main__":
    main()
