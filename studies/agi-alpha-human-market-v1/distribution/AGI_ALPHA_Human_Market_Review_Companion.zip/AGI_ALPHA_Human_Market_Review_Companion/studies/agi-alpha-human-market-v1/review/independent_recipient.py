# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import csv
import hashlib
import io
import re
import unicodedata
from collections import defaultdict
from datetime import date
from pathlib import Path
from typing import Any

FIELDS = ('record_id', 'category', 'date', 'amount', 'updated_at')


def normalized(value: str) -> str:
    return unicodedata.normalize('NFC', value.strip())


def iso_day(value: str, style: str) -> str:
    pattern = r'[0-9]{4}-[0-9]{2}-[0-9]{2}' if style == 'iso' else r'[0-9]{2}/[0-9]{2}/[0-9]{4}'
    if re.fullmatch(pattern, value) is None:
        raise ValueError('date syntax')
    parts = [int(v) for v in re.split(r'[-/]', value)]
    year, month, day = parts if style == 'iso' else parts[::-1]
    if not 1900 <= year <= 2100:
        raise ValueError('year')
    return date(year, month, day).isoformat()


def money(value: str, locale: str) -> str:
    if locale == 'dot':
        pattern = r'-?[0-9]{1,10}(?:\.[0-9]{1,2})?'
        separator = '.'
    else:
        pattern = r'-?(?:[0-9]{1,10}|[0-9]{1,3}(?:\.[0-9]{3})+)(?:,[0-9]{1,2})?'
        separator = ','
    if re.fullmatch(pattern, value) is None:
        raise ValueError('amount syntax')
    negative = value.startswith('-')
    body = value[1:] if negative else value
    if locale == 'comma':
        body = body.replace('.', '')
    parts = body.split(separator)
    cents = int(parts[0]) * 100 + int((parts[1] if len(parts) == 2 else '').ljust(2, '0'))
    if cents > 999999999999:
        raise ValueError('amount limit')
    return ('-' if negative and cents else '') + f'{cents // 100}.{cents % 100:02d}'


def semantic(payload: bytes, rules: dict[str, Any], generation: int = 2) -> dict[str, Any]:
    delimiter = rules['delimiter']
    locale = rules['amount_locale']
    date_style = rules['date_format']
    key_policy = rules['key_policy']
    if delimiter not in (',', ';') or locale not in ('dot', 'comma'):
        raise ValueError('unsupported rules')
    if date_style not in ('iso', 'dmy') or key_policy not in ('hold', 'latest'):
        raise ValueError('unsupported rules')
    if generation not in (0, 1, 2):
        raise ValueError('generation')
    if generation == 0 and (locale != 'dot' or date_style != 'iso' or key_policy != 'hold'):
        raise ValueError('unsupported generation')
    if generation == 1 and key_policy != 'hold':
        raise ValueError('unsupported generation')
    markers = rules['missing_markers']
    mapping = rules['category_map']
    if not isinstance(markers, list) or not all(isinstance(v, str) for v in markers):
        raise ValueError('missing markers')
    if not isinstance(mapping, dict) or not all(isinstance(k, str) and isinstance(v, str) for k, v in mapping.items()):
        raise ValueError('category map')
    missing = {normalized(v) for v in markers}
    if '' not in missing:
        raise ValueError('empty missing marker required')
    replacements: dict[str, str] = {}
    for original, replacement in mapping.items():
        original, replacement = normalized(original), normalized(replacement)
        if original in replacements and replacements[original] != replacement:
            raise ValueError('conflicting normalized category map')
        replacements[original] = replacement
    if len(payload) > 10 * 1024 * 1024:
        raise ValueError('source too large')
    parsed = list(csv.reader(io.StringIO(payload.decode('utf-8-sig'), newline=''), delimiter=delimiter, strict=True))
    if not parsed or tuple(parsed[0]) != FIELDS:
        raise ValueError('headings')
    raw_rows = parsed[1:]
    if len(raw_rows) > 50000:
        raise ValueError('too many records')
    if any(len(row) != 5 or any(len(value) > 256 for value in row) for row in raw_rows):
        raise ValueError('record shape')
    result: dict[str, Any] = {'clean': [], 'quarantine': [], 'duplicates': [], 'superseded': [], 'disposition': []}
    statuses: dict[int, str] = {}
    unique: dict[tuple[str, ...], int] = {}
    groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for source_row, row in enumerate(raw_rows, 1):
        values = dict(zip(FIELDS, [normalized(v) for v in row], strict=True))
        reasons: list[str] = []
        values['category'] = replacements.get(values['category'], values['category'])
        for field in FIELDS:
            if values[field] in missing:
                values[field] = ''
                if field != 'updated_at' or key_policy == 'latest':
                    reasons.append('MISSING_' + field.upper())
        for field, parser in (('date', lambda s: iso_day(s, date_style)),
                              ('amount', lambda s: money(s, locale)),
                              ('updated_at', lambda s: iso_day(s, 'iso'))):
            if values[field]:
                try:
                    values[field] = parser(values[field])
                except ValueError:
                    reasons.append('INVALID_' + field.upper())
        if reasons:
            result['quarantine'].append({'source_row': source_row, 'reasons': sorted(set(reasons))})
            statuses[source_row] = 'QUARANTINE'
            continue
        signature = tuple(values[field] for field in FIELDS)
        if signature in unique:
            result['duplicates'].append({'source_row': source_row, 'kept_source_row': unique[signature]})
            statuses[source_row] = 'DUPLICATE_EXACT'
        else:
            unique[signature] = source_row
            groups[values['record_id']].append(dict(values, source_row=source_row))
    for members in groups.values():
        winners = members if key_policy == 'hold' else [m for m in members if m['updated_at'] == max(v['updated_at'] for v in members)]
        if len(winners) > 1:
            reason = 'CONFLICTING_KEY' if key_policy == 'hold' else 'CONFLICTING_LATEST'
            for row in members:
                result['quarantine'].append({'source_row': row['source_row'], 'reasons': [reason]})
                statuses[row['source_row']] = 'QUARANTINE'
            continue
        winner = winners[0]
        result['clean'].append(winner)
        statuses[winner['source_row']] = 'CLEAN'
        for row in members:
            if row is not winner:
                result['superseded'].append({'source_row': row['source_row'], 'kept_source_row': winner['source_row']})
                statuses[row['source_row']] = 'SUPERSEDED'
    result['clean'].sort(key=lambda row: row['record_id'])
    for name in ('quarantine', 'duplicates', 'superseded'):
        result[name].sort(key=lambda row: row['source_row'])
    result['disposition'] = [{'source_row': i, 'status': statuses[i]} for i in range(1, len(raw_rows) + 1)]
    return result


def deliver(job: dict[str, Any], directory: Path, generation: int = 2) -> dict[str, Any]:
    if job.get('schema') != 'csv-clean-job/v1' or not isinstance(job.get('id'), str) or not job['id']:
        raise ValueError('job')
    if job.get('data_class') not in ('public', 'synthetic'):
        raise ValueError('data class')
    source = job['source']
    filename = source['file']
    if not isinstance(filename, str) or filename in ('', '.', '..') or Path(filename).name != filename or '\\' in filename:
        raise ValueError('local basename required')
    path = directory / filename
    if path.is_symlink():
        raise ValueError('symlink source')
    payload = path.read_bytes()
    if hashlib.sha256(payload).hexdigest() != source['sha256']:
        raise ValueError('source digest')
    return semantic(payload, job['rules'], generation)
