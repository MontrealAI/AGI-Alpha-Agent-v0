import argparse
import hashlib
import importlib.util
import json
import random
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BASE_GENERATOR = ROOT / "acceptance" / "generate_fresh_jobs.py"
BASE_GENERATOR_SHA = "a4357e2a5484bbe3b6264031a8414898578aa10c16c0d6bb66da66c03fe7487e"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")


def main(seed, freeze_sha, out):
    if sha(BASE_GENERATOR) != BASE_GENERATOR_SHA:
        raise SystemExit("Frozen base generator identity changed")
    if (out / "inputs").exists() or (out / "private_keys").exists():
        raise SystemExit("Transfer inputs or answer keys already exist; replacement refused")
    spec = importlib.util.spec_from_file_location("frozen_latent_oracle", BASE_GENERATOR)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    rng = random.Random(seed)
    public = []
    seals = []
    for case_class in ("simple", "locale", "versioned"):
        for ordinal in range(2):
            job_id = f"transfer-{case_class}-{ordinal + 1:02d}"
            rule_index = 3 if case_class == "versioned" and ordinal else ordinal
            rules = module.rules_for(case_class, rule_index)
            count = rng.randint(800, 1600)
            rows, semantic = module.build_case(random.Random(rng.getrandbits(128)), count, rules)
            source = module.encode(rows, rules, bool(ordinal))
            source_sha = hashlib.sha256(source).hexdigest()
            job = {"schema": "csv-clean-job/v1", "id": job_id, "data_class": "synthetic",
                   "source": {"file": job_id + ".csv", "sha256": source_sha}, "rules": rules}
            source_path = out / "inputs" / (job_id + ".csv")
            source_path.parent.mkdir(parents=True, exist_ok=True)
            source_path.write_bytes(source)
            job_path = out / "inputs" / (job_id + ".json")
            write(job_path, job)
            key = {"schema": "fresh-transfer-latent-oracle/v1", "job_id": job_id, "case_class": case_class,
                   "panel": "transfer", "source_record_count": count, "actual_source_sha256": source_sha,
                   "expected_status": {"2": "COMPLETED"}, "semantic": semantic}
            key_path = out / "private_keys" / (job_id + ".json")
            write(key_path, key)
            seals.append({"job_id": job_id, "sha256": sha(key_path)})
            public.append({"job_id": job_id, "case_class": case_class, "panel": "transfer",
                           "source_record_count": count, "job_file": str(job_path.relative_to(out)),
                           "job_sha256": sha(job_path), "source_file": str(source_path.relative_to(out)), "source_sha256": source_sha})
    write(out / "inputs_manifest.json", {"schema": "fresh-transfer-inputs/v1", "transfer_freeze_sha256": freeze_sha, "records": public})
    write(out / "key_seals.json", {"schema": "fresh-transfer-key-seals/v1", "keys": seals})
    write(out / "private_keys" / "generation_receipt.json", {"seed": seed, "transfer_freeze_sha256": freeze_sha,
          "generated_at_utc": datetime.now(timezone.utc).isoformat(), "wrapper_sha256": sha(Path(__file__)),
          "base_generator_sha256": BASE_GENERATOR_SHA, "contract_sha256": sha(ROOT / "protocol" / "DELIVERY_CONTRACT.md")})
    print(json.dumps({"jobs": 6, "inputs_manifest_sha256": sha(out / "inputs_manifest.json"), "key_seals_sha256": sha(out / "key_seals.json")}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--seed", required=True)
    parser.add_argument("--freeze-sha256", required=True)
    parser.add_argument("--out", type=Path, default=Path(__file__).parent)
    args = parser.parse_args()
    if len(args.freeze_sha256) != 64:
        parser.error("Exact transfer-freeze SHA-256 required")
    main(args.seed, args.freeze_sha256, args.out)
