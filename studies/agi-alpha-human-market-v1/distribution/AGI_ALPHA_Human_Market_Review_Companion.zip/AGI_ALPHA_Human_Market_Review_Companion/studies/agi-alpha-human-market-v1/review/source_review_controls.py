# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import hashlib
import json
import sys
import time
from pathlib import Path
from types import SimpleNamespace
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
import cleaner
import recipient_controls as controls


def job_for(raw: bytes, rules: dict[str, Any]) -> dict[str, Any]:
    return {'schema':'csv-clean-job/v1','id':'source-review','data_class':'synthetic',
            'source':{'file':'input.csv','sha256':hashlib.sha256(raw).hexdigest()},'rules':rules}


def semantic(raw: bytes, rules: dict[str, Any], generation: int = 2) -> dict[str, Any]:
    return cleaner.clean(job_for(raw,rules),raw,generation)


def direct_deliver(job: dict[str, Any], directory: Path, generation: int = 2) -> dict[str, Any]:
    return cleaner.clean(job,(directory/job['source']['file']).read_bytes(),generation)


def exact_headings() -> None:
    raw=b'record_id, category,date,amount,updated_at\na,x,2024-01-01,1,\n'
    controls.must_refuse(lambda: semantic(raw,controls.BASE))


def ascii_date() -> None:
    raw='record_id,category,date,amount,updated_at\na,x,２０２４-０１-０１,1,\n'.encode()
    result=semantic(raw,controls.BASE)
    assert result['quarantine']==[{'source_row':1,'reasons':['INVALID_DATE']}]


def main() -> None:
    controls.recipient=SimpleNamespace(FIELDS=cleaner.FIELDS,semantic=semantic,iso_day=cleaner.date_value,
                                      money=cleaner.amount_value,deliver=direct_deliver)
    records=[]
    for fn in (controls.normalization,controls.validation,controls.money_boundaries,controls.calendar_boundaries,
               controls.hold_conflicts,controls.latest_reconciliation,controls.category_mapping_then_missing,
               controls.quoted_record_numbers,controls.format_refusals,exact_headings,ascii_date):
        start=time.perf_counter_ns()
        try:
            fn()
            records.append({'name':fn.__name__,'pass':True,'wall_ns':time.perf_counter_ns()-start})
        except Exception as error:
            records.append({'name':fn.__name__,'pass':False,'error':repr(error),
                            'wall_ns':time.perf_counter_ns()-start})
    paths=[ROOT/'protocol/DELIVERY_CONTRACT.md',*(ROOT/'src').glob('*.py'),*(ROOT/'src').glob('*.mjs')]
    result={'schema':'source-review-controls/v1','primary_observation':False,
            'controls':records,'pass':all(item['pass'] for item in records),
            'source_hashes':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}}
    target=ROOT/'review'/('source_review_'+(sys.argv[1] if len(sys.argv)>1 else 'before')+'.json')
    if target.exists():
        raise SystemExit('preserving existing review receipt; use a distinct label')
    target.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    main()
