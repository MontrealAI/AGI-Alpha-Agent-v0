// SPDX-License-Identifier: Apache-2.0
// Separate development receipt after the explicit provider-onboarding correction.
import assert from 'node:assert/strict';
import {readFile, writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {fixture} from '../economics/development-fixture.mjs';
import {simulateHumanMarket} from '../economics/human-market.mjs';
const config = fixture();
Object.assign(config, {id: 'INDEPENDENT_ONBOARDING_ARITHMETIC', weeks: 2, buyers: 1,
  arrivalProbability: 1, initialCashCents: 100000, reserveCents: 100,
  initialSetupCents: 100, historicalResearchCents: 200, weeklyOverheadCents: 10,
  opportunityScreeningCents: 2, opportunityAcquisitionCents: 20, providerOnboardingCents: 100,
  paymentDelayWeeks: 0, paymentProbability: 1, expenseDelayWeeks: 0,
  refundDelayWeeks: 1, refundProbability: 0, discountBps: 1000,
  paymentFeeBps: 1000, fiscalReserveBps: 2000});
config.classes = [{id: 'simple', weight: 1, humanReferenceCents: 10000,
  priceEvidenceReference: 'Independent arithmetic control, not market evidence'}];
config.profiles.forEach(p => {p.classes = {simple: p.classes.simple};});
const result = simulateHumanMarket(config, 990002, {maximumInvestments: 0});
// The preceding independent control costs $25.64. One $1 provider onboarding
// increases costs to $26.64, despite two accepted jobs from the same buyer.
assert.equal(result.summary.attempts, 2);
assert.equal(result.summary.accepted, 2);
assert.equal(result.summary.grossCollectionsCents, 18000);
assert.equal(result.summary.accruedCostsCents, 2664);
assert.equal(result.summary.fullProjectProfitCents, 15336);
assert.equal(result.summary.finalCashCents, 115336);
assert.equal(result.summary.fiscalReserveCents, 3107);
assert.equal(result.summary.operatingGeneratedAvailableCents, 12429);
assert.equal(result.actualCustomerCollectionsCents, 0);
const onboard = result.histories.bills.filter(b => b.reference.startsWith('provider-onboarding:'));
assert.equal(onboard.length, 1);
assert.equal(onboard[0].amountCents, 100);
const receipt = {schema: 'independent-onboarding-arithmetic-review/v1', primaryObservation: false,
  status: 'PASS', seed: 990002, expectedCostsCents: 2664, expectedProfitCents: 15336,
  expectedFiscalReserveCents: 3107, expectedGeneratedAvailableCents: 12429,
  onboardingBills: onboard, observedSummary: result.summary, actualCustomerCollectionsCents: 0,
  humanMarketSHA256: createHash('sha256').update(await readFile(new URL('../economics/human-market.mjs', import.meta.url))).digest('hex'),
  limitation: 'One independent arithmetic control, not a primary market world or demand evidence.'};
await writeFile(new URL('./economic_onboarding_control.json', import.meta.url),
  JSON.stringify(receipt, null, 2) + '\n', {flag: 'wx'});
console.log(JSON.stringify({status: receipt.status, expectedCostsCents: 2664,
  expectedGeneratedAvailableCents: 12429, humanMarketSHA256: receipt.humanMarketSHA256}));
