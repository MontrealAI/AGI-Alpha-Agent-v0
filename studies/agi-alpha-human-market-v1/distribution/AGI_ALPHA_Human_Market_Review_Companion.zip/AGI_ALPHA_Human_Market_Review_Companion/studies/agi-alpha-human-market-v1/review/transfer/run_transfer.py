# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import argparse
import hashlib
import json
import resource
import subprocess
import sys
import time
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
WORKSPACE = ROOT.parents[1]


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def dump(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--freeze", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    args.manifest, args.freeze, args.out = args.manifest.resolve(), args.freeze.resolve(), args.out.resolve()
    if args.out.exists():
        raise SystemExit("OUTPUT_EXISTS; preserve earlier attempts")
    manifest, freeze = json.loads(args.manifest.read_text()), json.loads(args.freeze.read_text())
    input_records = manifest["records"]
    if len(input_records) != 6 or Counter(r["case_class"] for r in input_records) != {"simple": 2, "locale": 2, "versioned": 2}:
        raise SystemExit("EXPECTED_SIX_BALANCED_FRESH_CASES")
    if len({r["job_id"] for r in input_records}) != 6:
        raise SystemExit("DUPLICATE_JOB_ID")
    manifest_hash, freeze_hash = sha(args.manifest), sha(args.freeze)

    def check_integrity() -> None:
        if sha(args.manifest) != manifest_hash or sha(args.freeze) != freeze_hash:
            raise RuntimeError("MANIFEST_DRIFT")
        for item in freeze["files"]:
            if sha(WORKSPACE / item["path"]) != item["sha256"]:
                raise RuntimeError("FROZEN_SOURCE_DRIFT:" + item["path"])
        for record in input_records:
            job_path, source_path = args.manifest.parent / record["job_file"], args.manifest.parent / record["source_file"]
            if sha(job_path) != record["job_sha256"] or sha(source_path) != record["source_sha256"]:
                raise RuntimeError("FRESH_INPUT_DRIFT:" + record["job_id"])
            job = json.loads(job_path.read_text())
            if job["id"] != record["job_id"] or job["source"]["sha256"] != record["source_sha256"]:
                raise RuntimeError("JOB_IDENTITY_MISMATCH")
            if (job_path.parent / job["source"]["file"]).resolve() != source_path.resolve():
                raise RuntimeError("JOB_SOURCE_PATH_MISMATCH")

    check_integrity()
    args.out.mkdir(parents=True)
    start = time.perf_counter()
    records, failures = [], []
    for index, item in enumerate(sorted(input_records, key=lambda r: r["job_id"])):
        job_path = (args.manifest.parent / item["job_file"]).resolve()
        order = ["recipient", "donor_g2"] if index % 2 == 0 else ["donor_g2", "recipient"]
        for method in order:
            try:
                check_integrity()
                if time.perf_counter() - start > 600:
                    raise RuntimeError("DECLARED_TRANSFER_WALL_BUDGET_EXCEEDED")
            except Exception as exc:
                failures.append({"job_id": item["job_id"], "method": method, "stage": "before", "reason": repr(exc)})
                break
            output = args.out / item["job_id"] / method
            if method == "recipient":
                command = [sys.executable, "-B", str(ROOT / "review/transfer/recipient_worker.py"), "--job", str(job_path), "--out", str(output)]
            else:
                command = [sys.executable, "-B", str(ROOT / "src/deliver.py"), "--job", str(job_path), "--generation", "2", "--out", str(output)]
            before = resource.getrusage(resource.RUSAGE_CHILDREN)
            attempt_start = time.perf_counter()
            try:
                process = subprocess.run(command, capture_output=True, text=True, timeout=90, check=False)
                stdout, stderr, code = process.stdout, process.stderr, process.returncode
            except subprocess.TimeoutExpired as exc:
                stdout = exc.stdout.decode(errors="replace") if isinstance(exc.stdout, bytes) else (exc.stdout or "")
                stderr = exc.stderr.decode(errors="replace") if isinstance(exc.stderr, bytes) else (exc.stderr or "")
                stderr += "\nTRANSFER_TIMEOUT; no retry\n"
                code = 124
            elapsed = time.perf_counter() - attempt_start
            after = resource.getrusage(resource.RUSAGE_CHILDREN)
            output.mkdir(parents=True, exist_ok=True)
            (output / "process.stdout").write_text(stdout)
            (output / "process.stderr").write_text(stderr)
            summary_path, semantic_path = output / "summary.json", output / "semantic.json"
            summary = json.loads(summary_path.read_text()) if summary_path.exists() else {"status": "FAILED"}
            status = summary.get("status", "FAILED") if code == 0 else "FAILED"
            record = {"job_id": item["job_id"], "case_class": item["case_class"], "method": method,
                      "status": status, "generation": 2, "source_sha256": item["source_sha256"],
                      "semantic_path": str(semantic_path.relative_to(ROOT)) if semantic_path.exists() else None,
                      "semantic_sha256": sha(semantic_path) if semantic_path.exists() else None,
                      "output_dir": str(output.relative_to(ROOT)), "route_summary": summary,
                      "process_exit_code": code, "subprocess_wall_seconds": elapsed,
                      "subprocess_cpu_seconds": after.ru_utime + after.ru_stime - before.ru_utime - before.ru_stime,
                      "attempt_number": 1, "timing_comparison_permitted": False}
            records.append(record)
            dump(args.out / "attempts-checkpoint.json", records)
            try:
                check_integrity()
            except Exception as exc:
                failures.append({"job_id": item["job_id"], "method": method, "stage": "after", "reason": repr(exc)})
                break
        if failures:
            break
    prediction = {"schema": "independent-transfer-predictions/v1", "status": "PREDICTIONS_SEALED_BEFORE_ORACLE",
                  "all_planned_executions_recorded": len(records) == 12 and not failures,
                  "source_freeze_sha256": freeze_hash, "input_manifest_sha256": manifest_hash,
                  "actual_customer_collections_usd": 0, "complete_monetary_cost": None,
                  "wall_seconds": time.perf_counter() - start, "records": records, "failures": failures,
                  "timing_interpretation": "Different route workloads; no speed comparison or ratio."}
    dump(args.out / "index.json", prediction)
    dump(args.out / "prediction-seal.json", {"schema": "independent-transfer-seal/v1",
         "index_sha256": sha(args.out / "index.json"), "records": len(records),
         "source_freeze_sha256": freeze_hash, "input_manifest_sha256": manifest_hash})
    print(json.dumps({"records": len(records), "failures": failures,
                      "index_sha256": sha(args.out / "index.json"), "wall_seconds": prediction["wall_seconds"]}))


if __name__ == "__main__":
    main()
