// SPDX-License-Identifier: Apache-2.0
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const root=__dirname,html=fs.readFileSync(path.join(root,'AGI_ALPHA_Human_Market_Demonstration.html'),'utf8');
const json=html.match(/<script id="evidence-data" type="application\/json">([\s\S]*?)<\/script>/)[1];
const script=html.match(/<script id="app-script">([\s\S]*?)<\/script>/)[1];
const elements={app:{innerHTML:''},'evidence-data':{textContent:json},'download-status':{textContent:''}};
const listeners={},downloads=[];
const document={activeElement:null,documentElement:{dataset:{}},body:{appendChild(){}},
 getElementById:id=>elements[id]||null,addEventListener:(name,fn)=>listeners[name]=fn,
 createElement:()=>({click(){downloads.push(this.download)},remove(){}})};
const context={document,window:{matchMedia:()=>({matches:false})},Intl,JSON,Math,Number,String,Object,Array,Error,Uint8Array,
 Blob,URL:{createObjectURL:()=> 'blob:test',revokeObjectURL(){}},atob:s=>Buffer.from(s,'base64').toString('binary'),setTimeout:fn=>fn()};
vm.createContext(context);vm.runInContext(script,context,{timeout:15000});
const app=context.window.EvidenceApp,data=app.getData(),translation=app.getTranslations();
assert.equal(Object.keys(data.cells).length,351);assert.equal(data.actualCollectionsCents,0);assert.equal(data.actualCompleteCost,null);
assert.deepEqual(Object.keys(translation.en).sort(),Object.keys(translation.fr).sort());
assert.deepEqual(Object.keys(translation.en.conditions).sort(),Object.keys(translation.fr.conditions).sort());
let states=0,zeroLowStates=0;
for(const lang of ['en','fr'])for(const price of ['2000','2500','9900'])for(const discount of ['500','1000','1500'])for(const cost of ['low','base','high'])for(const condition of data.design.primaryConditions.map(x=>x.id)){
 app.setState({lang,price,discount,cost,condition});const m=app.getModel();
 assert.equal(m.cell.scenario,`p${price}-d${discount}-${cost}-${condition}`);
 assert.equal(m.cell.seeds.length,8);assert.equal(document.documentElement.lang,lang);
 assert.ok(elements.app.innerHTML.includes(m.cell.scenario));
 assert.ok(elements.app.innerHTML.includes(translation[lang].actualHero));
 assert.ok(elements.app.innerHTML.includes(translation[lang].cellDescription));
 assert.ok(!elements.app.innerHTML.includes('undefined'));assert.ok(!elements.app.innerHTML.includes('NaN'));
 assert.equal(m.cycleCount,m.cell.seeds.filter(s=>s.cycle.fullCycleWithinModel).length);
 if(price!=='9900'){assert.ok(m.allZero);assert.equal(m.cycleCount,0);zeroLowStates++;}
 states++;
}
assert.equal(states,702);
for(const theme of ['dark','light']){app.setState({theme});assert.equal(document.documentElement.dataset.theme,theme);}
for(const lang of ['en','fr'])for(const file of Object.keys(data.packet.previews)){
 app.setState({lang,file});assert.ok(elements.app.innerHTML.includes(data.packet.assets[file].sha256));
 assert.ok(elements.app.innerHTML.includes(translation[lang].downloadFile));
}
let ledgerStates=0;
for(const lang of ['en','fr'])for(let ledgerPolicy=0;ledgerPolicy<3;ledgerPolicy++)for(let week=0;week<data.example.runs[ledgerPolicy].balances.length;week++){
 app.setState({lang,ledgerPolicy,week});assert.ok(!elements.app.innerHTML.includes('NaN'));ledgerStates++;
}
let embeddedAssets=0;
for(const [name,asset]of Object.entries(data.packet.assets)){
 const raw=Buffer.from(asset.base64,'base64');assert.equal(raw.length,asset.bytes);
 assert.equal(crypto.createHash('sha256').update(raw).digest('hex'),asset.sha256);
 app.downloadAsset(name);assert.equal(downloads.at(-1),asset.name);embeddedAssets++;
}
const freeze=JSON.parse(fs.readFileSync(path.join(root,'../protocol/economics-primary/campaign-primary.json'),'utf8'));
const summary=JSON.parse(fs.readFileSync(path.join(root,'../results/economics-primary-01/summary.json'),'utf8'));
const groups=new Map(summary.groups.map(x=>[x.scenarioId,x]));
for(const [id,cell]of Object.entries(data.cells))for(const seed of cell.seeds){
 const original=groups.get(id).seeds.find(x=>x.seed===seed.seed);assert.ok(original);
 for(let p=0;p<3;p++)for(const [key,value]of Object.entries(seed.summaries[p]))assert.equal(value,original.summaries[p][key]);
 for(const [key,value]of Object.entries(seed.cycle))assert.equal(value,original.connectedCycle[key]);
 const config=freeze.scenarios.find(x=>x.id===id);assert.equal(cell.offeredPriceCents,Math.round(config.classes[0].humanReferenceCents*(1-config.discountBps/10000)));
}
for(const source of data.sources){const raw=fs.readFileSync(path.join(root,'..',source.path));assert.equal(crypto.createHash('sha256').update(raw).digest('hex'),source.sha256);}
const example=data.example,final=example.runs[2].summary;
assert.equal(example.id,'p9900-d1000-base-base');assert.equal(example.seed,26001);
assert.equal(final.grossCollectionsCents,516780);assert.equal(final.accruedCostsCents,336401);
assert.equal(final.fullProjectProfitCents,180379);assert.equal(final.operatingGeneratedAvailableCents,220303);
assert.equal(example.runs[2].config.initialCashCents+final.grossCollectionsCents-final.paidCostsCents,final.finalCashCents);
assert.equal(Object.values(example.reconciliation[2].costBreakdownCents).reduce((a,b)=>a+b,0),final.accruedCostsCents);
assert.ok(!/<script\b[^>]*\bsrc=|<link\b[^>]*\brel=["']stylesheet/i.test(html));
assert.ok(!/\bfetch\s*\(|XMLHttpRequest|WebSocket|eval\s*\(/.test(script));
assert.ok(html.includes('AGI_ALPHA_Human_Market_Advantage.pdf'));
let embeddedFinalPDF=false;
if(fs.existsSync(path.join(root,'paper-identity.json'))){
 const identity=JSON.parse(fs.readFileSync(path.join(root,'paper-identity.json'),'utf8'));
 const pdf=data.packet.assets['paper.pdf'];assert.ok(pdf);
 assert.equal(pdf.sha256,identity.sha256);assert.equal(pdf.mime,'application/pdf');
 assert.ok(Buffer.from(pdf.base64,'base64').subarray(0,5).equals(Buffer.from('%PDF-')));
 assert.ok(!html.includes('href="../paper/'));
 embeddedFinalPDF=true;
}
assert.ok(html.includes('@media(max-width:560px)'));assert.ok(html.includes('prefers-reduced-motion'));
const receipt={schema:'offline-demo-vm-verification/v1',status:'PASS',languageScenarioStates:states,zeroLowPriceLanguageStates:zeroLowStates,
 ledgerLanguageStates:ledgerStates,languageKeyParity:true,embeddedAssetsVerified:embeddedAssets,allSeedValuesMatchFrozenSummary:true,
 allSourceDigestsReconciled:true,preselectedCashArithmeticReconciled:true,newForecastsExecuted:false,actualCollectionsCents:0,
 downloadHandlersExercised:downloads.length,networkAPIReferences:0,limitation:'VM checks behavior, data integrity and localization, not browser layout. See separate one-attempt browser record.',
 embeddedFinalPDF,
 htmlSHA256:crypto.createHash('sha256').update(html).digest('hex')};
fs.writeFileSync(path.join(root,'vm-verification.json'),JSON.stringify(receipt,null,2)+'\n');console.log(JSON.stringify(receipt,null,2));
