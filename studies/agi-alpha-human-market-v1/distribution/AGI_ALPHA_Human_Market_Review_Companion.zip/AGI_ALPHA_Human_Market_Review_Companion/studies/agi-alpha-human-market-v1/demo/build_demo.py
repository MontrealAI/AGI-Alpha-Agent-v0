# SPDX-License-Identifier: Apache-2.0
"""Package frozen observations into an offline bilingual evidence document."""
from __future__ import annotations
import base64,csv,hashlib,io,json,zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
OUT=Path(__file__).resolve().parent
def read(name): return json.loads((ROOT/name).read_text())
def sha(raw): return hashlib.sha256(raw).hexdigest()
def embedded(name,raw,mime): return {'name':name,'base64':base64.b64encode(raw).decode(),'sha256':sha(raw),'bytes':len(raw),'mime':mime}

summary=read('results/economics-primary-01/summary.json')
aggregation=read('analysis/primary-final/aggregation.json')
protocol=read('protocol/economics-primary/campaign-primary.json')
configs={c['id']:c for c in protocol['scenarios']}
groups={g['scenarioId']:g for g in summary['groups']}
assert len(groups)==351 and summary['actualCollectionsCents']==0
fields=['accepted','attempts','rejected','grossCollectionsCents','accruedCostsCents','fullProjectProfitCents',
        'operatingGeneratedAvailableCents','investmentCount','totalProtectedReservesCents','insolvent',
        'perAcceptedRecurringCents','perAcceptedFullyAllocatedCents','finalCashCents','obligationsCents',
        'fullProjectCostRecovered','nominalCustomerSavingsCents']
cells={}
for c in aggregation['cells']:
 config=configs[c['scenario']]; seeds=groups[c['scenario']]['seeds'];assert len(seeds)==8
 selected={k:c[k] for k in ['scenario','priceCents','discountBps','costSchedule','condition']}
 selected['offeredPriceCents']=round(c['priceCents']*(1-c['discountBps']/10000))
 selected['customerSavingsCents']=c['priceCents']-selected['offeredPriceCents']
 selected['metrics']={'full_cycles':c['metrics']['full_cycles']}
 for policy in ['policy_0','policy_1','policy_2']:
  selected['metrics'][policy]={key:{stat:c['metrics'][policy][key][stat] for stat in ['n','median','minimum','maximum']}
    for key in ['accepted','fullProjectProfitCents','operatingGeneratedAvailableCents','perAcceptedFullyAllocatedCents']}
 selected['seeds']=[{'seed':s['seed'],'summaries':[{k:p[k] for k in fields} for p in s['summaries']],
                     'cycle':s['connectedCycle']} for s in seeds]
 selected['assumptions']={k:config[k] for k in ['arrivalProbability','buyerIntegrationCents','providerOnboardingCents',
   'opportunityAcquisitionCents','enterprisePerceivedQuality','fieldReliabilityMultiplier','paymentDelayWeeks',
   'refundProbability','paymentFeeBps','fiscalReserveBps','initialSetupCents','historicalResearchCents','weeklyOverheadCents']}
 selected['capability']=config['capabilities'][0]
 cells[c['scenario']]=selected
assert {c['condition'] for c in cells.values()}=={c['id'] for c in read('protocol/economics-primary/design-summary.json')['primaryConditions']}

packet=ROOT/'results/primary/main-versioned-01/G2'
manifest=json.loads((packet/'delivery-manifest.json').read_text())
assert manifest['job_id']=='main-versioned-01'
file_names=[x['name'] for x in manifest['files']]+['delivery-manifest.json','workbench-pack.json','ti-summary.json','summary.json']
assets={};previews={};zip_buffer=io.BytesIO()
with zipfile.ZipFile(zip_buffer,'w',zipfile.ZIP_DEFLATED) as z:
 for name in sorted(set(file_names)):
  raw=(packet/name).read_bytes();mime='application/json' if name.endswith('.json') else 'text/csv' if name.endswith('.csv') else 'text/plain'
  assets[name]=embedded(name,raw,mime)
  entry=zipfile.ZipInfo('main-versioned-01-G2/'+name,date_time=(2026,10,26,0,0,0))
  entry.compress_type=zipfile.ZIP_DEFLATED
  z.writestr(entry,raw)
  if name.endswith('.csv'):
   rows=list(csv.reader(io.StringIO(raw.decode('utf-8-sig'),newline=''),delimiter=';' if name=='original.csv' and read('results/primary/main-versioned-01/G2/job.json')['rules']['delimiter']==';' else ','))
   previews[name]={'headings':rows[0],'rows':rows[1:7],'total':len(rows)-1}
assets['complete-packet.zip']=embedded('main-versioned-01-G2.zip',zip_buffer.getvalue(),'application/zip')
assert assets['original.csv']['sha256']==manifest['source']['sha256']
for f in manifest['files']:assert assets[f['name']]['sha256']==f['sha256']
example_raw=(ROOT/'analysis/primary-final/preselected-world.json').read_bytes();example=json.loads(example_raw)
world=example['world'];assert world['seed']==26001 and world['configId']=='p9900-d1000-base-base'
assets['finance-world.json']=embedded('preselected-finance-world.json',example_raw,'application/json')
paper_identity_path=OUT/'paper-identity.json'
paper_identity=json.loads(paper_identity_path.read_text()) if paper_identity_path.exists() else None
if paper_identity:
 paper_raw=(ROOT/paper_identity['source_path']).read_bytes()
 assert sha(paper_raw)==paper_identity['sha256'], 'Confirmed final PDF identity changed'
 assert paper_raw.startswith(b'%PDF-'), 'Expected a PDF artifact'
 assets['paper.pdf']=embedded('AGI_ALPHA_Human_Market_Advantage.pdf',paper_raw,'application/pdf')
selection=read('analysis/display-case-selection.json')
source_paths=['results/economics-primary-01/summary.json','results/economics-primary-01/completion.json',
 'analysis/primary-final/aggregation.json','analysis/primary-final/preselected-world.json','analysis/display-case-selection.json',
 'protocol/economics-primary/campaign-primary.json','protocol/economics-primary/design-summary.json',
 'protocol/PRICING_METHODOLOGY.json','economics/cost-schedules.json','evidence/production-profiles.json',
 'results/primary/acceptance.json','review/transfer/comparison.json','results/primary/main-versioned-01/G2/delivery-manifest.json']
sources=[{'path':p,'sha256':sha((ROOT/p).read_bytes()),'bytes':(ROOT/p).stat().st_size} for p in source_paths]
if paper_identity:
 sources.append({'path':paper_identity['source_path'],'sha256':paper_identity['sha256'],'bytes':len(paper_raw)})
data={'schema':'human-market-offline-evidence/v1','asOf':'2026-10-26','actualCollectionsCents':0,'actualCompleteCost':None,
 'cells':cells,'overall':{k:v for k,v in aggregation['overall'].items() if not isinstance(v,dict)},
 'design':read('protocol/economics-primary/design-summary.json'),'pricing':read('protocol/PRICING_METHODOLOGY.json'),
 'costs':read('economics/cost-schedules.json'),'production':read('results/primary/acceptance.json'),
 'profiles':read('evidence/production-profiles.json'),'transfer':read('review/transfer/comparison.json'),
 'packet':{'id':manifest['job_id'],'counts':manifest['counts'],'source':manifest['source'],
           'sourceCodeSHA256':manifest['source_code_sha256'],'previews':previews,'assets':assets},
 'example':{'selection':selection,'id':world['configId'],'seed':world['seed'],'cycle':world['connectedCycle'],
   'comparisons':world['comparisons'],'runs':[{'summary':r['summary'],'balances':r['histories']['balances'],
   'investments':r['histories']['investments'],'config':{k:r['config'][k] for k in ['initialCashCents','reserveCents','historicalResearchCents','initialSetupCents']}}
     for r in world['runs']],'reconciliation':example['implementerReconciliation']},'sources':sources}
encoded=json.dumps(data,ensure_ascii=False,separators=(',',':')).replace('<','\\u003c')
template=(OUT/'template.html').read_text()
assert template.count('__EVIDENCE_DATA__')==1
html=template.replace('__EVIDENCE_DATA__',encoded)
target=OUT/'AGI_ALPHA_Human_Market_Demonstration.html';target.write_text(html)
(OUT/'build-receipt.json').write_text(json.dumps({'schema':'offline-demo-build/v1','html':target.name,'sha256':sha(target.read_bytes()),
 'bytes':target.stat().st_size,'sourceInputs':sources,'scenarioCount':len(cells),'seedWorlds':sum(len(c['seeds']) for c in cells.values()),
 'languages':['en','fr'],'new_simulation_executed':False,'selected_packet':str(packet.relative_to(ROOT)),
 'packet_assets':len(assets),'embedded_final_pdf':paper_identity,
 'all_manifest_file_hashes_reconciled':True,'actual_collections_cents':0},indent=2)+'\n')
print(json.dumps({'html':str(target),'bytes':target.stat().st_size,'cells':len(cells),'packet_assets':len(assets)}))
