// SPDX-License-Identifier: Apache-2.0
// One authorized browser launch attempt. On restriction/failure, preserve raw
// output and use the independent VM tests; do not retry or change sandbox flags.
const fs=require('node:fs');
const path=require('node:path');
const {pathToFileURL}=require('node:url');
const root=__dirname;
(async()=>{
 const record={schema:'offline-demo-browser-check/v1',launchAttempts:1};
 const target=path.join(root,'browser-check.json');
 if(fs.existsSync(target))throw Error('Preserve existing browser attempt; no retry');
 let browser;
 try{
  const {chromium}=require(path.join(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES,'playwright'));
  browser=await chromium.launch({headless:true});
  const page=await browser.newPage({viewport:{width:1365,height:940}});
  const errors=[],external=[];
  page.on('pageerror',e=>errors.push(String(e)));
  page.on('request',r=>{if(/^https?:/.test(r.url()))external.push(r.url())});
  await page.goto(pathToFileURL(path.join(root,'AGI_ALPHA_Human_Market_Demonstration.html')).href);
  await page.screenshot({path:path.join(root,'desktop-en.png')});
  await page.locator('#economics').scrollIntoViewIfNeeded();
  await page.screenshot({path:path.join(root,'economics-en.png')});
  await page.locator('[data-action="lang"][data-value="fr"]').click();
  await page.setViewportSize({width:390,height:844});
  await page.locator('#delivery').scrollIntoViewIfNeeded();
  await page.screenshot({path:path.join(root,'mobile-fr.png')});
  await page.locator('[data-action="theme"]').click();
  await page.locator('#economics').scrollIntoViewIfNeeded();
  await page.screenshot({path:path.join(root,'mobile-economics-fr.png')});
  const horizontalOverflow=await page.evaluate(()=>document.documentElement.scrollWidth>window.innerWidth);
  Object.assign(record,{status:errors.length||external.length||horizontalOverflow?'CHECK_FAILED':'PASS',
   pageErrors:errors,externalRequests:external,horizontalOverflow,screenshots:['desktop-en.png','economics-en.png','mobile-fr.png','mobile-economics-fr.png']});
 }catch(error){
  fs.writeFileSync(path.join(root,'browser-error.txt'),error.stack||String(error));
  Object.assign(record,{status:'BROWSER_UNAVAILABLE',rawError:'browser-error.txt',noRetryOrWorkaround:true});
 }finally{if(browser)await browser.close();fs.writeFileSync(target,JSON.stringify(record,null,2)+'\n');console.log(JSON.stringify(record));}
})().catch(e=>{console.error(e);process.exitCode=1});
