CSV cleanup and reconciliation

Import clean.csv using explicit text types for identifiers.
Use exceptions.csv to resolve missing, invalid or conflicting source records.
Use disposition.csv to trace every original record. Original bytes are retained.
No missing value was guessed. Formula-like cells are inert CSV text; do not execute them.
For one scoped revision, change explicit rules in job.json and rerun deliver.py with a new output
directory and --revision-of set to this delivery's manifest digest. Retain both deliveries.
Synthetic study output: factual acceptance and actual commercial activity are separate.
