// SPDX-License-Identifier: Apache-2.0
import assert from 'node:assert/strict';
import test from 'node:test';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {fixture} from './development-fixture.mjs';
import {simulateHumanMarket, pairedHumanMarket, validateHumanConfig} from './human-market.mjs';

test('Exact original cash source is preserved and interface is append-only', async () => {
  const meta = JSON.parse(await readFile(new URL('./core-transformation.json', import.meta.url)));
  const original = await readFile(new URL('./upstream/market/upstream/src/market.mjs', import.meta.url), 'utf8');
  const derived = await readFile(new URL('./upstream/market/upstream/src/cash-core.mjs', import.meta.url), 'utf8');
  const sha = value => createHash('sha256').update(value).digest('hex');
  assert.equal(sha(original), meta.sourceSHA256); assert.equal(sha(derived), meta.outputSHA256);
  assert.equal(derived, original + meta.appendedText);
});
test('Unknown costs are rejected rather than converted to zero', () => {
  const c = fixture(); c.profiles[0].classes.simple.deliveryCostCents = null;
  assert.throws(() => validateHumanConfig(c), /Explicit bounded integer/);
});
test('Only human, enterprise and defer are buyer options', () => {
  const r = simulateHumanMarket(fixture(), 123);
  assert.ok(r.histories.choices.every(c => ['enterprise', 'human', 'defer'].includes(c.choice)));
  assert.ok(r.histories.choices.flatMap(c => c.offers).every(o => ['enterprise', 'human'].includes(o.id)));
  assert.equal(r.actualCustomerCollectionsCents, 0);
});
test('Zero demand has no collections or operating financed investment', () => {
  const c = fixture(); c.arrivalProbability = 0;
  const r = simulateHumanMarket(c, 123);
  assert.equal(r.summary.grossCollectionsCents, 0); assert.equal(r.summary.investmentCount, 0);
  assert.equal(r.summary.perAcceptedRecurringCents, null); assert.equal(r.summary.operatingGeneratedAvailableCents, 0);
  assert.equal(r.summary.fullProjectProfitCents, -c.initialSetupCents - c.historicalResearchCents - c.weeks * c.weeklyOverheadCents);
});
test('Seed abundance cannot substitute for operating surplus', () => {
  const c = fixture(); c.initialCashCents = 100000000; c.paymentProbability = 0;
  const r = simulateHumanMarket(c, 123);
  assert.ok(r.summary.accepted > 0); assert.equal(r.summary.grossCollectionsCents, 0);
  assert.equal(r.summary.investmentCount, 0); assert.equal(r.summary.operatingGeneratedAvailableCents, 0);
});
test('Uncollected invoices cannot finance an investment', () => {
  const c = fixture(); c.paymentDelayWeeks = c.weeks + 1;
  const r = simulateHumanMarket(c, 123);
  assert.ok(r.summary.grossCollectionsCents > 0); assert.equal(r.summary.investmentCount, 0);
  assert.ok(r.histories.balances.filter(b => b.week < c.weeks).every(b => b.generatedAvailableCents === 0));
});
test('Buyer attention can eliminate the discounted offer', () => {
  const c = fixture(); c.profiles.forEach(p => Object.values(p.classes).forEach(v => {v.customerMinutes = 240;}));
  const r = simulateHumanMarket(c, 123);
  assert.equal(r.summary.attempts, 0); assert.equal(r.summary.investmentCount, 0); assert.ok(r.summary.humanChosen > 0);
});
test('Declined and unsupported prospects still incur explicit acquisition and screening cost', () => {
  const c = fixture(); c.opportunityAcquisitionCents = 300; c.opportunityScreeningCents = 2;
  c.profiles.forEach(p => Object.values(p.classes).forEach(v => {v.customerMinutes = 240;}));
  const r = simulateHumanMarket(c, 123);
  assert.equal(r.summary.attempts, 0);
  assert.equal(r.histories.bills.filter(b => b.reference.startsWith('opportunity-acquisition:')).length, c.buyers * c.weeks);
  assert.equal(r.summary.accruedCostsCents, c.initialSetupCents + c.historicalResearchCents + c.weeks * c.weeklyOverheadCents +
    c.buyers * c.weeks * (c.opportunityAcquisitionCents + c.opportunityScreeningCents));
});
test('Complete rejection produces costs but no invoice or collections', () => {
  const c = fixture(); c.fieldReliabilityMultiplier = 0;
  const r = simulateHumanMarket(c, 123);
  assert.ok(r.summary.rejected > 0); assert.equal(r.summary.accepted, 0); assert.equal(r.summary.grossInvoicesCents, 0);
  assert.equal(r.summary.grossCollectionsCents, 0); assert.equal(r.summary.investmentCount, 0);
  assert.ok(r.summary.accruedCostsCents > c.initialSetupCents + c.historicalResearchCents);
});
test('Measured-equivalent profiles receive no unearned investment benefit', () => {
  const c = fixture(); c.profiles.slice(1).forEach(p => {p.classes = structuredClone(c.profiles[0].classes);});
  const r = simulateHumanMarket(c, 123);
  assert.equal(r.summary.investmentCount, 0);
  assert.ok(r.histories.decisions.every(x => x.forecastBenefitCents === 0));
});
test('A complete synthetic two-investment loop is possible without seed financing', () => {
  const r = pairedHumanMarket(fixture(), 123);
  assert.equal(r.connectedCycle.fullCycleWithinModel, true);
  assert.equal(r.runs[2].summary.investmentCount, 2);
  assert.ok(r.runs[2].histories.investments.every(i => i.operatingGeneratedCents >= i.fullCostCents &&
    i.liquidAfterObligationsAndReserveCents >= i.fullCostCents));
  assert.ok(r.connectedCycle.firstRepaymentWeek !== null && r.connectedCycle.secondRepaymentWeek !== null);
  const firstUses = r.runs[1].histories.jobs.filter(j => j.accepted && j.classId === 'locale' && j.profileId === 'profile-1').length;
  const secondUses = r.runs[2].histories.jobs.filter(j => j.accepted && j.classId === 'versioned' && j.profileId === 'profile-2').length;
  assert.equal(r.connectedCycle.firstCapabilityAcceptedUses, firstUses);
  assert.equal(r.connectedCycle.secondCapabilityAcceptedUses, secondUses);
  assert.ok(r.connectedCycle.firstProfileTotalAcceptedUses > firstUses);
});
test('Known refund obligations accrue at collection and block reinvestment before refund payment', () => {
  const c = fixture(); c.refundProbability = 1; c.refundDelayWeeks = 8;
  const r = simulateHumanMarket(c, 678);
  assert.ok(r.histories.invoices.some(i => i.status === 'collected')); assert.equal(r.summary.investmentCount, 0);
  for (const invoice of r.histories.invoices.filter(i => i.status === 'collected')) {
    const bill = r.histories.bills.find(b => b.category === 'refund' && b.reference === invoice.id);
    assert.equal(bill.amountCents, invoice.amountCents); assert.equal(bill.week, invoice.collectedWeek);
    assert.equal(bill.dueWeek, invoice.collectedWeek + c.refundDelayWeeks);
  }
  assert.ok(r.histories.balances.some(b => b.obligationsCents > 0 && b.generatedAvailableCents === 0));
});
test('All histories reconcile cash, invoices, obligations and fiscal reserve', () => {
  const c = fixture(); c.paymentProbability = 0.8; c.refundProbability = 0.2; c.expenseDelayWeeks = 2;
  const r = simulateHumanMarket(c, 456);
  const paid = r.histories.bills.filter(b => b.paid).reduce((n, b) => n + b.amountCents, 0);
  const unpaid = r.histories.bills.filter(b => !b.paid).reduce((n, b) => n + b.amountCents, 0);
  const collected = r.histories.invoices.filter(i => i.status === 'collected').reduce((n, i) => n + i.amountCents, 0);
  assert.equal(r.summary.finalCashCents, c.initialCashCents + collected - paid);
  assert.equal(r.summary.obligationsCents, unpaid);
  assert.equal(r.summary.fullProjectProfitCents, r.summary.finalCashCents + r.summary.receivablesCents - unpaid - c.initialCashCents);
  assert.ok(r.histories.balances.every(b => b.cashCents >= 0));
  assert.ok(r.summary.fiscalReserveCents >= 0);
  assert.equal(r.canonical.cash.summary.scenario.reserve, c.reserveCents + r.summary.fiscalReserveCents);
});
test('Shared setup is charged once, and failure costs remain in accepted denominator', () => {
  const c = fixture(); c.fieldReliabilityMultiplier = 0.5;
  const r = simulateHumanMarket(c, 789, {maximumInvestments: 0});
  assert.equal(r.histories.bills.filter(b => b.reference.startsWith('Shared service setup')).length, 1);
  assert.ok(r.summary.rejected > 0 && r.summary.accepted > 0);
  assert.equal(r.summary.perAcceptedDeliveryAndSupportCents, r.summary.attempts * 200 / r.summary.accepted);
  assert.equal(r.summary.perAcceptedRecurringCents, (r.summary.accruedCostsCents - c.initialSetupCents - c.historicalResearchCents) / r.summary.accepted);
});
test('Provider onboarding is charged once per new buyer and survives first-delivery rejection', () => {
  const c = fixture(); c.providerOnboardingCents = 875; c.fieldReliabilityMultiplier = 0;
  const r = simulateHumanMarket(c, 123);
  const buyerIds = new Set(r.histories.jobs.map(j => j.buyer));
  const onboard = r.histories.bills.filter(b => b.reference.startsWith('provider-onboarding:'));
  assert.equal(onboard.length, buyerIds.size); assert.equal(r.summary.accepted, 0);
  assert.ok(onboard.every(b => b.amountCents === c.providerOnboardingCents));
});
test('Obsolescence limits investment forecast and accepted use', () => {
  const c = fixture(); c.capabilities[0].lifetimeWeeks = 1;
  const r = simulateHumanMarket(c, 123);
  assert.ok(r.histories.investments.length < 2);
  assert.ok(r.histories.decisions.every(d => d.forecastWeeks <= 1));
});
