// SPDX-License-Identifier: Apache-2.0
export function fixture() {
  const classes = ['simple', 'locale', 'versioned'].map(id => ({id, weight: 1 / 3, humanReferenceCents: 10000,
    priceEvidenceReference: 'Synthetic arithmetic control; not market evidence'}));
  const profiles = [0, 1, 2].map(n => ({id: `profile-${n}`, sourceSHA256: String(n + 1).repeat(64),
    evidenceReference: 'Synthetic finance control; no production claim',
    classes: Object.fromEntries(classes.map((item, i) => [item.id, {supported: i <= n,
      acceptanceProbability: i <= n ? 1 : 0, deliveryCostCents: 100, businessCostCents: 100,
      customerMinutes: 0, attemptsPerJob: 1, marginalExecutionCostCents: 1, setupAllocationCents: 20}]))}));
  const capabilities = [1, 2].map(n => ({id: `capability-${n}`, sourceSHA256: profiles[n].sourceSHA256,
    evidenceReference: 'Synthetic cost and effect control', constructionCents: 5000, validationCents: 1000,
    failedDiscoveryCents: 1000, integrationCents: 1000, weeklyMaintenanceCents: 10, lifetimeWeeks: 52,
    constructionWeeks: 1}));
  return {id: 'DEVELOPMENT_ONLY', currency: 'USD', weeks: 26, buyers: 9, arrivalProbability: 1,
    classes, profiles, capabilities, initialCashCents: 100000, reserveCents: 20000, initialSetupCents: 5000,
    historicalResearchCents: 10000, weeklyOverheadCents: 100, opportunityScreeningCents: 0, opportunityAcquisitionCents: 0,
    paymentDelayWeeks: 2, paymentProbability: 1,
    expenseDelayWeeks: 0, refundDelayWeeks: 1, refundProbability: 0, discountBps: 1000, buyerHourlyCents: 3500,
    humanReviewMinutes: 0, humanQuality: 1, enterprisePerceivedQuality: 1, humanDays: 2, enterpriseDays: 1,
    delayCentsPerDay: 0, buyerIntegrationCents: 0, buyerSwitchingCents: 0, providerOnboardingCents: 0, buyerValueMultiplier: 1.5,
    buyerErrorLossCents: 0, buyerProcurementBudgetCents: 10000000, enterpriseSlotsPerWeek: 20,
    choiceModel: 'deterministic', logitScaleCents: 100, forecastDiscount: 0.5, investmentEarliestWeek: 4,
    forecastWindowWeeks: 8, fieldReliabilityMultiplier: 1, paymentFeeBps: 1000, fiscalReserveBps: 2000,
    priceEvidenceReference: 'DEVELOPMENT synthetic reference', costAssumptionsReference: 'DEVELOPMENT synthetic costs',
    productionEvidenceReference: 'DEVELOPMENT synthetic profiles', allMoneyIsAssumed: true, demandIsAssumed: true};
}
