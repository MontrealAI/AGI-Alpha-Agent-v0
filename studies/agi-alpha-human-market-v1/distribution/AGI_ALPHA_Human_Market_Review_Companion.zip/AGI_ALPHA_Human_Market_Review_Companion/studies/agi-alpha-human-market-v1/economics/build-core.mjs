// SPDX-License-Identifier: Apache-2.0
import {readFile, writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const path = new URL('./upstream/market/upstream/src/market.mjs', import.meta.url);
const source = await readFile(path, 'utf8');
const names = 'createFirm, unpaid, receivable, expense, payBills, collect, liquidity, operatingSurplus';
const suffix = `\n// Human-market adapter: export existing pure accounting helpers without changing their bodies.\nexport {${names}};\n`;
await writeFile(new URL('./upstream/market/upstream/src/cash-core.mjs', import.meta.url), source + suffix);
const sha = text => createHash('sha256').update(text).digest('hex');
await writeFile(new URL('./core-transformation.json', import.meta.url), JSON.stringify({
  schema: 'human-market-core-interface/v1', upstreamRepository: 'MontrealAI/AGI-Alpha-Agent-v0',
  upstreamRef: 'daac40ee9e02a1b1bb100d7b9fcfa5caab04c297',
  upstreamPath: 'studies/agi-alpha-second-investment-v1/market/upstream/src/market.mjs',
  sourceSHA256: sha(source), outputSHA256: sha(source + suffix), operation: 'append-export-only',
  appendedText: suffix, exportedNames: names.split(', '),
  scope: 'The original buyer/AI market simulator remains preserved but is not executed. Accounting helper bodies are unchanged.'
}, null, 2) + '\n');
