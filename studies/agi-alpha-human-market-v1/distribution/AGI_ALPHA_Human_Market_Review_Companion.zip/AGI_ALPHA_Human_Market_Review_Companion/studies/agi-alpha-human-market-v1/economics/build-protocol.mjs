// SPDX-License-Identifier: Apache-2.0
import {readFile, writeFile, mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import path from 'node:path';
import {validateHumanConfig} from './human-market.mjs';

const study = path.resolve(new URL('..', import.meta.url).pathname);
const [profilesArg, freezeArg, protocolDirArg] = process.argv.slice(2);
if (!profilesArg || !freezeArg || !protocolDirArg) throw Error('Usage: node economics/build-protocol.mjs PRODUCTION_PROFILES.json SOURCE_FREEZE.json PROTOCOL_DIRECTORY');
const profilesPath = path.resolve(profilesArg), freezePath = path.resolve(freezeArg), out = path.resolve(protocolDirArg);
const source = JSON.parse(await readFile(profilesPath)), freezeBytes = await readFile(freezePath);
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
if (!Array.isArray(source.profiles) || source.profiles.length !== 3) throw Error('Three executed production profiles required');
const round = value => Math.round(value);
const costDocument = JSON.parse(await readFile(new URL('./cost-schedules.json', import.meta.url)));
const schedules = costDocument.schedules.map(s => ({id: s.id,
  historicalResearchCents: round(s.historical_research_and_discovery_usd * 100),
  initialSetupCents: round(s.shared_setup_usd * 100), reviewMinutes: s.provider_review_minutes_per_attempt,
  businessPerAttemptCents: round(s.business_support_correction_revision_usd_per_attempt * 100),
  opportunityAcquisitionCents: round(s.prospect_acquisition_usd_per_opportunity * 100),
  providerOnboardingCents: round(s.provider_onboarding_minutes_per_new_customer * 3500 / 60),
  weeklyOverheadCents: round(s.weekly_fixed_operating_cost_usd * 100),
  capability: ['construction_usd', 'validation_usd', 'unsuccessful_discovery_usd', 'integration_usd']
    .map(key => round(s.each_capability[key] * 100)),
  weeklyMaintenanceCents: round(s.each_capability.weekly_maintenance_usd * 100)}));
const conditions = [
  {id: 'base'}, {id: 'low-demand', arrivalProbability: 0.05}, {id: 'zero-demand', arrivalProbability: 0},
  {id: 'high-demand', arrivalProbability: 0.5}, {id: 'onboarding-10', buyerIntegrationCents: 1000},
  {id: 'high-provider-review', providerReviewMinutes: 45}, {id: 'maintenance-5', weeklyMaintenanceCents: 500},
  {id: 'obsolescence-8', lifetimeWeeks: 8}, {id: 'sparse-expanded', classWeights: [0.8, 0.1, 0.1]},
  {id: 'quality-collection-stress', fieldReliabilityMultiplier: 0.9, refundProbability: 0.1, paymentDelayWeeks: 8},
  {id: 'fiscal-fee-stress', fiscalReserveBps: 3500, paymentFeeBps: 1500},
  {id: 'acquisition-20', opportunityAcquisitionCents: 2000},
  {id: 'low-trust', enterprisePerceivedQuality: 0.90}
];
const classNames = ['simple', 'locale', 'versioned'];
const priceRefs = [{cents: 2000, evidence: 'Published Upwork $20 CSV cleanup listing; scope match uncertainty retained.'},
  {cents: 2500, evidence: 'Published Upwork $25 cleanup listing; row-limit and full-packet scope uncertain.'},
  {cents: 9900, evidence: 'Published Upwork $99 cleaned CSV plus data-quality report, <=10,000 rows and one revision.'}];
function scenario(price, discount, schedule, condition) {
  const profiles = source.profiles.map(p => ({id: p.id, sourceSHA256: p.sourceSHA256,
    evidenceReference: p.evidenceReference, classes: Object.fromEntries(classNames.map(id => {
      const measured = p.classes[id]; if (!measured) throw Error(`Missing ${p.id}/${id} evidence`);
      if (!Number.isFinite(measured.meanCpuSeconds) || measured.meanCpuSeconds < 0) throw Error('Measured CPU required');
      const reviewMinutes = condition.providerReviewMinutes ?? schedule.reviewMinutes;
      const marginal = round(10 + measured.meanCpuSeconds / 3600 * 100);
      const recurring = marginal + round(reviewMinutes * 3500 / 60);
      return [id, {supported: measured.supported, acceptanceProbability: measured.acceptanceProbability,
        deliveryCostCents: recurring, businessCostCents: schedule.businessPerAttemptCents,
        customerMinutes: 5, attemptsPerJob: measured.attemptsPerJob, marginalExecutionCostCents: marginal,
        setupAllocationCents: 0}];
    }))}));
  const capabilities = [1, 2].map((index) => ({id: `generation-${index}`, sourceSHA256: profiles[index].sourceSHA256,
    evidenceReference: profiles[index].evidenceReference, constructionCents: schedule.capability[0],
    validationCents: schedule.capability[1], failedDiscoveryCents: schedule.capability[2], integrationCents: schedule.capability[3],
    weeklyMaintenanceCents: condition.weeklyMaintenanceCents ?? schedule.weeklyMaintenanceCents,
    lifetimeWeeks: condition.lifetimeWeeks ?? 52, constructionWeeks: 1}));
  const c = {id: `p${price.cents}-d${discount}-${schedule.id}-${condition.id}`, currency: 'USD', weeks: 52, buyers: 8,
    arrivalProbability: condition.arrivalProbability ?? 0.25,
    classes: classNames.map((id, i) => ({id, weight: (condition.classWeights ?? [1/3, 1/3, 1/3])[i],
      humanReferenceCents: price.cents, priceEvidenceReference: price.evidence})), profiles, capabilities,
    initialCashCents: 500000, reserveCents: 50000, initialSetupCents: schedule.initialSetupCents,
    historicalResearchCents: schedule.historicalResearchCents, weeklyOverheadCents: schedule.weeklyOverheadCents, opportunityScreeningCents: 2,
    opportunityAcquisitionCents: condition.opportunityAcquisitionCents ?? schedule.opportunityAcquisitionCents,
    paymentDelayWeeks: condition.paymentDelayWeeks ?? 2, paymentProbability: 0.98, expenseDelayWeeks: 0,
    refundDelayWeeks: 2, refundProbability: condition.refundProbability ?? 0.02, discountBps: discount,
    buyerHourlyCents: 3500, humanReviewMinutes: 5, humanQuality: 1, enterprisePerceivedQuality: condition.enterprisePerceivedQuality ?? 0.98,
    humanDays: 2, enterpriseDays: 1, delayCentsPerDay: 0, buyerIntegrationCents: condition.buyerIntegrationCents ?? 300,
    buyerSwitchingCents: 0, providerOnboardingCents: schedule.providerOnboardingCents, buyerValueMultiplier: 1.5, buyerErrorLossCents: 2500,
    buyerProcurementBudgetCents: 1000000, enterpriseSlotsPerWeek: 8, choiceModel: 'deterministic', logitScaleCents: 1000,
    forecastDiscount: 0.5, investmentEarliestWeek: 4, forecastWindowWeeks: 8,
    fieldReliabilityMultiplier: condition.fieldReliabilityMultiplier ?? 1,
    paymentFeeBps: condition.paymentFeeBps ?? 1000, fiscalReserveBps: condition.fiscalReserveBps ?? 2000,
    priceEvidenceReference: 'evidence/market-prices.json and protocol/pricing-methodology.json; contemporaneous source-specific scope limits apply',
    costAssumptionsReference: 'economics/cost-schedules.json; allocations are sensitivity assumptions, not actual invoices or cost bounds',
    productionEvidenceReference: source.evidenceReference, allMoneyIsAssumed: true, demandIsAssumed: true};
  return validateHumanConfig(c);
}
const primary = [], boundary = [];
for (const price of priceRefs) for (const discount of [500, 1000, 1500]) for (const schedule of schedules) {
  for (const condition of conditions) primary.push(scenario(price, discount, schedule, condition));
  boundary.push(scenario(price, discount, schedule, {id: 'diagnostic-zero-buyer-integration', buyerIntegrationCents: 0}));
}
await mkdir(out, {recursive: true});
const common = {schema: 'agi-alpha-human-market-campaign/v1', sourceFreezeSHA256: sha(freezeBytes),
  productionProfilesSHA256: sha(await readFile(profilesPath)), seeds: Array.from({length: 8}, (_, i) => 26001 + i),
  wallBudgetSeconds: 600, definition: 'Designed structural sensitivity counts; not probabilities of market success.',
  buyerRule: 'Deterministic generalized-value choice among equivalent human service, enterprise and deferral.',
  noActualSales: true, actualCollectionsCents: 0};
await writeFile(path.join(out, 'campaign-primary.json'), JSON.stringify({...common,
  campaignId: 'human-market-primary-20261026', edition: 'primary', scenarios: primary}, null, 2) + '\n', {flag: 'wx'});
await writeFile(path.join(out, 'campaign-boundary.json'), JSON.stringify({...common,
  campaignId: 'human-market-zero-buyer-integration-diagnostic-20261026', edition: 'diagnostic', scenarios: boundary}, null, 2) + '\n', {flag: 'wx'});
await writeFile(path.join(out, 'design-summary.json'), JSON.stringify({schema: 'human-market-design/v1',
  primaryConditions: conditions, pricesCents: priceRefs, discountBps: [500, 1000, 1500], schedules: schedules.map(s => s.id),
  primaryScenarios: primary.length, primaryPairedWorlds: primary.length * 8, primaryHistories: primary.length * 8 * 3,
  diagnosticScenarios: boundary.length, diagnosticPairedWorlds: boundary.length * 8,
  diagnosticHistories: boundary.length * 8 * 3, primarySelection: 'All declared price, discount and cost cells reported; none selected by outcome.',
  remainingLimitations: ['Price scope uncertainty is not a random variable or a validated distribution.',
    'No empirical buyer conversion or review-time estimate exists.',
    'Buyer quality beliefs remain fixed within each condition and do not learn from rejection or refund; low-trust is a separate structural sensitivity.',
    'First-use utility gap at q=.98 is H*d - .02*(1.5*H + 25) - 3 USD. All primary discounts at USD20/25 lose that initial deterministic choice under base friction, an assumption-driven prediction rather than observed demand.',
    'The boundary diagnostic sets only buyer integration cost to zero. Provider onboarding, review, acquisition, fees, reserves and other business costs remain.',
    'The high review condition duplicates the high schedule review time intentionally; scenario counts are not independent samples.',
    'Zero setup allocation at job level avoids double charging; actual setup is charged once and unit allocation is calculated after accepted count is known.']}, null, 2) + '\n', {flag: 'wx'});
console.log(JSON.stringify({primaryScenarios: primary.length, primaryWorlds: primary.length * 8,
  diagnosticScenarios: boundary.length, diagnosticWorlds: boundary.length * 8, output: out}));
