# SPDX-License-Identifier: Apache-2.0
"""Publication figures from saved outcomes only; no production/model execution."""
from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import StrMethodFormatter

STUDY = Path(__file__).resolve().parents[1]
OUT = STUDY / 'paper/figures'
OUT.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,
    'axes.spines.top':False,'axes.spines.right':False,'axes.labelcolor':'#211a36',
    'text.color':'#211a36','xtick.color':'#3b3650','ytick.color':'#3b3650',
    'pdf.fonttype':42,'savefig.facecolor':'white'})
PURPLE,TEAL,GRAY='#633fb4','#167b81','#858092'
primary=json.loads((STUDY/'results/economics-primary-01/summary.json').read_text())
protocol=json.loads((STUDY/'protocol/economics-primary/campaign-primary.json').read_text())
groups={g['scenarioId']:g for g in primary['groups']}
conditions={}
for config in protocol['scenarios']:
    name='-'.join(config['id'].split('-')[3:])
    conditions.setdefault(name,[0,0])
    for s in groups[config['id']]['seeds']:
        conditions[name][0]+=bool(s['connectedCycle']['fullCycleWithinModel'])
        conditions[name][1]+=1
labels={'base':'Base assumptions','low-demand':'Low demand','zero-demand':'Zero demand',
    'high-demand':'High demand','onboarding-10':'Buyer integration: $10',
    'high-provider-review':'Provider review: 45 minutes','maintenance-5':'Maintenance: $5 / week',
    'obsolescence-8':'Useful life: 8 weeks','sparse-expanded':'Expanded classes: 20% of work',
    'quality-collection-stress':'Quality / collection stress','fiscal-fee-stress':'Fiscal / fee stress',
    'acquisition-20':'Acquisition: $20 / prospect','low-trust':'Enterprise quality belief: 0.90'}
fig,ax=plt.subplots(figsize=(7.15,4.55),layout='constrained')
keys=list(conditions);vals=[conditions[k][0] for k in keys]
ax.barh(range(len(keys)),vals,color=PURPLE,height=.56)
ax.set_yticks(range(len(keys)),[labels[k] for k in keys]);ax.invert_yaxis()
ax.set_xlim(0,max(vals)*1.35);ax.set_xticks([0,10,20,30,40])
ax.set_xlabel('Qualifying two-investment cycles (216 designed worlds per condition)')
ax.xaxis.grid(True,color='#e8e4ee',linewidth=.6);ax.set_axisbelow(True)
for i,v in enumerate(vals):ax.text(v+.7,i,f'{v}/216',va='center',fontsize=9)
fig.savefig(OUT/'cycle_conditions.pdf',bbox_inches='tight')
fig.savefig(OUT/'cycle_conditions.png',dpi=180,bbox_inches='tight');plt.close(fig)

case=json.loads((STUDY/'analysis/primary-final/preselected-world.json').read_text())['world']
fig,ax=plt.subplots(figsize=(7.15,3.65),layout='constrained')
for i,(name,color) in enumerate([('No investment',GRAY),('First only',TEAL),('Up to two',PURPLE)]):
    b=case['runs'][i]['histories']['balances']
    ax.step([x['week'] for x in b],[x['generatedAvailableCents']/100 for x in b],where='post',
        label=name,color=color,lw=2 if i==2 else 1.6)
for week,label in [(32,'G1 outlay\nweek 32'),(36,'G2 outlay\nweek 36')]:
    ax.axvline(week,color='#b9b0cc',ls='--',lw=.8)
    ax.text(week-.4 if week==32 else week+.4,2350,label,ha='right' if week==32 else 'left',va='top',fontsize=9)
ax.axvspan(52,57,color='#f0ecf8',alpha=.8)
ax.text(54.5,90,'Runoff',ha='center',fontsize=8,color='#625773')
ax.set(xlabel='Model week (52 service weeks, then settlement runoff)',ylabel='Available operating-generated funds (USD)',xlim=(0,57),ylim=(0,2450))
ax.yaxis.set_major_formatter(StrMethodFormatter('${x:,.0f}'))
ax.yaxis.grid(True,color='#e8e4ee',linewidth=.6);ax.set_axisbelow(True)
ax.legend(frameon=False,loc='upper left',fontsize=9)
fig.savefig(OUT/'selected_cash.pdf',bbox_inches='tight')
fig.savefig(OUT/'selected_cash.png',dpi=180,bbox_inches='tight');plt.close(fig)

fig,ax=plt.subplots(figsize=(6.5,3.5),layout='constrained')
matrix=[[8,8,8],[0,8,8],[0,0,8]]
import numpy as np
a=np.array(matrix)
ax.imshow(a,cmap=matplotlib.colors.ListedColormap(['#eeeaf4',PURPLE]),vmin=0,vmax=8,aspect='auto')
ax.set_xticks(range(3),['G0','G1: locale support','G2: version reconciliation'])
ax.set_yticks(range(3),['Ordinary cleanup','Locale normalization','Latest-version reconciliation'])
for i in range(3):
    for j in range(3):ax.text(j,i,'8/8 accepted' if a[i,j] else '8/8 refused',ha='center',va='center',color='white' if a[i,j] else '#211a36',fontsize=10)
ax.set_title('Fresh primary delivery: completed packets and correct refusals',loc='left',pad=12,fontsize=11)
for spine in ax.spines.values():spine.set_visible(False)
fig.savefig(OUT/'production_scope.pdf',bbox_inches='tight')
fig.savefig(OUT/'production_scope.png',dpi=180,bbox_inches='tight');plt.close(fig)
print(json.dumps({'output':str(OUT),'figures':3,'input_worlds':primary['completedWorlds'],'simulation_invoked':False}))
