# Selective public review companion

This is an explicitly incomplete scientific archive. See PUBLIC_REVIEW_EDITION.json
for every included/omitted path, byte size and SHA-256, and the identity of the
separately delivered complete companion. Frozen source/protocols are unchanged.

Read studies/agi-alpha-human-market-v1/README.md and the final paper. All 41
production-freeze source files and 86 economics-freeze source files are included.
The full raw-output verification command requires the COMPLETE companion.

The separate AGI_ALPHA_CSV_Offering.zip is the smallest self-contained executable.
For a modeled economic replay from this extracted archive root:
cd studies/agi-alpha-human-market-v1
node economics/run-campaign.mjs protocol/economics-primary/campaign-primary.json protocol/economics-source-freeze.json reproductions/market-primary-review
For the separate diagnostic, substitute campaign-boundary.json and a different
output directory. Use a new output directory; never replace archived outcomes.
The broader tools/reproduce.py wrapper also requires full-companion raw output
verification, so use the direct economic command above in this selective edition.
A replay is not fresh evidence.
Actual collections zero. Monetary results and demand are simulations.
