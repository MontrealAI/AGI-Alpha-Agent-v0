# SPDX-License-Identifier: Apache-2.0
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
manifest=json.loads((root/'COMPANION_MANIFEST.json').read_text())
for item in manifest['files']:
    p=(root/item['path']).resolve()
    if not p.is_relative_to(root):raise SystemExit('UNSAFE_PATH')
    b=p.read_bytes()
    if len(b)!=item['bytes'] or hashlib.sha256(b).hexdigest()!=item['sha256']:
        raise SystemExit('IDENTITY_MISMATCH:'+item['path'])
print(json.dumps({'status':'PASS','verified_files':len(manifest['files']),
    'bytes':sum(i['bytes'] for i in manifest['files']),'new_experiment_run':False}))
