# AGI Fleet · Linux & Apple silicon Mac

**[Which download and workflow should I use?](docs/START_HERE.md)** · **[Quel téléchargement et quel parcours choisir ?](docs/COMMENCER_ICI.md)** — Published releases, development previews, safe setup and recovery.

**[Build my SUCCESSOR Ω](https://montrealai.github.io/AGI-Fleet-Linux/successor.html)** · **[Créer mon SUCCESSOR Ω](https://montrealai.github.io/AGI-Fleet-Linux/successor-fr.html)** — Create useful local work, connect a qualified Fleet computer, check improvements and keep your system. [Builder guide](successor/docs/GUIDE.md).

**Published qualification releases: Linux 1.1.4 and Local Skills alpha.4.** Both were published on 15 October 2026 after their exact saved-archive gates passed on x86-64 and ARM64. They add stronger artifact checks, readable reports, explicit reuse/mapping, bounded history continuation, task admission and lifecycle corrections. [Linux release notes](docs/RELEASE_NOTES_1_1_4.md) · [Local Skills release](https://github.com/MontrealAI/AGI-Fleet-Linux/releases/tag/v0.1.0-local-skills-preview.4) · [Completion backlog and open gates](docs/PRODUCT_COMPLETION.json). Both remain prereleases with production qualification false; physical and live-provider commissioning remain open.

**New source candidate: Local Skills alpha.5.** The [Alpha project journey](docs/local-skills/PROJECT_JOURNEY.md) preserves one project through bounded Fleet execution and a separately authorized internal check, with USDC and $AGIALPHA kept explicit. This is a source candidate pending its own saved-package qualification; the published downloads above are unchanged.

**Linux 1.1.4 is the current controlled fresh-install qualification release.** [What changed](docs/RELEASE_NOTES_1_1_4.md). The free English/French Builder, authenticated Agent execution, separately authorized Node review, portable ownership and deliberate version choice remain available. [Download and release notes](https://github.com/MontrealAI/AGI-Fleet-Linux/releases/tag/v1.1.4-qualification) · [Verified release evidence](validation/LINUX_1_1_4_RELEASE_ADDENDUM.md). Browser-only missions need no account, wallet, installation or provider key. Physical and live-provider commissioning remain open.

**Local Skills alpha.4 · published separate Linux development preview:** [Download, verify and try it](docs/local-skills/DOWNLOAD.md) · [Télécharger et essayer en français](docs/local-skills/DOWNLOAD.md#français). One private installation, several actors and a zero-model-cost offline report. Full product acceptance remains open; funded work and general browser/desktop execution stay disabled.

**Preserved Linux 1.1.2:** [Frozen installation guide](https://github.com/MontrealAI/AGI-Fleet-Linux/blob/v1.1.2-qualification/docs/FRESH_INSTALL.md) · [Release assets](https://github.com/MontrealAI/AGI-Fleet-Linux/releases/tag/v1.1.2-qualification) · [Original evidence](validation/LINUX_1_1_2_RELEASE_ADDENDUM.md). Use its frozen guide when installing that version.

**Previous release:** Linux 1.1.1 remains available with its [frozen installation guide](https://github.com/MontrealAI/AGI-Fleet-Linux/blob/v1.1.1-qualification/docs/FRESH_INSTALL.md), [release assets](https://github.com/MontrealAI/AGI-Fleet-Linux/releases/tag/v1.1.1-qualification) and [original evidence](validation/LINUX_1_1_1_RELEASE_ADDENDUM.md).

**Earlier release:** Linux 1.1.0 remains available with its [frozen installation guide](https://github.com/MontrealAI/AGI-Fleet-Linux/blob/v1.1.0-qualification/docs/FRESH_INSTALL.md), [release assets](https://github.com/MontrealAI/AGI-Fleet-Linux/releases/tag/v1.1.0-qualification) and [original evidence](validation/LINUX_1_1_0_RELEASE_ADDENDUM.md). Use instructions that match your downloaded version.

**Historical release:** **Linux 1.0.11 is published for controlled fresh-install qualification.** Its exact installer passed native suites and AGIJobManager 1.15.0 integration on x86-64 and ARM64. [Download and release notes](https://github.com/MontrealAI/AGI-Fleet-Linux/releases/tag/v1.0.11-qualification) · [Hash-bound validation addendum](validation/LINUX_1_0_11_RELEASE_ADDENDUM.md). Physical commissioning remains open.

## New here? Let’s find your next step.

Fleet helps a dedicated Linux computer or Apple silicon Mac perform AI work and check the results. You can explore the possibilities without knowing the technical terms.

### [Start here — guide me, one step at a time →](https://montrealai.github.io/AGI-Fleet-Linux/start.html)

### [Commencer en français — me guider, étape par étape →](https://montrealai.github.io/AGI-Fleet-Linux/start-fr.html)

### Apple silicon Mac · M1 / M2

[**Set up your Mac, one step at a time →**](https://montrealai.github.io/AGI-Fleet-Linux/install-mac.html) · [**Configurer votre Mac, étape par étape →**](https://montrealai.github.io/AGI-Fleet-Linux/install-mac-fr.html)

An eight-step companion stays beside you through setup: clear account labels, Agent/Node instructions, larger text, saved progress, a printable guide and help at every stage. It asks for no secrets and does not inspect or change your computer.

[**Mac guide — start here →**](https://montrealai.github.io/AGI-Fleet-Linux/mac.html) · [**Guide Mac en français →**](https://montrealai.github.io/AGI-Fleet-Linux/mac-fr.html)

Mac mini, MacBook and Mac Studio have a dedicated native macOS distribution, all six roles, a clean Standard-account installation guide, recovery instructions and a physical qualification checklist. [Mac installation](macos/docs/FRESH_INSTALL.md) · [Platform parity](macos/docs/PARITY.md) · [Published Mac manifest](macos/published-release.json) · [Mac 1.20.2 download and release notes](https://github.com/MontrealAI/AGI-Fleet-Linux/releases/tag/v1.20.2-macos-qualification)

Mac **1.20.2** is published for controlled fresh-install qualification. Its exact archive passed native Apple silicon regressions on macOS 15 and 26 and the separate AGIJobManager integration gate. It is **not production-qualified, Developer ID signed or notarized**. Physical M1/M2 installation and 72-hour endurance remain **NOT_RUN**; keep funded work disabled. Linux results do not qualify a Mac.

**Get work done · Set up an AI worker · Help me understand**

Choose a goal in the guided welcome. It explains what you need and points you to the right next step, including help preparing a suitable computer. Use your browser’s Back button, keep larger text enabled, and copy or print a preparation plan for someone helping you. No sign-up is needed to explore.

**Published qualification prereleases:** Linux **1.1.4** (x86-64 and ARM64) and Mac **1.20.2** (native Apple silicon). Each has its own recorded native and AGIJobManager integration acceptance. Physical machine qualification remains open for both; paid work must stay disabled until the required checks pass.

[Explore the Fleet website](https://montrealai.github.io/AGI-Fleet-Linux/) · [Linux installation](docs/FRESH_INSTALL.md) · [Mac installation](macos/docs/FRESH_INSTALL.md) · [Linux help](docs/TROUBLESHOOTING.md) · [Mac help](macos/docs/TROUBLESHOOTING.md)

## What we’re building

**Our mission: make a large fraction of the work people do with a keyboard, mouse and screen accessible to a capable, easy-to-use AI workforce.** Fleet is being developed for everyday installed applications, signed-in business tools, documents, code, research and multi-step workflows, with independent review and clear human control.

The team frames this opportunity as an **approximately US$40 trillion annual total addressable market**. This is the team's strategic estimate, not a verified market measurement, revenue forecast or demonstrated automation rate.

**Linux 1.1.4 and Mac 1.20.2 are published as separate qualification prereleases.** Both contain all six AGI Jobs roles. Linux targets Ubuntu Desktop 24.04 LTS on x86-64 and ARM64; Mac targets native Apple silicon M1/M2 on macOS 15 or later. Each edition has its own native and AGIJobManager integration PASS evidence. Physical commissioning remains open.

[Download Linux 1.1.4](https://github.com/MontrealAI/AGI-Fleet-Linux/releases/tag/v1.1.4-qualification) · [Download Mac 1.20.2](https://github.com/MontrealAI/AGI-Fleet-Linux/releases/tag/v1.20.2-macos-qualification) · [Linux installation](docs/FRESH_INSTALL.md) · [Mac installation](macos/docs/FRESH_INSTALL.md)

## Choose the right work mode

| Your goal | Work mode | Where to start |
| --- | --- | --- |
| Produce checkable files from public or synthetic inputs on Linux. | **Linux public-work release.** Linux 1.1.4 has native and contract-integration PASS on both architectures, recorded in the [published manifest](https://github.com/MontrealAI/AGI-Fleet-Linux/releases/download/v1.1.4-qualification/Release-Manifest-v1.1.4.json); physical qualification remains open. | [Linux fresh-install guide](docs/FRESH_INSTALL.md) |
| Produce checkable files from public or synthetic inputs on an M1/M2 Mac. | **Mac public-work release.** Mac 1.20.2 includes the six roles and isolated Docker Desktop workspace. Native and integration acceptance are recorded in its [published manifest](https://github.com/MontrealAI/AGI-Fleet-Linux/releases/download/v1.20.2-macos-qualification/Release-Manifest-macOS-v1.20.2.json); physical qualification remains open. | [Mac fresh-install guide](macos/docs/FRESH_INSTALL.md) |
| Develop and qualify work across installed Linux applications and manually signed-in business accounts. | **Linux authorized workspace preview.** A separate Linux X11 native engine, signed task grants, action budgets and encrypted result handoffs. Pilot-only development preview; production execution is disabled. Not included in the 1.1.4 Fleet ZIP; the preview records a historical 1.0.9 source basis. | [Workspace quickstart](workstation/QUICKSTART.md) |
| Evaluate the original native Mac application workflow in a dedicated account. | **Bundled Mac native-workforce pilot.** Included in the Mac 1.20.2 archive, with signed task grants and explicit macOS screen/accessibility permissions. Separate operating qualification is required; archive acceptance does not qualify native execution or private-work settlement. | [Bundled Mac pilot scope and launcher](macos/docs/PARITY.md#native-macos-work-is-an-additional-track) |
| Develop broader Mac work with guided task preparation and larger public Studio imports. | **New Mac source preview.** Adds a guided native menu, job drafts, STOP/resume and general-v2 public Studio. Outside the Mac 1.20.2 ZIP, with no inherited release acceptance; production native execution is disabled and all physical gates remain NOT_RUN. | [Mac preview overview](macos/preview/README.md) · [Native task setup](macos/preview/QUICKSTART.md) · [Public Studio setup](macos/preview/STUDIO.md) |

**Source previews for broader work:** [Linux workspace](workstation/QUICKSTART.md) · [Mac workspace and larger Studio](macos/preview/README.md). Both are separate development artifacts, outside their platform release ZIPs, with production native execution disabled and no inherited physical qualification. The bundled original Mac native-workforce pilot remains a distinct track.

The public sandbox is one work mode, **not the ceiling of the product's mission**. Native workstation paths use dedicated OS accounts: desktop control can reach everything that account can access. Keep them separate from your everyday account and the Fleet signer; a grant is not a per-site sandbox. Sign into approved applications yourself. These previews do not automatically publish private results or settle private jobs through AGIJobManager.

**Larger public Studio tasks are retained in Linux 1.1.4 and available in both source previews:** [Linux Studio](successor/docs/GUIDE.md#keep-larger-work-safely) · [Preserved Linux source preview](workstation/STUDIO.md) · [Mac Studio](macos/preview/STUDIO.md). Agent and Node can import public `computer-work/v2` jobs with arbitrary declared file formats, up to **64 files and 64 MiB total**, exact-byte review handoffs and revision feedback. Large Studio work can be explicitly excluded from bounded wallet backups; keep its exported files separately. The quick editor remains v1. Imports preserve each job's exact runtime identities, permissions, criteria, budgets and deadlines, and grant no execution authority. The reviewed public Studio format and explicit backup exclusion were introduced in Linux 1.1.2 and remain included in Linux 1.1.4. The Mac additions remain outside its 1.20.2 ZIP; private or signed-in work belongs to the separate native workflow.

## Ideas behind the workforce

[Read four selected essays](https://montrealai.github.io/AGI-Fleet-Linux/#reading) on provider trust, governed autonomy, coordinated execution and the cost of verification. English/French summaries link to current guides. [Reading notes and version context](docs/READING.md).

## The potential of Fleet + AGIJobManager

**Our assessment: together, they could form a reusable workforce that turns a clear request into an independently checked outcome in the tools people already use.** Fleet supplies execution and review; AGIJobManager supplies funded work orders, participation rules and settlement. This is an architectural and commercial assessment, not a measured automation rate.

Modern assistants can already use tools. The combined product's value would be a dependable process: **define the result → execute in the required applications → independently review the outcome → settle under the job's rules**. That process must justify its total cost; a simple question or draft may still be better served by an assistant alone. The private workspace preview needs a separately implemented and qualified settlement bridge.

The target spans software, data, documents, research, creative production, business operations and cross-application projects. The job format has no profession or file-extension allowlist, but tools, permissions and demonstrated competence still determine coverage. **A successful task, a completed workflow and an entire occupation are different units.** Measure accepted results across all attempted work, human intervention and the share of representative work time or value covered.

The commercial progression is **verified task templates → repeat-buyer workflows → cross-application projects → a multi-operator market**. Expand when quality, demand, review capacity and economics support the next step. These are recommended development stages, not completed deployments.

Keep the market model clear: **total opportunity → serviceable work → accepted paid job value → actual participant receipts and profit**. At the team's stated US$40 trillion TAM, 0.01%, 0.1% and 1% correspond arithmetically to US$4 billion, US$40 billion and US$400 billion in associated annual human-work spending. These illustrate scale; they are neither forecasts, job transaction volume nor company revenue. No platform fee is assumed.

A user-friendly experience should answer five questions: **What should be done? Which workspace may be used? What may it change? What will it cost? How do I review or stop it?** The preview quickstart makes the first workspace explicit; task templates, smoother setup and broader application qualification remain part of the development roadmap.

Success means **repeatable, independently accepted results at a competitive total cost and low human supervision**. No current release establishes that most keyboard-and-mouse jobs can already be completed.

The full analysis reviews Fleet [`2f27979`](https://github.com/MontrealAI/AGI-Fleet-Linux/tree/2f2797905fe7867ab3ec63d3b7332ef6d38f407d) and AGIJobManager [`69a9d6c` (1.14.0 source)](https://github.com/MontrealAI/AGIJobManager/blob/69a9d6cef1d6f4daff22cfe360282f6abefcd27a/README.md). The subsequent [1.14.0](validation/AGIJOBMANAGER_1_14_0_COMPATIBILITY.md) and [1.15.0](validation/AGIJOBMANAGER_1_15_0_COMPATIBILITY.md) compatibility records report separate, source-pinned public-work probes. These records do not qualify private-work settlement or replace physical commissioning.

**[Read the complete potential and scope guide](docs/POTENTIAL_AND_SCOPE.md)** · **[Français](docs/POTENTIEL_ET_PERIMETRE.md)** · **[Explore the website explanation](https://montrealai.github.io/AGI-Fleet-Linux/#potential)**

## Ready to prepare a computer?

Choose the [Linux guided welcome](https://montrealai.github.io/AGI-Fleet-Linux/start.html) or [Mac M1/M2 guided welcome](https://montrealai.github.io/AGI-Fleet-Linux/mac.html). Mac operators should follow the [fresh Mac setup guide](macos/docs/FRESH_INSTALL.md), using a new Standard compute account and separate signer. The following checklist is the **Linux installation path** for operators and technical helpers.

1. Use a dedicated, clean **Ubuntu Desktop 24.04 LTS** machine with GNOME, systemd and cgroup v2. Allow at least 8 GB RAM and 40 GB free disk; 16 GB RAM is recommended.