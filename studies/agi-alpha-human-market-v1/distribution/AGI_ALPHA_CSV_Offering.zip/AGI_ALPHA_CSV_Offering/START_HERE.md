# Working bounded CSV offering

This small archive supplies the exact frozen delivery implementation, upstream
source/licenses, one synthetic input, and its accepted output. It is not the full
scientific companion: complete freezes, oracle corpus and economics are separate.

Requirements: existing Python3 and Node. Original versions3.12.14 and24.22.1.
No pip/npm install, credentials, paid calls or infrastructure startup is required.

From this archive root:
python3 verify_companion.py
python3 studies/agi-alpha-human-market-v1/src/deliver.py --job studies/agi-alpha-human-market-v1/example/job.json --generation 2 --out replay-output

Use a new output directory. Inspect summary.json for COMPLETED, then compare
semantic.json with accepted-example/semantic.json. The output is a clean-and-
exception packet, not a guarantee that every input row is import-ready.
Read the supplied DELIVERY_CONTRACT.md before supplying other permitted inputs.
The runner verifies the declared source SHA256; no confidential data is authorized.
The other source files preserve the source identity; study/graph/campaign commands
need the complete companion and are not the delivery entry point for this archive.

Runtime model calls0. Actual complete research/delivery money unknown; collections0.
HOLD, no execution authority, no settlement. Research reproduction only.
