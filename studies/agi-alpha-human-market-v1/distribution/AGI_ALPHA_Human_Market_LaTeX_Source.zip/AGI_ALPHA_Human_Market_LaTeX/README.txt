Publication-ready LaTeX source, English paper with French summary.
Run latexmk -pdf -interaction=nonstopmode -halt-on-error AGI_ALPHA_Human_Market_Advantage.tex
using existing standard TeX packages. The figures are already supplied; regenerating
them with build_figures.py requires the complete companion's saved study data.
No new simulation is run by the paper. The original French Babel dependency failure
was resolved without installing packages; the French text uses standard T1 fonts.
