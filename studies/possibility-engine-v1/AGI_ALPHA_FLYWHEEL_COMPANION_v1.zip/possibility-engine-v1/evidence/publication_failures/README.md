# Publication corrections

The first XeLaTeX invocation failed because hyperref configuration preceded its package; its original log is retained. Configuration now runs at document start. Long unbreakable labels, unavailable italic shape selection, TOC number spacing and an equation introduction were corrected during render review. No scientific source, seed or acceptance changed.

The initial graph-grid drawing let a direct edge pass visually through an unrelated vertex. The original PNG/PDF are retained here; the final circular layout avoids that ambiguity. An economics figure footer initially overlapped its axis title; final visual review verifies separation.

The first mobile reading edition overflowed because a display equation escaped its container. The diagnostic is verification/publication_qa/initial_mobile_overflow.json. The corrected reader scrolls long equations locally and has no horizontal page overflow. A table-of-contents regular expression initially omitted headings with wrapped attributes; final QA requires one navigation link per main heading. The mobile chart now retains readable labels.

The first local Chromium invocation was blocked by the execution sandbox (Operation not permitted). The same local-file-only test ran through the approved escalation route, with zero external requests. No security configuration was changed.
