import json,time
from pathlib import Path
T={1:['()']}; found=[]; total=0; start=time.perf_counter()
def adj(s):
 a=[]; stack=[]
 for c in s:
  if c=='(':
   i=len(a); a.append([])
   if stack: a[i].append(stack[-1]);a[stack[-1]].append(i)
   stack.append(i)
  else:stack.pop()
 return a
def sig(a):
 n=len(a);v=[1]+[0]*(n-1);m=[]
 for k in range(2*n):
  m.append(v[0]);v=[len(a[i])*v[i]-sum(v[j] for j in a[i]) for i in range(n)]
 return tuple(m)
def canon(a,r,p=-1):return '('+''.join(sorted(canon(a,j,r) for j in a[r] if j!=p))+')'
for n in range(2,15):
 pool=sorted([(k,s) for k,v in T.items() for s in v]);out=[]
 def rec(left,lo,parts):
  if left==0:out.append('('+''.join(sorted(parts))+')');return
  for idx in range(lo,len(pool)):
   k,s=pool[idx]
   if k>left:break
   rec(left-k,idx,parts+[s])
 rec(n-1,0,[]);T[n]=sorted(out);seen={};count=0
 for s in T[n]:
  a=adj(s);ss=sig(a);total+=1
  if ss in seen:
   o=seen[ss];b=adj(o)
   if min(canon(a,r) for r in range(n))!=min(canon(b,r) for r in range(n)):
    found.append({'n':n,'tree_a':o,'tree_b':s,'edges_a':[[i,j] for i,z in enumerate(b) for j in z if i<j],'edges_b':[[i,j] for i,z in enumerate(a) for j in z if i<j],'moments':ss});count+=1
  else:seen[ss]=s
 print(n,len(T[n]),count,round(time.perf_counter()-start,2),flush=True)
 if found:break
Path('research/graph_probe_results.json').write_text(json.dumps({'pairs':found,'examined':total,'seconds':time.perf_counter()-start},indent=2)+'\n')
