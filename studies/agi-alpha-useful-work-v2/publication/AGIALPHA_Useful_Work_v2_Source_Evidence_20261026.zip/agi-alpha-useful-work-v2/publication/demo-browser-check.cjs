const {chromium}=require('playwright');
const fs=require('fs'),path=require('path'),crypto=require('crypto');
(async()=>{
const t0=performance.now(),cpu0=process.cpuUsage();
const root=path.resolve('research/useful-work-v2'),out=path.resolve('tmp/useful-work-demo-qa');
const browser=await chromium.launch({headless:true,executablePath:path.resolve('tmp/useful-work-browser/chrome-headless-shell-linux64/chrome-headless-shell')});
const context=await browser.newContext({viewport:{width:1440,height:1100},acceptDownloads:true});
const page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(String(e)));
await page.goto('file://'+root+'/publication/AGIALPHA_Useful_Work_Demo.html');
await page.locator('#download-packet').waitFor();
const checks=[];
for(const language of ['en','fr']){
 await page.locator('#'+language).click();
 for(const mission of ['development','starlette-1','starlette-2','starlette-3','pydantic-1','pydantic-2','pydantic-3']){
  await page.locator('#mission').selectOption(mission);
  const doc=await page.evaluate(()=>({lang:document.documentElement.lang,chosen:document.querySelector('#mission').value,status:document.querySelector('.status').textContent,result:document.querySelector('.result h3').textContent,scroll:document.documentElement.scrollWidth,width:innerWidth}));
  if(doc.lang!==language||doc.chosen!==mission||doc.scroll>doc.width)throw Error('Language/mission/overflow:'+JSON.stringify(doc));
  checks.push({language,mission,...doc});
 }
}
const downloads=[];
for(const [language,mission] of [['en','development'],['fr','pydantic-3']]){
 await page.locator('#'+language).click();await page.locator('#mission').selectOption(mission);
 const waiting=page.waitForEvent('download');await page.locator('#download-packet').click();const d=await waiting;
 const destination=path.join(out,d.suggestedFilename());await d.saveAs(destination);
 const expected=await page.evaluate(id=>JSON.parse(document.querySelector('#sealed-data').textContent).packets.find(p=>p.id===id).download.sha256,mission);
 const bytes=fs.readFileSync(destination),actual=crypto.createHash('sha256').update(bytes).digest('hex');
 if(actual!==expected)throw Error('Downloaded bytes mismatch');downloads.push({language,mission,path:destination,bytes:bytes.length,sha256:actual});
}
await page.locator('#en').click();await page.locator('#mission').selectOption('development');await page.evaluate(()=>scrollTo(0,0));await page.screenshot({path:path.join(out,'desktop-en.png')});
await page.locator('#fresh').scrollIntoViewIfNeeded();await page.screenshot({path:path.join(out,'results-en.png')});
await page.locator('#fr').click();await page.setViewportSize({width:390,height:844});await page.evaluate(()=>scrollTo(0,0));
if(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth))throw Error('Mobile overflow');
await page.screenshot({path:path.join(out,'mobile-fr.png')});
await browser.close();
const cpu=process.cpuUsage(cpu0),record={schema:'bilingual-demo-browser-qa/v1',created_at:new Date().toISOString(),checks,downloads,page_errors:errors,wall_seconds:(performance.now()-t0)/1000,controller_cpu_seconds:(cpu.user+cpu.system)/1e6,money_usd:null,new_missions:0,note:'Browser/Node child CPU is measured separately by enclosing command. Local static display/download QA only; no production service or new confirmation.'};
fs.writeFileSync(path.join(root,'publication/demo-browser-qa.json'),JSON.stringify(record,null,2)+'\n');
if(errors.length)throw Error('Page errors');console.log(JSON.stringify({checks:checks.length,downloads:downloads.length,page_errors:errors.length,wall_seconds:record.wall_seconds}));
})().catch(e=>{console.error(e);process.exitCode=1});
