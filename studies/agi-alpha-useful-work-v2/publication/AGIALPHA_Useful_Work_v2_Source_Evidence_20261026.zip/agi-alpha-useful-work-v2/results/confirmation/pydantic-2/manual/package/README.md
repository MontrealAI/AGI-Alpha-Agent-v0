# Dependency refresh: researcher-finalized incumbent assessment

**SCOPED_COMPONENT_PRESERVED**

Accept this finite component evidence for further qualification; keep the current native lock pending full application and release checks.

Required cases: 61. Verified conforming cases: 61 before, 61 after.

| Package | Before | Proposed |
|---|---|---|
| annotated-doc | 0.0.5 | 0.0.5 |
| annotated-types | 0.8.0 | 0.8.0 |
| anyio | 4.15.1 | 4.15.1 |
| fastapi | 0.141.1 | 0.141.1 |
| idna | 3.20 | 3.20 |
| pydantic | 2.13.3 | 2.13.4 |
| pydantic-core | 2.46.3 | 2.46.4 |
| starlette | 1.7.0 | 1.7.0 |
| typing-extensions | 4.16.0 | 4.16.0 |
| typing-inspection | 0.4.4 | 0.4.4 |

Root supplied the disposition after reviewing the exact common verifier outcomes. The retained assembly template and shared receipt checks refuse an unsupported disposition. This is researcher-assisted work, not measured no-AI human labor.

## Remaining qualification

- Decide whether the refresh is needed for the maintained release.
- Resolve and qualify the full application lock and supported platforms.
- Run authorized whole-application authentication, journal persistence and mission-execution checks.
- Obtain owner review and the existing exact-source release gates.

Evidence contains source, exact component locks, observations, execution receipts, complete requirement results and reproduction commands. The required scope includes the original FastAPI import bridge and real 15-second timeout; the recorded results show completion or gaps. No full application, credentials, Journal or operator action was created. Complete cost, price and attention remain unknown; customer receipts are zero. Cases and retries do not add customer jobs.
