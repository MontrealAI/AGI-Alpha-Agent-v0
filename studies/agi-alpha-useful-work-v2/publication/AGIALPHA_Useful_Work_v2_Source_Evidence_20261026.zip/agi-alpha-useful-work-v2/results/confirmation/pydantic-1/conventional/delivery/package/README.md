# Dependency refresh: conventional component assessment

**SCOPED_COMPONENT_PRESERVED**

Accept this finite component evidence for further qualification; keep the current native lock pending full-application and release checks.

Required cases: 61. Verified cases: 61 before, 61 after.

| Package | Before | Proposed |
|---|---|---|
| annotated-doc | 0.0.5 | 0.0.5 |
| annotated-types | 0.8.0 | 0.8.0 |
| anyio | 4.15.1 | 4.15.1 |
| fastapi | 0.141.1 | 0.141.1 |
| idna | 3.20 | 3.20 |
| pydantic | 2.13.2 | 2.13.3 |
| pydantic-core | 2.46.2 | 2.46.3 |
| starlette | 1.7.0 | 1.7.0 |
| typing-extensions | 4.16.0 | 4.16.0 |
| typing-inspection | 0.4.4 | 0.4.4 |

The original component definitions and FastAPI import bridge were tested with a reusable ordinary unittest suite. The shared independent verifier checks all required observations. Required assertions, environment repetitions and invalid-input rejection cases are not separate customer jobs or production defects.

## Remaining qualification

- Decide whether this proposed refresh is needed for the maintained release.
- Resolve and qualify the full application dependency lock and supported platform matrix.
- Run separately authorized whole-application authentication, journal persistence and mission-execution checks.
- Obtain existing owner review and exact-source release gates before adoption.

The exact component locks, sources, observations, process receipts, verifier and implementation are in evidence/. The full companion supplies the preserved wheel environments. The patch does not replace requirements-agent.lock. No credentials, Journal, full application or operator action was created. All monetary cost, price and attention estimates remain unknown; actual receipts are zero.
