# Mise à jour des dépendances : évaluation conventionnelle des composants

**SCOPED_COMPONENT_PRESERVED**

Accepter ces preuves limitées aux composants pour la qualification suivante ; conserver le verrou natif actuel jusqu'aux contrôles de l'application complète et de publication.

Cas requis : 61. Cas vérifiés conformes : 61 avant, 61 après.

| Paquet | Avant | Proposition |
|---|---|---|
| annotated-doc | 0.0.5 | 0.0.5 |
| annotated-types | 0.8.0 | 0.8.0 |
| anyio | 4.15.1 | 4.15.1 |
| fastapi | 0.141.1 | 0.141.1 |
| idna | 3.20 | 3.20 |
| pydantic | 2.13.2 | 2.13.3 |
| pydantic-core | 2.46.2 | 2.46.3 |
| starlette | 1.7.0 | 1.7.0 |
| typing-extensions | 4.16.0 | 4.16.0 |
| typing-inspection | 0.4.4 | 0.4.4 |

Les définitions d'origine des composants et leur chemin d'importation FastAPI ont été exécutés au moyen d'une suite réutilisable de tests unittest. Le vérificateur indépendant commun contrôle les observations requises. Les assertions, les environnements répétés et les rejets attendus d'entrées invalides ne constituent ni des missions clientes distinctes ni des défauts de production découverts.

## Qualification restante

- Déterminer si cette mise à jour est nécessaire pour la version maintenue.
- Résoudre et qualifier toutes les dépendances de l'application et les plateformes prises en charge.
- Exécuter les contrôles autorisés de l'application complète : authentification, persistance du journal et exécution des missions.
- Obtenir la revue des responsables et satisfaire les exigences de publication liées au code source exact.

Les verrous exacts des composants, le code source, les observations, les reçus d'exécution, le vérificateur et l'implémentation figurent dans evidence/. Le compagnon complet fournit les environnements et les fichiers wheel conservés. Le correctif proposé ne remplace pas requirements-agent.lock. Aucun identifiant d'accès, Journal, application complète ou acte d'opérateur n'a été créé. Les coûts monétaires complets, le prix et le temps d'attention restent inconnus ; les encaissements clients réels sont nuls. La conformité des composants ne vaut pas autorisation de publication.
