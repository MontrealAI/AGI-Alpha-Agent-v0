# Mise à jour des dépendances : dossier finalisé par le chercheur

**SCOPED_COMPONENT_PRESERVED**

Accepter ces preuves limitées aux composants pour la qualification suivante ; conserver le verrou natif actuel jusqu'aux contrôles complets de l'application et de publication.

Cas requis : 61. Cas vérifiés conformes : 61 avant, 61 après.

| Paquet | Avant | Proposition |
|---|---|---|
| annotated-doc | 0.0.5 | 0.0.5 |
| annotated-types | 0.8.0 | 0.8.0 |
| anyio | 4.15.1 | 4.15.1 |
| fastapi | 0.141.1 | 0.141.1 |
| idna | 3.20 | 3.20 |
| pydantic | 2.13.5 | 2.13.5 |
| pydantic-core | 2.46.5 | 2.46.5 |
| starlette | 1.6.0 | 1.8.0 |
| typing-extensions | 4.16.0 | 4.16.0 |
| typing-inspection | 0.4.4 | 0.4.4 |

Le responsable de l'étude a fourni la décision après examen des résultats exacts du vérificateur commun. Le modèle de dossier conservé et les contrôles de reçus refusent une décision non étayée. Ce travail assisté par le chercheur ne constitue pas une mesure du travail humain sans IA.

## Qualification restante

- Déterminer si la mise à jour est nécessaire pour la version maintenue.
- Résoudre et qualifier toutes les dépendances de l'application et les plateformes prises en charge.
- Exécuter les contrôles autorisés d'authentification, de persistance du journal et d'exécution des missions.
- Obtenir la revue des responsables et satisfaire les exigences de publication liées au code source exact.

Les preuves comprennent le code source, les verrous exacts des composants, les observations, les reçus d'exécution, les résultats détaillés et les commandes de reproduction. Le périmètre requis inclut le chemin d'importation FastAPI d'origine et le délai réel de 15 secondes ; les résultats indiquent les contrôles terminés ou les lacunes. Aucune application complète, aucun identifiant d'accès, Journal ou acte d'opérateur n'a été créé. Le coût complet, le prix et le temps d'attention restent inconnus ; les encaissements clients sont nuls. Les cas et les nouvelles tentatives ne constituent pas des missions clientes supplémentaires.
