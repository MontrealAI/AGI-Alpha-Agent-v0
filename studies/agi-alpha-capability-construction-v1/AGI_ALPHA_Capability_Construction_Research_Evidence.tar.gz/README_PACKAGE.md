# AGI ALPHA capability-construction companion

This complete local research payload preserves source, the 110 frozen inputs,
raw results, unsuccessful development, market-data economic models, measured
cost ledgers, intervention records, editable figures, the paper, and browser
companion. Extract the archive before opening HTML or running code.

Start with `capability_study/README.md` and
`capability_study/reproduction/README.md`. The browser HTML is self-contained.
Its local computations, recorded planning evidence, and conditional economics
are labeled separately. Authenticated browser-to-approved-executor operation
was NOT RUN; no operator credential, daemon or financial route is supplied.

The canonical PDF SHA-256 is `51ee8ded6860b6ab6b1a7bd1e0901fe864a96c30d40446c3743dd975ba139b28`.
The prospective FREEZE.json SHA-256 is `55fe389e077028c1439cf3dbdadc09164455df00865db471ddf03bd1eb99e282`.
`SHA256SUMS.json` hashes every archive member except itself. The file contents
are unchanged from the selected local originals. Archive member order, times,
permissions and compression settings are fixed for deterministic packaging.

`capability_study/publication/STATUS.json` (or the status record named in the
package verification report) describes the actual publication stage. Packaging
is not a merge, remote publication, deployment or public-availability check.
Earlier editions and their prospective checkpoint remain preserved separately.

Excluded materials are caches, transient TeX build products, internal browser
screenshots and downloaded QA fixtures, PDF inspection captures, provider/private
state, and nested historical checkpoint archives. Scientific stdout, stderr,
failed attempts and their original receipts remain included. File selection and
a private-key marker check are not a claim of comprehensive security certification.

The two primary implementation license families and exact source provenance are
in `capability_study/reproduction/licenses/`. Original source notices remain
intact. Official statistics retain their recorded source terms and scope.

Recreating the experiment requires the reference environment and a fresh output
directory, as described in the reproduction guide. Complete monetary costs,
human attention and long-term maintenance remain unmeasured. Qualification and
load cases are not additional primary customer jobs.
