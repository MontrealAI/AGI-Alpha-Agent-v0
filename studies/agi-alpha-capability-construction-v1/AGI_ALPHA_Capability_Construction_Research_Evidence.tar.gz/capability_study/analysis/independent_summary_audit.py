# SPDX-License-Identifier: Apache-2.0
"""Read-only scientific consistency audit of saved study results.

Recomputes summary arithmetic from raw records and re-evaluates saved outputs with
the frozen independent oracles. It does not import producer or summary code,
alter the frozen study, rerun missions, or create new experimental observations.
"""

from __future__ import annotations

import hashlib
import json
import math
import random
import statistics
import sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "evaluation"))
from evidence_oracle import accept_evidence  # noqa: E402
from native_oracle import accept_native  # noqa: E402
from plan_oracle import accept_journey, accept_plan  # noqa: E402
from review_run import diagnose  # noqa: E402


def read(path: str | Path) -> Any:
    return json.loads((ROOT / path).read_text())


def identity(path: str | Path) -> str:
    return hashlib.sha256((ROOT / path).read_bytes()).hexdigest()


def close(left: Any, right: Any) -> bool:
    if isinstance(left, (float, int)) and isinstance(right, (float, int)):
        return math.isclose(left, right, rel_tol=1e-12, abs_tol=1e-12)
    return left == right


def main() -> None:
    checks: dict[str, bool] = {}

    def check(name: str, condition: Any) -> None:
        checks[name] = bool(condition)

    def stats(prefix: str, actual: dict[str, Any], values: list[float]) -> None:
        ordered = sorted(values)
        expected = {
            "n": len(values),
            "min": min(values),
            "median": statistics.median(values),
            "mean": statistics.mean(values),
            "max": max(values),
            "p95_nearest_rank": ordered[math.ceil(len(values) * 0.95) - 1],
            "all": values,
        }
        for key, value in expected.items():
            check(prefix + "/" + key, close(actual[key], value))

    freeze = read("protocol/FREEZE.json")
    for entry in freeze["files"]:
        check("freeze/" + entry["path"], identity(entry["path"]) == entry["sha256"])
    aggregate = read("analysis/SUMMARY.json")
    portfolio = read("raw/portfolio/summary.json")
    planning = read("raw/planning/summary.json")
    rows = []
    primary_ids = []
    for record in portfolio["attempts"]:
        path = ROOT / "raw/portfolio" / record["id"]
        task = read(path / "task.json")
        pack = read(path / "output/pack.json")
        verdict = (
            accept_evidence(task["spec"], pack)
            if task["spec"]["family"].startswith("evidence-")
            else accept_native(task["spec"], pack)
        )
        check(
            "primary/" + record["id"] + "/independent_acceptance", verdict["accepted"]
        )
        check(
            "primary/" + record["id"] + "/receipt_identity",
            read(path / "receipt.json") == record,
        )
        check(
            "primary/" + record["id"] + "/verdict_matches",
            read(path / "acceptance.json")["accepted"]
            == record["accepted"]
            == verdict["accepted"],
        )
        primary_ids.append(record["id"])
        rows.append(
            {
                "id": record["id"],
                "family": record["work_family"],
                "accepted": record["accepted"],
                "wall": record["delivery_wall_seconds"],
                "cpu": record["child_cpu_seconds"]
                + record["supervisor_and_oracle_cpu_seconds"],
            }
        )
    for record in planning["receipts"]:
        path = ROOT / "raw/planning" / record["id"]
        check(
            "planning/" + record["id"] + "/receipt_identity",
            read(path / "receipt.json") == record,
        )
        request = read(path / "request.json")
        result = read(path / "worker-result.json")
        if record["method"] == "run-journey":
            verdict = accept_journey(request["payload"], result)
        else:
            phase = result["result"]["phases"][0]
            verdict = accept_plan(request["payload"]["task"], phase["result"])
            check(
                "planning/" + record["id"] + "/input_binding",
                phase["task"] == request["payload"]["task"],
            )
        check(
            "planning/" + record["id"] + "/independent_acceptance", verdict["accepted"]
        )
        check(
            "planning/" + record["id"] + "/verdict_matches",
            verdict["accepted"] == record["accepted"],
        )
        if record["id"].startswith("planning-"):
            primary_ids.append(record["id"])
            rows.append(
                {
                    "id": record["id"],
                    "family": "planning-operations",
                    "accepted": record["accepted"],
                    "wall": record["outer_wall_seconds"],
                    "cpu": record["cpu_seconds"],
                }
            )
    check("primary/42_unique_jobs", len(primary_ids) == len(set(primary_ids)) == 42)
    check("primary/attempted_count", aggregate["primary_attempted"] == len(rows))
    check(
        "primary/accepted_count",
        aggregate["primary_accepted"] == sum(row["accepted"] for row in rows),
    )
    for actual, expected in zip(aggregate["primary_rows"], rows):
        for key, value in expected.items():
            check(
                "summary_row/" + expected["id"] + "/" + key, close(actual[key], value)
            )
    stats(
        "summary_primary_wall",
        aggregate["primary_wall_seconds"],
        [row["wall"] for row in rows],
    )
    for family in aggregate["families"]:
        selected = [row for row in rows if row["family"] == family]
        output = aggregate["families"][family]
        check("family/" + family + "/six", len(selected) == output["attempted"] == 6)
        check(
            "family/" + family + "/accepted",
            output["accepted"] == sum(row["accepted"] for row in selected),
        )
        stats(
            "family/" + family + "/wall",
            output["wall_seconds"],
            [row["wall"] for row in selected],
        )
        stats(
            "family/" + family + "/cpu",
            output["known_cpu_seconds"],
            [row["cpu"] for row in selected],
        )
    n, accepted, z = len(rows), sum(row["accepted"] for row in rows), 1.959963984540054
    phat = accepted / n
    centre = (phat + z * z / (2 * n)) / (1 + z * z / n)
    radius = (
        z * math.sqrt(phat * (1 - phat) / n + z * z / (4 * n * n)) / (1 + z * z / n)
    )
    check(
        "summary/wilson_lower",
        close(aggregate["acceptance_wilson_95_descriptive"][0], centre - radius),
    )
    check(
        "summary/wilson_upper",
        close(
            aggregate["acceptance_wilson_95_descriptive"][1], min(1, centre + radius)
        ),
    )

    evidence = read("raw/evidence-mechanism/summary.json")
    evidence_root = ROOT / "raw/evidence-mechanism"
    parent_by_hash = {
        identity(path): path.parent
        for path in evidence_root.glob("*/output/brief.json")
    }
    for record in evidence["attempts"]:
        path = evidence_root / record["id"]
        if "mechanism_arm" in record:
            path = evidence_root / (record["id"] + "-" + record["mechanism_arm"])
        task = read(path / "task.json")
        pack = read(path / "output/pack.json")
        lineage = read(path / "output/lineage.json")
        parent_pack = None
        if lineage["parent_brief_file_sha256"] is not None:
            parent_dir = parent_by_hash[lineage["parent_brief_file_sha256"]]
            parent_pack = read(parent_dir / "pack.json")
            check(
                "evidence/" + path.name + "/parent_tool",
                identity(parent_dir / "repair-tool.mjs")
                == lineage["parent_tool_sha256"],
            )
            check(
                "evidence/" + path.name + "/module_binding",
                lineage["parent_tool_sha256"] == identity("src/evidence.mjs"),
            )
            check(
                "evidence/" + path.name + "/invoked_parent",
                lineage["invoked_module"] == "verified-parent-artifact",
            )
        verdict = accept_evidence(task["spec"], pack, parent_pack)
        check("evidence/" + path.name + "/independent_acceptance", verdict["accepted"])
        check(
            "evidence/" + path.name + "/verdict_matches",
            verdict["accepted"] == record["accepted"],
        )
    check(
        "source/count_54",
        evidence["count"]
        == len(evidence["attempts"])
        == aggregate["source_mechanism"]["attempts"]
        == 54,
    )
    check(
        "source/accepted",
        evidence["accepted"]
        == sum(row["accepted"] for row in evidence["attempts"])
        == aggregate["source_mechanism"]["accepted"],
    )

    def cpu(row: dict[str, Any]) -> float:
        return row["child_cpu_seconds"] + row["supervisor_and_oracle_cpu_seconds"]

    pairs = [
        (cpu(pair["incremental"]), cpu(pair["full"])) for pair in evidence["pairs"]
    ]
    ratio = sum(row[0] for row in pairs) / sum(row[1] for row in pairs)
    check(
        "source/cpu_ratio",
        close(aggregate["source_mechanism"]["incremental_over_full_cpu_ratio"], ratio),
    )
    rng = random.Random(2026102557)
    bootstrap = []
    for _ in range(2000):
        sample = [rng.choice(pairs) for _ in pairs]
        bootstrap.append(sum(row[0] for row in sample) / sum(row[1] for row in sample))
    bootstrap.sort()
    check(
        "source/bootstrap",
        aggregate["source_mechanism"]["task_bootstrap_95"]
        == [bootstrap[50], bootstrap[1949]],
    )
    for number, policy in enumerate(evidence["policies"], 1):
        path = evidence_root / f"policy-cycle-{number}.json"
        check(
            "policy/" + str(number) + "/frozen_bytes",
            identity(path) == policy["policy_sha256_before_validation"],
        )
        record = read(path)
        measured = evidence["pairs"][(number - 1) * 4 : number * 4]
        expected_admit = all(
            pair[method]["accepted"]
            for pair in measured
            for method in ("full", "incremental")
        ) and all(
            cpu(pair["incremental"]) / cpu(pair["full"]) < 0.95 for pair in measured
        )
        check(
            "policy/" + str(number) + "/gate",
            record["preferred_method"] == ("incremental" if expected_admit else "full"),
        )
        check(
            "policy/" + str(number) + "/paired_evaluation_cost",
            close(
                policy["discovery_cpu_seconds"],
                sum(
                    cpu(pair[method])
                    for pair in measured
                    for method in ("full", "incremental")
                ),
            ),
        )

    review = read("raw/review/summary.json")
    check("review/exact_in_summary", aggregate["review"] == review)
    for row in review["records"]:
        path = ROOT / "raw/review" / row["id"]
        request, result = read(path / "request.json"), read(path / "result.json")
        expected = diagnose(request["input"], request["brief"])
        observed = {(item["code"], item["claim_id"]) for item in result["criticisms"]}
        check("review/" + row["id"] + "/critic", observed == expected)
        submitted = request.get("criticisms", result["criticisms"])
        check(
            "review/" + row["id"] + "/adjudication",
            len(result["adjudication"]) == len(submitted)
            and all(
                verdict["substantiated"]
                == ((item["code"], item["claim_id"]) in expected)
                for verdict, item in zip(result["adjudication"], submitted)
            ),
        )
    check(
        "review/case_counts",
        Counter(row["kind"] for row in review["records"])
        == {"clean": 6, "seeded-defect": 27, "false-criticism": 6},
    )
    check(
        "review/wall_total",
        close(
            review["wall_seconds_sum"],
            sum(row["wall_seconds"] for row in review["records"]),
        ),
    )
    check(
        "review/cpu_total",
        close(
            review["cpu_seconds_sum"],
            sum(
                row["child_cpu_seconds"] + row["supervisor_cpu_seconds"]
                for row in review["records"]
            ),
        ),
    )
    control = read("raw/controls/summary.json")
    check("controls/exact_in_summary", aggregate["controls"] == control)
    check(
        "controls/16_unique",
        len(control["cases"]) == len({row["case"] for row in control["cases"]}) == 16,
    )
    check("controls/passed", all(row["passed"] for row in control["cases"]))

    scale = read("raw/scale/summary.json")
    check(
        "scale/108_attempts_12_inputs",
        scale["attempts"] == 108 and scale["distinct_inputs"] == 12,
    )
    throughputs: dict[int, list[float]] = {}
    for concurrency in (1, 2, 4):
        batches = [row for row in scale["batches"] if row["concurrency"] == concurrency]
        check("scale/" + str(concurrency) + "/three_batches", len(batches) == 3)
        throughputs[concurrency] = []
        for batch in batches:
            accepted = sum(row["accepted"] for row in batch["rows"])
            rate = 60 * accepted / batch["batch_wall_seconds"]
            throughputs[concurrency].append(rate)
            check(
                "scale/batch/" + str(concurrency) + "/" + str(batch["repeat"]),
                batch["accepted"] == accepted == 12
                and close(rate, batch["accepted_per_minute"]),
            )
            for row in batch["rows"]:
                path = (
                    ROOT
                    / "raw/scale"
                    / f"c{concurrency}-r{batch['repeat']}"
                    / row["id"]
                )
                task, pack = read(path / "task.json"), read(path / "output/pack.json")
                verdict = (
                    accept_evidence(task["spec"], pack)
                    if task["spec"]["family"].startswith("evidence-")
                    else accept_native(task["spec"], pack)
                )
                check(
                    "scale/reaccept/"
                    + str(concurrency)
                    + "/"
                    + str(batch["repeat"])
                    + "/"
                    + row["id"],
                    verdict["accepted"] == row["accepted"],
                )
        stats(
            "scale/summary/" + str(concurrency),
            aggregate["scale"][str(concurrency)]["throughput_per_minute"],
            throughputs[concurrency],
        )
    check(
        "scale/c4_c1_ratio",
        close(
            aggregate["scale_ratio_c4_c1"],
            statistics.median(throughputs[4]) / statistics.median(throughputs[1]),
        ),
    )
    for field in ("complete_agent_money", "human_attention_minutes", "actual_revenue"):
        check("unknowns/" + field, aggregate[field] is None)
    check("unknowns/human_trial", aggregate["empirical_human_trial"] == "NOT_RUN")
    check(
        "unknowns/economics_and_acceleration",
        aggregate["full_economic_admission"]
        == aggregate["self_acceleration"]
        == "NOT_ESTABLISHED",
    )

    failures = [key for key, value in checks.items() if not value]
    output = {
        "schema": "capability-independent-summary-audit/v1",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "passed": not failures,
        "checks_total": len(checks),
        "failed_checks": failures,
        "input_summary_sha256": identity("analysis/SUMMARY.json"),
        "freeze_sha256": identity("protocol/FREEZE.json"),
        "checks": checks,
        "validity_flags": [
            {
                "status": "PASS",
                "finding": "Observed counts, output acceptance and summary arithmetic match saved records within declared numerical tolerance.",
            },
            {
                "status": "SCOPE",
                "finding": "Forty-two primary jobs are controlled instances of eight input templates in seven bounded families; review, controls, transfer and repeated load are separate denominators.",
            },
            {
                "status": "LIMIT",
                "finding": "Critic and adjudicator share deterministic contract logic; independent Python implementation is not an externally blinded human assessment.",
            },
            {
                "status": "LIMIT",
                "finding": "Full monetary cost, employer attention, authoring cost, deployment and maintenance remain materially unmeasured; human economics is conditional.",
            },
            {
                "status": "LABEL",
                "finding": "Policy discovery_cpu_seconds covers the eight paired search evaluations per cycle, excluding useful parent delivery and later presentation calls; do not label it a complete cycle cost.",
            },
            {
                "status": "NEGATIVE",
                "finding": "Retained planning repair lost all twelve fresh specialist quality comparisons; source incremental CPU point ratio exceeds one with an interval crossing one. No positive incremental productivity claim is supported.",
            },
            {
                "status": "LIMIT",
                "finding": "Control cases demonstrate bounded local refusal, cooperative STOP, injected interruption/fresh restart and local selection rollback, not an authenticated remote executor, continuous operation or transactional recovery.",
            },
            {
                "status": "LIMIT",
                "finding": "Wilson and paired bootstrap intervals describe this bounded purposive sample; repeated scale calls are not independent task diversity.",
            },
        ],
        "scope": "Read-only reacceptance and arithmetic audit; no new execution outcomes and no frozen source changes",
    }
    destination = ROOT / "analysis/INDEPENDENT_SCIENTIFIC_AUDIT.json"
    if destination.exists():
        raise FileExistsError("Preserve the existing audit and use a new edition")
    destination.write_text(json.dumps(output, indent=2) + "\n")
    print(
        json.dumps(
            {
                key: value
                for key, value in output.items()
                if key not in ("checks", "validity_flags")
            }
        )
    )


if __name__ == "__main__":
    main()
