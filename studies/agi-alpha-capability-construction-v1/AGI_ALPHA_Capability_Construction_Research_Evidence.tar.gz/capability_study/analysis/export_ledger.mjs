// CSV export from the canonical JSON ledger. Use the documented artifact tool
// matrix interface; the CSV serializer preserves raw numeric precision.
// Run from a temporary directory linked to the runtime-owned node_modules.
import fs from "node:fs/promises";
import path from "node:path";
import { Workbook } from "@oai/artifact-tool";

const base = process.argv[2];
if (!base) throw new Error("Pass the absolute capability_study/analysis path");
const ledger = JSON.parse(await fs.readFile(path.join(base, "LEDGER.json"), "utf8"));
const columns = [
  "ledger_id", "phase", "account", "record_type", "operation_count",
  "mission_id", "work_family", "arm", "artifact_accepted", "qualification_passed",
  "primary_sample_contribution", "wall_seconds", "cpu_seconds",
  "child_cpu_seconds", "supervisor_cpu_seconds", "service_work_units",
  "improvement_work_units", "native_calls", "native_reserved_solve_seconds",
  "fixed_execution_model_calls", "human_minutes", "authoring_model_tokens",
  "authoring_model_cost", "monetary_cost", "currency", "maintenance_cost",
  "support_cost", "deployment_cost", "queue_seconds", "submission_to_delivery_seconds",
  "batch_id", "concurrency", "wall_scope", "cpu_scope", "source_path",
  "source_sha256", "error", "notes"
];
const matrix = [columns, ...ledger.rows.map(row => columns.map(key => {
  const value = row[key];
  return value !== null && typeof value === "object" ? JSON.stringify(value) : value;
}))];
const workbook = Workbook.create();
const sheet = workbook.worksheets.add("Measured ledger");
const range = sheet.getRangeByIndexes(0, 0, matrix.length, columns.length);
range.values = matrix;
workbook.recalculate();
const roundtrip = range.values;
if (JSON.stringify(roundtrip) !== JSON.stringify(matrix)) {
  throw new Error("Typed ledger matrix changed during spreadsheet authoring");
}
const quote = value => {
  if (value === null || value === undefined) return "";
  const s = String(value);
  return /[",\r\n]/.test(s) ? '"' + s.replaceAll('"', '""') + '"' : s;
};
const text = roundtrip.map(values => values.map(quote).join(",")).join("\r\n") + "\r\n";
await fs.writeFile(path.join(base, "LEDGER.csv"), text);
console.log(JSON.stringify({rows: ledger.rows.length, columns: columns.length, output: "LEDGER.csv", nulls: "empty CSV fields; canonical JSON retains null"}));
