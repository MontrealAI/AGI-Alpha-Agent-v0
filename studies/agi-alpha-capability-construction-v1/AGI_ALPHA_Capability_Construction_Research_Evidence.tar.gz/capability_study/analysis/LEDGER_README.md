# Measured execution ledger and intervention register

`LEDGER.json` is the canonical, machine-readable accounting export. `LEDGER.csv`
contains the same operation and resource-pool rows as a flat table. An empty CSV
field corresponds to an unmeasured or inapplicable value; the JSON retains explicit
`null`. Neither format converts missing costs to zero.

The ledger includes every preserved raw and development receipt in this additive
study. It does not include the earlier Economics of Autonomous Work experiment as
if those operations had occurred again. It does not change the prospective freeze,
task results, prior editions, or public release status.

## What the rows represent

There are 357 unique leaf receipts, 374 recorded operating cases, 14 supplementary
resource pools, and five unmeasured project cost accounts. The 374 operating cases
comprise 284 confirmation and 90 development operations. Twelve controls have only
suite-level evidence rather than an individual leaf receipt, and five initial
native example executions were not timed. These cases account for the difference
between receipt and operation counts.

**The main accepted delivery sample is 42 jobs.** The remaining rows include paired
mechanism research, review qualification, controlled refusals, construction,
development failures, and repeated load jobs. Their inclusion pays attention to
research and operating costs; it does not create a sample of 374 customer jobs.
`artifact_accepted` and `qualification_passed` therefore have different meanings.
An expected refusal passes its control while delivering no accepted artifact.

| Confirmation account | Operations | Known CPU seconds | Accumulated measured wall seconds |
|---|---:|---:|---:|
| Primary delivery | 42 | 29.197227 | 12.149574 |
| Connected planning construction and delivery | 1 | 16.437662 | 8.096995 |
| Fresh planning transfer research | 24 | 96.231648 | 31.852587 |
| Source parent delivery | 15 | 2.045197 | 1.708514 |
| Source paired research | 24 | 3.262284 | 2.702867 |
| Source presentation transfer research | 12 | 1.718902 | 1.462922 |
| Source policy validation | 3 | 0.396238 | 0.329094 |
| Source suite overhead | 0 | Unmeasured | 0.078044 |
| Review qualification | 39 | 1.421349 | 1.354492 |
| Control qualification, including residual pool | 16 | 0.939616 | 0.846104 |
| Finite load qualification, including residual pools | 108 | 19.624458 | 18.131489 |

The confirmation accounts contain **171.274581650 measured CPU seconds**. Known
development accounts add **70.631571057 CPU seconds**, for **241.906152707 CPU
seconds** across the preserved measured execution. These are lower bounds on
resources used in this study. Complete CPU, monetary cost, authoring cost,
maintenance, support, deployment, and human attention remain `null`.

Accumulated wall time sums operation intervals. Concurrent service intervals
overlap, so that sum is not elapsed project time or customer turnaround. The
`resource_pools` array retains each complete load batch's elapsed time; per-job
queue and submission-to-delivery times remain available in the ledger. This is a
finite local workload, not a continuously running service.

## No duplicated summary costs

Every leaf receipt is assigned exactly once, using its relative path as identity.
This matters because the full and inherited source methods share mission IDs.
Embedded copies of receipts in summaries, copied parent artifacts, and analysis
reports are evidence references rather than additional operating attempts.

For controls, the whole-suite child CPU includes costs already recorded in ten
case receipts. The residual pool is whole-suite child CPU minus those leaf child
CPU values. Known supervisor/oracle CPU is added once at its original cases.
Unmeasured driver CPU is still unknown. The sequential wall residual is the suite
elapsed time minus measured individual case intervals.

For each load batch, the whole child-process CPU includes the Python wrappers and
their descendants. The residual is this total minus each leaf's producer and
supervisor/oracle CPU. It accounts for measured startup/exit work outside leaf
timers. Adding the complete batch CPU a second time would double count. The batch
driver's own CPU remains unmeasured.

The source suite has a measured elapsed interval covering its operation loop.
The difference between that interval and leaf delivery times is retained as
unallocated source-suite wall overhead. Its CPU was not metered.

## Delivery and improvement accounts

Planning exposes separate `service_work_units` and `improvement_work_units`.
These are implementation counters. They are neither CPU seconds nor currency.
`native_reserved_solve_seconds` is a reservation charged by the worker, not the
observed duration of a native solver. Actual whole-process CPU and wall time are
recorded separately. In the connected journey, available telemetry cannot split
real CPU between three useful plans and the construction/qualification work, so
the operating cost remains in `connected_construction_mixed`.

The source policy field named `discovery_cpu_seconds` records **paired
search-evaluation CPU only**. It excludes parent delivery, transfer, policy-parent
delivery, validation and initial source authorship. `source_cycle_accounts`
reconciles all 18 measured operations in each of three cycles and separately
reports its paired-search CPU. Even the 18-operation subtotal is not a complete
cycle cost: shared suite overhead is not allocated to cycles, and authoring,
setup, human effort, integration and maintenance are unmeasured.

The five initially executed native examples and two failed planning development
attempts remain visible. No confirmation rerun or favorable result was substituted
for them. Rejected planned control requests are identified separately from these
unexpected development failures.

## Intervention records and launch scorecard

`INTERVENTIONS.json` combines documented prefreeze implementation changes,
preserved planning development epochs, and all planned control injections. It
explicitly identifies overlapping descriptions of the same development history.
It is not a timed diary of every research-assistant action. The total number of
human interventions and human minutes are unknown; neither is inferred from an
absence of recorded rescue events.

`LAUNCH_SCORECARD.json` separates supported bounded delivery, actual inheritance,
negative planning-transfer results, functional source transfer, unchanged
discovery policies, conditional economics and unestablished self-acceleration.
It does not assert public deployment or supply an approved executor credential.

## Reproduction

From the study's parent directory, regenerate the JSON accounts with:

```sh
python capability_study/analysis/build_ledger.py
```

The builder verifies all 110 frozen source hashes, reconciles all receipt paths,
checks expected operation counts, and rejects duplicate assignment. It does not
execute a mission. Derived output timestamps and the builder's own hash are
expected to change if the accounting export is regenerated.

The CSV exporter uses the documented `@oai/artifact-tool` matrix interface, then
serializes its verified typed matrix to CSV without reducing numeric precision.
Run `export_ledger.mjs` with the absolute analysis directory as its argument in an
environment where that package is available. No worksheet formulas or market
assumptions are hidden in the CSV. The original receipts remain the source of all
measured values; source paths and SHA-256 hashes accompany each row.
