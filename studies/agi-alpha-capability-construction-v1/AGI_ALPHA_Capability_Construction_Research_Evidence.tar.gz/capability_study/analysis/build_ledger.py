#!/usr/bin/env python3
"""Export measured operation accounts without changing frozen study material.

This is post-confirmation accounting, not a new experiment or a preregistered
analysis change. Each leaf receipt enters once. Nested summaries are references.
"""

from __future__ import annotations

import hashlib
import json
import math
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "analysis"
ROWS: list[dict] = []
SOURCES: dict[str, str] = {}
LEAVES: set[str] = set()
POOLS: list[dict] = []


def rel(path: Path) -> str:
    return str(path.relative_to(ROOT))


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path: Path):
    SOURCES[rel(path)] = digest(path)
    return json.loads(path.read_text())


def save(name: str, data) -> None:
    (OUT / name).write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n")


def row(key: str, phase: str, account: str, source: Path, count=1) -> dict:
    return {
        "ledger_id": key,
        "phase": phase,
        "account": account,
        "record_type": "operation" if count else "unallocated_resource_pool",
        "operation_count": count,
        "source_path": rel(source),
        "source_sha256": SOURCES.get(rel(source)) or digest(source),
        "mission_id": None,
        "work_family": None,
        "arm": None,
        "artifact_accepted": None,
        "qualification_passed": None,
        "primary_sample_contribution": 0,
        "wall_seconds": None,
        "wall_scope": None,
        "cpu_seconds": None,
        "cpu_scope": None,
        "child_cpu_seconds": None,
        "supervisor_cpu_seconds": None,
        "service_work_units": None,
        "improvement_work_units": None,
        "native_calls": None,
        "native_reserved_solve_seconds": None,
        "fixed_execution_model_calls": None,
        "human_minutes": None,
        "authoring_model_tokens": None,
        "authoring_model_cost": None,
        "monetary_cost": None,
        "currency": None,
        "maintenance_cost": None,
        "support_cost": None,
        "deployment_cost": None,
        "queue_seconds": None,
        "submission_to_delivery_seconds": None,
        "batch_id": None,
        "concurrency": None,
        "error": None,
        "notes": [],
    }


def generic(path: Path, phase: str, account: str, *, add=True) -> dict:
    receipt = read(path)
    if rel(path) in LEAVES:
        raise AssertionError(f"Duplicate receipt: {path}")
    LEAVES.add(rel(path))
    item = row(rel(path.parent), phase, account, path)
    item.update(
        mission_id=receipt["id"],
        work_family=receipt.get("work_family"),
        artifact_accepted=receipt["accepted"],
        wall_seconds=receipt["delivery_wall_seconds"],
        wall_scope=receipt["scope"],
        child_cpu_seconds=receipt["child_cpu_seconds"],
        supervisor_cpu_seconds=receipt["supervisor_and_oracle_cpu_seconds"],
        cpu_seconds=receipt["child_cpu_seconds"]
        + receipt["supervisor_and_oracle_cpu_seconds"],
        cpu_scope="Producer descendants plus measured supervisor/oracle interval; initial input serialization and receipt tail excluded",
        fixed_execution_model_calls=receipt.get("task_model_calls"),
        error=receipt.get("error"),
    )
    if phase == "confirmation" and account == "primary_delivery":
        item["primary_sample_contribution"] = 1
    if add:
        ROWS.append(item)
    return item


def add_portfolio(base: Path, phase: str) -> None:
    summary = read(base / "summary.json")
    files = sorted(base.glob("*/receipt.json"))
    assert len(files) == summary["count"]
    for path in files:
        generic(path, phase, "primary_delivery")


def add_planning(base: Path, phase: str) -> None:
    summary = read(base / "summary.json")
    files = sorted(base.glob("*/receipt.json"))
    assert len(files) == summary["attempts"]
    for path in files:
        r = read(path)
        assert rel(path) not in LEAVES
        LEAVES.add(rel(path))
        account = (
            "connected_construction_mixed"
            if r["method"] == "run-journey"
            else (
                "planning_transfer_research"
                if r["id"].startswith("repair-transfer-")
                else "primary_delivery"
            )
        )
        item = row(rel(path.parent), phase, account, path)
        costs = r.get("costs") or {}
        item.update(
            mission_id=r["id"],
            work_family="planning-operations",
            arm=r["arm"],
            artifact_accepted=r["accepted"],
            wall_seconds=r["outer_wall_seconds"],
            wall_scope=r["outer_timing_scope"],
            cpu_seconds=r.get("cpu_seconds"),
            cpu_scope=r.get("cpu_scope"),
            service_work_units=costs.get("service_work"),
            improvement_work_units=costs.get("improvement_work"),
            native_calls=costs.get("native_calls"),
            native_reserved_solve_seconds=costs.get("native_solve_seconds"),
            fixed_execution_model_calls=r.get("model_calls_during_fixed_execution"),
            error=r.get("error"),
            notes=costs.get("unknown_costs", []),
        )
        if account == "connected_construction_mixed":
            item["notes"].append(
                "One three-stage journey bundle; actual wall/CPU cannot be split into delivery and improvement from these records. Declared work-unit accounts remain separate."
            )
        if phase == "confirmation" and account == "primary_delivery":
            item["primary_sample_contribution"] = 1
        ROWS.append(item)


def add_source(base: Path, phase: str) -> None:
    summary = read(base / "summary.json")
    files = sorted(base.glob("*/receipt.json"))
    assert len(files) == summary["count"]
    begin = len(ROWS)
    for path in files:
        name = path.parent.name
        if name.startswith(("evidence-parent-", "policy-parent-")):
            account = "source_parent_delivery"
        elif name.startswith("evidence-change-"):
            account = "source_paired_research"
        elif name.startswith("presentation-transfer-"):
            account = "source_transfer_research"
        elif name.startswith("policy-validation-"):
            account = "source_policy_validation"
        else:
            raise AssertionError(name)
        item = generic(path, phase, account)
        if account == "source_paired_research":
            item["arm"] = name.rsplit("-", 1)[1]
            item["notes"].append(
                "Paired search-evaluation cost only; parent delivery, transfer, validation and source authorship are separate."
            )
    measured = sum(x["wall_seconds"] for x in ROWS[begin:])
    residual = summary["elapsed_seconds"] - measured
    assert residual >= 0
    pool = row(
        rel(base) + "#source-suite-overhead",
        phase,
        "source_suite_overhead",
        base / "summary.json",
        0,
    )
    pool.update(
        wall_seconds=residual,
        wall_scope="Sequential source-suite elapsed time minus recorded delivery intervals; input generation, policy decisions and inter-operation I/O included; setup before loop excluded",
        cpu_scope="Suite overhead CPU was not measured",
        notes=[
            "No new mission. This residual is not part of paired search-evaluation CPU."
        ],
    )
    ROWS.append(pool)
    POOLS.append(
        {
            "suite": rel(base),
            "kind": "source-sequential-wall",
            "observed_elapsed_seconds": summary["elapsed_seconds"],
            "sum_operation_wall_seconds": measured,
            "unallocated_wall_seconds": residual,
        }
    )


def add_review(base: Path, phase: str) -> None:
    summary = read(base / "summary.json")
    assert len(summary["records"]) == summary["attempts"]
    for r in summary["records"]:
        path = base / r["id"] / "receipt.json"
        actual = read(path)
        assert actual == r
        assert rel(path) not in LEAVES
        LEAVES.add(rel(path))
        item = row(rel(path.parent), phase, "review_qualification", path)
        item.update(
            mission_id=r["id"],
            arm=r["kind"],
            qualification_passed=r["accepted"],
            wall_seconds=r["wall_seconds"],
            wall_scope=r["scope"],
            child_cpu_seconds=r["child_cpu_seconds"],
            supervisor_cpu_seconds=r["supervisor_cpu_seconds"],
            cpu_seconds=r["child_cpu_seconds"] + r["supervisor_cpu_seconds"],
            cpu_scope=r["scope"],
            fixed_execution_model_calls=0,
            error=r["error"],
            notes=[
                "Review qualification, not a customer deliverable or an independent mind."
            ],
        )
        ROWS.append(item)


def add_controls(base: Path, phase: str) -> None:
    summary = read(base / "summary.json")
    matched = 0
    measured_wall = 0.0
    measured_child = 0.0
    for index, case in enumerate(summary["cases"]):
        name = case["case"]
        if "receipt" in case:
            sub = {
                "explicit-restart-after-interruption": "recovered-delivery",
                "corrupt-retained-code-refused": "corrupt-source-refusal",
            }.get(name, name)
            path = base / sub / "receipt.json"
            item = generic(path, phase, "control_qualification", add=False)
            assert read(path) == case["receipt"]
            matched += 1
            measured_child += item["child_cpu_seconds"]
        else:
            item = row(
                rel(base) + "#" + name,
                phase,
                "control_qualification",
                base / "summary.json",
            )
            item.update(
                wall_seconds=case.get("seconds"),
                wall_scope="Individual control case wall time, where recorded",
                cpu_scope="Individual CPU unavailable; cost included in suite child-CPU pool",
                error=case.get("observed", {}).get("error"),
            )
        item.update(
            mission_id=name,
            qualification_passed=case["passed"],
            arm="planned-control-injection",
        )
        item["notes"].append(
            "A successful refusal is a passed control, not an accepted productive deliverable."
        )
        item["notes"].append("Summary case index: " + str(index))
        measured_wall += item["wall_seconds"] or 0
        ROWS.append(item)
    assert matched == len(list(base.glob("*/receipt.json")))
    residual_cpu = summary["child_cpu_seconds"] - measured_child
    residual_wall = summary["wall_seconds"] - measured_wall
    assert residual_cpu >= 0 and residual_wall >= 0
    pool = row(
        rel(base) + "#unallocated-suite-resources",
        phase,
        "control_qualification",
        base / "summary.json",
        0,
    )
    pool.update(
        cpu_seconds=residual_cpu,
        child_cpu_seconds=residual_cpu,
        cpu_scope="Whole-suite child CPU minus child CPU already assigned to individual cases; remaining driver CPU unavailable",
        wall_seconds=residual_wall,
        wall_scope="Whole sequential control suite minus individual measured case intervals",
        notes=[
            "Residual resource account, not another attempt. Known supervisor CPU is added once at its original cases."
        ],
    )
    ROWS.append(pool)
    POOLS.append(
        {
            "suite": rel(base),
            "kind": "controls",
            "observed_elapsed_seconds": summary["wall_seconds"],
            "observed_child_cpu_seconds": summary["child_cpu_seconds"],
            "allocated_child_cpu_seconds": measured_child,
            "unallocated_child_cpu_seconds": residual_cpu,
            "unallocated_wall_seconds": residual_wall,
        }
    )


def add_scale(base: Path, phase: str) -> None:
    summary = read(base / "summary.json")
    count = 0
    for batch in summary["batches"]:
        bdir = base / f"c{batch['concurrency']}-r{batch['repeat']}"
        bpath = bdir / "batch.json"
        assert read(bpath) == batch
        allocated_cpu = 0.0
        for case in batch["rows"]:
            path = bdir / case["id"] / "receipt.json"
            item = generic(path, phase, "scale_qualification", add=False)
            assert read(path) == case["receipt"]
            allocated_cpu += item["cpu_seconds"]
            item.update(
                qualification_passed=case["accepted"],
                wall_seconds=case["service_outer_seconds"],
                wall_scope="Full outer service interval including child Python startup and exit; concurrent intervals overlap",
                queue_seconds=case["queue_seconds"],
                submission_to_delivery_seconds=case["submission_to_delivery_seconds"],
                batch_id=rel(bdir),
                concurrency=batch["concurrency"],
            )
            item["notes"].append(
                "Repeated load instance; does not increase task diversity or the primary sample size."
            )
            ROWS.append(item)
            count += 1
        residual = batch["batch_child_cpu_seconds"] - allocated_cpu
        assert residual >= 0
        pool = row(
            rel(bdir) + "#unallocated-process-cpu",
            phase,
            "scale_qualification",
            bpath,
            0,
        )
        pool.update(
            cpu_seconds=residual,
            cpu_scope="Whole batch child/grandchild CPU minus all measured per-job producer and supervisor CPU; includes process startup/exit outside leaf windows; batch driver CPU unavailable",
            wall_scope="No additive wall residual: concurrent job intervals overlap; use batch elapsed time from resource_pools",
            batch_id=rel(bdir),
            concurrency=batch["concurrency"],
            notes=["Residual CPU account only, not another attempt."],
        )
        ROWS.append(pool)
        POOLS.append(
            {
                "suite": rel(bdir),
                "kind": "concurrent-load",
                "concurrency": batch["concurrency"],
                "observed_elapsed_seconds": batch["batch_wall_seconds"],
                "observed_child_cpu_seconds": batch["batch_child_cpu_seconds"],
                "allocated_cpu_seconds": allocated_cpu,
                "unallocated_cpu_seconds": residual,
                "accepted": batch["accepted"],
                "accepted_per_minute": batch["accepted_per_minute"],
            }
        )
    assert count == summary["attempts"]


def aggregate(rows: list[dict]) -> dict:
    operations = [x for x in rows if x["operation_count"]]
    return {
        "operations": sum(x["operation_count"] for x in rows),
        "primary_sample_size": sum(x["primary_sample_contribution"] for x in rows),
        "accepted_artifact_operations": sum(
            x["artifact_accepted"] is True for x in operations
        ),
        "unaccepted_artifact_operations": sum(
            x["artifact_accepted"] is False for x in operations
        ),
        "qualification_passed": sum(
            x["qualification_passed"] is True for x in operations
        ),
        "qualification_failed": sum(
            x["qualification_passed"] is False for x in operations
        ),
        "known_cpu_seconds_sum": math.fsum(
            x["cpu_seconds"] for x in rows if x["cpu_seconds"] is not None
        ),
        "accumulated_measured_wall_seconds": math.fsum(
            x["wall_seconds"] for x in rows if x["wall_seconds"] is not None
        ),
        "operations_without_individually_allocated_cpu": sum(
            x["cpu_seconds"] is None for x in operations
        ),
        "operations_without_individually_allocated_wall": sum(
            x["wall_seconds"] is None for x in operations
        ),
        "service_work_units_sum": sum(
            x["service_work_units"] for x in rows if x["service_work_units"] is not None
        ),
        "improvement_work_units_sum": sum(
            x["improvement_work_units"]
            for x in rows
            if x["improvement_work_units"] is not None
        ),
        "operations_with_declared_work_units": sum(
            x["service_work_units"] is not None for x in operations
        ),
        "native_calls_sum": sum(
            x["native_calls"] for x in rows if x["native_calls"] is not None
        ),
        "native_reserved_solve_seconds_sum": sum(
            x["native_reserved_solve_seconds"]
            for x in rows
            if x["native_reserved_solve_seconds"] is not None
        ),
        "fixed_execution_model_calls_observed_sum": sum(
            x["fixed_execution_model_calls"]
            for x in rows
            if x["fixed_execution_model_calls"] is not None
        ),
        "complete_cpu_seconds": None,
        "complete_monetary_cost": None,
        "human_attention_minutes": None,
        "authoring_model_usage_and_cost": None,
        "support_maintenance_deployment_cost": None,
    }


def intervention_records(created: str) -> dict:
    source = ROOT / "development/ROOT_DEVELOPMENT_RECORD.json"
    initial = read(source)
    events = []
    for i, item in enumerate(initial["known_events"], 1):
        events.append(
            {
                "id": f"prefreeze-authoring-{i:02d}",
                "stage": "development",
                "event_type": "documented_authoring_or_implementation_intervention",
                "event": item["event"],
                "response": item["response"],
                "source_path": rel(source),
                "source_index": i - 1,
                "occurred_at": None,
                "human_minutes": None,
                "model_authoring_cost": None,
                "measured_runtime_cost": None,
            }
        )
    plan_source = ROOT / "development/PLANNING_DEVELOPMENT_RECORD.json"
    plan = read(plan_source)
    for item in plan["records"]:
        events.append(
            {
                "id": "development-epoch-" + item["id"],
                "stage": "development",
                "event_type": "development_execution_epoch",
                "event": item["reason"],
                "source_path": item.get(
                    "path", "development/native-oracle-v1/summary.json"
                ),
                "attempts": item["attempts"],
                "accepted": item["accepted_attempts"],
                "measured_wall_seconds": item["observed_outer_seconds"],
                "measured_cpu_seconds": item["observed_cpu_seconds"],
                "cost_accounting": "Already included in LEDGER rows; do not add again",
                "overlap": "The planning epochs expand prefreeze-authoring-07; this is not a count of distinct human interventions",
                "human_minutes": None,
            }
        )
    for phase, base in (
        ("confirmation", ROOT / "raw/controls"),
        ("development", ROOT / "development/controls-v1"),
    ):
        summary = read(base / "summary.json")
        for i, case in enumerate(summary["cases"]):
            events.append(
                {
                    "id": phase + "-control-" + case["case"],
                    "stage": phase,
                    "event_type": "planned_control_or_refusal_test",
                    "event": case["case"],
                    "expected": case.get("expected"),
                    "observed": case.get("observed"),
                    "passed": case["passed"],
                    "source_path": rel(base / "summary.json"),
                    "source_index": i,
                    "cost_accounting": "Included in control_qualification; not an unplanned rescue or another run",
                    "human_minutes": None,
                    "scope": case.get("scope"),
                }
            )
    return {
        "schema": "capability-intervention-register/v1",
        "compiled_at": created,
        "coverage": "Material interventions preserved in development records and planned control tests; not a complete timed record of every authoring, review or publication action",
        "events": events,
        "unexpected_failed_development_attempts": 2,
        "whole_session_human_minutes": None,
        "whole_session_intervention_count": None,
        "unmeasured_activities": [
            "Initial source retrieval, repository inspection, local setup and approval handling",
            "Task, producer, evaluator, protocol and paper authoring with model assistance",
            "Manual examination, debugging and interpretation of evidence",
            "Independent audit reruns of already-created artifacts",
            "Document generation, rendering, visual review and publication packaging",
            "Long-term deployment, customer support and maintenance",
        ],
        "permission_boundary": "Finite local research only. No new spending, credentials, transaction or authenticated operator journal created.",
    }


def main() -> None:
    created = datetime.now(timezone.utc).isoformat()
    freeze_path = ROOT / "protocol/FREEZE.json"
    freeze = read(freeze_path)
    assert len(freeze["files"]) == 110
    for f in freeze["files"]:
        assert digest(ROOT / f["path"]) == f["sha256"], f["path"]
    for phase, prefix in (("confirmation", "raw"), ("development", "development")):
        suffix = "" if phase == "confirmation" else "-v1"
        add_portfolio(ROOT / prefix / ("portfolio" + suffix), phase)
        add_source(ROOT / prefix / ("evidence-mechanism" + suffix), phase)
        add_review(ROOT / prefix / ("review" + suffix), phase)
        add_controls(ROOT / prefix / ("controls" + suffix), phase)
        add_scale(ROOT / prefix / ("scale" + suffix), phase)
    add_planning(ROOT / "raw/planning", "confirmation")
    for name in (
        "planning-v1",
        "planning-v2-approved-process",
        "planning-v3-contention",
    ):
        add_planning(ROOT / "development" / name, "development")
    native_path = ROOT / "development/native-oracle-v1/summary.json"
    for result in read(native_path):
        item = row(
            "development/native-oracle-v1#" + result["family"],
            "development",
            "unmetered_development",
            native_path,
        )
        item.update(
            mission_id=result["family"],
            artifact_accepted=result["accepted"],
            qualification_passed=result["accepted"],
            wall_scope="Unmetered example execution for oracle development",
            cpu_scope="Unmetered example execution for oracle development",
            notes=[
                "Five shipped examples; all execution/setup costs unknown. Not confirmation."
            ],
        )
        ROWS.append(item)
    interventions = intervention_records(created)
    for name, scope in {
        "initial_setup": "Source retrieval, environment audit, operator setup and preparation before recorded timers",
        "model_authoring": "All model-assisted source, test, protocol, analysis and paper authoring; task-time model call count of zero does not price this work",
        "human_attention": "Employer brief preparation, review, supervision and correction; no human-minute observation was obtained",
        "deployment_support_maintenance": "Packaging, installation, integration, operational support, hardware price and future maintenance",
        "research_publication": "Unmetered evaluator self-check, historical artifact review, analysis, independent audit, document rendering and publication operations",
    }.items():
        item = row(
            "project#" + name, "project", "unmeasured_project_costs", freeze_path, 0
        )
        item.update(
            record_type="unmeasured_project_cost",
            wall_scope=scope,
            cpu_scope=scope,
            notes=[scope],
        )
        ROWS.append(item)
    all_paths = {
        rel(p)
        for parent in (ROOT / "raw", ROOT / "development")
        for p in parent.rglob("receipt.json")
    }
    assert all_paths == LEAVES, {
        "missing": sorted(all_paths - LEAVES),
        "extra": sorted(LEAVES - all_paths),
    }
    assert len({x["ledger_id"] for x in ROWS}) == len(ROWS)
    by_phase = {
        p: aggregate([r for r in ROWS if r["phase"] == p])
        for p in ("confirmation", "development", "project")
    }
    assert by_phase["confirmation"]["operations"] == 284
    assert by_phase["development"]["operations"] == 90
    assert by_phase["confirmation"]["primary_sample_size"] == 42
    grouped = defaultdict(list)
    for item in ROWS:
        grouped[(item["phase"], item["account"])].append(item)
    accounts = [
        {"phase": phase, "account": account, **aggregate(values)}
        for (phase, account), values in sorted(grouped.items())
    ]
    summary = read(OUT / "SUMMARY.json")
    planning = read(OUT / "planning.json")
    source = read(ROOT / "raw/evidence-mechanism/summary.json")
    construction = {c["stage"]: c for c in planning["journeys"][0]["construction"]}
    source_cycles = []
    for policy_record in source["policies"]:
        cycle = policy_record["policy"]["cycle"]
        indices = range((cycle - 1) * 4 + 1, cycle * 4 + 1)
        names = {
            name
            for i in indices
            for name in (
                f"evidence-parent-{i:02d}",
                f"evidence-change-{i:02d}-full",
                f"evidence-change-{i:02d}-incremental",
                f"presentation-transfer-{i:02d}",
            )
        } | {f"policy-parent-{cycle}", f"policy-validation-{cycle}"}
        cycle_rows = [
            r
            for r in ROWS
            if r["ledger_id"].startswith("raw/evidence-mechanism/")
            and r["ledger_id"].rsplit("/", 1)[-1] in names
        ]
        assert len(cycle_rows) == 18
        paired_cpu = math.fsum(
            r["cpu_seconds"]
            for r in cycle_rows
            if r["account"] == "source_paired_research"
        )
        assert math.isclose(
            paired_cpu,
            policy_record["discovery_cpu_seconds"],
            rel_tol=1e-12,
            abs_tol=1e-12,
        )
        source_cycles.append(
            {
                "cycle": cycle,
                "observed_operations": 18,
                "paired_search_evaluation_cpu_seconds": paired_cpu,
                "all_18_operations_known_cpu_seconds": math.fsum(
                    r["cpu_seconds"] for r in cycle_rows
                ),
                "all_18_operations_wall_seconds_sum": math.fsum(
                    r["wall_seconds"] for r in cycle_rows
                ),
                "complete_cycle_cost": None,
                "exclusions": "Shared suite overhead is allocated only at suite level. Initial code authorship, setup, human attention, integration and maintenance remain unmeasured.",
                "operation_ids": [r["ledger_id"] for r in cycle_rows],
            }
        )
    scorecard = {
        "schema": "capability-launch-scorecard/v1",
        "compiled_at": created,
        "scope": "Finite local research on frozen bounded templates; does not activate operational authority",
        "useful_delivery": {
            "status": "DEMONSTRATED_WITHIN_CONTRACT",
            "accepted": 42,
            "attempted": 42,
            "source": "analysis/SUMMARY.json",
        },
        "breadth": {
            "families": list(summary["families"]),
            "broad_family_count": len(summary["families"]),
            "bounded_template_count": 8,
            "unsupported_categories": [
                x["case"]
                for x in summary["controls"]["cases"]
                if x.get("delivery") is False
            ],
            "scope": "Template variations, not a sample of eight occupations or general digital work",
        },
        "inheritance": {
            "status": "ACTUAL_PARENT_INVOCATION",
            "planning_lookahead_parent_calls": construction["lookahead"][
                "parent_calls"
            ],
            "planning_repair_parent_calls": construction["repair"]["parent_calls"],
            "source_distinct_retained_module_sources": source[
                "distinct_retained_module_source_count"
            ],
            "source": "analysis/planning.json and raw/evidence-mechanism/*/output/lineage.json",
        },
        "planning_transfer": {
            "quality_counts": planning["transfer_quality_counts"],
            "offered_over_ordinary_cpu_ratio": planning[
                "transfer_cpu_ratio_offered_over_ordinary"
            ],
            "paired_task_bootstrap_95": planning["paired_task_bootstrap_95_interval"],
            "status": "NO_CANDIDATE_ADVANTAGE",
        },
        "source_transfer": {
            "accepted_presentations": 12,
            "incremental_over_full_cpu_ratio": summary["source_mechanism"][
                "incremental_over_full_cpu_ratio"
            ],
            "paired_task_bootstrap_95": summary["source_mechanism"][
                "task_bootstrap_95"
            ],
            "status": "FUNCTIONAL_TRANSFER; COMPUTE_ADVANTAGE_NOT_ESTABLISHED",
        },
        "discovery_efficiency": {
            "cycles": len(source["policies"]),
            "admitted_improvements": sum(
                x["policy"]["admitted_compute_improvement"] for x in source["policies"]
            ),
            "preferred_methods": [
                x["policy"]["preferred_method"] for x in source["policies"]
            ],
            "status": "BOUNDED_STOP_AND_SPECIALIST_RETENTION",
            "cost_scope": "Each reported discovery_cpu_seconds is paired search-evaluation only; LEDGER includes parent, transfer, validation and overhead separately",
        },
        "net_economics": {
            "status": summary["full_economic_admission"],
            "complete_agent_money": None,
            "human_attention_minutes": None,
            "actual_revenue": None,
            "human_market_comparison": summary["human_market_comparison"],
            "empirical_human_trial": summary["empirical_human_trial"],
        },
        "acceleration": {"status": summary["self_acceleration"]},
        "finite_scale": {
            "attempts": 108,
            "accepted": 108,
            "distinct_inputs": 12,
            "median_throughput_ratio_c4_over_c1": summary["scale_ratio_c4_c1"],
            "continuous_service": False,
        },
        "browser_to_approved_executor": {
            "status": summary["controls"]["browser_approved_executor"]
        },
        "publication_status": "See current release/publication records; this scientific scorecard does not assert merge or public deployment",
    }
    metadata = {
        "schema": "capability-measured-cost-ledger/v1",
        "compiled_at": created,
        "freeze_sha256": digest(freeze_path),
        "frozen_files_verified": len(freeze["files"]),
        "builder_sha256": digest(Path(__file__)),
        "scope": "All preserved new-study raw and development receipt operations plus explicitly unmetered development/support accounts; initial setup, complete authoring, human effort and long-term support remain unknown",
        "accounting_rules": [
            "Each leaf receipt is assigned once. Repeated embedded receipts, copied parent packs and summaries are not new operations.",
            "Qualification passes and deliberately rejected requests are separate from useful accepted artifacts; total operation counts are not customer output counts.",
            "Known CPU sums include residual pools only after subtracting costs already allocated to leaf operations.",
            "Accumulated measured wall seconds sums service intervals; concurrent intervals overlap, so this is not total elapsed project time. Resource pools retain complete load batch elapsed times.",
            "Null means unmeasured or inapplicable, never free. Every monetary total, human-minute total and complete CPU total remains null.",
            "Planning service/improvement work units are implementation counters, not CPU seconds or money. Native solve seconds are reservations, not observed solver duration.",
            "Source paired-search CPU excludes useful parent, transfer and validation operations and all pre-authored method construction costs.",
            "Primary accepted deliverable count is 42; one journey is one mixed operating bundle with three plans. Repeated load jobs do not expand diversity.",
        ],
        "totals": aggregate(ROWS),
        "by_phase": by_phase,
        "by_account": accounts,
        "resource_pools": POOLS,
        "source_cycle_accounts": source_cycles,
        "rows": ROWS,
        "coverage": {
            "leaf_receipts_found": len(all_paths),
            "leaf_receipts_assigned_once": len(LEAVES),
            "confirmation_operations": 284,
            "development_operations": 90,
            "unknown_native_development_operations": 5,
            "qualification_case_identity_not_always_leaf_receipt": True,
        },
        "sources": [{"path": p, "sha256": sha} for p, sha in sorted(SOURCES.items())],
    }
    save("LEDGER.json", metadata)
    save("INTERVENTIONS.json", interventions)
    save("LAUNCH_SCORECARD.json", scorecard)
    print(
        json.dumps(
            {
                "records": len(ROWS),
                "by_phase": by_phase,
                "source_receipts": len(LEAVES),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
