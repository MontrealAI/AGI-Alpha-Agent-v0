# SPDX-License-Identifier: Apache-2.0
"""Prospective defect, false-alarm and cost audit for bounded evidence review.

The creator/challenger/adjudicator are fixed contract mechanisms.  This audit
does not claim independent model judgment or count the review fixtures as
productive portfolio missions.
"""

from __future__ import annotations

import argparse
import copy
import datetime as dt
import hashlib
import json
import os
import random
import resource
import subprocess
import time
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
FAULTS = (
    "missing-required",
    "wrong-quote",
    "wrong-source-hash",
    "wrong-url",
    "wrong-section",
    "unrequested-claim",
    "duplicate-claim",
    "wrong-mission",
    "wrong-title",
)


def _save(path: Path, value: Any) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def diagnose(inputs: dict[str, Any], brief: dict[str, Any]) -> set[tuple[str, str]]:
    """Expected criticisms from the registered contract, without producer calls."""
    findings: set[tuple[str, str]] = set()
    if brief.get("mission_id") != inputs["id"]:
        findings.add(("MISSION_BINDING", ""))
    if brief.get("title") != inputs["title"]:
        findings.add(("TITLE_BINDING", ""))
    sources = {row["id"]: row for row in inputs["source_packets"]}
    required = {row["id"]: row for row in inputs["claims"] if row["required"]}
    output = {row["id"]: row for row in brief["claims"]}
    if len(output) != len(brief["claims"]):
        findings.add(("DUPLICATE_CLAIM", ""))
    for identity in output.keys() - required.keys():
        findings.add(("UNREQUESTED_CLAIM", identity))
    for identity, claim in required.items():
        actual = output.get(identity)
        source = sources[claim["source_id"]]
        if actual is None:
            findings.add(("MISSING_REQUIRED", identity))
            continue
        if actual["quote"] != claim["quote"] or actual["quote"] not in source["text"]:
            findings.add(("PASSAGE_MISMATCH", identity))
        if (actual["source_id"], actual["source_sha256"], actual["url"]) != (
            source["id"],
            source["sha256"],
            source["url"],
        ):
            findings.add(("SOURCE_BINDING", identity))
        if actual["section"] != claim["section"]:
            findings.add(("SECTION_MISMATCH", identity))
    return findings


def _clean(
    rng: random.Random, registry: list[dict[str, Any]], identity: str
) -> dict[str, Any]:
    sources, claims, compiled = [], [], []
    for source in rng.sample(registry, 3):
        quote = rng.choice(source["passages"])
        text = "\n\n".join(source["passages"])
        identity_hash = hashlib.sha256(text.encode()).hexdigest()
        sources.append(
            {
                "id": source["id"],
                "url": source["url"],
                "sha256": identity_hash,
                "text": text,
            }
        )
        claim = {
            "id": source["id"] + "-" + identity,
            "source_id": source["id"],
            "quote": quote,
            "required": True,
            "section": source["title"],
        }
        claims.append(claim)
        compiled.append(
            {key: value for key, value in claim.items() if key != "required"}
            | {"url": source["url"], "source_sha256": identity_hash}
        )
    inputs = {
        "id": identity,
        "title": "Source review fixture " + identity,
        "source_packets": sources,
        "claims": claims,
    }
    brief = {
        "schema": "evidence-brief/v1",
        "mission_id": identity,
        "title": inputs["title"],
        "claims": compiled,
        "limits": ["Exact supplied passages only; bounded review fixture."],
    }
    return {"input": inputs, "brief": brief}


def corpus(seed: int) -> list[dict[str, Any]]:
    rng = random.Random(seed)
    registry = json.loads((ROOT / "sources/source_packets.json").read_text())
    clean = [_clean(rng, registry, f"review-{seed}-{index:02d}") for index in range(6)]
    output = [
        {"id": f"clean-{index:02d}", "kind": "clean", "request": item}
        for index, item in enumerate(clean)
    ]
    for fault in FAULTS:
        for index in range(3):
            request = copy.deepcopy(clean[index])
            brief = request["brief"]
            first = brief["claims"][0]
            if fault == "missing-required":
                brief["claims"].pop(0)
            elif fault == "wrong-quote":
                first["quote"] = (
                    "This sentence is an intentionally injected unsupported passage."
                )
            elif fault == "wrong-source-hash":
                first["source_sha256"] = "0" * 64
            elif fault == "wrong-url":
                first["url"] += "?incorrect-source-binding=1"
            elif fault == "wrong-section":
                first["section"] = "Intentionally incorrect section"
            elif fault == "unrequested-claim":
                extra = copy.deepcopy(first)
                extra["id"] = "unrequested-" + str(index)
                brief["claims"].append(extra)
            elif fault == "duplicate-claim":
                brief["claims"].append(copy.deepcopy(first))
            elif fault == "wrong-mission":
                brief["mission_id"] += "-wrong"
            elif fault == "wrong-title":
                brief["title"] += " - wrong title"
            output.append(
                {
                    "id": fault + "-" + str(index),
                    "kind": "seeded-defect",
                    "fault": fault,
                    "request": request,
                }
            )
    for index, item in enumerate(clean):
        request = copy.deepcopy(item)
        claim = request["brief"]["claims"][0]
        request["criticisms"] = [
            {
                "code": "PASSAGE_MISMATCH" if index % 2 else "SOURCE_BINDING",
                "claim_id": claim["id"],
                "evidence": {
                    "assertion": "Authored false alarm; no genuine violated contract"
                },
            }
        ]
        output.append(
            {
                "id": f"false-criticism-{index:02d}",
                "kind": "false-criticism",
                "request": request,
            }
        )
    rng.shuffle(output)
    for case in output:
        expected = diagnose(case["request"]["input"], case["request"]["brief"])
        case["expected_findings"] = [
            {"code": code, "claim_id": identity} for code, identity in sorted(expected)
        ]
        if (case["kind"] == "seeded-defect") != bool(expected):
            raise ValueError(
                "Authored review corpus does not implement its declared condition"
            )
    return output


def _check_freeze(freeze: Path) -> None:
    manifest = json.loads(freeze.read_text())
    for entry in manifest["files"]:
        path = ROOT / entry["path"]
        if hashlib.sha256(path.read_bytes()).hexdigest() != entry["sha256"]:
            raise ValueError("Frozen source changed: " + entry["path"])


def run(seed: int, output: Path, mode: str) -> dict[str, Any]:
    if mode == "confirmation":
        _check_freeze(ROOT / "protocol/FREEZE.json")
    output.mkdir(parents=True, exist_ok=False)
    cases = corpus(seed)
    if mode == "development":
        cases = [
            next(case for case in cases if case["kind"] == "clean"),
            next(case for case in cases if case.get("fault") == "wrong-quote"),
            next(case for case in cases if case.get("fault") == "wrong-mission"),
            next(case for case in cases if case["kind"] == "false-criticism"),
        ]
    _save(output / "corpus.json", cases)
    records = []
    for case in cases:
        destination = output / case["id"]
        destination.mkdir()
        request = case["request"]
        _save(destination / "request.json", request)
        cpu0 = resource.getrusage(resource.RUSAGE_CHILDREN)
        own0 = time.process_time()
        start = time.perf_counter()
        result, error = None, None
        expected = {
            (item["code"], item["claim_id"]) for item in case["expected_findings"]
        }
        try:
            environment = {
                key: value
                for key, value in os.environ.items()
                if key in {"PATH", "SYSTEMROOT", "WINDIR", "TMPDIR"}
            }
            process = subprocess.run(
                ["node", str(ROOT / "src/review_worker.mjs")],
                input=json.dumps(request),
                text=True,
                capture_output=True,
                timeout=10,
                check=False,
                env=environment,
            )
            (destination / "stdout.txt").write_text(process.stdout)
            (destination / "stderr.txt").write_text(process.stderr)
            if process.returncode:
                raise RuntimeError("Review worker exit " + str(process.returncode))
            result = json.loads(process.stdout)
            _save(destination / "result.json", result)
            # Fabricated assertions are adjudicated against a clean artifact;
            # ordinary critic findings must still reflect the actual contract.
            actual = {(item["code"], item["claim_id"]) for item in result["criticisms"]}
            adjudication = result["adjudication"]
            supplied = request.get("criticisms", result["criticisms"])
            verdicts_exact = len(adjudication) == len(supplied) and all(
                verdict["code"] == item["code"]
                and verdict["claim_id"] == item["claim_id"]
                and verdict["substantiated"]
                == ((item["code"], item["claim_id"]) in expected)
                for verdict, item in zip(adjudication, supplied)
            )
            checks = {
                "critic_exact": actual == expected,
                "adjudication_verified": verdicts_exact,
            }
            missed = len(expected - actual)
            false_alarms = len(actual - expected)
        except (
            KeyError,
            ValueError,
            TypeError,
            RuntimeError,
            subprocess.TimeoutExpired,
        ) as caught:
            error = {"type": type(caught).__name__, "message": str(caught)}
            checks = {"completed": False}
            missed, false_alarms = None, None
        cpu1 = resource.getrusage(resource.RUSAGE_CHILDREN)
        record = {
            "id": case["id"],
            "kind": case["kind"],
            "fault": case.get("fault"),
            "accepted": all(checks.values()),
            "checks": checks,
            "error": error,
            "expected_defects": len(expected),
            "missed_defects": missed,
            "false_alarms": false_alarms,
            "wall_seconds": time.perf_counter() - start,
            "child_cpu_seconds": cpu1.ru_utime
            + cpu1.ru_stime
            - cpu0.ru_utime
            - cpu0.ru_stime,
            "supervisor_cpu_seconds": time.process_time() - own0,
            "human_review_minutes": None,
            "complete_cost": None,
            "scope": "Full review subprocess plus independent result inspection; final receipt serialization excluded",
        }
        _save(destination / "receipt.json", record)
        records.append(record)
    summary = {
        "schema": "capability-review-summary/v1",
        "mode": mode,
        "seed": seed,
        "completed_at": dt.datetime.now(dt.timezone.utc).isoformat(),
        "attempts": len(records),
        "passed": sum(record["accepted"] for record in records),
        "clean_cases": sum(record["kind"] == "clean" for record in records),
        "defect_cases": sum(record["kind"] == "seeded-defect" for record in records),
        "false_criticism_cases": sum(
            record["kind"] == "false-criticism" for record in records
        ),
        "missed_defects_observed": sum(
            record["missed_defects"]
            for record in records
            if record["missed_defects"] is not None
        ),
        "false_alarms_observed": sum(
            record["false_alarms"]
            for record in records
            if record["false_alarms"] is not None
        ),
        "unobserved_outcomes": sum(
            record["missed_defects"] is None for record in records
        ),
        "wall_seconds_sum": sum(record["wall_seconds"] for record in records),
        "cpu_seconds_sum": sum(
            record["child_cpu_seconds"] + record["supervisor_cpu_seconds"]
            for record in records
        ),
        "records": records,
        "scientific_delivery_sample_size_contribution": 0,
        "interpretation": "Detection of registered contract faults only; no general semantic-reliability or independent-agent claim",
    }
    _save(output / "summary.json", summary)
    return summary


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--mode", choices=("development", "confirmation"), required=True
    )
    args = parser.parse_args()
    summary = run(args.seed, args.output, args.mode)
    print(
        json.dumps({key: value for key, value in summary.items() if key != "records"})
    )
    return 0 if summary["passed"] == summary["attempts"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
