# SPDX-License-Identifier: Apache-2.0
"""Semantic mutation checks for the independently implemented acceptance rules.

These checks exercise the evaluator using retained development artifacts.  They
are not fresh productive missions and do not enter the scientific sample size.
"""

from __future__ import annotations

import copy
import json
from pathlib import Path
from typing import Any

from native_oracle import accept_native, digest
from plan_oracle import accept_journey, accept_plan


def resign(pack: dict[str, Any]) -> None:
    for artifact in pack["result"]["artifacts"]:
        artifact["digest"] = digest(
            "workbench-artifact",
            {key: value for key, value in artifact.items() if key != "digest"},
        )
    pack["integrityDigest"] = digest(
        "workbench-pack",
        {key: value for key, value in pack.items() if key != "integrityDigest"},
    )


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    development = root / "development"
    observations = []
    mutations = {
        "reliability": ("contains.mjs", lambda text: text.replace("low <=", "low <")),
        "documentation": (
            "checked-examples.md",
            lambda text: text.replace("hello%20world", "invented"),
        ),
        "public-data": (
            "analysis.json",
            lambda text: json.dumps({**json.loads(text), "total": -12345}),
        ),
        "numerical": (
            "numerical.json",
            lambda text: json.dumps({**json.loads(text), "analytic": "999/1"}),
        ),
        "performance": (
            "benchmark.json",
            lambda text: json.dumps({**json.loads(text), "output": [999]}),
        ),
    }
    for family, (name, mutate) in mutations.items():
        prefix = development / "native-oracle-v1"
        brief = json.loads((prefix / (family + "-spec.json")).read_text())
        pack = json.loads((prefix / (family + "-pack.json")).read_text())
        valid = accept_native(brief, pack)
        damaged = copy.deepcopy(pack)
        artifact = next(
            item for item in damaged["result"]["artifacts"] if item["name"] == name
        )
        artifact["content"] = mutate(artifact["content"])
        resign(damaged)
        invalid = accept_native(brief, damaged)
        observations.append(
            {
                "family": family,
                "valid_accepted": valid["accepted"],
                "resigned_semantic_defect_rejected": not invalid["accepted"],
                "failed_checks": invalid["failed_checks"],
            }
        )
    prefix = development / "planning-v3-contention" / "connected-release-8102027"
    payload = json.loads((prefix / "request.json").read_text())["payload"]
    outcome = json.loads((prefix / "worker-result.json").read_text())
    valid_journey = accept_journey(payload, outcome)
    phase = outcome["result"]["phases"][2]
    damaged_plan = copy.deepcopy(phase["result"])
    damaged_plan["movement"] += 1
    rejected_movement = accept_plan(phase["task"], damaged_plan)
    damaged_journey = copy.deepcopy(outcome)
    damaged_journey["result"]["phases"][2]["task"]["baseline"]["J6"] += 1
    rejected_lineage = accept_journey(payload, damaged_journey)
    observations.append(
        {
            "family": "planning",
            "valid_accepted": valid_journey["accepted"],
            "false_movement_rejected": not rejected_movement["accepted"],
            "false_parent_baseline_rejected": not rejected_lineage["accepted"],
        }
    )
    passed = all(
        all(
            value
            for key, value in row.items()
            if key.endswith("accepted") or key.endswith("rejected")
        )
        for row in observations
    )
    result = {
        "schema": "capability-evaluator-development-check/v1",
        "passed": passed,
        "observations": observations,
        "scientific_sample_size_contribution": 0,
        "scope": "Evaluator development mutation checks; no claims of external independence",
    }
    destination = development / "evaluator-selfcheck.json"
    if destination.exists():
        raise FileExistsError(
            "Preserve the previous evaluator selfcheck; choose an additive new filename"
        )
    destination.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
