# SPDX-License-Identifier: Apache-2.0
"""Independent exact-passage acceptance for source briefs and presentation decks.

The contract is deliberately bounded: selected, supplied source passages are
assembled with exact provenance.  This does not assess free-form semantic
synthesis, source truth, comprehensive research, or expert editorial judgment.
"""

from __future__ import annotations

import hashlib
import json
from html.parser import HTMLParser
from typing import Any

from native_oracle import digest


class VisibleHTML(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.text: list[str] = []
        self.links: list[str] = []
        self.executable = False
        self.headings = 0
        self.hidden_tags: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        properties = dict(attrs)
        if tag in ("head", "style", "script", "template"):
            self.hidden_tags.append(tag)
        if tag == "a" and properties.get("href"):
            self.links.append(str(properties["href"]))
        if tag in ("script", "iframe", "object", "embed") or any(
            key.startswith("on") for key in properties
        ):
            self.executable = True
        if tag in ("h1", "h2", "h3"):
            self.headings += 1

    def handle_data(self, data: str) -> None:
        if not self.hidden_tags:
            self.text.append(data)

    def handle_endtag(self, tag: str) -> None:
        if tag in self.hidden_tags:
            self.hidden_tags.remove(tag)


def _sha(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def expected_claims(inputs: dict[str, Any]) -> list[dict[str, Any]]:
    packets = {source["id"]: source for source in inputs["source_packets"]}
    output = []
    for claim in inputs["claims"]:
        if not claim["required"]:
            continue
        source = packets[claim["source_id"]]
        output.append(
            {
                "id": claim["id"],
                "source_id": claim["source_id"],
                "quote": claim["quote"],
                "section": claim["section"],
                "source_sha256": source["sha256"],
                "url": source["url"],
            }
        )
    return output


def accept_evidence(
    spec: dict[str, Any],
    pack: dict[str, Any],
    parent_pack: dict[str, Any] | None = None,
) -> dict[str, Any]:
    checks: dict[str, bool] = {}
    details: dict[str, Any] = {}
    try:
        inputs = spec["inputs"]
        checks["supported_family"] = spec["family"] in (
            "evidence-brief",
            "evidence-deck",
        )
        checks["external_brief_binding"] = pack["spec"] == spec
        checks["input_claim_bound"] = 1 <= len(inputs["claims"]) <= 64
        checks["unique_input_claim_ids"] = len(
            {claim["id"] for claim in inputs["claims"]}
        ) == len(inputs["claims"])
        sources = {source["id"]: source for source in inputs["source_packets"]}
        checks["unique_source_ids"] = len(sources) == len(inputs["source_packets"])
        checks["source_text_size_bound"] = (
            sum(len(source["text"].encode()) for source in sources.values()) <= 200_000
        )
        for identity, source in sources.items():
            checks["source_hash_" + identity] = _sha(source["text"]) == source["sha256"]
            checks["source_url_" + identity] = isinstance(
                source["url"], str
            ) and source["url"].startswith("https://")
        for claim in inputs["claims"]:
            checks["source_passage_" + claim["id"]] = (
                claim["source_id"] in sources
                and bool(claim["quote"])
                and claim["quote"] in sources[claim["source_id"]]["text"]
            )
        artifacts = pack["result"]["artifacts"]
        files = {artifact["name"]: artifact["content"] for artifact in artifacts}
        checks["unique_artifacts"] = len(files) == len(artifacts)
        checks["pack_hash"] = pack["integrityDigest"] == digest(
            "workbench-pack",
            {key: value for key, value in pack.items() if key != "integrityDigest"},
        )
        for artifact in artifacts:
            body = {key: value for key, value in artifact.items() if key != "digest"}
            checks["artifact_hash_" + artifact["name"]] = artifact["digest"] == digest(
                "workbench-artifact", body
            )
        brief = json.loads(files["brief.json"])
        checks["brief_schema"] = brief["schema"] == "evidence-brief/v1"
        checks["mission_id"] = brief["mission_id"] == inputs["id"]
        checks["title"] = brief["title"] == inputs["title"]
        expected = expected_claims(inputs)
        checks["exact_required_claims_no_additions"] = brief["claims"] == expected
        checks["limits_declared"] = isinstance(brief.get("limits"), list) and bool(
            brief["limits"]
        )
        for name in (
            ["brief.html", "slides.html"]
            if spec["family"] == "evidence-deck"
            else ["brief.html"]
        ):
            parser = VisibleHTML()
            parser.feed(files[name])
            visible = " ".join(" ".join(parser.text).split())
            checks[name + "_title_visible"] = (
                " ".join(inputs["title"].split()) in visible
            )
            checks[name + "_all_quotes_visible"] = all(
                " ".join(claim["quote"].split()) in visible for claim in expected
            )
            checks[name + "_all_citations_linked"] = all(
                claim["url"] in parser.links for claim in expected
            )
            checks[name + "_no_executable_content"] = not parser.executable
            checks[name + "_readable_structure"] = parser.headings >= 1
        checks["empty_current_authority"] = (
            pack["evaluation"]["authority"] == [] and pack["frozen"]["authority"] == []
        )
        checks["no_settlement"] = pack["evaluation"]["settlement"] == "NOT_CONNECTED"
        checks["unknown_costs_not_zero"] = (
            pack["economics"]["computeCost"] is None
            and pack["economics"]["humanMinutes"] is None
        )
        details.update(
            claim_count=len(expected),
            source_count=len(sources),
            brief_sha256=_sha(files["brief.json"]),
        )
        if parent_pack is not None:
            parent_files = {
                item["name"]: item["content"]
                for item in parent_pack["result"]["artifacts"]
            }
            parent_brief = json.loads(parent_files["brief.json"])
            parent_claims = {claim["id"]: claim for claim in parent_brief["claims"]}
            reusable = [
                claim["id"]
                for claim in expected
                if parent_claims.get(claim["id"]) == claim
            ]
            changed = [claim["id"] for claim in expected if claim["id"] not in reusable]
            old_sources = {
                source["id"]: source
                for source in parent_pack["spec"]["inputs"]["source_packets"]
            }
            changed_sources = sorted(
                identity
                for identity in sources.keys() | old_sources.keys()
                if sources.get(identity) != old_sources.get(identity)
            )
            canonical_parent = json.dumps(
                parent_brief, ensure_ascii=False, sort_keys=True, separators=(",", ":")
            )
            details.update(
                expected_reused_claim_ids=reusable,
                expected_recompiled_claim_ids=changed,
                expected_changed_source_ids=changed_sources,
                parent_brief_sha256=_sha(canonical_parent),
                parent_brief_file_sha256=_sha(parent_files["brief.json"]),
            )
            checks["parent_lineage_present"] = "lineage.json" in files
            if "lineage.json" in files:
                lineage = json.loads(files["lineage.json"])
                # These transparent fields bind reuse to actual data. Extra
                # policy/accounting fields remain allowed but cannot substitute.
                checks["parent_brief_hash_exact"] = (
                    lineage["parent_brief_sha256"] == details["parent_brief_sha256"]
                )
                checks["parent_brief_file_hash_exact"] = (
                    lineage["parent_brief_file_sha256"]
                    == details["parent_brief_file_sha256"]
                )
                checks["actual_parent_claim_reads_exact"] = lineage[
                    "actual_parent_claim_reads"
                ] == len(parent_brief["claims"])
                checks["reused_claims_exact"] = lineage["reused_claim_ids"] == reusable
                checks["recompiled_claims_exact"] = (
                    lineage["recompiled_claim_ids"] == changed
                )
                checks["changed_sources_exact"] = (
                    sorted(lineage["changed_source_ids"]) == changed_sources
                )
    except (KeyError, ValueError, TypeError, IndexError, UnicodeError):
        checks["evaluation_completed"] = False
    return {
        "schema": "capability-evidence-acceptance/v1",
        "accepted": bool(checks) and all(checks.values()),
        "checks": checks,
        "failed_checks": [key for key, value in checks.items() if not value],
        "details": details,
        "scope": "Exact supplied passages and artifact provenance; no free-form semantic or external human acceptance",
    }
