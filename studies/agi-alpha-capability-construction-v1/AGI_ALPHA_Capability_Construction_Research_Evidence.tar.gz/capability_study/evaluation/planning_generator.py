# SPDX-License-Identifier: Apache-2.0
"""Prospective fresh, synthetic planning briefs for the existing Strategy worker.

Generation does not execute a solver or inspect candidate outcomes.  The task
families are project-planning contexts, not independent occupations.  Durations
are abstract planning slots supplied as scenario inputs, never human task-time
observations.
"""

from __future__ import annotations

import argparse
import copy
import json
import random
from pathlib import Path
from typing import Any


def _task(
    rng: random.Random, identity: str, count: int, context: str
) -> dict[str, Any]:
    jobs = []
    for index in range(count):
        dependencies: list[str] = []
        if index >= 2:
            dependencies.append("J" + str(index - 1))
        if index >= 4 and rng.random() < 0.4:
            earlier = "J" + str(rng.randrange(1, index - 1))
            if earlier not in dependencies:
                dependencies.append(earlier)
        jobs.append(
            {
                "id": f"J{index + 1}",
                "duration": rng.randint(1, 4),
                "crew": 1 if index % 3 else 2,
                "deps": dependencies,
            }
        )
    horizon = sum(job["duration"] for job in jobs) + 12
    capacity = [3] * horizon
    # A known nonbinding early reduction changes calendar shape, while a serial
    # schedule remains possible.  This is a constraint-variation design, not a
    # hard scheduling benchmark selected after a win.
    capacity[-3:] = [2, 2, 2]
    return {
        "schema": "release-plan/v1",
        "id": identity,
        "kind": "plan",
        "jobs": jobs,
        "capacity": capacity,
        "deadline": horizon - 3,
        "release": {},
        "public_or_synthetic": "synthetic",
        "planning_only": True,
        "project_id": context,
        "input_license": "CC0 synthetic research scenario",
    }


def planning_cases(seed: int) -> list[dict[str, Any]]:
    rng = random.Random(seed)
    contexts = [
        "software-release",
        "research-publication",
        "service-migration",
        "editorial-release",
        "data-delivery",
        "operations-handover",
    ]
    output = []
    for index, context in enumerate(contexts):
        count = [6, 9, 12][index // 2]
        task = _task(rng, f"planning-{index + 1:02d}-{seed}", count, context)
        output.append(
            {
                "id": task["id"],
                "family": "planning-and-operations",
                "complexity": ["low", "medium", "high"][index // 2],
                "context": context,
                "brief": "Produce a usable resource-constrained schedule meeting dependencies, releases and the stated deadline; retain alternative attempts and explicit limitations.",
                "task": task,
            }
        )
    return output


def journey_case(seed: int) -> dict[str, Any]:
    rng = random.Random(seed)
    # Three parallel preparations feed an integration and two release steps.
    # Only this separately registered authored topology seeds construction.
    initial = {
        "schema": "release-plan/v1",
        "id": f"connected-release-{seed}",
        "kind": "plan",
        "jobs": [
            {"id": "J1", "duration": 2 + rng.randrange(2), "crew": 1, "deps": []},
            {"id": "J2", "duration": 3 + rng.randrange(2), "crew": 2, "deps": []},
            {"id": "J3", "duration": 2 + rng.randrange(2), "crew": 2, "deps": []},
            {"id": "J4", "duration": 4, "crew": 2, "deps": ["J2"]},
            {"id": "J5", "duration": 3, "crew": 2, "deps": ["J3", "J4"]},
            {"id": "J6", "duration": 2, "crew": 1, "deps": ["J5"]},
        ],
        "capacity": [3] * 36,
        "deadline": 28,
        "release": {},
        "public_or_synthetic": "synthetic",
        "planning_only": True,
        "project_id": "public-evidence-release",
        "input_license": "CC0 synthetic research scenario",
    }
    capacity = [3] * 36
    # The future zero-capacity window necessarily interrupts a sufficiently long
    # dependency chain.  Starts before slot 1 are locked by the real worker.
    # It does not alter the slot already observed and does not claim physical
    # execution.  Whether the preceding schedule is damaged is measured later.
    capacity[8:11] = [0, 0, 0]
    return {
        "id": initial["id"],
        "brief": "Plan a public-evidence release; adapt to a longer integration step; repair the actual preceding plan after a future service window becomes unavailable, preserving its already-started prefix.",
        "job_labels": {
            "J1": "inventory sources",
            "J2": "verify analysis",
            "J3": "prepare citations",
            "J4": "assemble report",
            "J5": "review release",
            "J6": "package handoff",
        },
        "payload": {
            "initial": initial,
            "changes": {"durations": {"J4": 5}, "deadline": 30},
            "repair": {
                "observed_at": 1,
                "capacity": capacity,
                "deadline": 34,
                "movement_limit": 180,
            },
            "construction": {"enabled": True},
        },
    }


def repair_transfers(seed: int) -> list[dict[str, Any]]:
    rng = random.Random(seed)
    contexts = [
        "service-migration",
        "research-delivery",
        "editorial-update",
        "data-handover",
    ]
    output = []
    for index in range(12):
        count = 4 + index % 3
        task = _task(
            rng, f"repair-transfer-{index + 1:02d}-{seed}", count, contexts[index % 4]
        )
        # The historical artifact is a feasible conservative serial plan.  It is
        # supplied, not inferred from a candidate being evaluated.  The changed
        # release requirement forces a nonzero repair on an unlocked suffix.
        starts: dict[str, int] = {}
        clock = 0
        schedule = []
        for job in task["jobs"]:
            starts[job["id"]] = clock
            schedule.append(
                {"id": job["id"], "start": clock, "end": clock + job["duration"]}
            )
            clock += job["duration"]
        parent = copy.deepcopy(task)
        target = task["jobs"][2]["id"]
        task.update(
            kind="repair",
            baseline=starts,
            locked={"J1": 0},
            release={target: starts[target] + 1 + index % 3},
            movement_limit=180,
        )
        output.append(
            {
                "id": task["id"],
                "family": "planning-repair-transfer",
                "context": contexts[index % 4],
                "task": task,
                "parent": {"task": parent, "schedule": schedule},
                "change": {
                    "kind": "later-input-release",
                    "job_id": target,
                    "previous": 0,
                    "current": task["release"][target],
                },
                "scope": "Fresh planning context and graph; no physical task completion observed",
            }
        )
    return output


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    bundle = {
        "schema": "capability-planning-corpus/v1",
        "seed": args.seed,
        "planning": planning_cases(args.seed),
        "journey": journey_case(args.seed + 1),
        "transfers": repair_transfers(args.seed + 2),
    }
    (args.output / "planning-corpus.json").write_text(
        json.dumps(bundle, indent=2) + "\n"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
