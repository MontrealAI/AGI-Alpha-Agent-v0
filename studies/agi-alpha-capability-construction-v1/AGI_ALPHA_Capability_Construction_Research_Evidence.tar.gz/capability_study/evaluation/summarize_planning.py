# SPDX-License-Identifier: Apache-2.0
"""Prospectively specified descriptive planning and paired-transfer analysis."""

from __future__ import annotations

import argparse
import json
import random
import statistics
from pathlib import Path
from typing import Any

from plan_oracle import accept_plan


def describe(values: list[float]) -> dict[str, Any]:
    if not values:
        return {
            "n": 0,
            "sum": None,
            "median": None,
            "mean": None,
            "min": None,
            "max": None,
        }
    return {
        "n": len(values),
        "sum": sum(values),
        "median": statistics.median(values),
        "mean": statistics.mean(values),
        "min": min(values),
        "max": max(values),
    }


def _quality(task: dict[str, Any], attempt: dict[str, Any]) -> tuple[int, int, int]:
    result = attempt.get("result")
    if result is None or not accept_plan(task, result)["accepted"]:
        return (1, 10**9, 10**9)
    return (0, result["movement"], result["makespan"])


def summarize(root: Path) -> dict[str, Any]:
    summary = json.loads((root / "summary.json").read_text())
    receipts = summary["receipts"]
    primary = [row for row in receipts if row["id"].startswith("planning-")]
    transfers: dict[str, dict[str, Any]] = {}
    for row in receipts:
        if row["id"].startswith("repair-transfer-"):
            identity = (
                row["id"]
                .removesuffix("-ordinary-native")
                .removesuffix("-retained-offered")
            )
            transfers.setdefault(identity, {})[row["arm"]] = row
    paired = []
    for identity, arms in sorted(transfers.items()):
        if set(arms) != {"ordinary-native", "retained-offered"}:
            paired.append({"id": identity, "status": "INCOMPLETE_PAIR"})
            continue
        offered = arms["retained-offered"]
        ordinary = arms["ordinary-native"]
        result_path = root / offered["id"] / "worker-result.json"
        if not result_path.exists():
            paired.append(
                {
                    "id": identity,
                    "status": "INCOMPLETE_PAIR_RESULT",
                    "both_accepted": False,
                }
            )
            continue
        outcome = json.loads(result_path.read_text())
        phase = outcome["result"]["phases"][0]
        candidate = next(
            (
                attempt
                for attempt in phase["attempts"]
                if attempt["method"] == "retained-qualified-trial"
            ),
            None,
        )
        alternatives = [
            attempt
            for attempt in phase["attempts"]
            if attempt["method"] != "retained-qualified-trial"
        ]
        specialist = min(
            alternatives, key=lambda attempt: _quality(phase["task"], attempt)
        )
        if candidate is None:
            relation = "NOT_TRIALLED"
        else:
            left, right = _quality(phase["task"], candidate), _quality(
                phase["task"], specialist
            )
            relation = (
                "UNQUALIFIED_BOTH"
                if left[0] and right[0]
                else "TIE" if left == right else "WIN" if left < right else "LOSS"
            )
        paired.append(
            {
                "id": identity,
                "status": "COMPLETE_PAIR",
                "both_accepted": offered["accepted"] and ordinary["accepted"],
                "candidate_relation_to_strongest_available": relation,
                "selected_method": phase["selected_method"],
                "strongest_reference": specialist["method"],
                "ordinary_wall_seconds": ordinary["outer_wall_seconds"],
                "offered_wall_seconds": offered["outer_wall_seconds"],
                "ordinary_cpu_seconds": ordinary.get("cpu_seconds"),
                "offered_cpu_seconds": offered.get("cpu_seconds"),
                "candidate_work_units": candidate.get("work") if candidate else None,
            }
        )
    complete = [row for row in paired if row["status"] == "COMPLETE_PAIR"]
    ratio = None
    interval = None
    if complete and all(
        row["ordinary_cpu_seconds"] is not None
        and row["offered_cpu_seconds"] is not None
        for row in complete
    ):
        ratio = sum(row["offered_cpu_seconds"] for row in complete) / sum(
            row["ordinary_cpu_seconds"] for row in complete
        )
        rng = random.Random(29012026)
        samples = []
        for _ in range(2000):
            selected = [rng.choice(complete) for _ in complete]
            samples.append(
                sum(row["offered_cpu_seconds"] for row in selected)
                / sum(row["ordinary_cpu_seconds"] for row in selected)
            )
        samples.sort()
        interval = [samples[49], samples[1949]]
    journeys = []
    for row in receipts:
        if row.get("method") != "run-journey":
            continue
        path = root / row["id"] / "worker-result.json"
        if not path.exists():
            journeys.append({"id": row["id"], "accepted": False})
            continue
        outcome = json.loads(path.read_text())["result"]
        construction = []
        for entry in outcome.get("capabilities", []):
            asset = entry.get("asset")
            if asset:
                construction.append(
                    {
                        "stage": entry["stage"],
                        "decision": entry["decision"],
                        "digest": asset["digest"],
                        "parent_digest": asset["parent_digest"],
                        "parent_reads": entry["lineage"]["parent_read"],
                        "parent_calls": entry["lineage"]["parent_calls"],
                        "construction_work_units": entry["construction_work"],
                        "candidate_trials": len(
                            entry.get("search", {}).get("trials", [])
                        ),
                    }
                )
        journeys.append(
            {
                "id": row["id"],
                "accepted": row["accepted"],
                "outer_wall_seconds": row["outer_wall_seconds"],
                "cpu_seconds": row.get("cpu_seconds"),
                "construction": construction,
                "phases": [
                    {
                        "label": phase["label"],
                        "selected_method": phase["selected_method"],
                        "qualified": phase["qualified"],
                        "makespan": (phase.get("result") or {}).get("makespan"),
                        "movement": (phase.get("result") or {}).get("movement"),
                    }
                    for phase in outcome["phases"]
                ],
                "repair_relation_to_strongest_available": outcome.get(
                    "repair_usefulness", {}
                ).get("consequence"),
                "parent_diagnostics": outcome.get("inheritance", {}).get(
                    "diagnostics", []
                ),
            }
        )
    return {
        "schema": "capability-planning-analysis/v1",
        "primary_jobs": len(primary),
        "primary_accepted": sum(row["accepted"] for row in primary),
        "primary_wall_seconds": describe(
            [row["outer_wall_seconds"] for row in primary]
        ),
        "primary_cpu_seconds": describe(
            [
                row["cpu_seconds"]
                for row in primary
                if row.get("cpu_seconds") is not None
            ]
        ),
        "journeys": journeys,
        "fresh_transfer_instances": len(transfers),
        "transfer_attempts": sum(len(arms) for arms in transfers.values()),
        "transfer_quality_counts": {
            key: sum(
                row.get("candidate_relation_to_strongest_available") == key
                for row in complete
            )
            for key in ("WIN", "TIE", "LOSS", "NOT_TRIALLED", "UNQUALIFIED_BOTH")
        },
        "transfer_cpu_ratio_offered_over_ordinary": ratio,
        "paired_task_bootstrap_95_interval": interval,
        "paired_bootstrap_repetitions": 2000,
        "paired_bootstrap_scope": "Descriptive sample uncertainty; shared-host systematic variation and complete money/attention unknown",
        "pairs": paired,
        "complete_cost_advantage": "NOT_ESTABLISHED",
        "self_acceleration": "NOT_ESTABLISHED",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("raw", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(
            "Preserve the previous analysis; choose a new output path"
        )
    result = summarize(args.raw)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            {
                key: value
                for key, value in result.items()
                if key not in ("journeys", "pairs")
            }
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
