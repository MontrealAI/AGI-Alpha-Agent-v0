# SPDX-License-Identifier: Apache-2.0
"""Independent feasibility, objective and lineage checks for release-plan/v1.

No worker, scheduling heuristic or optimizer is imported.  The complete artifact
is judged against the supplied task.  Optimality is asserted only when the
reported makespan equals a separately derived valid bound, not from solver status.
"""

from __future__ import annotations

import copy
import hashlib
import json
from typing import Any


def _canonical(value: Any) -> bytes:
    return json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode()


def _hash(value: Any) -> str:
    return hashlib.sha256(_canonical(value)).hexdigest()


def accept_plan(task: dict[str, Any], result: dict[str, Any] | None) -> dict[str, Any]:
    checks: dict[str, bool] = {}
    details: dict[str, Any] = {}
    try:
        jobs = {job["id"]: job for job in task["jobs"]}
        capacity = task["capacity"]
        horizon = len(capacity)
        checks["unique_job_ids"] = len(jobs) == len(task["jobs"])
        checks["bounded_input_scope"] = (
            task["schema"] == "release-plan/v1"
            and 1 <= len(jobs) <= 18
            and 1 <= horizon <= 128
            and task["planning_only"] is True
            and task["public_or_synthetic"] in ("synthetic", "public")
        )
        checks["capacity_integers"] = all(
            type(value) is int and 0 <= value <= 4 for value in capacity
        )
        checks["job_contracts"] = all(
            type(job["duration"]) is int
            and 1 <= job["duration"] <= 12
            and type(job["crew"]) is int
            and 1 <= job["crew"] <= 4
            and len(job["deps"]) == len(set(job["deps"]))
            and set(job["deps"]) <= jobs.keys()
            for job in jobs.values()
        )
        topological: list[str] = []
        pending = set(jobs)
        while pending:
            ready = sorted(
                identity
                for identity in pending
                if set(jobs[identity]["deps"]) <= set(topological)
            )
            if not ready:
                break
            topological.extend(ready)
            pending.difference_update(ready)
        checks["acyclic_dependencies"] = not pending
        if pending or not all(checks.values()):
            raise ValueError("Invalid declared task")
        release = task.get("release", {})
        locked = task.get("locked", {})
        baseline = task.get("baseline", {})
        earliest = {}
        for identity in topological:
            job = jobs[identity]
            begin = max(
                [release.get(identity, 0)]
                + [earliest[parent] for parent in job["deps"]]
            )
            if identity in locked:
                checks["valid_lock_precedence_" + identity] = locked[identity] >= begin
                begin = locked[identity]
            earliest[identity] = begin + job["duration"]
        work = sum(job["crew"] * job["duration"] for job in jobs.values())
        cumulative = 0
        load_bound = None
        for position, slots in enumerate(capacity):
            cumulative += slots
            if cumulative >= work:
                load_bound = position + 1
                break
        checks["enough_total_capacity"] = load_bound is not None
        bound = {
            "critical": max(earliest.values()),
            "load": load_bound,
            "locked": max(
                (locked[identity] + jobs[identity]["duration"] for identity in locked),
                default=0,
            ),
        }
        bound["value"] = max(value for value in bound.values() if value is not None)
        details["independent_lower_bound"] = bound
        if not isinstance(result, dict):
            checks["result_present"] = False
            raise ValueError("No delivered plan")
        checks["result_identity"] = (
            result["schema"] == "release-plan-result/v1"
            and result["task_id"] == task["id"]
        )
        schedule = {row["id"]: row for row in result["schedule"]}
        checks["all_jobs_once"] = len(schedule) == len(result["schedule"]) and set(
            schedule
        ) == set(jobs)
        if not checks["all_jobs_once"]:
            raise ValueError("Incomplete schedule")
        usage = [0] * horizon
        for identity, row in schedule.items():
            job = jobs[identity]
            valid = (
                type(row["start"]) is int
                and type(row["end"]) is int
                and row["start"] >= release.get(identity, 0)
                and row["end"] == row["start"] + job["duration"]
                and 0 <= row["start"] < row["end"] <= horizon
            )
            checks["interval_" + identity] = valid
            if valid:
                for slot in range(row["start"], row["end"]):
                    usage[slot] += job["crew"]
            checks["dependencies_" + identity] = all(
                schedule[parent]["end"] <= row["start"] for parent in job["deps"]
            )
            if identity in locked:
                checks["preserved_lock_" + identity] = (
                    row["start"] == locked[identity] == baseline[identity]
                )
                checks["closed_lock_prefix_" + identity] = (
                    set(job["deps"]) <= locked.keys()
                )
        checks["resource_capacity"] = all(
            used <= limit for used, limit in zip(usage, capacity)
        )
        makespan = max(row["end"] for row in schedule.values())
        movement = sum(
            abs(row["start"] - baseline[identity])
            for identity, row in schedule.items()
            if identity in baseline
        )
        checks["makespan_exact"] = result["makespan"] == makespan
        checks["movement_exact"] = result["movement"] == movement
        checks["bound_exact"] = result["lower_bound"] == bound
        checks["optimality_claim_supported"] = result["optimal_by_lower_bound"] == (
            makespan == bound["value"]
        )
        checks["empty_current_proof_and_authority"] = (
            result["proof"] == [] and result["authority"] == []
        )
        checks["deadline_met"] = makespan <= task.get("deadline", horizon)
        checks["movement_limit_met"] = movement <= task.get("movement_limit", 2304)
        details.update(makespan=makespan, movement=movement, usage=usage)
    except (KeyError, ValueError, TypeError, IndexError):
        checks["evaluation_completed"] = False
    return {
        "schema": "capability-plan-acceptance/v1",
        "accepted": bool(checks) and all(checks.values()),
        "checks": checks,
        "failed_checks": [key for key, value in checks.items() if not value],
        "details": details,
        "scope": "Independent schedule feasibility and honest bounds, not physical execution",
    }


def accept_journey(
    payload: dict[str, Any], worker_result: dict[str, Any]
) -> dict[str, Any]:
    checks: dict[str, bool] = {}
    phases = worker_result.get("result", worker_result).get("phases", [])
    reports = []
    try:
        checks["three_phases_delivered"] = len(phases) == 3
        if len(phases) != 3:
            raise ValueError("Incomplete journey")
        expected_initial = payload["initial"]
        checks["initial_brief_exact"] = phases[0]["task"] == expected_initial
        expected_changed = copy.deepcopy(expected_initial)
        expected_changed["id"] = expected_changed["id"][:110] + "-changed"
        for source, destination in (("durations", "duration"), ("crew", "crew")):
            for identity, value in payload["changes"].get(source, {}).items():
                next(job for job in expected_changed["jobs"] if job["id"] == identity)[
                    destination
                ] = value
        for field in ("capacity", "release", "deadline"):
            if field in payload["changes"]:
                expected_changed[field] = payload["changes"][field]
        checks["changed_brief_exact"] = phases[1]["task"] == expected_changed
        changed_schedule = phases[1]["result"]["schedule"]
        repair = payload["repair"]
        expected_repair = copy.deepcopy(expected_changed)
        expected_repair.update(
            kind="repair", id=expected_repair["id"][:110] + "-repair"
        )
        expected_repair["baseline"] = {
            row["id"]: row["start"] for row in changed_schedule
        }
        expected_repair["locked"] = {
            row["id"]: row["start"]
            for row in changed_schedule
            if row["start"] < repair["observed_at"]
        }
        prior_release = expected_repair.get("release", {})
        expected_repair["release"] = {
            job["id"]: (
                prior_release.get(job["id"], 0)
                if job["id"] in expected_repair["locked"]
                else max(prior_release.get(job["id"], 0), repair["observed_at"])
            )
            for job in expected_repair["jobs"]
        }
        for field in ("capacity", "deadline", "movement_limit"):
            if field in repair:
                expected_repair[field] = repair[field]
        expected_repair["disruption"] = {
            "observed_at": repair["observed_at"],
            "completed_jobs": [
                row["id"]
                for row in changed_schedule
                if row["end"] <= repair["observed_at"]
            ],
            "in_progress_jobs": [
                row["id"]
                for row in changed_schedule
                if row["start"] < repair["observed_at"] < row["end"]
            ],
        }
        checks["repair_uses_actual_parent_artifact"] = (
            phases[2]["task"] == expected_repair
        )
        for index, phase in enumerate(phases):
            report = accept_plan(phase["task"], phase["result"])
            reports.append(report)
            checks[f"phase_{index}_accepted"] = report["accepted"]
            checks[f"phase_{index}_receipt_hash"] = (
                _hash(phase["receipt"]) == phase["receipt_hash"]
            )
            checks[f"phase_{index}_receipt_binding"] = (
                phase["receipt"]["task"] == phase["task"]
                and phase["receipt"]["result"] == phase["result"]
            )
        source = phases[2]["baseline_source"]
        checks["actual_parent_receipt_named"] = (
            source["receipt_hash"] == phases[1]["receipt_hash"]
        )
        checks["actual_parent_task_named"] = source["task_id"] == phases[1]["task_id"]
        checks["past_calendar_preserved"] = (
            phases[2]["task"]["capacity"][: repair["observed_at"]]
            == phases[1]["task"]["capacity"][: repair["observed_at"]]
        )
        retained = [
            entry.get("asset")
            for entry in worker_result.get("result", worker_result).get(
                "capabilities", []
            )
            if entry.get("asset")
        ]
        checks["capabilities_do_not_self_authorize"] = all(
            asset["authority"] == []
            and asset["proof"] == []
            and asset["active"] is False
            and asset["production_authority"] is False
            for asset in retained
        )
    except (KeyError, ValueError, TypeError, IndexError):
        checks["journey_evaluation_completed"] = False
    return {
        "schema": "capability-journey-acceptance/v1",
        "accepted": bool(checks) and all(checks.values()),
        "checks": checks,
        "failed_checks": [key for key, value in checks.items() if not value],
        "phases": reports,
        "scope": "Actual preceding scheduling artifact and prefix retained; physical completion is not observed",
    }
