# SPDX-License-Identifier: Apache-2.0
"""Run the unchanged, pinned Strategy worker with independent study acceptance.

No Journal, key, credential or network service is initialized.  This is a finite
local research execution; it cannot qualify an authenticated browser deployment.
Every attempt has its own child process and complete outer latency observation.
"""

from __future__ import annotations

import argparse
import csv
import datetime as dt
import hashlib
import html
import importlib.util
import json
import random
import resource
import subprocess
import sys
import time
import traceback
from pathlib import Path
from typing import Any

from plan_oracle import accept_journey, accept_plan
from planning_generator import journey_case, planning_cases, repair_transfers


def _save(path: Path, value: Any) -> None:
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def _cpu() -> float:
    own = resource.getrusage(resource.RUSAGE_SELF)
    child = resource.getrusage(resource.RUSAGE_CHILDREN)
    return own.ru_utime + own.ru_stime + child.ru_utime + child.ru_stime


def _load_worker(root: Path) -> Any:
    spec = importlib.util.spec_from_file_location(
        "study_pinned_strategy_worker", root / "fixed_worker.py"
    )
    if spec is None or spec.loader is None:
        raise ValueError("Unable to load the pinned worker")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _render_plans(outcome: dict[str, Any], output: Path) -> None:
    """Make the exact returned schedules usable without a JSON reader."""
    phases = outcome["result"].get("phases", [])
    parts = [
        "<!doctype html><html lang='en'><meta charset='utf-8'>",
        "<meta name='viewport' content='width=device-width,initial-scale=1'>",
        "<title>Verified planning delivery</title><style>body{font:18px system-ui;max-width:64rem;",
        "margin:2rem auto;padding:1rem;color:#232036}table{border-collapse:collapse;width:100%}",
        "td,th{padding:.6rem;text-align:left;border-bottom:1px solid #ccc}code{overflow-wrap:anywhere}</style>",
        "<h1>Planning delivery</h1><p>Times are supplied scenario slots. This is a planning artifact; physical work has not been observed.</p>",
    ]
    with (output / "schedule.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            ["phase", "task", "job", "start_slot", "end_slot", "locked_in_repair"]
        )
        for index, phase in enumerate(phases):
            result = phase.get("result")
            if result is None:
                parts.append("<h2>Undelivered phase</h2>")
                continue
            parts.append(
                "<h2>"
                + html.escape(phase["label"])
                + "</h2><p>"
                + html.escape(phase["task_id"])
                + " · Selected method: "
                + html.escape(phase["selected_method"])
                + " · Finish slot "
                + str(result["makespan"])
                + " · Total start movement "
                + str(result["movement"])
                + "</p><table><thead><tr><th>Job</th><th>Start</th><th>End</th><th>Preserved lock</th></tr></thead><tbody>"
            )
            for row in result["schedule"]:
                locked = row["id"] in phase["task"].get("locked", {})
                writer.writerow(
                    [
                        index,
                        phase["task_id"],
                        row["id"],
                        row["start"],
                        row["end"],
                        locked,
                    ]
                )
                parts.append(
                    "<tr><td>"
                    + html.escape(row["id"])
                    + "</td><td>"
                    + str(row["start"])
                    + "</td><td>"
                    + str(row["end"])
                    + "</td><td>"
                    + ("Yes" if locked else "No")
                    + "</td></tr>"
                )
            parts.append(
                "</tbody></table><p>Receipt <code>"
                + html.escape(phase["receipt_hash"])
                + "</code></p>"
            )
    parts.append(
        "<p>Acceptance and all failed or rejected alternatives are included in the accompanying JSON evidence. No production authority or payment is granted.</p></html>"
    )
    (output / "schedule.html").write_text("".join(parts))


def one(request_path: Path, output: Path, source_root: Path) -> int:
    started = time.perf_counter()
    request = json.loads(request_path.read_text())
    output.mkdir(parents=True, exist_ok=False)
    _save(output / "request.json", request)
    worker_module = _load_worker(source_root)
    progress: list[dict[str, Any]] = []
    checkpoints: list[dict[str, Any]] = []
    worker = worker_module.FixedWorker(source_root, on_progress=progress.append)
    identity = worker.verify_sources()
    limits = {
        "service_work": 3_000_000,
        "improvement_work": 5_000_000,
        "native_calls": 6,
        "native_solve_seconds": 12,
        "wall_seconds": 180,
        "allow_native": True,
        "source_hash": identity,
    }
    outcome: dict[str, Any] | None = None
    error: dict[str, Any] | None = None
    try:
        outcome = worker.execute(
            request["method"],
            request["payload"],
            limits,
            lambda **values: checkpoints.append(values),
        )
        _save(output / "worker-result.json", outcome)
        _render_plans(outcome, output)
        if request["method"] == "run-journey":
            acceptance = accept_journey(request["payload"], outcome)
        else:
            phase = outcome["result"]["phases"][0]
            acceptance = accept_plan(request["payload"]["task"], phase["result"])
            acceptance["checks"]["external_task_binding"] = (
                phase["task"] == request["payload"]["task"]
            )
            acceptance["accepted"] = (
                acceptance["accepted"] and acceptance["checks"]["external_task_binding"]
            )
        _save(output / "acceptance.json", acceptance)
    except Exception as caught:  # All failed attempts remain evidence.
        error = {
            "type": type(caught).__name__,
            "message": str(caught),
            "known_costs": getattr(caught, "costs", None),
            "interrupted": getattr(caught, "interrupted", False),
        }
        (output / "failure-trace.txt").write_text(traceback.format_exc())
        acceptance = {
            "accepted": False,
            "failed_checks": ["execution_failed"],
            "error": error,
        }
        _save(output / "acceptance.json", acceptance)
    _save(output / "progress.json", progress)
    _save(output / "checkpoints.json", checkpoints)
    receipt = {
        "schema": "capability-planning-attempt/v1",
        "id": request["id"],
        "method": request["method"],
        "arm": request.get("arm", "complete-system"),
        "accepted": acceptance["accepted"],
        "limits": limits,
        "worker_manifest_sha256": identity,
        "worker_wall_seconds": time.perf_counter() - started,
        "cpu_seconds": _cpu(),
        "cpu_scope": "Whole worker Python process and waited descendants from process start through evidence write; final receipt/exit tail excluded",
        "observed_human_minutes": None,
        "complete_monetary_cost": None,
        "model_calls_during_fixed_execution": 0,
        "authoring_model_usage_and_cost": None,
        "source_status": "Exact supplied source with manifest verification; local research only",
        "execution": "Finite local FixedWorker, no authenticated transport or journal",
        "error": error,
        "costs": (
            outcome["costs"] if outcome else error.get("known_costs") if error else None
        ),
    }
    _save(output / "receipt.json", receipt)
    return 0 if acceptance["accepted"] else 1


def _launch(
    request: dict[str, Any], destination: Path, source_root: Path, request_root: Path
) -> dict[str, Any]:
    request_path = request_root / (request["id"] + ".json")
    _save(request_path, request)
    began = time.perf_counter()
    try:
        finished = subprocess.run(
            [
                sys.executable,
                str(Path(__file__).resolve()),
                "--one",
                str(request_path),
                "--source-root",
                str(source_root),
                "--output",
                str(destination),
            ],
            capture_output=True,
            text=True,
            timeout=210,
            check=False,
        )
        stdout, stderr, exit_code = (
            finished.stdout,
            finished.stderr,
            finished.returncode,
        )
        timeout = False
    except subprocess.TimeoutExpired as caught:
        stdout = (
            caught.stdout.decode(errors="replace")
            if isinstance(caught.stdout, bytes)
            else caught.stdout or ""
        )
        stderr = (
            caught.stderr.decode(errors="replace")
            if isinstance(caught.stderr, bytes)
            else caught.stderr or ""
        )
        exit_code, timeout = None, True
    elapsed = time.perf_counter() - began
    # Even an unexpected supervisor failure is retained, never silently retried.
    if not destination.exists():
        destination.mkdir(parents=True)
    (destination / "stdout.txt").write_text(stdout)
    (destination / "stderr.txt").write_text(stderr)
    receipt_path = destination / "receipt.json"
    receipt = (
        json.loads(receipt_path.read_text())
        if receipt_path.exists()
        else {
            "id": request["id"],
            "method": request["method"],
            "arm": request.get("arm", "complete-system"),
            "accepted": False,
            "cpu_seconds": None,
            "error": "No completed worker receipt",
        }
    )
    if timeout:
        receipt.update(
            accepted=False,
            error="Outer process timeout; residual child cleanup not independently measured",
        )
    receipt.update(
        outer_wall_seconds=elapsed,
        exit_code=exit_code,
        outer_timeout=timeout,
        outer_timing_scope="Full child launch, source verification, all methods, checks, evidence serialization and exit",
    )
    _save(receipt_path, receipt)
    return receipt


def run(
    output: Path,
    source_root: Path,
    seed: int,
    mode: str,
    freeze: Path | None,
    part: str,
) -> dict[str, Any]:
    if mode == "confirmation" and (freeze is None or not freeze.is_file()):
        raise ValueError(
            "Confirmation requires an existing separately recorded prospective freeze"
        )
    if mode == "confirmation":
        assert freeze is not None
        manifest = json.loads(freeze.read_text())
        study_root = freeze.resolve().parents[1]
        for entry in manifest["files"]:
            source = study_root / entry["path"]
            if (
                not source.is_file()
                or hashlib.sha256(source.read_bytes()).hexdigest() != entry["sha256"]
            ):
                raise ValueError("Frozen study source changed: " + entry["path"])
    output.mkdir(parents=True, exist_ok=False)
    requests = output / "requests"
    requests.mkdir()
    corpus = {
        "planning": planning_cases(seed),
        "journey": journey_case(seed + 1),
        "transfers": repair_transfers(seed + 2),
    }
    _save(output / "corpus.json", corpus)
    _save(
        output / "execution-start.json",
        {
            "mode": mode,
            "seed": seed,
            "started_at": dt.datetime.now(dt.timezone.utc).isoformat(),
            "freeze_sha256": (
                hashlib.sha256(freeze.read_bytes()).hexdigest() if freeze else None
            ),
            "confirmation_design": "Six planning jobs, one construction journey, twelve paired fresh transfers",
            "human_trial": "NOT_RUN",
        },
    )
    receipts = []
    if part in ("all", "portfolio"):
        cases = list(
            corpus["planning"] if mode == "confirmation" else corpus["planning"][:1]
        )
        random.Random(seed + 19).shuffle(cases)
        for item in cases:
            request = {
                "id": item["id"],
                "method": "run-mission",
                "payload": {"task": item["task"]},
            }
            receipts.append(
                _launch(request, output / item["id"], source_root, requests)
            )
    if part in ("all", "journey"):
        item = corpus["journey"]
        request = {
            "id": item["id"],
            "method": "run-journey",
            "payload": item["payload"],
        }
        receipts.append(_launch(request, output / item["id"], source_root, requests))
        journey_result_path = output / item["id"] / "worker-result.json"
        asset = None
        if journey_result_path.exists():
            journey_result = json.loads(journey_result_path.read_text())
            for construction in journey_result["result"].get("capabilities", []):
                candidate = construction.get("asset")
                if (
                    candidate
                    and candidate.get("stage") == "repair"
                    and candidate["qualification"]["correctness"]
                ):
                    asset = candidate
                    break
        _save(
            output / "retained-repair-capability.json",
            {
                "asset": asset,
                "source_attempt": item["id"],
                "production_authority": False,
            },
        )
        transfer_cases = (
            corpus["transfers"] if mode == "confirmation" else corpus["transfers"][:1]
        )
        if asset:
            treatment_requests = []
            for transfer in transfer_cases:
                for arm in ("ordinary-native", "retained-offered"):
                    payload = {"task": transfer["task"]}
                    if arm == "retained-offered":
                        payload["strategy"] = asset["strategy"]
                    treatment_requests.append(
                        {
                            "id": transfer["id"] + "-" + arm,
                            "method": "run-mission",
                            "arm": arm,
                            "parent_capability_digest": asset["digest"],
                            "payload": payload,
                        }
                    )
            random.Random(seed + 3).shuffle(treatment_requests)
            for request in treatment_requests:
                receipts.append(
                    _launch(request, output / request["id"], source_root, requests)
                )
        else:
            _save(
                output / "transfer-status.json",
                {
                    "status": "NOT_RUN_NO_QUALIFIED_RETAINED_REPAIR",
                    "count_planned": len(transfer_cases),
                    "reason": "No substitute candidate constructed after observing confirmation",
                },
            )
    summary = {
        "mode": mode,
        "part": part,
        "seed": seed,
        "attempts": len(receipts),
        "accepted_attempts": sum(bool(row["accepted"]) for row in receipts),
        "receipts": receipts,
        "elapsed_seconds_sum": sum(row["outer_wall_seconds"] for row in receipts),
        "known_cpu_seconds_sum": sum(
            row["cpu_seconds"] for row in receipts if row.get("cpu_seconds") is not None
        ),
        "cpu_unmeasured_attempts": sum(
            row.get("cpu_seconds") is None for row in receipts
        ),
        "complete_cost": None,
        "attention": None,
        "scope": "Finite native planning actions and fresh transfer; mechanism arms are separate from human economics",
    }
    _save(output / "summary.json", summary)
    return summary


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--seed", type=int, default=8102026)
    parser.add_argument(
        "--mode", choices=("development", "confirmation"), default="development"
    )
    parser.add_argument(
        "--part", choices=("all", "portfolio", "journey"), default="all"
    )
    parser.add_argument("--freeze", type=Path)
    parser.add_argument("--one", type=Path)
    args = parser.parse_args()
    if args.one:
        return one(args.one, args.output, args.source_root.resolve())
    result = run(
        args.output,
        args.source_root.resolve(),
        args.seed,
        args.mode,
        args.freeze,
        args.part,
    )
    print(
        json.dumps({key: value for key, value in result.items() if key != "receipts"})
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
