# SPDX-License-Identifier: Apache-2.0
"""Independent acceptance for the released bounded workbench adapters.

This evaluator imports no producer code.  Expected values come from the submitted
brief, Python's standard library, and the task contract.  Its authors share a
research environment with the producer; that is procedural separation, not an
external or blinded human acceptance trial.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import html
import io
import json
import re
from collections import defaultdict
from fractions import Fraction
from pathlib import Path
from typing import Any
from urllib.parse import quote, unquote_to_bytes


def canonical(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def digest(domain: str, value: Any) -> str:
    payload = "successor-omega/v1:" + domain + "\0" + canonical(value)
    return hashlib.sha256(payload.encode()).hexdigest()


class Checks:
    def __init__(self) -> None:
        self.checks: dict[str, bool] = {}

    def add(self, name: str, condition: Any) -> None:
        self.checks[name] = bool(condition)

    def result(self, family: str) -> dict[str, Any]:
        return {
            "schema": "capability-native-acceptance/v1",
            "family": family,
            "accepted": bool(self.checks) and all(self.checks.values()),
            "checks": self.checks,
            "failed_checks": [key for key, value in self.checks.items() if not value],
            "scope": "Independent implementation of a bounded contract; no external human assessment",
        }


def _reliability(
    inputs: dict[str, Any],
    result: dict[str, Any],
    files: dict[str, str],
    checks: Checks,
) -> None:
    low, high = inputs["low"], inputs["high"]
    pattern = re.compile(
        r"\s*export\s+function\s+contains\s*\(\s*value\s*,\s*low\s*,\s*high\s*\)"
        r"\s*\{\s*return\s+low\s*(<=|<)\s*value\s*&&\s*value\s*(<=|<)\s*high\s*;\s*\}\s*"
    )
    before = pattern.fullmatch(inputs["source"])
    after = pattern.fullmatch(files["contains.mjs"])
    checks.add(
        "candidate_closed_interval_contract",
        after is not None and after.groups() == ("<=", "<="),
    )
    checks.add(
        "original_source_retained", files["original.mjs"] == inputs["source"] + "\n"
    )
    cases = list(dict.fromkeys(inputs["cases"] + [low - 1, low, high, high + 1]))
    expected = []
    if before is None:
        checks.add("source_in_declared_grammar", False)
        return
    for value in cases:
        lower = low <= value if before[1] == "<=" else low < value
        upper = value <= high if before[2] == "<=" else value < high
        expected.append(
            {
                "value": value,
                "expected": low <= value <= high,
                "actual": lower and upper,
            }
        )
    defects = sum(row["expected"] != row["actual"] for row in expected)
    checks.add(
        "reported_original_tests_exact", json.loads(files["tests.json"]) == expected
    )
    checks.add("reported_defects_exact", result["summary"]["defects"] == defects)
    checks.add("reported_test_count_exact", result["summary"]["tests"] == len(expected))
    checks.add(
        "correct_repair_decision",
        result["decision"] == ("REPAIR_PROPOSED" if defects else "RETAIN_INCUMBENT"),
    )
    checks.add("finite_attempts_recorded", len(result["evidence"]["attempts"]) == 4)
    checks.add(
        "patch_and_executable_checks_present",
        "repair.patch" in files and "check.mjs" in files,
    )


def _documentation(
    inputs: dict[str, Any],
    result: dict[str, Any],
    files: dict[str, str],
    checks: Checks,
) -> None:
    markdown = inputs["markdown"]
    pattern = re.compile(r"```successor-example\s*\n([\s\S]*?)\n```")
    expected = []
    rebuilt = []
    offset = 0
    for match in pattern.finditer(markdown):
        item = json.loads(match[1])
        actual, error = None, None
        try:
            if item["operation"] == "url-encode":
                actual = quote(item["input"], safe="~!*'()")
            elif item["operation"] == "url-decode":
                if re.search(r"%(?![0-9A-Fa-f]{2})", item["input"]):
                    raise ValueError("Malformed percent escape")
                actual = unquote_to_bytes(item["input"]).decode(
                    "utf-8", errors="strict"
                )
            elif item["operation"] == "utf8-bytes":
                actual = str(len(item["input"].encode("utf-8")))
            else:
                raise ValueError("Unsupported operation")
        except (UnicodeError, ValueError):
            error = "INVALID_URI_ENCODING"
        expected.append(
            {
                "index": len(expected) + 1,
                **item,
                "actual": actual,
                "error": error,
                "passed": error is None and actual == item["expected"],
            }
        )
        rebuilt.append(markdown[offset : match.start()])
        replacement = json.dumps(
            {**item, "expected": actual}, ensure_ascii=False, separators=(",", ":")
        )
        rebuilt.append(
            match[0] if error else "```successor-example\n" + replacement + "\n```"
        )
        offset = match.end()
    rebuilt.append(markdown[offset:])
    failed = sum(not row["passed"] for row in expected)
    errors = sum(row["error"] is not None for row in expected)
    decision = (
        "REPAIR_REQUIRED"
        if errors
        else "DOCUMENTATION_CORRECTION_PROPOSED" if failed else "RETAIN_INCUMBENT"
    )
    checks.add(
        "example_observations_exact",
        json.loads(files["example-checks.json"]) == expected,
    )
    checks.add("original_markdown_retained", files["original-examples.md"] == markdown)
    checks.add(
        "only_supported_expectations_corrected",
        files["checked-examples.md"] == "".join(rebuilt),
    )
    checks.add(
        "incorrect_example_count_exact",
        result["summary"]["incorrectExamples"] == failed,
    )
    checks.add(
        "invalid_input_count_exact", result["summary"]["invalidInputs"] == errors
    )
    checks.add("correct_documentation_decision", result["decision"] == decision)


def _public_data(
    inputs: dict[str, Any],
    result: dict[str, Any],
    files: dict[str, str],
    checks: Checks,
) -> None:
    records = list(csv.DictReader(io.StringIO(inputs["csv"])))
    groups: dict[str, list[int]] = defaultdict(list)
    for row in records:
        groups[row["group"]].append(int(row["amount"]))
    # JavaScript orders UTF-16 code units.  Explicit ordering avoids a Python
    # Unicode-codepoint discrepancy when labels include supplementary characters.
    keys = sorted(groups, key=lambda value: value.encode("utf-16-be"))
    rows = [
        {
            "group": key,
            "count": len(groups[key]),
            "total": sum(groups[key]),
            "min": min(groups[key]),
            "max": max(groups[key]),
        }
        for key in keys
    ]
    total = sum(sum(values) for values in groups.values())
    checks.add(
        "analysis_exact",
        json.loads(files["analysis.json"]) == {"total": total, "groups": rows},
    )
    checks.add("reported_rows_exact", result["summary"]["rows"] == len(records))
    checks.add("reported_total_exact", result["summary"]["total"] == total)
    checks.add("reported_unit_exact", result["summary"]["unit"] == inputs["unit"])
    exported = list(csv.DictReader(io.StringIO(files["summary.csv"])))
    expected_csv = []
    for row in rows:
        label = row["group"]
        if re.match(r"[=+\-@\t\r]", label):
            label = "'" + label
        expected_csv.append(
            {key: str(value) for key, value in {**row, "group": label}.items()}
        )
    checks.add("csv_exact_and_formula_escaped", exported == expected_csv)
    report = files["report.html"]
    checks.add(
        "html_report_present",
        "<!doctype html>" in report.lower() and "<table>" in report,
    )
    checks.add(
        "html_labels_escaped",
        all(
            html.escape(key, quote=True).replace("&#x27;", "&#39;") in report
            for key in keys
        ),
    )
    checks.add("correct_data_decision", result["decision"] == "REPORT_READY_FOR_REVIEW")


def _numerical(
    inputs: dict[str, Any],
    result: dict[str, Any],
    files: dict[str, str],
    checks: Checks,
) -> None:
    coefficients = inputs["coefficients"]
    lower, upper, steps = inputs["lower"], inputs["upper"], inputs["steps"]
    exact = sum(
        (
            Fraction(c * (upper ** (i + 1) - lower ** (i + 1)), i + 1)
            for i, c in enumerate(coefficients)
        ),
        Fraction(),
    )
    increment = Fraction(upper - lower, steps)
    points = [lower + index * increment for index in range(steps + 1)]
    values = [
        sum(
            (
                Fraction(coefficient) * point**power
                for power, coefficient in enumerate(coefficients)
            ),
            Fraction(),
        )
        for point in points
    ]
    trapezoid = increment * (
        sum(values[1:-1], Fraction()) + (values[0] + values[-1]) / 2
    )
    simpson = (
        increment
        * (
            values[0]
            + values[-1]
            + 4 * sum(values[1:-1:2], Fraction())
            + 2 * sum(values[2:-1:2], Fraction())
        )
        / 3
    )
    tolerance = Fraction(inputs["tolerancePpm"], 1_000_000)
    actual = json.loads(files["numerical.json"])
    for name, expected in (
        ("analytic", exact),
        ("trapezoid", trapezoid),
        ("simpson", simpson),
        ("absoluteTolerance", tolerance),
    ):
        checks.add("exact_" + name, Fraction(actual[name]) == expected)
    for name, approximation in (("trapezoid", trapezoid), ("simpson", simpson)):
        error = abs(approximation - exact)
        checks.add(
            "exact_" + name + "_error",
            Fraction(actual["absoluteErrors"][name]) == error,
        )
        checks.add(
            "exact_" + name + "_tolerance_decision",
            actual["passes"][name] == (error <= tolerance),
        )
    checks.add(
        "calculation_input_retained",
        json.loads(files["calculation-input.json"]) == inputs,
    )
    checks.add(
        "correct_numerical_decision",
        result["decision"]
        == (
            "WITHIN_DECLARED_TOLERANCE"
            if abs(simpson - exact) <= tolerance
            else "REPAIR_REQUIRED"
        ),
    )


def _performance(
    inputs: dict[str, Any],
    result: dict[str, Any],
    files: dict[str, str],
    checks: Checks,
) -> None:
    observed = json.loads(files["benchmark.json"])
    checks.add(
        "integer_unique_output_exact",
        observed["output"] == sorted(set(inputs["values"])),
    )
    checks.add("values_retained", json.loads(files["values.json"]) == inputs["values"])
    medians = {}
    for name in ("sort", "set"):
        samples = observed["samplesMicrosecondsPerBatch"][name]
        checks.add(name + "_sample_count", len(samples) == inputs["repetitions"])
        checks.add(
            name + "_nonnegative_measurements",
            all(isinstance(value, int) and value >= 0 for value in samples),
        )
        medians[name] = sorted(samples)[len(samples) // 2]
    checks.add("median_arithmetic_exact", medians == observed["medianMicroseconds"])
    selected = "set" if medians["set"] < medians["sort"] else "sort"
    checks.add("selection_follows_observed_median", observed["selected"] == selected)
    checks.add("batch_repeats_disclosed", observed["batchRepeats"] == inputs["repeats"])
    checks.add("executable_retained", "export const unique" in files["unique.mjs"])
    checks.add(
        "correct_performance_summary",
        result["summary"]["outputCount"] == len(set(inputs["values"])),
    )


HANDLERS = {
    "reliability": _reliability,
    "documentation": _documentation,
    "public-data": _public_data,
    "numerical": _numerical,
    "performance": _performance,
}


def accept_native(spec: dict[str, Any], pack: dict[str, Any]) -> dict[str, Any]:
    checks = Checks()
    family = spec.get("family", "unknown")
    try:
        checks.add("input_matches_external_brief", pack["spec"] == spec)
        body = {key: value for key, value in pack.items() if key != "integrityDigest"}
        checks.add(
            "pack_digest_valid",
            digest("workbench-pack", body) == pack["integrityDigest"],
        )
        checks.add(
            "no_authority_grant",
            pack["evaluation"]["authority"] == [] and pack["frozen"]["authority"] == [],
        )
        checks.add(
            "no_settlement_connection",
            pack["evaluation"]["settlement"] == "NOT_CONNECTED",
        )
        checks.add(
            "unknown_costs_not_zero",
            pack["economics"]["computeCost"] is None
            and pack["economics"]["humanMinutes"] is None,
        )
        artifacts = pack["result"]["artifacts"]
        checks.add(
            "unique_artifact_names",
            len({item["name"] for item in artifacts}) == len(artifacts),
        )
        for artifact in artifacts:
            content = {key: value for key, value in artifact.items() if key != "digest"}
            checks.add(
                "artifact_digest_" + artifact["name"],
                digest("workbench-artifact", content) == artifact["digest"],
            )
        files = {item["name"]: item["content"] for item in artifacts}
        if family not in HANDLERS:
            checks.add("supported_evaluator_family", False)
        else:
            HANDLERS[family](spec["inputs"], pack["result"], files, checks)
    except (
        KeyError,
        ValueError,
        TypeError,
        IndexError,
        UnicodeError,
        ZeroDivisionError,
    ):
        checks.add("schema_and_evaluation_completed", False)
    return checks.result(family)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("brief", type=Path)
    parser.add_argument("pack", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = accept_native(
        json.loads(args.brief.read_text()), json.loads(args.pack.read_text())
    )
    text = json.dumps(result, indent=2, ensure_ascii=False) + "\n"
    if args.output:
        args.output.write_text(text)
    else:
        print(text, end="")
    return 0 if result["accepted"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
