# AGI ALPHA FLYWHEEL
## From useful work to reusable productive capability

**SUCCESSOR Ω HARNESS — ACTIVATE. EVOLVE. SCALE.**

Powered by TRANSFORMATIONAL INTELLIGENCE ∞.

This additive research edition was frozen before confirmation on 25 October 2026. It asks what accepted digital work the available Agent route can deliver, what executable methods remain, whether they help fresh work, and what an employer would need to observe before adoption.

## Results that can be inspected

| Question | Observed answer |
|---|---|
| Useful delivery | 42/42 primary jobs accepted; seven bounded families, eight principal templates |
| Local turnaround | Family medians 0.099–1.301 seconds; setup and employer attention are outside these clocks |
| Inheritance | Actual parent reads; 15 inherited calls in lookahead and 3 in repair construction |
| Repair transfer | The retained candidate lost to the strongest available specialist on 12/12 fresh cases; the complete system still delivered 24/24 accepted paired outputs |
| Source reuse | Actual retained executable imported on changed briefs/presentations; CPU ratio 1.0356 versus full compilation, with no admitted discovery-cycle gain |
| Review | 27/27 seeded defects detected, six clean cases without alarms, six fabricated criticisms rejected |
| Finite load | 108/108 accepted; 3.176× median throughput at concurrency four versus one, on twelve tiny non-planning inputs |
| Complete economics | Conditional market-data model; full Agent cost, matched human duration and employer attention unknown |
| Self-acceleration | NOT ESTABLISHED |
| Authenticated executor | NOT RUN; no existing approved operator home was supplied, and no credentials or authority were created |

The primary economic comparator is competent traditional human work with ordinary non-AI tools. There was no newly recruited human trial. Official wages, employer costs, task descriptions and published performance evidence are used with their scope and AI-use limitations preserved. Break-even times and sensitivity replace invented human task durations.

The implementation includes the original maintained workbench and Strategy Succession worker, the available native specialist, a new bounded evidence adapter, frozen independent evaluators, actual output artifacts and all development/confirmation attempts. It is not an installed production enterprise or a general computer-use benchmark.

## Start here

- `paper/main.pdf`: complete scientific paper, with appendices and bibliography.
- `browser/`: accessible standalone companion, actual local computation, recorded planning and adjustable scenario economics.
- `analysis/SUMMARY.json`, `analysis/planning.json`: machine-readable results.
- `analysis/INDEPENDENT_SCIENTIFIC_AUDIT.json`: 1,101 independent checks of artifacts, arithmetic and frozen identities.
- `analysis/LEDGER.json`: separate measured delivery/improvement/qualification accounts and explicit missing costs.
- `protocol/PROTOCOL.md` and `protocol/FREEZE.json`: prospective protocol and 110 frozen input identities.
- `reproduction/README.md`: fresh-copy execution, evidence audit and clean-build instructions.
- `publication/STATUS.json`: prepared, reviewed, draft, merged and public verification statuses, kept separate.

The earlier **Economics of Autonomous Work** edition and PR #4901 remain independent. Their 69 frozen inputs and canonical PDF are preserved. This new study does not retroactively broaden their claims.

## Evidence custody

Freeze SHA-256: `55fe389e077028c1439cf3dbdadc09164455df00865db471ddf03bd1eb99e282`.

Public prospective notice: https://github.com/MontrealAI/AGI-Alpha-Agent-v0/issues/4850#issuecomment-6397672653

Checkpoint SHA-256: `67a793b9ed781aa62ae9ce1469c701adc66c3149f3a36631812263aa8b59e4d5`.

No private participant records, credentials, nonpublic personal material, financial transactions or deployment authority are included. Upstream software retains its original license and source notices; official labor-data sources retain their documented scope and terms. The source audit distinguishes USDC commissioning from separate $AGIALPHA routes. Neither was funded or executed.
