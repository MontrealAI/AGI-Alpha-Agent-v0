# SPDX-License-Identifier: Apache-2.0
"""Finite offline browser checks; not scientific reruns or authenticated execution."""
import hashlib
import json
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent
QA = ROOT / 'qa'
QA.mkdir(exist_ok=True)
checks = []
errors = []
requests = []


def check(name, passed, detail=None):
    checks.append({'check': name, 'passed': bool(passed), 'detail': detail})
    if not passed:
        raise AssertionError(name + ': ' + str(detail))


with sync_playwright() as p:
    browser = p.chromium.launch(headless=True, executable_path='/tmp/successor-chrome/chrome-headless-shell-linux64/chrome-headless-shell', args=['--no-sandbox'])
    context = browser.new_context(viewport={'width': 1440, 'height': 1050}, accept_downloads=True, offline=True)
    page = context.new_page()
    page.on('pageerror', lambda error: errors.append(str(error)))
    page.on('request', lambda request: requests.append(request.url) if request.url.startswith(('http:', 'https:')) else None)
    page.goto((ROOT / 'AGI_ALPHA_Capability_Construction_Demo.html').as_uri())
    page.wait_for_function('window.CAPABILITY_DEMO?.ready === true', timeout=20000)
    check('Frozen modules initialize without network', not requests, requests)
    page.screenshot(path=str(QA / 'desktop-opening.png'), full_page=True)
    page.locator('#first').click()
    page.wait_for_function('CAPABILITY_DEMO.state().history.length===1 && !CAPABILITY_DEMO.state().busy')
    state = page.evaluate('CAPABILITY_DEMO.state()')
    check('First useful source brief', state['history'][0]['pack']['result']['summary']['claims'] == 4)
    check('First complete-contract check', state['history'][0]['checks']['exact_contract'])
    page.locator('#changed').click()
    page.wait_for_function('CAPABILITY_DEMO.state().history.length===2 && !CAPABILITY_DEMO.state().busy')
    state = page.evaluate('CAPABILITY_DEMO.state()')
    check('Actual parent executable imported', state['retainedInvocations'] == 1)
    lineage = json.loads(next(x['content'] for x in state['history'][1]['pack']['result']['artifacts'] if x['name'] == 'lineage.json'))
    check('Changed source repairs while preserving eligible claims', bool(lineage['changed_source_ids']) and bool(lineage['reused_claim_ids']) and bool(lineage['recompiled_claim_ids']), lineage)
    page.locator('#transfer').click()
    page.wait_for_function('CAPABILITY_DEMO.state().history.length===3 && !CAPABILITY_DEMO.state().busy')
    state = page.evaluate('CAPABILITY_DEMO.state()')
    check('Fresh format transfer imports retained module again', state['retainedInvocations'] == 2 and state['history'][2]['pack']['spec']['family'] == 'evidence-deck')
    lineage = json.loads(next(x['content'] for x in state['history'][2]['pack']['result']['artifacts'] if x['name'] == 'lineage.json'))
    check('Cross-family contribution recorded', lineage['cross_family'] and len(lineage['reused_claim_ids']) == 4, lineage)
    with page.expect_download() as result:
        page.get_by_role('button', name='repair-tool.mjs', exact=True).click()
    download = result.value
    path = QA / 'repair-tool.mjs'
    download.save_as(path)
    check('Downloaded retained executable exact', path.read_bytes() == (ROOT.parent / 'src/evidence.mjs').read_bytes())
    with page.expect_download() as result:
        page.get_by_role('button', name='slides.html', exact=True).click()
    result.value.save_as(QA / 'slides.html')
    check('Usable presentation download', '<article class="slide">' in (QA / 'slides.html').read_text())
    workspace = page.evaluate('CAPABILITY_DEMO.exportWorkspace()')
    (QA / 'workspace.json').write_text(workspace)
    page.locator('#rollback').click()
    state = page.evaluate('CAPABILITY_DEMO.state()')
    check('Rollback preserves every prior output', state['selected'] == 1 and len(state['history']) == 3)
    page.locator('#stopNext').check()
    page.locator('#first').click()
    page.wait_for_function('!CAPABILITY_DEMO.state().busy')
    state = page.evaluate('CAPABILITY_DEMO.state()')
    check('Pre-execution STOP preserves outputs', len(state['history']) == 3 and any(x['kind'] == 'failed-or-stopped' and x['detail']['error'] == 'CANCELLED' for x in state['events']))
    page.evaluate('raw=>CAPABILITY_DEMO.restore(raw)', workspace)
    check('Historical workspace recovery', page.evaluate('CAPABILITY_DEMO.state().history.length') == 3)
    corrupt = json.loads(workspace)
    corrupt['history'][0]['pack']['result']['summary']['claims'] = 999
    refusal = page.evaluate('async raw=>{try{await CAPABILITY_DEMO.restore(raw);return null;}catch(e){return e.message}}', json.dumps(corrupt))
    check('Corrupt history refused', refusal == 'PACK_INTEGRITY', refusal)
    check('Refusal retains prior history', page.evaluate('CAPABILITY_DEMO.state().history.length') == 3)
    page.screenshot(path=str(QA / 'desktop-live-output.png'), full_page=True)
    page.get_by_role('tab', name='Inspect the study · recorded').click()
    check('Recorded scorecard42/42 and7families', page.locator('#recordedMetrics').inner_text().startswith('42/42') and page.locator('#familyRows tr').count() == 7)
    with page.expect_download() as result:
        page.locator('#downloadEvidence').click()
    evidence_path = QA / 'recorded-evidence.zip'
    result.value.save_as(evidence_path)
    wanted = page.evaluate('CAPABILITY_DEMO.data.evidence.sha256')
    check('Recorded download exact digest', hashlib.sha256(evidence_path.read_bytes()).hexdigest() == wanted)
    page.screenshot(path=str(QA / 'desktop-recorded.png'), full_page=True)
    page.get_by_role('tab', name='Estimate value · scenario').click()
    check('Conditional economics default arithmetic', page.locator('#humanCost').inner_text() == '$17.98' and page.locator('#agentCost').inner_text() == '$4.00')
    page.locator('#humanMinutes').fill('5')
    page.locator('#attention').fill('15')
    page.locator('#otherCost').fill('5')
    check('Unfavorable scenario retained', 'traditional work costs' in page.locator('#modelVerdict').inner_text())
    page.get_by_role('tab', name='Executor & boundaries').click()
    check('Authenticated executor not claimed', 'NOT RUN in this research session' in page.locator('#executor').inner_text())
    for tab in ['live', 'recorded', 'economics', 'executor']:
        page.set_viewport_size({'width': 390, 'height': 844})
        page.locator('[data-tab='+tab+']').click()
        check('Mobile horizontal containment '+tab, page.evaluate('document.documentElement.scrollWidth<=window.innerWidth+1'))
        page.screenshot(path=str(QA / ('mobile-'+tab+'.png')), full_page=True)
    for frame_id, tab in [('preview', 'live'), ('planningPreview', 'recorded')]:
        page.locator('[data-tab='+tab+']').click()
        page.locator('#'+frame_id).scroll_into_view_if_needed()
        page.frame_locator('#'+frame_id).locator('h1').wait_for()
        check('Mobile iframe text contains within width '+frame_id, page.frame_locator('#'+frame_id).locator('body').evaluate('e=>e.scrollWidth<=e.ownerDocument.documentElement.clientWidth+1'))
        page.screenshot(path=str(QA / ('final-mobile-'+frame_id+'.png')))
    check('No page script errors', not errors, errors)
    check('No external runtime requests', not requests, requests)
    browser.close()

report = {'schema': 'capability-browser-qa/v1', 'mode': 'OFFLINE_LOCAL_BROWSER_ENGINEERING_QA', 'checks': checks, 'passed': sum(x['passed'] for x in checks), 'attempted': len(checks), 'page_errors': errors, 'external_requests': requests, 'scientific_confirmation_rerun': False, 'authenticated_executor': 'NOT_RUN', 'screenshots': 'Internal visual QA only; exclude images from distributed evidence'}
(ROOT / 'QA_REPORT.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'passed': report['passed'], 'attempted': report['attempted'], 'page_errors': errors, 'external_requests': requests}))
