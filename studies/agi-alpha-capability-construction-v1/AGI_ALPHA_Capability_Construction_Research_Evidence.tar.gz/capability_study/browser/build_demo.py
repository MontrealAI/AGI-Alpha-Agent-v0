# SPDX-License-Identifier: Apache-2.0
"""Build an offline live-local/replay/scenario companion from preserved sources."""
import base64
import hashlib
import io
import json
import posixpath
import re
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
HERE = ROOT / 'browser'


def read(path):
    return json.loads((ROOT / path).read_text())


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    modules = {}
    identities = []

    def collect(path):
        if path in modules:
            return
        raw = (ROOT / path).read_bytes()
        text = raw.decode('utf-8')
        modules[path] = text
        identities.append({'path': path, 'sha256': sha(raw), 'bytes': len(raw)})
        for relative in re.findall(r"^(?:import|export)\s+[^;]*?\bfrom\s+['\"]([^'\"]+)['\"]", text, re.MULTILINE):
            if not relative.startswith('.'):
                raise ValueError('Unexpected external import: ' + relative)
            collect(posixpath.normpath(posixpath.join(posixpath.dirname(path), relative)))

    collect('upstream/examples/successor-workbench/engine.mjs')
    collect('src/evidence.mjs')
    base = 'raw/evidence-mechanism/'
    cases = ['evidence-parent-01', 'evidence-change-01-incremental', 'presentation-transfer-01']
    records = []
    evidence_paths = ['analysis/SUMMARY.json', 'protocol/FREEZE.json']
    for case in cases:
        stem = base + case + '/'
        records.append({'id': case, 'spec': read(stem + 'brief.json'),
                        'pack': read(stem + 'output/pack.json'),
                        'receipt': read(stem + 'receipt.json'),
                        'acceptance': read(stem + 'acceptance.json')})
        for rel in ['brief.json', 'receipt.json', 'acceptance.json']:
            evidence_paths.append(stem + rel)
        evidence_paths += [str(p.relative_to(ROOT)) for p in (ROOT / stem / 'output').iterdir() if p.is_file()]
    planning = 'raw/planning/connected-release-2026102518/'
    for name in ['request.json', 'acceptance.json', 'receipt.json', 'worker-result.json', 'schedule.html', 'schedule.csv']:
        evidence_paths.append(planning + name)
    evidence_paths += [item['path'] for item in identities]
    evidence_paths = sorted(set(evidence_paths))
    binary = io.BytesIO()
    evidence_manifest = []
    with zipfile.ZipFile(binary, 'w', zipfile.ZIP_DEFLATED) as archive:
        for path in evidence_paths:
            raw = (ROOT / path).read_bytes()
            evidence_manifest.append({'path': path, 'sha256': sha(raw), 'bytes': len(raw)})
            info = zipfile.ZipInfo(path, (2026, 10, 25, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, raw)
        archive.writestr('MANIFEST.json', json.dumps(evidence_manifest, indent=2) + '\n')
        archive.writestr('README.txt', 'Recorded source and evidence subset. Live browser runs are new local computation and never replace frozen confirmation. Complete companion retains all experiments, failures and protocols.\n')
    payload = {
        'schema': 'capability-browser-companion/v1', 'modules': modules,
        'moduleIdentities': identities, 'records': records,
        'sourceHash': records[0]['receipt']['source_sha256'],
        'summary': read('analysis/SUMMARY.json'),
        'planningHtml': (ROOT / planning / 'schedule.html').read_text(),
        'planningReceipt': read(planning + 'receipt.json'),
        'planningAcceptance': read(planning + 'acceptance.json'),
        'evidence': {'base64': base64.b64encode(binary.getvalue()).decode(),
                     'sha256': sha(binary.getvalue()), 'bytes': len(binary.getvalue())},
    }
    html = (HERE / 'template.html').read_text().replace('__PAYLOAD__', json.dumps(payload, ensure_ascii=False, separators=(',', ':')).replace('<', '\\u003c'))
    destination = HERE / 'AGI_ALPHA_Capability_Construction_Demo.html'
    destination.write_text(html)
    manifest = {'path': destination.name, 'bytes': destination.stat().st_size,
                'sha256': sha(destination.read_bytes()), 'source_files': identities,
                'frozen_input_paths': evidence_paths, 'external_runtime_requests': [],
                'modes': ['LIVE_LOCAL', 'RECORDED_REPLAY', 'MODELED_ECONOMICS'],
                'authenticated_executor': 'NOT_RUN', 'publication': 'PREPARED_LOCAL_NOT_DEPLOYED'}
    (HERE / 'BUILD_MANIFEST.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({k: v for k, v in manifest.items() if k not in ['source_files', 'frozen_input_paths']}, indent=2))


if __name__ == '__main__':
    main()
