#!/usr/bin/env python3
"""Reproduce in a NEW directory; the delivered evidence is never overwritten."""

import argparse
import hashlib
import json
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--destination", required=True, type=Path)
    parser.add_argument("--prepare-only", action="store_true")
    args = parser.parse_args()
    target = args.destination.resolve()
    if target == ROOT or ROOT in target.parents:
        raise SystemExit("Choose a new directory outside the delivered study.")
    if target.exists():
        raise SystemExit("Destination exists; refusing to overwrite evidence.")
    freeze = json.loads((ROOT / "protocol/FREEZE.json").read_text())
    for item in freeze["files"]:
        if digest(ROOT / item["path"]) != item["sha256"]:
            raise SystemExit("Frozen input mismatch: " + item["path"])
    target.mkdir(parents=True, exist_ok=False)
    for item in freeze["files"]:
        destination = target / item["path"]
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / item["path"], destination)
    shutil.copyfile(ROOT / "protocol/FREEZE.json", target / "protocol/FREEZE.json")
    (target / "analysis").mkdir()
    (target / "reproduction-logs").mkdir()
    python = sys.executable
    commands = [
        [
            python,
            "src/run_portfolio.py",
            "--seed",
            "2026102507",
            "--output",
            "raw/portfolio",
            "--mode",
            "confirmation",
        ],
        [
            python,
            "src/mechanism_run.py",
            "--seed",
            "2026102527",
            "--output",
            "raw/evidence-mechanism",
            "--mode",
            "confirmation",
        ],
        [
            python,
            "src/controls_run.py",
            "--seed",
            "2026102547",
            "--output",
            "raw/controls",
            "--mode",
            "confirmation",
        ],
        [
            python,
            "src/scale_run.py",
            "--seed",
            "2026102507",
            "--output",
            "raw/scale",
            "--mode",
            "confirmation",
        ],
        [
            python,
            "evaluation/planning_run.py",
            "--source-root",
            "strategy_worker",
            "--output",
            "raw/planning",
            "--seed",
            "2026102517",
            "--mode",
            "confirmation",
            "--freeze",
            "protocol/FREEZE.json",
        ],
        [
            python,
            "evaluation/review_run.py",
            "--seed",
            "2026102537",
            "--output",
            "raw/review",
            "--mode",
            "confirmation",
        ],
        [
            python,
            "evaluation/summarize_planning.py",
            "raw/planning",
            "--output",
            "analysis/planning.json",
        ],
        [python, "src/analyze.py"],
        [python, "economics/validate.py"],
    ]
    run = {
        "schema": "capability-reproduction/v1",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "source_freeze_sha256": digest(ROOT / "protocol/FREEZE.json"),
        "copied_frozen_inputs": len(freeze["files"]),
        "destination": str(target),
        "prepare_only": args.prepare_only,
        "commands": commands,
        "attempts": [],
        "interpretation": "New reproduction, not additional primary-study observations. Timing varies by environment.",
    }
    record = target / "REPRODUCTION.json"
    record.write_text(json.dumps(run, indent=2) + "\n")
    if args.prepare_only:
        print(json.dumps({"prepared": str(target), "files": len(freeze["files"])}))
        return
    for index, command in enumerate(commands):
        # No shell, network request, credentials or financial actions are invoked.
        process = subprocess.run(
            command, cwd=target, capture_output=True, text=True, timeout=600
        )
        (target / "reproduction-logs" / f"{index:02d}.stdout.txt").write_text(
            process.stdout
        )
        (target / "reproduction-logs" / f"{index:02d}.stderr.txt").write_text(
            process.stderr
        )
        run["attempts"].append({"index": index, "returncode": process.returncode})
        record.write_text(json.dumps(run, indent=2) + "\n")
        print(json.dumps({"step": index, "returncode": process.returncode}), flush=True)
        if process.returncode:
            raise SystemExit(
                "Stopped after a failed step; logs retained. No retries or evidence replacement."
            )
    print(json.dumps({"status": "REPRODUCTION_COMPLETE", "destination": str(target)}))


if __name__ == "__main__":
    main()
