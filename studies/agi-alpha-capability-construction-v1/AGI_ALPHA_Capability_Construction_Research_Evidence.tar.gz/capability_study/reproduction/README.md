# Reproduce without changing the published evidence

The study is a finite local experiment. Its authenticated browser-to-approved-executor route was **NOT RUN**. Reproduction does not create an operator identity, signing key, wallet, daemon or financial transaction.

## Reference environment

Python 3.12.14; Node 24.22.1; SciPy 1.17.0; NumPy 2.4.6; Pydantic 2.13.5; cryptography 50.0.1. Figure generation uses Matplotlib 3.10.8. `sources/ENVIRONMENT.json` records the observed environment. The original strategy worker's Node-to-Python subprocess must be permitted by the approved execution environment. A sandbox that refuses it is not a reason to change source guards or create credentials.

The bundled selected runtime source is pinned to Alpha commit `f836f06e8351e64db1da770e16e304b5feb01f28`. It is a selected source snapshot, not a full installed release. Source manifests identify exact files. All task data are public-source packets or authored synthetic inputs.

## Verify first

From the study root:

```bash
python analysis/independent_summary_audit.py
python economics/validate.py
```

The first command rechecks delivered artifacts with the frozen independent acceptance implementations. It does not launch a new mission or rewrite the 110 frozen input files. Its generated audit report is separate from the original confirmation results. The second checks the frozen economic model identities and arithmetic; it does not download a new data vintage.

## Fresh reproduction

Choose a new path outside the delivered study. The script refuses an existing destination and copies only the verified 110 frozen inputs plus their manifest.

```bash
python reproduction/reproduce.py --destination ../alpha-capability-rerun --prepare-only
```

That command only prepares and verifies a copy. To execute all experiments, use a **different new destination** and omit `--prepare-only`:

```bash
python reproduction/reproduce.py --destination ../alpha-capability-confirmation-rerun
```

All commands, stdout, stderr, failures and return codes are retained in the new directory. No failed step is automatically retried. Numerical outputs should satisfy the frozen contracts; wall time and CPU depend on host conditions. A rerun is a reproduction and must not be added to the original study's task counts. No additional external service call is required by the deterministic workers.

The original commands use seeds 2026102507 (primary non-planning and load), 2026102517 (planning), 2026102527 (source mechanisms), 2026102537 (review), 2026102547 (controls) and 2026102557 (analysis bootstrap). See `protocol/PROTOCOL.md` for every denominator and limit.

## Paper and editable figures

The publication requires a conventional TeX Live installation with pdfLaTeX, BibTeX and the packages listed in `paper/main.tex`.

```bash
cd paper
make figures
make clean
make all
```

`make figures` regenerates the five execution figures from the immutable result JSON. The three economic figures have their own editable script and input manifest in `figures/`. The supplied SVGs retain text and vector elements. `make all` pins `SOURCE_DATE_EPOCH`; a clean repeated build must reproduce the canonical PDF hash in `publication/BUILD_VERIFICATION.json` for the reference toolchain.

Rendered page images are an internal visual-quality check and are not needed for reproduction. The final PDF and editable sources are the deliverables.

## Browser companion

Open the standalone companion HTML from `browser/` in a modern browser. Its visible badges distinguish actual local computation, recorded planning evidence and modeled economics. Source and evidence downloads are embedded. An existing approved executor remains a separate operator process; use its existing documented authentication and authority only. No unapproved server or credentials are supplied by this study.

## Cost boundaries

Local CPU and turnaround are measured. Complete infrastructure price, host-model authorship, employer attention, deployment, support and maintenance are unknown. Explicit strategy work units are neither CPU seconds nor money. The economics model therefore remains conditional. Source prices preserve currency, geography, year and benefits coverage; refreshing them creates a new economic vintage.

## Preserving the earlier edition

The Economics edition associated with PR #4901 is a separate study. Its 69 frozen files and canonical PDF were checked unchanged. No reproduction command here updates that edition, its publication records or its results.
