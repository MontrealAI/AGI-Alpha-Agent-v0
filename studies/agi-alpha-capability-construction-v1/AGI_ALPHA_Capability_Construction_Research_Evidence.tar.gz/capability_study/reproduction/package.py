#!/usr/bin/env python3
"""Deterministic local publication packages; never publishes remotely.

The default is a dry run. Final mode requires completed browser QA and an explicit
publication-status record. Original evidence and source files are never changed.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile
import zipfile
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parents[1]
PREFIX = "capability_study"
MANIFEST = "SHA256SUMS.json"
PDF_NAME = "AGI_ALPHA_Flywheel_Capability_Construction.pdf"
COMPANION_NAME = "AGI_ALPHA_Flywheel_Capability_Construction_Companion.zip"
TEX_NAME = "AGI_ALPHA_Flywheel_Capability_Construction_LaTeX_Source.zip"
HTML_NAME = "AGI_ALPHA_Capability_Construction_Demo.html"
SCORECARD_NAME = "AGI_ALPHA_Capability_Construction_Scorecard.json"
LEDGER_NAME = "AGI_ALPHA_Capability_Construction_Ledger.csv"

TOP_LEVEL = {
    "README.md",
    "analysis",
    "browser",
    "development",
    "economics",
    "evaluation",
    "figures",
    "paper",
    "protocol",
    "publication",
    "reproduction",
    "raw",
    "sources",
    "src",
    "strategy_worker",
    "upstream",
}
TRANSIENT_TEX = {
    ".aux",
    ".bbl",
    ".blg",
    ".log",
    ".out",
    ".toc",
    ".fls",
    ".fdb_latexmk",
    ".nav",
    ".snm",
    ".vrb",
}
PRIVATE_DIRS = {
    "credentials",
    "secrets",
    "private",
    "operator-home",
    "operator_state",
    "library_receipts",
    "provider_receipts",
    "node_modules",
}
PRIVATE_EXTENSIONS = {".pem", ".key", ".p12", ".pfx", ".docx", ".docm"}
FIGURE_INPUTS = {
    "analysis/SUMMARY.json",
    "analysis/planning.json",
    "raw/planning/connected-release-2026102518/schedule.csv",
}
PRIVATE_KEY = re.compile(
    rb"(?m)^-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----\s*$"
)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def git_blob_sha(data: bytes) -> str:
    envelope = f"blob {len(data)}\0".encode() + data
    return hashlib.sha1(envelope, usedforsecurity=False).hexdigest()


def serialized(value) -> bytes:
    return (
        json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n"
    ).encode()


def read_json(path: Path):
    return json.loads(path.read_bytes())


def exclusion(relative: Path) -> str | None:
    parts = relative.parts
    lower_parts = {p.lower() for p in parts}
    if any(p.startswith(".") for p in parts):
        return "hidden state or cache"
    if "__pycache__" in parts or relative.suffix in {".pyc", ".pyo"}:
        return "Python cache"
    if lower_parts.intersection(PRIVATE_DIRS):
        return "private/provider/operator state or dependencies"
    if relative.suffix.lower() in PRIVATE_EXTENSIONS:
        return "credential/private-document extension"
    if parts[0] == "deliverables":
        return "historical checkpoint preserved separately; no nested release archives"
    if parts[:2] == ("browser", "qa"):
        return "internal browser screenshots and downloaded QA fixtures"
    if parts[0] == "paper" and (
        relative.suffix in TRANSIENT_TEX or relative.name.endswith(".synctex.gz")
    ):
        return "transient TeX build product"
    if relative.name.endswith("_pdfproof.png"):
        return "internal PDF figure inspection capture"
    if parts[0] not in TOP_LEVEL:
        raise ValueError(f"Unclassified study path: {relative}")
    return None


def collect() -> tuple[dict[str, bytes], list[dict]]:
    selected = {}
    excluded = []
    for path in sorted(ROOT.rglob("*")):
        if path.is_symlink():
            raise ValueError(
                f"Symlink is not a distributable regular file: {path.relative_to(ROOT)}"
            )
        if not path.is_file():
            continue
        relative = path.relative_to(ROOT)
        reason = exclusion(relative)
        if reason:
            excluded.append({"path": relative.as_posix(), "reason": reason})
            continue
        content = path.read_bytes()
        if PRIVATE_KEY.search(content):
            raise ValueError(f"Private-key material requires review: {relative}")
        selected[relative.as_posix()] = content
    return selected, excluded


def verify_freeze(files: dict[str, bytes], freeze: dict) -> int:
    assert len(freeze["files"]) == 110, "Unexpected frozen-file inventory"
    for entry in freeze["files"]:
        name = entry["path"]
        if name not in files:
            raise ValueError(f"Frozen input missing from payload: {name}")
        if sha(files[name]) != entry["sha256"]:
            raise ValueError(f"Frozen input changed: {name}")
    return len(freeze["files"])


def validated_relative(value: str) -> Path:
    candidate = ROOT / value
    resolved = candidate.resolve()
    if not resolved.is_relative_to(ROOT):
        raise ValueError("Readiness records must be inside this study")
    return resolved


def readiness(files: dict[str, bytes], publication_path: Path, qa_path: Path) -> dict:
    missing = [
        str(p.relative_to(ROOT)) for p in (publication_path, qa_path) if not p.is_file()
    ]
    issues = []
    data = {"missing_records": missing, "issues": issues}
    build = json.loads(files["publication/BUILD_VERIFICATION.json"])
    pdf_hash = sha(files["paper/main.pdf"])
    if not build.get("byte_identical") or build.get("clean_build_sha256") != pdf_hash:
        issues.append("Canonical PDF does not match clean-build verification")
    scientific = json.loads(files["analysis/INDEPENDENT_SCIENTIFIC_AUDIT.json"])
    if scientific.get("passed") is not True:
        issues.append("Independent scientific audit is not passed")
    browser = json.loads(files["browser/BUILD_MANIFEST.json"])
    if browser["sha256"] != sha(files[f"browser/{HTML_NAME}"]):
        issues.append("Browser HTML does not match its build manifest")
    if qa_path.is_file():
        qa = read_json(qa_path)
        if not (qa.get("attempted", 0) > 0 and qa.get("passed") == qa["attempted"]):
            issues.append("Browser QA has incomplete or failed checks")
        if qa.get("page_errors") or qa.get("external_requests"):
            issues.append("Browser QA reports script errors or external requests")
        data["browser_checks"] = qa.get("attempted")
        data["browser_qa_sha256"] = sha(qa_path.read_bytes())
    if publication_path.is_file():
        status = read_json(publication_path)
        if not isinstance(status, dict) or not status:
            issues.append("Publication status is not a nonempty object")
        if status.get("prepared") is False:
            issues.append("Publication status explicitly says not prepared")
        data["publication_status_sha256"] = sha(publication_path.read_bytes())
    data["ready"] = not missing and not issues
    return data


def zip_time(freeze: dict) -> tuple:
    stamp = datetime.fromisoformat(freeze["frozen_utc"]).astimezone(timezone.utc)
    return (
        stamp.year,
        stamp.month,
        stamp.day,
        stamp.hour,
        stamp.minute,
        stamp.second // 2 * 2,
    )


def companion_readme(pdf_hash: str, freeze_hash: str) -> bytes:
    return f"""# AGI ALPHA capability-construction companion

This complete local research payload preserves source, the 110 frozen inputs,
raw results, unsuccessful development, market-data economic models, measured
cost ledgers, intervention records, editable figures, the paper, and browser
companion. Extract the archive before opening HTML or running code.

Start with `capability_study/README.md` and
`capability_study/reproduction/README.md`. The browser HTML is self-contained.
Its local computations, recorded planning evidence, and conditional economics
are labeled separately. Authenticated browser-to-approved-executor operation
was NOT RUN; no operator credential, daemon or financial route is supplied.

The canonical PDF SHA-256 is `{pdf_hash}`.
The prospective FREEZE.json SHA-256 is `{freeze_hash}`.
`SHA256SUMS.json` hashes every archive member except itself. The file contents
are unchanged from the selected local originals. Archive member order, times,
permissions and compression settings are fixed for deterministic packaging.

`capability_study/publication/STATUS.json` (or the status record named in the
package verification report) describes the actual publication stage. Packaging
is not a merge, remote publication, deployment or public-availability check.
Earlier editions and their prospective checkpoint remain preserved separately.

Excluded materials are caches, transient TeX build products, internal browser
screenshots and downloaded QA fixtures, PDF inspection captures, provider/private
state, and nested historical checkpoint archives. Scientific stdout, stderr,
failed attempts and their original receipts remain included. File selection and
a private-key marker check are not a claim of comprehensive security certification.

The two primary implementation license families and exact source provenance are
in `capability_study/reproduction/licenses/`. Original source notices remain
intact. Official statistics retain their recorded source terms and scope.

Recreating the experiment requires the reference environment and a fresh output
directory, as described in the reproduction guide. Complete monetary costs,
human attention and long-term maintenance remain unmeasured. Qualification and
load cases are not additional primary customer jobs.
""".encode()


def source_readme(pdf_hash: str) -> bytes:
    return f"""# Compilable LaTeX and editable figure source

This compact archive includes the entire paper source, its bibliography and
section dependencies, publication figures in PDF/SVG/PNG, both figure-generation
scripts, and all data inputs those scripts read. It is not the complete raw
evidence archive. Obtain the complete companion ZIP for execution receipts,
failed attempts, evaluator source and the prospective 110-file protocol.

## Compile the supplied figures into the paper

Use the reference TeX Live/pdfLaTeX/BibTeX toolchain from the companion environment
record, with the packages declared at the top of `paper/main.tex`.

```sh
cd capability_study/paper
make all
```

No precompiled main.pdf is included in this source archive. The Makefile performs
the necessary pdfLaTeX/BibTeX passes and pins SOURCE_DATE_EPOCH. The canonical PDF
SHA-256 is `{pdf_hash}`. The packaging report records the actual clean compilation
of the extracted source. A different TeX/font toolchain can change PDF bytes.

## Regenerate figures

From `capability_study/paper`, run `make figures`. This reads the included
`analysis/SUMMARY.json`, `analysis/planning.json` and connected schedule CSV.
From `capability_study`, run `python figures/make_economic_figures.py` for the three
economic figures. Their economic results, scenario inputs and labor rates are
included. Python, NumPy and Matplotlib are required; versions are recorded in
`sources/ENVIRONMENT.json`. Regeneration is separate from compiling the supplied
publication figure bytes. Runtime/library metadata may change regenerated file
hashes without changing the plotted data.

Every member except this archive's manifest is listed in SHA256SUMS.json. Source
files are unchanged. Frozen source inputs included in this compact subset are
checked against the original freeze; the full companion is independently checked
against all 110 entries. No experimental result is created by rebuilding figures.
""".encode()


def payloads(files: dict[str, bytes], freeze: dict) -> tuple[dict, dict]:
    pdf_hash = sha(files["paper/main.pdf"])
    complete = {f"{PREFIX}/{name}": data for name, data in files.items()}
    complete["README_PACKAGE.md"] = companion_readme(
        pdf_hash, sha(files["protocol/FREEZE.json"])
    )
    source = {}
    for name, data in files.items():
        include = (
            name.startswith(
                ("paper/", "figures/", "economics/", "reproduction/licenses/")
            )
            or name in FIGURE_INPUTS
            or name
            in {"sources/ENVIRONMENT.json", "publication/BUILD_VERIFICATION.json"}
        )
        if include and name != "paper/main.pdf":
            source[f"{PREFIX}/{name}"] = data
    source["README_LATEX_SOURCE.md"] = source_readme(pdf_hash)
    assert all(f"{PREFIX}/{p}" in source for p in FIGURE_INPUTS)
    return complete, source


def archive_manifest(payload: dict[str, bytes], kind: str) -> bytes:
    return serialized(
        {
            "schema": "capability-archive-sha256/v1",
            "archive_kind": kind,
            "algorithm": "SHA-256",
            "self_excluded": MANIFEST,
            "members": [
                {"path": name, "bytes": len(data), "sha256": sha(data)}
                for name, data in sorted(payload.items())
            ],
        }
    )


def write_archive(
    path: Path, payload: dict[str, bytes], kind: str, stamp: tuple
) -> None:
    members = {**payload, MANIFEST: archive_manifest(payload, kind)}
    with zipfile.ZipFile(
        path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9
    ) as out:
        for name, content in sorted(members.items()):
            info = zipfile.ZipInfo(name, stamp)
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            info.extra = b""
            info.comment = b""
            out.writestr(
                info, content, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9
            )


def audit_archive(
    path: Path, payload: dict[str, bytes], freeze: dict, complete: bool
) -> dict:
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        assert len(names) == len(set(names))
        assert set(names) == set(payload) | {MANIFEST}
        assert archive.testzip() is None
        manifest = json.loads(archive.read(MANIFEST))
        assert len(manifest["members"]) == len(payload)
        for entry in manifest["members"]:
            data = archive.read(entry["path"])
            assert len(data) == entry["bytes"]
            assert sha(data) == entry["sha256"]
            assert data == payload[entry["path"]]
        verified = 0
        for entry in freeze["files"]:
            name = f"{PREFIX}/{entry['path']}"
            if name in names:
                assert sha(archive.read(name)) == entry["sha256"]
                verified += 1
            elif complete:
                raise AssertionError(f"Missing frozen archive member: {name}")
        pdf_name = f"{PREFIX}/paper/main.pdf"
        pdf_hash = sha(archive.read(pdf_name)) if pdf_name in names else None
    return {
        "members_including_manifest": len(names),
        "member_bytes_verified": True,
        "frozen_members_verified": verified,
        "all_110_frozen_members_required": complete,
        "canonical_pdf_sha256": pdf_hash,
        "archive_sha256": sha(path.read_bytes()),
        "archive_bytes": path.stat().st_size,
    }


def compile_extracted_source(
    archive_path: Path, temporary: Path, expected_pdf: str
) -> dict:
    target = temporary / "latex-source-build"
    target.mkdir()
    with zipfile.ZipFile(archive_path) as archive:
        for name in archive.namelist():
            parts = PurePosixPath(name).parts
            assert not name.startswith("/") and ".." not in parts
        archive.extractall(target)
    paper = target / PREFIX / "paper"
    run = subprocess.run(
        ["make", "all"],
        cwd=paper,
        capture_output=True,
        text=True,
        timeout=180,
        check=False,
    )
    if run.returncode:
        raise RuntimeError(
            "Extracted LaTeX source failed to compile: "
            + (run.stdout + run.stderr)[-4000:]
        )
    compiled = sha((paper / "main.pdf").read_bytes())
    if compiled != expected_pdf:
        raise RuntimeError(
            f"Extracted source PDF differs from canonical PDF: {compiled}"
        )
    log = (paper / "main.log").read_text(errors="replace")
    if "Overfull \\" in log or "There were undefined references" in log:
        raise RuntimeError("Extracted source build reports layout/reference defects")
    figure_checks = []
    for command, cwd in (
        (["make", "figures"], paper),
        ([sys.executable, "figures/make_economic_figures.py"], target / PREFIX),
    ):
        generated = subprocess.run(
            command,
            cwd=cwd,
            capture_output=True,
            text=True,
            timeout=180,
            check=False,
        )
        if generated.returncode:
            raise RuntimeError(
                "Extracted figure source failed: "
                + (generated.stdout + generated.stderr)[-4000:]
            )
        figure_checks.append({"command": command, "exit_code": generated.returncode})
    stems = (
        "signature_flywheel",
        "portfolio_turnaround",
        "connected_planning",
        "inheritance_and_cost",
        "finite_capacity",
        "economic_adoption",
        "economic_market_scopes",
        "economic_reuse_payback",
    )
    for stem in stems:
        for extension in ("pdf", "svg", "png"):
            assert (target / PREFIX / "figures" / f"{stem}.{extension}").is_file()
    return {
        "command": "make all",
        "exit_code": run.returncode,
        "compiled_pdf_sha256": compiled,
        "matches_canonical_pdf": True,
        "overfull_or_undefined_reference_warnings": False,
        "figure_regeneration": figure_checks,
        "regenerated_figures": len(stems),
        "regenerated_formats_per_figure": ["pdf", "svg", "png"],
        "scope": "Compile extracted compact source with supplied publication figure bytes; no mission execution",
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_mutually_exclusive_group()
    modes.add_argument("--dry-run", action="store_true")
    modes.add_argument("--final", action="store_true")
    parser.add_argument("--output", type=Path, default=ROOT.parent / "deliverables")
    parser.add_argument("--publication-status", default="publication/STATUS.json")
    parser.add_argument("--browser-qa", default="browser/QA_REPORT.json")
    args = parser.parse_args()
    output = args.output.resolve()
    if output.is_relative_to(ROOT):
        raise ValueError("Final deliverables must be outside the study tree")
    files, excluded = collect()
    freeze = json.loads(files["protocol/FREEZE.json"])
    frozen_count = verify_freeze(files, freeze)
    publication = validated_relative(args.publication_status)
    qa = validated_relative(args.browser_qa)
    ready = readiness(files, publication, qa)
    complete, source = payloads(files, freeze)
    plan = {
        "mode": "final" if args.final else "dry-run",
        "frozen_files_verified": frozen_count,
        "selected_files": len(files),
        "selected_bytes": sum(map(len, files.values())),
        "companion_members_including_manifest": len(complete) + 1,
        "latex_source_members_including_manifest": len(source) + 1,
        "excluded_files": len(excluded),
        "exclusion_reasons": dict(Counter(x["reason"] for x in excluded)),
        "readiness": ready,
        "destination": str(output),
        "remote_publication": False,
    }
    if not args.final:
        print(json.dumps(plan, indent=2))
        return
    if not ready["ready"]:
        raise RuntimeError("Final packaging not ready: " + json.dumps(ready))
    final_names = [
        PDF_NAME,
        COMPANION_NAME,
        TEX_NAME,
        HTML_NAME,
        SCORECARD_NAME,
        LEDGER_NAME,
        "PACKAGE_VERIFICATION.json",
        MANIFEST,
    ]
    for name in final_names:
        if (output / name).exists():
            raise FileExistsError(f"Preserve previous deliverable: {output / name}")
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(
        prefix="alpha-publication-package-", dir=output.parent
    ) as work:
        temporary = Path(work)
        staged = temporary / "final"
        staged.mkdir()
        stamp = zip_time(freeze)
        complete_path = staged / COMPANION_NAME
        source_path = staged / TEX_NAME
        write_archive(complete_path, complete, "complete-companion", stamp)
        write_archive(source_path, source, "compilable-latex-source", stamp)
        complete_audit = audit_archive(complete_path, complete, freeze, True)
        source_audit = audit_archive(source_path, source, freeze, False)
        pdf_hash = sha(files["paper/main.pdf"])
        assert complete_audit["canonical_pdf_sha256"] == pdf_hash
        build = compile_extracted_source(source_path, temporary, pdf_hash)
        for name, payload, kind in (
            (COMPANION_NAME, complete, "complete-companion"),
            (TEX_NAME, source, "compilable-latex-source"),
        ):
            repeated = temporary / name
            write_archive(repeated, payload, kind, stamp)
            assert sha(repeated.read_bytes()) == sha((staged / name).read_bytes())
        for name, original in {
            PDF_NAME: "paper/main.pdf",
            HTML_NAME: f"browser/{HTML_NAME}",
            SCORECARD_NAME: "analysis/LAUNCH_SCORECARD.json",
            LEDGER_NAME: "analysis/LEDGER.csv",
        }.items():
            (staged / name).write_bytes(files[original])
        current, _ = collect()
        assert current == files, "Selected study files changed during packaging"
        verification = {
            "schema": "capability-final-package-verification/v1",
            "status": "PASS",
            "basis_frozen_utc": freeze["frozen_utc"],
            "archive_timestamp_utc": list(stamp),
            "compression": "ZIP_DEFLATED level 9; sorted paths; normalized regular-file permissions",
            "canonical_pdf_sha256": pdf_hash,
            "freeze_sha256": sha(files["protocol/FREEZE.json"]),
            "frozen_files_verified": frozen_count,
            "complete_companion": complete_audit,
            "latex_source": source_audit,
            "extracted_source_clean_build": build,
            "repeated_archive_builds_byte_identical": True,
            "originals_unchanged": True,
            "publication_status_path": str(publication.relative_to(ROOT)),
            "browser_qa_path": str(qa.relative_to(ROOT)),
            "readiness": ready,
            "excluded_files": excluded,
            "selection_privacy_scope": "Selected study tree only; no original DOCX, private operator home, credentials, provider persistence records, browser screenshots or internal captures. Filename and private-key checks are not a comprehensive security certification.",
            "remote_publication": False,
        }
        (staged / "PACKAGE_VERIFICATION.json").write_bytes(serialized(verification))
        checksums = {
            "schema": "capability-release-sha256/v1",
            "algorithm": "SHA-256",
            "self_excluded": MANIFEST,
            "files": [
                {
                    "path": p.name,
                    "bytes": p.stat().st_size,
                    "sha256": sha(p.read_bytes()),
                    "git_blob_sha1": git_blob_sha(p.read_bytes()),
                }
                for p in sorted(staged.iterdir())
            ],
        }
        (staged / MANIFEST).write_bytes(serialized(checksums))
        output.mkdir(parents=True, exist_ok=True)
        for path in sorted(staged.iterdir()):
            if (output / path.name).exists():
                raise FileExistsError(output / path.name)
            os.replace(path, output / path.name)
        for entry in checksums["files"]:
            data = (output / entry["path"]).read_bytes()
            assert len(data) == entry["bytes"] and sha(data) == entry["sha256"]
    print(json.dumps({"status": "PASS", **plan, "files": checksums["files"]}, indent=2))


if __name__ == "__main__":
    main()
