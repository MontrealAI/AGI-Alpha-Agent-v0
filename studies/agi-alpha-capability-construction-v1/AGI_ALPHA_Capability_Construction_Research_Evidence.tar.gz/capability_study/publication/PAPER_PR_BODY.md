## Summary

This adds the separately preregistered capability-construction continuation of #4850 as a new immutable research paper. It is a passive paper proposal: the canonical PDF, one catalog record and five deterministic README/homepage/service-worker outputs. No new HTML experience, runtime source, workflow, dependency or software-release version is included.

**Stacking:** this proposal targets `main` and is prepared on the complete reviewed Economics paper tree from #4902. Merge/review #4902 independently first; this continuation must not delay or replace that earlier publication. The older #4901 study, its frozen protocol, findings, limitations and originals remain unchanged. The new study's source/evidence draft is separately identified through a commit-pinned `experimental_source` README; it is not part of this paper branch's source history and is not described as qualified software.

## Research result and limits

The 27-page paper reports 42/42 accepted primary instances across seven bounded digital-work families, actual invocation of retained capabilities and a complete evidence trail. The strongest available specialist defeats the retained repair candidate in all twelve fresh comparisons; the full product still completes the paired tasks. Neither the inheritance experiments nor three discovery cycles establish net economic gains or self-acceleration. Finite local load results and official labor-market scenarios retain their separate denominators and limitations.

The economic benchmark is competent traditional human work with ordinary non-AI tools. The paper uses sourced wages, employer costs and published human-performance evidence without inventing matched task duration. Complete Agent cost and employer attention remain unknown. The companion is experimental research material; authenticated approved-executor execution remains not run.

## Exact paper change

- Add `docs/papers/agi-alpha-capability-construction-v1.pdf` with its original bytes.
- Append the catalog record to `docs/research-papers.json`, preserving all older records and the existing featured paper.
- Regenerate only the research-paper blocks in `README.md` and `docs/index.html`, plus the three existing lightweight service workers, using the unchanged importer.

The complete compilable LaTeX, figures, source and raw evidence belong to the separately linked companion. A lone dependent `main.tex` is not presented as standalone TeX. The archive link uses the allowed commit-pinned experimental source route; no guessed research release URL or unsupported `source_archive` commit URL is introduced.

## Validation

- Existing locked validator: `pypdf==6.21.2`.
- Canonical PDF: 622,372 bytes; SHA-256 `51ee8ded6860b6ab6b1a7bd1e0901fe864a96c30d40446c3743dd975ba139b28`.
- Importer and complete paper-catalog validation passed locally.
- Exact seven-path draft check and `git diff --check` passed locally.
- Canonical paper clean build is byte-identical, with no overfull boxes or undefined references; visual page-review reports accompany the separate evidence package.
- Formal pre-change Git-history proof and exact public source-link readback must be recorded for the final proposed head. The local preparation record must not be mistaken for a hosted check.

Local pre-commit and hosted `Lint (ruff)`/`Smoke tests` results must be reported for the actual final head. No unrun repository check or software acceptance is claimed. The existing paper publication workflow must still prove ancestry from the public software baseline, validate the homepage/links and verify actual served PDF bytes. A successful passive paper check does not imply merge, publication or runtime qualification.

No release tag, immutable software asset, credentials, security setting, contract, financial transaction or held Harness/Fleet action is changed. References #4850 and stacks after #4902; does not close the larger research program.
