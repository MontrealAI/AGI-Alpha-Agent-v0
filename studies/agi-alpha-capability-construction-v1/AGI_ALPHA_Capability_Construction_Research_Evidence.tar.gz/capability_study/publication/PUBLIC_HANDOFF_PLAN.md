# Public evidence handoff: capability-construction study

**Status: prepared locally for the existing publication owner. No remote write, merge, release, deployment or approval was performed by this inspection.**

This is the new continuation of issue #4850. It does not replace the Economics of Autonomous Work edition associated with #4901, the earlier Strategy Succession study, or any existing software release. All scientific identities remain tied to the separately frozen 110-file experiment. Publication files have their own later identities.

## Recommended smallest additive route

Use two independent changes. First, submit a new immutable research PDF through the existing paper lane. Second, hand off the complete new study in a versioned `studies/` directory for an explicitly experimental source/evidence draft. Keep source, evidence and the downloadable companion together in one public payload, with a separate exact manifest. Publishing a new interactive page on the production website is a later full-source action; it is not needed to make the PDF or a downloadable research companion available.

For the immediate complete-evidence route, the experimental source draft may carry a complete companion ZIP and its manifest below the new study directory, together with an inspectable README. After that public commit exists, the paper can link its exact README through `experimental_source`. The README may provide a commit-pinned download of the archive. This uses ordinary source publication and creates no research release, runtime installation or website deployment. The catalog's `source_archive` role cannot point to a commit, blob or raw-file URL: it specifically requires a verified release-download ZIP. Keep that role absent unless the owner later uses the distinct research-release route.

The suggested, locally collision-checked identifier is `agi-alpha-capability-construction-v1`. Its suggested source destination is `studies/agi-alpha-capability-construction-v1/`. These are proposed new identities, not claims that remote branches, URLs, tags or assets already exist. The receiving owner should refresh current main, the active release lease and identifier availability before selecting them.

The first paper-only change need contain **seven files**. Omit optional TeX from that narrow change unless a separately verified standalone form exists. The current `paper/main.tex` needs its section, bibliography and figure files; the complete compilable source is already in the study payload. Calling that single source file standalone would be misleading. The paper lane does not compile TeX.

### Exact narrow paper path set

| Path | Permitted change |
|---|---|
| `docs/papers/agi-alpha-capability-construction-v1.pdf` | Add the final canonical PDF, preserving its exact bytes. |
| `docs/research-papers.json` | Append one new versioned record with truthful English/French summary and actual PDF title/hash. Preserve existing records, original identities and featured placement. |
| `README.md` | Only the importer-generated research-paper block. |
| `docs/index.html` | Only the importer-generated research-paper block. |
| `docs/service-worker.js` | Exact output of the unchanged generator. |
| `docs/assets/service-worker.js` | Exact output of the unchanged generator. |
| `docs/alpha_factory_v1/demos/alpha_agi_insight_v1/service-worker.js` | Exact output of the unchanged generator. |

The optional eighth path is `docs/papers/agi-alpha-capability-construction-v1.tex`, but it is not required for the minimal PDF proposal. Do not add the temporary importer metadata JSON to the checkout. A candidate metadata file is supplied separately in this handoff.

Use the existing `python -m scripts.research_papers add` importer in a separate authorized working copy, then `python -m scripts.research_papers check`. Review the exact diff. Commit the complete catalog/PDF/generated change together. Do not hand-edit generated blocks or service workers. No software version bump is required for a successfully proved paper-only change.

The trusted pre-change classifier checks every introduced transition, including side-branch history, with a 200-commit bound. Unknown paths, modified source, new HTML, dependencies, workflows, policy changes, file-mode changes or removals force full qualification. A source change followed by a revert is still a source change in that history. If a web upload creates intermediate incomplete commits, the documented complete reviewed squash route is available; a merge retaining those intermediates takes the full lane. The ordinary UTF-8 changelog exception is unnecessary here and would also require the strict documentation build.

## Complete source, evidence and companion handoff

The source/evidence proposal is additive below the new `studies/agi-alpha-capability-construction-v1/` directory. It must not edit the old study, existing contracts, runtime source, owner branches, release workflows, source-pin guards or repository policy merely to fit the experiment. Its public README must describe this as an experimental research payload and retain the negative mechanism results and unknown full costs.

The exact current candidate file selection is recorded in `PUBLIC_HANDOFF_SELECTION.json`. It is an inventory snapshot, not a final archive manifest: the browser owner was still completing the companion when this plan was prepared. Seal a final manifest only after those files and their acceptance evidence are terminal.

| Study component | Include in the complete public payload |
|---|---|
| `protocol/` | Original frozen protocol, manifest, acceptance/analysis declarations and custody evidence. Preserve all 110 frozen file bodies and the original manifest byte for byte. |
| `src/`, `evaluation/` | Frozen implementation and independent acceptance code, plus explicitly later audit reports. Preserve source/license notices. |
| `upstream/`, `strategy_worker/`, `sources/` | Selected pinned original runtime/worker snapshots, exact source identities and public-source records. These remain selected snapshots, not a full installed software release. |
| `raw/`, `development/` | Every original successful, failed, refused and interrupted attempt and its material inputs/outputs. Do not retain only accepted results. |
| `analysis/` | Result summaries, delivery/improvement ledgers, independent arithmetic/artifact audit and scorecard. |
| `economics/` | Frozen source data, methods, occupation mappings, model, scenarios, bibliography and validation. Unknown observed costs remain null. |
| `paper/`, `figures/` | Final PDF, complete compilable LaTeX, bibliography, Makefile, original plotting code, SVG/PDF/PNG figures and build/QA evidence. |
| `browser/` | The completed self-contained companion, its editable source and observed QA evidence. Clearly separate local computation, replay and modeled economics. |
| `reproduction/`, `README.md`, public `publication/` records | Exact rebuild/reproduction instructions, publication status, manifest/hash records and reviewable handoff information. |

Exclude interpreter caches, virtual environments, `.git`, local transfer helpers, provider locators/receipts, private prompts or original private files, credentials, private operator state and temporary document-build products. Retain scientific stdout/stderr and failed-attempt logs; excluding temporary TeX logs is not permission to drop execution failures. No private participant material is present in the measured experiment. The final public selection still needs an explicit privacy/secret review; a filename or pattern scan alone is not a certification.

The prospective checkpoint ZIP is a distinct historical custody artifact. Keep its stated hash and durable receipt. It may be handed off separately or retained unchanged as a documented historical asset, but it is not the finished paper/companion package. Do not silently regenerate it with later outputs under the same name.

For a compact source PR, the existing Strategy study provides a precedent for keeping editable source, summaries and a complete evidence index in Git while passing large raw-evidence archives separately to the owner. If that split is chosen, the public README and availability record must say the raw archive is not yet publicly released until the actual asset exists. The complete downloadable companion must restore the exact original paths and include all raw and negative evidence. Do not call the smaller source tree a complete evidence distribution. Alternatively, an ordinary source draft may include the complete public evidence files or bounded archives below its new study directory; those additions are full-scope source changes, even when the archives contain research data.

A distinct immutable research release is permitted by the existing paper policy and does not replace the latest software release. The existing owner must choose its unused tag, qualify the exact public payload as required, upload it, re-download it and verify its size/hash before catalog links claim availability. The complete companion ZIP should contain both the runnable source and all evidence, avoiding an unnecessary second archive when one suffices. There is no need to modify the software release version or existing release assets to distribute that research archive.

## Resource links supported by the inspected implementation

The current code supports more closed resource roles than the older prose guide lists. Use the actual trusted parser and do not add schema fields or change it for this study.

| Role | Exact required fields and boundary |
|---|---|
| `experimental_source` | `{url}`: this repository's `blob/<40-character-commit>/studies/<versioned-name>/README.md`. Use only after that exact public source commit and README have been verified. The fixed label identifies historical experimental source, not accepted software. |
| `current_companion` | `{url}`: this repository's `blob/main/studies/<versioned-name>/README.md`. Use only when the maintained guide actually exists on main and its status is accurate. |
| `companion`, `source_archive` | `{url, sha256, bytes}`: canonical repository `releases/download/<simple-tag>/<simple-name>.zip`, positive size at most 2,147,483,647 bytes. A single complete companion avoids duplicate payloads. |
| `source_evidence` | `{url}`: canonical repository `releases/tag/<simple-tag>`. Where an archive role is also present, it must name the same research tag. |
| `reading`, `experience` | `{path, sha256}`: ordinary UTF-8 `docs/reports/<versioned-study>/<simple-name>.html`, at most 25,000,000 bytes. New or changed HTML requires full source qualification. |
| `tex_source` | `{path, sha256}` matching the paper record's exact TeX source. Its fixed navigation label promises standalone TeX. |

Do not populate placeholder commit hashes, guessed release URLs or declared archive hashes as if they establish public availability. A paper can be submitted without resource roles and receive new verified roles later; existing resource identities cannot be retargeted. Changed published paper, HTML or archive identities need a new versioned record. An `experimental_source` link can point to an explicitly unmerged public source draft without implying that draft passed software acceptance, but the exact commit and public bytes must actually exist.

## Production website and executable boundaries

A new companion HTML file under `docs/reports/` takes the full lane. Linking a new HTML file from paper metadata does not transfer it into the qualified site: the paper overlay copies only catalog-referenced PDF/TEX assets and deterministic paper surfaces. For an experience link, current checkout, already-public software source and restored immutable site pack must contain byte-identical HTML, or the overlay defers. First make the downloadable companion useful; add a production website experience through the current owner's full source/site qualification when ready.

A local browser demonstration or an archived acceptance report does not replace configured review, applicable hosted PR checks, full resulting-main release acceptance, public asset verification or installed acceptance. The study's authenticated approved-executor route remains **NOT RUN** unless a separately recorded authorized execution actually establishes it. No new credentials, security settings, wallet, server authority or financial transaction is authorized by this publication plan.

The inspected current readiness record identifies a 1.44.0 Strategy Succession candidate and says its existing publisher owns all assets. Its previous installed results do not transfer to this study. The original Harness #4863 review/merge restriction, #4865 dependency, Fleet restrictions, four excluded native outcomes and five protected source pins remain with their owners. An experimental label, a research ZIP or a paper-lane pass does not clear them. The source-specific Strategy lint exceptions cover named historical bytes; they are not blanket exceptions for this new frozen study. If blocking lint conflicts with frozen source, preserve the original evidence and obtain the applicable exact-source review/disposition instead of formatting frozen inputs or widening exclusions unilaterally.

## Hold conditions and truthful status

| Boundary | Required evidence before advancing |
|---|---|
| Final public payload | Browser work complete; 110 frozen inputs and prior 69 identities unchanged; complete manifest sealed; private/provider material excluded; raw evidence availability accurately stated. |
| Public source draft | Existing authorized owner/process, exact selected files and privacy scope; actual check outcomes disclosed. Local hook completion is not a prerequisite to a draft, and unrun checks are not passes. |
| Source merge or software/site release | Configured exact-source review, applicable hosted PR checks and all required resulting-main security, integrity, regression, dependency, browser, packaging and source-binding gates. No action-level holds bypassed. |
| Research asset availability | Authorized owner/tag, exact public payload, successful upload followed by actual re-download/hash/size verification; no replacement of historical release bytes. |
| Paper-only classification | Trusted pre-change policy, complete exact Git history, immutable originals, passive PDF checks, exact generated outputs and applicable hosted checks. |
| Public paper website | Matching software already public; paper-only ancestry from that qualified software baseline; homepage/link acceptance; current-main/public-baseline/monotonic guard; actual served PDF and provenance verification. A mixed pending software main can defer the paper overlay. |
| Production companion page | Full qualification of the new HTML and its source, then exact qualified/source/site bytes and public interaction acceptance. |

Keep distinct fields for `prepared`, `reviewed`, `draft_source_public`, `merged`, `research_asset_public`, `paper_site_public_verified` and `production_companion_qualified`. A local paper check is not a merge or a public release. A successful PR is not a publicly verified website. Never mark software acceptance complete using only paper-site checks.

## Policy provenance and review limit

This inspection read local checkout HEAD `8a65a12d00f783086e9c7c104213accc2181d23e`. `PUBLIC_HANDOFF_POLICY_AUDIT.json` records the actual file hashes and whether their bytes match that HEAD. Policies inspected include `AGENTS.md`, `CONTRIBUTING.md`, `docs/agent/PAPER_UPLOADS.md`, `FAST_RELEASE_POLICY.md`, `SCOPED_RELEASE_POLICY.md`, `RELEASE_READINESS.md`, the trusted classifier/parser, paper publication workflow and exact-source lint compatibility record.

No remote status, active lease, new tag availability or future main ancestry was independently queried by this task. The policy observations are current to the local checkout only. The receiving coordinator should refresh those particular external facts at handoff and preserve the existing owners' completed work. This plan creates no new authorization and does not delay the separate #4901 publication work.
