## Summary

This adds a separately preregistered continuation of #4850 under `studies/agi-alpha-capability-construction-v1/`. It makes the bounded capability-construction experiment reproducible through its protocol, pinned implementation, finished artifacts, complete raw evidence, unsuccessful development, cost ledgers, market-data model, editable paper/figures and offline browser companion.

The earlier Economics of Autonomous Work study and its publication work (#4901 and the separate passive-paper #4902) retain their own scope, results and immutable identities. This addition does not change those studies, existing runtime modules, contracts, source-pin guards, production website, release versions or deployed authority.

### Findings

- All 42 primary jobs were accepted across seven explicitly bounded digital-work families and eight principal templates. These are fresh task instances within authored grammars, not 42 occupations or an open-ended workplace sample.
- Successive missions invoke retained executable artifacts and actual parent information. The retained repair candidate lost to the strongest available specialist in all 12 fresh comparisons; the full product still delivered all 24 paired outputs successfully. Source-incremental execution showed no admitted discovery-cycle improvement. The negative findings remain in the paper and evidence.
- The finite local load campaign accepted 108/108 deliveries. Median throughput at concurrency four was 3.176 times concurrency one on twelve small non-planning inputs. This is a local batch-capacity comparison, not a human speed ratio or a sustained-service measurement.
- Official occupational wages and employer-cost sources support conditional comparison with competent traditional non-AI work. Complete Agent monetary cost, employer attention and matched human task duration remain unknown; modeled savings and market scenarios are not reported as observed revenue or cash margin. Self-acceleration is not established.

## Contents and boundaries

The public payload includes the original 110 frozen inputs, their manifest, all original confirmation/development outcomes, independent acceptance implementations, the source and environment pins, separate delivery/improvement accounts, complete compilable LaTeX and bibliography, editable vector figures, the final PDF and reproduction instructions. Any archive arrangement must preserve the full raw evidence and its original relative paths; the final public manifest identifies exactly what is delivered and where.

The browser companion distinguishes actual local computation, recorded planning evidence and modeled economics. It can be used from its downloaded HTML. The authenticated browser-to-approved-executor route is **NOT RUN**; this PR neither creates an operator identity nor supplies new credentials, authority or spending.

This is an **experimental research source/evidence draft**. It is not a production software qualification or a website deployment. Source publication, scientific review, merge, research-asset availability and software/site acceptance are separate statuses. Existing Harness/Fleet restrictions and the current publisher's ownership remain in force. A passive paper submission is handled independently through the existing paper lane.

## Evidence and local validation

- Prospective freeze: 25 October 2026, 12:31:23 UTC, before confirmation.
- Freeze SHA-256: `55fe389e077028c1439cf3dbdadc09164455df00865db471ddf03bd1eb99e282`.
- Public prospective notice: https://github.com/MontrealAI/AGI-Alpha-Agent-v0/issues/4850#issuecomment-6397672653
- Independent read-only acceptance/arithmetic/source audit: **1,101 checks passed**, zero failed checks. This does not add new trials.
- Frozen economics validation: **2,619 checks passed**.
- Offline browser engineering QA: **25/25 checks passed**, zero recorded page errors and zero external requests. The authenticated executor remains not run.
- Paper: 27 pages; clean repeated build is byte-identical, with zero overfull boxes and no undefined references. Page-review reports identify their exact PDF and PNG hashes.
- Canonical PDF SHA-256: `51ee8ded6860b6ab6b1a7bd1e0901fe864a96c30d40446c3743dd975ba139b28`.
- The preserved earlier edition's 69 frozen inputs and this study's 110 frozen inputs were rechecked unchanged after the final paper review.

These checks belong to the recorded local source and environment. They are not hosted PR or release results. The receiving coordinator must bind the final public selection and archive hashes to this PR's exact source commit before describing the public payload as verified.

## Repository checks and outstanding gates

Repository-wide pre-commit, canonical hosted `Lint (ruff)` and `Smoke tests`, configured exact-source review, resulting-main release acceptance, public research-asset readback and installed/production-site acceptance have **not been claimed by this draft**. Record actual outcomes for this new head as they become available. A local hook limitation permits a disclosed draft under the contributor policy; it does not waive a required hosted check, change frozen evidence or extend an existing source-specific lint exception.

No release tag, existing immutable asset or live website is changed by this proposal. No new spending, credentials, security changes, financial transactions or deployed-contract changes are requested. References #4850; does not close the broader research program.
