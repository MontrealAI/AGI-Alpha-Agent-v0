# Client helper reference web-documentation-05

```successor-example
{"operation":"url-encode","input":"100% done","expected":"100%25%20done"}
```

```successor-example
{"operation":"utf8-bytes","input":"Ω field","expected":"8"}
```

```successor-example
{"operation":"url-decode","input":"hello%20world","expected":"hello world"}
```

```successor-example
{"operation":"url-decode","input":"hello%20world","expected":"hello world"}
```

```successor-example
{"operation":"url-encode","input":"Ω field","expected":"%CE%A9%20field"}
```

```successor-example
{"operation":"utf8-bytes","input":"Ω field","expected":"8"}
```

```successor-example
{"operation":"url-encode","input":"hello world","expected":"hello%20world"}
```

```successor-example
{"operation":"url-decode","input":"100%25%20done","expected":"100% done"}
```
