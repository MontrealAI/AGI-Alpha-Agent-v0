// SPDX-License-Identifier: Apache-2.0
import assert from 'node:assert/strict';
import { contains } from './contains.mjs';
for (const c of [{"value":17,"expected":false},{"value":29,"expected":false},{"value":24,"expected":false},{"value":18,"expected":false},{"value":21,"expected":false},{"value":15,"expected":false},{"value":37,"expected":false},{"value":25,"expected":true},{"value":19,"expected":false},{"value":28,"expected":true}]) assert.equal(contains(c.value, 25, 28), c.expected);
console.log('All 10 fixed contract checks passed');
