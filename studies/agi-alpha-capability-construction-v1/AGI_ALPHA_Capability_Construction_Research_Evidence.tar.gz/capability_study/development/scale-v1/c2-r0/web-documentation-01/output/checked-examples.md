# Client helper reference web-documentation-01

```successor-example
{"operation":"url-encode","input":"Ω field","expected":"%CE%A9%20field"}
```

```successor-example
{"operation":"utf8-bytes","input":"Ω field","expected":"8"}
```
