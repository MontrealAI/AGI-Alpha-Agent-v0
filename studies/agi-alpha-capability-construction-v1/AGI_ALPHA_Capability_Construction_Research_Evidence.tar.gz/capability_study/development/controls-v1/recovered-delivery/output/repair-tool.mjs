// SPDX-License-Identifier: Apache-2.0
// Installed, bounded evidence compiler. Inputs are data, never executable code.
// Self-contained source can be retained and invoked after exact-code verification.
const canonical = value => JSON.stringify(value, (_, item) => item && typeof item === 'object' && !Array.isArray(item)
  ? Object.fromEntries(Object.keys(item).sort().map(key => [key, item[key]])) : item);

export const RULES = Object.freeze(['hash-source', 'select-required', 'bind-exact-passage',
  'reuse-unchanged-claim', 'recompile-changed-claim', 'render-brief', 'render-deck']);
const hex = /^[a-f0-9]{64}$/;
const safeId = /^[A-Za-z0-9][A-Za-z0-9_.:-]{0,95}$/;
const clone = value => JSON.parse(canonical(value));
export async function sha(text) {
  const value = new TextEncoder().encode(typeof text === 'string' ? text : canonical(text));
  return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', value)),
    byte => byte.toString(16).padStart(2, '0')).join('');
}
const require = (test, code) => { if (!test) throw Error(code); };
const esc = value => String(value).replace(/[&<>"']/g, char =>
  ({'&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;'}[char]));
const artifact = (name, type, content) => ({name, type, content});
const jsonArtifact = (name, value) => artifact(name, 'application/json', JSON.stringify(value, null, 2) + '\n');

export function validateEvidence(input) {
  require(input && typeof input === 'object', 'INPUT_OBJECT');
  require(Object.keys(input).sort().join('|') === ['id', 'title', 'source_packets', 'claims'].sort().join('|'), 'INPUT_FIELDS');
  require(safeId.test(input.id) && typeof input.title === 'string' && input.title.length <= 200, 'INPUT_ID_TITLE');
  require(Array.isArray(input.source_packets) && input.source_packets.length >= 1 && input.source_packets.length <= 20, 'SOURCE_COUNT');
  require(Array.isArray(input.claims) && input.claims.length >= 1 && input.claims.length <= 64, 'CLAIM_COUNT');
  require(new TextEncoder().encode(canonical(input)).length <= 200000, 'INPUT_BYTES');
  const ids = new Set();
  for (const source of input.source_packets) {
    require(Object.keys(source).sort().join('|') === ['id', 'url', 'sha256', 'text'].sort().join('|'), 'SOURCE_FIELDS');
    require(safeId.test(source.id) && !ids.has(source.id), 'SOURCE_ID');
    ids.add(source.id);
    require(hex.test(source.sha256), 'SOURCE_DIGEST_FORMAT');
    require(typeof source.text === 'string' && source.text.length <= 20000, 'SOURCE_TEXT');
    let url;
    try { url = new URL(source.url); } catch { throw Error('SOURCE_URL'); }
    require(url.protocol === 'https:' && !url.username && !url.password && source.url.length <= 500, 'SOURCE_URL');
  }
  const claims = new Set();
  for (const claim of input.claims) {
    require(Object.keys(claim).sort().join('|') === ['id', 'source_id', 'quote', 'required', 'section'].sort().join('|'), 'CLAIM_FIELDS');
    require(safeId.test(claim.id) && !claims.has(claim.id) && ids.has(claim.source_id), 'CLAIM_ID_OR_SOURCE');
    claims.add(claim.id);
    require(typeof claim.quote === 'string' && claim.quote.trim() && claim.quote.length <= 800, 'CLAIM_PASSAGE');
    require(typeof claim.required === 'boolean' && typeof claim.section === 'string' && claim.section.length <= 80, 'CLAIM_SCOPE');
  }
  require(input.claims.some(c => c.required), 'NO_REQUIRED_EVIDENCE');
}

export async function validateCapability(value, sourceHash) {
  require(value?.schema === 'evidence-repair-capability/v1', 'CAPABILITY_SCHEMA');
  require(canonical(value.rules) === canonical(RULES), 'CAPABILITY_RULES');
  require(value.source_sha256 === sourceHash && hex.test(sourceHash), 'CAPABILITY_SOURCE');
  require(value.authority?.length === 0 && value.proof?.length === 0, 'CAPABILITY_AUTHORITY');
  require(value.applicability === 'Explicit exact-passage claim inventories over bounded nonpersonal source packets', 'CAPABILITY_SCOPE');
}

// Criticism must identify an actual violated input contract; no model votes are used.
export async function challenge(input, brief) {
  const findings = [];
  if (brief.mission_id !== input.id) findings.push({code:'MISSION_BINDING', claim_id:'', evidence:{expected:input.id}});
  if (brief.title !== input.title) findings.push({code:'TITLE_BINDING', claim_id:'', evidence:{expected:input.title}});
  const sources = new Map(input.source_packets.map(source => [source.id, source]));
  const required = new Map(input.claims.filter(c => c.required).map(c => [c.id, c]));
  const actual = new Map((brief.claims || []).map(c => [c.id, c]));
  for (const [id, wanted] of required) {
    const got = actual.get(id), source = sources.get(wanted.source_id);
    if (!got) { findings.push({code:'MISSING_REQUIRED', claim_id:id, evidence:wanted}); continue; }
    if (got.quote !== wanted.quote || !source.text.includes(got.quote)) findings.push({code:'PASSAGE_MISMATCH', claim_id:id, evidence:{expected:wanted.quote, actual:got.quote, source_id:source.id}});
    if (got.source_sha256 !== source.sha256 || got.url !== source.url || got.source_id !== source.id) findings.push({code:'SOURCE_BINDING', claim_id:id, evidence:{expected_sha256:source.sha256, expected_url:source.url}});
    if (got.section !== wanted.section) findings.push({code:'SECTION_MISMATCH', claim_id:id, evidence:{expected:wanted.section}});
  }
  for (const [id] of actual) if (!required.has(id)) findings.push({code:'UNREQUESTED_CLAIM', claim_id:id, evidence:{required_ids:[...required.keys()]}});
  if ((brief.claims || []).length !== actual.size) findings.push({code:'DUPLICATE_CLAIM', claim_id:'', evidence:{count:(brief.claims || []).length, unique:actual.size}});
  return findings;
}

export async function adjudicate(input, brief, criticisms) {
  // Recompute the contract facts; critic assertions do not authorize a change.
  const verified = await challenge(input, brief);
  return criticisms.map(item => ({...item, substantiated:verified.some(f => f.code === item.code && f.claim_id === item.claim_id),
    basis:'Recomputed exact input contract; no semantic independence is claimed'}));
}

const style = `:root{color-scheme:light}*{box-sizing:border-box}body{margin:0;background:#f6f4fb;color:#19132c;font:17px/1.6 system-ui,sans-serif}main{max-width:980px;margin:0 auto;padding:52px 34px}h1{font-size:38px;line-height:1.14}h2{font-size:25px;line-height:1.2}header{border-bottom:4px solid #c79a42;padding-bottom:24px;margin-bottom:28px}.eyebrow{color:#64518b;letter-spacing:.12em;font-size:12px;font-weight:800}article{background:white;border:1px solid #ded8e9;border-radius:12px;padding:22px;margin:18px 0;break-inside:avoid}blockquote{margin:12px 0;font-size:19px}a{color:#59398d;overflow-wrap:anywhere}.meta{font-size:12px;color:#625a70;overflow-wrap:anywhere}.limit{background:#eee9f6;padding:16px;border-radius:8px}@media print{body{background:white}main{padding:0}article{border-radius:0}}`;
export function renderBrief(brief, deck = false) {
  const groups = new Map();
  for (const claim of brief.claims) { if (!groups.has(claim.section)) groups.set(claim.section, []); groups.get(claim.section).push(claim); }
  const cards = [...groups].map(([title, claims], index) => `<article${deck ? ' class="slide"' : ''}><p class="eyebrow">${deck ? 'SLIDE ' + (index + 1) : 'EVIDENCE'}</p><h2>${esc(title)}</h2>${claims.map(c => `<div data-claim="${esc(c.id)}"><blockquote>${esc(c.quote)}</blockquote><p class="meta"><a href="${esc(c.url)}">${esc(c.source_id)}</a> · claim ${esc(c.id)} · SHA-256 ${esc(c.source_sha256)}</p></div>`).join('')}</article>`).join('');
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(brief.title)}</title><style>${style}${deck ? '.slide{min-height:360px;page-break-after:always}@media print{.slide{page-break-after:always}}' : ''}</style></head><body><main><header><p class="eyebrow">AGI ALPHA · VERIFIED SOURCE PACKET</p><h1>${esc(brief.title)}</h1><p>${esc(brief.mission_id)} · ${brief.claims.length} requested evidence passages</p></header>${cards}<p class="limit">These are exact, source-linked passages selected by the supplied brief. They are not an independent assessment of source truth, a free-form summary, or permission to take an external action.</p></main></body></html>\n`;
}

export function evidenceAdapter({family = 'evidence-brief', sourceHash, parent = null, capability = null, mode = 'incremental', toolSource = ''} = {}) {
  return {manifest:{id:family, version:1, en:'Build a source-linked evidence delivery', fr:'Produire un dossier sourcé',
    scope:'Exact-passage evidence compilation and source-aware repair of bounded explicit briefs; no autonomous truth certification.', artifact:'brief.html'},
  validate:validateEvidence,
  async execute(input, checkpoint) {
    const start = performance.now();
    const stages = [];
    const stage = (name, decision, artifactName) => stages.push({stage:name, decision, artifact:artifactName});
    await checkpoint('Identify'); stage('Identify', 'Bind purpose, required evidence and permitted source packets', 'mission.json');
    if (capability) await validateCapability(capability, sourceHash);
    const sources = new Map();
    for (const source of input.source_packets) {
      require(await sha(source.text) === source.sha256, 'SOURCE_DIGEST_MISMATCH');
      sources.set(source.id, source);
    }
    await checkpoint('Out-Learn'); stage('Out-Learn', 'Acquire and hash the exact supplied passages; no network acquisition', 'sources.json');
    const previousClaims = new Map((parent?.brief?.claims || []).map(c => [c.id, c]));
    const previousSources = new Map((parent?.input?.source_packets || []).map(s => [s.id, s]));
    if (parent) {
      validateEvidence(parent.input);
      require((await challenge(parent.input, parent.brief)).length === 0, 'PARENT_CONTRACT_INVALID');
      require(parent.brief.mission_id === parent.input.id, 'PARENT_BINDING');
      for (const source of previousSources.values()) require(await sha(source.text) === source.sha256, 'PARENT_SOURCE_CORRUPTION');
    }
    const changed = [...new Set([...input.source_packets.filter(s => previousSources.get(s.id)?.sha256 !== s.sha256 || previousSources.get(s.id)?.url !== s.url).map(s => s.id),
      ...[...previousSources.keys()].filter(id => !sources.has(id))])].sort();
    const reused = [], recompiled = [], claims = [];
    await checkpoint('Out-Think'); stage('Out-Think', 'Check required-claim dependencies and change impact', 'lineage.json');
    for (const wanted of input.claims.filter(c => c.required)) {
      const source = sources.get(wanted.source_id), prior = previousClaims.get(wanted.id);
      const eligible = mode === 'incremental' && capability && prior && !changed.includes(source.id) &&
        prior.source_id === wanted.source_id && prior.quote === wanted.quote && prior.section === wanted.section &&
        prior.source_sha256 === source.sha256 && prior.url === source.url;
      if (eligible) { claims.push(clone(prior)); reused.push(wanted.id); }
      else {
        require(source.text.includes(wanted.quote), 'UNSUPPORTED_PASSAGE');
        claims.push({id:wanted.id, source_id:source.id, quote:wanted.quote, section:wanted.section, source_sha256:source.sha256, url:source.url});
        recompiled.push(wanted.id);
      }
      await checkpoint('Out-Design');
    }
    stage('Out-Design', 'Compose exact evidence with a reusable source-dependency rule set', 'retained-capability.json');
    const brief = {schema:'evidence-brief/v1', mission_id:input.id, title:input.title, claims,
      limits:['Exact passage fidelity and required coverage only; source truth and semantic importance remain outside this contract.']};
    const criticisms = await challenge(input, brief);
    const review = await adjudicate(input, brief, criticisms);
    require(!review.some(r => r.substantiated), 'VERIFIED_DEFECT_REQUIRES_REPAIR');
    await checkpoint('Out-Strategise'); stage('Out-Strategise', mode === 'incremental' && parent ? 'Reuse eligible verified claims; fully compile changed dependencies' : 'Use full compilation without inherited claims', 'lineage.json');
    const retained = {schema:'evidence-repair-capability/v1', rules:RULES, source_sha256:sourceHash,
      applicability:'Explicit exact-passage claim inventories over bounded nonpersonal source packets',
      failure_conditions:['Unstructured claim inventory', 'Missing or corrupted source', 'Unsupported quote', 'Parent contract mismatch'],
      rollback:'Discard successor output and retain the immutable parent directory; no external state is modified',
      construction_cost:{cpu_seconds:null, monetary_cost:null, reason:'Authoring and upstream acquisition are separate measured/unknown improvement accounts'},
      proof:[], authority:[]};
    const lineage = {schema:'evidence-lineage/v1', input_sha256:await sha(input), parent_input_sha256:parent ? await sha(parent.input) : null,
      parent_brief_sha256:parent ? await sha(parent.brief) : null, parent_brief_file_sha256:parent?.raw_brief_sha256 ?? null,
      parent_tool_sha256:parent?.tool_sha256 ?? null, invoked_module:parent ? 'verified-parent-artifact' : 'installed-source',
      capability_sha256:capability ? await sha(capability) : null,
      actual_parent_claim_reads:previousClaims.size, changed_source_ids:changed, reused_claim_ids:reused, recompiled_claim_ids:recompiled,
      mode, family, cross_family:parent ? parent.family !== family : false, proof:[], authority:[]};
    await checkpoint('Out-Execute'); stage('Out-Execute', 'Deliver readable brief, presentation and provenance records', 'brief.html');
    await checkpoint('Out-Evolve'); stage('Out-Evolve', 'Retain bounded executable rule data and checked source dependencies', 'retained-capability.json');
    const files = [jsonArtifact('brief.json', brief), artifact('brief.html', 'text/html', renderBrief(brief)),
      artifact('slides.html', 'text/html', renderBrief(brief, true)), jsonArtifact('sources.json', input.source_packets),
      jsonArtifact('lineage.json', lineage), jsonArtifact('retained-capability.json', retained),
      jsonArtifact('review.json', {criticisms, adjudication:review, review_model:'Deterministic contract checks, not independent model votes'}),
      jsonArtifact('stages.json', stages), artifact('repair-tool.mjs', 'text/javascript', toolSource)];
    return {decision:'SOURCE_LINKED_DELIVERY', summary:{claims:claims.length, sources:sources.size, reused:reused.length, recompiled:recompiled.length},
      evidence:{lineage, review, worker_elapsed_microseconds:Math.round((performance.now() - start) * 1000)}, artifacts:files,
      limits:['Bounded evidence compilation; not arbitrary research or source-truth verification.', 'All monetary costs and human review remain separately accounted; no authority or settlement.']};
  }};
}
