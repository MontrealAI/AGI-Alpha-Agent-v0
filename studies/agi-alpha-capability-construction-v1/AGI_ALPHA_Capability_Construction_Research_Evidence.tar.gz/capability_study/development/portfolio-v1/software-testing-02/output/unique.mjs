// SPDX-License-Identifier: Apache-2.0
export const unique = values => [...new Set(values)].sort((a,b)=>a-b);
