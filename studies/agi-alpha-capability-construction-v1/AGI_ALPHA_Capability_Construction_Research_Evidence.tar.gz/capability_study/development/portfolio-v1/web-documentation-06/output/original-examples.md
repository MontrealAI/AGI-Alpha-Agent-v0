# Client helper reference web-documentation-06

```successor-example
{"operation": "utf8-bytes", "input": "hello world", "expected": "incorrect-example"}
```

```successor-example
{"operation": "url-decode", "input": "100%25%20done", "expected": "100% done"}
```

```successor-example
{"operation": "url-encode", "input": "Ω field", "expected": "incorrect-example"}
```

```successor-example
{"operation": "url-decode", "input": "A%26B%20%2F%20C", "expected": "A&B / C"}
```

```successor-example
{"operation": "url-decode", "input": "hello%20world", "expected": "incorrect-example"}
```

```successor-example
{"operation": "url-encode", "input": "Montréal", "expected": "Montr%C3%A9al"}
```

```successor-example
{"operation": "url-encode", "input": "Ω field", "expected": "incorrect-example"}
```

```successor-example
{"operation": "url-decode", "input": "A%26B%20%2F%20C", "expected": "A&B / C"}
```
