# Client helper reference web-documentation-05

```successor-example
{"operation": "utf8-bytes", "input": "Ω field", "expected": "incorrect-example"}
```

```successor-example
{"operation": "url-encode", "input": "100% done", "expected": "100%25%20done"}
```

```successor-example
{"operation": "url-decode", "input": "100%25%20done", "expected": "incorrect-example"}
```

```successor-example
{"operation": "url-decode", "input": "%CE%A9%20field", "expected": "Ω field"}
```

```successor-example
{"operation": "url-decode", "input": "A%26B%20%2F%20C", "expected": "incorrect-example"}
```

```successor-example
{"operation": "url-decode", "input": "Montr%C3%A9al", "expected": "Montréal"}
```

```successor-example
{"operation": "url-decode", "input": "%CE%A9%20field", "expected": "incorrect-example"}
```

```successor-example
{"operation": "utf8-bytes", "input": "A&B / C", "expected": "7"}
```
