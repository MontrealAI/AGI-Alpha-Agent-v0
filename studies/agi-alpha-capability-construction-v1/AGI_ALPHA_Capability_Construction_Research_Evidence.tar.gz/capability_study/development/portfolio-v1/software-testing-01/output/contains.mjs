export function contains(value, low, high) { return low <= value && value <= high; }
