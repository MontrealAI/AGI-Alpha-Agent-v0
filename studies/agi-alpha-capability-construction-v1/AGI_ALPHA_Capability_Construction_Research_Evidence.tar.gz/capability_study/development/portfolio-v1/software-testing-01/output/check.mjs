// SPDX-License-Identifier: Apache-2.0
import assert from 'node:assert/strict';
import { contains } from './contains.mjs';
for (const c of [{"value":-78,"expected":true},{"value":-120,"expected":true},{"value":-98,"expected":true},{"value":-88,"expected":true},{"value":-127,"expected":false},{"value":-119,"expected":true},{"value":-106,"expected":true},{"value":-77,"expected":true},{"value":-129,"expected":false},{"value":-87,"expected":true},{"value":-121,"expected":true},{"value":-125,"expected":false},{"value":-124,"expected":true},{"value":-76,"expected":false}]) assert.equal(contains(c.value, -124, -77), c.expected);
console.log('All 14 fixed contract checks passed');
