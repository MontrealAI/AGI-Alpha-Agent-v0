# Client helper reference web-documentation-01

```successor-example
{"operation": "url-encode", "input": "100% done", "expected": "incorrect-example"}
```

```successor-example
{"operation": "utf8-bytes", "input": "Montréal", "expected": "9"}
```
