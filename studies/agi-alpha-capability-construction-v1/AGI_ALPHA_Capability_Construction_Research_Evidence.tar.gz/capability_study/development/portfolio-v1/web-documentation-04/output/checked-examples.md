# Client helper reference web-documentation-04

```successor-example
{"operation":"url-encode","input":"100% done","expected":"100%25%20done"}
```

```successor-example
{"operation":"url-encode","input":"hello world","expected":"hello%20world"}
```

```successor-example
{"operation":"url-encode","input":"A&B / C","expected":"A%26B%20%2F%20C"}
```

```successor-example
{"operation":"url-decode","input":"A%26B%20%2F%20C","expected":"A&B / C"}
```

```successor-example
{"operation":"url-encode","input":"100% done","expected":"100%25%20done"}
```
