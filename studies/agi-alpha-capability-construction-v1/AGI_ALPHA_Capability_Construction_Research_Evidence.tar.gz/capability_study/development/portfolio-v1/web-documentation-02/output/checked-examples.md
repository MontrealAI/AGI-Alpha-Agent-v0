# Client helper reference web-documentation-02

```successor-example
{"operation":"utf8-bytes","input":"hello world","expected":"11"}
```

```successor-example
{"operation":"utf8-bytes","input":"hello world","expected":"11"}
```
