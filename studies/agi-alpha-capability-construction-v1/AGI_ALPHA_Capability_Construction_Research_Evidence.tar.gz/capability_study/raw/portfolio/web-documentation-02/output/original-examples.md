# Client helper reference web-documentation-02

```successor-example
{"operation": "url-decode", "input": "hello%20world", "expected": "incorrect-example"}
```

```successor-example
{"operation": "url-decode", "input": "hello%20world", "expected": "hello world"}
```
