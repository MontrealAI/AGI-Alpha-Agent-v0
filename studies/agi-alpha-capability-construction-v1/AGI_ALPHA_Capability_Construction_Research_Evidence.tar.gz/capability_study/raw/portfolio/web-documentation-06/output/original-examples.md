# Client helper reference web-documentation-06

```successor-example
{"operation": "url-decode", "input": "A%26B%20%2F%20C", "expected": "incorrect-example"}
```

```successor-example
{"operation": "utf8-bytes", "input": "Ω field", "expected": "8"}
```

```successor-example
{"operation": "url-decode", "input": "100%25%20done", "expected": "incorrect-example"}
```

```successor-example
{"operation": "url-decode", "input": "%CE%A9%20field", "expected": "Ω field"}
```

```successor-example
{"operation": "url-encode", "input": "A&B / C", "expected": "incorrect-example"}
```

```successor-example
{"operation": "utf8-bytes", "input": "Ω field", "expected": "8"}
```

```successor-example
{"operation": "utf8-bytes", "input": "Montréal", "expected": "incorrect-example"}
```

```successor-example
{"operation": "url-encode", "input": "Montréal", "expected": "Montr%C3%A9al"}
```
