# Client helper reference web-documentation-01

```successor-example
{"operation": "url-decode", "input": "hello%20world", "expected": "incorrect-example"}
```

```successor-example
{"operation": "url-encode", "input": "100% done", "expected": "100%25%20done"}
```
