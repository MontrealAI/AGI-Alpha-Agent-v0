# Client helper reference web-documentation-05

```successor-example
{"operation": "url-decode", "input": "A%26B%20%2F%20C", "expected": "incorrect-example"}
```

```successor-example
{"operation": "url-decode", "input": "hello%20world", "expected": "hello world"}
```

```successor-example
{"operation": "utf8-bytes", "input": "hello world", "expected": "incorrect-example"}
```

```successor-example
{"operation": "url-encode", "input": "Montréal", "expected": "Montr%C3%A9al"}
```

```successor-example
{"operation": "url-decode", "input": "%CE%A9%20field", "expected": "incorrect-example"}
```

```successor-example
{"operation": "url-encode", "input": "A&B / C", "expected": "A%26B%20%2F%20C"}
```

```successor-example
{"operation": "url-decode", "input": "100%25%20done", "expected": "incorrect-example"}
```

```successor-example
{"operation": "utf8-bytes", "input": "A&B / C", "expected": "7"}
```
