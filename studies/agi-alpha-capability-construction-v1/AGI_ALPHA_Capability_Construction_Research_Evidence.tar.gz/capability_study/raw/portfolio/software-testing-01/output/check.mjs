// SPDX-License-Identifier: Apache-2.0
import assert from 'node:assert/strict';
import { contains } from './contains.mjs';
for (const c of [{"value":-267,"expected":true},{"value":-302,"expected":true},{"value":-254,"expected":true},{"value":-271,"expected":true},{"value":-280,"expected":true},{"value":-266,"expected":true},{"value":-236,"expected":false},{"value":-258,"expected":true},{"value":-279,"expected":true},{"value":-299,"expected":true},{"value":-262,"expected":true},{"value":-304,"expected":false},{"value":-303,"expected":true},{"value":-239,"expected":true},{"value":-238,"expected":false}]) assert.equal(contains(c.value, -303, -239), c.expected);
console.log('All 15 fixed contract checks passed');
