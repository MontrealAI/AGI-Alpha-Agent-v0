# Client helper reference web-documentation-03

```successor-example
{"operation":"utf8-bytes","input":"100% done","expected":"9"}
```

```successor-example
{"operation":"url-decode","input":"100%25%20done","expected":"100% done"}
```

```successor-example
{"operation":"url-decode","input":"%CE%A9%20field","expected":"Ω field"}
```

```successor-example
{"operation":"url-encode","input":"hello world","expected":"hello%20world"}
```

```successor-example
{"operation":"utf8-bytes","input":"Montréal","expected":"9"}
```
