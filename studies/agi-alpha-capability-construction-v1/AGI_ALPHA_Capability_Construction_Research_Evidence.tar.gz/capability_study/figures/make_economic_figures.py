# SPDX-License-Identifier: Apache-2.0
"""Rebuild editable economic figures from preregistered, unchanged inputs.

These figures are conditional economic calculations, not observed productivity
estimates. SVG preserves editable text; PDF embeds TrueType fonts.
"""
import hashlib
import json
import os
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
import tempfile

os.environ.setdefault('MPLCONFIGDIR', str(Path(tempfile.gettempdir()) / 'agi-alpha-figure-cache'))

import matplotlib

matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.colors import LogNorm
from matplotlib.patches import Rectangle

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / 'figures'
ECON = ROOT / 'economics'
RESULTS = json.loads((ECON / 'economic_results.json').read_text())
INPUTS = json.loads((ECON / 'scenario_inputs.json').read_text())
RATES = {r['id']: r for r in json.loads((ECON / 'rate_matrix.json').read_text())['rates']}
PURPLE = '#37254B'
TEAL = '#176E7B'
GOLD = '#BE8B36'
GRAY = '#67717B'
LIGHT = '#E6E9EC'
INK = '#1E2430'
plt.rcParams.update({
    'font.family': 'DejaVu Sans',
    'font.size': 9,
    'axes.labelsize': 9,
    'axes.titlesize': 10,
    'axes.titleweight': 'bold',
    'axes.spines.top': False,
    'axes.spines.right': False,
    'axes.edgecolor': '#A3AAB3',
    'axes.labelcolor': INK,
    'text.color': INK,
    'xtick.color': GRAY,
    'ytick.color': GRAY,
    'svg.fonttype': 'none',
    'svg.hashsalt': 'agi-alpha-capability-economics-v1',
    'pdf.fonttype': 42,
    'savefig.facecolor': 'white',
})


def save(fig, stem, description):
    for extension in ['svg', 'pdf', 'png']:
        target = OUT / f'{stem}.{extension}'
        if extension == 'pdf':
            metadata = {'Creator': 'Reproducible matplotlib economics figure',
                        'CreationDate': None, 'ModDate': None,
                        'Subject': description}
        elif extension == 'svg':
            metadata = {'Creator': 'Reproducible matplotlib economics figure',
                        'Date': None, 'Description': description}
        else:
            metadata = {'Description': description}
        fig.savefig(target, dpi=190, metadata=metadata)
    plt.close(fig)


def money(value):
    return str(Decimal(str(value)).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP))


def delivery_frontier():
    fig, axes = plt.subplots(1, 2, figsize=(7.8, 4.4), sharex=True, sharey=True)
    fig.subplots_adjust(left=.085, right=.965, bottom=.31, top=.73, wspace=.17)
    fig.suptitle('The human minutes displaced determine economic advantage',
                 x=.085, y=.96, ha='left', fontsize=13, weight='bold')
    fig.text(.085, .885, 'MODELED COSTS  ·  Observed labor prices; assumed task time and Agent costs',
             color=TEAL, weight='bold', fontsize=8.7)
    records = []
    selections = [('us_office_admin_compensation', 'Office and administrative work', PURPLE),
                  ('us_professional_compensation', 'Professional and related work', TEAL)]
    for ax, (rate_id, label, color) in zip(axes, selections):
        rate = RATES[rate_id]['rate_per_hour']
        row = next(row for row in RESULTS['delivery_sensitivity']
                   if row['rate_id'] == rate_id
                   and row['human_minutes_assumed'] == 30
                   and row['attention_minutes_assumed'] == 5
                   and row['other_agent_cost_assumed'] == 1
                   and row['q_human_assumed'] == 1
                   and row['q_agent_assumed'] == 1)
        human_cost = row['human_cost_per_accepted_output']
        agent_cost = row['agent_cost_per_accepted_output']
        threshold = 60 * agent_cost / rate
        xs = np.array([v for v in INPUTS['human_minutes'] if v <= 60])
        ax.plot(xs, xs * rate / 60, color=color, lw=2.2,
                label='Traditional human work')
        ax.axhline(agent_cost, color=GOLD, ls='--', lw=2,
                   label='Agent + remaining human effort')
        ax.axvline(threshold, color=GRAY, ls=':', lw=1)
        ax.plot([30], [human_cost], marker='o', color=color, ms=5)
        ax.annotate(f'30 min: ${money(human_cost)}', xy=(30, human_cost),
                    xytext=(16, human_cost + 13), fontsize=8.5,
                    color=color, arrowprops={'arrowstyle': '-', 'color': color, 'lw': .8})
        ax.text(57, agent_cost + 2.3, f'Agent ${money(agent_cost)}',
                color='#875E17', ha='right', fontsize=8.5, weight='bold')
        ax.text(threshold + 1.4, 64, f'Break-even\n{threshold:.2f} min',
                fontsize=8, color=GRAY)
        ax.set_title(f'{label}\n${rate:.2f} / hour, including benefits', loc='left', pad=12)
        ax.set_xlim(0, 60)
        ax.set_ylim(0, 76)
        ax.set_xticks([0, 15, 30, 45, 60])
        ax.set_xlabel('Traditional work time assumed (minutes)')
        ax.set_yticks([0, 20, 40, 60])
        ax.grid(axis='y', color=LIGHT, lw=.7)
        ax.set_axisbelow(True)
        records.append({'rate_id': rate_id, 'hourly_compensation_usd_observed': rate,
                        'human_minutes_assumed': 30,
                        'agent_attention_minutes_assumed': 5,
                        'other_agent_cost_usd_assumed': 1,
                        'human_cost_usd_modeled': human_cost,
                        'agent_cost_usd_modeled': agent_cost,
                        'break_even_minutes_modeled': threshold})
    axes[0].set_ylabel('Cost per accepted deliverable (USD)')
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc='lower left', bbox_to_anchor=(.07, .135),
               frameon=False, ncol=2, fontsize=8.5, handlelength=2.6)
    fig.text(.085, .095, 'Assumptions: equal acceptance = 1; five paid human minutes remain; $1 covers all other allocated Agent costs.',
             fontsize=7.8, color=GRAY)
    fig.text(.085, .056, 'Price source: BLS, December 2025 ECEC, private industry. These are broad occupational groups.',
             fontsize=7.8, color=GRAY)
    fig.text(.085, .018, 'Actual full-system Agent cost and employer attention are unmeasured; the curves are not experimental cost ratios.',
             fontsize=7.8, color=GRAY)
    save(fig, 'economic_adoption', 'Conditional human-versus-Agent cost, using BLS compensation rates and preregistered assumptions.')
    return records


def reuse_payback():
    constructions = INPUTS['improvement_cost_local_currency']
    savings = INPUTS['saving_per_accepted_reuse_local_currency']
    lookup = {(r['full_construction_cost_assumed'], r['saving_per_accepted_reuse_assumed']):
              r['reuse_volume_break_even'] for r in RESULTS['construction_break_even']}
    counts = np.array([[lookup[(cost, saving)] for saving in savings]
                       for cost in constructions])
    fig, ax = plt.subplots(figsize=(7.8, 3.8))
    fig.subplots_adjust(left=.20, right=.96, bottom=.28, top=.70)
    fig.suptitle('Reuse must repay the cost of capability construction',
                 x=.045, y=.95, ha='left', fontsize=12.8, weight='bold')
    fig.text(.045, .858, 'MODELED PAYBACK  ·  Accepted reuses needed: ceiling(construction cost / net saving per reuse)',
             color=TEAL, weight='bold', fontsize=8.5)
    norm = LogNorm(vmin=5, vmax=50000)
    cmap = plt.get_cmap('YlGnBu')
    for row in range(len(constructions)):
        for col in range(len(savings)):
            ax.add_patch(Rectangle((col - .5, row - .5), 1, 1,
                                   facecolor=cmap(norm(counts[row, col])),
                                   edgecolor='none'))
    ax.set_xlim(-.5, len(savings) - .5)
    ax.set_ylim(len(constructions) - .5, -.5)
    ax.set_xticks(range(len(savings)), [f'{v:g}' for v in savings])
    ax.set_yticks(range(len(constructions)), [f'{v:,}' for v in constructions])
    ax.set_xlabel('Net saving per accepted reuse (local currency)', labelpad=9)
    ax.set_ylabel('Full construction cost\n(local currency)', labelpad=11)
    ax.tick_params(length=0, pad=7)
    for row in range(len(constructions)):
        for col in range(len(savings)):
            count = counts[row, col]
            ax.text(col, row, f'{count:,}', ha='center', va='center', fontsize=12,
                    color='white' if count >= 1000 else INK, weight='bold')
    ax.set_xticks(np.arange(-.5, len(savings), 1), minor=True)
    ax.set_yticks(np.arange(-.5, len(constructions), 1), minor=True)
    ax.grid(which='minor', color='white', lw=2)
    ax.tick_params(which='minor', bottom=False, left=False)
    for spine in ax.spines.values():
        spine.set_visible(False)
    fig.text(.045, .12, 'Every cell includes construction in the threshold. Net reuse savings must include verification and maintenance.',
             fontsize=8, color=GRAY)
    fig.text(.045, .073, 'Nonpositive net saving has no finite payback. Uncertain demand or short asset life can prevent cost recovery.',
             fontsize=8, color=GRAY)
    fig.text(.045, .026, 'The construction costs and savings are sensitivity assumptions, not measured commercial returns.',
             fontsize=8, color=GRAY)
    save(fig, 'economic_reuse_payback', 'Prospective construction-cost and net-saving sensitivities; exact payback counts, not measured returns.')
    return RESULTS['construction_break_even']


def market_scopes():
    fig = plt.figure(figsize=(7.8, 6.0))
    fig.suptitle('Labor expenditure, serviceable work and revenue are different quantities',
                 x=.06, y=.96, ha='left', fontsize=12.4, weight='bold')
    fig.text(.06, .913, 'ASSUMPTION SCENARIOS  ·  Neither scale nor market coverage is established by fixture acceptance',
             color=TEAL, fontsize=8.5, weight='bold')
    ax = fig.add_axes([.17, .55, .76, .25])
    names = ['Conservative', 'Central', 'Ambitious']
    rows = RESULTS['us_scenarios']
    values = [r['updated_base_2025_usd'] / 1e12 for r in rows]
    ax.barh([2, 1, 0], values, color=[PURPLE, TEAL, GOLD], height=.54)
    ax.set_yticks([2, 1, 0], names)
    ax.set_xlim(0, 16.7)
    ax.set_xticks([0, 5, 10, 15])
    ax.set_xlabel('Assumed computer-mediated employee compensation (USD trillions / year)')
    ax.grid(axis='x', color=LIGHT, lw=.7)
    ax.set_axisbelow(True)
    base = INPUTS['updated_us_denominator']['compensation_paid_usd'] / 1e12
    ax.axvline(base, color=GRAY, ls=':', lw=1.2)
    ax.text(base - .2, 2.45, f'All domestic employee compensation: ${base:.2f}T',
            ha='right', fontsize=8, color=GRAY)
    for yy, value, row in zip([2, 1, 0], values, rows):
        shares = f'{row["occupation_eligibility_assumed"]:.1%} × {row["computer_task_share_assumed"]:.0%}'
        ax.text(value + .2, yy, f'${value:.2f}T  ({shares})', va='center', fontsize=8.5)
    fig.text(.06, .835, 'A   U.S. 2025 denominator: BEA $15.718937T; both digital-work shares are assumed',
             fontsize=9, weight='bold')
    fig.text(.06, .457, 'B   Separate ten-occupation model: central scenario; disjoint task shares, not an official wage bill',
             fontsize=9, weight='bold')
    bx = fig.add_axes([.32, .155, .61, .255])
    row = next(r for r in RESULTS['bottom_up'] if r['name'] == 'Central')
    fields = ['relevant_task_value', 'technically_matching_context_value_assumed',
              'serviceable_adopted_value_assumed', 'all_provider_fees_assumed',
              'individual_provider_revenue_assumed']
    labels = ['Relevant task proxy', 'Matching contexts assumed', 'Adopted work assumed',
              'All-provider fees assumed', 'One provider at 1% share']
    amounts = [row[f] for f in fields]
    positions = np.arange(4, -1, -1)
    bx.hlines(positions, 1e6, amounts, color=LIGHT, lw=5)
    bx.scatter(amounts, positions, color=[PURPLE, PURPLE, TEAL, TEAL, GOLD], s=36, zorder=3)
    bx.set_xscale('log')
    bx.set_xlim(1e6, 1.5e11)
    bx.set_yticks(positions, labels)
    bx.tick_params(axis='y', length=0, pad=8, labelsize=8)
    bx.set_xticks([1e6, 1e7, 1e8, 1e9, 1e10, 1e11], ['$1M', '$10M', '$100M', '$1B', '$10B', '$100B'])
    bx.tick_params(axis='x', labelsize=8)
    bx.set_xlabel('Annual USD wage-value proxy or assumed fee — logarithmic scale', fontsize=8)
    bx.spines['left'].set_visible(False)
    for yy, amount in zip(positions, amounts):
        label = f'${amount / 1e9:.2f}B' if amount >= 1e9 else f'${amount / 1e6:.2f}M'
        bx.text(amount * 1.18, yy, label, va='center', fontsize=8.5)
    fig.text(.06, .061, 'A: the supplied rounded-base scenario remains $4.9455T / $7.3005T / $10.00875T in the evidence file.',
             fontsize=7.5, color=GRAY)
    fig.text(.06, .031, 'B: BLS 2025 job counts × median wages, then assumed task/context/adoption/fee shares. Never add panels A and B.',
             fontsize=7.5, color=GRAY)
    save(fig, 'economic_market_scopes', 'National compensation scenario and a separately constructed occupation-based proxy. All digital shares and provider revenue are assumptions.')
    return {'us_scenarios': rows, 'central_bottom_up': {f: row[f] for f in fields}}


def main():
    OUT.mkdir(exist_ok=True)
    payload = {'status': 'CONDITIONAL_ECONOMIC_FIGURES_NOT_OBSERVED_AGENT_ADVANTAGE',
               'delivery': delivery_frontier(),
               'reuse': reuse_payback(),
               'market': market_scopes()}
    (OUT / 'economic_figure_data.json').write_text(json.dumps(payload, indent=2) + '\n')
    inputs = ['economic_results.json', 'scenario_inputs.json', 'rate_matrix.json', 'INPUTS_SHA256.json']
    stems = ['economic_adoption', 'economic_reuse_payback', 'economic_market_scopes']
    outputs = [OUT / f'{stem}.{extension}' for stem in stems for extension in ['svg', 'pdf', 'png']]
    outputs.append(OUT / 'economic_figure_data.json')
    manifest = {
        'script': 'figures/make_economic_figures.py',
        'inputs_sha256': {f: hashlib.sha256((ECON / f).read_bytes()).hexdigest() for f in inputs},
        'output_sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in outputs},
        'scope': payload['status'],
        'svg_text': 'Editable; not converted to paths',
        'pdf_fonts': 'Embedded TrueType',
        'no_empirical_human_task_ratio': True,
    }
    (OUT / 'economic_figures_manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({'figures': 3, 'output_files': len(outputs), 'status': payload['status']}, indent=2))


if __name__ == '__main__':
    main()
