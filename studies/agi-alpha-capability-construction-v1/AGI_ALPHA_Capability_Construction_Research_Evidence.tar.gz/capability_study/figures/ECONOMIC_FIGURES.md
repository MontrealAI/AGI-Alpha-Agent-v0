# Economic figures

These are conditional economic figures built from the prospective economics files. They contain no observed human task-time comparison and no empirical full-system cost ratio.

| Figure | Intended use | Main interpretation |
|---|---|---|
| `economic_adoption.pdf` / `.svg` | Main economics result | Official employer prices can identify a break-even human duration only after Agent cost and remaining attention are supplied or explicitly assumed. |
| `economic_reuse_payback.pdf` / `.svg` | Capability-construction economics | Construction cost must be repaid across enough accepted reuses at positive net saving; the 12 cells are frozen sensitivity assumptions. |
| `economic_market_scopes.pdf` / `.svg` | Market scenario appendix | National employee compensation, selected task exposure, matching contexts, adopted work and provider fees are distinct quantities; both panels are assumption scenarios. |

Run `python capability_study/figures/make_economic_figures.py` from the project root. Outputs include editable SVG text, embedded-font PDFs, PNG previews, the plotted data and SHA-256 provenance. All plotted objects are vector paths or text; the heatmap uses 12 editable rectangles, not a bitmap. Source data are `economics/rate_matrix.json`, `scenario_inputs.json` and `economic_results.json`. The economics input manifest is read but never rewritten by the figure generator.

`economic_pdf_render_check.json` records successful independent PDF rendering and visual inspection of all three single-page PDFs. The `_pdfproof.png` files are rendered proof images. Layout revisions corrected a legend/axis collision and the clipped first character of a scenario label before final inspection.

## Development record

The first figure-generation attempt stopped before producing a complete figure because four assumed dictionary-key names did not match the actual economic result schema. The generator was corrected to read the existing keys; no economics data or assumptions were changed. The first visual pass then identified the two layout issues above. A later pass replaced a heatmap raster with vector rectangles so SVG/PDF meet the vector-deliverable requirement. These are authoring/build corrections, not discarded experimental outcomes.

## Suggested captions

**Adoption.** Conditional delivery-cost comparison using BLS December 2025 private-industry employer compensation. Each panel assumes equal acceptance, five minutes of remaining human effort priced at its stated occupational-group rate, and USD 1 of all other allocated Agent cost. Traditional task duration is varied; the resulting 6.67- and 5.83-minute break-even thresholds are modeled, not human-trial findings. Complete Agent cost and attention remain unmeasured.

**Reuse.** Accepted reuses needed to recover construction cost under prospective cost/saving assumptions, calculated as the ceiling of full construction cost divided by positive net saving per accepted reuse. Unsuccessful search, evaluation and deployment belong in construction; continuing verification and maintenance reduce net saving. The figure does not establish actual positive margin or demand.

**Market scopes.** Panel A applies assumed eligibility and computer-work shares to the observed BEA 2025 domestic employee-compensation denominator. The exact supplied rounded-base scenario remains in the data. Panel B is a separate standardized BLS median-wage-times-employment proxy with nonoverlapping occupation-task allocations and assumed context, adoption, fee and obtainable-share fractions. The panels must not be added, and fixture acceptance does not identify those shares.
