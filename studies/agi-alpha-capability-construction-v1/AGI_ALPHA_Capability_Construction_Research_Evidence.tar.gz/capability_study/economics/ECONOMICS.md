# Productive capability and the employer's decision

## What the new evidence can price

A retained method has commercial value when it repeatedly delivers acceptable work at lower total cost or within a constraint that previously prevented delivery. It may also make a new offering possible. The value belongs to the accepted deliverables and expanded feasible service, not to the number of saved tools. The market comparison uses observed labor-price evidence and measured Agent execution alongside explicitly hypothetical human durations and attention costs. It does not report a newly conducted human experiment or imply that salary statistics supply task timings.

The source register contains 24 **price records**, including two pairs of differently represented BLS wage estimates; these are not 24 independent surveys. The seven proposed work families map to real occupational duties. O*NET describes software QA defect documentation and regression checks, technical writing and revision, and project-plan updates and coordination. These sources justify task relevance. They do not establish what fraction of each job the implemented system can perform, nor do they measure the time distribution of the exact missions. Human responsibility remains for goals, authority, ambiguous inputs, high-stakes judgment, stakeholder work, production decisions and physical implementation. See `family_matrix.json`, the linked O*NET sources, and BLS Table 1.2.

## Labor prices and geography

| Labor-price anchor | Reference year or period | Currency and amount | Cost boundary |
|---|---|---:|---|
| U.S. software developer median | May 2025 | USD 135,980/year; analytical USD 65.375/hour | Wage only; annual/2,080 conversion is a convention |
| U.S. software QA/tester median | May 2025 | USD 104,300/year; USD 50.144/hour | Wage only |
| U.S. data scientist median | May 2025 | USD 120,230/year; USD 57.803/hour | Wage only |
| U.S. project specialist median | May 2025 | USD 102,320/year; USD 49.192/hour | Wage only |
| U.S. technical writer median | May 2025 | USD 90,390/year; USD 43.457/hour | Wage only |
| U.S. market research median | May 2025 | USD 78,760/year; USD 37.865/hour | Wage only |
| U.S. private office/admin mean | December 2025 | USD 35.96/hour | Wages 24.79 plus benefits 11.17 |
| U.S. private professional mean | December 2025 | USD 72.19/hour | Wages 50.10 plus benefits 22.09 |
| Quebec software developer median | LFS 2023–2024; updated 19 Nov 2025 | CAD 45.67/hour | Wage only; published low 29.00/high 68.13 |
| Ontario technical writer median | LFS 2023–2024; updated 19 Nov 2025 | CAD 34.98/hour | Wage only; low 27.00/high 59.63 |
| EU covered-economy mean | 2025; published 31 Mar 2026 | EUR 34.9/hour | Employer labor costs, not an occupation match |
| Netherlands/Bulgaria sensitivities | 2025 | EUR 47.9/EUR 12.0 per hour | Same Eurostat covered-sector definition |

Sources: [BLS occupation matrix](https://www.bls.gov/emp/tables/occupational-projections-and-characteristics.htm); [BLS ECEC](https://www.bls.gov/news.release/archives/ecec_03202026.htm); [Quebec Job Bank](https://www.jobbank.gc.ca/marketreport/wages-occupation/22548/QC); [Ontario Job Bank](https://www.jobbank.gc.ca/marketreport/wages-occupation/20923/ON); [Eurostat](https://ec.europa.eu/eurostat/en/web/products-eurostat-news/w/ddn-20260331-2). The full machine-readable matrix preserves occupation codes, publication dates, currency, methodology, coverage and remaining responsibilities.

Wage-only estimates receive separately displayed assumed employer loads 1.00/1.30/1.50. Inclusive ECEC and Eurostat costs receive no extra benefit multiplier. Eurostat's covered economy excludes agriculture, public administration, households and extraterritorial bodies, and the standard enterprise-size scope is 10+ employees. None of the wage sources establishes workers' AI use. Their economic role is to price the explicitly stated traditional non-AI comparator; they are not a survey of such a comparator. ILOSTAT supplies earnings concepts and cross-country methods; national definitions, reference periods and coverage must be retained, rather than treating local-currency observations as a single global wage. No exchange-rate conversion is used here.

## What published human timing establishes—and does not

The strongest historical evidence for ordinary non-generative workflows in the preserved evidence docket is WREX's 2020 manual coding condition: twelve professional data scientists worked on six transformation microtasks with internet access and a five-minute limit. Twelve of 36 manual attempts passed. Censored failures and task mismatch prevent using its reported times as the human denominator for Alpha's full deliveries.

The 2022 experiment reported by [Peng et al., 2023](https://arxiv.org/html/2302.06590v1) recruited 95 professional programmers to implement a JavaScript HTTP server. Correctness required all twelve tests; elapsed time ran from repository creation to first passing commit. Controls averaged 160.89 minutes **conditional on completing the task**. Copilot was unavailable to controls, but other methods were otherwise unconstrained; the source does not establish a universal ban on every AI tool. This is useful evidence that complete software jobs have measurable acceptance and rework, not a measured time for the present bounded utility repairs.

The [Noy–Zhang working-paper version dated 2 March 2023](https://economics.mit.edu/sites/default/files/inline-files/Noy_Zhang_1.pdf) reports 444 professionals, a 27-minute self-reported control mean and mean grade 3.789/7. It also reports ChatGPT use by 10–20% of controls. Therefore its control mean is **excluded from strict no-AI cost calibration**. The later Science paper has a different sample size; versions are not mixed. TASHEEH's cumulative ten-file manual repair time and SpreadsheetBench's human accuracy are retained as adjacent evidence with unknown AI restrictions and unmatched task contracts. No credible exact human time was retrieved for the seven new templates. Break-even analysis is consequently the primary quantitative comparison, with explicit duration sensitivities rather than borrowed denominators.

## Cost per accepted delivery

For an observed batch, divide every attributable delivery and allocated improvement cost by accepted outputs. Rejected attempts, retries and abandonment belong in the numerator. A repeat-until-accepted model may divide per-attempt costs by acceptance only when attempts and costs use the same boundary. Quality is part of the contract, not an afterthought to fast execution.

With hourly labor price w, traditional total effort t, remaining Agent attention h and other allocated Agent cost k, equal acceptance gives `C_H=wt/60`, `C_A=wh/60+k`, and `t*=h+60 k/w`. Here k includes all other costs, not merely CPU. At the U.S. office/admin employer cost 35.96/hour, assumed h=5 minutes and k=USD 1 imply an Agent cost USD 3.997 and break-even traditional effort 6.669 minutes. An assumed 30-minute traditional workflow costs USD 17.98: the conditional ratio is 4.50× and attention-limited capacity ratio 6×. If the traditional work takes only 5 minutes, its cost USD 2.997 is lower. These are scenarios, not measured commercial wins.

Using the broader professional employer price 72.19/hour under the same 5-minute/$1 assumptions gives Agent cost USD 7.016, break-even 5.831 minutes, and a conditional 30-minute cost ratio 5.14×. Geographic wage-only examples require explicit loads. An all-in Agent price of 5 local-currency units breaks even after 6.57 minutes of Quebec software-developer time at the unburdened median, 8.58 minutes of Ontario technical-writer time, 6.26 minutes at the Netherlands broad employer cost and 25.00 minutes at Bulgaria's. These are separate currencies and contexts; this comparison is not a ranking of local profitability.

The predeclared grid has 810 scenarios across two inclusive U.S. rates, five human durations, three attention durations, three other-cost values and three independent acceptance assumptions per side. In 266 combinations, the modeled Agent advantage is nonpositive. This count expresses sensitivity, not a probability or observed failure rate. Actual complete Agent monetary cost, whole-system employer attention and matched human advantage remain null until observed. Measured execution latency and resources should be joined without erasing these unknowns.

## From national scale to an addressable service

BEA reports calendar 2025 **domestic employee compensation paid of USD 15.718937 trillion** in its September 30, 2026 vintage, distributed by FRED as [GDICOMPA](https://fred.stlouisfed.org/series/GDICOMPA). It includes wages and employer supplements, includes remuneration for domestic production paid to nonresidents, excludes receipts from abroad and excludes self-employed proprietors' earnings. It is neither GDP nor cash wages alone. The separate national-income series is USD 15.696228 trillion; the two concepts must not be silently interchanged.

Preserve the supplied scenario exactly: rounded USD 15.70 T × assumed eligible-occupation share (0.70/0.775/0.85) × assumed computer-task share within eligible work (0.45/0.60/0.75) yields **USD 4.9455 T/7.3005 T/10.00875 T**. The refreshed domestic denominator gives **USD 4.9515 T/7.3093 T/10.0208 T** using those same assumptions. The supplied USD 5–10 T range is thus an explicit 2025 scenario. Neither share is an official estimate of computer-mediated work; neither is proven by this task portfolio. A 2026 sensitivity separately applies hypothetical nominal growth 0%/4%/8%. It is not a 2026 annual BEA observation or official forecast.

A bottom-up model then makes the large number harder to misuse. Ten distinct BLS occupational codes receive nonoverlapping time allocations for the seven families. For each occupation, employment times annual median wage is a standardized wage-value proxy. This is deliberately not called payroll: a median is not a mean, and the employment series includes self-employment while OEWS wages exclude it. Assumed task shares are multiplied by family-specific matching-context shares, then adoption/integration shares, retained customer costs, service fees and one provider's obtainable share. These are hypotheses to validate through deployment, not outputs inferred from fixture success.

| Bottom-up scenario | Relevant task-value proxy | Matching-context value, assumed | Serviceable/adopted value, assumed | Fees to all providers, assumed | One provider revenue, assumed |
|---|---:|---:|---:|---:|---:|
| Conservative | USD 23.10 B | USD 4.87 B | USD 243.62 M | USD 48.72 M | USD 48.72 K |
| Central | USD 46.19 B | USD 19.49 B | USD 3.90 B | USD 779.59 M | USD 7.80 M |
| Ambitious | USD 92.39 B | USD 58.47 B | USD 23.39 B | USD 4.68 B | USD 233.88 M |

The provider shares are assumed 0.1%/1%/5%; they are not evidence of sales. The selected wage-value proxy must not be added to national compensation or to customer savings. Global USD 12 T/24 T/40 T digital-work illustrations remain separate hypothetical portions of a USD 60 T labor envelope. ILO's modeled 2025 labor-income share 52.6% does not convert selected U.S. task coverage into a worldwide addressable market. Currency conversion, sector/occupation harmonization, informal work, infrastructure, language, procurement, privacy and integration all remain material.

## Closing the construction account

The accepted-use break-even is `ceil(K/delta_C)` when the net saving per reuse against the strongest available feasible method is positive. At a construction cost of 100 local-currency units and a net saving of 1 unit per accepted reuse, 100 accepted reuses repay the investment; at a saving of 0.01 unit, 10,000 are required. A reusable method that loses to the existing specialist has no finite cost payback without another verified benefit. Expected demand, review, deployment, support, maintenance, regressions and obsolescence must enter this decision. A technically sound tool can therefore be a rejected investment.

The accompanying model explores 243 eight-cycle reinvestment scenarios. Only 63 permit any reinvestment under the frozen demand, price, reliability, utilization and diminishing-return inputs; simulated final cash ranges 320 to 7,802.144 from hypothetical opening cash 1,000. These expected-value paths enforce a finite improvement allowance and never spend money. They demonstrate the accounting distinction between revenue, delivery outlay, cash margin and an improvement budget. They do not establish real revenue, cash reinvestment, self-acceleration or sustained autonomous operation. Reduced employee effort can create economic value while releasing no cash that the provider can spend.

## Interfaces to larger productive systems

The demonstrated digital mechanisms suggest specific future interfaces; they do not validate physical outcomes:

| System | Digital contribution to test next | Required external validation and dependencies |
|---|---|---|
| Scientific discovery | Reproducible evidence packets, numerical checks, experiment dependency plans and result provenance | Domain experts, calibrated instruments, experimental design, repeatable measurements, materials, laboratory access and actual elapsed experiments |
| Engineering | Traceable requirements, software/test artifacts, design-change impact and simulation orchestration | Trusted CAD/CAE interfaces, boundary conditions, uncertainty, physical tests, manufacturing tolerance and authorized design approval |
| Infrastructure | Scenario comparison, constraint checks, procurement records and schedule repair | Site data, grid interconnection, permitting, equipment lead times, financing, construction capacity and safety validation |
| Industrial coordination | Quality-record reconciliation, versioned operating instructions and exception routing | MES/ERP authority, trustworthy sensors, supply chains, access control, physical inventory and accountable operating decisions |

[NASA's systems-engineering guidance](https://www.nasa.gov/reference/2-0-fundamentals-of-systems-engineering/) distinguishes conformance verification from suitability validation. [NIST's manufacturing digital-twin work](https://www.nist.gov/programs-projects/digital-twins-advanced-manufacturing) emphasizes verification, validation, uncertainty and traceable interfaces. A dependency repair method can preserve digital evidence without making a material or machine safe. A bounded scientific-computing task is not a discovery claim.

Energy, capital and lead time put real bounds on compounding. The [IEA's 2025 Energy and AI report](https://www.iea.org/reports/energy-and-ai/executive-summary) estimates 415 TWh of data-centre electricity in 2024 and projects 945 TWh in its 2030 base case; these figures cover data centres, not only AGI or AI. Its discussion of grid delays and multiyear equipment/transmission lead times explains why software replication cannot imply unlimited physical output. Faster digital methods may improve the planning or utilization of scarce resources; energy, compute, materials, manufacturing, finance and physical validation still have to be supplied.
