# SPDX-License-Identifier: Apache-2.0
"""Validate consequential economic identities without inferring missing data."""
import hashlib
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parent
results = json.loads((ROOT / 'economic_results.json').read_text())
inputs = json.loads((ROOT / 'scenario_inputs.json').read_text())
rates = json.loads((ROOT / 'rate_matrix.json').read_text())['rates']
families = json.loads((ROOT / 'family_matrix.json').read_text())['families']
checks = []

def check(name, passed):
    checks.append({'check': name, 'passed': bool(passed)})
    if not passed:
        raise AssertionError(name)

check('Unique price-record identifiers', len({r['id'] for r in rates}) == len(rates))
check('Exactly seven declared families', len(families) == 7)
check('No fictional full-cost value', results['actual_agent_cost_per_accepted_output'] is None)
check('No fictional attention value', results['actual_full_system_employer_attention_minutes'] is None)
check('No empirical human advantage invented', results['empirical_human_advantage_ratio'] is None)
check('Same-task human durations are not wage-derived', all(r['duration_or_quality_on_study_jobs'] == 'NOT_MEASURED' for r in rates))
check('AI-use status disclosed for all price records', all(r['ai_usage_in_source_workers'] == 'NOT_ESTABLISHED' for r in rates))
rate_map = {r['id']: r for r in rates}
for row in results['break_even']:
    rate = rate_map[row['rate_id']]
    if rate['cost_basis'] != 'wage_only':
        check('No double benefits uplift: '+row['rate_id'], row['load_assumed'] == 1)
    lhs = row['human_break_even_minutes_per_accepted_output'] * rate['rate_per_hour'] * row['load_assumed'] / 60
    check('Break-even identity: '+row['rate_id'], math.isclose(lhs, row['all_in_agent_cost_per_accepted_output_assumed']))
for row in results['bottom_up']:
    adopted = row['serviceable_adopted_value_assumed']
    flows = row['all_provider_fees_assumed'] + row['customer_retained_cost_assumed'] + row['customer_potential_economic_value']
    check('Customer accounting partition: '+row['name'], math.isclose(adopted, flows))
    contributions = row['all_provider_contribution_before_fixed_cost'] + row['all_provider_delivery_cost_assumed']
    check('Provider accounting partition: '+row['name'], math.isclose(contributions, row['all_provider_fees_assumed']))
    check('Market scopes nested: '+row['name'], 0 <= adopted <= row['technically_matching_context_value_assumed'] <= row['relevant_task_value'])
for row in results['reinvestment_simulations']:
    check('No real cash claim in simulation', row['status'].startswith('SIMULATION_ONLY'))
    last_cash = row['parameters']['initial_cash']
    for cycle in row['cycles']:
        expected = last_cash + cycle['cash_margin_before_improvement_expected'] - cycle['improvement_outlay_simulated']
        check('Finite-cycle cash conservation', math.isclose(expected, cycle['cash_balance_simulated']))
        if cycle['construction_adopted']:
            check('Reinvestment within positive-margin allowance', cycle['improvement_outlay_simulated'] <= min(100, cycle['cash_margin_before_improvement_expected'] / 2))
        last_cash = cycle['cash_balance_simulated']
check('Sensitivity counts reconcile', len(results['delivery_sensitivity']) == 810)
check('Simulation counts reconcile', len(results['reinvestment_simulations']) == 243)
files = ['PROSPECTIVE_ECONOMICS.md', 'scenario_inputs.json', 'rate_matrix.json', 'family_matrix.json', 'model.py', 'build_inputs.py', 'validate.py', 'bibliography.bib', 'sources/expanded_source_register.json', 'sources/prior_human_market_benchmarks.json', 'sources/prior_source_register.json', 'sources/prior_human_evidence.md']
hashes = {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in files}
(ROOT / 'INPUTS_SHA256.json').write_text(json.dumps(hashes, indent=2)+'\n')
report = {'status': 'PASS', 'check_count': len(checks), 'scope': 'Economic accounting and scenario invariants, not empirical efficacy or independent scientific review', 'input_hashes': hashes, 'checks': checks}
(ROOT / 'VALIDATION.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps({'status': 'PASS', 'check_count': len(checks), 'source_inputs': len(files)}, indent=2))
