# Labor-price evidence for traditional human work

These are observed labor prices, not observed no-AI task durations or acceptance rates. All price records retain AI-use status `NOT_ESTABLISHED`. The comparator is explicitly competent traditional work with ordinary non-AI tools; salary data alone cannot identify its timing, quality or cost per accepted task.

| Geography | Occupation or scope | Reference period | Currency / hour | Price boundary | Source |
|---|---|---|---:|---|---|
| Quebec, Canada | Data entry clerks | 2023-2024 | CAD 24 | Wage only | [Primary source](https://www.jobbank.gc.ca/marketreport/wages-occupation/19213/QC) |
| Quebec, Canada | Accounting technicians and bookkeepers | 2023-2024 | CAD 28.02 | Wage only | [Primary source](https://www.jobbank.gc.ca/marketreport/wages-occupation/24500/QC) |
| Quebec, Canada | Database analysts and data administrators; data analyst - informatics and systems | 2023-2024 | CAD 43.96 | Wage only | [Primary source](https://www.jobbank.gc.ca/marketreport/wages-occupation/17873/QC) |
| United States | Data Entry Keyers | 2025 | USD 19.88 | Wage only | [Primary source](https://www.onetonline.org/link/summary/43-9021.00) |
| United States | Bookkeeping, Accounting, and Auditing Clerks | 2025 | USD 24.36 | Wage only | [Primary source](https://www.onetonline.org/link/summary/43-3031.00) |
| United States, private industry | Office and administrative support occupations | December 2025 | USD 35.96 | Wage + benefits | [Primary source](https://www.bls.gov/news.release/archives/ecec_03202026.htm) |
| United States, private industry | Professional and related occupations | December 2025 | USD 72.19 | Wage + benefits | [Primary source](https://www.bls.gov/news.release/archives/ecec_03202026.htm) |
| European Union | Covered economy, all occupations | 2025 | EUR 34.9 | Employer labor costs | [Primary source](https://ec.europa.eu/eurostat/en/web/products-eurostat-news/w/ddn-20260331-2) |
| Netherlands | Covered economy, all occupations | 2025 | EUR 47.9 | Employer labor costs | [Primary source](https://ec.europa.eu/eurostat/en/web/products-eurostat-news/w/ddn-20260331-2) |
| Luxembourg | Covered economy, all occupations | 2025 | EUR 56.8 | Employer labor costs | [Primary source](https://ec.europa.eu/eurostat/en/web/products-eurostat-news/w/ddn-20260331-2) |
| Bulgaria | Covered economy, all occupations | 2025 | EUR 12 | Employer labor costs | [Primary source](https://ec.europa.eu/eurostat/en/web/products-eurostat-news/w/ddn-20260331-2) |
| Romania | Covered economy, all occupations | 2025 | EUR 13.6 | Employer labor costs | [Primary source](https://ec.europa.eu/eurostat/en/web/products-eurostat-news/w/ddn-20260331-2) |
| United States | Software developers | 2025; wage reference May 2025 | USD 65.375 | Wage only | [Primary source](https://www.bls.gov/emp/tables/occupational-projections-and-characteristics.htm) |
| United States | Software quality assurance analysts and testers | 2025; wage reference May 2025 | USD 50.144 | Wage only | [Primary source](https://www.bls.gov/emp/tables/occupational-projections-and-characteristics.htm) |
| United States | Data scientists | 2025; wage reference May 2025 | USD 57.803 | Wage only | [Primary source](https://www.bls.gov/emp/tables/occupational-projections-and-characteristics.htm) |
| United States | Operations research analysts | 2025; wage reference May 2025 | USD 42.76 | Wage only | [Primary source](https://www.bls.gov/emp/tables/occupational-projections-and-characteristics.htm) |
| United States | Project management specialists | 2025; wage reference May 2025 | USD 49.192 | Wage only | [Primary source](https://www.bls.gov/emp/tables/occupational-projections-and-characteristics.htm) |
| United States | Market research analysts and marketing specialists | 2025; wage reference May 2025 | USD 37.865 | Wage only | [Primary source](https://www.bls.gov/emp/tables/occupational-projections-and-characteristics.htm) |
| United States | Technical writers | 2025; wage reference May 2025 | USD 43.457 | Wage only | [Primary source](https://www.bls.gov/emp/tables/occupational-projections-and-characteristics.htm) |
| United States | Web developers | 2025; wage reference May 2025 | USD 44.543 | Wage only | [Primary source](https://www.bls.gov/emp/tables/occupational-projections-and-characteristics.htm) |
| United States | Data entry keyers | 2025; wage reference May 2025 | USD 19.875 | Wage only | [Primary source](https://www.bls.gov/emp/tables/occupational-projections-and-characteristics.htm) |
| United States | Bookkeeping, accounting, and auditing clerks | 2025; wage reference May 2025 | USD 24.361 | Wage only | [Primary source](https://www.bls.gov/emp/tables/occupational-projections-and-characteristics.htm) |
| Quebec, Canada | Software developers and programmers | 2023-2024 | CAD 45.67 | Wage only | [Primary source](https://www.jobbank.gc.ca/marketreport/wages-occupation/22548/QC) |
| Ontario, Canada | Technical writers | 2023-2024 | CAD 34.98 | Wage only | [Primary source](https://www.jobbank.gc.ca/marketreport/wages-occupation/20923/ON) |

U.S. occupation rates sourced from annual medians use a declared 2,080-hour conversion convention, not observed annual hours. BLS ECEC rates are broad occupational-group means per hour worked. Eurostat figures are covered-economy means, normally enterprises with 10 or more employees in NACE B–N and P–S; they are not occupation-matched prices. Canadian provincial estimates are Statistics Canada LFS medians distributed by Job Bank. Wage-only employer loads of 1.00, 1.30 and 1.50 are sensitivity assumptions; benefits-inclusive rates are not loaded a second time.

The 24 records include two pairs of differently represented BLS data-entry and bookkeeping wage estimates. They are not 24 independent surveys, and hourly currencies are not converted or ranked as if they represented the same market. Full source dates, methods, ranges and limitations are in `rate_matrix.json`.
