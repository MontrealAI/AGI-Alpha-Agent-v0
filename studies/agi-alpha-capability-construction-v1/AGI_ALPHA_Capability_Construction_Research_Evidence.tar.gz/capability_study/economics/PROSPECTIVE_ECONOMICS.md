# Prospective economic analysis — capability construction edition

Prepared 25 October 2026; separate from the frozen Economics of Autonomous Work edition (#4901). This document and the JSON inputs are to be hashed with the new study's protocol **before confirmatory Agent outcomes are inspected**. The historical edition and its evidence remain unchanged.

## Comparator and evidence boundary

The primary employer comparator is competent traditional human-performed digital work using ordinary non-AI tools, efficient legitimate workflows, reusable templates, review and correction. This is a market-data-grounded economic comparison, **not a newly recruited human trial**. Official wages and employer costs are price parameters; they identify neither no-AI behavior nor task duration or quality on these missions. The seven selected families are bounded portions of occupations. Forty-two fresh variants do not constitute forty-two independent occupational families.

The planned groups are software/testing, analysis, source research/synthesis, documents/presentations, planning/operations, scientific computation, and web/documentation. The family matrix records tested portions and retained human responsibilities. Higher-stakes or unsupported uses are excluded from serviceability evidence even if adjacent fixture tasks pass.

## Outcomes and complete cost boundary

For each actual attempt retain setup/input preparation, producer execution, output verification, review/challenge/adjudication, correction, retries, abandoned work, interventions and delivery. Record elapsed time, CPU, model calls/tokens where observable, and accepted outputs. Record actual human effort and money only if observed; use null when unobservable. Preserve separate delivery and improvement accounts; combine them for adoption analysis. Model generation, failed construction, independent evaluation, deployment, support and maintenance count toward improvement cost and amortization. Do not replace missing full cost with deterministic execution cost.

Let n be attempted jobs, a accepted deliveries, and K the full construction/deployment investment plus accrued maintenance reserve. A realized cost ledger gives `C_accept = (sum(all attempt delivery costs) + allocated K) / a`. The sensitivity form is `C_H = (w_H t_H/60 + v_H)/q_H` and `C_A = (w_A h_A/60 + k_A)/q_A`; t_H and h_A include attributable review/rework within an attempt, and k_A includes all other allocated costs. Failed attempts are included. If rework is assigned a separate attempt, do not also count it as within-attempt effort. At equal acceptance probabilities and labor prices, break-even human minutes equal `h_A + 60 k_A/w`. Otherwise use `t_H* = 60(q_H C_A - v_H)/w_H`.

Primary reporting includes accepted quality, cost per accepted output (unknown if material components are unmeasured), end-to-end turnaround, human effort remaining and capacity constrained by budget, attention, execution resources and real demand. CPU time is not monetary cost, and released employee time is not cash savings. A zero observed intervention in a bounded worker does not establish zero whole-system supervision.

## Frozen sensitivities, not empirical duration estimates

- Human total effort per attempt: 5, 15, 30, 60 and 120 minutes.
- Remaining Agent employer attention per attempt: 1, 5 and 15 minutes.
- All other Agent cost per attempt: 1, 5 and 25 units of the source currency.
- Acceptance probabilities: .80, .95 and 1.00 for each comparator independently; use empirical fixture acceptance descriptively outside this population sensitivity.
- Wage-only employer loads: 1.00, 1.30 and 1.50. Never uplift already inclusive ECEC or Eurostat employer-cost figures a second time.
- All-in Agent cost per accepted output for geography-specific break-even: 1, 5, 10 and 25 local-currency units.
- Full construction costs: 25, 100 and 500; net savings per accepted reuse: .01, .10, 1 and 5, each hypothetical.

No exchange-rate conversion or pooled cross-currency wage ranking is made. Equal numerical USD, CAD and EUR scenario inputs are separate assumptions, not exchange equivalents. Unweighted sensitivity counts are not probabilities. Report losing as well as winning combinations; do not select assumptions to achieve a predetermined ratio.

## Market model

Preserve the supplied U.S. calculation exactly: rounded 2025 compensation $15.70 T × assumed occupation eligibility (.70, .775, .85) × assumed computer-task shares within eligible work (.45, .60, .75) = $4.9455 T, $7.3005 T and $10.00875 T. These are scenarios, not official statistics or measured automation coverage. Show the revised BEA domestic compensation-paid denominator $15.718937 T separately, with the same assumptions. The year is 2025; 2026 growth of 0%, 4% or 8% is an explicit projection sensitivity, not a new annual observation.

The bottom-up model uses ten distinct BLS occupation codes. A published job count times a median wage is explicitly a **standardized wage-value proxy**, not a reconstructed official wage bill. Employment-projection job counts include self-employment whereas OEWS wages exclude it; no suppressed self-employed percentage is invented as zero. Every occupation has nonoverlapping assumed task allocations across families, summing to less than one. Each family's matching-context, adoption, retained-customer-cost, provider-cost, fee and obtainable-share assumptions remain visible. Neither the national scenario nor this selected proxy is a forecast. The two cannot be summed. No portfolio pass rate or cost ratio is extrapolated across all work.

## Construction, discovery and reinvestment

Break-even reuse is `ceil(K / delta_C)` only if delta_C is positive net saving against the best available feasible alternative at equivalent acceptance. If delta_C ≤ 0, there is no finite cost payback. Use expected accepted demand over a bounded horizon and include obsolescence, deployment, review and maintenance when deciding whether to continue. Do not value a retained tool as an asset merely because it exists.

The economic simulation is separately labeled. It is eight finite cycles with hypothetical opening cash 1000, attempt cost 2, support 25 per cycle, construction 50 and maximum improvement allowance 100 per cycle, further bounded by half the current positive delivery cash margin. A construction is adopted only if its assumed next-four-cycle savings exceed its cost and cash/allowance cover it. Demand 10/50/100, price 2/5/10, acceptance.7/.9/1, utilization.25/.5/1 and diminishing-return multipliers.25/.5/.8 are all scenario inputs. No money is collected, spent or committed. This simulation does not establish self-acceleration; discovery efficiency and acceleration require separately frozen empirical tests.

## Metric input interface

A later report may join actual attempt records with fields `mission_id`, `family`, `accepted`, `attempt`, `outer_wall_seconds`, `child_cpu_seconds`, `verification_seconds`, `model_calls`, `model_tokens`, `human_attention_minutes`, `delivery_cost`, `improvement_cost_allocation`, `maintenance_cost`, `interventions`, and source hashes. Missing fields remain null. No new pricing or task-time assumption is inferred from observed confirmation performance.
