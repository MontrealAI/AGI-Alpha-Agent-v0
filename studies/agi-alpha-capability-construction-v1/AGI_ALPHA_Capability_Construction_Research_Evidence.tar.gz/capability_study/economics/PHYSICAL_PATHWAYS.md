# Digital capability in larger productive systems

**Status: proposed interfaces and validation requirements, not demonstrated physical productivity.** The interfaces below are engineering inferences from the bounded digital mechanisms and the cited primary guidance. A reusable numerical check or dependency repair can support a larger process; acceptance of the digital artifact does not establish that a physical system works safely or that an experiment discovers something new.

| Productive system | Concrete digital interface to investigate | Acceptance beyond the digital artifact | Resources and constraints that remain | Primary basis |
|---|---|---|---|---|
| Scientific discovery | Evidence packet and reproducible numerical method → electronic laboratory record and experiment plan | Domain review, calibrated instruments, reproducible measurements and physical experiments | Materials, specimens, laboratory access, instrument capacity and experimental elapsed time | NASA's distinction between verification and validation supplies the general acceptance principle; this scientific interface is a proposal, not a NASA or Alpha result. |
| Engineering | Requirements and changed-dependency repair → CAD/CAE, product lifecycle records and test plans | Verify requirements, validate intended use, quantify uncertainty, then conduct appropriate physical tests | Engineering judgment, compute, manufacturing tolerances, test facilities, material availability and design authority | NASA systems engineering; NIST manufacturing digital-twin work. |
| Manufacturing and industrial coordination | Versioned procedures, quality-record reconciliation and exception routing → digital twins, ERP/MES and operator work orders | Traceable models and data, calibrated sensor evidence, physical quality checks and accountable decisions | Machines, workers, tooling, inventory, logistics, manufacturing throughput and working capital | NIST emphasizes interfaces, traceability, verification, validation and uncertainty; the proposed Alpha connection is not a certification. |
| Infrastructure | Constraint checks and schedule repair → site, grid-interconnection, procurement and construction records | Site-specific feasibility, authorized approvals, permits, independent engineering and commissioning | Energy supply, land, steel/copper and equipment, financing, skilled construction capacity and lead times | IEA documents electricity/grid constraints and transmission construction taking 4–8 years in advanced economies. No Alpha physical delivery is measured. |
| Compute and energy enabling every row | Resource-allocation policy → approved executor, metered compute and workload queue | Meter actual accepted throughput, energy/resource costs, failures, supervision and recovery | Servers, electricity, cooling, network connections, capital expenditure and grid capacity | IEA estimates global data-centre electricity use of 415 TWh in 2024 and projects 945 TWh in its 2030 base case; these include non-AI data centres and are not measurements of this study. |

## Primary-source record

| Source | Year / scope | What is supported | What is not supported |
|---|---|---|---|
| [NASA, Fundamentals of Systems Engineering](https://www.nasa.gov/reference/2-0-fundamentals-of-systems-engineering/) | 2025 webpage; systems-engineering guidance | Conformance verification and suitability validation are different obligations | Certification of AGI ALPHA or proof of physical discovery |
| [NIST, Digital Twins for Advanced Manufacturing](https://www.nist.gov/programs-projects/digital-twins-advanced-manufacturing) | Page retrieved October 2026; manufacturing research program | Traceable interfaces, verification, validation and uncertainty requirements | A completed general digital-twin product or Alpha deployment |
| [IEA, Energy and AI, executive summary](https://www.iea.org/reports/energy-and-ai/executive-summary) | 2025 report; global 2024 estimate, 2030 base-case projection | Aggregate electricity and grid constraints; multiyear infrastructure lead times | Marginal energy per Alpha task, infinite scaling, guaranteed 2030 demand or a physical automation market |

Energy and infrastructure values are contextual evidence, not inputs to the frozen labor-cost scenarios. The pathway remains conditional: improve a digital step; connect to an authorized process; verify and validate at the external interface; then measure the complete physical result, its elapsed time and its resource cost.

Bibliography keys: `nasaSystemsEngineering`, `nistDigitalTwins`, `iea2025EnergyAI`.
