# SPDX-License-Identifier: Apache-2.0
"""Build explicit research inputs from inspected primary-source extracts."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PRIOR = ROOT / 'sources'

def write(name, obj):
    (ROOT / name).write_text(json.dumps(obj, indent=2, ensure_ascii=False) + '\n')

prior_path = PRIOR / 'prior_human_market_benchmarks.json'
prior = json.loads(prior_path.read_text())
rates = prior['rates']
for rate in rates:
    rate['ai_usage_in_source_workers'] = 'NOT_ESTABLISHED'
    rate['duration_or_quality_on_study_jobs'] = 'NOT_MEASURED'
    rate['benefits_coverage'] = (
        'Excluded; any employer load is an explicit scenario.'
        if rate['cost_basis'] == 'wage_only'
        else 'Included in published cost basis; do not add a second benefits multiplier.'
    )
    rate['reuse_provenance'] = 'Preserved Economics edition source register; unchanged source value.'

bls_table = 'https://www.bls.gov/emp/tables/occupational-projections-and-characteristics.htm'
occ_rows = [
    ('us_software', 'Software developers', '15-1252', 135980, 1717800, 1.5, 'software_testing', {'software_testing': 0.05, 'web_documentation': 0.01}),
    ('us_qa', 'Software quality assurance analysts and testers', '15-1253', 104300, 187600, None, 'software_testing', {'software_testing': 0.10, 'web_documentation': 0.02}),
    ('us_analysis', 'Data scientists', '15-2051', 120230, 275600, 1.9, 'analysis', {'analysis': 0.05, 'scientific_computing': 0.02, 'research_synthesis': 0.02}),
    ('us_operations', 'Operations research analysts', '15-2031', 88940, 113100, None, 'planning_operations', {'planning_operations': 0.05, 'scientific_computing': 0.03, 'analysis': 0.02}),
    ('us_projects', 'Project management specialists', '13-1082', 102320, 1094300, 1.2, 'planning_operations', {'planning_operations': 0.05, 'documents_presentations': 0.02, 'analysis': 0.01}),
    ('us_research', 'Market research analysts and marketing specialists', '13-1161', 78760, 952700, 3.8, 'research_synthesis', {'research_synthesis': 0.08, 'documents_presentations': 0.03, 'analysis': 0.02}),
    ('us_technical_writer', 'Technical writers', '27-3042', 90390, 46400, 1.0, 'documents_presentations', {'documents_presentations': 0.12, 'web_documentation': 0.03}),
    ('us_web', 'Web developers', '15-1254', 92650, 87400, 17.5, 'web_documentation', {'web_documentation': 0.10, 'software_testing': 0.03, 'documents_presentations': 0.01}),
    ('us_data_entry_cohort', 'Data entry keyers', '43-9021', 41340, 131800, 1.6, 'analysis', {'analysis': 0.10, 'web_documentation': 0.03}),
    ('us_bookkeeping_cohort', 'Bookkeeping, accounting, and auditing clerks', '43-3031', 50670, 1532400, 5.6, 'analysis', {'analysis': 0.05, 'documents_presentations': 0.01}),
]
cohorts = []
for key, title, code, wage, employment, self_employed, family, allocation in occ_rows:
    row = {
        'id': key,
        'geography': 'United States',
        'occupation': title,
        'occupation_code': code,
        'currency': 'USD',
        'annual_median_wage': wage,
        'rate_per_hour': wage / 2080,
        'hourly_conversion': 'Annual median divided by 2,080; analytical convention, not measured annual hours.',
        'statistic': 'OEWS median annual wage; Employment Projections base-year employment',
        'cost_basis': 'wage_only',
        'reference_period': '2025; wage reference May 2025',
        'published_or_updated': '2026-08-27',
        'source_key': 'bls2025occupationmatrix',
        'source_url': bls_table,
        'source_refs': ['turn68view2', 'turn69view2', 'turn69view3', 'turn69view4', 'turn70view0', 'turn70view2', 'turn70view4', 'turn70view5'],
        'methodology': 'BLS Table 1.2 combines Employment Projections employment (including self-employment) with OEWS wage estimates (excluding self-employed). Employment is not observed task volume; median times employment is only a standardized wage-value proxy, not an estimated wage bill.',
        'benefits_coverage': 'Excluded; assumed load shown separately.',
        'ai_usage_in_source_workers': 'NOT_ESTABLISHED',
        'duration_or_quality_on_study_jobs': 'NOT_MEASURED',
        'task_fit': family,
    }
    rates.append(row)
    cohorts.append({
        'occupation_rate_id': key,
        'employment_2025': employment,
        'self_employed_percent_2025': self_employed,
        'self_employment_treatment': 'Scenario cohort uses all published jobs. No invented zero for suppressed self-employment. Wage-value proxy may be biased because OEWS wages exclude self-employment.',
        'task_time_allocation_central': allocation,
        'allocation_status': 'ASSUMED_NONOVERLAPPING_SHARES_WITHIN_OCCUPATION; no empirical O*NET task-time estimate',
    })

for key, title, code, geo, median, low, high, url in [
    ('ca_qc_software', 'Software developers and programmers', 'NOC 21232', 'Quebec, Canada', 45.67, 29.00, 68.13, 'https://www.jobbank.gc.ca/marketreport/wages-occupation/22548/QC'),
    ('ca_on_technical_writer', 'Technical writers', 'NOC 51112', 'Ontario, Canada', 34.98, 27.00, 59.63, 'https://www.jobbank.gc.ca/marketreport/wages-occupation/20923/ON'),
]:
    rates.append({
        'id': key, 'occupation': title, 'occupation_code': code,
        'geography': geo, 'currency': 'CAD', 'rate_per_hour': median,
        'low_per_hour': low, 'high_per_hour': high,
        'statistic': 'Median hourly wage; low/high published wage estimates, not confidence bounds',
        'cost_basis': 'wage_only', 'reference_period': '2023-2024',
        'published_or_updated': '2025-11-19', 'source_key': key,
        'source_url': url, 'source_refs': ['turn63view3' if key == 'ca_qc_software' else 'turn63view4'],
        'methodology': 'Statistics Canada Labour Force Survey via ESDC Job Bank. Provincial estimate. Gross wages exclude non-wage benefits; benefit receipt percentages do not quantify their cost.',
        'benefits_coverage': 'Excluded; employer load is a separate assumption.',
        'ai_usage_in_source_workers': 'NOT_ESTABLISHED',
        'duration_or_quality_on_study_jobs': 'NOT_MEASURED',
        'task_fit': 'Software repair' if key == 'ca_qc_software' else 'Structured technical briefs and slides; not the entire occupation',
    })

families = [
    ('software_testing', 'Software and testing', 'Bounded utility repair, regression checks and code patch', 'Regression completeness; API and source preservation', 'Security-sensitive changes, unobserved dependencies, broad maintenance obligations', ['us_software', 'us_qa', 'ca_qc_software'], 0.5),
    ('analysis', 'Data analysis', 'CSV-derived counts and reports with reproducible calculations', 'Exact units, types, missing data and denominator', 'Causal interpretation, data authority, sensitive records and business decisions', ['us_analysis', 'ca_qc_database_analyst', 'us_bookkeeping_wage'], 0.5),
    ('research_synthesis', 'Research and synthesis', 'Exact passage/source compilation from a frozen evidence packet', 'Required-claim presence, literal passage matching, source/hash/URL provenance and rendered-output consistency; no semantic entailment or source-truth validation', 'Open-world recall, disputed evidence and independent domain judgment', ['us_research', 'us_professional_compensation'], 0.25),
    ('documents_presentations', 'Documents and presentations', 'Structured brief and slide artifact from explicit supplied content', 'Completeness, editable output and render inspection', 'Original persuasion, audience understanding, external stakeholder acceptance', ['us_technical_writer', 'ca_on_technical_writer'], 0.5),
    ('planning_operations', 'Planning and operations', 'Dependency plan and affected-work repair under explicit change', 'Feasibility, dependency closure and preservation of valid work', 'Resource truth, negotiation, workforce decisions and physical execution', ['us_projects', 'us_operations'], 0.3),
    ('scientific_computing', 'Scientific computation', 'Numerical reproduction and machine-checkable result', 'Error tolerances, conditioning and reproducible methods', 'Scientific novelty, experimental validity and physical confirmation', ['us_analysis', 'us_operations'], 0.15),
    ('web_documentation', 'Web and documentation maintenance', 'Bounded URI/UTF-8 examples and documentation check', 'Standards compliance in tested cases, link/source traceability', 'Production rollout, external service permission and broad accessibility audit', ['us_web', 'us_qa', 'us_technical_writer'], 0.4),
]
write('rate_matrix.json', {
    'status': 'MARKET_DATA; NOT_NEW_HUMAN_TRIAL',
    'retrieved': '2026-10-25',
    'currency_policy': prior['currency_policy'],
    'prior_source_sha256': hashlib.sha256(prior_path.read_bytes()).hexdigest(),
    'rates': rates,
})
write('family_matrix.json', {
    'scope': 'Seven bounded task families; fresh instances do not create new occupations or independent task families.',
    'families': [dict(zip(['id', 'name', 'tested_portion', 'acceptance_focus', 'human_responsibilities_or_uncovered_scope', 'rate_ids', 'central_technical_context_share_assumed'], family)) for family in families],
    'breadth_warning': 'Fixture acceptance estimates conditional performance on this portfolio. It does not identify the market fraction matching these contexts, occupational task prevalence, customer acceptance, or independent deployment reliability.',
})
write('scenario_inputs.json', {
    'status': 'PROSPECTIVE_ASSUMPTIONS; freeze separately from old edition',
    'baseline': 'Competent traditional human digital work using ordinary non-AI tools; no human task durations inferred from salaries.',
    'human_minutes': [5, 15, 30, 60, 120],
    'human_minutes_status': 'ASSUMED inclusive effort per attempt, including attributable review and correction; not observed on study tasks',
    'agent_attention_minutes': [1, 5, 15],
    'agent_attention_status': 'ASSUMED inclusive employer effort per attempt; actual full-system attention unknown',
    'other_agent_cost_per_attempt_local_currency': [1, 5, 25],
    'other_cost_status': 'ASSUMED execution/model/setup/deployment/support/maintenance and construction allocation together; not measured billing',
    'wage_only_loads': [1.0, 1.3, 1.5],
    'human_acceptance_probability': [0.8, 0.95, 1.0],
    'agent_acceptance_probability': [0.8, 0.95, 1.0],
    'acceptance_status': 'Hypothetical sensitivities; not a population estimate from 42 fixtures',
    'all_in_agent_cost_per_accepted_output_local_currency': [1, 5, 10, 25],
    'improvement_cost_local_currency': [25, 100, 500],
    'improvement_cost_status': 'ASSUMED full construction, unsuccessful search, independent evaluation, deployment and maintenance reserve',
    'saving_per_accepted_reuse_local_currency': [0.01, 0.1, 1, 5],
    'saving_status': 'ASSUMED savings against the best available feasible method; not revenue',
    'cohorts': cohorts,
    'bottom_up_scenarios': [
        {'name': 'Conservative', 'task_allocation_multiplier': 0.5, 'context_share_multiplier': 0.5, 'adoption_fraction': 0.05, 'retained_customer_cost_fraction': 0.6, 'service_fee_fraction': 0.2, 'provider_delivery_cost_fraction': 0.15, 'individual_provider_share': 0.001},
        {'name': 'Central', 'task_allocation_multiplier': 1.0, 'context_share_multiplier': 1.0, 'adoption_fraction': 0.2, 'retained_customer_cost_fraction': 0.4, 'service_fee_fraction': 0.2, 'provider_delivery_cost_fraction': 0.1, 'individual_provider_share': 0.01},
        {'name': 'Ambitious', 'task_allocation_multiplier': 2.0, 'context_share_multiplier': 1.5, 'adoption_fraction': 0.4, 'retained_customer_cost_fraction': 0.2, 'service_fee_fraction': 0.2, 'provider_delivery_cost_fraction': 0.06, 'individual_provider_share': 0.05},
    ],
    'bottom_up_warning': 'All task shares, context shares, adoption, fees, costs and obtainable share are assumptions, not estimates fitted to confirmatory outcomes. Employment times median is a standardized wage-value proxy, not payroll. Scenario totals cannot be added to the U.S. compensation envelope.',
    'supplied_us_scenario': {
        'year': 2025, 'currency': 'USD', 'rounded_compensation_usd': 15700000000000,
        'occupation_eligibility_share': [0.70, 0.775, 0.85],
        'computer_mediated_task_share_within_eligible': [0.45, 0.60, 0.75],
        'expected_result_usd': [4945500000000, 7300500000000, 10008750000000],
        'status': 'USER_SUPPLIED_ILLUSTRATIVE_SCENARIO; neither share is an official estimate or demonstrated technical coverage',
    },
    'updated_us_denominator': {
        'year': 2025, 'currency': 'current USD', 'compensation_paid_usd': 15718937000000,
        'source': 'BEA NIPA Table 1.10, A4002C, distributed by Federal Reserve FRED GDICOMPA',
        'vintage': '2026-09-30', 'source_url': 'https://fred.stlouisfed.org/series/GDICOMPA',
        'scope': 'Employee remuneration for domestic production including wages and supplements; paid to nonresidents included, receipts from abroad excluded. Excludes self-employed proprietors income.',
    },
    'projection_2026_assumed_growth': [0.0, 0.04, 0.08],
    'projection_2026_status': 'SCENARIO_ONLY; not a BEA annual observation or official forecast',
    'global_scenario': {
        'reference_year': 2025, 'hypothetical_labor_envelope_usd': 60000000000000,
        'hypothetical_digital_task_labor_usd': [12000000000000, 24000000000000, 40000000000000],
        'status': 'Illustrative continuity scenarios from Economics edition; not harmonized global compensation estimates. Global GDP times modeled labor share is not an official employer-cost bill.',
    },
})
print(json.dumps({'rates': len(rates), 'occupational_cohorts': len(cohorts), 'families': len(families)}, indent=2))
