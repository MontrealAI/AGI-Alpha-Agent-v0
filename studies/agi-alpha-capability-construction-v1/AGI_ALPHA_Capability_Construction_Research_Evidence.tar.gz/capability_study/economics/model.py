# SPDX-License-Identifier: Apache-2.0
"""Transparent labor-price scenarios; no human trial or automatic spending.

All monetary Agent and human-duration inputs are hypothetical. Recorded
execution measurements may be joined separately, but cannot fill missing
prices, attention, construction, support or maintenance with zero.
"""

from __future__ import annotations

import itertools
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def read(name: str) -> dict:
    return json.loads((ROOT / name).read_text())


def delivery_cost(
    hourly_labor_cost: float,
    human_minutes: float,
    attention_minutes: float,
    other_agent_cost: float,
    human_acceptance: float,
    agent_acceptance: float,
) -> dict:
    """Per-attempt costs divided by acceptance; retries remain in denominator."""
    human = hourly_labor_cost * human_minutes / 60 / human_acceptance
    agent = (
        hourly_labor_cost * attention_minutes / 60 + other_agent_cost
    ) / agent_acceptance
    return {
        "human_cost_per_accepted_output": human,
        "agent_cost_per_accepted_output": agent,
        "cost_advantage_human_over_agent": human / agent,
        "human_minutes_per_accepted_output": human_minutes / human_acceptance,
        "remaining_attention_minutes_per_accepted_output": (
            attention_minutes / agent_acceptance
        ),
        "attention_capacity_ratio": (
            human_minutes / human_acceptance
        ) / (attention_minutes / agent_acceptance),
        "human_break_even_minutes_per_attempt": (
            60 * human_acceptance * agent / hourly_labor_cost
        ),
        "potential_economic_value_per_output": human - agent,
        "realized_cash_savings": None,
    }


def bottom_up(inputs: dict, rates: dict, families: dict) -> list[dict]:
    """Allocate each occupation's time once, before context/adoption filters."""
    results = []
    for scenario in inputs["bottom_up_scenarios"]:
        contributions = []
        for cohort in inputs["cohorts"]:
            rate = rates[cohort["occupation_rate_id"]]
            proxy = cohort["employment_2025"] * rate["annual_median_wage"]
            shares = cohort["task_time_allocation_central"]
            assert sum(shares.values()) * scenario["task_allocation_multiplier"] <= 1
            for family, fraction in shares.items():
                task_share = fraction * scenario["task_allocation_multiplier"]
                context_share = min(
                    1,
                    families[family]["central_technical_context_share_assumed"]
                    * scenario["context_share_multiplier"],
                )
                relevant = proxy * task_share
                eligible = relevant * context_share
                adopted = eligible * scenario["adoption_fraction"]
                contributions.append(
                    {
                        "occupation": rate["occupation_code"],
                        "family": family,
                        "standardized_wage_value_proxy": proxy,
                        "task_share_assumed": task_share,
                        "context_share_assumed": context_share,
                        "relevant_task_value": relevant,
                        "technically_matching_context_value_assumed": eligible,
                        "serviceable_adopted_value_assumed": adopted,
                    }
                )
        adopted_total = sum(
            row["serviceable_adopted_value_assumed"] for row in contributions
        )
        fee_total = adopted_total * scenario["service_fee_fraction"]
        retained = adopted_total * scenario["retained_customer_cost_fraction"]
        provider_cost = adopted_total * scenario["provider_delivery_cost_fraction"]
        results.append(
            {
                "name": scenario["name"],
                "status": "ASSUMPTION_SENSITIVITY_NOT_MARKET_ESTIMATE",
                "currency": "annual USD wage-value proxy",
                "relevant_task_value": sum(
                    row["relevant_task_value"] for row in contributions
                ),
                "technically_matching_context_value_assumed": sum(
                    row["technically_matching_context_value_assumed"]
                    for row in contributions
                ),
                "serviceable_adopted_value_assumed": adopted_total,
                "all_provider_fees_assumed": fee_total,
                "customer_retained_cost_assumed": retained,
                "customer_potential_economic_value": adopted_total - fee_total - retained,
                "all_provider_delivery_cost_assumed": provider_cost,
                "all_provider_contribution_before_fixed_cost": fee_total - provider_cost,
                "individual_provider_revenue_assumed": (
                    fee_total * scenario["individual_provider_share"]
                ),
                "actual_revenue": None,
                "actual_cash_margin": None,
                "components": contributions,
            }
        )
    return results


def reinvestment_simulation(
    demand: int,
    price: float,
    acceptance: float,
    utilization: float,
    diminishing: float,
) -> dict:
    """Finite expected-value simulation. Does not spend or provision anything."""
    cash = 1000.0
    attempt_cost = 2.0
    support_per_cycle = 25.0
    construction_cost = 50.0
    proposed_saving_per_attempt = 0.5
    cycles = []
    for cycle in range(1, 9):
        attempts = min(100 * utilization, demand / acceptance)
        accepted = attempts * acceptance
        revenue = accepted * price
        delivery_outlay = attempts * attempt_cost + support_per_cycle
        cash_margin = revenue - delivery_outlay
        cash += cash_margin
        expected_reuse_value = attempts * proposed_saving_per_attempt * 4
        authorized_simulation_allowance = min(100.0, max(0.0, cash_margin) * 0.5)
        adopt = (
            expected_reuse_value > construction_cost
            and authorized_simulation_allowance >= construction_cost
            and cash >= construction_cost
        )
        if adopt:
            cash -= construction_cost
            attempt_cost = max(0.1, attempt_cost - proposed_saving_per_attempt)
            proposed_saving_per_attempt *= diminishing
        cycles.append(
            {
                "cycle": cycle,
                "attempts_expected": attempts,
                "accepted_expected": accepted,
                "revenue_expected": revenue,
                "delivery_outlay_expected": delivery_outlay,
                "cash_margin_before_improvement_expected": cash_margin,
                "improvement_outlay_simulated": construction_cost if adopt else 0,
                "future_four_cycle_reuse_value_assumed": expected_reuse_value,
                "construction_adopted": adopt,
                "cash_balance_simulated": cash,
                "next_attempt_cost_assumed": attempt_cost,
                "stop_further_construction_reason": (
                    None if adopt else "Insufficient margin allocation or expected reuse value"
                ),
            }
        )
        if cash < 0:
            break
    return {
        "status": "SIMULATION_ONLY; no revenue collected or resources purchased",
        "parameters": {
            "demand": demand,
            "price": price,
            "acceptance": acceptance,
            "utilization": utilization,
            "diminishing_multiplier": diminishing,
            "initial_cash": 1000.0,
        },
        "cycles": cycles,
        "final_cash_simulated": cash,
        "cumulative_reinvestment_simulated": sum(
            row["improvement_outlay_simulated"] for row in cycles
        ),
    }


def run() -> dict:
    inputs = read("scenario_inputs.json")
    rate_rows = read("rate_matrix.json")["rates"]
    rates = {row["id"]: row for row in rate_rows}
    families = {row["id"]: row for row in read("family_matrix.json")["families"]}
    break_even = []
    for rate in rate_rows:
        loads = inputs["wage_only_loads"] if rate["cost_basis"] == "wage_only" else [1]
        for load, cost in itertools.product(
            loads, inputs["all_in_agent_cost_per_accepted_output_local_currency"]
        ):
            break_even.append(
                {
                    "rate_id": rate["id"],
                    "currency": rate["currency"],
                    "load_assumed": load,
                    "all_in_agent_cost_per_accepted_output_assumed": cost,
                    "human_break_even_minutes_per_accepted_output": (
                        60 * cost / (rate["rate_per_hour"] * load)
                    ),
                }
            )
    costs = []
    for rate_id in ["us_office_admin_compensation", "us_professional_compensation"]:
        for human, attention, other, qh, qa in itertools.product(
            inputs["human_minutes"],
            inputs["agent_attention_minutes"],
            inputs["other_agent_cost_per_attempt_local_currency"],
            inputs["human_acceptance_probability"],
            inputs["agent_acceptance_probability"],
        ):
            costs.append(
                {
                    "rate_id": rate_id,
                    "human_minutes_assumed": human,
                    "attention_minutes_assumed": attention,
                    "other_agent_cost_assumed": other,
                    "q_human_assumed": qh,
                    "q_agent_assumed": qa,
                    **delivery_cost(rates[rate_id]["rate_per_hour"], human, attention, other, qh, qa),
                }
            )
    supplied = inputs["supplied_us_scenario"]
    us_results = []
    for index, (eligibility, screen) in enumerate(
        zip(
            supplied["occupation_eligibility_share"],
            supplied["computer_mediated_task_share_within_eligible"],
            strict=True,
        )
    ):
        original = supplied["rounded_compensation_usd"] * eligibility * screen
        assert math.isclose(original, supplied["expected_result_usd"][index])
        updated = (
            inputs["updated_us_denominator"]["compensation_paid_usd"]
            * eligibility
            * screen
        )
        us_results.append(
            {
                "supplied_2025_usd": original,
                "updated_base_2025_usd": updated,
                "occupation_eligibility_assumed": eligibility,
                "computer_task_share_assumed": screen,
                "total_compensation_share_assumed": eligibility * screen,
                "2026_projection_scenarios_not_observations": [
                    {"growth_assumed": growth, "usd": updated * (1 + growth)}
                    for growth in inputs["projection_2026_assumed_growth"]
                ],
            }
        )
    simulations = [
        reinvestment_simulation(*values)
        for values in itertools.product(
            [10, 50, 100], [2, 5, 10], [0.7, 0.9, 1], [0.25, 0.5, 1], [0.25, 0.5, 0.8]
        )
    ]
    result = {
        "status": "MODELED_ECONOMICS; NO_NEW_HUMAN_TRIAL",
        "actual_agent_cost_per_accepted_output": None,
        "actual_full_system_employer_attention_minutes": None,
        "actual_customer_cash_savings": None,
        "actual_revenue": None,
        "actual_cash_margin": None,
        "empirical_human_advantage_ratio": None,
        "rates": len(rates),
        "families": len(families),
        "break_even": break_even,
        "delivery_sensitivity": costs,
        "delivery_sensitivity_summary": {
            "combinations": len(costs),
            "nonpositive_economic_value": sum(
                row["potential_economic_value_per_output"] <= 0 for row in costs
            ),
            "interpretation": "Unweighted scenarios, not probabilities or empirical frequencies.",
        },
        "us_scenarios": us_results,
        "bottom_up": bottom_up(inputs, rates, families),
        "construction_break_even": [
            {
                "full_construction_cost_assumed": construction,
                "saving_per_accepted_reuse_assumed": saving,
                "reuse_volume_break_even": math.ceil(construction / saving),
            }
            for construction, saving in itertools.product(
                inputs["improvement_cost_local_currency"],
                inputs["saving_per_accepted_reuse_local_currency"],
            )
        ],
        "simulation_sensitivity_summary": {
            "combinations": len(simulations),
            "with_any_reinvestment": sum(
                row["cumulative_reinvestment_simulated"] > 0 for row in simulations
            ),
            "final_cash_range": [
                min(row["final_cash_simulated"] for row in simulations),
                max(row["final_cash_simulated"] for row in simulations),
            ],
            "interpretation": "Eight-cycle expected-value simulations, not observations or forecasts.",
        },
        "reinvestment_simulations": simulations,
    }
    (ROOT / "economic_results.json").write_text(json.dumps(result, indent=2) + "\n")
    return result


if __name__ == "__main__":
    output = run()
    print(json.dumps({key: output[key] for key in [
        "status", "rates", "families", "delivery_sensitivity_summary",
        "simulation_sensitivity_summary",
    ]}, indent=2))
