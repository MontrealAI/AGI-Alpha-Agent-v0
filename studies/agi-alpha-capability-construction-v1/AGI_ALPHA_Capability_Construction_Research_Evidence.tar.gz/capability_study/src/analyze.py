# SPDX-License-Identifier: Apache-2.0
"""Fixed summaries; never alters or reruns recorded experiments."""
from __future__ import annotations

import json
import math
import random
import statistics
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def describe(values: list[float]) -> dict:
    if not values:
        return {
            "n": 0,
            "min": None,
            "median": None,
            "mean": None,
            "max": None,
            "p95_nearest_rank": None,
            "all": [],
        }
    ordered = sorted(values)
    return {
        "n": len(values),
        "min": min(values),
        "median": statistics.median(values),
        "mean": statistics.mean(values),
        "max": max(values),
        "p95_nearest_rank": ordered[math.ceil(len(values) * 0.95) - 1],
        "all": values,
    }


def wilson(a: int, n: int) -> list[float]:
    z = 1.959963984540054
    p = a / n
    d = 1 + z * z / n
    middle = (p + z * z / (2 * n)) / d
    width = z * math.sqrt((p * (1 - p) + z * z / (4 * n)) / n) / d
    return [max(0, middle - width), min(1, middle + width)]


def main() -> None:
    target = ROOT / "analysis"
    target.mkdir(exist_ok=True)
    summary_path = target / "SUMMARY.json"
    if summary_path.exists():
        raise FileExistsError("Preserve existing analysis; do not silently overwrite")

    def load(path: str) -> dict:
        return json.loads((ROOT / path).read_text())

    nonplanning = load("raw/portfolio/summary.json")["attempts"]
    planning = load("raw/planning/summary.json")
    planning_primary = [
        r for r in planning["receipts"] if r["id"].startswith("planning-")
    ]
    rows = []
    for row in nonplanning:
        rows.append(
            {
                "id": row["id"],
                "family": row["work_family"],
                "accepted": row["accepted"],
                "wall": row["delivery_wall_seconds"],
                "cpu": row["child_cpu_seconds"]
                + row["supervisor_and_oracle_cpu_seconds"],
                "boundary": "producer process + external oracle and export, excluding final receipt serialization",
            }
        )
    for row in planning_primary:
        rows.append(
            {
                "id": row["id"],
                "family": "planning-operations",
                "accepted": row["accepted"],
                "wall": row["outer_wall_seconds"],
                "cpu": row.get("cpu_seconds"),
                "boundary": "complete outer worker launch-to-exit; CPU excludes final receipt/exit tail",
            }
        )
    families = {}
    for family in sorted({r["family"] for r in rows}):
        chosen = [r for r in rows if r["family"] == family]
        families[family] = {
            "attempted": len(chosen),
            "accepted": sum(r["accepted"] for r in chosen),
            "wall_seconds": describe([r["wall"] for r in chosen]),
            "known_cpu_seconds": describe(
                [r["cpu"] for r in chosen if r["cpu"] is not None]
            ),
        }
    evidence = load("raw/evidence-mechanism/summary.json")

    def metric(row: dict) -> float:
        return row["child_cpu_seconds"] + row["supervisor_and_oracle_cpu_seconds"]

    pairs = [(metric(p["incremental"]), metric(p["full"])) for p in evidence["pairs"]]
    ratio = sum(p[0] for p in pairs) / sum(p[1] for p in pairs)
    rng = random.Random(2026102557)
    boot = []
    for _ in range(2000):
        sampled = [rng.choice(pairs) for _ in pairs]
        boot.append(sum(p[0] for p in sampled) / sum(p[1] for p in sampled))
    boot.sort()
    lineages = []
    for path in sorted((ROOT / "raw/evidence-mechanism").glob("*/output/lineage.json")):
        data = json.loads(path.read_text())
        if data["parent_brief_sha256"]:
            lineages.append({"attempt": path.parents[1].name, **data})
    scales = load("raw/scale/summary.json")
    scale_groups = {}
    for concurrency in (1, 2, 4):
        batches = [b for b in scales["batches"] if b["concurrency"] == concurrency]
        scale_groups[str(concurrency)] = {
            "accepted": sum(b["accepted"] for b in batches),
            "throughput_per_minute": describe(
                [b["accepted_per_minute"] for b in batches]
            ),
            "submission_latency_seconds": describe(
                [
                    r["submission_to_delivery_seconds"]
                    for b in batches
                    for r in b["rows"]
                ]
            ),
            "total_cpu_seconds": sum(b["batch_child_cpu_seconds"] for b in batches),
        }
    result = {
        "schema": "capability-construction-summary/v1",
        "primary_attempted": len(rows),
        "primary_accepted": sum(r["accepted"] for r in rows),
        "acceptance_wilson_95_descriptive": wilson(
            sum(r["accepted"] for r in rows), len(rows)
        ),
        "primary_wall_seconds": describe([r["wall"] for r in rows]),
        "families": families,
        "primary_rows": rows,
        "source_mechanism": {
            "attempts": evidence["count"],
            "accepted": evidence["accepted"],
            "incremental_over_full_cpu_ratio": ratio,
            "task_bootstrap_95": [boot[50], boot[1949]],
            "lineages": lineages,
            "policies": evidence["policies"],
            "unique_retained_module_sources": evidence[
                "distinct_retained_module_source_count"
            ],
        },
        "review": load("raw/review/summary.json"),
        "controls": load("raw/controls/summary.json"),
        "scale": scale_groups,
        "scale_ratio_c4_c1": scale_groups["4"]["throughput_per_minute"]["median"]
        / scale_groups["1"]["throughput_per_minute"]["median"],
        "complete_agent_money": None,
        "human_attention_minutes": None,
        "actual_revenue": None,
        "empirical_human_trial": "NOT_RUN",
        "human_market_comparison": "CONDITIONAL_MODEL",
        "full_economic_admission": "NOT_ESTABLISHED",
        "self_acceleration": "NOT_ESTABLISHED",
    }
    summary_path.write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            {
                "primary_attempted": len(rows),
                "primary_accepted": result["primary_accepted"],
                "source_cpu_ratio": ratio,
                "scale_ratio": result["scale_ratio_c4_c1"],
            }
        )
    )


if __name__ == "__main__":
    main()
