// SPDX-License-Identifier: Apache-2.0
import fs from 'node:fs';
import {challenge, adjudicate, validateEvidence} from './evidence.mjs';
const text = fs.readFileSync(0, 'utf8');
if (Buffer.byteLength(text) > 400000) throw Error('REVIEW_INPUT_BOUND');
const request = JSON.parse(text);
validateEvidence(request.input);
const criticisms = await challenge(request.input, request.brief);
const submitted = request.criticisms ?? criticisms;
if (!Array.isArray(submitted) || submitted.length > 100) throw Error('CRITICISM_BOUND');
const adjudication = await adjudicate(request.input, request.brief, submitted);
process.stdout.write(JSON.stringify({criticisms, adjudication}));
