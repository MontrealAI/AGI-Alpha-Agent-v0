// SPDX-License-Identifier: Apache-2.0
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath, pathToFileURL} from 'node:url';
import {createWorkbench} from '../upstream/examples/successor-workbench/engine.mjs';
import {parseBounded} from '../upstream/docs/assets/successor/engine.mjs';
import {evidenceAdapter, sha} from './evidence.mjs';

const [briefFile, outputDirectory, sourceHash, parentDirectory = '', mode = 'incremental'] = process.argv.slice(2);
if (!briefFile || !outputDirectory || !/^[a-f0-9]{64}$/.test(sourceHash || '') || !['incremental', 'full'].includes(mode)) throw Error('ARGUMENTS');
if (fs.existsSync(outputDirectory)) throw Error('OUTPUT_EXISTS');
const installedDirectory = path.dirname(fileURLToPath(import.meta.url));
const hash = crypto.createHash('sha256');
for (const name of fs.readdirSync(installedDirectory).filter(x => x.endsWith('.mjs')).sort()) {
  hash.update(name); hash.update(Buffer.from([0])); hash.update(fs.readFileSync(path.join(installedDirectory, name)));
}
if (hash.digest('hex') !== sourceHash) throw Error('INSTALLED_SOURCE_MISMATCH');
const toolSource = fs.readFileSync(path.join(installedDirectory, 'evidence.mjs'), 'utf8');
const spec = parseBounded(fs.readFileSync(briefFile, 'utf8'));
let parent = null, capability = null;
let factory = evidenceAdapter;
if (parentDirectory) {
  const previousSpec = parseBounded(fs.readFileSync(path.join(parentDirectory, 'mission.json'), 'utf8'));
  const rawBrief = fs.readFileSync(path.join(parentDirectory, 'brief.json'), 'utf8');
  const retainedPath = path.join(parentDirectory, 'repair-tool.mjs');
  const retained = fs.readFileSync(retainedPath, 'utf8');
  if (retained !== toolSource || fs.lstatSync(retainedPath).isSymbolicLink()) throw Error('PARENT_TOOL_SOURCE_MISMATCH');
  factory = (await import(pathToFileURL(path.resolve(retainedPath)))).evidenceAdapter;
  parent = {family:previousSpec.family, input:previousSpec.inputs, brief:parseBounded(rawBrief),
    raw_brief_sha256:await sha(rawBrief), tool_sha256:await sha(retained)};
  capability = parseBounded(fs.readFileSync(path.join(parentDirectory, 'retained-capability.json'), 'utf8'));
}
const workbench = createWorkbench(['evidence-brief', 'evidence-deck'].map(family => factory({family, sourceHash, parent, capability, mode, toolSource})));
const checkpoints = [], start = performance.now(), cpu = process.cpuUsage();
const pack = await workbench.run(spec, {sourceHash, onProgress:phase => checkpoints.push(phase)});
await workbench.inspectPack(pack);
fs.mkdirSync(outputDirectory, {recursive:true});
fs.writeFileSync(path.join(outputDirectory, 'mission.json'), JSON.stringify(spec, null, 2) + '\n');
fs.writeFileSync(path.join(outputDirectory, 'pack.json'), JSON.stringify(pack, null, 2) + '\n');
for (const file of pack.result.artifacts) fs.writeFileSync(path.join(outputDirectory, file.name), file.content);
const delta = process.cpuUsage(cpu);
fs.writeFileSync(path.join(outputDirectory, 'worker-telemetry.json'), JSON.stringify({schema:'bounded-worker-telemetry/v1',
  worker_wall_seconds:(performance.now()-start)/1000, worker_cpu_seconds:(delta.user+delta.system)/1e6,
  boundary:'Before workbench.run through artifact writes; receipt serialization tail excluded. Outer supervisor records whole process.',
  checkpoints, source_sha256:sourceHash, input_sha256:await sha(spec), task_model_calls:0, provider_cost_observed:null, human_attention_minutes:null}, null, 2) + '\n');
