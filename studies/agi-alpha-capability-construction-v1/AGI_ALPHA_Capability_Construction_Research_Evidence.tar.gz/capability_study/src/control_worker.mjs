// SPDX-License-Identifier: Apache-2.0
import fs from 'node:fs';
import {createWorkbench} from '../upstream/examples/successor-workbench/engine.mjs';
import {evidenceAdapter} from './evidence.mjs';
const request = JSON.parse(fs.readFileSync(0, 'utf8'));
const sourceHash = request.sourceHash;
const stop = new AbortController();
let checkpoints = 0;
const workbench = createWorkbench(['evidence-brief', 'evidence-deck'].map(family => evidenceAdapter({family, sourceHash})));
if (request.control === 'pre-stop') stop.abort();
try {
  const pack = await workbench.run(request.spec, {sourceHash, signal:stop.signal,
    clock:request.control === 'time-budget' ? (() => { let tick = 0; return () => tick++ * 70000; })() : undefined,
    onCheckpoint:async () => { checkpoints++; if (request.control === 'interrupt' && checkpoints === 3) throw Error('INJECTED_INTERRUPTION'); }});
  process.stdout.write(JSON.stringify({completed:true, checkpoints, pack}));
} catch (error) {
  process.stdout.write(JSON.stringify({completed:false, checkpoints, error:error.message}));
}
