# SPDX-License-Identifier: Apache-2.0
"""Predeclared source-aware repair, transfer and bounded discovery diagnostics."""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import random
import statistics
import time
from pathlib import Path

from generate_portfolio import ROOT, evidence_input, spec
from run_portfolio import execute, frozen_check, save


def task(seed: int, identity: str, level: int) -> dict:
    inputs = evidence_input(random.Random(seed), identity, level, "evidence-brief")
    return {
        "id": identity,
        "work_family": "source-synthesis",
        "complexity": ["low", "medium", "high"][level],
        "brief": "Deliver a source-backed packet covering the employer's explicit required passages.",
        "spec": spec("evidence-brief", identity, inputs, "public"),
    }


def changed(parent: dict, identity: str, variation: int) -> dict:
    item = copy.deepcopy(parent)
    item["id"] = identity
    inputs = item["spec"]["inputs"]
    item["spec"]["name"] = identity
    inputs["id"] = identity
    inputs["title"] = "Updated evidence requirements · " + identity
    registry = {
        p["id"]: p
        for p in json.loads((ROOT / "sources/source_packets.json").read_text())
    }
    selected = next(c for c in inputs["claims"] if c["required"])
    source = next(
        s for s in inputs["source_packets"] if s["id"] == selected["source_id"]
    )
    fresh = next(
        (
            text
            for text in registry[source["id"]]["passages"]
            if text not in source["text"]
        ),
        None,
    )
    if fresh is None:
        raise ValueError("No independent extra source passage available")
    source["text"] += "\n\n" + fresh
    source["sha256"] = hashlib.sha256(source["text"].encode()).hexdigest()
    selected["quote"] = fresh
    if variation % 3 == 1:
        optional = next((c for c in inputs["claims"] if not c["required"]), None)
        if optional:
            optional["required"] = True
    elif variation % 3 == 2:
        candidates = [
            c for c in inputs["claims"] if c["required"] and c["id"] != selected["id"]
        ]
        if candidates:
            candidates[-1]["section"] = "New employer reporting requirement"
    item["brief"] = (
        "The employer changed the evidence requirement. Use the actual preceding deliverable, repair dependent claims and preserve valid content. Source packets contain only real pinned passages."
    )
    return item


def cpu(row: dict) -> float:
    return row["child_cpu_seconds"] + row["supervisor_and_oracle_cpu_seconds"]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--mode", choices=("development", "confirmation"), required=True
    )
    args = parser.parse_args()
    if args.mode == "confirmation":
        frozen_check()
    args.output.mkdir(parents=True, exist_ok=False)
    count = 12 if args.mode == "confirmation" else 2
    rows = []
    pairs = []
    policies = []
    active_policy = {
        "preferred_method": "full",
        "basis": "Strong installed full-compilation specialist; no inherited efficiency claim",
    }
    beginning = time.perf_counter()
    for index in range(count):
        # Identical four-case complexity pattern in each cycle prevents easier-later claims.
        level = (0, 1, 2, 1)[index % 4]
        parent = task(
            args.seed + 100 * index, f"evidence-parent-{index + 1:02d}", level
        )
        parent_dir = args.output / parent["id"]
        rows.append(execute(parent, parent_dir, mode="full"))
        next_task = changed(parent, f"evidence-change-{index + 1:02d}", index)
        order = ["full", "incremental"]
        random.Random(args.seed + index).shuffle(order)
        pair = {}
        for method in order:
            destination = args.output / (next_task["id"] + "-" + method)
            row = execute(
                next_task,
                destination,
                parent_dir / "output" if method == "incremental" else None,
                method,
            )
            row["mechanism_arm"] = method
            rows.append(row)
            pair[method] = row
        pair["case"] = index
        pair["complexity"] = parent["complexity"]
        pairs.append(pair)
        transfer = copy.deepcopy(next_task)
        transfer["id"] = f"presentation-transfer-{index + 1:02d}"
        transfer["work_family"] = "documents-presentations"
        transfer["spec"]["family"] = "evidence-deck"
        transfer["spec"]["name"] = transfer["id"]
        transfer["spec"]["inputs"]["id"] = transfer["id"]
        transfer["spec"]["inputs"]["title"] = "Executive handover · " + transfer["id"]
        transfer["brief"] = (
            "Apply the retained source-aware method to a presentation handover using the verified changed brief. This is a cross-artifact transfer, not an independent occupational sample."
        )
        rows.append(
            execute(
                transfer,
                args.output / transfer["id"],
                args.output / (next_task["id"] + "-incremental") / "output",
            )
        )
        if index % 4 == 3:
            cycle = index // 4 + 1
            current = pairs[-4:]
            ratios = [cpu(p["incremental"]) / cpu(p["full"]) for p in current]
            all_valid = all(
                p[m]["accepted"] for p in current for m in ("full", "incremental")
            )
            # Conservative fixed small-sample gate; no post-result relaxed threshold.
            admit = all_valid and all(r < 0.95 for r in ratios)
            active_policy = {
                "schema": "evidence-method-policy/v1",
                "cycle": cycle,
                "preferred_method": "incremental" if admit else "full",
                "candidate_ratios": ratios,
                "admission_rule": "Every one of four paired delivery-CPU ratios below .95, no acceptance loss; descriptive finite gate, not population confidence",
                "admitted_compute_improvement": admit,
                "full_economic_admission": False,
                "unknown_costs": [
                    "initial code authorship",
                    "employer attention",
                    "deployment",
                    "maintenance",
                    "infrastructure price",
                ],
                "next_validation_seed": args.seed + 50000 + cycle,
                "no_additional_exploration": True,
                "stop_reason": "Four-pair search budget exhausted; always retain strongest feasible full compiler",
            }
            policy_path = args.output / f"policy-cycle-{cycle}.json"
            save(policy_path, active_policy)
            policy_hash = hashlib.sha256(policy_path.read_bytes()).hexdigest()
            # New confirmation input is constructed only AFTER the policy bytes are frozen.
            fresh_parent = task(
                active_policy["next_validation_seed"], f"policy-parent-{cycle}", 1
            )
            fresh_dir = args.output / fresh_parent["id"]
            rows.append(execute(fresh_parent, fresh_dir, mode="full"))
            fresh = changed(fresh_parent, f"policy-validation-{cycle}", cycle)
            method = active_policy["preferred_method"]
            validation = execute(
                fresh,
                args.output / fresh["id"],
                fresh_dir / "output" if method == "incremental" else None,
                method,
            )
            rows.append(validation)
            policies.append(
                {
                    "policy": active_policy,
                    "policy_sha256_before_validation": policy_hash,
                    "validation": validation,
                    "discovery_cpu_seconds": sum(
                        cpu(p[m]) for p in current for m in ("full", "incremental")
                    ),
                    "median_discovery_ratio": statistics.median(ratios),
                    "construction_account_includes_all_candidates": True,
                }
            )
        save(
            args.output / "summary.json",
            {
                "mode": args.mode,
                "seed": args.seed,
                "attempts": rows,
                "pairs": pairs,
                "policies": policies,
                "count": len(rows),
                "accepted": sum(r["accepted"] for r in rows),
                "elapsed_seconds": time.perf_counter() - beginning,
                "new_method_count": 1,
                "distinct_retained_module_source_count": 1,
                "self_acceleration": "NOT_ESTABLISHED: no three successive positive full-cost-normalized capability gains; complete costs unmeasured",
            },
        )
        print(
            json.dumps(
                {
                    "case": index + 1,
                    "accepted_attempts": sum(r["accepted"] for r in rows),
                    "attempts": len(rows),
                }
            ),
            flush=True,
        )


if __name__ == "__main__":
    main()
