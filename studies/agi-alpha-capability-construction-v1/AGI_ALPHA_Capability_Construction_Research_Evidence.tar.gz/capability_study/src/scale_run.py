# SPDX-License-Identifier: Apache-2.0
"""Finite local load; each task's CPU is measured in an isolated process."""
from __future__ import annotations

import argparse
import concurrent.futures
import json
import random
import resource
import subprocess
import sys
import time
from pathlib import Path

from generate_portfolio import ROOT, generate
from run_portfolio import frozen_check, save


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--mode", choices=("development", "confirmation"), required=True
    )
    args = parser.parse_args()
    if args.mode == "confirmation":
        frozen_check()
    args.output.mkdir(parents=True, exist_ok=False)
    tasks = [t for t in generate(args.seed) if t["id"].endswith(("-01", "-05"))]
    paths = []
    for task in tasks:
        path = args.output / (task["id"] + ".json")
        save(path, task)
        paths.append(path)
    cases = (
        [(c, r) for c in (1, 2, 4) for r in range(3)]
        if args.mode == "confirmation"
        else [(2, 0)]
    )
    random.Random(args.seed + 555).shuffle(cases)
    batches = []
    for concurrency, repeat in cases:
        batch = args.output / f"c{concurrency}-r{repeat}"
        batch.mkdir()
        submission = time.perf_counter()
        cpu0 = resource.getrusage(resource.RUSAGE_CHILDREN)

        def job(path: Path) -> dict:
            entered = time.perf_counter()
            out = batch / path.stem
            try:
                run = subprocess.run(
                    [
                        sys.executable,
                        str(ROOT / "src/job_process.py"),
                        str(path),
                        str(out),
                    ],
                    capture_output=True,
                    text=True,
                    timeout=75,
                )
            except subprocess.TimeoutExpired as error:
                return {
                    "id": path.stem,
                    "accepted": False,
                    "exit": None,
                    "queue_seconds": entered - submission,
                    "service_outer_seconds": time.perf_counter() - entered,
                    "submission_to_delivery_seconds": time.perf_counter() - submission,
                    "stderr": str(error),
                    "receipt": None,
                    "residual_descendant_cost": None,
                    "failure": "Timeout; no safe replay or zero-cost inference",
                }
            finished = time.perf_counter()
            receipt = (
                json.loads((out / "receipt.json").read_text())
                if (out / "receipt.json").exists()
                else None
            )
            return {
                "id": path.stem,
                "accepted": bool(receipt and receipt["accepted"]),
                "exit": run.returncode,
                "queue_seconds": entered - submission,
                "service_outer_seconds": finished - entered,
                "submission_to_delivery_seconds": finished - submission,
                "stderr": run.stderr,
                "receipt": receipt,
            }

        with concurrent.futures.ThreadPoolExecutor(max_workers=concurrency) as pool:
            rows = list(pool.map(job, paths))
        duration = time.perf_counter() - submission
        cpu1 = resource.getrusage(resource.RUSAGE_CHILDREN)
        record = {
            "concurrency": concurrency,
            "repeat": repeat,
            "jobs": len(rows),
            "accepted": sum(r["accepted"] for r in rows),
            "batch_wall_seconds": duration,
            "accepted_per_minute": sum(r["accepted"] for r in rows) * 60 / duration,
            "batch_child_cpu_seconds": cpu1.ru_utime
            + cpu1.ru_stime
            - cpu0.ru_utime
            - cpu0.ru_stime,
            "initial_backlog": max(0, len(rows) - concurrency),
            "rows": rows,
            "scope": "Repeated mixed six-family inputs; planning/native solver excluded; finite foreground local processes",
        }
        save(batch / "batch.json", record)
        batches.append(record)
        save(
            args.output / "summary.json",
            {
                "mode": args.mode,
                "batches": batches,
                "distinct_inputs": len(paths),
                "attempts": sum(b["jobs"] for b in batches),
                "accepted": sum(b["accepted"] for b in batches),
                "human_supervision_minutes": None,
                "host_price": None,
                "continuous_service": False,
            },
        )
        print(
            json.dumps(
                {
                    k: record[k]
                    for k in (
                        "concurrency",
                        "repeat",
                        "accepted",
                        "batch_wall_seconds",
                        "accepted_per_minute",
                    )
                }
            ),
            flush=True,
        )


if __name__ == "__main__":
    main()
