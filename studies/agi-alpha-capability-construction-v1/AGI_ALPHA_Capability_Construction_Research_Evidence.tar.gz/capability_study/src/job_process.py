# SPDX-License-Identifier: Apache-2.0
"""One isolated delivery process for measured load tests."""
import json
import sys
from pathlib import Path

from run_portfolio import execute

if __name__ == "__main__":
    execute(json.loads(Path(sys.argv[1]).read_text()), Path(sys.argv[2]))
