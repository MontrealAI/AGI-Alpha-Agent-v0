# SPDX-License-Identifier: Apache-2.0
"""Finite negative/control cases, never an authority or remote-deployment test."""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import resource
import shutil
import subprocess
import time
from pathlib import Path

from generate_portfolio import ROOT, generate
from run_portfolio import execute, frozen_check, save, source_hash


def file_hashes(directory: Path) -> dict:
    return {
        str(p.relative_to(directory)): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in directory.rglob("*")
        if p.is_file()
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--mode", choices=("development", "confirmation"), required=True
    )
    args = parser.parse_args()
    if args.mode == "confirmation":
        frozen_check()
    args.output.mkdir(parents=True, exist_ok=False)
    task = next(
        t for t in generate(args.seed) if t["work_family"] == "source-synthesis"
    )
    rows = []
    started = time.perf_counter()
    cpu0 = resource.getrusage(resource.RUSAGE_CHILDREN)
    for control, expected in (
        ("pre-stop", "CANCELLED"),
        ("interrupt", "INJECTED_INTERRUPTION"),
        ("time-budget", "TIME_BUDGET_EXCEEDED"),
    ):
        before = time.perf_counter()
        request = {
            "spec": task["spec"],
            "sourceHash": source_hash(),
            "control": control,
        }
        process = subprocess.run(
            ["node", str(ROOT / "src/control_worker.mjs")],
            input=json.dumps(request),
            capture_output=True,
            text=True,
            timeout=10,
        )
        result = json.loads(process.stdout)
        row = {
            "case": control,
            "expected": expected,
            "observed": result,
            "passed": not result["completed"] and result["error"] == expected,
            "seconds": time.perf_counter() - before,
        }
        save(args.output / f"{control}.json", row)
        rows.append(row)
    parent = args.output / "recovered-delivery"
    delivered = execute(task, parent, mode="full")
    rows.append(
        {
            "case": "explicit-restart-after-interruption",
            "passed": delivered["accepted"],
            "scope": "New pure operation from supplied input; not continuation of a program counter or an external side effect",
            "receipt": delivered,
        }
    )
    preserved = file_hashes(parent)
    kinds = {
        "arbitrary-software": (
            "reliability",
            {
                "source": "export function payment() { return 0; }",
                "low": 0,
                "high": 1,
                "cases": [0, 1],
            },
        ),
        "unstructured-summary": (
            "evidence-brief",
            {"book": "A book without a supplied claim inventory"},
        ),
        "financial-action": ("fund-transfer", {}),
        "physical-action": ("manufacture-part", {}),
        "private-login": ("browser-login", {}),
        "clinical-prediction": ("clinical-prediction", {}),
    }
    for label, (family, inputs) in kinds.items():
        invalid = copy.deepcopy(task)
        invalid["id"] = label
        invalid["spec"]["family"] = family
        invalid["spec"]["inputs"] = inputs
        row = execute(invalid, args.output / label)
        rows.append(
            {
                "case": label,
                "passed": not row["accepted"] and row["error"] is not None,
                "delivery": False,
                "receipt": row,
            }
        )
    for label in ("restricted-data", "input-budget"):
        invalid = copy.deepcopy(task)
        invalid["id"] = label
        if label == "restricted-data":
            invalid["spec"]["rights"]["dataClass"] = "private-personal"
        else:
            invalid["spec"]["inputs"]["source_packets"] *= 21
        row = execute(invalid, args.output / label)
        rows.append(
            {
                "case": label,
                "passed": not row["accepted"] and row["error"] is not None,
                "delivery": False,
                "receipt": row,
            }
        )
    corrupt = args.output / "corrupt-parent-copy"
    shutil.copytree(parent / "output", corrupt)
    with (corrupt / "repair-tool.mjs").open("a") as stream:
        stream.write("\n// injected source corruption\n")
    row = execute(task, args.output / "corrupt-source-refusal", corrupt)
    rows.append(
        {
            "case": "corrupt-retained-code-refused",
            "passed": not row["accepted"] and row["error"] is not None,
            "receipt": row,
        }
    )
    command = [
        "node",
        str(ROOT / "src/worker.mjs"),
        str(parent / "brief.json"),
        str(args.output / "wrong-source-output"),
        "0" * 64,
    ]
    refusal = subprocess.run(command, capture_output=True, text=True, timeout=10)
    rows.append(
        {
            "case": "source-identity-refusal",
            "passed": refusal.returncode != 0
            and "INSTALLED_SOURCE_MISMATCH" in refusal.stderr,
        }
    )
    command = [
        "node",
        str(ROOT / "src/worker.mjs"),
        str(parent / "brief.json"),
        str(parent / "output"),
        source_hash(),
    ]
    refusal = subprocess.run(command, capture_output=True, text=True, timeout=10)
    rows.append(
        {
            "case": "immutable-output-refusal",
            "passed": refusal.returncode != 0 and preserved == file_hashes(parent),
        }
    )
    pointer = args.output / "current-delivery.json"
    save(
        pointer,
        {
            "directory": "corrupt-parent-copy",
            "scope": "Research-local selection only; not an authorized executor state",
        },
    )
    save(
        pointer,
        {
            "directory": "recovered-delivery/output",
            "scope": "Research-local rollback to preserved parent",
        },
    )
    rows.append(
        {
            "case": "local-artifact-rollback",
            "passed": preserved == file_hashes(parent)
            and json.loads(pointer.read_text())["directory"]
            == "recovered-delivery/output",
            "scope": "Restores a local selection pointer and verifies unchanged parent bytes; not operational or transactional rollback",
        }
    )
    cpu1 = resource.getrusage(resource.RUSAGE_CHILDREN)
    save(
        args.output / "summary.json",
        {
            "mode": args.mode,
            "cases": rows,
            "count": len(rows),
            "passed": sum(r["passed"] for r in rows),
            "wall_seconds": time.perf_counter() - started,
            "child_cpu_seconds": cpu1.ru_utime
            + cpu1.ru_stime
            - cpu0.ru_utime
            - cpu0.ru_stime,
            "monetary_spend_enforcement": "NOT_RUN: no spend-enabled route",
            "browser_approved_executor": "NOT_RUN: existing approved operator home was not supplied; no credentials created",
            "continuous_operation": False,
        },
    )
    print(json.dumps({"count": len(rows), "passed": sum(r["passed"] for r in rows)}))


if __name__ == "__main__":
    main()
