# SPDX-License-Identifier: Apache-2.0
"""Whole local delivery accounting, including independent acceptance and failed attempts."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import resource
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "evaluation"))
from native_oracle import accept_native  # noqa: E402
from evidence_oracle import accept_evidence  # noqa: E402
from generate_portfolio import generate  # noqa: E402


def save(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def source_hash() -> str:
    paths = sorted((ROOT / "src").glob("*.mjs"))
    return hashlib.sha256(
        b"".join(p.name.encode() + b"\0" + p.read_bytes() for p in paths)
    ).hexdigest()


def frozen_check() -> dict:
    value = json.loads((ROOT / "protocol/FREEZE.json").read_text())
    for entry in value["files"]:
        path = ROOT / entry["path"]
        if hashlib.sha256(path.read_bytes()).hexdigest() != entry["sha256"]:
            raise ValueError("Frozen source changed: " + entry["path"])
    return value


def execute(
    task: dict, out: Path, parent: Path | None = None, mode: str = "incremental"
) -> dict:
    out.mkdir(parents=True, exist_ok=False)
    save(out / "task.json", task)
    save(out / "brief.json", task["spec"])
    usage0 = resource.getrusage(resource.RUSAGE_CHILDREN)
    own0 = time.process_time()
    start = time.perf_counter()
    stamp = datetime.now(timezone.utc).isoformat()
    command = [
        "node",
        str(ROOT / "src/worker.mjs"),
        str(out / "brief.json"),
        str(out / "output"),
        source_hash(),
        str(parent) if parent else "",
        mode,
    ]
    error = None
    accepted = False
    acceptance = None
    result = None
    execution_seconds = None
    try:
        environment = {
            k: v
            for k, v in os.environ.items()
            if k in {"PATH", "SYSTEMROOT", "WINDIR", "TMPDIR"}
        }
        process = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=65,
            env=environment,
            check=False,
        )
        execution_seconds = time.perf_counter() - start
        (out / "stdout.txt").write_text(process.stdout)
        (out / "stderr.txt").write_text(process.stderr)
        if process.returncode:
            raise RuntimeError(f"worker exit {process.returncode}")
        result = json.loads((out / "output/pack.json").read_text())
        if task["spec"]["family"].startswith("evidence-"):
            parent_pack = (
                json.loads((parent / "pack.json").read_text()) if parent else None
            )
            acceptance = accept_evidence(task["spec"], result, parent_pack)
        else:
            acceptance = accept_native(task["spec"], result)
        accepted = acceptance["accepted"]
        save(out / "acceptance.json", acceptance)
    except Exception as exc:
        error = {"type": type(exc).__name__, "message": str(exc)}
    usage1 = resource.getrusage(resource.RUSAGE_CHILDREN)
    row = {
        "id": task["id"],
        "work_family": task["work_family"],
        "complexity": task["complexity"],
        "started_at": stamp,
        "accepted": accepted,
        "error": error,
        "attempt": 1,
        "delivery_wall_seconds": time.perf_counter() - start,
        "process_wall_seconds": execution_seconds,
        "child_cpu_seconds": usage1.ru_utime
        + usage1.ru_stime
        - usage0.ru_utime
        - usage0.ru_stime,
        "supervisor_and_oracle_cpu_seconds": time.process_time() - own0,
        "task_model_calls": 0,
        "human_attention_minutes": None,
        "monetary_cost": None,
        "source_sha256": source_hash(),
        "acceptance_checks": acceptance.get("checks", None) if acceptance else None,
        "scope": "Complete local producer process plus independent acceptance, export and file I/O through receipt creation; receipt serialization tail excluded. Authoring/setup/upstream maintenance and employer attention are separate unknown costs.",
    }
    save(out / "receipt.json", row)
    return row


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--mode", choices=["development", "confirmation"], required=True
    )
    parser.add_argument("--limit", type=int)
    args = parser.parse_args()
    if args.mode == "confirmation":
        frozen_check()
        if args.limit is not None:
            raise ValueError("Cannot trim confirmation portfolio")
    tasks = generate(args.seed)
    if args.limit is not None:
        tasks = tasks[: args.limit]
    args.output.mkdir(parents=True, exist_ok=False)
    rows = []
    for task in tasks:
        row = execute(task, args.output / task["id"])
        rows.append(row)
        save(
            args.output / "summary.json",
            {
                "mode": args.mode,
                "seed": args.seed,
                "attempts": rows,
                "count": len(rows),
                "accepted": sum(x["accepted"] for x in rows),
            },
        )
        print(
            json.dumps(
                {
                    "id": row["id"],
                    "accepted": row["accepted"],
                    "seconds": row["delivery_wall_seconds"],
                    "error": row["error"],
                }
            ),
            flush=True,
        )


if __name__ == "__main__":
    main()
