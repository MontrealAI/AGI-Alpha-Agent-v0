# SPDX-License-Identifier: Apache-2.0
"""Fresh, controlled input generation. Never executes a producer or sees its outputs."""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import random
from pathlib import Path
from urllib.parse import quote

ROOT = Path(__file__).resolve().parents[1]
GROUPS = (
    "Research",
    "Documentation",
    "Software",
    "Verification",
    "Operations",
    "=Public label",
)


def spec(family: str, name: str, inputs: dict, data_class: str = "synthetic") -> dict:
    return {
        "schema": "successor-workbench/v1",
        "family": family,
        "name": name[:64],
        "language": "en",
        "owner": "public-research-study",
        "rights": {
            "dataClass": data_class,
            "source": "Shareable frozen study materials",
            "license": "Apache-2.0",
        },
        "reviewMinutes": 10,
        "inputs": inputs,
    }


def evidence_input(
    rng: random.Random, identity: str, complexity: int, family: str
) -> dict:
    registry = json.loads((ROOT / "sources/source_packets.json").read_text())
    selected = rng.sample(registry, 2 + complexity)
    sources = []
    claims = []
    for source in selected:
        passages = rng.sample(
            source["passages"], min(2 + complexity, len(source["passages"]))
        )
        # The source packet is a documented excerpt, not a claim to have fetched the whole source at task time.
        text = "\n\n".join(passages)
        sources.append(
            {
                "id": source["id"],
                "url": source["url"],
                "text": text,
                "sha256": hashlib.sha256(text.encode()).hexdigest(),
            }
        )
        for index, passage in enumerate(passages):
            claims.append(
                {
                    "id": f"{source['id']}-p{index}",
                    "source_id": source["id"],
                    "quote": passage,
                    "required": index != len(passages) - 1 or complexity == 0,
                    "section": source["title"],
                }
            )
    rng.shuffle(claims)
    return {
        "id": identity,
        "title": (
            "Publication evidence brief"
            if family == "evidence-brief"
            else "Operating constraints presentation"
        )
        + f" · {identity}",
        "source_packets": sources,
        "claims": claims,
    }


def generate(seed: int) -> list[dict]:
    rng = random.Random(seed)
    tasks = []
    for index in range(6):
        level = index // 2
        size = [12, 80, 400][level]
        for broad in (
            "software-testing",
            "structured-analysis",
            "source-synthesis",
            "documents-presentations",
            "scientific-computation",
            "web-documentation",
        ):
            identity = f"{broad}-{index + 1:02d}"
            if broad == "software-testing" and index % 2 == 0:
                low = rng.randint(-500, 50)
                high = low + rng.randint(1, 80)
                lo_op, hi_op = rng.choice((("<", "<"), ("<=", "<"), ("<", "<=")))
                inputs = {
                    "source": f"export function contains(value, low, high) {{ return low {lo_op} value && value {hi_op} high; }}",
                    "low": low,
                    "high": high,
                    "cases": [rng.randint(low - 10, high + 10) for _ in range(size)],
                }
                native = "reliability"
                brief = "Repair the supplied closed-interval utility, deliver an applicable patch and executable regression checks."
            elif broad == "software-testing":
                inputs = {
                    "values": [rng.randint(-size, size) for _ in range(size * 3)],
                    "repetitions": 5,
                    "repeats": 20,
                }
                native = "performance"
                brief = "Deliver a correct sorted-unique utility and a comparison of two legitimate standard-library approaches on these inputs."
            elif broad == "structured-analysis":
                buffer = io.StringIO(newline="")
                writer = csv.writer(buffer, lineterminator="\n")
                writer.writerow(("group", "amount"))
                writer.writerows(
                    (rng.choice(GROUPS[: 3 + level]), rng.randint(-50, 500))
                    for _ in range(size)
                )
                inputs = {
                    "csv": buffer.getvalue(),
                    "unit": "declared synthetic project units",
                }
                native = "public-data"
                brief = "Produce a reconciled descriptive report by project group, with exact counts, totals and range and a safe reusable CSV."
            elif broad in ("source-synthesis", "documents-presentations"):
                native = (
                    "evidence-brief" if broad == "source-synthesis" else "evidence-deck"
                )
                inputs = evidence_input(rng, identity, level, native)
                brief = "Compile the explicitly requested passages from the frozen public source packets into a usable cited brief and presentation, preserving source and scope."
            elif broad == "scientific-computation":
                # Exact quadrature report, not a free-form scientific replication claim.
                inputs = {
                    "coefficients": [rng.randint(-6, 6) for _ in range(3 + level)],
                    "lower": 0,
                    "upper": rng.randint(2, 6),
                    "steps": [12, 24, 48][level],
                    "tolerancePpm": 100000,
                }
                native = "numerical"
                brief = "Reproduce the supplied polynomial integral with exact arithmetic, compare quadrature methods, and truthfully flag tolerance failures."
            else:
                blocks = []
                for counter in range(2 + level * 3):
                    operation = rng.choice(("url-encode", "url-decode", "utf8-bytes"))
                    text = rng.choice(
                        ("hello world", "Montréal", "A&B / C", "Ω field", "100% done")
                    )
                    if operation == "url-encode":
                        actual = quote(text, safe="~()*!.'-")
                    elif operation == "url-decode":
                        actual = text
                        text = quote(text, safe="~()*!.'-")
                    else:
                        actual = str(len(text.encode()))
                    expected = actual if counter % 2 else "incorrect-example"
                    blocks.append(
                        "```successor-example\n"
                        + json.dumps(
                            {
                                "operation": operation,
                                "input": text,
                                "expected": expected,
                            },
                            ensure_ascii=False,
                        )
                        + "\n```"
                    )
                inputs = {
                    "markdown": f"# Client helper reference {identity}\n\n"
                    + "\n\n".join(blocks)
                    + "\n"
                }
                native = "documentation"
                brief = "Execute every bounded SDK example, correct inaccurate expected values, retain originals and deliver a corrected reference."
            tasks.append(
                {
                    "id": identity,
                    "work_family": broad,
                    "complexity": ("low", "medium", "high")[level],
                    "brief": brief,
                    "spec": spec(
                        native,
                        identity,
                        inputs,
                        (
                            "public"
                            if broad in ("source-synthesis", "documents-presentations")
                            else "synthetic"
                        ),
                    ),
                }
            )
    rng.shuffle(tasks)
    return tasks


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    tasks = generate(args.seed)
    for task in tasks:
        (args.output / f"{task['id']}.json").write_text(
            json.dumps(task, ensure_ascii=False, indent=2) + "\n"
        )
    (args.output / "INDEX.json").write_text(
        json.dumps(
            {"seed": args.seed, "count": len(tasks), "order": [x["id"] for x in tasks]},
            indent=2,
        )
        + "\n"
    )


if __name__ == "__main__":
    main()
