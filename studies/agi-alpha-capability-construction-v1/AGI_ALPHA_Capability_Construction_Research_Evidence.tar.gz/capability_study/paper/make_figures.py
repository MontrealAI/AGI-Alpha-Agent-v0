#!/usr/bin/env python3
"""Publication figures from immutable confirmation records; no new experiment."""

import csv
import hashlib
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "figures"
OUT.mkdir(exist_ok=True)
S = json.loads((ROOT / "analysis/SUMMARY.json").read_text())
P = json.loads((ROOT / "analysis/planning.json").read_text())
NAVY = "#13263D"
TEAL = "#087F8C"
AMBER = "#A05A16"
GREY = "#556575"
PALE = "#F0F5F7"
plt.rcParams.update(
    {
        "font.family": "DejaVu Sans",
        "font.size": 9,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.labelcolor": NAVY,
        "text.color": NAVY,
        "axes.edgecolor": "#CDD6DE",
        "xtick.color": GREY,
        "ytick.color": GREY,
        "svg.fonttype": "none",
        "pdf.fonttype": 42,
    }
)


def save(fig, name):
    for ext in ("pdf", "svg", "png"):
        fig.savefig(
            OUT / f"{name}.{ext}",
            bbox_inches="tight",
            dpi=180,
            metadata={"Creator": "AGI ALPHA reproducible figure script"},
        )
    plt.close(fig)


def card(ax, x, y, title, body, accent=TEAL):
    ax.add_patch(
        FancyBboxPatch(
            (x, y),
            0.425,
            0.30,
            boxstyle="round,pad=0.014,rounding_size=0.015",
            facecolor=PALE,
            edgecolor="#D1DCE3",
            linewidth=0.9,
        )
    )
    ax.plot([x + 0.02, x + 0.02], [y + 0.04, y + 0.26], color=accent, lw=3)
    ax.text(x + 0.043, y + 0.245, title, fontsize=10, weight="bold", va="center")
    ax.text(x + 0.043, y + 0.185, body, fontsize=9.1, va="top", linespacing=1.65)


fig, ax = plt.subplots(figsize=(7.1, 4.35))
ax.set(xlim=(0, 1), ylim=(0, 1))
ax.axis("off")
card(
    ax,
    0.025,
    0.59,
    "WORK DELIVERED",
    "Release plans: 15 / 16 / 21 slots\nChanged calendar respected\nLocked starts preserved",
)
card(
    ax,
    0.55,
    0.59,
    "METHOD RETAINED",
    "Dispatch → lookahead → repair\nActual parent calls: 15 and 3\nExecutable strategies + evidence",
)
card(
    ax,
    0.55,
    0.15,
    "FRESH APPLICATION",
    "12 fresh repair instances\n24/24 paired deliveries accepted\nBest specialist remains available",
)
card(
    ax,
    0.025,
    0.15,
    "MEASURED CAPACITY",
    "42/42 bounded jobs accepted\nFinite-batch throughput: 3.176×*\nComplete net gain: unknown",
    AMBER,
)
for start, end in [
    ((0.465, 0.74), (0.535, 0.74)),
    ((0.76, 0.575), (0.76, 0.465)),
    ((0.535, 0.30), (0.465, 0.30)),
]:
    ax.add_patch(
        FancyArrowPatch(
            start, end, arrowstyle="-|>", mutation_scale=13, color=TEAL, lw=1.8
        )
    )
ax.add_patch(
    FancyArrowPatch(
        (0.09, 0.465),
        (0.09, 0.575),
        arrowstyle="-|>",
        mutation_scale=13,
        color=AMBER,
        lw=1.5,
        linestyle="--",
    )
)
ax.text(
    0.135, 0.515, "Reinvest only after verified net value", fontsize=7.7, color=AMBER
)
ax.text(
    0.5,
    0.985,
    "A capability flywheel must earn its next turn",
    ha="center",
    va="top",
    fontsize=14,
    weight="bold",
)
ax.text(
    0.5,
    0.075,
    "Retained repair: 0/12 wins. Source reuse CPU: 1.036× full recomputation.",
    ha="center",
    fontsize=9,
    color=AMBER,
)
ax.text(
    0.5,
    0.027,
    "*Concurrency 4 versus 1 on 12 tiny non-planning inputs; not a causal effect of inheritance.",
    ha="center",
    fontsize=7.6,
    color=GREY,
)
save(fig, "signature_flywheel")

families = [
    ("software-testing", "Software / testing"),
    ("structured-analysis", "Structured analysis"),
    ("source-synthesis", "Source-backed briefs"),
    ("documents-presentations", "Documents / slides"),
    ("planning-operations", "Planning / operations"),
    ("scientific-computation", "Polynomial computation"),
    ("web-documentation", "Executable documentation"),
]
fig, ax = plt.subplots(figsize=(7.1, 3.8))
fig.subplots_adjust(left=0.28, right=0.98, bottom=0.23, top=0.87)
for y, (key, label) in enumerate(reversed(families)):
    vals = np.asarray(S["families"][key]["wall_seconds"]["all"])
    ax.plot([vals.min(), vals.max()], [y, y], color="#C0D3DD", lw=3, zorder=1)
    ax.scatter(
        vals,
        np.full(len(vals), y) + np.linspace(-0.10, 0.10, len(vals)),
        s=24,
        color=TEAL,
        alpha=0.85,
        zorder=3,
    )
    med = float(np.median(vals))
    ax.scatter([med], [y], marker="|", s=180, color=NAVY, zorder=4)
    ax.text(1.58, y, f"{med:.3f} s", va="center", fontsize=9)
ax.set_yticks(range(7), [x[1] for x in reversed(families)])
ax.set_xscale("log")
ax.set_xlim(0.075, 2.25)
ax.set_xticks([0.1, 0.2, 0.5, 1, 2], ["0.1", "0.2", "0.5", "1", "2"])
ax.set_xlabel("Local delivery turnaround (seconds; log scale)")
ax.set_ylim(-0.55, 6.65)
ax.grid(axis="x", alpha=0.25)
fig.suptitle(
    "All 42 primary outputs accepted; six fresh instances per bounded family",
    fontsize=10,
    weight="bold",
    y=0.98,
)
fig.text(
    0.02,
    0.025,
    "Dots are individual jobs. Planning includes complete child-process exit.\nOther families include producer, acceptance and export; final receipt tail excluded.",
    fontsize=7.5,
    color=GREY,
    linespacing=1.4,
)
save(fig, "portfolio_turnaround")

csv_path = ROOT / "raw/planning/connected-release-2026102518/schedule.csv"
rows = list(csv.DictReader(csv_path.open()))
fig, axes = plt.subplots(
    3, 1, figsize=(7.1, 5.1), sharex=True, gridspec_kw={"hspace": 0.54}
)
fig.subplots_adjust(bottom=0.19, top=0.94)
for phase, (ax, label) in enumerate(
    zip(
        axes,
        [
            "Initial plan • finish 15",
            "Changed requirements • finish 16",
            "Repair after calendar interruption • finish 21",
        ],
    )
):
    if phase == 2:
        ax.axvspan(8, 11, color="#F1D6B9", alpha=0.9, zorder=0)
        ax.text(9.5, 5.7, "zero capacity", ha="center", fontsize=7.6, color=AMBER)
    for r in rows:
        if int(r["phase"]) != phase:
            continue
        j = int(r["job"][1:]) - 1
        start = int(r["start_slot"])
        end = int(r["end_slot"])
        locked = r["locked_in_repair"] == "True"
        ax.barh(
            j,
            end - start,
            left=start,
            height=0.67,
            color=NAVY if locked else TEAL,
            zorder=2,
        )
        ax.text(
            (start + end) / 2,
            j,
            r["job"],
            ha="center",
            va="center",
            color="white",
            fontsize=8,
        )
    ax.set_yticks([])
    ax.set_ylim(-0.7, 6.3)
    ax.set_xlim(0, 22)
    ax.set_title(label, loc="left", fontsize=10, weight="bold", pad=7)
    ax.grid(axis="x", alpha=0.22)
    ax.spines["left"].set_visible(False)
axes[-1].set_xlabel("Planning slots (scenario inputs, not measured human work hours)")
fig.text(
    0.125,
    0.025,
    "Dark bars: J1 and J2 remain at start 0.\nNative repair moves less than the retained candidate (20 versus 22).",
    fontsize=7.5,
    color=GREY,
    linespacing=1.4,
)
save(fig, "connected_planning")

fig, (ax, bx) = plt.subplots(
    1, 2, figsize=(7.1, 3.35), gridspec_kw={"width_ratios": [1.05, 1], "wspace": 0.38}
)
fig.subplots_adjust(bottom=0.28, top=0.87)
x = np.arange(2)
width = 0.24
data = [[27542, 18623], [58923, 77541], [27529, 18614]]
for i, (label, vals, col) in enumerate(
    zip(["Inherited", "Reconstructed", "Equivalent"], data, [TEAL, "#ADC2CE", NAVY])
):
    ax.bar(x + (i - 1) * width, np.asarray(vals) / 1000, width, label=label, color=col)
ax.set_xticks(x, ["Lookahead", "Repair"])
ax.set_ylabel("Construction work units (thousands)")
ax.set_title(
    "Inheritance avoids reconstruction", fontsize=10, loc="left", weight="bold"
)
ax.legend(fontsize=7.6, frameon=False, loc="upper left")
ax.set_ylim(0, 100)
ax.grid(axis="y", alpha=0.2)
ratios = [r["offered_cpu_seconds"] / r["ordinary_cpu_seconds"] for r in P["pairs"]]
bx.scatter(
    ratios,
    np.linspace(-0.11, 0.11, len(ratios)),
    color=TEAL,
    s=22,
    label="Planning pairs",
)
sm = S["source_mechanism"]
bx.errorbar(
    [
        P["transfer_cpu_ratio_offered_over_ordinary"],
        sm["incremental_over_full_cpu_ratio"],
    ],
    [0, 1],
    xerr=[
        [
            P["transfer_cpu_ratio_offered_over_ordinary"]
            - P["paired_task_bootstrap_95_interval"][0],
            sm["incremental_over_full_cpu_ratio"] - sm["task_bootstrap_95"][0],
        ],
        [
            P["paired_task_bootstrap_95_interval"][1]
            - P["transfer_cpu_ratio_offered_over_ordinary"],
            sm["task_bootstrap_95"][1] - sm["incremental_over_full_cpu_ratio"],
        ],
    ],
    fmt="D",
    color=NAVY,
    capsize=4,
    ms=5,
    zorder=5,
)
bx.axvline(1, color=AMBER, lw=1.2, linestyle="--")
bx.set_yticks([0, 1], ["Repair offered", "Source reuse"])
bx.set_ylim(-0.65, 1.65)
bx.set_xlim(0.88, 1.18)
bx.set_xlabel("CPU ratio versus direct route")
bx.set_title("No observed CPU saving", fontsize=10, loc="left", weight="bold")
bx.grid(axis="x", alpha=0.2)
fig.text(
    0.04,
    0.02,
    "Work units are not money. Diamonds: aggregate CPU ratios; lower is better.\nBars: paired descriptive 95% bootstrap intervals. Dots: the 12 planning pairs.",
    fontsize=7.5,
    color=GREY,
    linespacing=1.4,
)
save(fig, "inheritance_and_cost")

fig, (ax, bx) = plt.subplots(1, 2, figsize=(7.1, 3.2), gridspec_kw={"wspace": 0.38})
fig.subplots_adjust(bottom=0.28, top=0.88)
xs = [1, 2, 4]
for c in xs:
    a = S["scale"][str(c)]
    v = a["throughput_per_minute"]
    ax.scatter([c] * 3, v["all"], color=TEAL, s=32)
    ax.plot([c - 0.16, c + 0.16], [v["median"]] * 2, color=NAVY, lw=2)
    bx.scatter(
        [c] * 36, a["submission_latency_seconds"]["all"], color=TEAL, alpha=0.4, s=12
    )
    m = a["submission_latency_seconds"]["median"]
    bx.plot([c - 0.16, c + 0.16], [m] * 2, color=NAVY, lw=2)
ax.set_ylabel("Accepted outputs / minute")
bx.set_ylabel("Submission-to-delivery seconds")
for a in (ax, bx):
    a.set_xticks(xs)
    a.set_xlabel("Concurrent local processes")
    a.grid(axis="y", alpha=0.2)
ax.set_title("Finite-batch capacity", loc="left", fontsize=10, weight="bold")
bx.set_title("Latency includes initial queue", loc="left", fontsize=10, weight="bold")
fig.text(
    0.02,
    0.015,
    "108/108 accepted. Three 12-job batches per setting, reusing 12 inputs; all finish in under two seconds.\nPlanning and remote model load are excluded.",
    fontsize=7.2,
    color=GREY,
    linespacing=1.4,
)
save(fig, "finite_capacity")

manifest = {
    "schema": "publication-figures/v1",
    "source_summary_sha256": hashlib.sha256(
        (ROOT / "analysis/SUMMARY.json").read_bytes()
    ).hexdigest(),
    "source_planning_sha256": hashlib.sha256(
        (ROOT / "analysis/planning.json").read_bytes()
    ).hexdigest(),
    "files": [
        {
            "path": str(p.relative_to(ROOT)),
            "bytes": p.stat().st_size,
            "sha256": hashlib.sha256(p.read_bytes()).hexdigest(),
        }
        for p in sorted(OUT.glob("*"))
        if p.suffix in {".pdf", ".svg", ".png"}
    ],
}
(OUT / "PUBLICATION_FIGURES.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps({"generated_figures": 5, "formats": ["pdf", "svg", "png"]}))
