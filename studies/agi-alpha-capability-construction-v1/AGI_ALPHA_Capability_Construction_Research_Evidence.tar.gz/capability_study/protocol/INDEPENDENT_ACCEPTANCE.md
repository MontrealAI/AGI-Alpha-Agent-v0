# Acceptance rules: additive capability-construction study

These rules belong to the new study. They do not replace the Economics of
Autonomous Work edition, its frozen protocol, or any previous negative result.

## Separation and evidentiary status

Acceptance uses a separately authored Python oracle that imports no producer
implementation. Its author can inspect public task contracts and producer
interfaces. This separation is useful engineering evidence; it is not an
externally administered, blinded human assessment. There is no recruited human
trial. All model-based authoring and integration costs that cannot be measured
must remain unknown, not zero.

## Complete deliverable

A task is accepted only when the supplied brief is bound to the output, the
required usable artifacts are present, provenance and integrity match, and all
material contract checks pass. Zero material arithmetic errors, omitted input
records, invalid dependency edges, stale affected outputs, or fabricated source
claims are allowed. A bounded explicit refusal can pass a safety/control test;
it does not count as an accepted requested deliverable.

## Native supported work

- **Software repair:** a corrected closed-interval utility, original source,
  executable checks, patch and original defect observations. Only the declared
  finite source grammar is supported. Contract boundaries must be correct.
- **Analysis:** an exact grouped CSV report, HTML report and JSON evidence. Every
  input row contributes exactly once; grouped count, total, minimum and maximum
  must match independent arithmetic; display labels must be escaped.
- **Executable documentation:** all supported URI/UTF-8 example outcomes match
  standard-library semantics; original text is retained; only the expected
  fields of executable examples may change. Malformed inputs remain visible.
- **Numerical reproduction:** exact polynomial integral and independent rational
  quadrature calculations; tolerance decisions must match exact arithmetic.
  Passing arithmetic does not validate a physical model.
- **Algorithm comparison:** sorted unique integers must be exact and all timing
  samples and selection arithmetic retained. This validates a bounded comparison,
  not general algorithm superiority or a human-economic advantage.

Broader headings such as software engineering, scientific research and document
production must always retain these narrower tested scopes. Repeated variants
of one grammar do not become separate task families.

## Repair and inheritance

A parent artifact must be supplied as bytes, hashed, validated and actually read.
The child must identify changed inputs and all affected downstream dependencies.
Previously valid unaffected results must retain their identities. A repaired
schedule must satisfy every dependency and its stated optimization contract.
The retained repair tool must be executable, with applicability, failure modes,
construction/evaluation cost, version and rollback recorded. Fresh transfer
requires a different mission with changed content and dependency structure.
Lineage labels without invocation evidence are insufficient.

## Review protocol

Creator, challenger and adjudicator are bounded functions or agents, not assumed
independent minds. A challenge needs a source passage, reproducible counterexample
or violated frozen constraint. Adjudication must verify it before changing work.
Preserve the original, challenge, verdict, correction and regression test.
Measure challenged valid cases (false alarms), undetected seeded defects (misses),
successful detections, review latency and resource use. Lack of objections does
not establish correctness. The independent final acceptance oracle stays outside
the optimized review policy.

## Economic and improvement claims

The primary economic comparator is competent traditional human work with ordinary
non-AI tools, grounded in sourced market data and published task evidence.
Mechanism comparisons with full recomputation or a strong specialist are separate.
Report full delivery and improvement accounts, unsuccessful construction and all
retries. Unknown attention, provider cost, maintenance or development cost blocks
an observed all-in economic gain claim.

Self-acceleration requires a prospectively specified rising rate of independently
verified capability gain per complete resource cost across successive comparable
cycles, held resource limits and difficulty, and fresh transfer. A single speedup,
cache hit, larger archive, or additional agent is insufficient. When the costs or
cycles cannot support this test, report NOT ESTABLISHED rather than inventing a
growth curve.
