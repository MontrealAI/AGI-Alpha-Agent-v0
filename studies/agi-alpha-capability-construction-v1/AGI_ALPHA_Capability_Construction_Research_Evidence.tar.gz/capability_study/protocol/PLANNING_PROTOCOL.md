# Prospective planning and capability-transfer subprotocol

Status: DEVELOPMENT until included in the new study's timestamped freeze. No
confirmation result may change this protocol. It is additive to all earlier
AGI ALPHA publications, including Strategy Succession and Economics of Autonomous
Work. Prior repair losses remain historical evidence.

## Product and tasks

Use the current source-pinned, unmodified `contrib/strategy_succession/worker`
FixedWorker. This is an actual AGI ALPHA implementation, executed through its
finite local Python/Node interface. It verifies its source manifest, uses its
ordinary portfolio, permits the existing local SciPy/HiGHS specialist, invokes
its independent checker, builds workbench delivery packs and records attempts.
No journal, identity, credential, network service or daemon is created.

Six primary portfolio jobs are generated before execution from the frozen
generator and a separately recorded new seed. Their sizes are six, nine and
twelve jobs, two instances per size, with varied durations, dependencies and
calendar capacity. Named release, research, editorial and operations contexts
aid usability; they do not establish six independent task families. All
durations are abstract supplied planning slots, not observed human work times.
The requested artifact is a feasible resource-constrained schedule meeting the
supplied deadline, with accurate objective/bound claims and all alternatives.

## Connected demonstration

One separately generated six-job mission executes the existing `run-journey`:

1. Produce and independently verify an initial plan.
2. Construct dispatch, lookahead and repair methods using the worker's fixed
   disjoint development variants, before exposing actual changed/repair service
   inputs to candidate evaluation. Preserve deferrals and candidate failures.
3. Execute a changed brief with a longer integration task.
4. Derive the repair baseline from the actual preceding verified schedule and
   receipt. Lock starts earlier than the declared observation time. Apply the
   supplied future unavailable calendar window; preserve the observed past.
5. Independently check the repaired schedule and exact baseline/lock lineage.

The execution order is recorded by worker checkpoints.
Completed/in-progress labels are inferred from a planning time. No physical
task completion is observed. Whether the future disruption actually invalidates
the preceding plan is measured; a no-change case must be labelled as such.

The worker's inherited, rebuilt and equivalent-parent diagnostic arms remain
available with their existing matched allowances. These are capability-mechanism
tests, separate from the primary human-work economic comparison. They neither
restore a mandatory same-AI/no-learning economic arm nor imply that all value
comes from learning.

## Fresh repair transfer

Use the first correctness-qualified repair asset retained by the journey, still
in HOLD with no production authority. Freeze its exact bytes and digest before
transfer. Generate twelve new repair briefs with four-to-six jobs and different
graphs, durations, source schedules and release changes. The historical baseline
is a feasible serial schedule supplied as task material; a delayed input makes
that baseline require repair. Preserve its locked first task.

Run each task in two randomized-order complete-worker arms:

- ordinary portfolio plus both available native modes;
- the same worker with the retained repair AST additionally offered as a trial.

The strongest ordinary/native methods remain available in both arms. Record the
candidate's own feasibility, target quality and method cost, as well as which
method the complete product selects. A native win is useful product output but
is not evidence for the retained candidate. If no repair asset qualifies, mark
transfer NOT RUN and report the construction failure. Do not create a replacement
after observing confirmation.

## Limits and accounting

Each action has service allowance 3,000,000 declared worker units, improvement
allowance 5,000,000, at most six native calls, twelve seconds of reserved native
solve time (two per call), 180 seconds worker wall and 210 seconds outer process
guard. Units are the existing worker's explicit accounting model; they are not
CPU instructions, currency, model tokens or observed employee minutes. Every
ordinary/native/candidate attempt, failed construction, independent check,
retention/export and deferral remains in the raw record.

Measure complete outer child-process latency from launch through exit. Measure
whole Python process plus waited descendants' CPU through final evidence writing;
disclose the excluded receipt/exit CPU tail. Keep service and improvement accounts
separate, then combine them for the whole journey. Retained asset development is
paid once; mechanism-diagnostic reconstruction is additionally charged. Include
all development failures in a separate construction ledger. Authoring AI usage,
human attention, host price, full maintenance and deployment cost remain unknown
unless independently observed. No empirical all-in economic win is inferred.

## Independent acceptance and analysis

The new Python oracle imports no producer or optimizer. It verifies input binding,
all jobs exactly once, duration, releases, precedence, capacity, locked prefix,
makespan, movement, deadline, declared movement limit, independent valid lower
bounds and empty proof/authority. The journey oracle binds every receipt and
derives the new baseline and locks from the actual previous artifact. Solver
success alone does not establish acceptance.

Report every attempted job, accepted counts, refusals/failures, latency and CPU
distribution, candidate versus strongest-specialist WIN/TIE/LOSS, selected method,
parent reads/calls, retained asset identity and transfer acceptance. Primary
planning observations are six fresh jobs. The journey is one connected example;
paired transfer calls are twenty-four attempts on twelve fresh repair instances,
not twenty-four unrelated tasks. No repeat is silently added to the sample.

Compare quality lexicographically as the worker does: target qualification first;
for qualified repairs, movement first and makespan second; for planning, makespan
then movement. Costs always include unsuccessful alternatives. Wall-time ratios
are descriptive on this shared host and do not establish universal runtime gains.
Use paired task-level summaries for the two transfer arms; preserve equality and
losses, and report all confidence intervals as descriptive of this bounded sample.
The paired CPU ratio is the sum of retained-offered CPU divided by the sum of
ordinary/native CPU over complete pairs. A paired task bootstrap uses 2,000 draws
with analysis seed 29012026 and empirical 2.5/97.5 percentiles. It cannot quantify
unmeasured systematic host effects. Missing paired results remain explicit and
are not converted to zero costs or successful outcomes.

These different construction stages have different objectives and difficulty.
They do not identify self-acceleration. The acceleration scorecard remains
NOT ESTABLISHED without separately preregistered comparable cycles, complete
resource costs and independent capability-gain units.

## Operating and publication boundary

The local worker stops when its finite process ends. It does not demonstrate the
authenticated browser-to-approved-executor route, which needs an already admitted
operator home and token. That route is NOT RUN unless those existing authorized
resources are independently available. No new credentials may be created to
fill this gap. Public source, replay, local computation and actual authenticated
execution must carry distinct labels.
