# Prospective bounded review experiment

This study freezes the creator, challenger, adjudicator and independent acceptance
before confirmation. They are deterministic contract procedures; their different
roles do not establish statistically independent model judgments.

The review worker receives `{input, brief, criticisms?}`. It returns its own
contract findings as `criticisms`, and adjudicates either the separately supplied
criticisms or those actual findings. Criticisms identify a claim, a violated rule
and concrete expected/observed source evidence. The adjudicator recomputes the
facts before substantiating a criticism. No unverified assertion authorizes a
changed output. Final acceptance is outside the policy being assessed.

## Frozen corpus and denominator

Generate six clean evidence inventories from the frozen public source packets.
Each inventory selects three real supplied passages with exact source hash and
URL. Then create three instances of each of nine fault classes: missing required
claim, wrong quotation, wrong source hash, wrong source URL, wrong section,
unrequested claim, duplicate claim, wrong mission binding and wrong title.
Separately submit six plausible but false criticisms against clean artifacts.
This produces **39 review attempts: 6 clean, 27 seeded-defect, 6 false-criticism**.
Randomize order using the registered seed. These are engineering review fixtures,
not 39 new productive deliveries or a prevalence-weighted real-world error rate.

The evaluator independently derives expected failures directly from the supplied
brief and source passages. The test passes only if the critic reports exactly
the applicable findings and every adjudication matches recomputed evidence.
Record true detections, missed registered defects, false alarms on valid content,
false assertions correctly rejected and failures to complete review. Unknown
outcomes must remain unknown; an interrupted review is not a zero miss.

## Cost and limits

Each attempt launches the fixed local Node review worker with a ten-second process
cap and a scrubbed environment. Measure complete process wall time plus independent
result inspection and export through receipt creation, child CPU and supervisor
CPU. Include all 39 attempts in the total. Final receipt serialization is outside
the interval and disclosed. No model/provider calls or financial transactions are
made by this fixed route; authoring costs, human time and full monetary cost remain
separate and unknown.

No more rounds are added after inspecting confirmation. Keep originals, mutations,
critic evidence, adjudication, verdicts and latency/cost receipts as regression
cases. These findings establish the behavior of the registered bounded checks;
they do not measure free-form factual understanding, all possible document errors,
general review quality or economic return on unmeasured human review.
