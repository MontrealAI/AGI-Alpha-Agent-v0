# AGI ALPHA FLYWHEEL — When Capability Creates Opportunity

## Connected example · From measurements to a qualified decision to successor work

**Vincent Boucher — President of MONTREAL.AI**

**October 27, 2026 · Actual technical execution; hypothetical customer and commercial scenario**

### 1. A useful question is missing its instrument

A hypothetical battery-reuse operator holds labeled pulse measurements and wants to know whether a proposed diagnostic process can support an **80% nominal-capacity requirement**. A point prediction alone is insufficient. If the model leaks measured health through a filename, confuses aging states with independent cells, or skips expensive ambiguous cases, the apparent solution can be misleading.

The original purpose is an informed testing decision. The binding restriction is the missing connection between valid evidence, uncertainty, testing obligations and cost. AGI ALPHA constructs that connection as an executable analytical dossier. The operator buys the assessment, including a justified no-go; it does not buy an undisclosed promise that every cell will pass. [1,2]

### 2. Build and freeze the capability

The construction starts with four immutable public PulseBat workbooks: 2,700 observations from 215 physical cells. Known retired-cell cohorts provide 91 training, 51 calibration, 31 originating and 30 successor cells. Twelve laboratory-aged cells are an explicit outside-scope challenge. All repeated observations stay with their physical cell. [1]

Measured capacity, health, identity, target-derived filenames and known state of charge are excluded from the predictors. The bounded search compares conventional cohort medians and two-/five-pulse random forests with raw or current-normalized voltage features. The selected model uses two pulses; the strongest five-pulse control receives the same data and valid formulation.

Cell-level calibration gives the selected instrument a 0.18519 SOH interval radius. The exported JSON contains the trained trees and calibration metadata, but no confirmation answers. Both technical and commercial policies are committed before their respective fresh evaluations. The researcher supplied the estimator family, candidate features, thresholds and selection rule; autonomous scientific discovery is not claimed. [1,2]

### 3. Deliver one useful capacity statement

Originating cell `NMC_21|02LCC02100101A87Y0010168` receives:

| Quantity | Actual retrospective result |
|---|---:|
| Predicted state of health | 0.99460 |
| Declared interval | 0.80941–1.17979 |
| Required threshold | 0.80000 |
| Measured capacity / nominal capacity | 1.00329 |
| Disposition | Capacity at least the threshold |

The complete interval exceeds the stated requirement. Values above 1.00 are allowed because health here is measured capacity divided by nominal capacity. This is a scoped analytical disposition, with `physical_release_authorized` explicitly false. [2]

### 4. Keep the difficult case and its cost

Originating LFP cell `14号` has a point estimate near 0.8393, but the interval crosses 0.80. It retains a full-capacity-test obligation. Across all 31 originating cells, the instrument issues 6 dispositions and 25 referrals. Every decisive case is NMC 21 Ah; all 12 outside-population cells require requalification. [2]

The customer scenario prices pulse setup at $2, channel time at $6/hour and each full test at $25. Including all referrals, the selected policy costs **$726.27**, while the stronger five-pulse policy costs **$688.67**. The two-pulse policy loses **$37.60** on this originating task. That unfavorable result belongs in the customer's decision. These costs are declared scenarios, not laboratory invoices, and they exclude the analytical dossier fee. [2]

<!-- PAGEBREAK -->

### 5. Price and finance the same offering

The hypothetical customer purchases the complete analytical dossier for **$1,084.61**, under a fully refundable upfront deposit until analytical acceptance. The fee is half the central estimated equivalent human selling reference of $2,169.22. The human reference covers analytical expertise, not laboratory testing. A buyer can choose an internal team, a human provider or no purchase. [3]

The 12-week model includes finite $6,000 seed financing, six-job weekly capacity, price-sensitive participation, failures, refunds, invoice liabilities, support and reserves. Refundable prepayment cannot finance delivery commitments. The model reserves the ex-ante resource envelope before uncertain costs occur; it cannot inspect future token or correction draws when admitting a job. [3]

Across 1,000 fresh hypothetical worlds, direct delivery averages **17.408 accepted dossiers**, **$18,880.88 accepted revenue**, **$12,111.56 complete operating cost** and **$6,769.32 operating profit**. After the rejected optional-retention assessment, mean profit is **$6,687.13**. The direct-service fifth-to-ninety-fifth-percentile profit range is **−$3,566.31 to $20,597.38**. Actual customer collections are **$0**, and complete realized research construction cost is unknown. [3]

Small-batch testing savings alone do not repay this fee. The commercial hypothesis is that some buyers value a complete analytical assessment enough to commission it instead of equivalent human work or for a larger consequential decision. A cheap competent in-house option can remove the market entirely. [2,3]

### 6. Transfer the instrument; recheck the new purpose

The fresh successor mission asks about a **75% capacity requirement** on 30 different physical cells. The recipient runs in a separate process and receives the actual learned parameters plus hash-bound inference code and requests. It obtains 8 capacity dispositions and retains 22 full-test obligations, with 2.81 percentage-point mean absolute error. All 8 decisive cells are NMC 21 Ah. [2,4]

The selected two-pulse and stronger five-pulse controls now have equal referral counts. Under the same cost assumptions the shorter sequence costs **$648**, versus **$660** for the five-pulse policy. The $12 advantage is conditional on this fresh set and cost scenario. The five-pulse method remains more accurate. The result is not evidence of broad field superiority. [2]

The old 0.80 mission grant cannot authorize the new 0.75 purpose. Changed artifacts, code or inputs, expired or revoked authority and replayed nonces are refused. The existing integration passes **44/44 controls**. Names under `*.agent.agi.eth` are research fixtures; live ENS authentication is untested. The unchanged production capsule schema refuses battery scope. [4]

### 7. Inherit useful work without inventing incremental Alpha

An ordinary library containing identical reusable information produces exactly the same predictions. This is a real transfer of an executable learned instrument, not evidence that graph membership creates superior economics. The Gym does not run a mandatory campaign.

Additional retention has a declared $80 assessment, $170 extraction cost, $20 weekly maintenance and $3 invocation cost. Its frozen uncertainty model includes negative, zero and positive benefits. Expected incremental value fails admission, so the commercial policy keeps direct delivery and declines extra retention. The rejected assessment stays in enterprise accounts. [3]

**The next opportunity:** qualify an independently supplied buyer dataset, then test whether a complementary measurement-planning specialist can reduce the total cost of resolving ambiguous cases. It would inherit the provenance and instrument, recheck the buyer's new meaning, and obtain new authority. Its success remains a falsifiable next study.

**Evidence:** [1] `data/`, `evidence/data_sources.json`, `config/technical_protocol.json`; [2] `results/development.json`, `results/origin_confirmation.json`, `results/successor_confirmation.json`; [3] `config/commercial_protocol.json`, `results/economics_summary.json`, `results/economics_example_ledger.json`; [4] `integration/results/confirmation-01/summary.json`. Full sources and uncertainty intervals are in the accompanying paper.
