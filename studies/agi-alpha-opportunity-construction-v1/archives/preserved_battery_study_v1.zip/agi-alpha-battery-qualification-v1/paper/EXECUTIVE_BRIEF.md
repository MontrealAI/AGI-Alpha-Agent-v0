# AGI ALPHA FLYWHEEL — When Capability Creates Opportunity

## Executive brief · A decision service that leaves its successor better equipped

**Vincent Boucher — President of MONTREAL.AI**

**October 27, 2026 · Research edition 1.0.0**

### The result to build on

AGI ALPHA constructed an executable **battery-diagnostic qualification dossier**: a service that connects real measurements to a justified capacity decision, the tests still required, and the economics of the complete testing plan. The same learned instrument then ran successfully on fresh successor work under a new capacity requirement. This makes a bounded, auditable analytical offering concrete. It does not establish autonomous battery certification. [1–3]

The commercial study supports a positive conditional result at a **$1,084.61 service price**: **$6,769 mean operating profit over 12 weeks**, or **$6,687 after charging a rejected optional-retention assessment**. The modeled fifth-to-ninety-fifth-percentile range for direct delivery is **−$3,566 to $20,597**. Actual customer collections are **$0**; complete realized study construction cost is unknown. [3]

### What became possible

A reuse operator may already have pulse and capacity measurements yet lack a defensible answer to: *Which diagnostic program should we pay for, for this battery population and requirement?* An accuracy score alone cannot answer it. Cell identity, leakage, uncertainty, costly referrals and unsupported measurement conditions all change the decision.

The offering combines those obligations in a replayable report. A supported recommendation to retain the conventional test can satisfy the contract, because the purchased outcome is a valid analytical assessment. Physical testing and safety release remain separate. The organizational gap and buyer willingness to pay are hypotheses for a pilot, not established market facts. [1,3]

### Real-data evidence

| Evidence | Origin | Fresh successor |
|---|---:|---:|
| Independent physical cells | 31 | 30 |
| Selected two-pulse mean absolute health error | 2.94 percentage points | 2.81 percentage points |
| Capacity dispositions / full-test referrals | 6 / 25 | 8 / 22 |
| Two-pulse testing cost relative to strong five-pulse control | $37.60 more | $12.00 less |

The study uses 2,700 public observations from 215 physical cells, with cell-level development and confirmation splits. All 14 decisive cases are from the NMC 21 Ah cohort; the other known cohorts retain full-test obligations. Twelve outside-population cells are routed to requalification. Computational delivery checks pass 41/41. [2]

The five-pulse conventional control matches or exceeds important technical outcomes. The origin result refutes the attractive claim that a shorter acquisition sequence always reduces complete testing expense: two extra full tests outweighed the time saved. Small retrospective batches do not recover the dossier fee through testing savings alone. The modeled buyer purchases equivalent analytical work or a decision of broader scope. [2,3]

<!-- PAGEBREAK -->

### Complete commercial economics

The service uses buyer-supplied, rights-cleared labeled data for up to three known cell families. Human production is estimated at **$780–$3,089**, with a **$1,627 central case** for 16 competent analyst/engineer hours, benefits, nonlabor overhead and tools. A separately assumed 25% operating margin gives a $2,169 central selling reference. It is not a quote or measured willingness to pay. The lowest human-price estimate is slightly below the selected agent price. [3,5]

Development compared nine price/deposit policies plus no launch. Fresh confirmation used 1,000 disjoint hypothetical worlds. Demand changes with price, confidence, financing and outside options. Refundable deposits cannot finance delivery commitments. [3]

| Direct service, mean 12-week scenario | Result |
|---|---:|
| Booked / accepted dossiers by day 84 | 21.56 / 17.41 |
| Accepted service revenue | $18,880.88 |
| Complete modeled operating cost | $12,111.56 |
| Operating profit | **$6,769.32** |
| Complete period cost per accepted dossier | $695.75 |
| Available funds gained after obligations and reserves, excluding $6,000 seed | **$6,041.97** |

The model includes inference, execution, verification, retries, corrections, packaging, support, acquisition, productization, business overhead, payment processing and settlement. Unknown expenses remain explicit. Its 80.5% profitable-world frequency describes the specified scenario distribution, not the empirical probability of business success. [3]

### What changes the decision

Mean profit remains positive with half the demand ($1,118), four times model costs ($1,474), or an extra $250 per booking ($1,407). It turns negative with a 0.60 baseline mission acceptance probability (−$2,154), an extra $750 per booking (−$5,167), or a cheaper competent in-house alternative available to every buyer (−$5,313). The initial segment must value this analytical scope and lack an adequate cheaper route. [3]

### What the successor inherits

A separately invoked recipient receives the actual trained parameters, calibration, scope, rights and source identities. It runs 30 fresh requests under a new 0.75 capacity requirement; the prior 0.80 grant cannot authorize that mission. Existing transport and authority controls pass **44/44**, and an identical ordinary library ties the recipient exactly. Live ENS authentication and production battery admission are not claimed. [4]

**Operational Alpha remains unmeasured.** Technical transfer is demonstrated; incremental commercial gain from retention is not. The frozen investment policy declines retention after its $80 assessment. Direct delivery remains a valid commercial scenario without a mandatory Gym campaign, token appreciation or graph growth. [3,4]

### Next useful validation

Run one scoped buyer pilot on an independently supplied, rights-cleared dataset, with analytical acceptance fixed in advance and actual cost, correction, support and collection telemetry. Obtain three scoped price reactions and one human quote or time study. A separate physical campaign must validate field conditions and the shorter measurement protocol before operational battery use. [1–4]

**Evidence:** [1] `evidence/opportunity_dossier.json`; [2] `results/origin_confirmation.json`, `results/successor_confirmation.json`, `results/delivery_acceptance.json`; [3] `config/commercial_protocol.json`, `results/economics_summary.json`; [4] `integration/results/confirmation-01/summary.json`; [5] official wage and benefit sources in the full paper, references 5–7. Full methods, provenance, failures and limitations are in `PAPER.md` and the executable companion.
