# AGI ALPHA FLYWHEEL — When Capability Creates Opportunity

## Transformational Intelligence, Experience-Trained Specialists and the Expanding Frontier of Profitable Work

**Vincent Boucher — President of MONTREAL.AI**

**TRANSFORMATIONAL INTELLIGENCE: LEARNING TO CHANGE THE GAME**

**FIND YOUR ALPHA. BUILD YOUR SUCCESSOR Ω.**

“As Columbus braved the seas, we now venture into the vast oceans of AGI. The age of AGI exploration has dawned, and the horizons are boundless. Dare to dream, dare to explore.” — α-AGI Agent

**Research edition 1.0.0 · October 27, 2026 · Battery diagnostic qualification**

### The possibility

An intelligent enterprise can sell a better-founded decision about what to build, measure or buy. Its useful output may be a validated testing plan, including a well-supported decision to obtain more evidence. This edition constructs that offering for battery diagnostics and carries a real learned instrument into fresh successor work.

**Evidence at a glance:** 2,700 public observations, 215 physical cells, 61 fresh capacity evaluations, 12 additional cells refused outside the calibrated population, 41/41 computational delivery checks, and 44/44 integration controls. The transferred instrument and an ordinary library containing identical information give identical results. Commercial outcomes are explicitly conditional simulations; actual customer collections are $0. [R1–R4]

## Abstract

We investigate a commercially useful possibility: making a rigorous, customer-specific battery-diagnostic qualification dossier economical enough for a bounded analytical service. The dossier answers whether an available pulse-based model supports a stated capacity decision, what must still be measured, and whether the complete testing arrangement is worthwhile. The study begins with five independently motivated opportunities and selects battery qualification before model fitting. It uses four immutable, rights-cleared PulseBat workbooks containing 2,700 observations from 215 physical cells. Identity-aware splitting excludes target-derived filenames, measured capacity, known state of charge and repeated observations of the same physical cell from the prediction inputs or independent-sample count. [1–3; R1–R2]

A trained two-pulse instrument achieves mean absolute state-of-health errors of **2.94 percentage points on 31 originating cells** and **2.81 points on 30 fresh successor cells**. Its declared intervals cover all observations in both confirmations. It issues 6 and 8 capacity dispositions respectively; the remaining 25 and 22 cells retain full-capacity-test obligations. All decisive cases belong to the NMC 21 Ah cohort. Twelve laboratory-aged cells outside the calibrated cohorts are refused, not removed. A strong conventional five-pulse control has comparable or better accuracy. Under the stated testing-cost scenario, the two-pulse policy costs **$37.60 more on the originating task** and **$12 less on the successor task**. [R2]

The commercial model evaluates the same analytical dossier against an estimated equivalent human service. A frozen bounded price-and-payment search selects a **$1,084.61 fee**, half the **$2,169.22 central human-service selling reference**. Corrected fresh simulation produces **$6,769.32 mean operating profit over 12 weeks**, with **−$3,566.31 to $20,597.38** as the conditional fifth-to-ninety-fifth-percentile range. Charging the rejected optional-retention assessment lowers mean profit to **$6,687.13**. These outcomes assume modeled demand, buyer participation, delivery reliability and complete forward costs; they are not earned revenue. [5–7; R3]

An independently invoked recipient executes the actual retained model on a new capacity requirement, with fresh fixture authorization. An identical-content ordinary library ties it. Mission-level frontier Operational Alpha remains unmeasured, and optional retention is declined by the frozen commercial admission policy. The contribution is a complete, executable decision service joining real technical evidence to conditional economics while preserving conventional controls, full-test obligations and the distinction between reusable capability and incremental profit. [R3–R4]

## 1. Start with the opportunity

The central question is: **What valuable possibility has become achievable now, which existing organizations are not yet equipped to pursue, and what can AGI ALPHA construct to make it real?** For this edition, the concrete customer question is: *Which diagnostic program should we pay for, for this battery population and this capacity requirement?*

Retired batteries differ in chemistry, nominal capacity, physical form, history and present state of charge. The PulseBat authors document those differences and the expense of collecting the data needed for state-of-health estimation. Their published work already demonstrates rapid prediction and generative approaches to unfamiliar retirement conditions. Conformal and transfer-learning approaches to battery health also already exist. We therefore treat prediction algorithms and uncertainty methods as available components. [1–4]

The specific service gap is the work needed to connect an available predictor to a particular buyer's decision: reconstruct the data lineage, prevent leakage between repeated cells, state what the calibration covers, distinguish a useful capacity statement from a required full test, and price the complete arrangement. A small operator may lack this combined analytical workflow. That organizational constraint is a business hypothesis supported by the documented technical difficulty; it has not been established by interviews or observed purchases.

Current frontier systems expose reasoning, code execution, tools and computer-use interfaces capable of helping construct and operate such a workflow. Public battery data, open software and portable trained parameters make a small executable study possible now. Official capability documentation establishes the available tools, not their success rate on this mission. This research uses hosted AI assistance for construction and review, deterministic software for the measurements, and explicit simulations for unavailable service and market behavior. [8–13]

## 2. A bounded search, with reasons to stop

Five opportunities were compared before fitting a battery model. Each was assessed for customer value, unresolved gap, plausible transformation, testability, commercial feasibility and reusable capability. Scores are transparent researcher judgments on a common ordinal scale; they are not valuations, measured demand or independent market rankings. The full dossier records source URLs, assumptions, proposed experiments and rejection reasons. [R1]

| Candidate | Useful missing outcome and proposed construction | Score / 5 | Selection decision |
|---|---|---:|---|
| Battery diagnostic qualification | A lot-specific testing decision, with cell-valid evidence and priced referrals; construct a replayable diagnostic qualification instrument | 3.85 | Selected: real measurements, identifiable units, a small complete experiment |
| Obsolete-component requalification | An application-bound replacement dossier preserving circuit obligations; combine datasheets, models and verification | 3.80 | Strong reserve: manufacturer cross-references already exist; circuit simulation and physical validation remain necessary |
| Tactile STEM diagrams | A usable representation preserving scientific meaning; construct and test tactile reading tasks | 3.55 | Deferred: intended-reader acceptance unavailable in this edition |
| Weathered-polymer spectroscopy | A useful composition or remeasurement decision from altered spectra | 3.35 | Deferred: relevant composition labels and independent measurements uncertain |
| Urban-flood inspection planning | Inspection commitments tied to event uncertainty and asset obligations | 3.20 | Deferred: event labels and operational validation insufficient |

The component candidate is concrete: Texas Instruments identifies obsolete OPA602 variants and offers OPA145 as a similar-functionality alternative. A manufacturer cross-reference does not establish stability, noise, bandwidth or packaging compatibility in a particular circuit. It remains a valuable reserve opportunity, but the battery dataset supports a stronger retrospective evaluation in this edition. [14]

Repository continuity mattered to selection. Current teams already cover scientific-model reuse, microscopy, manufacturing inspection evidence, ecological demand loss, shared satellite observation and primary-report reconstruction. We preserved those sources and their corrections, selected a distinct battery lane, and reused the existing transport and accounting adapter. No earlier study's profit, claimed advantage or test pass is imported into this offering. [15–18; R1; R4]

## 3. The transformation witness

The original purpose is to support an informed testing or procurement decision. A single point estimate of battery health is insufficient when repeated-cell leakage, uncertain calibration and expensive referrals can change the answer. The reformulation makes the deliverable a decision dossier: an executable statement of what the evidence supports, what remains an obligation, and what each route costs.

| Witness field | This study's commitment |
|---|---|
| Original purpose | Decide whether a proposed diagnostic program can support a stated capacity requirement economically |
| Binding restriction | Predictor output is disconnected from cell identity, measurement scope, uncertainty, referral costs and mission-specific authority |
| Reformulation | Construct a qualified analytical report and testing policy with explicit full-test obligations |
| Mechanism | Input whitelist; physical-cell splits; fitted pulse regressor; cell-level calibration; purpose-specific routing; independent replay; complete financial model |
| Preserved obligations | The same capacity requirement; every hard case retained; all unsupported cases requalified; no safety or physical-release inference |
| Acceptance | Source identity, split integrity, portable inference, complete dispositions, independently recomputed results and correctly scoped accounting |
| Falsifiers | Leakage; incorrect model transport; unpriced referrals; unsupported scope admitted; an adverse control or cost case removing the claimed advantage |

This transformation changes the service offered without claiming to replace physical battery certification. A supported no-go is an acceptable result of the analytical contract only because the customer purchases an evidence-based assessment in advance. It cannot be substituted for a promised successful battery classification after failure. The original capacity thresholds remain fixed, and unresolved cells remain visible in the costed test queue.

The researcher supplied the candidate set, features, estimator family, capacity requirements, selection rule and commercial policy family. The actual construction joins these elements and exposes their consequences. It is useful engineering, not evidence that a frontier agent autonomously discovered a new battery-physics method. Competent conventional controls receive the same data, valid formulation, tools and acceptance conditions.

## 4. The offering and its acceptance contract

**Offering:** a 48-hour battery-diagnostic qualification dossier for up to three known cell families, using buyer-supplied, rights-cleared labeled pulse and capacity data. The package contains a lineage audit, identity-aware model evaluation, explicit uncertainty, full-test referrals, a testing-cost scenario, a portable instrument and reproduction instructions. The 48-hour service window is a modeled commercial promise awaiting a live pilot; this study does not measure a distribution of autonomous delivery times.

The offering excludes physical sampling, full-capacity tests, pack qualification, safety certification and remaining-life guarantees. These are different obligations with different prices and evidence. Customer-owned testing costs appear in the customer model and never become provider revenue. Missing labels or unsupported measurement conditions can lead to an accurately documented insufficient-evidence report, subject to the same analytical contract.

Computational delivery acceptance passes **41 of 41 checks**. These include source hashes, the complete 215-cell allocation, exclusion of confirmation answers from the retained artifact, direct recomputation from measured capacity, identical units across methods, actual retained inference, full-test obligations and the exact native handoff identities. Twelve separately authored boundary tests pass, including a real sklearn float32 split-boundary case, nonfinite measurements, altered context, unknown cohorts and target-field invariance. These are executed software checks; buyer acceptance and physical acceptance have not been observed. [R2; R4]

## 5. Real measurements, clean unit boundaries

The four input workbooks come from immutable PulseBat repository commit `92aeb9b8a26bc337164401411271fa8eeadf605c`. Their original bytes, source URLs, SHA-256 values, MIT license and author README are retained. This is a selected processed-data subset, not a claim to reanalyze every measurement in the larger PulseBat collection. [1–3; R1]

| Population | Rows | Physical cells | Role |
|---|---:|---:|---|
| Retired LMO, 10 Ah | 950 | 95 | Development, calibration and fresh confirmation |
| Retired NMC, 21 Ah | 520 | 52 | Development, calibration and fresh confirmation |
| Retired LFP, 35 Ah | 560 | 56 | Development, calibration and fresh confirmation |
| Laboratory-aged NMC, 2.1 Ah | 670 | 12 | Explicit outside-scope stress |
| **Total** | **2,700** | **215** | Every physical cell accounted for |

The laboratory file contains 67 aging-state identifiers belonging to 12 physical cells. Grouping only by complete aging-state identifier would inflate independence. The analysis groups those records by physical-cell prefix. All ten state-of-charge observations for an EV-retired cell stay together. Deterministic hash-based allocation within each cohort assigns 91 cells to training, 51 to calibration, 31 to originating confirmation and 30 to a fresh successor purpose. No label-based stratification selects favorable test cases. Each fresh cell contributes one deterministically hash-selected SOC observation to its primary confirmation task; the reported 31 and 30 coverage events concern those selected requests, not all 310 and 300 held-out SOC rows. [R1–R2]

Prediction inputs are voltage features and known nominal chemistry/capacity. Measured capacity Q, health SOH, source filename, identity, record count, state of charge and its derived fields are excluded. The filename's maximum planned state of charge depends on calibrated health, making it a particularly serious leakage route. The public measurements were acquired under a controlled protocol; withholding SOC as a predictor does not establish performance under arbitrary field conditions. [2]

The experimental air-conditioner setting was 25°C, and these processed features use the 5–50% nominal-SOC region. The instrument requires the declared retrospective context, voltage unit, pulse width and rest interval. Such a supplied context assertion does not independently measure physical temperature or establish trustworthy field metadata. New measurements need their own qualification. [2; R2]

## 6. Constructing the retained instrument

The bounded candidate family includes a no-pulse cohort-median control; two-pulse and five-pulse random forests using raw voltages; and the same forests using voltage changes normalized by nominal pulse current. Random forests have 128 trees, depth at most 6 and a minimum leaf size of 2, with a fixed seed. Five-fold cross-validation groups by physical cell. Every candidate uses identical training units and target definitions. [R2]

The selection rule chooses the least measurement time among candidates whose development mean absolute error lies within 0.005 absolute SOH of the best candidate, then breaks ties by error and name. It selects the two-pulse normalized-feature model. The five-pulse normalized-feature model is frozen as the strongest full-protocol reference from the same development comparison. This is a bounded policy search, not a global optimum over estimators or diagnostic designs.

For each calibration cell, the score is the maximum absolute prediction error over that cell's ten observations. The interval radius is the 50th sorted score among 51 cells: the finite-sample order statistic at ceil(52 × 0.95). The selected radius is **0.18519 SOH**; the full-protocol reference radius is **0.14324**. The deliberately wide intervals make uncertainty visible. The conformal interpretation requires exchangeability of the declared cell mixture and a fixed trained score function. Because allocation uses fixed per-cohort quotas, this edition reports empirical coverage and does not establish exact finite-sample coverage for a new cohort mixture. It provides neither per-chemistry coverage nor a 95% correctness guarantee conditional on issuing a decisive result. [4; R2]

A request receives a capacity disposition only when the complete interval lies above or below its requirement; otherwise it retains a full-test obligation. The originating threshold is 0.80. The successor threshold is 0.75 on different physical cells. These are researcher-specified capacity requirements, not safety standards. Unknown cohorts and mismatched measurement context route to requalification.

The trained forest, calibration quantile and scope metadata are exported as a standard-library-readable JSON instrument. It contains no confirmation observations or answers. Independent inference matches sklearn within approximately 1.1 × 10^-15 on calibration predictions after fixing an actual float32 portability defect. The initial failed construction and the independent review remain in the evidence record. The final technical policy was frozen before originating and successor evaluation. [R2]

## 7. Fresh technical results

![Prediction error on fresh physical cells](../figures/01_prediction_results.png)

*Figure 1. Actual retrospective prediction errors. The two-pulse and five-pulse normalized methods use the same estimator family and cell splits. This comparison does not measure ordinary versus expert frontier-agent operation.*

| Fresh task and method | MAE, percentage points | Decisive capacity cases | Full-test referrals | Wrong decisive cases |
|---|---:|---:|---:|---:|
| Origin, no-pulse median | 5.66 | 0 | 31 | 0 |
| Origin, selected two-pulse | **2.94** | **6** | **25** | **0** |
| Origin, strong five-pulse | 2.94 | 8 | 23 | 0 |
| Successor, no-pulse median | 7.00 | 0 | 30 | 0 |
| Successor, retained two-pulse | **2.81** | **8** | **22** | **0** |
| Successor, strong five-pulse | 2.45 | 8 | 22 | 0 |

All 31 selected originating observations and all 30 selected successor observations lie inside the selected intervals. Exact two-sided 95% intervals for empirical coverage are approximately **88.8–100%** and **88.4–100%**, respectively. The small number of decisive cases matters: zero errors among 6 or 8 decisions still permits exact upper bounds of approximately **45.9%** or **36.9%** on an identically distributed conditional error rate. This evidence cannot justify a low-risk field release. [R2]

All 14 decisive cases belong to NMC 21 Ah. LMO and LFP cases retain their full-test obligations. Thus the result demonstrates a scoped capability in this mixture, rather than broad battery-type coverage. The 12 laboratory-aged NMC cells all receive outside-scope referrals; they do not contribute favorable prediction scores.

The paired selected-minus-full MAE difference is **+0.006 percentage points** on origin, with a conditional bootstrap interval of **−0.226 to +0.220 points**. On successor it is **+0.360 points**, with interval **+0.005 to +0.786 points**. Both lie within the prespecified 2-point noninferiority margin, while the full method is more accurate on the successor set. The margin is an exploratory analytical tolerance, not a battery qualification standard. Bootstrap sampling operates on the distinct physical cells within each task. [R2]

![Decisions and retained obligations](../figures/02_decisions_and_obligations.png)

*Figure 2. Every ambiguous case remains in the testing queue. The no-pulse control is permitted; in these confirmations its pooled interval makes no decisive capacity statement.*

## 8. Prediction economy and testing economy can differ

The source protocol uses five-second pulses followed by 75-second rests, with a shared initial rest of 600 seconds. Reconstructing a standalone two-pulse subprotocol gives 760 seconds; five pulses give 1,000 seconds. This is a **24% modeled sequence-time reduction**, not a measured operational throughput improvement. The published data came from a larger experiment with calibration and SOC conditioning; channel occupancy, labor, handling and energy do not all fall by the same percentage. [2]

The transparent customer scenario assigns $2 setup per pulse-tested cell, $6 per channel-hour, $25 per full-capacity test, and $100 per wrong decisive capacity result. These are illustrative operating inputs, not laboratory quotes. They include every referral. A separately modeled three-hour full-test duration affects channel time, not a second charge on top of the $25 full-test price. [R2]

![Complete customer testing costs](../figures/03_customer_testing_economics.png)

*Figure 3. Scenario expense includes pulse testing, all full-test referrals and the declared error charge. Dossier fees, physical safety certification and unmeasured deployment risk are separate.*

| Customer testing scenario | Origin, 31 cells | Successor, 30 cells |
|---|---:|---:|
| Full-capacity tests for every cell | $775.00 | $750.00 |
| Selected two-pulse policy | $726.27 | $648.00 |
| Strong five-pulse policy | $688.67 | $660.00 |
| Selected minus strong reference | **+$37.60** | **−$12.00** |

The 12 separate outside-scope stress cells retain $300 of full-test obligations under the same $25/test scenario, separately from the 31-cell originating batch.

The origin result falsifies the claim that minimizing pulse acquisition necessarily minimizes complete testing expense. Two additional full tests cost more than the time saved. On the successor task the referral counts match, so the shorter sequence saves $12 in the stated scenario. Across both different-purpose task sets, the two-pulse choice costs $25.60 more than the five-pulse reference; the tasks must not be combined to conceal the unfavorable originating result. [R2]

The analytical service can still be valuable when it advises a buyer to keep the conventional method. Its sale concerns the rigorously evaluated decision, not a guaranteed diagnostic shortcut. The small retrospective batches alone do not recover a $1,084.61 dossier fee through the modeled testing savings. A buyer could value the analytical report instead of commissioning equivalent human analysis, or commission it for a larger decision; neither willingness to pay nor large-volume physical savings is established here.

<!-- PAGEBREAK -->

## 9. Establish the commercial foundation independently

The equivalent human service is an analytical qualification dossier, not a laboratory procedure. We estimate competent U.S. data-science and electrical-engineering delivery at constant acceptance quality, using 8, 16 and 28 total hours for low, central and high friction. The central case assigns 12 analyst hours across scope, lineage, grouped validation, uncertainty and reporting, plus 4 engineering hours for physical scope and review. These hours are study assumptions awaiting a time study or quote. [R3]

BLS reports May 2025 median wages of $120,230 for data scientists and $120,630 for electrical engineers. Annual wages divided by 2,080 give hourly proxies. June 2026 private-industry compensation of $46.89, including $32.82 wages, supplies a broad 1.4287 benefit multiplier. It is not an occupation-specific contractor rate. Nonlabor overhead of 15%, 20% or 30% excludes benefits, paid leave, payroll taxes and all directly assigned review/coordination hours already counted. Tools add $20, $40 or $80. [5–7]

| Equivalent human analytical service | Low | Central | High |
|---|---:|---:|---:|
| Total scoped hours | 8 | 16 | 28 |
| Estimated complete production cost | $780.40 | $1,626.91 | $3,088.52 |
| Assumed selling price at 25% operating margin | $1,040.53 | $2,169.22 | $4,118.03 |

Selling price equals production cost divided by 0.75. It is an estimated reference, not a supplier quote and not evidence of buyer willingness to pay. The automated policy tests 25%, 50% and 75% of the central reference, paired with 25%, 50% and 100% refundable deposits, plus no launch. The winning policy is selected using development worlds, then frozen before fresh confirmation. [R3]

The selected price does not beat every human-service estimate: the low-friction human selling reference is $1,040.53. The modeled target segment needs enough scope, urgency or unavailable internal capacity to prefer this $1,084.61 dossier. Neither the central wage-based estimate nor the difference in fees establishes an actual purchase.

| Base per-job resource plan | Aggregate usage or scope | Modeled cost |
|---|---|---:|
| Astra discovery and difficult judgment | 2.00M input + 0.20M output tokens | $30.00 |
| Terra execution | 3.00M input + 0.30M output tokens | $4.50 |
| Fable independent review | 0.75M input + 0.10M output tokens | $12.50 |
| Search | 40 calls; retrieved context included above | $0.40 |
| Runtime, programmatic checks, storage and packaging | $8 + $6 + $4 + $4 | $22.00 |

The $47 model-token subtotal is multiplied by a triangular usage factor (0.5, 1, 3). A retry occurs with assumed probability 0.25 and consumes another half of the resource plan. Unknown delivery expense has triangular inputs ($0, $40, $150); accepted-job support uses ($12, $24, $60). Fees are 3% of payments, refund processing costs $5, and accepted work prepays a $5 automated settlement/archive tail. These resource figures are assumptions, not measured API invoices. The admission envelope reserves $393.10 of maximum declared delivery resources before additional support, refund, tail and payment provisions. [R3]

The modeled complete automated workflow includes discovery and context construction, execution, independent validation, source checks, search, runtime, storage, failures, retries, correction, packaging, recovery, support, settlement/archive costs, customer acquisition, startup productization and ongoing business costs. No mandatory manual-review allowance is inserted into the assumed automated configuration. A separate residual-expert sensitivity adds two hours where a real deployment requires them. Unknown delivery costs have a nonzero distribution and adverse sensitivity rather than silently disappearing.

Actual unpaid research construction remains sunk expenditure of unknown complete amount. It is not called paid-job learning and is not assigned a fabricated invoice. The forward model pays its own explicit startup cost. In category A, originating delivery includes learning necessary to finish the contracted job. Category B adds only assessment, extraction, retention, sharing, invocation and maintenance beyond that delivery. Category C is optional extra research or Gym work. The frozen forward policy chooses no Gym campaign. [R3–R4]

## 10. Price, participation and financing form one arrangement

The simulation gives each prospective buyer four options: the agent dossier, equivalent human analysis, an available in-house team using open-source tools, or no purchase. Prices and payment terms change buyer participation. Perceived analytical value is modeled separately from the human selling reference; confidence discounts agent value. An unsuccessful delivery refunds the deposit and incurs an expected delay cost. Deposit financing and perceived counterparty risk affect demand. A competent conventional provider has access to the same formulation and reusable information. [R3]

The policy search optimizes day-84 cash after unearned deposits, accrued obligations, operating reserves and initial seed financing. It does not maximize margin while assuming unlimited demand. The world has a bounded 4–12 qualified-lead-per-week distribution, a six-job weekly capacity and finite $6,000 seed capital. Buyers may choose their in-house alternative. The provider may refuse a booking or stop accepting new work when its ex-ante resource envelope cannot be funded.

The selected arrangement charges **$1,084.61**, half the central human-service reference, with a fully refundable upfront deposit. Refundable deposits remain liabilities and cannot finance the provider's delivery commitment. An ex-ante resource ceiling is reserved before the uncertain token, retry and extra-cost draws are realized. Fees become revenue only on analytical acceptance. Support and invoice-processing liabilities are accrued; later payment does not charge them twice. Receivables, collection delays, default, two weeks of operating reserve and a settlement tail remain separate. [R3]

The buyer model draws analytical value at 0.6–2.0 times the human reference (mode 1.1), agent confidence at 0.55–0.90 (mode 0.75), and in-house availability with probability 0.70. An available in-house option costs 0.35–0.80 times human production cost (mode 0.50) and has quality 0.65–0.95 (mode 0.80). Human analytical quality is assumed 0.95. The agent's baseline final-delivery probability is triangular (0.60, 0.90, 0.98), with an 8% weekly common-failure probability multiplying it by 0.65. Buyers see its scenario-average risk, not future shocks. These broad distributions explicitly include low confidence and no purchase; they are not fitted market estimates. [R3]

This is a bounded decision-theoretic mechanism, not an equilibrium proof. Buyer values and confidence are not empirically estimated. The fixed-fee contract pays for a correct assessment, including a supported no-go, which reduces the modeled incentive to manufacture favorable diagnostic claims. Enforcement, legal allocation and counterparty trust require a live agreement. Shared technical failures are correlated across a week's work and are not diversified away merely by having several buyers.

## 11. Conditional commercial results

**The corrected, prospectively frozen commercial confirmation supports a positive modeled service result.** It uses 1,000 fresh worlds, with the original exploratory implementation and its accounting corrections preserved. The following results are before income tax and concern the analytical offering described above. No prior study's profit is carried into them. [R3]

| Direct service, 12 weeks | Mean conditional result |
|---|---:|
| Qualified leads | 95.583 |
| Booked dossiers | 21.562 |
| Accepted dossiers by day 84 | 17.408 |
| Accepted analytical-service revenue | $18,880.88 |
| Complete operating costs | $12,111.56 |
| Contribution after delivery, acquisition and processing | $11,552.22 |
| **Direct-service operating profit (E)** | **$6,769.32** |
| Complete period cost / accepted dossier | $695.75 |
| Operating profit with rejected retention assessment charged | $6,687.13 |

| Direct service E: day-84 financing and settlement | Mean conditional result |
|---|---:|
| Initial seed financing | $6,000.00 |
| Cash balance | $13,158.61 |
| Refundable, unearned deposits | $298.27 |
| Accrued support payable | $91.03 |
| Pending delivery commitments | $127.35 |
| Operating reserve | $600.00 |
| Accepted invoice receivables and pending processing fees | $0.00 at the selected full-deposit terms |
| Available expansion cash after all restrictions | $12,041.97 |
| **Available funds gained, excluding initial seed** | **$6,041.97** |

![Direct-service economics and important failure conditions](../figures/04_commercial_result.png)

*Figure 4. Corrected conditional confirmation. Left: accepted revenue less delivery, acquisition, payment and business expense. Right: unchanged price and payment terms under selected stresses, with participation and finite-cash admission recomputed. These are direct-service E results; optional-assessment costs are reported separately.*

The conditional operating-profit distribution spans **−$3,566.31 to $20,597.38** between its fifth and ninety-fifth percentiles; **80.5%** of modeled worlds are profitable. These are scenario frequencies under the declared parameter distributions, not confidence that a real business will succeed. The model records **17.408 accepted dossiers on average**, separately from booked jobs, failures, cash and receivables. Actual customer collections remain **$0** and complete realized research profit remains unknown.

| Frozen-policy sensitivity | Mean 12-week operating profit |
|---|---:|
| Base assumptions | $6,769.32 |
| Half the qualified demand | $1,118.35 |
| Analytical value ×0.65 | $4,993.59 |
| All buyers have a cheaper competent in-house option | −$5,312.94 |
| Model costs ×4 | $1,473.83 |
| Baseline mission acceptance probability 0.60 | −$2,154.23 |
| Acquisition cost ×3 | $2,203.22 |
| Support cost ×3 | $5,641.23 |
| Additional unknown expense $250/booking | $1,407.34 |
| Additional unknown expense $750/booking | −$5,166.50 |
| Two residual expert hours per booking | $3,209.49 |
| Compound adverse scenario | −$5,196.84 |

The important commercial uncertainty is not a small floating-point error in forecast profit. It is whether qualified buyers value this scope enough, whether the assumed frontier workflow delivers it reliably, and whether real correction, support, insurance and acquisition costs remain within the envelope. A cheap competent in-house alternative can remove the market. The same frozen price is retained in stress cases; demand is recomputed rather than held fixed.

The complete period cost per accepted dossier is the ratio of total simulated costs to total accepted dossiers, including zero-acceptance worlds. It is $695.75 at day 84 and $690.26 after the existing commitments settle. The latter includes completion of work already booked and cannot be read as a separate operating horizon. The Monte Carlo interval for the mean operating profit is $6,302.65–$7,235.99; it measures sampling error within this model, not uncertainty about the real world.

At fixed sales volume, approximately $313.95 of additional expense per booking consumes the modeled mean profit. Finite cash can change admission and volume, so the full extra-cost scenarios above are the appropriate comparison when the cost actually changes. [R3]

A negative optional-retention result does not erase a viable direct-delivery scenario. The selected policy pays its assessment expense, declines extra retention investment and continues serving the analytical offering. Additional retention is an investment decision with its own opportunity cost. [R3]

<!-- PAGEBREAK -->

## 12. Frontier intelligence, Operational Alpha and retained Alpha

Official documentation was checked on October 27, 2026. The modeled configuration uses `gpt-6-astra` at high reasoning effort for difficult discovery and judgment, `gpt-6.1-terra` at medium effort for suitable execution, and `claude-fable-5-1` with adaptive/high effort for independent review. Standard token prices are respectively $10/$50, $1/$5 and $10/$50 per million input/output tokens. Gemini `gemini-4-argon` is a verified alternative at promotional $2/$10 through November 30, then $4/$20; its computer use remains Preview. Documentation describes availability and interfaces, not mission reliability. [8–13]

The cost configuration assumes multiple requests below 200,000 input tokens each. It does not apply an unearned caching discount or ignore reasoning output. Astra and Terra long-context price uplifts must be applied if future requests cross their documented threshold. Tool-generated computer actions still require an execution environment. A consumer subscription does not establish unlimited automated commercial capacity, and closed-model weights are not modified. [8–10]

| Comparison | Meaning | Evidence in this edition |
|---|---|---|
| H | Equivalent human analytical service | Sourced wage anchors; explicit estimated hours, overhead and selling margin |
| U | Representative ordinary operation of the same frontier models | Mission-level behavior unmeasured; no weakened ordinary-user trial is manufactured |
| E | Expert context, decomposition, source grounding, tools, checking and recovery | The service construction is executed; autonomous repeated-job cost and reliability remain modeled |
| E+ | E plus an additionally retained capability | Actual predictive artifact transfers; additional frontier-service gain is unmeasured and includes zero/negative scenarios |
| Ordinary reusable library | Identical rights-cleared instrument and information | Exact prediction parity; same modeled maintenance and invocation costs |

The normalized-voltage versus raw-voltage result is a conventional feature-construction comparison. It is not E versus U. Likewise, lower refitting work from loading a model is not automatically additional retained Alpha if normal expert operation already retains its models. No controlled frontier-agent campaign supports a numerical Operational Alpha claim here.

A transparent break-even calculation replaces an invented Operational Alpha percentage. If expert operation costs $75 more per attempt and price, demand, scope and terms remain equal, it needs approximately **7.125 percentage points more final dossier acceptance** to cover that increment under the stated support and refund model. Hypothetical premiums of $25 and $150 require approximately 2.375 and 14.250 points. These are thresholds to test, not observed performance differences. [R3]

The business model therefore admits profitable direct delivery independently of these unmeasured increments. It also evaluates a small retained-capability uncertainty family containing negative transfer, no benefit and possible benefit. Retention is rejected after its additional assessment cost. The extra investment has a complete declared budget: $80 assessment, $170 extraction/retention, $20 per week maintenance and $3 per invocation; category C is zero. The development mixture assigns weight 0.25 to negative transfer (5% extra resource use and 3 percentage points lower acceptance), 0.50 to no benefit, and 0.25 to possible benefit (25% resource savings and 3 points higher acceptance). Its weighted development available-funds increment is −$349.81 after assessment, so admission is declined. In fresh confirmation, charging the rejected assessment produces $6,687.13 mean profit, a paired −$82.18 versus direct delivery including small financing effects. Its available-funds gain after restrictions and excluding seed is $5,960.24, versus $6,041.97 for direct delivery. Forced retention under zero benefit loses a paired $566.44. These figures do not estimate actual research extraction expense. An identical ordinary library shares any modeled reuse benefit; provenance or graph membership alone creates no demonstrated moat. [R3–R4]

## 13. What the next agent inherits

The successor receives an actual learned predictive instrument: forest parameters, the calibration quantile, version, source hashes, rights, dependency declaration and failure scope. A separately supplied inference module is bound by hash. The artifact does not include protected confirmation answers, secrets or customer material. Its training came from this research exercise, not a paid originating customer job. [R2–R4]

The existing source-pinned integration closure is reused: 29 vendored native files plus five bridge files. Actual encrypted transport and signature checks execute locally. The recipient runs the received instrument in a separate process on all 30 fresh successor requests. The prior 0.80 mission grant cannot authorize the new 0.75 purpose. Changed model, code or input, revoked or expired authority and nonce reuse are refused. The ordinary library produces exactly the same output. Forty-four integration controls pass. [R4]

This applies the inherited rule: **REUSE stable structure. RECHECK the new mission's meaning. REGRANT authority separately.** The new capacity purpose remains explicit. Current production capsule admission refuses the battery scope because the unchanged schema only admits its existing bounded scope. Local `*.agent.agi.eth` names and authorizations are fixtures, not live ENS authentication. No production authority is silently broadened. [17; R4]

The next opportunity is to turn a buyer's independently labeled data into a fresh qualified testing policy, perhaps with better cohort-specific uncertainty and operational measurement evidence. A second useful specialist could optimize the choice of additional measurements under the buyer's budget. That extension should be admitted only after its combined incremental value, coordination, rights, costs and falsifier are specified. It is an opportunity, not an established superhuman specialist or self-accelerating enterprise.

## 14. From bounded service to a larger business

The first attainable customer is an organization already holding rights-cleared pulse and capacity measurements and deciding whether to invest in a diagnostic process. A repeatable service could extend to recurring qualification, changed supplier populations, laboratory partnerships and licensed diagnostic-validation workflows. Scale would come from additional accepted customer decisions and lower repeat delivery effort, with capacity and maintenance measured along the way.

Defensibility would need to arise from trusted customer relationships, authorized data access, credible validation, useful integrations and accumulated evidence. The present open instrument can be copied under its stated rights; the study demonstrates no exclusive algorithm or graph moat. Addressable battery demand is not the same as reachable buyers of this particular dossier. No headline battery-market size is converted into enterprise value.

This study's commercial accounts are in USD. It executes no new `$AGIALPHA` settlement or payment path and establishes no new token utility or token valuation. Productive service surplus, conditional investment funds and token appreciation remain distinct. The existing ecosystem's roles and restrictions are preserved.

## 15. The smallest next validation that changes the decision

The next useful step is a **single scoped buyer pilot**: obtain a rights-cleared dataset from a battery-reuse organization, agree in advance that the purchased outcome is a complete qualification decision, and record actual token, tool, correction, verification, support and collection data. A supplier quote or competent human time study would calibrate the human comparison. Three scoped price conversations would help distinguish interest from willingness to pay; none has been initiated by this study.

Physical deployment requires a separate prospectively designed measurement campaign. It must validate the shorter standalone protocol, temperature and history shifts, real acquisition costs, relevant error losses and conditional decision risk. A cohort-aware uncertainty control and a stronger diagnostic policy search should receive the same information and budget. New calibration is needed before a new population is admitted.

For an Operational Alpha claim, freeze a representative ordinary-user workflow and the expert workflow on the same frontier models and tools, then compare accepted outcomes on fresh buyer-like tasks. For retained Alpha, charge only incremental extraction, qualification, invocation and maintenance, compare an ordinary identical-information library, and include failed assessments. A null improvement is compatible with a valuable service.

The present achievement is concrete: a documented opportunity became an executable analytical offering; its real-data evidence transfers into fresh work; and its commercial model supports a conditional positive result while identifying the costs, alternatives and assumptions that can overturn it. The enterprise becomes better equipped to choose its next experiment because those distinctions remain visible.

<!-- PAGEBREAK -->

## Appendix A. Complete connected example

**1. Discover the need.** A hypothetical reuse operator has measurements and a proposed capacity threshold, but lacks a reliable connection from model accuracy to its actual testing obligation. This is the scoped customer model, not an observed customer.

**2. Construct the instrument.** The study validates cell identities and source bytes, excludes target-bearing information, fits the frozen candidate family, calibrates by physical cell and exports the selected parameters. Its computational delivery contract passes 41/41 checks. [R2]

**3. Produce a useful disposition.** For originating cell `NMC_21|02LCC02100101A87Y0010168`, the retained model predicts 0.99460 SOH and returns interval [0.80941, 1.17979]. The lower endpoint exceeds the 0.80 requirement. The retrospective reference is 1.00329. Values above 1 are possible because the denominator is nominal capacity; the analysis does not clip favorable observations to 1.00. [R2]

**4. Preserve a hard case.** For originating LFP cell `14号`, the prediction is approximately 0.8393 but its wide interval crosses 0.80. It remains a full-test obligation even though the point estimate exceeds the requirement. All 31 originating cells retain a disposition, and all 12 outside-population stress cells require requalification.

**5. Price the actual offering.** The modeled $1,084.61 fee purchases the complete analytical dossier. The $25 illustrative physical-test cost belongs to the customer testing scenario. It is neither included in provider receipts nor silently omitted from customer expense. Refundable deposits remain liabilities until analytical acceptance. [R3]

**6. Retain and reauthorize.** A separate recipient process receives the actual model bytes and a fresh 0.75-threshold mission. It evaluates 30 different cells, with 8 capacity dispositions and 22 full-test referrals. Its output matches the identical ordinary library. Production battery scope remains refused. [R4]

**7. Choose the next investment.** The technical handoff succeeds. The additional commercial retention policy is nevertheless declined under the frozen uncertainty and cost assumptions. The enterprise may continue direct delivery while collecting better evidence for a later investment.

## Appendix B. Failures, corrections and limitations

**Portability failure preserved.** The first independent JSON tree walker used Python double precision at branch comparisons while sklearn converts feature inputs to float32. Development verification failed. The original source and partial models remain in `evidence/development_attempt_1/`; the repaired implementation has a direct boundary regression and calibration agreement within approximately 1.1 × 10^-15.

**Scope and metadata repairs.** An early input path could raise on missing cohort metadata, and the first context interface did not enforce the declared protocol. Independent synthetic probes exposed these problems before confirmation. The final interface routes malformed observations and unknown context to full testing. It relies on asserted metadata and does not inspect a physical laboratory.

**Financial corrections preserved.** The first exploratory economic implementation used future realized resource draws in its admission decision and omitted predictable fees on outstanding accepted invoices from interim accrual costs. These were corrected before a new development search and disjoint fresh confirmation. The old code, configuration and results, including a completed first confirmation, remain archived as superseded pre-correction evidence. No favorable original profit is relabeled as the corrected primary result. [R3]

**Scientific limits.** The sample is small, the three retired-cell cohorts are specific, and all decisive outcomes come from one cohort. Calibration intervals are wide. Strong conventional controls match or exceed important outcomes. Published processed data cannot establish standalone protocol performance, broad temperature robustness, battery safety or prospective commercial acceptance. The homogeneous-radius method is deliberately bounded; more capable cohort-aware uncertainty methods remain a relevant next control.

**Commercial limits.** Demand, buyer values, service success, token usage, insurance availability and real business cost remain unmeasured. Report acceptance is computational. Actual collections are zero. Modeled profit is conditional forward operating profit, not recovery of the unknown complete cost of this research exercise.

**Implementation limits.** The integration executes on Python 3.12.14 and Node 24.22.1 using an unchanged source-pinned research bridge. This is not qualification of the repository's full runtime or required release platforms. No software release, canonical Pages deployment, live ENS authorization or physical execution is inferred from local checks.

## Appendix C. Reproduction and evidence map

The complete companion contains input workbooks and licenses; frozen protocols; selected model and ordinary controls; physical-cell assignments; all per-cell confirmation records; commercial development grids, freezes and fresh worlds; transport and accounting evidence; figures; source manuscripts; and reproduction instructions. The retained instrument uses the Python standard library for inference. Training uses the pinned scientific dependencies recorded in `requirements-study.txt`.

Run `python src/reproduce.py` from the study directory to rebuild in an isolated temporary copy and compare deterministic numerical results. The command preserves the delivered originals. Individual commands and expected evidence identities are in `REPRODUCE.md`. Actual runtime observations are descriptive and may vary by machine; source and artifact identity and numerical acceptance are checked separately.

| Claim family | Primary evidence |
|---|---|
| Opportunity selection and prior art | `evidence/opportunity_dossier.json`; `evidence/data_sources.json` |
| Prospective technical policy | `config/technical_protocol.json`; `results/technical_freeze.json` |
| Origin and fresh successor results | `results/origin_confirmation.json`; `results/successor_confirmation.json` |
| Computational delivery acceptance | `results/delivery_acceptance.json`; `tests/test_instrument.py` |
| Commercial prices, costs and participation | `config/commercial_protocol.json`; `src/economics.py`; `results/economics_confirmation.json` |
| Exact retained instrument | `results/retained_instrument.json`; `src/instrument.py` |
| Actual transport, library parity and authority | `integration/results/confirmation-01/summary.json`; `integration/validation_record.json` |
| Foundational continuity and publication scope | `evidence/continuity.json` |

The source edition is additive to inspected repository main `47c17f6aca6b1bb8779dd3e47d5ba5f8af3329f4`. It changes only the new study directory. Existing paper originals, source histories, active owners and publication gates are preserved. The browser-readable manuscript and downloadable PDF are an immutable research source edition, distinct from canonical website or software publication. [R4]

## Appendix D. The bounded commercial policy search

The table reports development means over seeds 281000–281199, before fresh confirmation. The objective is available funds gained at day 84 after restrictions and excluding the original seed; operating profit is shown separately. The full grid includes no launch, and higher prices can reduce demand enough to destroy value. No global optimum or empirical demand estimate is implied. [R3]

| Price / human reference | Refundable deposit | Accepted dossiers | Operating profit | Available-funds gain |
|---|---:|---:|---:|---:|
| 25% | 25% | 27.86 | $1,336.00 | −$2,666.78 |
| 25% | 50% | 34.72 | $2,581.55 | −$1,174.16 |
| 25% | 100% | 35.59 | $2,761.17 | $1,985.19 |
| 50% | 25% | 16.91 | $6,329.77 | $1,094.49 |
| 50% | 50% | 17.04 | $6,406.15 | $2,621.15 |
| 50% | 100% | 16.84 | $6,337.53 | $5,633.33 |
| 75% | 25% | 2.10 | −$3,175.00 | −$4,463.11 |
| 75% | 50% | 2.09 | −$3,198.88 | −$4,291.82 |
| 75% | 100% | 1.92 | −$3,382.12 | −$3,996.01 |
| No launch | 0% | 0.00 | $0.00 | $0.00 |

The selected 50%-reference price and 100% deposit are fixed before seeds 991000–991999. The independent financial review exercises future-fee accrual, default, refunds, support, seed accounting, nonanticipation and restricted deposits; all eight controlled corrected probes pass. The original failed financial audit remains accessible.

## References

**[1]** Tao, S. et al. (2024). *Generative learning assisted state-of-health estimation for sustainable battery recycling with random retirement conditions*. Nature Communications 15, 10154. [doi:10.1038/s41467-024-54454-0](https://www.nature.com/articles/s41467-024-54454-0).

**[2]** PulseBat author repository. *Pulse Voltage Response Generation: dataset, experimental protocol and processed features*. Immutable commit [92aeb9b8a26bc337164401411271fa8eeadf605c](https://github.com/terencetaothucb/Pulse-Voltage-Response-Generation/tree/92aeb9b8a26bc337164401411271fa8eeadf605c). MIT license; retrieved October 27, 2026.

**[3]** Tao, S. et al. (2025). *PulseBat: A field-accessible dataset for second-life battery diagnostics from realistic histories using multidimensional rapid pulse test*. [arXiv:2502.16848](https://arxiv.org/abs/2502.16848).

**[4]** Angelopoulos, A. N. and Bates, S. (2021). *A Gentle Introduction to Conformal Prediction and Distribution-Free Uncertainty Quantification*. [arXiv:2107.07511](https://arxiv.org/abs/2107.07511). Related battery prior art: da Silva, S. F. et al. (2026), *Conformalized Transfer Learning for Li-ion Battery State of Health Forecasting under Manufacturing and Usage Variability*, [arXiv:2603.24475](https://arxiv.org/abs/2603.24475).

**[5]** U.S. Bureau of Labor Statistics. *Data Scientists, Occupational Outlook Handbook*. May 2025 wage statistics; retrieved October 27, 2026. [Official source](https://www.bls.gov/ooh/math/data-scientists.htm).

**[6]** U.S. Bureau of Labor Statistics. *Electrical and Electronics Engineers, Occupational Outlook Handbook*. May 2025 wage statistics; retrieved October 27, 2026. [Official source](https://www.bls.gov/ooh/architecture-and-engineering/electrical-and-electronics-engineers.htm).

**[7]** U.S. Bureau of Labor Statistics. *Employer Costs for Employee Compensation, June 2026*. [Official release](https://www.bls.gov/news.release/ecec.nr0.htm).

**[8]** OpenAI. *GPT-6 Astra model documentation*. Exact API identifier, supported reasoning, tools and standard prices; retrieved October 27, 2026. [Official documentation](https://developers.openai.com/api/docs/models/gpt-6-astra).

**[9]** OpenAI. *GPT-6.1 Terra model documentation*. [Official documentation](https://developers.openai.com/api/docs/models/gpt-6.1-terra).

**[10]** OpenAI. *API pricing and computer-use guide*. [Pricing](https://developers.openai.com/api/docs/pricing); [computer use](https://developers.openai.com/api/docs/guides/tools-computer-use).

**[11]** Anthropic. *Claude Fable 5.1 overview and computer-use documentation*. [Model documentation](https://platform.claude.com/docs/en/models/fable-5-1/overview); [computer use](https://platform.claude.com/docs/en/agents-and-tools/tool-use/computer-use-tool). Retrieved October 27, 2026.

**[12]** Google. *Gemini 4 Argon model documentation*. [Official documentation](https://ai.google.dev/gemini-api/docs/models/gemini-4-argon).

**[13]** Google. *Gemini Developer API pricing*. [Official pricing](https://ai.google.dev/gemini-api/docs/pricing). October 27, 2026 snapshot; promotional expiry is explicitly modeled as a future price condition.

**[14]** Texas Instruments. *OPA602 product and replacement information*. [Official product page](https://www.ti.com/product/OPA602); [OPA602BP status](https://www.ti.com/product/OPA602/part-details/OPA602BP). Used only for opportunity comparison.

**[15]** Boucher, V. *Transformational Intelligence: Learning to Change the Game*. [Immutable source](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/blob/47c17f6aca6b1bb8779dd3e47d5ba5f8af3329f4/docs/Transformational_Intelligence.tex).

**[16]** Boucher, V. *Invent the Economy: Transformational Intelligence for Creating Viable Markets*. [Immutable source](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/blob/47c17f6aca6b1bb8779dd3e47d5ba5f8af3329f4/docs/Invent_the_Economy.tex).

**[17]** MONTREAL.AI. *Transformational Autonomous Enterprises — SUCCESSOR Ω Harness: Mission-Relative Revalidation for Capability Inheritance Across Four Execution Systems*. [Immutable source](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/blob/47c17f6aca6b1bb8779dd3e47d5ba5f8af3329f4/docs/papers/transformational-autonomous-enterprises-v1.tex).

**[18]** Boucher, V. *Autonomous Enterprises — Activate. Evolve. Scale. — SUCCESSOR Ω Harness*. [Immutable source](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/blob/47c17f6aca6b1bb8779dd3e47d5ba5f8af3329f4/docs/Autonomous_Enterprises_SUCCESSOR_Omega.tex).

**[R1]** This study. Opportunity dossier, immutable source provenance and preconfirmation audit, `evidence/`.

**[R2]** This study. Frozen technical protocol, complete fitted models and physical-cell confirmation records, `config/technical_protocol.json` and `results/`.

**[R3]** This study. Corrected commercial protocol, full development policy grid, disjoint fresh confirmation and retained exploratory failures, `config/commercial_protocol.json`, `src/economics.py` and `results/economics*`.

**[R4]** This study. Existing native integration, actual received-byte execution, identical-library comparator, source identities and continuity ledger, `integration/` and `evidence/continuity.json`.
