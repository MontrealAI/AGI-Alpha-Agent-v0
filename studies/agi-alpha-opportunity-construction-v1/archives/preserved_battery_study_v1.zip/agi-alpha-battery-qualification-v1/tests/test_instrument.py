# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import copy
import json
import sys
import unittest
from pathlib import Path
from typing import Any

import numpy as np
from sklearn.ensemble import RandomForestRegressor

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from instrument import MEASUREMENT_CONTEXT, estimate, features, predict


class InstrumentBoundaries(unittest.TestCase):
    def setUp(self) -> None:
        self.artifact: dict[str, Any] = {
            "method": "two_pulse_raw",
            "allowed_cohorts": ["LMO_10"],
            "calibration_q": 0.01,
            "measurement_context": copy.deepcopy(MEASUREMENT_CONTEXT),
            "trees": [
                {
                    "left": [1, -1, -1],
                    "right": [2, -1, -1],
                    "feature": [0, -2, -2],
                    "threshold": [0.5, -2, -2],
                    "value": [0.85, 0.7, 1.0],
                }
            ],
        }
        self.request: dict[str, Any] = {
            "capacity_threshold": 0.8,
            "measurement_context": copy.deepcopy(MEASUREMENT_CONTEXT),
            "observation": {"Mat": "LMO", "Qn": 10, **{f"U{i}": 0.5 for i in range(1, 22)}},
        }

    def assert_fallback(self, result: dict[str, Any]) -> None:
        self.assertTrue(result["requires_full_test"])
        self.assertEqual(result["disposition"], "full_capacity_test")
        self.assertFalse(result["physical_release_authorized"])

    def test_float32_split_matches_independent_sklearn_prediction(self) -> None:
        rows = [copy.deepcopy(self.request["observation"]) for _ in range(4)]
        for row, value in zip(rows, [0.25, 0.25, 0.75, 0.75], strict=True):
            row["U1"] = value
        matrix = np.array([features(row, "two_pulse_raw") for row in rows])
        forest = RandomForestRegressor(n_estimators=1, bootstrap=False, max_depth=1, random_state=3)
        forest.fit(matrix, [0.7, 0.7, 1.0, 1.0])
        tree = forest.estimators_[0].tree_
        artifact = copy.deepcopy(self.artifact)
        artifact["trees"] = [
            {
                "left": tree.children_left.tolist(),
                "right": tree.children_right.tolist(),
                "feature": tree.feature.tolist(),
                "threshold": tree.threshold.tolist(),
                "value": tree.value[:, 0, 0].tolist(),
            }
        ]
        self.request["observation"]["U1"] = 0.50000001
        vector = features(self.request["observation"], "two_pulse_raw")
        expected = float(forest.predict([vector])[0])
        self.assertEqual(expected, 0.7)
        self.assertEqual(estimate(artifact, self.request["observation"]), expected)

    def test_missing_and_invalid_identity_preserve_full_test(self) -> None:
        for key in ["Mat", "Qn"]:
            with self.subTest(missing=key):
                request = copy.deepcopy(self.request)
                del request["observation"][key]
                self.assert_fallback(predict(self.artifact, request))
        for value in [None, "unavailable", float("nan"), float("inf"), 0, -10]:
            with self.subTest(capacity=value):
                request = copy.deepcopy(self.request)
                request["observation"]["Qn"] = value
                self.assert_fallback(predict(self.artifact, request))

    def test_unknown_cohort_is_requalified(self) -> None:
        self.request["observation"].update(Mat="NMC", Qn=2.1)
        result = predict(self.artifact, self.request)
        self.assert_fallback(result)
        self.assertEqual(result["scope"], "outside_calibrated_cohorts")

    def test_missing_measurements_preserve_full_test(self) -> None:
        for key in ["U1", "U5", "U9"]:
            with self.subTest(missing=key):
                request = copy.deepcopy(self.request)
                del request["observation"][key]
                self.assert_fallback(predict(self.artifact, request))

    def test_nonfinite_and_outlier_measurements_preserve_full_test(self) -> None:
        for value in [None, "missing", float("nan"), float("inf"), -float("inf"), 0, -0.01, 6, 6.1, 1e100]:
            with self.subTest(voltage=value):
                request = copy.deepcopy(self.request)
                request["observation"]["U1"] = value
                self.assert_fallback(predict(self.artifact, request))

    def test_missing_context_preserves_full_test(self) -> None:
        del self.request["measurement_context"]
        self.assert_fallback(predict(self.artifact, self.request))

    def test_changed_protocol_temperature_and_unit_preserve_full_test(self) -> None:
        changes = {
            "temperature_c": -20,
            "pulse_width_s": 0.03,
            "pulse_rest_s": 0,
            "voltage_unit": "mV",
            "retrospective_context": "new_field_cell",
        }
        for field, value in changes.items():
            with self.subTest(field=field):
                request = copy.deepcopy(self.request)
                request["measurement_context"][field] = value
                result = predict(self.artifact, request)
                self.assert_fallback(result)
                self.assertEqual(result["scope"], "unverified_measurement_context")

    def test_invalid_thresholds_are_errors_not_decisions(self) -> None:
        for value in [None, "unknown", float("nan"), float("inf"), 0, -1, 1.2001]:
            with self.subTest(threshold=value):
                request = copy.deepcopy(self.request)
                request["capacity_threshold"] = value
                with self.assertRaises((TypeError, ValueError)):
                    predict(self.artifact, request)

    def test_no_pulse_control_requires_no_voltage_values(self) -> None:
        artifact = {**self.artifact, "method": "chemistry_median", "medians": {"LMO_10": 0.9}}
        self.request["observation"] = {"Mat": "LMO", "Qn": 10}
        result = predict(artifact, self.request)
        self.assertEqual(result["point"], 0.9)
        self.assertEqual(result["disposition"], "capacity_at_least_threshold")
        self.assertFalse(result["physical_release_authorized"])

    def test_target_and_filename_fields_do_not_change_prediction(self) -> None:
        before = predict(self.artifact, self.request)
        self.request["observation"].update(
            Q=1000, SOH=100, SOC=95, SOCR=1, SOE=1, File_Name="leak_SOC_5-95", ID="protected", maximum_SOC=95
        )
        self.assertEqual(predict(self.artifact, self.request), before)

    def test_intervals_crossing_capacity_requirement_retain_full_test(self) -> None:
        self.artifact["calibration_q"] = 0.15
        result = predict(self.artifact, self.request)
        self.assert_fallback(result)
        self.assertLess(result["lower"], self.request["capacity_threshold"])
        self.assertGreater(result["upper"], self.request["capacity_threshold"])

    def test_decisive_outputs_remain_finite_and_never_authorize_release(self) -> None:
        for voltage, expected in [(0.25, "capacity_below_threshold"), (0.75, "capacity_at_least_threshold")]:
            with self.subTest(voltage=voltage):
                request = copy.deepcopy(self.request)
                request["observation"]["U1"] = voltage
                result = predict(self.artifact, request)
                self.assertEqual(result["disposition"], expected)
                self.assertFalse(result["physical_release_authorized"])
                json.dumps(result, allow_nan=False)


if __name__ == "__main__":
    unittest.main()
