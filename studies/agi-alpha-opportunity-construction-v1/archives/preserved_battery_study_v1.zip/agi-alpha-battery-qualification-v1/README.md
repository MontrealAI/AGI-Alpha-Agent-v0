# AGI ALPHA FLYWHEEL — When Capability Creates Opportunity

## Transformational Intelligence, Experience-Trained Specialists and the Expanding Frontier of Profitable Work

**Vincent Boucher — President of MONTREAL.AI**

Research edition 1.0.0 · 27 October 2026 · Additive battery-diagnostic qualification study.

## Read the result

- [Publication manuscript](paper/PAPER.md) · [PDF](paper/paper.pdf)
- [Executive brief](paper/EXECUTIVE_BRIEF.md) · [PDF](paper/executive_brief.pdf)
- [Connected example](paper/CONNECTED_EXAMPLE.md) · [PDF](paper/connected_example.pdf)
- [Approval-ready LinkedIn draft](paper/LINKEDIN_DRAFT.md) — not posted
- [Self-contained HTML edition](web/index.html) — download and open locally
- [Reproduction instructions](REPRODUCE.md)

The constructed offering is a **48-hour analytical battery-diagnostic qualification dossier**, using supplied labeled data for up to three known cell families. Acceptance concerns the validity and completeness of that report, including a well-supported no-go or full-test recommendation. No physical safety release is authorized.

## Strongest supported results

| Evidence layer | Result | Boundary |
|---|---|---|
| Actual technical execution | Selected two-pulse MAE 2.94 percentage points on 31 origin cells; 2.81 points on 30 fresh successor cells | All 14 decisive capacity cases are NMC 21 Ah; 47 known-population cases retain full-test obligations and 12 outside-population cells require requalification |
| Actual computational acceptance | 41/41 delivery checks; 12 instrument boundary tests | Software acceptance, not observed customer or physical acceptance |
| Complete customer testing scenario | Selected policy costs $37.60 more than strong five-pulse control on origin and $12 less on successor | No general superiority; small batches do not recover the dossier fee through testing savings |
| Conditional direct-service economics | $1,084.61 price; $6,769.32 mean 12-week operating profit; 5th–95th percentile −$3,566.31 to $20,597.38 | 1,000 hypothetical worlds; demand, mission performance and costs remain assumptions |
| Rejected assessment in enterprise accounts | $6,687.13 mean profit after additional assessment | Extra retention declined; no forced Gym campaign |
| Actual transfer | Actual model executed in a separate process; 44/44 integration controls | Identical ordinary library ties; fixture authorization only, unchanged production schema refuses battery scope |
| Operational Alpha | Unmeasured | Feature engineering is not a same-model U/E agent comparison |
| Actual commercial realization | Customer collections $0 | Complete realized construction cost and research profit unknown |

## What is inside

`data/` contains immutable source workbooks, original MIT license and author README. `config/` contains technical and corrected commercial policies. `src/` contains portable inference, training/evaluation, economics, figures, acceptance and publication builders. `results/` includes per-cell outcomes, trained controls, all commercial worlds and explicit superseded exploration. `evidence/` contains source provenance, opportunity search, commitments, corrections, independent audits and reproducibility/visual checks. `integration/` contains the source-pinned native bridge, actual recipient execution, ordinary-library comparison and authority refusals.

The technical freeze precedes originating and successor evaluation. The corrected economic development uses seeds 281000–281199 and fresh confirmation uses 991000–991999. The earlier defective economics revision is preserved with its completed first confirmation as superseded pre-correction evidence; it is not a primary result.

## Start

Use Python 3.12 with the pinned dependencies and Node 24 as described in [REPRODUCE.md](REPRODUCE.md), then run:

```bash
python src/reproduce.py
```

Reproduction uses a temporary isolated copy and leaves the delivered results unchanged. Original training and inference code commitments remain frozen. No network, model API, customer account, private key or paid service is needed to reproduce the computational study. Public source URLs and retrieval evidence are preserved for provenance.

## Scope, rights and continuity

This directory is additive to inspected repository commit `47c17f6aca6b1bb8779dd3e47d5ba5f8af3329f4`. It preserves current publication and runtime owners and does not change root runtime, release workflows or existing studies. The Markdown/PDF files form a research source edition; canonical website or software release is a separate process.

New study code is Apache-2.0 under the repository license. The public measurement files retain their upstream MIT license in `data/LICENSE`. Vendored prior implementation files preserve their exact source bytes, licenses and source manifest in `integration/upstream/`. No customer secrets, protected evaluation material or private signing keys are included. The study adds no live `$AGIALPHA` payment implementation and makes no token-value claim.
