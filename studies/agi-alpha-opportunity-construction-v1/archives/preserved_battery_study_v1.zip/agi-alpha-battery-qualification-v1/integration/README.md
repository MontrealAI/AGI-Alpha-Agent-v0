# Existing-interface integration

This directory adds a research adapter around unchanged existing AGI ALPHA interfaces. The fitted JSON instrument is the actual payload. The recipient gets no protected confirmation labels, old customer answer, current acceptance or live authority.

## Reproduce

From the battery study root, after technical construction has produced the retained instrument and fresh successor requests:

```sh
python -B integration/run_native_integration.py \
  --artifact results/retained_instrument.json \
  --request results/successor_requests.json \
  --engine src/instrument.py \
  --out integration/results/reproduction-01
```

The destination must be new. Replaying the supplied observations reproduces evidence; it is not another independent confirmation. Python 3.12, `cryptography` and `pydantic` plus Node are required; the study's inference dependencies must also be installed.

## What runs

The five frozen bridge files and 29 vendored source/license files total 529,546 bytes. Every file is checked before import. They retain adapter source `231834269599d85e49cfe1ca9917a1a874522d44`, native source `80b345828f34fd8a6e592977dd17ef37141305f4` and research lifecycle source `2727262caa52766a78916f2ed81f5afaf668edce`. These pins describe a research dependency; they do not assert current installed-system qualification.

The preserved 29-control conformance assay exercises actual artifact transport, encryption, signatures, member restrictions, revocation, artifact-integrity checks and native accounting. Its favorable monetary pairs are artificial protocol fixtures. They do not admit the fitted battery instrument as empirical Alpha.

The new wrapper then:

1. Checks that source, recovered and ordinary-library instrument bytes are identical.
2. Attempts the battery scope against the unchanged native capsule schema and records its refusal. The actual allowed literal remains `bounded-public-source-selection/v1`.
3. Records unknown actual A/B/C expenses in the existing signed cost ledger. Complete actual profit and available funds stay unknown; actual customer collections are zero. Separate economics simulations are not bank receipts or paid research work.
4. Binds the current mission, observations, fitted model and inference source to a separately configured local research grant. The original 0.80-capacity request cannot authorize the new 0.75-capacity request.
5. Executes the actual received fitted instrument in a fresh Python process on the technical study's different successor cells, with no labels supplied to inference. It runs the identical ordinary-library artifact under the same current mission and compares every prediction.
6. Uses the existing native Journal to consume one-use grants and refuses replay, changed model/source/mission, expired authority and revoked controller.

The recipient reports current capacity thresholds unchanged. Independent technical acceptance remains in the technical study: successful transport and equal predictions do not prove prediction accuracy, economic value, physical safety or authorization for reuse.

## Evidence boundaries

Identities such as `lyra.agent.agi.eth`, membership and mission authorization are local fixtures. Ed25519 and encrypted byte transport execute, but no live ENS authentication or production registration occurs. Ephemeral private signing and journal keys are never included in published artifacts. Public context and signed fixture grants may be retained as evidence; they confer no live authority.

The engine supplied at `src/instrument.py` is a separately provided dependency, hash-bound before and after inference. The payload contains fitted instrument parameters and declared calibration, scope and provenance. The runtime must independently supply compatible inference code. This demonstrates transfer of an executable predictive instrument under those dependencies, not unrestricted code or model-weight acquisition by a recipient.

Separate local processes are a reproducibility boundary, not a production sandbox or independent organization. Ordinary-library parity preserves the conventional control. This experiment supplies no frontier U-versus-E performance estimate and no measured additional monetary Alpha.

## Rights and unchanged source

The copied sources retain their Apache-2.0 license and source manifest. New adapter files use Apache-2.0. Battery data rights and source provenance remain in `../data` and `../evidence`; no customer-restricted material or protected labels are added to the shared instrument. Source records and foundation corrections are in `../evidence/continuity.json`.
