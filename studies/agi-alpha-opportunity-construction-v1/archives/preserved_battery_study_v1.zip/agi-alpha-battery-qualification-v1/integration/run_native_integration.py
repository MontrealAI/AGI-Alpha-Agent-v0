# SPDX-License-Identifier: Apache-2.0
"""Thin study-local adapter for byte transfer, fresh inference and explicit refusal."""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Any

from binding import DOMAIN, MODE, PINS, RECIPIENT, ROOT, bind, load_upstream, native_trust, read, requests, save, sha

CATEGORIES = ["model", "tools", "compute", "storage", "network", "human", "acceptance", "correction", "overhead"]


def unknown_commands(artifact_sha256: str) -> list[dict[str, Any]]:
    """Keep unmetered, disjoint work unknown rather than silently entering zero expense."""
    scopes = {
        "A": "qualification-mission-production",
        "B": "extra-retention-transport-invocation-and-maintenance",
        "C": "experimental-construction-before-mission-production",
    }
    commands = []
    for bucket, mission in scopes.items():
        for category in CATEGORIES:
            commands.append(
                {
                    "action": "charge",
                    "record": {
                        "activity_id": f"battery-unmetered-{bucket}-{category}",
                        "mission_id": mission,
                        "bucket": bucket,
                        "category": category,
                        "accrued_micro_usd": None,
                        "paid_micro_usd": 0,
                        "basis": "unknown",
                        "evidence_digest": hashlib.sha256((artifact_sha256 + bucket + category).encode()).hexdigest(),
                        "note": "Unreconciled actual research expense. No recorded payment is not zero cost; modeled scenarios are separate.",
                    },
                }
            )
    return commands


def native_battery_scope(artifact_sha256: str) -> dict[str, Any]:
    """Exercise the unchanged native schema with actual artifact identity and new scope."""
    native_trust()
    from pydantic import ValidationError
    from alpha_factory_v1.core.runtime.successor.flywheel_capsules import CapsuleManifest
    from alpha_factory_v1.core.runtime.successor.protocol import digest

    baseline = {
        "skill_id": "battery-capacity-instrument",
        "version": 1,
        "origin_mission": "retrospective-battery-qualification-research",
        "origin_record_digest": digest("battery-fixture-origin", {"research_fixture": True}),
        "origin_agent": "atlas.agent.agi.eth",
        "origin_wallet": "0x" + "11" * 20,
        "content_digest": artifact_sha256,
        "supported_scope": "bounded-public-source-selection/v1",
        "prerequisites": [],
        "limitations": "Schema validation control only. Battery scope must be refused; no live ENS or production claim.",
        "rights": "cleared-for-authenticated-network",
        "rights_evidence": digest("battery-fixture-rights", {"research_fixture": True}),
        "dependency_digests": [],
    }
    CapsuleManifest.model_validate(baseline)
    attempted = {**baseline, "supported_scope": "retrospective-battery-capacity-qualification/v1"}
    try:
        CapsuleManifest.model_validate(attempted)
    except ValidationError as exc:
        errors = [{"loc": list(e["loc"]), "type": e["type"]} for e in exc.errors()]
        passed = {"loc": ["supported_scope"], "type": "literal_error"} in errors
        return {
            "passed": passed,
            "unchanged_allowed_scope": baseline["supported_scope"],
            "attempted_scope": attempted["supported_scope"],
            "artifact_sha256": artifact_sha256,
            "errors": errors,
            "decision": "NOT_QUALIFIED_UNSUPPORTED_BATTERY_SCOPE",
            "boundary": "Allowed-scope control validates schema shape only; it does not admit the battery instrument.",
        }
    return {"passed": False, "decision": "UNEXPECTED_BATTERY_SCOPE_ACCEPTANCE"}


def execute_recipient(
    artifact: Path, request: Path, engine: Path, grant: Path, context: Path, journal: Path, output: Path
) -> dict[str, Any]:
    """Launch fresh local Python; no shell, external credentials or inherited acceptance."""
    command = [sys.executable, "-B", str(ROOT / "recipient.py")]
    for key, path in (
        ("artifact", artifact),
        ("request", request),
        ("engine", engine),
        ("grant", grant),
        ("context", context),
        ("journal", journal),
        ("output", output),
    ):
        command += ["--" + key, str(path)]
    environment = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1", "PYTHONHASHSEED": "0"}
    started = time.perf_counter()
    process = subprocess.run(
        command, cwd=ROOT, env=environment, capture_output=True, text=True, timeout=90, check=False
    )
    return {
        "returncode": process.returncode,
        "elapsed_seconds": time.perf_counter() - started,
        "stdout": process.stdout,
        "stderr": process.stderr,
        "report": read(output) if output.is_file() else None,
    }


def run(artifact: Path, request: Path, engine: Path, out: Path) -> dict[str, Any]:
    """Run protected fixture transport and the independently authorized fresh successor."""
    artifact, request, engine, out = (path.resolve() for path in (artifact, request, engine, out))
    artifact_digest = sha(artifact)
    original_binding = bind(artifact, request, engine)
    if original_binding["capacity_threshold_basis_points"] != 7500:
        raise ValueError("declared successor mission requires a 0.75 capacity threshold")
    if not 0 < artifact.stat().st_size <= 2_000_000:
        raise ValueError("actual artifact must fit the frozen two-megabyte transport bound")
    out.mkdir(parents=True, exist_ok=False)
    source = out / "source-instrument.json"
    source.write_bytes(artifact.read_bytes())
    request_snapshot = out / "successor-requests.json"
    request_snapshot.write_bytes(request.read_bytes())
    protocol = {
        "schema": "agialpha.battery.native-integration-protocol.v1",
        "adapter_source_commit": "231834269599d85e49cfe1ca9917a1a874522d44",
        "native_source_commit": "80b345828f34fd8a6e592977dd17ef37141305f4",
        "lifecycle_source_commit": "2727262caa52766a78916f2ed81f5afaf668edce",
        "upstream_pins": PINS,
        "wrapper_sha256": sha(Path(__file__)),
        "binding_sha256": sha(ROOT / "binding.py"),
        "recipient_sha256": sha(ROOT / "recipient.py"),
        "mission": original_binding,
        "artifact_bytes": artifact.stat().st_size,
        "declared_before_this_execution": True,
        "scope": "Actual-byte local research transport and inference; no production or live identity qualification.",
        "prior_threshold_basis_points": 8000,
        "new_threshold_basis_points": 7500,
        "cost_basis": "Actual full monetary cost unknown; separate pricing simulations are not journal collections.",
    }
    save(out / "protocol.json", protocol)
    started = time.perf_counter()
    try:
        bridge, conformance = load_upstream()
        original = conformance.run(source, out / "preserved-conformance")
        received = out / "received-instrument.json"
        received.write_bytes((out / "preserved-conformance" / "received-v2.json").read_bytes())
        library = out / "ordinary-library-instrument.json"
        library.write_bytes(source.read_bytes())
        native = bridge.replay_native(unknown_commands(artifact_digest))
        save(out / "actual-cost-uncertainty.json", native)
        scope = native_battery_scope(artifact_digest)
        save(out / "production-scope-refusal.json", scope)
        checks = list(original["checks"])

        def check(name: str, passed: bool, **detail: Any) -> None:
            checks.append({"name": name, "passed": bool(passed), **detail})

        check(
            "source-received-and-ordinary-library-bytes-identical",
            source.read_bytes() == received.read_bytes() == library.read_bytes(),
        )
        check("native-battery-scope-is-actually-refused", scope["passed"])
        check(
            "unknown-actual-costs-prevent-profit-and-spendable-funds-claims",
            native["report"]["complete_cost_profit"] is None
            and native["report"]["available_funds"] is None
            and native["report"]["unknown_costs"] is True
            and native["report"]["collected_revenue"] == 0,
        )
        trust = native_trust()
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
        from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat
        from alpha_factory_v1.core.runtime.store import Journal
        from binding import verify_grant

        key = Ed25519PrivateKey.generate()
        public = key.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw).hex()
        authority_context = {"public_key": public, "mode": MODE, "recipient": RECIPIENT, "revoked": []}
        context_path = out / "fixture-public-authority-context.json"
        save(context_path, authority_context)
        now = int(time.time())

        def grant(binding: dict[str, Any], nonce: str) -> dict[str, Any]:
            payload = {"binding": binding, "nonce": nonce, "not_before": now - 1, "expires": now + 3600}
            return trust.sign_record(key, "battery-controller", DOMAIN, payload).model_dump(mode="json")

        current_binding = bind(received, request_snapshot, engine)
        origin_request = copy.deepcopy(read(request_snapshot))
        for row in requests(origin_request):
            row["capacity_threshold"] = 0.8
        origin_path = out / "origin-meaning-fixture.json"
        save(origin_path, origin_request)
        prior = grant(bind(received, origin_path, engine), "origin-0.8")
        save(out / "prior-origin-grant.json", prior)
        try:
            verify_grant(prior, authority_context, current_binding, now)
            refused = False
        except ValueError:
            refused = True
        check("origin-0.8-authority-cannot-authorize-successor-0.75", refused)
        fresh = grant(current_binding, "fresh-successor-received")
        fresh_path = out / "fresh-successor-grant.json"
        save(fresh_path, fresh)
        for label, altered_binding, altered_context, altered_now in (
            ("changed-artifact", {**current_binding, "artifact_sha256": "0" * 64}, authority_context, now),
            ("changed-inference-code", {**current_binding, "engine_sha256": "0" * 64}, authority_context, now),
            ("changed-mission-input", {**current_binding, "request_sha256": "0" * 64}, authority_context, now),
            ("expired-authority", current_binding, authority_context, now + 3601),
            ("revoked-controller", current_binding, {**authority_context, "revoked": ["battery-controller"]}, now),
        ):
            try:
                verify_grant(fresh, altered_context, altered_binding, altered_now)
                refused = False
            except ValueError:
                refused = True
            check(label + "-refused", refused)
        with tempfile.TemporaryDirectory(prefix="battery-research-journal-") as temporary:
            journal_path = Path(temporary) / "journal"
            Journal.initialize(journal_path)
            received_execution = execute_recipient(
                received,
                request_snapshot,
                engine,
                fresh_path,
                context_path,
                journal_path,
                out / "recipient-received.json",
            )
            save(out / "received-process.json", received_execution)
            library_grant = out / "ordinary-library-grant.json"
            save(library_grant, grant(bind(library, request_snapshot, engine), "fresh-successor-library"))
            library_execution = execute_recipient(
                library,
                request_snapshot,
                engine,
                library_grant,
                context_path,
                journal_path,
                out / "recipient-library.json",
            )
            save(out / "library-process.json", library_execution)
            replay = execute_recipient(
                received,
                request_snapshot,
                engine,
                fresh_path,
                context_path,
                journal_path,
                out / "replayed-grant-refusal.json",
            )
            save(out / "replayed-grant-process.json", replay)
        check("fresh-recipient-process-executes-received-instrument", received_execution["returncode"] == 0)
        check("ordinary-library-process-executes-identical-instrument", library_execution["returncode"] == 0)
        check(
            "one-use-current-research-grant-refuses-replay",
            replay["returncode"] != 0 and "already consumed" in str(replay["report"]),
        )
        recipient_report, library_report = received_execution["report"], library_execution["report"]
        successful = received_execution["returncode"] == library_execution["returncode"] == 0
        check(
            "identical-content-library-matches-all-fresh-recipient-predictions",
            successful and recipient_report["outputs"] == library_report["outputs"],
        )
        check(
            "recipient-runs-in-new-process-with-current-threshold",
            successful
            and recipient_report["pid"] != os.getpid()
            and recipient_report["binding"]["capacity_threshold_basis_points"] == 7500
            and all(row["capacity_threshold"] == 0.75 for row in recipient_report["outputs"]),
        )
        check(
            "origin-model-and-current-inference-source-preserved",
            sha(artifact) == artifact_digest and sha(engine) == original_binding["engine_sha256"],
        )
        summary = {
            "schema": "agialpha.battery.native-integration.v1",
            "artifact_sha256": artifact_digest,
            "artifact_bytes": artifact.stat().st_size,
            "engine_sha256": sha(engine),
            "recipient_request_sha256": sha(request_snapshot),
            "recipient_requests": current_binding["requests"],
            "passed": sum(row["passed"] for row in checks),
            "total": len(checks),
            "checks": checks,
            "elapsed_seconds": time.perf_counter() - started,
            "frozen_vendor_files": len(bridge.verify_sources()["files"]),
            "actual_collections_usd": 0,
            "actual_complete_cost_profit": None,
            "live_ens_authentications": 0,
            "live_authority": "Not established; all identities and current grants are local research fixtures.",
            "production_admission": scope["decision"],
            "empirical_alpha_admission": False,
            "actual_transferred_instrument_executed": successful,
            "ordinary_library_result": "Identical content and prediction parity control; no graph-specific gain established.",
            "frontier_operational_alpha": "Not measured by this deterministic inference and transport experiment.",
            "current_acceptance_boundary": "Fresh capacity inference is checked by the technical study; no physical safety or reuse approval.",
            "prior_threshold_basis_points": 8000,
            "current_threshold_basis_points": 7500,
            "private_fixture_keys_published": False,
            "upstream_conformance_boundary": "The unchanged artificial positive monetary fixture tests protocol behavior, not measured Alpha; its legacy scientific labels are retained.",
        }
        save(out / "summary.json", summary)
        return summary
    except Exception as exc:
        save(
            out / "failed-attempt.json",
            {"type": type(exc).__name__, "error": str(exc), "elapsed_seconds": time.perf_counter() - started},
        )
        raise


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    for option in ("artifact", "request", "engine", "out"):
        parser.add_argument("--" + option, type=Path, required=True)
    args = parser.parse_args()
    result = run(args.artifact, args.request, args.engine, args.out)
    print(
        json.dumps(
            {
                key: result[key]
                for key in ("passed", "total", "artifact_sha256", "recipient_requests", "production_admission")
            }
        )
    )
    raise SystemExit(0 if result["passed"] == result["total"] else 1)
