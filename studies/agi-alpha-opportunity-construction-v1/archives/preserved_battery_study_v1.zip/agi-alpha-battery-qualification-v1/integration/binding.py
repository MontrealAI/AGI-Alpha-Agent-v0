# SPDX-License-Identifier: Apache-2.0
"""Bind a research mission to the existing frozen transport and native trust APIs."""

from __future__ import annotations

import hashlib
import importlib
import importlib.util
import json
import math
import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
UPSTREAM = ROOT / "upstream"
DOMAIN = "battery-research-mission"
MODE = "LOCAL_EPHEMERAL_RESEARCH_FIXTURE_NOT_LIVE_ENS"
RECIPIENT = "lyra.agent.agi.eth"
PINS = {
    "bridge.py": "6acad454931d3a7b86e254a365a732dba5d0f5866a04f45dbce6c5890de4446a",
    "replay.mjs": "21424aca2d4cbd5ed2553875e5f8120de2a51dcdbf21bdedc12b01534cc969c7",
    "run_integration.py": "9e553e42a4301d107e487e762525e1941dcb80a44fbec43f64f879bb0a7b1251",
    "crypto_controls.mjs": "7767b56c6938ca4353ce5f99e7ad5fdff8212e7029958283498b9d956924db68",
    "source_manifest.json": "3489b4bc2870a1fa17af17566f58d16ef190e8039cc71382dcdb9cfabcbd5ba6",
}
OBSERVATIONS = {"Mat", "Qn", *(f"U{i}" for i in range(1, 22))}


def canonical(value: Any) -> bytes:
    """Return finite canonical JSON for research byte commitments."""
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


def sha(path: Path) -> str:
    """Hash an ordinary file, refusing symlink substitution."""
    if path.is_symlink() or not path.is_file():
        raise ValueError("expected ordinary file: " + str(path))
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path: Path) -> Any:
    """Read finite JSON while refusing duplicate object keys."""
    sha(path)

    def unique(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        output: dict[str, Any] = {}
        for key, value in pairs:
            if key in output:
                raise ValueError("duplicate JSON key: " + key)
            output[key] = value
        return output

    result = json.loads(path.read_bytes(), object_pairs_hook=unique)
    canonical(result)
    return result


def save(path: Path, value: Any) -> None:
    """Preserve each output as a new evidence file."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as stream:
        stream.write(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")


def load_upstream() -> tuple[Any, Any]:
    """Verify all 34 unchanged bridge files before use."""
    for name, expected in PINS.items():
        if sha(UPSTREAM / name) != expected:
            raise ValueError("frozen upstream adapter changed: " + name)
    current = sys.modules.get("bridge")
    if current is not None and Path(current.__file__).resolve() != UPSTREAM / "bridge.py":
        raise ValueError("unrelated bridge already imported")
    sys.path.insert(0, str(UPSTREAM))
    bridge = importlib.import_module("bridge")
    bridge.verify_sources()
    spec = importlib.util.spec_from_file_location("preserved_battery_conformance", UPSTREAM / "run_integration.py")
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load frozen conformance adapter")
    conformance = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(conformance)
    return bridge, conformance


def native_trust() -> Any:
    """Use the existing pinned native trust implementation, without adding a registry."""
    bridge, _ = load_upstream()
    bridge.verify_sources()
    native_root = (UPSTREAM / "vendor" / "runtime").resolve()
    sys.path.insert(0, str(native_root))
    module = importlib.import_module("alpha_factory_v1.core.runtime.successor.trust")
    for name, imported in tuple(sys.modules.items()):
        if name.startswith("alpha_factory_v1") and getattr(imported, "__file__", None):
            if not Path(imported.__file__).resolve().is_relative_to(native_root):
                raise ValueError("native module outside pinned closure: " + name)
    return module


def requests(value: Any) -> list[dict[str, Any]]:
    """Admit unlabeled observations only; all requests in a batch share one threshold."""
    rows = value if isinstance(value, list) else value.get("requests", [value])
    if not isinstance(rows, list) or not rows:
        raise ValueError("nonempty fresh recipient request list required")
    output: list[dict[str, Any]] = []
    for row in rows:
        request = row.get("request", row) if isinstance(row, dict) else None
        if not isinstance(request, dict) or not isinstance(request.get("observation"), dict):
            raise ValueError("each request requires an observation")
        if not set(request["observation"]) <= OBSERVATIONS:
            raise ValueError("request contains a forbidden predictor or protected label")
        threshold = request.get("capacity_threshold")
        if isinstance(threshold, bool) or not isinstance(threshold, (int, float)):
            raise ValueError("capacity threshold must be numeric")
        if not math.isfinite(threshold) or not 0 < threshold < 1:
            raise ValueError("capacity threshold outside research scope")
        output.append(request)
    if len({round(row["capacity_threshold"] * 10000) for row in output}) != 1:
        raise ValueError("each current mission grant binds one capacity threshold")
    return output


def bind(artifact: Path, request: Path, engine: Path) -> dict[str, Any]:
    """Recheck source, actual payload and the current mission's meaning."""
    rows = requests(read(request))
    threshold = rows[0]["capacity_threshold"]
    if abs(threshold * 10000 - round(threshold * 10000)) > 1e-9:
        raise ValueError("threshold needs exact basis-point representation")
    return {
        "artifact_sha256": sha(artifact),
        "request_sha256": sha(request),
        "engine_sha256": sha(engine),
        "capacity_threshold_basis_points": round(threshold * 10000),
        "requests": len(rows),
        "recipient": RECIPIENT,
        "right": "run-local-retrospective-battery-capacity-inference",
        "mode": MODE,
    }


def verify_grant(signed: dict[str, Any], context: dict[str, Any], binding: dict[str, Any], now: int) -> dict[str, Any]:
    """Require fresh independently supplied fixture authority, not inherited proof."""
    native = native_trust()
    if context.get("mode") != MODE or context.get("recipient") != RECIPIENT:
        raise ValueError("unsupported research authority context")
    registry = native.TrustRegistry(
        {"battery-controller": native.TrustAnchor(context["public_key"], frozenset({"controller"}))}
    )
    for principal in context.get("revoked", []):
        registry.revoke(principal)
    payload = registry.verify(native.SignedEnvelope.model_validate(signed), DOMAIN, "controller")
    if set(payload) != {"binding", "nonce", "not_before", "expires"} or payload["binding"] != binding:
        raise ValueError("grant does not authorize the current artifact, mission and inference code")
    if type(payload["not_before"]) is not int or type(payload["expires"]) is not int:
        raise ValueError("integer authority times required")
    if not payload["not_before"] <= now < payload["expires"]:
        raise ValueError("research authority expired or not yet valid")
    if not isinstance(payload["nonce"], str) or not payload["nonce"]:
        raise ValueError("one-use nonce required")
    return payload
