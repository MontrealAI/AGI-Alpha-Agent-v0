# SPDX-License-Identifier: Apache-2.0
"""Execute received fitted instrument bytes in a separate authorized research process."""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
import time
from pathlib import Path
from typing import Any

from binding import bind, native_trust, read, requests, save, sha, verify_grant


def consume(journal_path: Path, payload: dict[str, Any], signed: dict[str, Any]) -> dict[str, Any]:
    """Use the native Journal to consume one current research grant before execution."""
    native_trust()
    from alpha_factory_v1.core.runtime.store import Journal

    journal = Journal(journal_path)
    journal.verify()
    name = "@battery-research-grant:" + hashlib.sha256(payload["nonce"].encode()).hexdigest()
    with journal.transaction() as connection:
        try:
            journal.latest(name, connection)
        except KeyError:
            journal.append(connection, name, {"state": "consumed-before-inference", "signed_grant": signed})
        else:
            raise ValueError("current research grant already consumed")
    verified = journal.verify()
    return {"valid": verified["valid"], "events": verified["events"], "identity": journal.identity}


def run(artifact: Path, request: Path, engine: Path, grant: Path, context: Path, journal: Path) -> dict[str, Any]:
    """Recheck meaning and authorization, then run the actual transferred model."""
    started = time.perf_counter()
    before = bind(artifact, request, engine)
    signed = read(grant)
    payload = verify_grant(signed, read(context), before, int(time.time()))
    journal_receipt = consume(journal, payload, signed)
    spec = importlib.util.spec_from_file_location("battery_received_inference", engine)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load current inference implementation")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    model = read(artifact)
    rows = requests(read(request))
    outputs = [module.predict(model, row) for row in rows]
    after = bind(artifact, request, engine)
    if before != after:
        raise ValueError("artifact, mission or inference source changed during execution")
    if any(output.get("capacity_threshold") != row["capacity_threshold"] for output, row in zip(outputs, rows)):
        raise ValueError("inference output substituted the requested capacity threshold")
    return {
        "schema": "agialpha.battery.recipient-execution.v1",
        "pid": os.getpid(),
        "binding": before,
        "journal_after_consumption": journal_receipt,
        "outputs": outputs,
        "elapsed_seconds": time.perf_counter() - started,
        "actual_collections_usd": 0,
        "actual_complete_cost_usd": None,
        "source_integrity_before_after": True,
        "current_mission_rechecked": True,
        "authority_regranted": True,
        "prior_acceptance_inherited": False,
        "isolation": "Separate local Python process; not an independent organization or production security sandbox.",
        "qualification": "Computational retrospective capacity inference only; no physical reuse or safety certification.",
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    for name in ("artifact", "request", "engine", "grant", "context", "journal", "output"):
        parser.add_argument("--" + name, required=True, type=Path)
    args = parser.parse_args()
    if args.output.exists():
        raise ValueError("refusing to overwrite recipient evidence")
    try:
        result = run(args.artifact, args.request, args.engine, args.grant, args.context, args.journal)
        save(args.output, result)
        print(json.dumps({"requests": len(result["outputs"]), "artifact_sha256": sha(args.artifact)}))
    except Exception as exc:
        save(
            args.output,
            {"schema": "agialpha.battery.recipient-refusal.v1", "type": type(exc).__name__, "error": str(exc)},
        )
        raise SystemExit(1) from exc
