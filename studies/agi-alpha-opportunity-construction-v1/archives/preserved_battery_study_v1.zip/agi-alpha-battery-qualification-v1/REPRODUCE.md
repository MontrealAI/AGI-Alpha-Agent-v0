# Reproduce the battery qualification study

The reproduction runner rebuilds the fitted instruments, both technical confirmations, the native-interface experiment and the complete commercial simulation in a temporary copy. It compares the regenerated outputs with the published artifacts, writes `evidence/reproduction_check.json`, and deletes the temporary tree. Original study results stay intact.

This is a replay of the published observations, model configurations and seeds. It establishes computational reproducibility; it does not supply additional independent cells, customer acceptance, actual revenue, physical battery qualification or a frontier-model U/E/E+ trial.

## Setup

Run from `studies/agi-alpha-battery-qualification-v1` in the repository or the same directory in the downloaded study package. The recorded environment is Linux x86-64, Python **3.12.14** and Node **v24.22.1**. Node uses its standard library; no npm installation is required. Python dependencies, including their transitive dependencies, are pinned in `requirements-study.txt`.

```sh
python3.12 -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements-study.txt
python --version
node --version
python -B src/reproduce.py
```

Installing dependencies requires the ordinary package distribution services. After setup, the runner uses the included measurements and vendored source closure. It does not fetch data, call a paid model API, contact ENS, or send customer material. The complete study data, provenance and upstream source/license files must remain in the package.

The main scientific dependencies used for the recorded run are NumPy 2.3.2, pandas 2.3.1, SciPy 1.17.0, scikit-learn 1.8.0 and openpyxl 3.1.5. The integration uses Pydantic 2.11.7 and cryptography 50.0.2. The receipt records the actual interpreter, platform, Node version and all supplied Python pins. Different environments may produce a reported mismatch. A package-pin deviation is reported rather than automatically failing the run; passing still requires the declared exact output comparisons, including the versions recorded in the technical development output. Use the pinned environment to reproduce the published result.

## What the runner executes

In a fresh temporary copy, the runner removes the outputs it will regenerate, then runs these commands in order:

```sh
python -B -m unittest discover -s tests -p test_instrument.py -v
python -B src/study.py develop
python -B src/study.py origin
python -B src/study.py successor
python -B integration/run_native_integration.py \
  --artifact results/retained_instrument.json \
  --request results/successor_requests.json \
  --engine src/instrument.py \
  --out integration/results/confirmation-01
python -B src/validate_delivery.py
python -B src/economics.py self-test
python -B src/economics.py explore
python -B src/economics.py confirm
```

These individual commands are shown for transparency. Use `src/reproduce.py` for a protected replay: running `develop`, `explore` or `confirm` directly in the published study directory overwrites the corresponding result files. The integration destination must not already exist; the runner removes it only inside its temporary copy.

The technical protocol fixes seed 20261027, physical-cell splits and all five candidate models. Origin and successor bootstrap seeds are 27102026 and 27102027, with 10,000 replicates each. The corrected commercial protocol explores 200 worlds using seeds 281000–281199, freezes the selected policy, then runs the 1,000 fresh confirmation worlds at seeds 991000–991999. The initial, corrected-away commercial exploration and failed technical attempts remain preserved as historical evidence. They are not substituted for current results.

## Acceptance and comparison rules

All fitted model files, physical-cell split assignments, mission requests, per-cell confirmation outputs, commercial worlds and economic summaries must match **byte for byte**. The native-interface comparisons preserve the actual transported instrument, all predictions, scope refusals, accounting outputs, source hashes, mission hashes and control results.

Only narrowly enumerated metadata are omitted from exact JSON comparisons: elapsed execution durations, technical-freeze timestamp and historical amendment metadata, process IDs, ephemeral public keys/signatures, grant validity timestamps and local journal identities. Each omitted path is recorded in the receipt. Grant duration, journal validity, mission bindings and the 44 native controls remain checked. The development-file hash changes with its measured runtime; both original and regenerated freeze hashes are separately validated against their actual files.

The runner does not round numerical discrepancies away or omit an unfavorable observation. Missing files, failed commands, changed input/source bytes, changed substantive results, failed native controls or failed computational delivery checks produce a failed receipt and a nonzero exit status. Each comparison includes original and regenerated SHA-256 hashes. Command exit codes and bounded output logs are retained. A later rerun preserves prior receipt contents under `previous_runs`.

The original scientific inputs, frozen implementations, published results, native source closure and historical archives are hashed before and after the run to confirm preservation. A successful receipt is specific to this study and these commands. It is **not a claim that full-repository CI, a software release gate, a live identity deployment or physical battery safety qualification has passed**.

## Reading the result

The recorded run on 2026-10-27 passed **51 of 51 artifact comparisons** in 49.975 seconds: 39 artifacts were byte-identical and 12 matched exactly after the declared metadata omissions. The 12 existing instrument boundary tests, eight accounting self-tests, all 44 native controls and the computational delivery checks passed. Both sets of freeze bindings verified, the original scientific inputs and results remained unchanged, and the temporary tree was deleted. This timing describes the recorded machine, not a promised service turnaround.

Open `evidence/reproduction_check.json` and check `passed`, `comparisons_passed`, `comparisons_total`, command return codes and `original_scientific_inputs_and_results_unchanged`. The same receipt also lists the exact comparison omissions, any concrete mismatch paths and the measured elapsed runtime. Only the receipt is retained; temporary reproduced trees and ephemeral private signing/journal keys are removed.

The commercial result is still conditional on the protocol's hypothetical demand, price, mission success and cost assumptions. Reproducing those calculations does not turn modeled receipts into collected money or measure Operational Alpha. The executed technical and native results retain the qualifications stated in the paper and protocols.
