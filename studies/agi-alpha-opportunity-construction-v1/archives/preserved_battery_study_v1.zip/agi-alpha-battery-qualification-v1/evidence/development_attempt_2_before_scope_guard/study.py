# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import argparse
import hashlib
import json
import math
import platform
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import sklearn
from scipy.stats import beta
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import GroupKFold

from instrument import cohort, estimate, features, predict

ROOT = Path(__file__).resolve().parents[1]
CONFIG = json.loads((ROOT / "config/technical_protocol.json").read_text())
SOURCES = {
    "LMO_10Ah_W_5000.xlsx": "70820b404b712a3764781e6c6dab1999ea884b0f60028b34ffe11bae1c3db9ba",
    "NMC_21Ah_W_5000.xlsx": "cc826a7c5901a15075cfcc38184153f83223b3438ed92fd9b17adce34b7af5ee",
    "LFP_35Ah_W_5000.xlsx": "3acc96033ba5474171ff8ddd0eef159e37e10034473e33814fd8aa398e4d7538",
    "NMC_2.1Ah_W_5000.xlsx": "60822626f9ecddb77470a9d4764c90031dcce8aa3ed9d271d486ee9a35da323c",
}


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + "\n")


def load_data() -> pd.DataFrame:
    frames = []
    for filename, expected in SOURCES.items():
        path = ROOT / "data" / filename
        if digest(path) != expected:
            raise ValueError(f"Source hash mismatch: {filename}")
        frame = pd.read_excel(path, sheet_name="SOC ALL")
        frame["cohort"] = [cohort(x) for x in frame.to_dict("records")]
        frame["physical_id"] = frame["ID"].astype(str)
        if "2.1Ah" in filename:
            frame["physical_id"] = frame["physical_id"].str.split("-").str[0]
        frame["group"] = frame["cohort"] + "|" + frame["physical_id"]
        frame["source_file"] = filename
        if not np.allclose(frame["Q"] / frame["Qn"], frame["SOH"], atol=1e-9):
            raise ValueError("Source capacity and target disagree")
        if frame[[f"U{i}" for i in range(1, 22)]].isna().any().any():
            raise ValueError("Missing public voltage data")
        frames.append(frame)
    return pd.concat(frames, ignore_index=True)


def assignments(data: pd.DataFrame) -> dict[str, str]:
    result = {}
    for family, counts in CONFIG["split"].items():
        ids = data.loc[data["cohort"] == family, "group"].unique().tolist()
        ids.sort(key=lambda g: hashlib.sha256(f"{CONFIG['seed']}|{g}".encode()).hexdigest())
        if len(ids) != sum(counts.values()):
            raise ValueError("Declared split count does not match physical cells")
        cursor = 0
        for phase, count in counts.items():
            result.update({g: phase for g in ids[cursor : cursor + count]})
            cursor += count
    result.update({g: "scope_stress" for g in data.loc[data["cohort"] == "NMC_2.1", "group"].unique()})
    return result


def fit(method: str, frame: pd.DataFrame) -> Any:
    if method == "chemistry_median":
        return frame.groupby("cohort")["SOH"].median().to_dict()
    matrix = np.array([features(x, method) for x in frame.to_dict("records")])
    parameters = {k: v for k, v in CONFIG["regressor"].items() if k != "name"}
    model = RandomForestRegressor(**parameters)
    model.fit(matrix, frame["SOH"].to_numpy())
    return model


def model_predict(model: Any, method: str, frame: pd.DataFrame) -> np.ndarray:
    if method == "chemistry_median":
        return np.array([model[c] for c in frame["cohort"]])
    return model.predict(np.array([features(x, method) for x in frame.to_dict("records")]))


def encode(model: Any, method: str, radius: float) -> dict[str, Any]:
    result: dict[str, Any] = {
        "schema": "agialpha.battery-instrument.v1",
        "version": "1.0.0",
        "method": method,
        "allowed_cohorts": list(CONFIG["split"]),
        "calibration_q": radius,
        "coverage_level": CONFIG["coverage_level"],
        "coverage_scope": CONFIG["coverage_boundary"],
        "source_commit": CONFIG["source_commit"],
        "source_sha256": SOURCES,
        "protocol_sha256": digest(ROOT / "config/technical_protocol.json"),
        "rights": "New code Apache-2.0; source dataset MIT; attribution and license retained",
        "dependencies_for_inference": "Python 3.11+ standard library; src/instrument.py",
        "failures": [
            "unknown cohort",
            "missing/nonfinite measurements",
            "interval crosses capacity threshold",
            "temperature/history/measurement distribution shift",
            "physical safety not assessed",
        ],
        "training_units": 91,
        "calibration_units": 51,
        "protected_confirmation_answers": False,
        "physical_release_authorized": False,
    }
    if method == "chemistry_median":
        result["medians"] = model
    else:
        result["trees"] = [
            {
                "left": t.tree_.children_left.tolist(),
                "right": t.tree_.children_right.tolist(),
                "feature": t.tree_.feature.tolist(),
                "threshold": t.tree_.threshold.tolist(),
                "value": t.tree_.value[:, 0, 0].tolist(),
            }
            for t in model.estimators_
        ]
    return result


def selected_rows(frame: pd.DataFrame, phase: str) -> pd.DataFrame:
    rows = []
    for group, unit in frame.groupby("group", sort=True):
        unit = unit.sort_values(["ID", "SOC"])
        index = int(hashlib.sha256(f"{phase}-observation|{group}".encode()).hexdigest(), 16) % len(unit)
        rows.append(unit.iloc[index])
    return pd.DataFrame(rows).reset_index(drop=True)


def request(row: dict[str, Any], threshold: float) -> dict[str, Any]:
    return {"capacity_threshold": threshold, "observation": {k: row[k] for k in CONFIG["prediction_whitelist"]}}


def develop() -> None:
    start = time.perf_counter()
    data = load_data()
    split = assignments(data)
    data["phase"] = data["group"].map(split)
    train = data[data["phase"] == "train"].reset_index(drop=True)
    cal = data[data["phase"] == "calibration"].reset_index(drop=True)
    results: list[dict[str, Any]] = []
    encoded: dict[str, dict[str, Any]] = {}
    for method in CONFIG["candidates"]:
        predictions = np.empty(len(train))
        for training, validation in GroupKFold(5).split(train, groups=train["group"]):
            model = fit(method, train.iloc[training])
            predictions[validation] = model_predict(model, method, train.iloc[validation])
        mae = float(np.abs(predictions - train["SOH"].to_numpy()).mean())
        model = fit(method, train)
        cal_predictions = model_predict(model, method, cal)
        residual = pd.DataFrame({"group": cal["group"], "absolute_error": np.abs(cal_predictions - cal["SOH"])})
        scores = residual.groupby("group")["absolute_error"].max().sort_values().to_numpy()
        rank = math.ceil((len(scores) + 1) * CONFIG["coverage_level"])
        if rank > len(scores):
            raise ValueError("Insufficient calibration cells for requested coverage")
        radius = float(scores[rank - 1])
        artifact = encode(model, method, radius)
        reproduced = np.array([estimate(artifact, row) for row in cal.to_dict("records")])
        difference = float(np.max(np.abs(reproduced - cal_predictions)))
        if difference > 1e-10:
            raise ValueError("Independent retained inference differs from sklearn")
        encoded[method] = artifact
        write_json(ROOT / "results/models" / f"{method}.json", artifact)
        results.append(
            {
                "method": method,
                "development_group_cv_mae": mae,
                "calibration_cell_max_quantile": radius,
                "calibration_cells": len(scores),
                "conformal_rank": rank,
                "required_seconds_scenario": CONFIG["measurement_seconds"][method],
                "independent_inference_max_absolute_difference": difference,
            }
        )
    best = min(r["development_group_cv_mae"] for r in results)
    eligible = [r for r in results if r["development_group_cv_mae"] <= best + 0.005]
    selected = min(eligible, key=lambda r: (r["required_seconds_scenario"], r["development_group_cv_mae"], r["method"]))
    full = min(
        (r for r in results if r["method"].startswith("five")),
        key=lambda r: (r["development_group_cv_mae"], r["method"]),
    )
    write_json(ROOT / "results/retained_instrument.json", encoded[selected["method"]])
    write_json(ROOT / "results/split_assignments.json", split)
    for phase, threshold in [("origin", 0.8), ("successor", 0.75)]:
        rows = selected_rows(data[data["phase"] == phase], phase)
        write_json(
            ROOT / "results" / f"{phase}_requests.json", [request(row, threshold) for row in rows.to_dict("records")]
        )
    write_json(
        ROOT / "results/development.json",
        {
            "candidates": results,
            "selected": selected,
            "strong_full_reference": full,
            "elapsed_seconds_measured": time.perf_counter() - start,
            "environment": {
                "python": platform.python_version(),
                "numpy": np.__version__,
                "pandas": pd.__version__,
                "sklearn": sklearn.__version__,
            },
            "cell_counts": data.groupby("phase")["group"].nunique().to_dict(),
            "rows": len(data),
            "physical_cells": data["group"].nunique(),
            "measured_usd_cost": None,
            "complete_actual_research_cost": None,
        },
    )
    frozen_files = [
        ROOT / "src/study.py",
        ROOT / "src/instrument.py",
        ROOT / "config/technical_protocol.json",
        ROOT / "results/retained_instrument.json",
        ROOT / "results/split_assignments.json",
        ROOT / "results/development.json",
    ]
    frozen_files += list((ROOT / "results/models").glob("*.json"))
    write_json(
        ROOT / "results/technical_freeze.json",
        {
            "frozen_at_utc": datetime.now(timezone.utc).isoformat(),
            "stage": "Development and calibration complete; before origin or successor confirmation",
            "selected_method": selected["method"],
            "full_reference_method": full["method"],
            "files": {str(p.relative_to(ROOT)): digest(p) for p in frozen_files},
        },
    )
    print(json.dumps({"selected": selected, "full": full, "development": results}, indent=2))


def binomial_interval(successes: int, total: int) -> list[float] | None:
    if total == 0:
        return None
    lo = 0.0 if successes == 0 else float(beta.ppf(0.025, successes, total - successes + 1))
    hi = 1.0 if successes == total else float(beta.ppf(0.975, successes + 1, total - successes))
    return [lo, hi]


def summarize(records: list[dict[str, Any]], seconds: float) -> dict[str, Any]:
    total = len(records)
    errors = np.array([r["absolute_error"] for r in records])
    decisive = [r for r in records if not r["requires_full_test"]]
    wrong = sum(bool(r["wrong_decisive"]) for r in records)
    covered = sum(bool(r["covered"]) for r in records)
    fallback = total - len(decisive)
    expenses = CONFIG["customer_testing_cost_scenario"]
    rapid = (
        0
        if seconds == 0
        else total * (expenses["rapid_setup_per_cell_usd"] + seconds / 3600 * expenses["channel_hour_usd"])
    )
    testing = rapid + fallback * expenses["full_capacity_test_per_cell_usd"]
    return {
        "physical_cells": total,
        "mae": float(errors.mean()),
        "rmse": float(np.sqrt(np.mean(errors**2))),
        "interval_covered_cells": covered,
        "coverage": covered / total,
        "coverage_exact_95_interval": binomial_interval(covered, total),
        "decisive_cells": len(decisive),
        "full_capacity_test_referrals": fallback,
        "wrong_decisive_cells": wrong,
        "wrong_decisive_fraction": wrong / len(decisive) if decisive else None,
        "wrong_decisive_exact_95_interval": binomial_interval(wrong, len(decisive)),
        "customer_testing_cost_usd_scenario": testing,
        "customer_testing_plus_wrong_decision_cost_usd_scenario": testing + wrong * expenses["wrong_decision_loss_usd"],
        "all_full_test_cost_usd_scenario": total * expenses["full_capacity_test_per_cell_usd"],
        "channel_seconds_scenario": total * seconds + fallback * CONFIG["full_capacity_test_seconds_scenario"],
    }


def confirm(phase: str) -> None:
    freeze = json.loads((ROOT / "results/technical_freeze.json").read_text())
    for path, expected in freeze["files"].items():
        if digest(ROOT / path) != expected:
            raise ValueError(f"Frozen technical source changed: {path}")
    data = load_data()
    split = json.loads((ROOT / "results/split_assignments.json").read_text())
    data["phase"] = data["group"].map(split)
    frame = selected_rows(data[data["phase"] == phase], phase)
    threshold = CONFIG["primary_threshold"] if phase == "origin" else CONFIG["successor_threshold"]
    all_records: dict[str, list[dict[str, Any]]] = {}
    summaries = {}
    for method in CONFIG["candidates"]:
        artifact = json.loads((ROOT / "results/models" / f"{method}.json").read_text())
        records = []
        for row in frame.to_dict("records"):
            result = predict(artifact, request(row, threshold))
            true = float(row["SOH"])
            wrong = not result["requires_full_test"] and ((result["point"] >= threshold) != (true >= threshold))
            records.append(
                {
                    **result,
                    "group": row["group"],
                    "cohort": row["cohort"],
                    "observed_soc_for_audit_only": int(row["SOC"]),
                    "true_soh": true,
                    "absolute_error": abs(result["point"] - true),
                    "covered": result["lower"] <= true <= result["upper"],
                    "wrong_decisive": bool(wrong),
                }
            )
        all_records[method] = records
        summaries[method] = summarize(records, CONFIG["measurement_seconds"][method])
    selected = freeze["selected_method"]
    full = freeze["full_reference_method"]
    delta = np.array(
        [
            a["absolute_error"] - b["absolute_error"]
            for a, b in zip(all_records[selected], all_records[full], strict=True)
        ]
    )
    rng = np.random.default_rng(CONFIG["bootstrap_seed"] + (0 if phase == "origin" else 1))
    bootstrap = rng.choice(delta, size=(CONFIG["bootstrap_replicates"], len(delta)), replace=True).mean(axis=1)
    interval = [float(x) for x in np.quantile(bootstrap, [0.025, 0.975])]
    selected_summary = summaries[selected]
    full_summary = summaries[full]
    report = {
        "phase": phase,
        "capacity_threshold": threshold,
        "selected_method": selected,
        "strong_full_reference": full,
        "method_summaries": summaries,
        "paired_mae_difference_selected_minus_full": float(delta.mean()),
        "paired_bootstrap_95_interval": interval,
        "noninferiority_margin": CONFIG["noninferiority_margin"],
        "noninferiority_supported": interval[1] <= CONFIG["noninferiority_margin"],
        "subgroups_selected": {
            c: summarize(
                [r for r in all_records[selected] if r["cohort"] == c], CONFIG["measurement_seconds"][selected]
            )
            for c in CONFIG["split"]
        },
        "customer_cost_difference_selected_minus_full_scenario": selected_summary[
            "customer_testing_plus_wrong_decision_cost_usd_scenario"
        ]
        - full_summary["customer_testing_plus_wrong_decision_cost_usd_scenario"],
        "empirical_coverage_only": True,
        "customer_acceptance_observed": False,
        "physical_release_authorized": False,
        "all_records": all_records,
    }
    if phase == "origin":
        stress = selected_rows(data[data["phase"] == "scope_stress"], "stress")
        artifact = json.loads((ROOT / "results/retained_instrument.json").read_text())
        report["scope_stress"] = [
            dict(group=row["group"], **predict(artifact, request(row, threshold))) for row in stress.to_dict("records")
        ]
        report["scope_stress_full_test_cost_usd_scenario"] = (
            len(stress) * CONFIG["customer_testing_cost_scenario"]["full_capacity_test_per_cell_usd"]
        )
    write_json(ROOT / "results" / f"{phase}_confirmation.json", report)
    print(
        json.dumps(
            {k: v for k, v in report.items() if k not in ["all_records", "scope_stress", "subgroups_selected"]},
            indent=2,
        )
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=["develop", "origin", "successor"])
    args = parser.parse_args()
    if args.stage == "develop":
        develop()
    else:
        confirm(args.stage)


if __name__ == "__main__":
    main()
