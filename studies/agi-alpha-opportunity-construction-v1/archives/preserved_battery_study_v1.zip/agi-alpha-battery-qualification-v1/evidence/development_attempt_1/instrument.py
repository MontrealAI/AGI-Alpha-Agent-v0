# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Any


def cohort(observation: dict[str, Any]) -> str:
    return f"{observation['Mat']}_{float(observation['Qn']):g}"


def features(observation: dict[str, Any], method: str) -> list[float]:
    last = 9 if method.startswith('two') else 21
    first = float(observation['U1'])
    qn = float(observation['Qn'])
    if qn <= 0:
        raise ValueError('Nominal capacity must be positive')
    if method.endswith('delta'):
        values = [first]
        for i in range(2, last + 1):
            magnitude = 0.5 if i <= 9 else (1.0 if i <= 17 else 1.5)
            values.append((float(observation[f'U{i}']) - first) / (qn * magnitude))
    else:
        values = [float(observation[f'U{i}']) for i in range(1, last + 1)]
    values += [qn] + [float(observation['Mat'] == name) for name in ['LMO', 'NMC', 'LFP']]
    if not all(math.isfinite(x) for x in values):
        raise ValueError('Nonfinite prediction input')
    return values


def estimate(artifact: dict[str, Any], observation: dict[str, Any]) -> float:
    if artifact['method'] == 'chemistry_median':
        return float(artifact['medians'][cohort(observation)])
    vector = features(observation, artifact['method'])
    values = []
    for tree in artifact['trees']:
        index = 0
        while tree['left'][index] != -1:
            feature = tree['feature'][index]
            index = tree['left'][index] if vector[feature] <= tree['threshold'][index] else tree['right'][index]
        values.append(float(tree['value'][index]))
    return sum(values) / len(values)


def predict(artifact: dict[str, Any], request: dict[str, Any]) -> dict[str, Any]:
    threshold = float(request['capacity_threshold'])
    if not math.isfinite(threshold) or not 0 < threshold <= 1.2:
        raise ValueError('Capacity threshold must be finite and in (0, 1.2]')
    row = request['observation']
    common: dict[str, Any] = {'capacity_threshold': threshold, 'physical_release_authorized': False}
    if cohort(row) not in artifact['allowed_cohorts']:
        return {**common, 'scope': 'outside_calibrated_cohorts', 'point': None, 'lower': None, 'upper': None,
                'disposition': 'full_capacity_test', 'requires_full_test': True,
                'reason': 'New cohort requires new qualification; no transported coverage claim'}
    try:
        point = estimate(artifact, row)
    except (KeyError, TypeError, ValueError, ZeroDivisionError):
        return {**common, 'scope': 'invalid_measurement', 'point': None, 'lower': None, 'upper': None,
                'disposition': 'full_capacity_test', 'requires_full_test': True,
                'reason': 'Required valid measurement missing; do not impute silently'}
    radius = float(artifact['calibration_q'])
    lower, upper = point - radius, point + radius
    if lower >= threshold:
        disposition = 'capacity_at_least_threshold'
    elif upper < threshold:
        disposition = 'capacity_below_threshold'
    else:
        disposition = 'full_capacity_test'
    return {**common, 'scope': 'specified_retrospective_envelope', 'point': point,
            'lower': lower, 'upper': upper, 'disposition': disposition,
            'requires_full_test': disposition == 'full_capacity_test',
            'reason': 'Pooled cell-calibrated interval; marginal assumption, not conditional decision assurance'}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--artifact', type=Path, required=True)
    parser.add_argument('--request', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    artifact = json.loads(args.artifact.read_text())
    request = json.loads(args.request.read_text())
    output = [predict(artifact, r) for r in request] if isinstance(request, list) else predict(artifact, request)
    args.output.write_text(json.dumps(output, indent=2, allow_nan=False) + '\n')


if __name__ == '__main__':
    main()
