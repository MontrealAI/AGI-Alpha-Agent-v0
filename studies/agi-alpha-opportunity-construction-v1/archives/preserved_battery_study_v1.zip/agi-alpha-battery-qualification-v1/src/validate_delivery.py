# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from instrument import predict

ROOT = Path(__file__).resolve().parents[1]


def read(path: str) -> Any:
    return json.loads((ROOT / path).read_text())


def main() -> None:
    checks: dict[str, bool] = {}
    freeze = read("results/technical_freeze.json")
    for name, expected in freeze["files"].items():
        checks[f"frozen:{name}"] = hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == expected
    assignments = read("results/split_assignments.json")
    counts = {stage: sum(s == stage for s in assignments.values()) for stage in set(assignments.values())}
    checks["all_215_physical_cells_accounted"] = counts == {
        "train": 91,
        "calibration": 51,
        "origin": 31,
        "successor": 30,
        "scope_stress": 12,
    }
    checks["unique_physical_split_keys"] = len(assignments) == 215
    sources = read("evidence/data_sources.json")
    frames = [pd.read_excel(p, sheet_name="SOC ALL") for p in (ROOT / "data").glob("*.xlsx")]
    raw = pd.concat(frames, ignore_index=True)
    truth = {
        f"{r['Mat']}_{float(r['Qn']):g}|{r['ID']}": float(r["Q"] / r["Qn"])
        for r in raw.to_dict("records")
        if float(r["Qn"]) != 2.1
    }
    artifact = read("results/retained_instrument.json")
    checks["artifact_has_no_confirmation_answers"] = artifact["protected_confirmation_answers"] is False
    checks["artifact_declares_research_scope"] = artifact["physical_release_authorized"] is False
    for phase, expected_n, threshold in [("origin", 31, 0.8), ("successor", 30, 0.75)]:
        report = read(f"results/{phase}_confirmation.json")
        requests = read(f"results/{phase}_requests.json")
        records = report["all_records"][report["selected_method"]]
        checks[f"{phase}:complete_dispositions"] = len(records) == len(requests) == expected_n
        checks[f"{phase}:raw_capacity_truth"] = all(abs(truth[r["group"]] - r["true_soh"]) < 1e-10 for r in records)
        checks[f"{phase}:fresh_units"] = all(assignments[r["group"]] == phase for r in records)
        checks[f"{phase}:no_duplicate_units"] = len({r["group"] for r in records}) == expected_n
        checks[f"{phase}:correct_purpose"] = all(r["capacity_threshold"] == threshold for r in records)
        outputs = [predict(artifact, request) for request in requests]
        checks[f"{phase}:actual_retained_output"] = all(
            output == {k: record[k] for k in output} for output, record in zip(outputs, records, strict=True)
        )
        summary = report["method_summaries"][report["selected_method"]]
        checks[f"{phase}:mae_independent_recalculation"] = bool(
            np.isclose(
                sum(abs(r["point"] - truth[r["group"]]) for r in records) / len(records), summary["mae"], atol=1e-12
            )
        )
        checks[f"{phase}:no_physical_release"] = all(r["physical_release_authorized"] is False for r in records)
        checks[f"{phase}:all_methods_same_units"] = all(
            [r["group"] for r in other] == [r["group"] for r in records] for other in report["all_records"].values()
        )
        checks[f"{phase}:fallbacks_accounted"] = (
            summary["decisive_cells"] + summary["full_capacity_test_referrals"] == expected_n
        )
    origin = read("results/origin_confirmation.json")
    checks["all_12_out_of_scope_cells_retained"] = len(origin["scope_stress"]) == 12
    checks["unknown_scope_full_test_required"] = all(x["requires_full_test"] for x in origin["scope_stress"])
    native = read("integration/results/confirmation-01/summary.json")
    checks["native_observed_controls_pass"] = native["passed"] == native["total"] == 44
    checks["native_model_is_current_model"] = (
        native["artifact_sha256"]
        == hashlib.sha256((ROOT / "results/retained_instrument.json").read_bytes()).hexdigest()
    )
    checks["native_engine_is_current_engine"] = (
        native["engine_sha256"] == hashlib.sha256((ROOT / "src/instrument.py").read_bytes()).hexdigest()
    )
    checks["sources_provenance_present"] = bool(sources)
    result = {
        "schema": "agialpha.battery-delivery-acceptance.v1",
        "passed": sum(checks.values()),
        "total": len(checks),
        "checks": checks,
        "evidence_type": "Executed computational acceptance",
        "buyer_acceptance_observed": False,
        "physical_release_authorized": False,
        "actual_customer_collections_usd": 0,
        "actual_complete_cost_usd": None,
        "claim": "The finite qualification dossier satisfies its declared computational contract.",
    }
    (ROOT / "results/delivery_acceptance.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    if not all(checks.values()):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
