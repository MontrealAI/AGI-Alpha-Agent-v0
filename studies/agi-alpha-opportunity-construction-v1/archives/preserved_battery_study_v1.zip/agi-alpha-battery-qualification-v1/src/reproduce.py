# SPDX-License-Identifier: Apache-2.0
"""Regenerate published study outputs in a disposable copy and compare them."""

from __future__ import annotations

import copy
import hashlib
import importlib.metadata
import json
import os
import platform
import shutil
import subprocess
import sys
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
RECEIPT = ROOT / "evidence/reproduction_check.json"
NATIVE = "integration/results/confirmation-01"
ECONOMIC_OUTPUTS = [
    f"results/economics_{name}.json"
    for name in ("exploration", "freeze", "confirmation", "sensitivity", "example_ledger", "summary")
]
TECHNICAL_OUTPUTS = [
    f"results/{name}.json"
    for name in (
        "development",
        "technical_freeze",
        "retained_instrument",
        "split_assignments",
        "origin_requests",
        "successor_requests",
        "origin_confirmation",
        "successor_confirmation",
        "delivery_acceptance",
    )
]
IGNORE_NAMES = {"__pycache__", ".git", ".venv", "venv", ".pytest_cache", ".mypy_cache", ".ruff_cache"}

# Every omission is file-specific. Model, input, source and evidence hashes stay
# comparable. The development file's hash changes because it records runtime.
OMISSIONS: dict[str, list[tuple[str, ...]]] = {
    "results/development.json": [("elapsed_seconds_measured",)],
    "results/technical_freeze.json": [
        ("frozen_at_utc",),
        ("amendment",),
        ("files", "results/development.json"),
    ],
    f"{NATIVE}/summary.json": [("elapsed_seconds",)],
    f"{NATIVE}/fixture-public-authority-context.json": [("public_key",)],
}
for _name in ("prior-origin-grant", "fresh-successor-grant", "ordinary-library-grant"):
    OMISSIONS[f"{NATIVE}/{_name}.json"] = [
        ("signature",),
        ("payload", "not_before"),
        ("payload", "expires"),
    ]
for _name in ("recipient-received", "recipient-library"):
    OMISSIONS[f"{NATIVE}/{_name}.json"] = [
        ("elapsed_seconds",),
        ("pid",),
        ("journal_after_consumption", "identity"),
    ]
for _name in ("received-process", "library-process", "replayed-grant-process"):
    OMISSIONS[f"{NATIVE}/{_name}.json"] = [
        ("elapsed_seconds",),
        ("report", "elapsed_seconds"),
        ("report", "pid"),
        ("report", "journal_after_consumption", "identity"),
    ]


def sha(path: Path) -> str:
    """Hash actual file bytes without interpreting their contents."""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path: Path) -> Any:
    """Read one JSON artifact."""
    return json.loads(path.read_text())


def requirements() -> dict[str, str]:
    """Read the recorded exact package versions without invoking a resolver."""
    return dict(
        line.strip().split("==", 1)
        for line in (ROOT / "requirements-study.txt").read_text().splitlines()
        if line.strip() and not line.lstrip().startswith("#")
    )


def environment() -> dict[str, Any]:
    """Record the actual runtime and any deviation from the supplied pins."""
    pins = requirements()
    actual: dict[str, str | None] = {}
    for name in pins:
        try:
            actual[name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            actual[name] = None
    node = shutil.which("node")
    version = (
        subprocess.run([node, "--version"], capture_output=True, text=True, check=True).stdout.strip() if node else None
    )
    return {
        "python": sys.version,
        "python_executable": sys.executable,
        "platform": platform.platform(),
        "node": version,
        "packages": actual,
        "package_pins_match": actual == pins,
        "requested_environment": {"PYTHONDONTWRITEBYTECODE": "1", "PYTHONHASHSEED": "0"},
    }


def files_for_manifest(root: Path) -> list[Path]:
    """Track scientific inputs, frozen implementations and all published results."""
    files = [
        root / name
        for name in (
            "src/study.py",
            "src/instrument.py",
            "src/economics.py",
            "src/validate_delivery.py",
            "src/reproduce.py",
            "requirements-study.txt",
            "evidence/data_sources.json",
        )
    ]
    for directory in ("config", "data", "results", "tests", "integration"):
        files.extend(
            path
            for path in (root / directory).rglob("*")
            if path.is_file() and not (set(path.parts) & IGNORE_NAMES) and path.suffix != ".pyc"
        )
    return sorted(set(files))


def manifest(root: Path) -> dict[str, str]:
    """Create a source and result preservation manifest."""
    return {str(path.relative_to(root)): sha(path) for path in files_for_manifest(root)}


def freeze_checks(root: Path) -> dict[str, bool]:
    """Validate every current technical and commercial freeze binding."""
    technical = read(root / "results/technical_freeze.json")
    checks = {"technical:" + name: sha(root / name) == digest for name, digest in technical["files"].items()}
    commercial = read(root / "results/economics_freeze.json")
    for key, name in (
        ("source_sha256", "src/economics.py"),
        ("protocol_sha256", "config/commercial_protocol.json"),
        ("exploration_sha256", "results/economics_exploration.json"),
    ):
        checks["commercial:" + name] = sha(root / name) == commercial[key]
    return checks


def normalized(value: Any, omitted: list[tuple[str, ...]]) -> Any:
    """Remove only the declared metadata paths from a comparison copy."""
    result = copy.deepcopy(value)
    for path in omitted:
        node = result
        for key in path[:-1]:
            node = node.get(key) if isinstance(node, dict) else None
        if isinstance(node, dict):
            node.pop(path[-1], None)
    return result


def differences(left: Any, right: Any, prefix: str = "$") -> list[dict[str, Any]]:
    """Return the first concrete mismatches without numerical rounding."""
    if type(left) is not type(right):
        return [{"path": prefix, "published": left, "reproduced": right, "reason": "type"}]
    if isinstance(left, dict):
        found = []
        for key in sorted(left.keys() | right.keys()):
            if key not in left or key not in right:
                found.append(
                    {
                        "path": prefix + "/" + key,
                        "reason": "missing key",
                        "published_has": key in left,
                        "reproduced_has": key in right,
                    }
                )
            else:
                found.extend(differences(left[key], right[key], prefix + "/" + key))
            if len(found) >= 12:
                break
        return found[:12]
    if isinstance(left, list):
        if len(left) != len(right):
            return [{"path": prefix, "reason": "length", "published": len(left), "reproduced": len(right)}]
        found = []
        for index, (old, new) in enumerate(zip(left, right, strict=True)):
            found.extend(differences(old, new, prefix + "/" + str(index)))
            if len(found) >= 12:
                break
        return found[:12]
    return [] if left == right else [{"path": prefix, "published": left, "reproduced": right, "reason": "value"}]


def comparison(original: Path, reproduced: Path, name: str) -> dict[str, Any]:
    """Use byte equality unless a specifically declared metadata field varies."""
    old, new = original / name, reproduced / name
    omitted = OMISSIONS.get(name, [])
    record: dict[str, Any] = {
        "file": name,
        "mode": "exact JSON after listed omissions" if omitted else "byte-for-byte",
        "omitted_paths": [list(path) for path in omitted],
    }
    if not old.is_file() or not new.is_file():
        return {**record, "passed": False, "published_exists": old.is_file(), "reproduced_exists": new.is_file()}
    record.update(published_sha256=sha(old), reproduced_sha256=sha(new))
    record["raw_bytes_identical"] = record["published_sha256"] == record["reproduced_sha256"]
    if not omitted and record["raw_bytes_identical"]:
        return {**record, "passed": True, "mismatches": []}
    left, right = (normalized(read(path), omitted) for path in (old, new))
    mismatch = differences(left, right)
    record.update(passed=not mismatch if omitted else record["raw_bytes_identical"], mismatches=mismatch)
    if not omitted and not mismatch:
        record["mismatches"] = [{"reason": "JSON values match but file bytes differ"}]
    return record


def execute(command: list[str], root: Path) -> dict[str, Any]:
    """Run one stage and retain diagnostics without publishing temporary trees."""
    started = time.perf_counter()
    print("RUN " + " ".join(command), flush=True)
    env = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1", "PYTHONHASHSEED": "0"}
    process = subprocess.run(command, cwd=root, env=env, capture_output=True, text=True, timeout=600, check=False)
    return {
        "command": [
            "python" if index == 0 and value == sys.executable else value for index, value in enumerate(command)
        ],
        "cwd": "<TEMP_STUDY>",
        "returncode": process.returncode,
        "elapsed_seconds": time.perf_counter() - started,
        "stdout_sha256": hashlib.sha256(process.stdout.encode()).hexdigest(),
        "stderr_sha256": hashlib.sha256(process.stderr.encode()).hexdigest(),
        "stdout_tail": process.stdout[-16000:].replace(str(root), "<TEMP_STUDY>"),
        "stderr_tail": process.stderr[-16000:].replace(str(root), "<TEMP_STUDY>"),
    }


def native_invariants(root: Path) -> dict[str, bool]:
    """Retain actual validity checks when random public identities cannot match."""
    base = root / NATIVE
    summary = read(base / "summary.json")
    acceptance = read(root / "results/delivery_acceptance.json")
    checks = {
        "all_44_native_controls_pass": summary["passed"] == summary["total"] == 44
        and all(row["passed"] for row in summary["checks"]),
        "all_computational_delivery_checks_pass": acceptance["passed"] == acceptance["total"]
        and all(acceptance["checks"].values()),
        "actual_collections_remain_zero": summary["actual_collections_usd"]
        == acceptance["actual_customer_collections_usd"]
        == 0,
        "actual_complete_cost_remains_unknown": acceptance["actual_complete_cost_usd"] is None,
    }
    received = read(base / "recipient-received.json")
    library = read(base / "recipient-library.json")
    checks["fresh_and_library_outputs_equal"] = received["outputs"] == library["outputs"]
    checks["valid_shared_local_journal"] = (
        all(item["journal_after_consumption"]["valid"] for item in (received, library))
        and received["journal_after_consumption"]["identity"] == library["journal_after_consumption"]["identity"]
    )
    checks["two_distinct_recipient_processes"] = received["pid"] != library["pid"]
    checks["matching_transferred_artifact_bytes"] = all(
        sha(base / name) == sha(root / "results/retained_instrument.json")
        for name in ("source-instrument.json", "received-instrument.json", "ordinary-library-instrument.json")
    )
    for name in ("prior-origin-grant", "fresh-successor-grant", "ordinary-library-grant"):
        payload = read(base / f"{name}.json")["payload"]
        checks[f"{name}:declared_validity_window"] = payload["expires"] - payload["not_before"] == 3601
    return checks


def run() -> dict[str, Any]:
    """Replay the complete declared study without changing its original results."""
    started = time.perf_counter()
    before = manifest(ROOT)
    outcome: dict[str, Any] = {
        "schema": "agialpha.battery.reproduction.v1",
        "recorded_at_utc": datetime.now(timezone.utc).isoformat(),
        "evidence_type": "Executed reproduction of supplied cases and seeds; not independent confirmation",
        "scope": "Technical development and confirmations, existing instrument boundary tests, native integration, computational delivery acceptance, and commercial exploration/confirmation",
        "environment": environment(),
        "source_and_published_result_manifest": before,
        "commands": [],
        "comparisons": [],
        "validation": {},
        "comparison_policy": {
            "non_metadata_outputs": "Exact bytes, including all fitted model parameters, per-cell outputs, commercial worlds and summaries",
            "metadata_files": "Exact parsed JSON after file-specific omissions listed per comparison; no numeric tolerance or omitted unfavorable case",
            "technical_freeze_development_hash": "Independently validated against each run's actual development file; cannot equal because elapsed runtime is recorded",
            "random_authority": "Local ephemeral key/signature/time/identity bytes differ; bindings, authority controls, journal validity and all predictions must still pass and agree",
            "historical_exploration": "Earlier failed-attempt archives and diagnostics preserved byte-for-byte, not treated as current outputs or rerun",
        },
        "full_repository_ci_claimed": False,
        "new_external_model_calls": 0,
        "actual_customer_collections_usd": 0,
    }
    temporary: Path | None = None
    try:
        original_checks = freeze_checks(ROOT)
        outcome["validation"]["published_freeze_bindings"] = original_checks
        if not all(original_checks.values()):
            raise ValueError("Published source or result does not match its declared freeze")
        with tempfile.TemporaryDirectory(prefix="agialpha-battery-reproduce-") as directory:
            temporary = Path(directory) / ROOT.name
            shutil.copytree(
                ROOT, temporary, ignore=shutil.ignore_patterns(*IGNORE_NAMES, "*.pyc", "reproduction_check.json")
            )
            targets = TECHNICAL_OUTPUTS + ECONOMIC_OUTPUTS
            targets += [str(path.relative_to(ROOT)) for path in sorted((ROOT / "results/models").glob("*.json"))]
            targets += [str(path.relative_to(ROOT)) for path in sorted((ROOT / NATIVE).rglob("*.json"))]
            for name in TECHNICAL_OUTPUTS + ECONOMIC_OUTPUTS:
                (temporary / name).unlink(missing_ok=True)
            shutil.rmtree(temporary / "results/models")
            shutil.rmtree(temporary / NATIVE)
            outcome["regenerated_outputs_removed_before_execution"] = sorted(targets)
            commands = [
                [sys.executable, "-B", "-m", "unittest", "discover", "-s", "tests", "-p", "test_instrument.py", "-v"],
                [sys.executable, "-B", "src/study.py", "develop"],
                [sys.executable, "-B", "src/study.py", "origin"],
                [sys.executable, "-B", "src/study.py", "successor"],
                [
                    sys.executable,
                    "-B",
                    "integration/run_native_integration.py",
                    "--artifact",
                    "results/retained_instrument.json",
                    "--request",
                    "results/successor_requests.json",
                    "--engine",
                    "src/instrument.py",
                    "--out",
                    NATIVE,
                ],
                [sys.executable, "-B", "src/validate_delivery.py"],
                [sys.executable, "-B", "src/economics.py", "self-test"],
                [sys.executable, "-B", "src/economics.py", "explore"],
                [sys.executable, "-B", "src/economics.py", "confirm"],
            ]
            for command in commands:
                result = execute(command, temporary)
                outcome["commands"].append(result)
                if result["returncode"] != 0:
                    raise RuntimeError("Stage failed: " + " ".join(result["command"]))
            outcome["comparisons"] = [comparison(ROOT, temporary, name) for name in sorted(targets)]
            outcome["validation"]["reproduced_freeze_bindings"] = freeze_checks(temporary)
            outcome["validation"]["native_and_acceptance_invariants"] = native_invariants(temporary)
    except Exception as exc:
        outcome["error"] = {"type": type(exc).__name__, "message": str(exc)}
    outcome["temporary_copy_deleted"] = temporary is None or not temporary.exists()
    after = manifest(ROOT)
    outcome["original_scientific_inputs_and_results_unchanged"] = before == after
    outcome["original_changes"] = differences(before, after)
    passed = (
        "error" not in outcome
        and outcome["original_scientific_inputs_and_results_unchanged"]
        and outcome["temporary_copy_deleted"]
        and all(item["passed"] for item in outcome["comparisons"])
        and all(value for group in outcome["validation"].values() for value in group.values())
    )
    outcome["passed"] = passed
    outcome["comparisons_passed"] = sum(item["passed"] for item in outcome["comparisons"])
    outcome["comparisons_total"] = len(outcome["comparisons"])
    outcome["elapsed_seconds"] = time.perf_counter() - started
    return outcome


def main() -> None:
    """Write one reviewable receipt, preserving earlier attempts if rerun."""
    outcome = run()
    if RECEIPT.is_file():
        prior = read(RECEIPT)
        older = prior.pop("previous_runs", [])
        outcome["previous_runs"] = [*older, prior]
    RECEIPT.parent.mkdir(parents=True, exist_ok=True)
    RECEIPT.write_text(json.dumps(outcome, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(
        json.dumps(
            {
                key: outcome[key]
                for key in (
                    "passed",
                    "comparisons_passed",
                    "comparisons_total",
                    "elapsed_seconds",
                    "original_scientific_inputs_and_results_unchanged",
                )
            },
            indent=2,
        )
    )
    if "error" in outcome:
        print(json.dumps(outcome["error"], indent=2))
    raise SystemExit(0 if outcome["passed"] else 1)


if __name__ == "__main__":
    main()
