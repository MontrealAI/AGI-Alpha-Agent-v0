# SPDX-License-Identifier: Apache-2.0
"""Prospectively frozen, paired commercial scenarios for a bounded analytical dossier."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import random
import statistics
import unittest
from dataclasses import dataclass
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
PROTOCOL = ROOT / "config" / "commercial_protocol.json"
RESULTS = ROOT / "results"


def read_json(path: Path) -> dict[str, Any]:
    """Read a structured protocol or result."""
    return dict(json.loads(path.read_text()))


def write_json(name: str, value: Any) -> None:
    """Write a deterministic research result."""
    RESULTS.mkdir(parents=True, exist_ok=True)
    (RESULTS / name).write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")


def digest(path: Path) -> str:
    """Return a source commitment."""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def triangle(rng: random.Random, values: list[float]) -> float:
    """Sample a declared low, modal, high assumption."""
    return rng.triangular(values[0], values[2], values[1])


def poisson(rng: random.Random, mean: float) -> int:
    """Draw a small Poisson count without numerical dependencies."""
    threshold, product, count = math.exp(-mean), 1.0, 0
    while product > threshold:
        product *= rng.random()
        count += 1
    return count - 1


def human_reference(config: dict[str, Any]) -> dict[str, dict[str, float]]:
    """Separate employee cost, complete analytical cost and assumed selling price."""
    human = config["human_reference"]
    rates = {key: value / human["annual_hour_divisor"] for key, value in human["annual_wages"].items()}
    result: dict[str, dict[str, float]] = {}
    for name, scenario in human["scenarios"].items():
        wages = rates["data_scientist"] * scenario["analyst_hours"]
        wages += rates["electrical_engineer"] * scenario["engineer_hours"]
        labor = wages * human["benefit_multiplier"]
        overhead = labor * scenario["nonlabor_overhead_fraction"]
        total = labor + overhead + scenario["tools"]
        result[name] = {
            "hours": scenario["analyst_hours"] + scenario["engineer_hours"],
            "wages": wages,
            "labor_with_benefits": labor,
            "nonlabor_overhead": overhead,
            "tools": scenario["tools"],
            "production_cost": total,
            "assumed_selling_price": total / (1 - human["assumed_operating_margin"]),
        }
    return result


@dataclass(frozen=True)
class Policy:
    """A finite candidate price and payment arrangement."""

    ratio: float
    deposit: float
    launch: bool = True

    def as_dict(self) -> dict[str, Any]:
        """Return an auditable policy specification."""
        return {"ratio": self.ratio, "deposit": self.deposit, "launch": self.launch}


def make_world(config: dict[str, Any], seed: int) -> dict[str, Any]:
    """Fix all exogenous draws before comparing policies."""
    rng = random.Random(seed)
    market, operations = config["market"], config["operations"]
    horizon = operations["horizon_days"]
    rate = triangle(rng, market["qualified_leads_per_week_triangle"])
    success = triangle(rng, operations["initial_acceptance_probability_triangle"])
    confidence = triangle(rng, market["confidence_triangle"])
    shocks = [rng.random() < operations["weekly_common_failure_probability"] for _ in range(horizon // 7)]
    count = poisson(rng, market["max_potential_leads_per_week"] * horizon / 7)
    leads: list[dict[str, Any]] = []
    for number in range(count):
        leads.append(
            {
                "number": number,
                "day": rng.randrange(horizon),
                "thinning": rng.random(),
                "value_ratio": triangle(rng, market["value_to_reference_triangle"]),
                "confidence": max(0.3, min(0.98, confidence + rng.uniform(-0.08, 0.08))),
                "inhouse_draw": rng.random(),
                "inhouse_ratio": triangle(rng, market["inhouse_cost_to_human_production_triangle"]),
                "inhouse_quality": triangle(rng, market["inhouse_quality_triangle"]),
                "tokens": triangle(rng, operations["token_usage_multiplier_triangle"]),
                "extra_cost": triangle(rng, operations["unknown_delivery_cost_triangle"]),
                "support": triangle(rng, operations["accepted_support_cost_triangle"]),
                "retry": rng.random() < operations["retry_probability"],
                "acceptance_draw": rng.random(),
                "default_draw": rng.random(),
                "payment_delay": rng.choice(operations["payment_delay_days"]),
            }
        )
    return {"seed": seed, "lead_rate": rate, "success": success, "shocks": shocks, "leads": leads}


def buyer_choice(
    config: dict[str, Any], world: dict[str, Any], lead: dict[str, Any], policy: Policy, mods: dict[str, float]
) -> dict[str, Any]:
    """Evaluate participation against human, in-house/open-source and abstention options."""
    human = human_reference(config)["central"]
    market, operations = config["market"], config["operations"]
    reference = human["assumed_selling_price"]
    price = policy.ratio * reference
    value = lead["value_ratio"] * reference * mods.get("value_factor", 1.0)
    quality = mods.get("acceptance_probability", world["success"])
    quality *= 1 - operations["weekly_common_failure_probability"] * (
        1 - operations["common_failure_acceptance_multiplier"]
    )
    confidence = lead["confidence"]
    deposit = price * policy.deposit
    financing = deposit * market["deposit_annual_financing_rate"] * operations["job_duration_days"] / 365
    deposit_risk = deposit * (1 - confidence) * market["deposit_risk_fraction"]
    expected_price = quality * price
    utility = quality * confidence * value - expected_price
    utility -= (1 - quality) * market["agent_failure_delay_loss"] + financing + deposit_risk
    outside = {"no_buy": 0.0, "human": market["human_quality_probability"] * (value - reference)}
    inhouse_available = mods.get("inhouse_available_probability", market["inhouse_available_probability"])
    if lead["inhouse_draw"] < inhouse_available:
        cost = human["production_cost"] * lead["inhouse_ratio"] * mods.get("inhouse_cost_factor", 1.0)
        outside["inhouse_open_source"] = lead["inhouse_quality"] * value - cost
    best = max(outside, key=lambda option: outside[option])
    return {
        "buy": utility > outside[best],
        "agent_utility": utility,
        "outside_utility": outside[best],
        "outside_option": best,
        "price": price,
        "reference_discount": reference - price,
        "value": value,
    }


def resource_cost(config: dict[str, Any], lead: dict[str, Any], mods: dict[str, float], saving: float) -> float:
    """Price complete originating computational work, including a frozen retry draw."""
    tariffs, operations = config["model_tariffs"], config["operations"]
    inference = 0.0
    for name in ("discovery", "execution", "validation"):
        item = tariffs[name]
        inference += (item["input_tokens"] * item["input_rate"] + item["output_tokens"] * item["output_rate"]) / 1e6
    inference *= lead["tokens"] * mods.get("model_cost_factor", 1.0)
    reusable = inference + tariffs["search"]["calls"] * tariffs["search"]["price_per_call"]
    reusable += sum(operations[key] for key in ("execution_cost", "programmatic_verification_cost", "packaging_cost"))
    reusable *= 1 - saving
    if lead["retry"]:
        reusable *= 1 + operations["retry_resource_fraction"]
    return float(reusable + operations["storage_cost"] + lead["extra_cost"] + mods.get("extra_cost_per_job", 0.0))


def resource_reservation(config: dict[str, Any], mods: dict[str, float], saving: float) -> float:
    """Reserve the declared maximum without observing future mission consumption."""
    operations = config["operations"]
    bounded_mission = {
        "tokens": operations["token_usage_multiplier_triangle"][2],
        "extra_cost": operations["unknown_delivery_cost_triangle"][2],
        "retry": True,
    }
    return resource_cost(config, bounded_mission, mods, saving)


def simulate(
    config: dict[str, Any],
    world: dict[str, Any],
    policy: Policy,
    mods: dict[str, float] | None = None,
    retain: bool = False,
    assess: bool = False,
    saving: float = 0.0,
    success_delta: float = 0.0,
    keep_ledger: bool = False,
) -> dict[str, Any]:
    """Execute finite cash, receivable, refund, delivery and capacity accounting."""
    modifiers = mods or {}
    op, market, retention = config["operations"], config["market"], config["retention"]
    horizon = op["horizon_days"]
    seed_cash = op["initial_seed_cash"]
    reserve = op["operating_reserve_weeks"] * op["fixed_business_cost_per_week"] if policy.launch else 0.0
    balance: dict[str, float] = {
        "cash": seed_cash,
        "receivables": 0.0,
        "unearned_deposits": 0.0,
        "support_payable": 0.0,
        "processing_payable": 0.0,
        "delivery_commitments": 0.0,
        "revenue": 0.0,
        "A": 0.0,
        "B": 0.0,
        "C": 0.0,
        "acquisition": 0.0,
        "business": 0.0,
        "processing": 0.0,
        "bad_debt": 0.0,
        "customer_collections": 0.0,
        "customer_refunds": 0.0,
    }
    ledger: list[dict[str, Any]] = []
    counts = {
        key: 0 for key in ("qualified_leads", "demand", "booked", "accepted", "failed", "capacity_hold", "cash_hold")
    }
    outside_counts = {key: 0 for key in ("human", "inhouse_open_source", "no_buy")}
    used: dict[int, int] = {}
    jobs: list[dict[str, Any]] = []
    payments: list[dict[str, Any]] = []
    support: list[dict[str, Any]] = []
    value_accepted, reference_savings, buyer_surplus = 0.0, 0.0, 0.0
    active = policy.launch
    min_free = seed_cash - reserve

    def event(day: int, kind: str, amount: float = 0.0, **extra: Any) -> None:
        if keep_ledger:
            ledger.append({"day": day, "kind": kind, "amount": amount, **extra})

    def expense(day: int, category: str, amount: float, kind: str) -> None:
        balance[category] += amount
        balance["cash"] -= amount
        event(day, kind, amount, category=category)

    def free_cash() -> float:
        return (
            balance["cash"]
            - balance["unearned_deposits"]
            - balance["support_payable"]
            - balance["processing_payable"]
            - balance["delivery_commitments"]
        )

    def snapshot(day: int) -> dict[str, Any]:
        allowance = balance["receivables"] * op["noncollection_probability"]
        operating_cost = sum(
            balance[key] for key in ("A", "B", "C", "acquisition", "business", "processing", "bad_debt")
        )
        operating_cost += allowance
        profit = balance["revenue"] - operating_cost
        identity = balance["cash"] + balance["receivables"] - allowance
        identity -= (
            balance["unearned_deposits"] + balance["support_payable"] + balance["processing_payable"] + seed_cash
        )
        if abs(identity - profit) > 1e-6 or free_cash() < -1e-6:
            raise AssertionError("Cash/accrual conservation or finite-finance constraint failed")
        return {
            "day": day,
            **balance,
            **counts,
            "outside_options": dict(outside_counts),
            "receivable_allowance": allowance,
            "total_operating_cost": operating_cost,
            "operating_profit": profit,
            "contribution": balance["revenue"]
            - balance["A"]
            - balance["acquisition"]
            - balance["processing"]
            - balance["bad_debt"]
            - allowance,
            "operating_reserve": reserve,
            "available_expansion_cash": free_cash() - reserve,
            "available_funds_gain_over_seed": free_cash() - reserve - seed_cash,
            "modeled_cash_collected_net_refunds": balance["customer_collections"] - balance["customer_refunds"],
            "actual_collected_cash": 0.0,
            "accepted_customer_value_scenario": value_accepted,
            "accepted_human_reference_discount": reference_savings,
            "accepted_incremental_buyer_utility": buyer_surplus,
            "min_free_cash_after_reserve": min_free,
            "active_at_end": active,
            "balance_sheet_identity_error": identity - profit,
        }

    event(0, "seed_financing_not_revenue", seed_cash)
    if policy.launch:
        expense(0, "business", op["startup_productization_cost"], "modeled_startup_productization")
        if assess or retain:
            expense(0, "B", retention["assessment_cost"], "capability_assessment")
        if retain:
            expense(0, "B", retention["extraction_retention_cost"], "additional_extraction_retention")

    first_snapshot: dict[str, Any] = {}
    for day in range(horizon + op["settlement_tail_days"] + 1):
        for item in support:
            if item["day"] == day:
                balance["cash"] -= item["amount"]
                balance["support_payable"] -= item["amount"]
                event(day, "pay_previously_accrued_support", item["amount"])
        for item in payments:
            if item["day"] == day:
                balance["receivables"] -= item["amount"]
                if item["default"]:
                    balance["bad_debt"] += item["amount"]
                    balance["processing_payable"] -= item["processing_fee"]
                    balance["processing"] -= item["processing_fee"]
                    event(day, "uncollected_invoice_writeoff", item["amount"])
                    event(day, "release_unused_invoice_processing_accrual", item["processing_fee"])
                else:
                    balance["cash"] += item["amount"]
                    balance["customer_collections"] += item["amount"]
                    event(day, "collect_accepted_invoice", item["amount"])
                    balance["cash"] -= item["processing_fee"]
                    balance["processing_payable"] -= item["processing_fee"]
                    event(day, "pay_previously_accrued_invoice_processing", item["processing_fee"])
        for job in jobs:
            if job["due"] != day:
                continue
            lead = job["lead"]
            balance["delivery_commitments"] -= job["commitment"]
            balance["unearned_deposits"] -= job["deposit"]
            realized_resources = resource_cost(config, lead, modifiers, saving if retain else 0.0)
            if realized_resources > job["resource_cap"] + 1e-9:
                raise AssertionError("Realized delivery consumption exceeded its declared ex-ante bound")
            expense(day, "A", realized_resources, "realized_delivery_including_verification_retry_packaging")
            if job["accepted"]:
                counts["accepted"] += 1
                balance["revenue"] += job["price"]
                remainder = job["price"] - job["deposit"]
                balance["receivables"] += remainder
                processing_fee = remainder * op["payment_processing_fraction"]
                balance["processing"] += processing_fee
                balance["processing_payable"] += processing_fee
                event(day, "accepted_invoice_processing_accrual", processing_fee)
                payments.append(
                    {
                        "day": day + lead["payment_delay"],
                        "amount": remainder,
                        "processing_fee": processing_fee,
                        "default": lead["default_draw"] < op["noncollection_probability"],
                    }
                )
                support_cost = lead["support"] * modifiers.get("support_cost_factor", 1.0)
                balance["A"] += support_cost
                balance["support_payable"] += support_cost
                expense(day, "A", op["settlement_tail_cost_per_accepted_job"], "prepaid_automated_settlement_tail")
                support.append({"day": day + 14, "amount": support_cost})
                value_accepted += job["choice"]["value"]
                reference_savings += job["choice"]["reference_discount"]
                buyer_surplus += job["choice"]["agent_utility"] - job["choice"]["outside_utility"]
                event(
                    day,
                    "accepted_dossier_revenue",
                    job["price"],
                    job=lead["number"],
                    meaning="Analytical acceptance; a supported no-go can pass",
                )
                event(day, "support_accrual_no_second_expense_on_payment", support_cost)
            else:
                counts["failed"] += 1
                balance["cash"] -= job["deposit"]
                balance["customer_refunds"] += job["deposit"]
                expense(day, "A", op["refund_processing_cost"], "failed_delivery_refund_processing")
                event(day, "full_deposit_refund_no_revenue", job["deposit"], job=lead["number"])
        if day < horizon and day % 7 == 0 and active:
            weekly = op["fixed_business_cost_per_week"] + (retention["maintenance_cost_per_week"] if retain else 0)
            if free_cash() < weekly + reserve:
                active = False
                event(day, "stop_new_business_for_finite_finance")
            else:
                expense(day, "business", op["fixed_business_cost_per_week"], "fixed_business")
                if retain:
                    expense(day, "B", retention["maintenance_cost_per_week"], "retained_capability_maintenance")
        if day < horizon and active:
            for lead in sorted(
                (item for item in world["leads"] if item["day"] == day), key=lambda item: item["number"]
            ):
                keep_probability = world["lead_rate"] / market["max_potential_leads_per_week"]
                keep_probability *= modifiers.get("demand_factor", 1.0)
                if lead["thinning"] >= min(1.0, keep_probability):
                    continue
                acquisition = market["acquisition_cost_per_qualified_lead"] * modifiers.get(
                    "acquisition_cost_factor", 1.0
                )
                if free_cash() < acquisition + reserve:
                    counts["cash_hold"] += 1
                    continue
                expense(day, "acquisition", acquisition, "qualified_lead_acquisition")
                counts["qualified_leads"] += 1
                choice = buyer_choice(config, world, lead, policy, modifiers)
                outside_counts[choice["outside_option"]] += 1
                if not choice["buy"]:
                    continue
                counts["demand"] += 1
                week = day // 7
                if used.get(week, 0) >= op["capacity_per_week"]:
                    counts["capacity_hold"] += 1
                    continue
                resource_cap = resource_reservation(config, modifiers, saving if retain else 0.0)
                invocation = retention["invocation_cost"] if retain else 0.0
                deposit = choice["price"] * policy.deposit
                processing = deposit * op["payment_processing_fraction"]
                commitment = op["accepted_support_cost_triangle"][2] * modifiers.get("support_cost_factor", 1.0)
                commitment += op["refund_processing_cost"]
                commitment += resource_cap + (choice["price"] - deposit) * op["payment_processing_fraction"]
                commitment += op["settlement_tail_cost_per_accepted_job"]
                if free_cash() < invocation + processing + commitment + reserve:
                    counts["cash_hold"] += 1
                    continue
                used[week] = used.get(week, 0) + 1
                counts["booked"] += 1
                balance["cash"] += deposit
                balance["customer_collections"] += deposit
                balance["unearned_deposits"] += deposit
                balance["delivery_commitments"] += commitment
                expense(day, "processing", processing, "deposit_processing")
                if retain:
                    expense(day, "B", invocation, "retained_capability_invocation")
                success = modifiers.get("acceptance_probability", world["success"])
                if world["shocks"][week]:
                    success *= op["common_failure_acceptance_multiplier"]
                success = max(0.0, min(1.0, success + (success_delta if retain else 0.0)))
                jobs.append(
                    {
                        "lead": lead,
                        "due": day + op["job_duration_days"],
                        "deposit": deposit,
                        "price": choice["price"],
                        "commitment": commitment,
                        "resource_cap": resource_cap,
                        "accepted": lead["acceptance_draw"] < success,
                        "choice": choice,
                    }
                )
                event(day, "refundable_deposit_is_liability", deposit, job=lead["number"])
        min_free = min(min_free, free_cash() - reserve)
        if day == horizon:
            first_snapshot = snapshot(day)
    terminal = snapshot(horizon + op["settlement_tail_days"])
    if any(
        abs(terminal[key]) > 1e-6
        for key in ("receivables", "unearned_deposits", "support_payable", "processing_payable", "delivery_commitments")
    ):
        raise AssertionError("Settlement tail did not close all obligations")
    return {"seed": world["seed"], "day84": first_snapshot, "settled": terminal, "ledger": ledger}


def describe(values: list[float]) -> dict[str, float]:
    """Describe conditional scenario variation, not empirical market uncertainty."""
    ordered = sorted(values)
    count = len(values)
    mean = statistics.mean(values)
    standard_error = statistics.stdev(values) / math.sqrt(count) if count > 1 else 0.0
    return {
        "mean": mean,
        "median": statistics.median(values),
        "p05": ordered[int(0.05 * (count - 1))],
        "p95": ordered[int(0.95 * (count - 1))],
        "positive_fraction": sum(value > 0 for value in values) / count,
        "monte_carlo_mean_95_low": mean - 1.96 * standard_error,
        "monte_carlo_mean_95_high": mean + 1.96 * standard_error,
    }


def summarize(runs: list[dict[str, Any]]) -> dict[str, Any]:
    """Summarize all economically distinct results."""
    keys = (
        "operating_profit",
        "revenue",
        "total_operating_cost",
        "contribution",
        "accepted",
        "booked",
        "failed",
        "qualified_leads",
        "demand",
        "capacity_hold",
        "cash_hold",
        "available_funds_gain_over_seed",
        "available_expansion_cash",
        "cash",
        "receivables",
        "unearned_deposits",
        "support_payable",
        "processing_payable",
        "delivery_commitments",
        "modeled_cash_collected_net_refunds",
        "A",
        "B",
        "C",
        "business",
        "acquisition",
        "processing",
        "bad_debt",
        "accepted_incremental_buyer_utility",
    )
    return {stage: {key: describe([run[stage][key] for run in runs]) for key in keys} for stage in ("day84", "settled")}


def explore(config: dict[str, Any]) -> None:
    """Select only on development seeds, then persist the source-bound freeze."""
    seeds = config["seeds"]
    worlds = [make_world(config, seeds["development_start"] + index) for index in range(seeds["development_worlds"])]
    grid = config["policy_grid"]
    policies = [Policy(ratio, deposit) for ratio in grid["price_ratios"] for deposit in grid["deposit_fractions"]]
    if grid["include_no_launch"]:
        policies.append(Policy(0.0, 0.0, False))
    candidates: list[dict[str, Any]] = []
    for policy in policies:
        runs = [simulate(config, world, policy) for world in worlds]
        candidates.append(
            {
                "policy": policy.as_dict(),
                "summary": summarize(runs),
                "world_outcomes": [{"seed": run["seed"], "day84": run["day84"]} for run in runs],
            }
        )
    selected = max(candidates, key=lambda item: item["summary"]["day84"]["available_funds_gain_over_seed"]["mean"])
    policy = Policy(**selected["policy"])
    unretained = [simulate(config, world, policy, assess=True) for world in worlds]
    learning_results: list[dict[str, Any]] = []
    weighted_gain = 0.0
    for assumption in config["retention"]["development_uncertainty"]:
        retained = [
            simulate(
                config,
                world,
                policy,
                retain=True,
                assess=True,
                saving=assumption["resource_savings_fraction"],
                success_delta=assumption["acceptance_probability_delta"],
            )
            for world in worlds
        ]
        differences = [
            new["day84"]["available_funds_gain_over_seed"] - old["day84"]["available_funds_gain_over_seed"]
            for new, old in zip(retained, unretained, strict=True)
        ]
        result = {"assumption": assumption, "paired_available_funds_gain": describe(differences)}
        learning_results.append(result)
        weighted_gain += assumption["weight"] * result["paired_available_funds_gain"]["mean"]
    exploration = {
        "evidence": config["evidence_label"],
        "human_reference": human_reference(config),
        "candidates": candidates,
        "retention_exploration": learning_results,
        "weighted_incremental_retention_gain_after_assessment": weighted_gain,
    }
    write_json("economics_exploration.json", exploration)
    freeze = {
        "source_sha256": digest(Path(__file__)),
        "protocol_sha256": digest(PROTOCOL),
        "exploration_sha256": digest(RESULTS / "economics_exploration.json"),
        "policy": policy.as_dict(),
        "retain": weighted_gain > 0,
        "retention_assessment_is_charged": True,
        "retention_primary_saving": 0.0,
        "retention_primary_success_delta": 0.0,
        "development_seed_range": [seeds["development_start"], seeds["development_start"] + len(worlds) - 1],
        "confirmation_seed_range": [
            seeds["confirmation_start"],
            seeds["confirmation_start"] + seeds["confirmation_worlds"] - 1,
        ],
        "policy_selection_objective": grid["objective"],
        "confirmation_has_run_at_freeze": False,
        "note": "Written before fresh confirmation. Any source/protocol change requires new exploration and freeze.",
    }
    write_json("economics_freeze.json", freeze)
    print(
        json.dumps(
            {
                "selected": policy.as_dict(),
                "human": human_reference(config),
                "development_profit": selected["summary"]["day84"]["operating_profit"],
                "weighted_retention_gain": weighted_gain,
                "freeze": str(RESULTS / "economics_freeze.json"),
            },
            indent=2,
        )
    )


def confirm(config: dict[str, Any]) -> None:
    """Run only the committed policy on fresh paired worlds and declared stresses."""
    freeze = read_json(RESULTS / "economics_freeze.json")
    if freeze["source_sha256"] != digest(Path(__file__)) or freeze["protocol_sha256"] != digest(PROTOCOL):
        raise ValueError(
            "Source/protocol changed after freeze; preserve old outcomes and freeze a prospective revision"
        )
    seeds = config["seeds"]
    worlds = [make_world(config, seeds["confirmation_start"] + index) for index in range(seeds["confirmation_worlds"])]
    policy = Policy(**freeze["policy"])
    plain = [simulate(config, world, policy) for world in worlds]
    selected = [simulate(config, world, policy, retain=freeze["retain"], assess=True) for world in worlds]
    null_retention = [simulate(config, world, policy, retain=True, assess=True) for world in worlds]

    def diff(new: list[dict[str, Any]], old: list[dict[str, Any]]) -> list[float]:
        return [a["day84"]["operating_profit"] - b["day84"]["operating_profit"] for a, b in zip(new, old, strict=True)]

    confirmation = {
        "evidence": config["evidence_label"],
        "source_sha256": freeze["source_sha256"],
        "protocol_sha256": freeze["protocol_sha256"],
        "freeze_sha256": digest(RESULTS / "economics_freeze.json"),
        "worlds": len(worlds),
        "policy": policy.as_dict(),
        "human_reference": human_reference(config),
        "E_direct_delivery": summarize(plain),
        "selected_optional_retention_policy": summarize(selected),
        "forced_null_benefit_E_plus": summarize(null_retention),
        "selected_minus_E_paired_operating_profit": describe(diff(selected, plain)),
        "null_E_plus_minus_E_paired_operating_profit": describe(diff(null_retention, plain)),
        "ordinary_identical_information_library_minus_E_plus": 0.0,
        "ordinary_library_interpretation": "Modeled equality by construction: identical reusable artifacts, execution and costs. The technical same-information control is a separate study result.",
        "operational_alpha": {
            "H": "Estimated analytical service reference",
            "U": "Unmeasured",
            "E": "Modeled operating performance only",
            "E_plus": "Modeled null-benefit retention only",
            "empirical_E_minus_U": None,
            "empirical_E_plus_minus_E": None,
        },
        "world_outcomes": [
            {
                "seed": run["seed"],
                "E": run["day84"],
                "E_settled": run["settled"],
                "selected": learned["day84"],
                "forced_null_E_plus": null["day84"],
            }
            for run, learned, null in zip(plain, selected, null_retention, strict=True)
        ],
        "interval_interpretation": "Percentiles span specified hypothetical worlds; mean intervals quantify simulation sampling error only.",
    }
    write_json("economics_confirmation.json", confirmation)
    stresses: list[dict[str, Any]] = []
    for scenario in config["sensitivities"]:
        runs = [simulate(config, world, policy, scenario["modifiers"]) for world in worlds]
        stresses.append(
            {
                "name": scenario["name"],
                "modifiers": scenario["modifiers"],
                "summary": summarize(runs),
                "paired_operating_profit_change": describe(diff(runs, plain)),
            }
        )
    write_json(
        "economics_sensitivity.json",
        {
            "freeze_sha256": digest(RESULTS / "economics_freeze.json"),
            "same_policy_all_stresses": True,
            "scenarios": stresses,
        },
    )
    write_json("economics_example_ledger.json", simulate(config, worlds[0], policy, keep_ledger=True))
    direct_summary = confirmation["E_direct_delivery"]
    price = human_reference(config)["central"]["assumed_selling_price"] * policy.ratio
    support_mean = sum(config["operations"]["accepted_support_cost_triangle"]) / 3
    acceptance_value = price - support_mean - config["operations"]["settlement_tail_cost_per_accepted_job"]
    acceptance_value += config["operations"]["refund_processing_cost"]
    unpaid_fraction = 1 - policy.deposit
    noncollection = config["operations"]["noncollection_probability"]
    acceptance_value -= (
        price
        * unpaid_fraction
        * (noncollection + config["operations"]["payment_processing_fraction"] * (1 - noncollection))
    )
    operational_boundary = []
    for premium in (0, 25, 75, 150):
        increment = premium / acceptance_value if acceptance_value > 0 else None
        operational_boundary.append(
            {"assumed_E_cost_premium_per_attempt": premium, "required_final_acceptance_probability_gain": increment}
        )
    brief = {
        "evidence": config["evidence_label"],
        "protocol_version": config["version"],
        "price": price,
        "policy": policy.as_dict(),
        "human_reference": human_reference(config),
        "retention_admitted": freeze["retain"],
        "E": direct_summary,
        "E_with_assessment_and_selected_retention": confirmation["selected_optional_retention_policy"],
        "E_plus_forced_null_benefit": confirmation["forced_null_benefit_E_plus"],
        "paired_optional_policy_minus_E": confirmation["selected_minus_E_paired_operating_profit"],
        "paired_forced_null_E_plus_minus_E": confirmation["null_E_plus_minus_E_paired_operating_profit"],
        "complete_modeled_cost_per_accepted": {
            stage: direct_summary[stage]["total_operating_cost"]["mean"]
            / max(1e-12, direct_summary[stage]["accepted"]["mean"])
            for stage in ("day84", "settled")
        },
        "cost_per_accepted_interpretation": "Ratio of summed modeled costs to summed accepted dossiers, including worlds with zero acceptance. day84 is the operating-period accrual measure; settled closes all commitments from that period. Actual complete cost remains unknown.",
        "fixed_volume_extra_cost_break_even_per_booking": direct_summary["day84"]["operating_profit"]["mean"]
        / max(1e-12, direct_summary["day84"]["booked"]["mean"]),
        "extra_cost_break_even_caveat": "Linear approximation holds volume and financing constant. Declared extra-cost sensitivities reapply cash admission and can change volume; use their full outcomes for those conditions.",
        "operational_alpha_break_even": operational_boundary,
        "operational_alpha_boundary_formula": "p_E - p_U >= (c_E-c_U)/(price-mean_support-prepaid_tail+failed_delivery_refund_cost-expected_remaining_invoice_noncollection_and_fees). Uses final accepted-dossier probability; assumes same frontier model set, price, demand, capacity, terms and support scope. Premiums are hypothetical; no U/E success rate or cost advantage is measured.",
        "stress_means": [
            {
                "name": item["name"],
                "operating_profit": item["summary"]["day84"]["operating_profit"]["mean"],
                "profit_p05": item["summary"]["day84"]["operating_profit"]["p05"],
                "profit_p95": item["summary"]["day84"]["operating_profit"]["p95"],
                "positive_fraction": item["summary"]["day84"]["operating_profit"]["positive_fraction"],
                "accepted": item["summary"]["day84"]["accepted"]["mean"],
                "booked": item["summary"]["day84"]["booked"]["mean"],
            }
            for item in stresses
        ],
        "actual_customer_collections": 0,
        "actual_research_and_engineering_total_cost": None,
    }
    write_json("economics_summary.json", brief)
    print(
        json.dumps(
            {
                "policy": policy.as_dict(),
                "direct_operating_profit": confirmation["E_direct_delivery"]["day84"]["operating_profit"],
                "optional_retention_admitted": freeze["retain"],
                "null_retention_increment": confirmation["null_E_plus_minus_E_paired_operating_profit"],
                "actual_collections": 0,
                "worlds": len(worlds),
            },
            indent=2,
        )
    )


class AccountingTests(unittest.TestCase):
    """Independent invariants for money, authority of outcomes and buyer incentives."""

    def test_no_launch_has_no_service_revenue(self) -> None:
        config = read_json(PROTOCOL)
        result = simulate(config, make_world(config, 9), Policy(0, 0, False))["settled"]
        self.assertEqual(result["revenue"], 0)
        self.assertEqual(result["cash"], config["operations"]["initial_seed_cash"])
        self.assertEqual(result["actual_collected_cash"], 0)

    def test_failures_refund_and_do_not_become_sales(self) -> None:
        config = read_json(PROTOCOL)
        world = make_world(config, 8)
        for lead in world["leads"]:
            lead["acceptance_draw"] = 1.0
            lead["inhouse_draw"] = 1.0
        result = simulate(config, world, Policy(0.25, 1.0))["settled"]
        self.assertGreater(result["booked"], 0)
        self.assertEqual(result["accepted"], 0)
        self.assertEqual(result["revenue"], 0)
        self.assertAlmostEqual(result["customer_collections"], result["customer_refunds"])
        self.assertLess(result["operating_profit"], 0)

    def test_price_changes_recompute_participation(self) -> None:
        config = read_json(PROTOCOL)
        world = make_world(config, 27)
        for lead in world["leads"]:
            low = buyer_choice(config, world, lead, Policy(0.25, 0.25), {})
            high = buyer_choice(config, world, lead, Policy(0.75, 0.25), {})
            self.assertGreater(low["agent_utility"], high["agent_utility"])
            self.assertFalse(high["buy"] and not low["buy"])

    def test_receivables_cash_and_capacity_are_distinct(self) -> None:
        config = read_json(PROTOCOL)
        config["operations"]["initial_seed_cash"] = 100000
        result = simulate(config, make_world(config, 271000), Policy(0.25, 0.25))
        self.assertGreater(result["day84"]["receivables"], 0)
        self.assertAlmostEqual(result["settled"]["receivables"], 0)
        self.assertLessEqual(result["day84"]["booked"], 12 * config["operations"]["capacity_per_week"])
        self.assertGreaterEqual(result["settled"]["min_free_cash_after_reserve"], -1e-6)

    def test_zero_gain_retention_is_not_free(self) -> None:
        config = read_json(PROTOCOL)
        config["operations"]["initial_seed_cash"] = 100000
        world = make_world(config, 271000)
        direct = simulate(config, world, Policy(0.25, 0.25))
        retained = simulate(config, world, Policy(0.25, 0.25), retain=True, assess=True)
        self.assertGreater(retained["day84"]["B"], 0)
        self.assertEqual(retained["day84"]["booked"], direct["day84"]["booked"])
        self.assertLess(retained["day84"]["operating_profit"], direct["day84"]["operating_profit"])

    def test_admission_cannot_see_future_resource_draws(self) -> None:
        config = read_json(PROTOCOL)
        config["operations"]["initial_seed_cash"] = 2600
        config["market"]["acquisition_cost_per_qualified_lead"] = 0
        world = make_world(config, 3)
        lead = dict(world["leads"][0])
        lead.update(
            day=0,
            thinning=0,
            value_ratio=1.5,
            confidence=0.99,
            inhouse_draw=1,
            acceptance_draw=0,
            default_draw=1,
            tokens=0.5,
            extra_cost=0,
            retry=False,
        )
        world.update(
            lead_rate=12, success=0.95, shocks=[False] * 12, leads=[dict(lead, number=0), dict(lead, number=1)]
        )
        expensive = json.loads(json.dumps(world))
        for item in expensive["leads"]:
            item.update(tokens=3, extra_cost=150, retry=True)
        low = simulate(config, world, Policy(0.5, 1.0))
        high = simulate(config, expensive, Policy(0.5, 1.0))
        self.assertEqual(low["day84"]["booked"], 1)
        self.assertEqual(high["day84"]["booked"], 1)
        self.assertGreater(high["day84"]["A"], low["day84"]["A"])

    def test_invoice_fees_accrue_before_collection(self) -> None:
        config = read_json(PROTOCOL)
        config["operations"].update(
            startup_productization_cost=0, fixed_business_cost_per_week=0, noncollection_probability=0
        )
        config["market"]["acquisition_cost_per_qualified_lead"] = 0
        world = make_world(config, 3)
        lead = dict(world["leads"][0])
        lead.update(
            day=70,
            thinning=0,
            value_ratio=1.5,
            confidence=0.99,
            inhouse_draw=1,
            acceptance_draw=0,
            default_draw=1,
            payment_delay=42,
            support=24,
        )
        world.update(lead_rate=12, success=0.98, shocks=[False] * 12, leads=[lead])
        result = simulate(config, world, Policy(0.25, 0.25))
        first, last = result["day84"], result["settled"]
        self.assertEqual(first["accepted"], 1)
        self.assertGreater(first["receivables"], 0)
        self.assertAlmostEqual(first["processing_payable"], first["receivables"] * 0.03)
        self.assertAlmostEqual(first["operating_profit"], last["operating_profit"])
        self.assertAlmostEqual(last["processing_payable"], 0)

    def test_buyer_expectation_uses_frequency_not_future_shock(self) -> None:
        config = read_json(PROTOCOL)
        world = make_world(config, 3)
        lead = dict(world["leads"][0], value_ratio=2, confidence=0.9)
        before = buyer_choice(config, world, lead, Policy(0.25, 0.25), {})
        world["shocks"] = [not item for item in world["shocks"]]
        after = buyer_choice(config, world, lead, Policy(0.25, 0.25), {})
        self.assertEqual(before, after)
        config["operations"]["weekly_common_failure_probability"] = 1
        adverse = buyer_choice(config, world, lead, Policy(0.25, 0.25), {})
        self.assertLess(adverse["agent_utility"], before["agent_utility"])


def main() -> None:
    """Expose separate exploration, freeze, confirmation and self-check stages."""
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=("explore", "confirm", "self-test"))
    args = parser.parse_args()
    if args.stage == "self-test":
        suite = unittest.defaultTestLoader.loadTestsFromTestCase(AccountingTests)
        result = unittest.TextTestRunner(verbosity=2).run(suite)
        if not result.wasSuccessful():
            raise SystemExit(1)
    elif args.stage == "explore":
        explore(read_json(PROTOCOL))
    else:
        confirm(read_json(PROTOCOL))


if __name__ == "__main__":
    main()
