# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "figures"
PURPLE, LIGHT, TEAL, GRAY = "#6635B4", "#B99BEA", "#087F8C", "#94A0AD"
plt.rcParams.update(
    {
        "font.family": "DejaVu Sans",
        "font.size": 10,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.labelcolor": "#241733",
        "text.color": "#241733",
        "axes.titleweight": "bold",
        "savefig.facecolor": "white",
    }
)


def read(name: str) -> Any:
    return json.loads((ROOT / name).read_text())


def save(fig: Any, name: str) -> None:
    OUT.mkdir(exist_ok=True)
    fig.savefig(OUT / f"{name}.png", dpi=220, bbox_inches="tight")
    fig.savefig(OUT / f"{name}.svg", bbox_inches="tight")
    plt.close(fig)


def technical() -> None:
    origin = read("results/origin_confirmation.json")
    successor = read("results/successor_confirmation.json")
    methods = ["chemistry_median", "two_pulse_raw", "two_pulse_delta", "five_pulse_delta"]
    labels = [
        "Cohort median\n(no pulse)",
        "Two pulses\nraw features",
        "Two pulses\nretained instrument",
        "Five pulses\nstrong reference",
    ]
    fig, axes = plt.subplots(1, 2, figsize=(10, 4.1), sharey=True)
    for axis, report, title in zip(
        axes,
        [origin, successor],
        ["Origin · 31 fresh cells · threshold 0.80", "Successor · 30 fresh cells · threshold 0.75"],
    ):
        values = [100 * report["method_summaries"][m]["mae"] for m in methods]
        bars = axis.bar(np.arange(len(methods)), values, color=[GRAY, LIGHT, PURPLE, TEAL], width=0.65)
        axis.set_xticks(np.arange(len(methods)), labels, fontsize=8)
        axis.set_title(title, fontsize=10)
        axis.set_ylim(0, 8.1)
        axis.bar_label(bars, labels=[f"{v:.2f}" for v in values], padding=4, fontsize=9)
        axis.grid(axis="y", alpha=0.14)
        axis.set_axisbelow(True)
    axes[0].set_ylabel("Mean absolute SOH error (percentage points)")
    fig.tight_layout(w_pad=2)
    save(fig, "01_prediction_results")

    fig, axes = plt.subplots(1, 2, figsize=(10, 3.8))
    for axis, report, title in zip(
        axes,
        [origin, successor],
        ["Origin: useful refusals remain obligations", "Successor: inherited model, new purpose"],
    ):
        names = ["Selected two-pulse", "Strong five-pulse"]
        ms = [report["method_summaries"][m] for m in ["two_pulse_delta", "five_pulse_delta"]]
        decisive = [m["decisive_cells"] for m in ms]
        fallback = [m["full_capacity_test_referrals"] for m in ms]
        axis.barh(names, decisive, color=PURPLE, label="Capacity disposition")
        axis.barh(names, fallback, left=decisive, color="#DAD6E4", label="Full test still required")
        for i, (a, b) in enumerate(zip(decisive, fallback)):
            axis.text(a / 2, i, str(a), ha="center", va="center", color="white", weight="bold")
            axis.text(a + b / 2, i, str(b), ha="center", va="center", color="#35244F")
        axis.set_xlabel("Physical cells")
        axis.set_xlim(0, 33)
        axis.set_title(title, fontsize=10)
        axis.invert_yaxis()
    handles, names = axes[0].get_legend_handles_labels()
    fig.legend(handles, names, loc="lower center", ncol=2, frameon=False)
    fig.tight_layout(rect=(0, 0.1, 1, 1))
    save(fig, "02_decisions_and_obligations")

    fig, axes = plt.subplots(1, 2, figsize=(10, 3.9), sharey=True)
    for axis, report, title in zip(axes, [origin, successor], ["Origin · 31 cells", "Successor · 30 cells"]):
        ms = [report["method_summaries"][m] for m in ["chemistry_median", "two_pulse_delta", "five_pulse_delta"]]
        values = [m["customer_testing_plus_wrong_decision_cost_usd_scenario"] for m in ms]
        bars = axis.bar(
            ["All full tests", "Two-pulse policy", "Five-pulse policy"], values, color=[GRAY, PURPLE, TEAL], width=0.6
        )
        axis.bar_label(bars, labels=[f"${v:.2f}" for v in values], padding=4)
        axis.set_ylim(0, 900)
        axis.set_title(title)
        axis.tick_params(axis="x", labelsize=9)
        axis.grid(axis="y", alpha=0.12)
        axis.set_axisbelow(True)
    axes[0].set_ylabel("Customer testing expense, USD (scenario)")
    fig.suptitle("A shorter pulse sequence need not minimize complete testing cost", fontsize=12, weight="bold")
    fig.tight_layout(rect=(0, 0, 1, 0.93))
    save(fig, "03_customer_testing_economics")


def commercial() -> None:
    summary = read("results/economics_summary.json")
    day = summary["E"]["day84"]
    fig, axes = plt.subplots(1, 2, figsize=(10.2, 4.3), gridspec_kw={"width_ratios": [1, 1.25]})
    names = ["Accepted\nrevenue", "Delivery", "Acquisition", "Payments", "Business", "Operating\nprofit"]
    levels = [
        day[k]["mean"] / 1000 for k in ["revenue", "A", "acquisition", "processing", "business", "operating_profit"]
    ]
    balance = levels[0]
    for i, value in enumerate(levels):
        if i in (0, 5):
            bottom, color = 0, TEAL if i == 0 else PURPLE
        else:
            bottom, color = balance - value, "#B6A6C9"
            balance = bottom
        axes[0].bar(i, value, bottom=bottom, color=color, width=0.68)
        axes[0].text(i, bottom + value + 0.25, f"{value:.2f}", ha="center", fontsize=8)
    axes[0].set_xticks(range(6), names, fontsize=7)
    axes[0].set_ylim(0, 21)
    axes[0].set_ylabel("Mean USD thousands / 12 weeks")
    axes[0].set_title("Complete direct-service economics", fontsize=11)
    stresses = {x["name"]: x for x in summary["stress_means"]}
    cases = [
        ("Base", "base"),
        ("Half demand", "half_demand"),
        ("Model cost ×4", "model_cost_4x"),
        ("Extra $250 / booking", "extra_unknown_cost_250"),
        ("Baseline acceptance 0.60", "mission_acceptance_060"),
        ("Cheap in-house for all", "cheaper_open_source_inhouse"),
    ]
    values = [stresses[key]["operating_profit"] / 1000 for _, key in cases]
    bars = axes[1].barh([label for label, _ in cases], values, color=[PURPLE if x >= 0 else "#A14D67" for x in values])
    axes[1].bar_label(bars, labels=[f"{x:+.2f}" for x in values], padding=4, fontsize=9)
    axes[1].axvline(0, color="#655C70", lw=0.8)
    axes[1].set_xlim(-6.8, 8.4)
    axes[1].invert_yaxis()
    axes[1].tick_params(axis="y", labelsize=8)
    axes[1].set_xlabel("Mean operating profit, USD thousands")
    axes[1].set_title("The same price can win or lose", fontsize=11)
    for ax in axes:
        ax.grid(axis="y" if ax is axes[0] else "x", alpha=0.1)
        ax.set_axisbelow(True)
    fig.suptitle("Conditional simulation · 1,000 fresh worlds · actual collections $0", fontsize=12, weight="bold")
    fig.tight_layout(rect=(0, 0, 1, 0.94), w_pad=2)
    save(fig, "04_commercial_result")


def main() -> None:
    technical()
    commercial()
    print(json.dumps({"figures": sorted(p.name for p in OUT.glob("*"))}))


if __name__ == "__main__":
    main()
