# Open the result. Inspect the evidence. Reproduce the study.

**AGI ALPHA FLYWHEEL — The Autonomous Work Economy · AWE-2026-01**

1. **Try the demonstration:** open `demo/AGI_ALPHA_Autonomous_Work_Economy.html` and choose **Try it now / Essayer**. It works offline and supports your permitted quote CSV, result exports, stop and recovery. No account, key, wallet or purchase is involved.
2. **Read the paper:** open `paper/AGI_ALPHA_Autonomous_Work_Economy.pdf`. Complete standalone LaTeX, bibliography, vector figures and underlying data are included.
3. **Inspect the evidence:** the directory guide in `README.md` identifies frozen protocols, every original outcome, negative results, economic assumptions and verification receipts.
4. **Reproduce:** with Node 22+, Python 3.11–3.13, NumPy and SciPy installed, run from this extracted directory:

```sh
python3 reproduce.py --output /tmp/awe-reproduction-new
```

Choose an output directory that does not already exist and is outside this companion. The command preserves the supplied evidence. Exact outcomes and arithmetic should agree; timings and timestamp-based identities can differ.

The equipment cart's price is separate from the unknown actual full cost of AGI ALPHA. Local execution, recorded evidence and economic scenarios are labeled separately. The complete authenticated autonomous enterprise, actual customer payments and self-acceleration were not established.

`SHA256SUMS` at the archive root lists the exact delivered files. On Linux, run `sha256sum -c SHA256SUMS`; on macOS, run `shasum -a 256 -c SHA256SUMS`. Historical manifests remain unchanged; their original scopes and dates still apply.

## Français

Ouvrez la démonstration HTML, puis **Essayer**. L’interface et le rapport exporté existent en français. Le PDF présente l’étude complète; les données et programmes permettent d’en vérifier les résultats. Les calculs économiques restent des scénarios explicitement déclarés, et non des coûts ou des recettes observés.
