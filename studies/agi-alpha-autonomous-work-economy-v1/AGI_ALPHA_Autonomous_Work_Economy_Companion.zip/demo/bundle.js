/*
                                 Apache License
                           Version 2.0, January 2004
                        http://www.apache.org/licenses/

   TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

   1. Definitions.

      "License" shall mean the terms and conditions for use, reproduction,
      and distribution as defined by Sections 1 through 9 of this document.

      "Licensor" shall mean the copyright owner or entity authorized by
      the copyright owner that is granting the License.

      "Legal Entity" shall mean the union of the acting entity and all
      other entities that control, are controlled by, or are under common
      control with that entity. For the purposes of this definition,
      "control" means (i) the power, direct or indirect, to cause the
      direction or management of such entity, whether by contract or
      otherwise, or (ii) ownership of fifty percent (50%) or more of the
      outstanding shares, or (iii) beneficial ownership of such entity.

      "You" (or "Your") shall mean an individual or Legal Entity
      exercising permissions granted by this License.

      "Source" form shall mean the preferred form for making modifications,
      including but not limited to software source code, documentation
      source, and configuration files.

      "Object" form shall mean any form resulting from mechanical
      transformation or translation of a Source form, including but
      not limited to compiled object code, generated documentation,
      and conversions to other media types.

      "Work" shall mean the work of authorship, whether in Source or
      Object form, made available under the License, as indicated by a
      copyright notice that is included in or attached to the work
      (an example is provided in the Appendix below).

      "Derivative Works" shall mean any work, whether in Source or Object
      form, that is based on (or derived from) the Work and for which the
      editorial revisions, annotations, elaborations, or other modifications
      represent, as a whole, an original work of authorship. For the purposes
      of this License, Derivative Works shall not include works that remain
      separable from, or merely link (or bind by name) to the interfaces of,
      the Work and Derivative Works thereof.

      "Contribution" shall mean any work of authorship, including
      the original version of the Work and any modifications or additions
      to that Work or Derivative Works thereof, that is intentionally
      submitted to Licensor for inclusion in the Work by the copyright owner
      or by an individual or Legal Entity authorized to submit on behalf of
      the copyright owner. For the purposes of this definition, "submitted"
      means any form of electronic, verbal, or written communication sent
      to the Licensor or its representatives, including but not limited to
      communication on electronic mailing lists, source code control systems,
      and issue tracking systems that are managed by, or on behalf of, the
      Licensor for the purpose of discussing and improving the Work, but
      excluding communication that is conspicuously marked or otherwise
      designated in writing by the copyright owner as "Not a Contribution."

      "Contributor" shall mean Licensor and any individual or Legal Entity
      on behalf of whom a Contribution has been received by Licensor and
      subsequently incorporated within the Work.

   2. Grant of Copyright License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      copyright license to reproduce, prepare Derivative Works of,
      publicly display, publicly perform, sublicense, and distribute the
      Work and such Derivative Works in Source or Object form.

   3. Grant of Patent License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      (except as stated in this section) patent license to make, have made,
      use, offer to sell, sell, import, and otherwise transfer the Work,
      where such license applies only to those patent claims licensable
      by such Contributor that are necessarily infringed by their
      Contribution(s) alone or by combination of their Contribution(s)
      with the Work to which such Contribution(s) was submitted. If You
      institute patent litigation against any entity (including a
      cross-claim or counterclaim in a lawsuit) alleging that the Work
      or a Contribution incorporated within the Work constitutes direct
      or contributory patent infringement, then any patent licenses
      granted to You under this License for that Work shall terminate
      as of the date such litigation is filed.

   4. Redistribution. You may reproduce and distribute copies of the
      Work or Derivative Works thereof in any medium, with or without
      modifications, and in Source or Object form, provided that You
      meet the following conditions:

      (a) You must give any other recipients of the Work or
          Derivative Works a copy of this License; and

      (b) You must cause any modified files to carry prominent notices
          stating that You changed the files; and

      (c) You must retain, in the Source form of any Derivative Works
          that You distribute, all copyright, patent, trademark, and
          attribution notices from the Source form of the Work,
          excluding those notices that do not pertain to any part of
          the Derivative Works; and

      (d) If the Work includes a "NOTICE" text file as part of its
          distribution, then any Derivative Works that You distribute must
          include a readable copy of the attribution notices contained
          within such NOTICE file, excluding those notices that do not
          pertain to any part of the Derivative Works, in at least one
          of the following places: within a NOTICE text file distributed
          as part of the Derivative Works; within the Source form or
          documentation, if provided along with the Derivative Works; or,
          within a display generated by the Derivative Works, if and
          wherever such third-party notices normally appear. The contents
          of the NOTICE file are for informational purposes only and
          do not modify the License. You may add Your own attribution
          notices within Derivative Works that You distribute, alongside
          or as an addendum to the NOTICE text from the Work, provided
          that such additional attribution notices cannot be construed
          as modifying the License.

      You may add Your own copyright statement to Your modifications and
      may provide additional or different license terms and conditions
      for use, reproduction, or distribution of Your modifications, or
      for any such Derivative Works as a whole, provided Your use,
      reproduction, and distribution of the Work otherwise complies with
      the conditions stated in this License.

   5. Submission of Contributions. Unless You explicitly state otherwise,
      any Contribution intentionally submitted for inclusion in the Work
      by You to the Licensor shall be under the terms and conditions of
      this License, without any additional terms or conditions.
      Notwithstanding the above, nothing herein shall supersede or modify
      the terms of any separate license agreement you may have executed
      with Licensor regarding such Contributions.

   6. Trademarks. This License does not grant permission to use the trade
      names, trademarks, service marks, or product names of the Licensor,
      except as required for reasonable and customary use in describing the
      origin of the Work and reproducing the content of the NOTICE file.

   7. Disclaimer of Warranty. Unless required by applicable law or
      agreed to in writing, Licensor provides the Work (and each
      Contributor provides its Contributions) on an "AS IS" BASIS,
      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
      implied, including, without limitation, any warranties or conditions
      of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A
      PARTICULAR PURPOSE. You are solely responsible for determining the
      appropriateness of using or redistributing the Work and assume any
      risks associated with Your exercise of permissions under this License.

   8. Limitation of Liability. In no event and under no legal theory,
      whether in tort (including negligence), contract, or otherwise,
      unless required by applicable law (such as deliberate and grossly
      negligent acts) or agreed to in writing, shall any Contributor be
      liable to You for damages, including any direct, indirect, special,
      incidental, or consequential damages of any character arising as a
      result of this License or out of the use or inability to use the
      Work (including but not limited to damages for loss of goodwill,
      work stoppage, computer failure or malfunction, or any and all
      other commercial damages or losses), even if such Contributor
      has been advised of the possibility of such damages.

   9. Accepting Warranty or Additional Liability. While redistributing
      the Work or Derivative Works thereof, You may choose to offer,
      and charge a fee for, acceptance of support, warranty, indemnity,
      or other liability obligations and/or rights consistent with this
      License. However, in accepting such obligations, You may act only
      on Your own behalf and on Your sole responsibility, not on behalf
      of any other Contributor, and only if You agree to indemnify,
      defend, and hold each Contributor harmless for any liability
      incurred by, or claims asserted against, such Contributor by reason
      of your accepting any such warranty or additional liability.

   END OF TERMS AND CONDITIONS

   APPENDIX: How to apply the Apache License to your work.

      To apply the Apache License to your work, attach the following
      boilerplate notice, with the fields enclosed by brackets "[]"
      replaced with your own identifying information. (Don't include
      the brackets!)  The text should be enclosed in the appropriate
      comment syntax for the file format. We also recommend that a
      file or class name and description of purpose be included on the
      same "printed page" as the copyright notice for easier
      identification within third-party archives.

   Copyright [yyyy] [name of copyright owner]

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

*/
"use strict";
const __modules = Object.create(null);
__modules["paper_support/demo_calculator.mjs"] = (() => {
/** Pure scenario arithmetic. No provider calls, collection, or experiment execution. */
function calculateScenario(data, options = {}) {
  const {
    scenario = 'reference', route = 'modeled_tool_delivery', attemptsPerMonth = 1000,
    price = 5, humanMinutes = 15, humanHourlyWage = 24.32,
    customerHourlyValue = data.customer_hourly_proxy_usd,
    extraCustomerMinutes = data.scenarios[scenario]?.customer_incremental_minutes,
    equivalentScope = true,
  } = options;
  const row = data.quote_unit_rows.find(r => r.scenario === scenario && r.route === route && r.attempts_per_month === attemptsPerMonth);
  if (!row) throw new RangeError('Select one frozen route, scenario, and monthly volume.');
  for (const [name, value] of Object.entries({price, humanMinutes, humanHourlyWage, customerHourlyValue, extraCustomerMinutes})) {
    if (!Number.isFinite(value) || value < 0 || (name === 'humanHourlyWage' && value === 0)) {
      throw new RangeError(`${name} must be finite and nonnegative; the human hourly wage must exceed zero.`);
    }
  }
  const s = data.scenarios[scenario], c = s.collection_fraction, z = s.refund_fraction;
  const {fraction: v, fixed_usd_per_collected_invoice: f0} = data.fees;
  const netReceiptPerAccepted = c * ((1 - z - v) * price - f0);
  const fullContributionPerAccepted = netReceiptPerAccepted - row.fully_loaded_pretax_usd_per_accepted;
  const recurringContributionPerAccepted = netReceiptPerAccepted - row.recurring_delivery_usd_per_accepted;
  const priceFloor = (row.fully_loaded_pretax_usd_per_accepted + c * f0) / (c * (1 - z - v));
  const alternativeLaborValue = humanMinutes * humanHourlyWage / 60;
  const automatedCustomerOutlay = price + extraCustomerMinutes * customerHourlyValue / 60;
  return {
    status: 'FRESH_ARITHMETIC_ON_FROZEN_ASSUMPTIONS', scenario, route,
    configuration: 'original_upkeep', currency: 'USD',
    assumptions: {scenario, route, attemptsPerMonth, price, humanMinutes, humanHourlyWage,
      customerHourlyValue, extraCustomerMinutes, equivalentScope}, input_sha256: data.input_sha256, row,
    netReceiptPerAccepted, fullContributionPerAccepted, recurringContributionPerAccepted, priceFloor,
    expectedAcceptedPerMonth: attemptsPerMonth * row.assumed_expected_acceptance,
    expectedAcceptedPortfolioPerMonth: attemptsPerMonth * row.assumed_expected_acceptance,
    expectedAcceptedQuoteSharePerMonth: attemptsPerMonth * row.assumed_expected_acceptance * data.portfolio_family_weights.quotes,
    volumeBasis: data.volume_basis,
    collectionDelayMonths: s.collection_delay_months,
    customerComparison: equivalentScope ? {
      status: 'CONDITIONAL_ON_EQUAL_SCOPE_AND_QUALITY', alternativeLaborValue, automatedCustomerOutlay,
      conditionalCustomerDifference: alternativeLaborValue - automatedCustomerOutlay,
      priceBreakEvenHumanMinutes: 60 * automatedCustomerOutlay / humanHourlyWage,
    } : {status: 'UNAVAILABLE_SCOPE_NOT_EQUIVALENT'},
    actualLocalTotalCost: null, observedPayments: false, capabilityPromotion: false,
    warning: 'Economic contribution is not currently collected or reinvestable cash. Production inputs and customer time are assumptions.',
  };
}

return {calculateScenario};
})();
__modules["implementation/vendor/alpha/docs/assets/successor/engine.mjs"] = (() => {
// SPDX-License-Identifier: Apache-2.0
/** Fixed, bounded aggregation engines. No generated JavaScript is executed. */
const VERSION = 'successor-browser-v1';
const exact = (value, keys) => value && typeof value === 'object' && !Array.isArray(value) && Object.keys(value).sort().join('|') === [...keys].sort().join('|');
const integer = (value, low, high) => Number.isSafeInteger(value) && value >= low && value <= high;
function scalar(value) {
    if (typeof value !== 'string') return false;
    for (let i = 0; i < value.length; i++) {
        const c = value.charCodeAt(i);
        if (c >= 0xd800 && c <= 0xdbff) {
            const next = value.charCodeAt(++i);
            if (!(next >= 0xdc00 && next <= 0xdfff)) return false;
        } else if (c >= 0xdc00 && c <= 0xdfff) return false;
    }
    return true;
}
function canonical(value) {
    let nodes = 0;
    function encode(item, depth = 0) {
        if (++nodes > 100000 || depth > 32) throw Error('JSON complexity exceeds limit');
        if (item === null || typeof item === 'boolean') return JSON.stringify(item);
        if (typeof item === 'string' && scalar(item)) return JSON.stringify(item);
        if (typeof item === 'number' && Number.isSafeInteger(item) && !Object.is(item, -0)) return String(item);
        if (Array.isArray(item)) {
            for (let i = 0; i < item.length; i++) if (!Object.hasOwn(item, i)) throw Error('Sparse arrays are not JSON');
            return '[' + item.map(v => encode(v, depth + 1)).join(',') + ']';
        }
        if (item && typeof item === 'object' && [Object.prototype, null].includes(Object.getPrototypeOf(item))) {
            return '{' + Object.keys(item).sort().map(key => {
                if (!/^[\x20-\x7e]+$/.test(key)) throw Error('Object keys must be printable ASCII');
                return JSON.stringify(key) + ':' + encode(item[key], depth + 1);
            }).join(',') + '}';
        }
        throw Error('Unsupported JSON value; integers and Unicode scalars required');
    }
    const result = encode(value);
    if (new TextEncoder().encode(result).length > 2000000) throw Error('Canonical JSON exceeds 2 MB');
    return result;
}
async function digest(domain, value) {
    if (!/^[a-z][a-z0-9-]{0,63}$/.test(domain)) throw Error('Invalid digest domain');
    const bytes = new TextEncoder().encode('successor-omega/v1:' + domain + '\0' + canonical(value));
    return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', bytes)), n => n.toString(16).padStart(2, '0')).join('');
}
/** Parse untrusted imports before they can allocate large or deeply nested objects. */
function parseBounded(text) {
    if (typeof text !== 'string' || new TextEncoder().encode(text).length > 2_000_000) throw Error('Import exceeds 2 MB');
    let pos = 0, nodes = 0;
    const ws = () => { while (/[\x20\t\n\r]/.test(text[pos] || '\u0000')) pos++; };
    const string = () => {
        const start = pos++;
        while (pos < text.length) {
            if (text[pos] === '\\') { pos += 2; continue; }
            if (text[pos++] === '"') {
                const value = JSON.parse(text.slice(start, pos));
                if (!scalar(value)) throw Error('Malformed Unicode');
                return value;
            }
        }
        throw Error('Unterminated string');
    };
    function read(depth = 0) {
        if (++nodes > 100000 || depth > 32) throw Error('Import complexity exceeds limit');
        ws();
        if (text[pos] === '"') return string();
        if (text[pos] === '[' || text[pos] === '{') {
            const object = text[pos++] === '{', end = object ? '}' : ']';
            const value = object ? Object.create(null) : [];
            ws(); if (text[pos] === end) { pos++; return value; }
            while (true) {
                ws();
                if (object) {
                    if (text[pos] !== '"') throw Error('Expected object key');
                    const key = string(); ws();
                    if (Object.hasOwn(value, key)) throw Error('Duplicate JSON key');
                    if (text[pos++] !== ':') throw Error('Expected colon');
                    value[key] = read(depth + 1);
                } else value.push(read(depth + 1));
                ws(); const next = text[pos++];
                if (next === end) break;
                if (next !== ',') throw Error('Expected comma');
            }
            return value;
        }
        for (const [token, value] of [['true', true], ['false', false], ['null', null]]) {
            if (text.startsWith(token, pos)) { pos += token.length; return value; }
        }
        const match = /^-?(?:0|[1-9]\d*)(?![\d.eE+-])/.exec(text.slice(pos));
        if (!match) throw Error('Expected integer JSON value');
        pos += match[0].length; const value = Number(match[0]);
        if (!Number.isSafeInteger(value) || Object.is(value, -0)) throw Error('Unsafe integer');
        return value;
    }
    const value = read(); ws();
    if (pos !== text.length) throw Error('Trailing JSON content');
    canonical(value);
    return value;
}
function validateRequest(request) {
    const keys = ['schema_version', 'kind', 'request_id', 'mission', 'seed', 'max_candidates', 'formation_trials', 'max_events', 'language'];
    if (!request || typeof request !== 'object' || Array.isArray(request) || !Object.hasOwn(request, 'request_id') || Object.keys(request).some(key => !keys.includes(key))) throw Error('Invalid versioned rehearsal request');
    request = {schema_version: 1, kind: 'successor-rehearsal', mission: 'streaming-metrics-v1', seed: 42, max_candidates: 4, formation_trials: 2, max_events: 1000, language: 'en', ...request};
    if (!exact(request, keys) || request.schema_version !== 1 || request.kind !== 'successor-rehearsal' || request.mission !== 'streaming-metrics-v1' || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(request.request_id) || !integer(request.seed, 0, 4294967295) || !integer(request.max_candidates, 2, 12) || !integer(request.formation_trials, 1, 6) || !integer(request.max_events, 64, 20000) || !['en', 'fr'].includes(request.language)) throw Error('Invalid versioned rehearsal request');
    return structuredClone(request);
}
function newRequest(options = {}) {
    return validateRequest({schema_version: 1, kind: 'successor-rehearsal', request_id: crypto.randomUUID(), mission: 'streaming-metrics-v1', seed: 42, max_candidates: 4, formation_trials: 2, max_events: 1000, language: 'en', ...options});
}
function order(a, b) {
    const aa = Array.from(a, c => c.codePointAt(0)), bb = Array.from(b, c => c.codePointAt(0));
    for (let i = 0; i < Math.min(aa.length, bb.length); i++) if (aa[i] !== bb[i]) return aa[i] - bb[i];
    return aa.length - bb.length;
}
const rowOrder = (a, b) => order(a.day, b.day) || order(a.service, b.service);
function validateEvents(events) {
    if (!Array.isArray(events) || events.length > 20000) throw Error('Event count exceeds mission bound');
    for (const e of events) {
        if (!exact(e, ['day', 'service', 'duration_us', 'ok']) || !scalar(e.day) || !scalar(e.service) || !integer(Array.from(e.day).length, 1, 64) || !integer(Array.from(e.service).length, 1, 64) || !integer(e.duration_us, 0, 1000000000) || typeof e.ok !== 'boolean') throw Error('Malformed aggregation event');
    }
}
const makeRow = e => ({day: e.day, service: e.service, count: 0, total_duration_us: 0, max_duration_us: 0, error_count: 0});
function update(row, e, kind = 'builtin') {
    row.count++; row.total_duration_us += e.duration_us; row.error_count += Number(!e.ok);
    if (kind === 'builtin') row.max_duration_us = Math.max(row.max_duration_us, e.duration_us);
    else if (e.duration_us > row.max_duration_us) row.max_duration_us = e.duration_us;
}
function current(events) {
    validateEvents(events); const groups = new Map();
    for (const e of events) {
        const key = JSON.stringify([e.day, e.service]);
        if (!groups.has(key)) groups.set(key, makeRow(e));
        update(groups.get(key), e);
    }
    return [...groups.values()].sort(rowOrder);
}
function beta(events) {
    validateEvents(events); const sorted = [...events].sort(rowOrder), rows = [];
    for (const e of sorted) {
        let row = rows[rows.length - 1];
        if (!row || row.day !== e.day || row.service !== e.service) { row = makeRow(e); rows.push(row); }
        row.count += 1; row.total_duration_us += e.duration_us;
        row.error_count += e.ok ? 0 : 1;
        row.max_duration_us = row.max_duration_us >= e.duration_us ? row.max_duration_us : e.duration_us;
    }
    return rows;
}
function validateCandidate(c) {
    if (!exact(c, ['version', 'layout', 'cache_last', 'update']) || c.version !== 1 || !['nested', 'tuple'].includes(c.layout) || typeof c.cache_last !== 'boolean' || !['branch', 'builtin'].includes(c.update)) throw Error('Candidate is outside the fixed grammar');
    return c;
}
function candidate(events, config) {
    validateEvents(events); validateCandidate(config);
    const groups = new Map(), rows = []; let last = null;
    for (const e of events) {
        let row;
        if (config.cache_last && last && e.day === last.day && e.service === last.service) row = last;
        else if (config.layout === 'nested') {
            if (!groups.has(e.day)) groups.set(e.day, new Map());
            const services = groups.get(e.day);
            row = services.get(e.service);
            if (!row) { row = makeRow(e); services.set(e.service, row); rows.push(row); }
        } else {
            const key = JSON.stringify([e.day, e.service]); row = groups.get(key);
            if (!row) { row = makeRow(e); groups.set(key, row); rows.push(row); }
        }
        update(row, e, config.update); last = row;
    }
    return rows.sort(rowOrder);
}
function generateCandidates(seed, count) {
    if (!integer(count, 2, 12)) throw Error('Candidate count outside bound');
    const out = [];
    // Eight complete compositions; repeated configuration is never represented as a new challenger.
    for (let i = 0; i < Math.min(count, 8); i++) {
        const bits = (i + (seed % 8)) % 8;
        out.push({version: 1, layout: bits & 1 ? 'nested' : 'tuple', cache_last: Boolean(bits & 2), update: bits & 4 ? 'branch' : 'builtin'});
    }
    return out;
}
function workload(seed, count, mode = 'mixed') {
    let state = seed >>> 0;
    const next = () => (state = (Math.imul(state, 1664525) + 1013904223) >>> 0);
    const names = ['api', 'résumé', '東京', '🙂', '__proto__', '\ue000', '𝄞'];
    return Array.from({length: count}, (_, i) => ({day: 'day-' + (next() % (mode === 'high' ? 97 : 3)), service: mode === 'high' ? names[next() % names.length] + i : names[next() % names.length], duration_us: next() % 1000000001, ok: next() % 5 !== 0}));
}
const pause = () => new Promise(resolve => setTimeout(resolve, 0));
function measured(fn, events) {
    const start = performance.now(); const result = fn(events);
    return {elapsed_ns: Math.max(1, Math.round((performance.now() - start) * 1000000)), rows: result.length, result};
}
function correct(fn) {
    const valid = [[], [{day: '🙂', service: '__proto__', duration_us: 1000000000, ok: false}], workload(12, 64, 'high'), workload(98, 120)];
    if (!valid.every(events => canonical(fn(events)) === canonical(beta(events)))) return false;
    const bad = [[{day: '', service: 'x', duration_us: 1, ok: true}], [{day: 'd', service: 'x', duration_us: true, ok: true}], [{day: 'd', service: 'x', duration_us: 1, ok: 'true'}], [{day: 'd', service: '\ud800', duration_us: 1, ok: true}], [{day: 'd', service: 'x', duration_us: -1, ok: true}]];
    return bad.every(events => { try { fn(events); return false; } catch { return true; } });
}
function abort(signal) { if (signal?.aborted) throw new DOMException('Cancelled', 'AbortError'); }
async function discover(request, {signal, onProgress = () => {}, preferred = null} = {}) {
    request = validateRequest(request); const configurations = generateCandidates(request.seed, request.max_candidates);
    configurations.sort((a, b) => Number(b.layout === 'nested') - Number(a.layout === 'nested'));
    if (preferred) { validateCandidate(preferred); configurations.sort((a, b) => Number(canonical(b) === canonical(preferred)) - Number(canonical(a) === canonical(preferred))); }
    const events = workload(request.seed, request.max_events), attempts = [];
    const world = {version: 1, prediction: 'nested map reduces tuple-key serialization', uncertainty: 'allocation and sorting may dominate', experiment: 'prioritize nested-map compositions, then test tuple-map alternatives within the same budget', selection_rule: 'minimum measured development elapsed_ns among correct candidates; not final proof'};
    for (const config of configurations) {
        abort(signal); await pause(); abort(signal);
        const fn = values => candidate(values, config), pass = correct(fn), measurement = measured(fn, events);
        const attempt = {config, construction: {operator: 'bounded-grammar-composition', seed: request.seed, parent: VERSION}, artifact_hash: await digest('candidate', config), correctness: pass, elapsed_ns: measurement.elapsed_ns, rows: measurement.rows};
        attempts.push(attempt); onProgress(attempts.length, configurations.length);
    }
    const nested = attempts.filter(a => a.config.layout === 'nested'), tuples = attempts.filter(a => a.config.layout === 'tuple');
    world.observation = {nested_mean_ns: Math.round(nested.reduce((sum, a) => sum + a.elapsed_ns, 0) / (nested.length || 1)), tuple_mean_ns: Math.round(tuples.reduce((sum, a) => sum + a.elapsed_ns, 0) / (tuples.length || 1)), interpretation: 'development observation only; confounded by composition and browser timing'};
    world.falsified_in_this_run = world.observation.nested_mean_ns >= world.observation.tuple_mean_ns;
    const feasible = attempts.filter(a => a.correctness).sort((a, b) => a.elapsed_ns - b.elapsed_ns);
    if (!feasible.length) throw Error('No correct candidate; retain Current');
    return {world, attempts, selected: feasible[0], generation_budget: request.max_candidates, actual_candidates: configurations.length, source: VERSION};
}
async function freeze(request, discovery, sourceHash) {
    if (!/^[0-9a-f]{64}$/.test(sourceHash)) throw Error('Exact engine source digest required');
    const manifest = {schema_version: 1, request_hash: await digest('request', validateRequest(request)), grammar: discovery.selected.config, candidate_hash: discovery.selected.artifact_hash, engine: VERSION, engine_source_hash: sourceHash, comparators: ['current-one-pass-map-v1', 'beta-sorted-reduction-v1'], protocol: 'browser-local-aggregation-v1', correctness_required: true, minimum_speedup_ppm: 50000, costs: {money: null, review: null, memory: null}, authority: []};
    return {manifest, release_hash: await digest('release', manifest)};
}
async function evaluate(request, frozen, {signal} = {}) {
    request = validateRequest(request);
    if (frozen.manifest.request_hash !== await digest('request', request) || frozen.release_hash !== await digest('release', frozen.manifest)) throw Error('Frozen release or request changed');
    if (frozen.manifest.candidate_hash !== await digest('candidate', frozen.manifest.grammar) || frozen.manifest.protocol !== 'browser-local-aggregation-v1' || frozen.manifest.minimum_speedup_ppm !== 50000 || frozen.manifest.correctness_required !== true || canonical(frozen.manifest.comparators) !== canonical(['current-one-pass-map-v1', 'beta-sorted-reduction-v1'])) throw Error('Candidate or protocol binding mismatch');
    const config = validateCandidate(frozen.manifest.grammar), fn = e => candidate(e, config), cases = [];
    const correctness = correct(fn);
    for (let i = 0; i < 6; i++) {
        abort(signal); await pause(); abort(signal);
        const events = workload((request.seed + 100003 + i * 907) >>> 0, i < 2 ? 64 : request.max_events, i % 2 ? 'high' : 'mixed');
        const samples = [measured(current, events), measured(beta, events), measured(fn, events)];
        const exact_output = canonical(samples[0].result) === canonical(samples[1].result) && canonical(samples[1].result) === canonical(samples[2].result);
        cases.push({case_index: i, events: events.length, current_ns: samples[0].elapsed_ns, beta_ns: samples[1].elapsed_ns, candidate_ns: samples[2].elapsed_ns, exact_output});
    }
    const totals = {current: 0, beta: 0, candidate: 0};
    for (const c of cases) { totals.current += c.current_ns; totals.beta += c.beta_ns; totals.candidate += c.candidate_ns; }
    const best_comparator = totals.current <= totals.beta ? 'current' : 'beta';
    const hard_gate = correctness && cases.every(c => c.exact_output);
    return {schema_version: 1, scope: 'browser-rehearsal', release_hash: frozen.release_hash, cases, correctness: hard_gate, totals_ns: totals, best_comparator, local_verdict: !hard_gate ? 'FAIL' : totals.candidate >= totals[best_comparator] ? (best_comparator === 'beta' ? 'RETAIN_ALTERNATIVE' : 'RETAIN_INCUMBENT') : totals.candidate / totals[best_comparator] > 0.95 ? 'INSUFFICIENT_MARGIN' : 'LOCAL_SPEEDUP_OBSERVED', institutional_verdict: 'HOLD', missing: ['independent-verifier', 'frontier-comparator', 'measured-peak-memory', 'accepted-realized-economics', 'principal-issued-authority'], authority: [], timing_limitations: 'Single browser process; timer resolution, order, JIT and device load confound timings. Descriptive measurements only.'};
}
async function renew(request, discovery, {signal, onProgress = () => {}, engineSourceHash = null} = {}) {
    request = validateRequest(request);
    const trials = [];
    for (let i = 0; i < request.formation_trials; i++) {
        abort(signal);
        const next = {...request, seed: (request.seed + 200003 + i * 997) >>> 0};
        const control = await discover(next, {signal}), treatment = await discover(next, {signal, preferred: discovery.selected.config});
        const controlFreeze = await freeze(next, control, engineSourceHash), treatmentFreeze = await freeze(next, treatment, engineSourceHash);
        const controlEvaluation = await evaluate(next, controlFreeze, {signal}), treatmentEvaluation = await evaluate(next, treatmentFreeze, {signal});
        trials.push({trial: i, seed: next.seed, control_attempts: control.attempts.length, treatment_attempts: treatment.attempts.length, control, treatment, control_release: controlFreeze, treatment_release: treatmentFreeze, control_evaluation: controlEvaluation, treatment_evaluation: treatmentEvaluation});
        onProgress(i + 1, request.formation_trials);
    }
    return {generation: 2, active_proof: [], authority: [], memory: {permitted: ['configuration-order-hint'], excluded: ['final-cases', 'proof', 'grants']}, primary_metric: 'construction_attempts', interpretation: 'Descriptive matched trials; equal construction counts do not establish compounding.', trials};
}
// Canonical encoding and low-order rejection supplement WebCrypto verification.
// Mathematical torsion encodings: @noble/curves 1.2.0 src/ed25519.ts ED25519_TORSION_SUBGROUP.
const lowOrderY = new Set([
    '0000000000000000000000000000000000000000000000000000000000000000',
    '0100000000000000000000000000000000000000000000000000000000000000',
    'ecffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff7f',
    '26e8958fc2b227b045c3f489f2ef98f0d5dfac05d3c63339b13802886d53fc05',
    'c7176a703d4dd84fba3c0b760d10670f2a2053fa2c39ccc64ec7fd7792ac037a',
]);
const littleEndian = bytes => BigInt('0x' + [...bytes].reverse().map(v => v.toString(16).padStart(2, '0')).join(''));
function validatePointEncoding(bytes) {
    const y = bytes.slice(); y[31] &= 0x7f;
    const hex = [...y].map(v => v.toString(16).padStart(2, '0')).join('');
    if (littleEndian(y) >= (1n << 255n) - 19n || lowOrderY.has(hex)) throw Error('Non-canonical or low-order Ed25519 point');
}
function validateSignatureEncoding(key, signature) {
    validatePointEncoding(key); validatePointEncoding(signature.slice(0, 32));
    if (littleEndian(signature.slice(32)) >= (1n << 252n) + 27742317777372353535851937790883648493n) throw Error('Non-canonical Ed25519 scalar');
}
async function verifyNative(request, envelope) {
    request = validateRequest(request);
    if (!exact(envelope, ['schema_version', 'kind', 'request_hash', 'evidence', 'evidence_hash', 'scope', 'signature']) || envelope.schema_version !== 1 || envelope.kind !== 'successor-result' || envelope.scope !== 'local-native-rehearsal') throw Error('Unsupported native evidence envelope');
    if (envelope.request_hash !== await digest('request', request)) throw Error('Native result belongs to a different request');
    if (!envelope.evidence || envelope.evidence.scope !== envelope.scope || envelope.evidence.request_hash !== envelope.request_hash || !exact(envelope.evidence.request, Object.keys(request)) || canonical(envelope.evidence.request) !== canonical(request)) throw Error('Authenticated evidence request or scope mismatch');
    if (envelope.evidence_hash !== await digest('evidence', envelope.evidence)) throw Error('Native evidence digest mismatch');
    if (envelope.signature !== null) {
        const signature = envelope.signature;
        if (!exact(signature, ['public_key', 'signature']) || !/^[0-9a-f]{64}$/.test(signature.public_key) || !/^[A-Za-z0-9+/]{86}==$/.test(signature.signature)) throw Error('Malformed native signature');
        const publicBytes = Uint8Array.from(signature.public_key.match(/../g), x => parseInt(x, 16));
        const bytes = Uint8Array.from(atob(signature.signature), c => c.charCodeAt(0));
        validateSignatureEncoding(publicBytes, bytes);
        const key = await crypto.subtle.importKey('raw', publicBytes, {name: 'Ed25519'}, false, ['verify']);
        const data = Uint8Array.from(envelope.evidence_hash.match(/../g), x => parseInt(x, 16));
        if (!await crypto.subtle.verify('Ed25519', key, bytes, data)) throw Error('Invalid native signature');
    }
    return {scope: envelope.scope, integrity: 'request-and-evidence-digests-match', authenticity: 'unverified', authority: [], evidence: envelope.evidence};
}

return {VERSION,canonical,digest,parseBounded,validateRequest,newRequest,validateEvents,current,beta,validateCandidate,candidate,generateCandidates,workload,discover,freeze,evaluate,renew,verifyNative};
})();
__modules["implementation/vendor/alpha/examples/build-successor/vendor/agijobs/integrity.mjs"] = (() => {
const FORBIDDEN_KEYS = new Set(['__proto__', 'prototype', 'constructor']);

/** Deterministic JSON encoding. Ambiguous or non-JSON values are refused. */
function canonicalize(value) {
  const active = new Set();
  let count = 0;
  const encode = (item, depth) => {
    if (++count > 100000 || depth > 64)
      throw new TypeError('JSON_LIMIT_EXCEEDED');
    if (item === null) return 'null';
    if (typeof item === 'string') {
      if (
        item !== item.normalize('NFC') ||
        /[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?<![\uD800-\uDBFF])[\uDC00-\uDFFF]/u.test(
          item
        )
      )
        throw new TypeError('NON_CANONICAL_UNICODE');
      return JSON.stringify(item);
    }
    if (typeof item === 'boolean') return item ? 'true' : 'false';
    if (typeof item === 'number') {
      if (
        !Number.isFinite(item) ||
        Object.is(item, -0) ||
        (Number.isInteger(item) && !Number.isSafeInteger(item))
      )
        throw new TypeError('UNSAFE_NUMBER');
      return JSON.stringify(item);
    }
    if (typeof item !== 'object' || active.has(item))
      throw new TypeError('NON_JSON_VALUE');
    const proto = Object.getPrototypeOf(item);
    if (
      (Array.isArray(item) && proto !== Array.prototype) ||
      (!Array.isArray(item) && proto !== Object.prototype && proto !== null)
    )
      throw new TypeError('NON_JSON_OBJECT');
    active.add(item);
    let encoded;
    if (Object.getOwnPropertySymbols(item).length)
      throw new TypeError('NON_JSON_SYMBOL');
    if (Array.isArray(item)) {
      const names = Object.getOwnPropertyNames(item);
      if (
        names.length !== item.length + 1 ||
        Object.keys(item).length !== item.length
      )
        throw new TypeError('SPARSE_OR_EXTENDED_ARRAY');
      for (let index = 0; index < item.length; index += 1) {
        const descriptor = Object.getOwnPropertyDescriptor(item, String(index));
        if (
          !descriptor ||
          descriptor.get ||
          descriptor.set ||
          !descriptor.enumerable
        )
          throw new TypeError('ACCESSOR_OR_SPARSE_ARRAY');
      }
      encoded = `[${Array.prototype.map
        .call(item, (part) => encode(part, depth + 1))
        .join(',')}]`;
    } else {
      const keys = Object.keys(item).sort();
      for (const key of keys) {
        if (FORBIDDEN_KEYS.has(key) || key !== key.normalize('NFC'))
          throw new TypeError('UNSAFE_OBJECT_KEY');
        if (
          Object.getOwnPropertyDescriptor(item, key)?.get ||
          Object.getOwnPropertyDescriptor(item, key)?.set
        )
          throw new TypeError('ACCESSOR_NOT_ALLOWED');
      }
      encoded = `{${keys
        .map(
          (key) => `${encode(key, depth + 1)}:${encode(item[key], depth + 1)}`
        )
        .join(',')}}`;
    }
    active.delete(item);
    return encoded;
  };
  return encode(value, 0);
}

async function digestBytes(value) {
  const bytes =
    typeof value === 'string' ? new TextEncoder().encode(value) : value;
  if (!(bytes instanceof Uint8Array)) throw new TypeError('BYTES_REQUIRED');
  if (!globalThis.crypto?.subtle) throw new Error('WEBCRYPTO_UNAVAILABLE');
  const digest = new Uint8Array(
    await globalThis.crypto.subtle.digest('SHA-256', bytes)
  );
  return `sha256:${Array.from(digest, (byte) =>
    byte.toString(16).padStart(2, '0')
  ).join('')}`;
}

async function digestObject(domain, object) {
  if (
    typeof domain !== 'string' ||
    !/^[a-zA-Z0-9][a-zA-Z0-9._:/-]{0,127}$/.test(domain)
  )
    throw new TypeError('INVALID_HASH_DOMAIN');
  return digestBytes(
    canonicalize({ hashFormat: 'successor-canonical-json-v1', domain, object })
  );
}

function cloneJson(value) {
  return JSON.parse(canonicalize(value));
}

return {canonicalize,digestBytes,digestObject,cloneJson};
})();
__modules["implementation/vendor/alpha/examples/build-successor/vendor/agijobs/domain.mjs"] = (() => {
const {canonicalize, cloneJson} = __modules["implementation/vendor/alpha/examples/build-successor/vendor/agijobs/integrity.mjs"];

const SCHEMA_VERSION = '1.0.0';
const JOB_FAMILIES = Object.freeze([
  'constitution',
  'evidence',
  'formation',
  'challenge',
  'verification',
  'admission',
  'renewal',
]);
const EDGE_KINDS = Object.freeze([
  'evidence',
  'control',
  'challenge',
  'rollback',
  'invalidation',
]);
const JOB_STATES = Object.freeze([
  'DRAFT',
  'UNDERWRITTEN',
  'AUTHORIZED',
  'EXECUTING',
  'VERIFIED',
  'ACCEPTED',
  'CHRONICLE_ELIGIBLE',
  'REFUSED',
  'FAILED',
  'TIMED_OUT',
  'REPAIR_REQUIRED',
  'ROLLED_BACK',
]);
class SuccessorError extends Error {
  constructor(code, message, { details = {}, retryable = false } = {}) {
    super(message);
    this.name = 'SuccessorError';
    this.code = code;
    this.details = details;
    this.retryable = retryable;
  }
  toJSON() {
    return {
      code: this.code,
      message: this.message,
      details: this.details,
      retryable: this.retryable,
    };
  }
}
function requireCondition(condition, code, message, details = {}) {
  if (!condition) throw new SuccessorError(code, message, { details });
}
const fail = (path, message) => {
  throw new SuccessorError('SCHEMA_INVALID', `${path}: ${message}`, {
    details: { path },
  });
};
function object(value, keys, required, path) {
  if (!value || typeof value !== 'object' || Array.isArray(value))
    fail(path, 'expected object');
  for (const key of Object.keys(value))
    if (!keys.includes(key)) fail(`${path}.${key}`, 'unknown field');
  for (const key of required)
    if (!Object.hasOwn(value, key)) fail(`${path}.${key}`, 'required field');
}
const text = (value, path) => {
  if (typeof value !== 'string' || !value.trim() || value.length > 16000)
    fail(path, 'expected nonempty bounded string');
};
const id = (value, path) => {
  text(value, path);
  if (!/^[A-Za-z0-9][A-Za-z0-9._:/-]{0,159}$/.test(value))
    fail(path, 'invalid identifier');
};
const list = (value, path, check = text, minimum = 0, maximum = 256) => {
  if (!Array.isArray(value) || value.length < minimum || value.length > maximum)
    fail(path, 'invalid list size');
  value.forEach((entry, i) => check(entry, `${path}[${i}]`));
};
const integer = (value, path, min = 0, max = 1000000000) => {
  if (!Number.isSafeInteger(value) || value < min || value > max)
    fail(path, 'expected bounded integer');
};
const date = (value, path) => {
  if (
    typeof value !== 'string' ||
    !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d{3})?Z$/.test(value) ||
    !Number.isFinite(Date.parse(value))
  )
    fail(path, 'expected UTC ISO timestamp');
  const normalized = new Date(value).toISOString();
  if (value !== normalized && value !== normalized.replace('.000Z', 'Z'))
    fail(path, 'invalid calendar timestamp');
};
const choice = (value, values, path) => {
  if (!values.includes(value))
    fail(path, `expected one of ${values.join(', ')}`);
};
const unique = (values, path) => {
  if (new Set(values).size !== values.length) fail(path, 'duplicate values');
};
const bool = (value, path) => {
  if (typeof value !== 'boolean') fail(path, 'expected boolean');
};
function json(value) {
  try {
    canonicalize(value);
  } catch (error) {
    throw new SuccessorError('SCHEMA_INVALID', error.message);
  }
}
function validateBudget(value, path = 'budget', mission = false) {
  const fields = [
    'unit',
    'limitBaseUnits',
    'maxDurationMs',
    'maxRetries',
    ...(mission ? ['maxJobs'] : []),
  ];
  object(value, fields, fields, path);
  id(value.unit, `${path}.unit`);
  if (
    typeof value.limitBaseUnits !== 'string' ||
    !/^(0|[1-9][0-9]{0,29})$/.test(value.limitBaseUnits)
  )
    fail(
      `${path}.limitBaseUnits`,
      'expected canonical unsigned integer string'
    );
  integer(value.maxDurationMs, `${path}.maxDurationMs`, 1, 86400000);
  integer(value.maxRetries, `${path}.maxRetries`, 0, 100);
  if (mission) integer(value.maxJobs, `${path}.maxJobs`, 1, 256);
}
function rollback(value, path) {
  object(
    value,
    ['target', 'available', 'reason'],
    ['target', 'available', 'reason'],
    path
  );
  id(value.target, `${path}.target`);
  bool(value.available, `${path}.available`);
  text(value.reason, `${path}.reason`);
}
function reference(value, path) {
  object(
    value,
    ['id', 'version', 'description'],
    ['id', 'version', 'description'],
    path
  );
  id(value.id, `${path}.id`);
  id(value.version, `${path}.version`);
  text(value.description, `${path}.description`);
}
function validateMission(input) {
  json(input);
  const fields = [
    'schemaVersion',
    'kind',
    'missionId',
    'institutionId',
    'version',
    'title',
    'principal',
    'beneficiary',
    'objective',
    'incumbent',
    'alternatives',
    'rights',
    'hardGates',
    'criticalFunctions',
    'roles',
    'budget',
    'expiresAt',
    'authorityCeiling',
    'allowedTools',
    'allowedActions',
    'rollback',
    'proofProtocol',
  ];
  object(input, fields, fields, 'mission');
  requireCondition(
    input.schemaVersion === SCHEMA_VERSION,
    'SCHEMA_VERSION_UNSUPPORTED',
    'Unsupported mission schema version'
  );
  choice(input.kind, ['MissionConstitution'], 'mission.kind');
  for (const key of ['missionId', 'institutionId', 'version', 'principal'])
    id(input[key], `mission.${key}`);
  for (const key of ['title', 'beneficiary', 'objective'])
    text(input[key], `mission.${key}`);
  reference(input.incumbent, 'mission.incumbent');
  list(input.alternatives, 'mission.alternatives', reference, 1, 32);
  unique(
    input.alternatives.map((alternative) => alternative.id),
    'mission.alternatives'
  );
  list(
    input.rights,
    'mission.rights',
    (right, path) => {
      object(
        right,
        ['sourceId', 'license', 'dataClass', 'permittedUses', 'expiresAt'],
        ['sourceId', 'license', 'dataClass', 'permittedUses', 'expiresAt'],
        path
      );
      id(right.sourceId, `${path}.sourceId`);
      text(right.license, `${path}.license`);
      choice(
        right.dataClass,
        ['synthetic', 'public-licensed-nonpersonal'],
        `${path}.dataClass`
      );
      list(right.permittedUses, `${path}.permittedUses`, id, 1, 20);
      date(right.expiresAt, `${path}.expiresAt`);
    },
    1,
    256
  );
  unique(
    input.rights.map((right) => right.sourceId),
    'mission.rights'
  );
  list(
    input.hardGates,
    'mission.hardGates',
    (gate, path) => {
      object(
        gate,
        ['id', 'description', 'maxViolations'],
        ['id', 'description', 'maxViolations'],
        path
      );
      id(gate.id, `${path}.id`);
      text(gate.description, `${path}.description`);
      integer(gate.maxViolations, `${path}.maxViolations`, 0, 100);
    },
    1,
    64
  );
  unique(
    input.hardGates.map((gate) => gate.id),
    'mission.hardGates'
  );
  list(input.criticalFunctions, 'mission.criticalFunctions', id, 1, 64);
  unique(input.criticalFunctions, 'mission.criticalFunctions');
  object(
    input.roles,
    ['producer', 'verifier', 'acceptor', 'admitter'],
    ['producer', 'verifier', 'acceptor', 'admitter'],
    'mission.roles'
  );
  for (const [key, value] of Object.entries(input.roles))
    id(value, `mission.roles.${key}`);
  validateBudget(input.budget, 'mission.budget', true);
  date(input.expiresAt, 'mission.expiresAt');
  object(
    input.authorityCeiling,
    ['level', 'permittedActions', 'prohibitedActions', 'externalEffects'],
    ['level', 'permittedActions', 'prohibitedActions', 'externalEffects'],
    'mission.authorityCeiling'
  );
  choice(
    input.authorityCeiling.level,
    ['A0', 'A1', 'A2', 'A3', 'A4'],
    'mission.authorityCeiling.level'
  );
  list(
    input.authorityCeiling.permittedActions,
    'mission.authorityCeiling.permittedActions',
    id,
    1
  );
  list(
    input.authorityCeiling.prohibitedActions,
    'mission.authorityCeiling.prohibitedActions',
    id,
    1
  );
  bool(
    input.authorityCeiling.externalEffects,
    'mission.authorityCeiling.externalEffects'
  );
  list(input.allowedTools, 'mission.allowedTools', id, 1);
  list(input.allowedActions, 'mission.allowedActions', id, 1);
  rollback(input.rollback, 'mission.rollback');
  object(
    input.proofProtocol,
    [
      'id',
      'version',
      'mode',
      'formationOwner',
      'custodian',
      'requiredIndependence',
      'minimumMargin',
      'criticalErrorCeiling',
      'scope',
    ],
    [
      'id',
      'version',
      'mode',
      'formationOwner',
      'custodian',
      'requiredIndependence',
      'minimumMargin',
      'criticalErrorCeiling',
      'scope',
    ],
    'mission.proofProtocol'
  );
  for (const key of ['id', 'version', 'formationOwner', 'custodian'])
    id(input.proofProtocol[key], `mission.proofProtocol.${key}`);
  choice(
    input.proofProtocol.mode,
    ['SYNTHETIC_REHEARSAL', 'INDEPENDENT_REQUEST'],
    'mission.proofProtocol.mode'
  );
  choice(
    input.proofProtocol.requiredIndependence,
    ['I0', 'I1', 'I2', 'I3', 'I4'],
    'mission.proofProtocol.requiredIndependence'
  );
  if (
    !Number.isFinite(input.proofProtocol.minimumMargin) ||
    input.proofProtocol.minimumMargin < 0
  )
    fail('mission.proofProtocol.minimumMargin', 'expected nonnegative number');
  integer(
    input.proofProtocol.criticalErrorCeiling,
    'mission.proofProtocol.criticalErrorCeiling',
    0,
    100
  );
  text(input.proofProtocol.scope, 'mission.proofProtocol.scope');
  return cloneJson(input);
}

function validateWorkOrder(input) {
  json(input);
  const required = [
    'schemaVersion',
    'kind',
    'jobId',
    'missionId',
    'version',
    'family',
    'objective',
    'principal',
    'actor',
    'authorizedInputs',
    'evidenceObligation',
    'permittedTools',
    'permittedActions',
    'prohibitedActions',
    'budget',
    'expiresAt',
    'outputSchema',
    'verifier',
    'acceptance',
    'rollback',
    'chronicle',
    'covers',
    'state',
  ];
  object(
    input,
    [...required, 'digest', 'sealed', 'signatureStatus'],
    required,
    'job'
  );
  requireCondition(
    input.schemaVersion === SCHEMA_VERSION,
    'SCHEMA_VERSION_UNSUPPORTED',
    'Unsupported work-order schema version'
  );
  choice(input.kind, ['SealedWorkOrder'], 'job.kind');
  for (const key of ['jobId', 'missionId', 'version', 'principal', 'actor'])
    id(input[key], `job.${key}`);
  choice(input.family, JOB_FAMILIES, 'job.family');
  choice(input.state, JOB_STATES, 'job.state');
  text(input.objective, 'job.objective');
  for (const key of [
    'authorizedInputs',
    'evidenceObligation',
    'permittedTools',
    'permittedActions',
    'prohibitedActions',
    'covers',
  ]) {
    list(input[key], `job.${key}`, id, key === 'covers' ? 0 : 1);
    unique(input[key], `job.${key}`);
  }
  validateBudget(input.budget, 'job.budget');
  date(input.expiresAt, 'job.expiresAt');
  object(
    input.outputSchema,
    ['type', 'required'],
    ['type', 'required'],
    'job.outputSchema'
  );
  choice(input.outputSchema.type, ['object'], 'job.outputSchema.type');
  list(input.outputSchema.required, 'job.outputSchema.required', id, 1);
  object(
    input.verifier,
    ['identity', 'method', 'independence'],
    ['identity', 'method', 'independence'],
    'job.verifier'
  );
  id(input.verifier.identity, 'job.verifier.identity');
  text(input.verifier.method, 'job.verifier.method');
  choice(
    input.verifier.independence,
    ['I0', 'I1', 'I2', 'I3', 'I4'],
    'job.verifier.independence'
  );
  object(
    input.acceptance,
    ['owner', 'predicate', 'evidenceSources'],
    ['owner', 'predicate', 'evidenceSources'],
    'job.acceptance'
  );
  id(input.acceptance.owner, 'job.acceptance.owner');
  text(input.acceptance.predicate, 'job.acceptance.predicate');
  list(
    input.acceptance.evidenceSources,
    'job.acceptance.evidenceSources',
    id,
    1
  );
  rollback(input.rollback, 'job.rollback');
  object(
    input.chronicle,
    ['eligible', 'rights', 'scope', 'expiresAt'],
    ['eligible', 'rights', 'scope', 'expiresAt'],
    'job.chronicle'
  );
  bool(input.chronicle.eligible, 'job.chronicle.eligible');
  text(input.chronicle.rights, 'job.chronicle.rights');
  text(input.chronicle.scope, 'job.chronicle.scope');
  date(input.chronicle.expiresAt, 'job.chronicle.expiresAt');
  if ('sealed' in input) bool(input.sealed, 'job.sealed');
  if ('digest' in input && !/^sha256:[a-f0-9]{64}$/.test(input.digest))
    fail('job.digest', 'expected SHA-256 digest');
  if ('signatureStatus' in input)
    choice(
      input.signatureStatus,
      ['UNSIGNED_COMMITMENT', 'FIXTURE_SIGNED', 'AUTHORIZED_SIGNATURE'],
      'job.signatureStatus'
    );
  return cloneJson(input);
}

function validateGraph(input) {
  json(input);
  object(
    input,
    [
      'schemaVersion',
      'kind',
      'graphId',
      'missionId',
      'version',
      'nodes',
      'edges',
      'authorityCreated',
      'digest',
    ],
    [
      'schemaVersion',
      'kind',
      'graphId',
      'missionId',
      'version',
      'nodes',
      'edges',
      'authorityCreated',
    ],
    'graph'
  );
  requireCondition(
    input.schemaVersion === SCHEMA_VERSION,
    'SCHEMA_VERSION_UNSUPPORTED',
    'Unsupported graph schema version'
  );
  choice(input.kind, ['JobGraph'], 'graph.kind');
  for (const key of ['graphId', 'missionId', 'version'])
    id(input[key], `graph.${key}`);
  list(input.nodes, 'graph.nodes', validateWorkOrder, 1, 256);
  unique(
    input.nodes.map((node) => node.jobId),
    'graph.nodes'
  );
  list(
    input.edges,
    'graph.edges',
    (edge, path) => {
      object(edge, ['from', 'to', 'kind'], ['from', 'to', 'kind'], path);
      id(edge.from, `${path}.from`);
      id(edge.to, `${path}.to`);
      choice(edge.kind, EDGE_KINDS, `${path}.kind`);
    },
    0,
    2048
  );
  choice(input.authorityCreated, ['NONE'], 'graph.authorityCreated');
  return cloneJson(input);
}

const FORWARD = {
  DRAFT: 'UNDERWRITTEN',
  UNDERWRITTEN: 'AUTHORIZED',
  AUTHORIZED: 'EXECUTING',
  EXECUTING: 'VERIFIED',
  VERIFIED: 'ACCEPTED',
  ACCEPTED: 'CHRONICLE_ELIGIBLE',
};
// Pure reducer: context must originate in a trusted runtime, never request JSON.
function transitionJob(current, event, context = {}) {
  const job = validateWorkOrder(current);
  json(event);
  object(
    event,
    [
      'eventId',
      'expectedState',
      'to',
      'actor',
      'timestamp',
      'evidence',
      'reason',
    ],
    [
      'eventId',
      'expectedState',
      'to',
      'actor',
      'timestamp',
      'evidence',
      'reason',
    ],
    'event'
  );
  id(event.eventId, 'event.eventId');
  id(event.actor, 'event.actor');
  date(event.timestamp, 'event.timestamp');
  text(event.reason, 'event.reason');
  list(event.evidence, 'event.evidence', id, 1);
  requireCondition(
    event.expectedState === job.state,
    'STATE_CONFLICT',
    'The job changed; reload before retrying'
  );
  const exceptional = [
    'REFUSED',
    'FAILED',
    'TIMED_OUT',
    'REPAIR_REQUIRED',
    'ROLLED_BACK',
  ];
  requireCondition(
    FORWARD[job.state] === event.to ||
      (exceptional.includes(event.to) &&
        !['CHRONICLE_ELIGIBLE', ...exceptional].includes(job.state)),
    'TRANSITION_FORBIDDEN',
    'This job transition is not permitted'
  );
  const owner =
    event.to === 'VERIFIED'
      ? job.verifier.identity
      : ['ACCEPTED', 'CHRONICLE_ELIGIBLE'].includes(event.to)
      ? job.acceptance.owner
      : event.to === 'EXECUTING'
      ? job.actor
      : job.principal;
  requireCondition(
    event.actor === owner,
    'ROLE_CONFLICT',
    'The actor cannot authorize this transition'
  );
  if (['AUTHORIZED', 'EXECUTING'].includes(event.to)) {
    requireCondition(
      job.sealed === true && !!job.digest,
      'JOB_UNSEALED',
      'Seal the exact work order before authorization'
    );
    requireCondition(
      context.sealValid === true,
      'JOB_SEAL_UNVERIFIED',
      'The runtime must cryptographically verify the immutable work-order seal'
    );
    requireCondition(
      Date.parse(event.timestamp) < Date.parse(job.expiresAt),
      'JOB_EXPIRED',
      'The work order has expired'
    );
    requireCondition(
      context.preconditionsValid === true,
      'PRECONDITION_UNAVAILABLE',
      'Rights, dependencies and budget must be validated by the runtime'
    );
  }
  if (event.to === 'VERIFIED')
    requireCondition(
      context.verifierVerdict === 'PASS' && context.receiptValid === true,
      'VERIFICATION_REQUIRED',
      'A valid receipt and passing independent verdict are required'
    );
  if (event.to === 'ACCEPTED')
    requireCondition(
      context.acceptanceSatisfied === true,
      'ACCEPTANCE_CRITERIA_UNMET',
      'The runtime must verify the frozen deliverable acceptance predicate'
    );
  if (event.to === 'CHRONICLE_ELIGIBLE')
    requireCondition(
      job.chronicle.eligible && context.rightsCurrent === true,
      'CHRONICLE_INELIGIBLE',
      'Current reuse rights are required'
    );
  return { ...job, state: event.to };
}

return {SCHEMA_VERSION,JOB_FAMILIES,EDGE_KINDS,JOB_STATES,SuccessorError,requireCondition,validateBudget,validateMission,validateWorkOrder,validateGraph,transitionJob};
})();
__modules["implementation/vendor/alpha/examples/build-successor/vendor/agijobs/templates.mjs"] = (() => {
const {SCHEMA_VERSION, validateMission} = __modules["implementation/vendor/alpha/examples/build-successor/vendor/agijobs/domain.mjs"];

const JOB_TEMPLATES = Object.freeze(
  [
    [
      'mission-constitution',
      'constitution',
      'Mission Constitution',
      'Freeze objective, beneficiary, accountable principal, hard constraints and prohibitions.',
    ],
    [
      'incumbent-baseline',
      'evidence',
      'Incumbent Baseline',
      'Measure accepted quality, complete cost, risk, time, human burden and authority.',
    ],
    [
      'alternative-set',
      'constitution',
      'Alternative Set',
      'Document the strongest credible frontier, specialist, human, hybrid, software and no-action alternatives.',
    ],
    [
      'rights-data',
      'constitution',
      'Rights and Data Constitution',
      'Establish source provenance, licenses, retention, exclusions and permitted reuse.',
    ],
    [
      'mission-gym',
      'formation',
      'Mission Gym and Benchmark Constitution',
      'Specify states, observations, actions, transitions, rewards, constraints, partitions, verifier and basis risk; freeze representative distribution, protected custody, critical failures and thresholds.',
    ],
    [
      'oracle-teacher',
      'evidence',
      'Oracle and Teacher Study',
      'Declare external teaching signals, hidden-call prohibition and transfer hypothesis.',
    ],
    [
      'failure-taxonomy',
      'challenge',
      'Failure Taxonomy',
      'Classify errors, severity, causes, abstention, adversarial cases and stop conditions.',
    ],
    [
      'architecture-frontier',
      'formation',
      'Architecture Frontier',
      'Form diverse complete candidates and retain non-dominated reserve options.',
    ],
    [
      'experience-formation',
      'formation',
      'Data and Experience Formation',
      'Build rights-cleared examples and simulation experience with explicit quality controls.',
    ],
    [
      'specialist-formation',
      'formation',
      'Specialist Model Formation',
      'Construct or adapt candidate components with exact immutable release identities.',
    ],
    [
      'tools-retrieval',
      'formation',
      'Tool and Retrieval Formation',
      'Build bounded deterministic checks, retrieval, planners, sandboxes and interfaces.',
    ],
    [
      'verifier-formation',
      'verification',
      'Verifier Formation',
      'Calibrate independent evaluation, replay, attacks, hidden ground truth and scoring.',
    ],
    [
      'security-privacy',
      'verification',
      'Security and Privacy Proof',
      'Test credential controls, isolation, threat model, incidents and provider risks.',
    ],
    [
      'complete-economics',
      'evidence',
      'Complete Economics',
      'Count construction, operation, human rescue, maintenance, requalification and unwind.',
    ],
    [
      'human-agency',
      'constitution',
      'Human Burden and Agency',
      'Define reviewer capacity, escalation, contestability and accountable decision rights.',
    ],
    [
      'resilience-rollback',
      'verification',
      'Resilience and Rollback',
      'Prove graceful degradation, kill switch, portability and known-good restoration.',
    ],
    [
      'fresh-evaluation',
      'verification',
      'Protected Fresh Evaluation',
      'Evaluate one frozen challenger on unseen representative work with full intervention costs.',
    ],
    [
      'independent-validation',
      'verification',
      'Independent Validation',
      'Independently examine evidence, limitations, critical errors, basis risk and fit for stated purpose.',
    ],
    [
      'accountable-acceptance',
      'admission',
      'Accountable Acceptance',
      'Record the attributable purpose-specific acceptance decision separately from independent validation and authority admission.',
    ],
    [
      'chronicle-authority',
      'admission',
      'Chronicle and Authority Admission',
      'Record separate knowledge and authority decisions, scope, expiry, monitoring and revocation.',
    ],
    [
      'capital-requalification',
      'renewal',
      'Capital-to-Capacity and Requalification',
      'Allocate verified available value and define next-successor and fresh-transfer triggers.',
    ],
  ].map(([id, family, title, objective]) =>
    Object.freeze({ id, family, title, objective, coverageKey: id })
  )
);

function createPortfolioJobs(input) {
  const mission = validateMission(input);
  return JOB_TEMPLATES.map((template) => ({
    schemaVersion: SCHEMA_VERSION,
    kind: 'SealedWorkOrder',
    jobId: `${mission.missionId}:${template.id}`,
    missionId: mission.missionId,
    version: '1',
    family: template.family,
    objective: template.objective,
    principal: mission.principal,
    actor: mission.roles.producer,
    authorizedInputs: mission.rights.map((right) => right.sourceId),
    evidenceObligation: ['source-lineage', 'complete-cost', 'failure-record'],
    permittedTools: [...mission.allowedTools],
    permittedActions: [...mission.allowedActions],
    prohibitedActions: [...mission.authorityCeiling.prohibitedActions],
    budget: {
      unit: mission.budget.unit,
      limitBaseUnits: (BigInt(mission.budget.limitBaseUnits) / 21n).toString(),
      maxDurationMs: mission.budget.maxDurationMs,
      maxRetries: mission.budget.maxRetries,
    },
    expiresAt: mission.expiresAt,
    outputSchema: {
      type: 'object',
      required: ['evidence', 'findings', 'cost'],
    },
    verifier: {
      identity: mission.roles.verifier,
      method:
        'Independent examination against frozen purpose-specific criteria; template is not executed proof.',
      independence: 'I0',
    },
    acceptance: {
      owner: mission.roles.acceptor,
      predicate: `All ${template.title} obligations have valid traceable evidence and no failed hard gate.`,
      evidenceSources: mission.rights.map((right) => right.sourceId),
    },
    rollback: { ...mission.rollback },
    chronicle: {
      eligible: false,
      rights: 'Requires a separate rights and admission review.',
      scope: mission.objective,
      expiresAt: mission.expiresAt,
    },
    covers: mission.criticalFunctions.includes(template.coverageKey)
      ? [template.coverageKey]
      : [],
    state: 'DRAFT',
  }));
}

return {JOB_TEMPLATES,createPortfolioJobs};
})();
__modules["implementation/vendor/alpha/examples/build-successor/vendor/agijobs/compiler.mjs"] = (() => {
const {SCHEMA_VERSION,
  SuccessorError,
  requireCondition,
  validateMission,
  validateWorkOrder,
  validateGraph,
  transitionJob,} = __modules["implementation/vendor/alpha/examples/build-successor/vendor/agijobs/domain.mjs"];
const {cloneJson, digestObject} = __modules["implementation/vendor/alpha/examples/build-successor/vendor/agijobs/integrity.mjs"];
const {createPortfolioJobs} = __modules["implementation/vendor/alpha/examples/build-successor/vendor/agijobs/templates.mjs"];

const EXECUTION_EDGES = new Set(['evidence', 'control', 'challenge']);
function workOrderPayload(input) {
  const job = validateWorkOrder(input);
  const { digest, sealed, signatureStatus, state, ...immutable } = job;
  return immutable;
}
async function sealWorkOrder(input) {
  const job = validateWorkOrder(input);
  requireCondition(
    job.state === 'DRAFT',
    'SEAL_STATE_FORBIDDEN',
    'Only a draft may be sealed; material changes require a new draft version'
  );
  return {
    ...job,
    sealed: true,
    signatureStatus: 'UNSIGNED_COMMITMENT',
    digest: await digestObject(
      'successor.work-order.v1',
      workOrderPayload(job)
    ),
  };
}
async function verifyWorkOrderSeal(input) {
  const job = validateWorkOrder(input);
  return (
    job.sealed === true &&
    job.digest ===
      (await digestObject('successor.work-order.v1', workOrderPayload(job)))
  );
}
async function transitionSealedJob(current, event, trustedContext = {}) {
  requireCondition(
    await verifyWorkOrderSeal(current),
    'JOB_SEAL_INVALID',
    'The immutable work-order seal is invalid'
  );
  return transitionJob(current, event, { ...trustedContext, sealValid: true });
}
function topologicalOrder(nodes, edges) {
  const indegree = new Map(nodes.map((node) => [node.jobId, 0]));
  const outgoing = new Map(nodes.map((node) => [node.jobId, []]));
  for (const edge of edges.filter((edge) => EXECUTION_EDGES.has(edge.kind))) {
    outgoing.get(edge.from).push(edge.to);
    indegree.set(edge.to, indegree.get(edge.to) + 1);
  }
  const queue = [...indegree]
    .filter(([, count]) => count === 0)
    .map(([key]) => key)
    .sort();
  const order = [];
  const depth = new Map(nodes.map((node) => [node.jobId, 1]));
  while (queue.length) {
    const key = queue.shift();
    order.push(key);
    for (const target of outgoing.get(key)) {
      depth.set(target, Math.max(depth.get(target), depth.get(key) + 1));
      indegree.set(target, indegree.get(target) - 1);
      if (!indegree.get(target)) {
        queue.push(target);
        queue.sort();
      }
    }
  }
  requireCondition(
    order.length === nodes.length,
    'GRAPH_CYCLE',
    'Execution, acceptance and challenge dependencies must be acyclic; use bounded version-producing discovery loops'
  );
  requireCondition(
    Math.max(...depth.values()) <= 64,
    'GRAPH_DEPTH_EXCEEDED',
    'Graph exceeds the supported execution depth'
  );
  return order;
}

async function compileJobs(
  input,
  { jobs: proposedJobs, edges = [], now = new Date().toISOString() } = {}
) {
  const mission = validateMission(input);
  const instant = Date.parse(now);
  requireCondition(
    Number.isFinite(instant),
    'CLOCK_INVALID',
    'A valid compiler clock is required'
  );
  requireCondition(
    instant < Date.parse(mission.expiresAt),
    'MISSION_EXPIRED',
    'The mission constitution has expired'
  );
  requireCondition(
    new Set([
      mission.roles.producer,
      mission.roles.verifier,
      mission.roles.admitter,
    ]).size === 3,
    'ROLE_CONFLICT',
    'Producer, verifier and admitter must have distinct identities'
  );
  requireCondition(
    mission.roles.producer !== mission.roles.acceptor,
    'ROLE_CONFLICT',
    'A producer cannot accept its own delivered work'
  );
  requireCondition(
    mission.proofProtocol.formationOwner !== mission.proofProtocol.custodian,
    'PROOF_CUSTODY_CONFLICT',
    'Formation and protected proof custody must be separately attributed'
  );
  requireCondition(
    mission.rollback.available,
    'ROLLBACK_UNAVAILABLE',
    'An available rollback or containment route is required'
  );
  if (mission.proofProtocol.mode === 'INDEPENDENT_REQUEST')
    requireCondition(
      ['I3', 'I4'].includes(mission.proofProtocol.requiredIndependence),
      'INDEPENDENCE_INSUFFICIENT',
      'An independently proven request requires I3 or I4 custody; internal rehearsal remains available'
    );
  for (const action of mission.allowedActions)
    requireCondition(
      !mission.authorityCeiling.prohibitedActions.includes(action),
      'ACTION_PROHIBITED',
      'A permitted formation action conflicts with a prohibition',
      { action }
    );
  requireCondition(
    proposedJobs === undefined || Array.isArray(proposedJobs),
    'SCHEMA_INVALID',
    'Jobs must be a bounded array'
  );
  const jobs = (proposedJobs ?? createPortfolioJobs(mission)).map(
    validateWorkOrder
  );
  requireCondition(
    jobs.length <= mission.budget.maxJobs,
    'JOB_LIMIT_EXCEEDED',
    'The graph exceeds its authorized work count'
  );
  const graph = validateGraph({
    schemaVersion: SCHEMA_VERSION,
    kind: 'JobGraph',
    graphId: `${mission.missionId}:graph`,
    missionId: mission.missionId,
    version: mission.version,
    nodes: jobs,
    edges,
    authorityCreated: 'NONE',
  });
  const ids = new Set(jobs.map((job) => job.jobId));
  const rights = new Map(
    mission.rights.map((right) => [right.sourceId, right])
  );
  const edgeKeys = new Set();
  for (const edge of graph.edges) {
    requireCondition(
      ids.has(edge.from) && ids.has(edge.to),
      'REFERENCE_UNRESOLVED',
      'A graph edge references an unknown job',
      edge
    );
    requireCondition(
      edge.from !== edge.to,
      'GRAPH_CYCLE',
      'Self-dependent jobs are not admissible',
      edge
    );
    const key = `${edge.from}|${edge.to}|${edge.kind}`;
    requireCondition(
      !edgeKeys.has(key),
      'EDGE_DUPLICATE',
      'Duplicate graph edge',
      edge
    );
    edgeKeys.add(key);
  }
  const executionOrder = topologicalOrder(jobs, graph.edges);
  let reservation = 0n;
  for (const job of jobs) {
    requireCondition(
      job.missionId === mission.missionId &&
        job.principal === mission.principal,
      'MISSION_BINDING_MISMATCH',
      'Job mission and accountable principal must match the constitution',
      { jobId: job.jobId }
    );
    requireCondition(
      job.state === 'DRAFT',
      'COMPILER_REQUIRES_DRAFT',
      'Compilation cannot grant or replay an existing job lifecycle state'
    );
    requireCondition(
      job.actor !== job.verifier.identity &&
        job.actor !== mission.roles.admitter,
      'ROLE_CONFLICT',
      'A producer cannot verify its own work or hold admission identity',
      { jobId: job.jobId }
    );
    requireCondition(
      job.actor !== job.acceptance.owner,
      'ROLE_CONFLICT',
      'A producing actor cannot accept its own delivered work',
      { jobId: job.jobId }
    );
    requireCondition(
      job.verifier.identity === mission.roles.verifier,
      'VERIFIER_UNAUTHORIZED',
      'Job verifier must be the constituted verifier identity',
      { jobId: job.jobId }
    );
    requireCondition(
      job.acceptance.owner === mission.roles.acceptor,
      'ACCEPTANCE_OWNER_MISMATCH',
      'Acceptance must belong to the constituted owner',
      { jobId: job.jobId }
    );
    requireCondition(
      job.rollback.available,
      'ROLLBACK_UNAVAILABLE',
      'Job has no available rollback or containment route',
      { jobId: job.jobId }
    );
    requireCondition(
      Date.parse(job.expiresAt) > instant &&
        Date.parse(job.expiresAt) <= Date.parse(mission.expiresAt),
      'JOB_EXPIRED',
      'Job expiry must be current and within the mission expiry',
      { jobId: job.jobId }
    );
    requireCondition(
      job.budget.unit === mission.budget.unit,
      'BUDGET_UNIT_MISMATCH',
      'Job and mission budget units differ',
      { jobId: job.jobId }
    );
    requireCondition(
      job.budget.maxRetries <= mission.budget.maxRetries &&
        job.budget.maxDurationMs <= mission.budget.maxDurationMs,
      'BUDGET_LIMIT_EXCEEDED',
      'Job resource limits exceed the mission ceiling',
      { jobId: job.jobId }
    );
    reservation += BigInt(job.budget.limitBaseUnits);
    for (const tool of job.permittedTools)
      requireCondition(
        mission.allowedTools.includes(tool),
        'TOOL_UNSUPPORTED',
        'The mission has not admitted this tool',
        { jobId: job.jobId, tool }
      );
    for (const action of job.permittedActions)
      requireCondition(
        mission.allowedActions.includes(action) &&
          !job.prohibitedActions.includes(action) &&
          !mission.authorityCeiling.prohibitedActions.includes(action),
        'ACTION_PROHIBITED',
        'Action is not within the mission capability mask',
        { jobId: job.jobId, action }
      );
    for (const prohibited of mission.authorityCeiling.prohibitedActions)
      requireCondition(
        job.prohibitedActions.includes(prohibited),
        'PROHIBITION_WEAKENED',
        'Job removes a constitutional prohibition',
        { jobId: job.jobId, prohibited }
      );
    for (const source of job.authorizedInputs) {
      if (rights.has(source)) {
        const right = rights.get(source);
        requireCondition(
          Date.parse(right.expiresAt) > instant &&
            Date.parse(right.expiresAt) >= Date.parse(job.expiresAt),
          'RIGHTS_EXPIRED',
          'Source rights do not cover the job duration',
          { jobId: job.jobId, source }
        );
        requireCondition(
          right.permittedUses.includes('mission-evaluation'),
          'RIGHTS_SCOPE_MISMATCH',
          'Source does not permit mission evaluation',
          { jobId: job.jobId, source }
        );
      } else {
        requireCondition(
          ids.has(source) &&
            graph.edges.some(
              (edge) =>
                edge.from === source &&
                edge.to === job.jobId &&
                edge.kind === 'evidence'
            ),
          'EVIDENCE_PATH_MISSING',
          'Every derived input requires an upstream evidence edge',
          { jobId: job.jobId, source }
        );
      }
    }
    for (const source of job.acceptance.evidenceSources)
      requireCondition(
        job.authorizedInputs.includes(source),
        'ACCEPTANCE_EVIDENCE_UNAVAILABLE',
        'Acceptance cannot depend on an unauthorized or producer-only source',
        { jobId: job.jobId, source }
      );
  }
  requireCondition(
    reservation <= BigInt(mission.budget.limitBaseUnits),
    'BUDGET_EXCEEDED',
    'Aggregate cumulative job budgets exceed the mission budget',
    {
      reservedBaseUnits: reservation.toString(),
      limitBaseUnits: mission.budget.limitBaseUnits,
    }
  );
  const coverage = mission.criticalFunctions.map((functionId) => ({
    functionId,
    jobIds: jobs
      .filter((job) => job.covers.includes(functionId))
      .map((job) => job.jobId),
    status: 'PLANNED_NOT_ACCEPTED',
  }));
  for (const obligation of coverage)
    requireCondition(
      obligation.jobIds.length > 0,
      'CRITICAL_COVERAGE_MISSING',
      'A non-negotiable mission function has no job path',
      { functionId: obligation.functionId }
    );
  const sealedJobs = await Promise.all(jobs.map(sealWorkOrder));
  const sealedGraph = { ...graph, nodes: sealedJobs };
  sealedGraph.digest = await digestObject(
    'successor.job-graph.v1',
    sealedGraph
  );
  const dependencyMap = Object.fromEntries(
    jobs.map((job) => [
      job.jobId,
      graph.edges
        .filter(
          (edge) => edge.to === job.jobId && EXECUTION_EDGES.has(edge.kind)
        )
        .map((edge) => ({ jobId: edge.from, kind: edge.kind })),
    ])
  );
  const invalidationMap = Object.fromEntries(
    [...rights.keys(), ...ids].map((key) => [
      key,
      jobs
        .filter((job) => job.authorizedInputs.includes(key))
        .map((job) => job.jobId),
    ])
  );
  for (const edge of graph.edges.filter((edge) =>
    ['evidence', 'invalidation', 'challenge', 'control'].includes(edge.kind)
  ))
    if (!invalidationMap[edge.from].includes(edge.to))
      invalidationMap[edge.from].push(edge.to);
  return {
    schemaVersion: SCHEMA_VERSION,
    status: 'SEALED',
    mode: mission.proofProtocol.mode,
    constitution: mission,
    graph: sealedGraph,
    executionOrder,
    coverage,
    criticalEvidenceCuts: coverage.map(({ functionId, jobIds }) => ({
      functionId,
      removeJobIds: jobIds,
      exhaustive: false,
    })),
    budgetReservations: {
      unit: mission.budget.unit,
      reservedBaseUnits: reservation.toString(),
      limitBaseUnits: mission.budget.limitBaseUnits,
      includesRetries: true,
    },
    dependencyMap,
    invalidationMap,
    capabilityRequests: jobs.map((job) => ({
      jobId: job.jobId,
      actor: job.actor,
      tools: job.permittedTools,
      actions: job.permittedActions,
      status: 'REQUESTED_NOT_GRANTED',
    })),
    evaluationPlan: cloneJson(mission.proofProtocol),
    authorityCreated: 'NONE',
    signatureStatus: 'UNSIGNED_COMMITMENT',
    digest: await digestObject('successor.constitution.v1', mission),
  };
}

function invalidationClosure(compilation, sourceIds) {
  const pending = [...sourceIds];
  const seen = new Set();
  while (pending.length) {
    const source = pending.shift();
    if (seen.has(source)) continue;
    seen.add(source);
    pending.push(...(compilation.invalidationMap[source] ?? []));
  }
  return [...seen].sort();
}

async function diagnoseMission(mission, options) {
  try {
    return await compileJobs(mission, options);
  } catch (error) {
    if (!(error instanceof SuccessorError)) throw error;
    return {
      status: 'REJECTED',
      diagnostics: [error.toJSON()],
      authorityCreated: 'NONE',
    };
  }
}

return {workOrderPayload,sealWorkOrder,verifyWorkOrderSeal,transitionSealedJob,compileJobs,invalidationClosure,diagnoseMission};
})();
__modules["implementation/vendor/alpha/examples/build-successor/model.mjs"] = (() => {
// SPDX-License-Identifier: Apache-2.0
const alpha = __modules["implementation/vendor/alpha/docs/assets/successor/engine.mjs"];
const {compileJobs} = __modules["implementation/vendor/alpha/examples/build-successor/vendor/agijobs/compiler.mjs"];
const {JOB_TEMPLATES, createPortfolioJobs} = __modules["implementation/vendor/alpha/examples/build-successor/vendor/agijobs/templates.mjs"];
const {digestObject} = __modules["implementation/vendor/alpha/examples/build-successor/vendor/agijobs/integrity.mjs"];

const TOKEN = '0xA61a3B3a130a9c20768EEBF97E21515A6046a1fA';
const DELIVERABLES = [
  'mission.json: count, sum, maximum duration and error count by day and service; zero incorrect totals.',
  'incumbent.json: exact outputs and observed timings for the existing one-pass Map implementation.',
  'alternatives.json: compare the deterministic sort-and-reduce baseline; record that a frontier comparison is missing.',
  'rights.json: synthetic nonpersonal events only; list code licenses and permitted reuse.',
  'gym.json: version the event generator, malformed-input cases, public partitions and zero-error gate.',
  'teacher.json: disclose that this example uses fixed code and no external model or teaching calls.',
  'failures.json: test empty data, invalid numbers, malformed Unicode and unusual service keys.',
  'candidates.json: preserve all four bounded aggregation configurations and rejected attempts.',
  'experience.json: record seeds, workload sizes and generator version; no protected claims.',
  'candidate.json: freeze the selected grammar and engine SHA-256 before comparative evaluation.',
  'tools.json: allow only the fixed aggregation engine; no arbitrary code, browsing or money movement.',
  'verifier.json: reproduce exact outputs and reject invalid inputs; identify missing independent custody.',
  'security.json: confirm no external requests, keys, personal data or wallet approvals are required.',
  'economics.json: record all observed costs; mark compute price, human review and maintenance unmeasured.',
  'roles.json: separate producer, verifier, acceptance owner and admitter; labels are unauthenticated.',
  'rollback.json: retain the baseline and demonstrate clearing the active candidate without external effects.',
  'evaluation.json: compare the frozen candidate with both baselines on six further public workloads.',
  'review.json: obtain a separately attributable review; this browser leaves independent proof absent.',
  'acceptance.json: require evidence against the frozen terms; all work orders remain DRAFT here.',
  'authority.json: retain HOLD with zero grants until separate, scoped, expiring, revocable admission.',
  'renewal.json: propose the next test and preserve lessons; a successor inherits no proof or authority.',
];
const FRENCH_TITLES = [
  'Constitution de mission', 'Référence actuelle', 'Ensemble des alternatives', 'Droits et données',
  'Environnement d’entraînement et protocole comparatif', 'Étude des oracles et des enseignants',
  'Classification des échecs', 'Comparaison des architectures', 'Formation des données et de l’expérience',
  'Formation du modèle spécialisé', 'Outils et recherche documentaire', 'Construction du vérificateur',
  'Sécurité et confidentialité', 'Économie complète', 'Charge humaine et pouvoir de décision',
  'Résilience et retour arrière', 'Évaluation protégée sur données nouvelles', 'Validation indépendante',
  'Acceptation responsable', 'Chronique et admission de l’autorité', 'Capacité financée et requalification',
];
const FRENCH_DELIVERABLES = [
  'mission.json : compter les événements, les erreurs, la durée totale et maximale par jour et service; aucun total incorrect.',
  'incumbent.json : conserver les sorties exactes et les durées de la référence Map en un seul passage.',
  'alternatives.json : comparer la référence déterministe par tri et réduction; signaler l’absence de comparaison avec les meilleures IA.',
  'rights.json : utiliser uniquement des événements fictifs non personnels; préciser les licences et réutilisations permises.',
  'gym.json : versionner le générateur, les entrées mal formées, les jeux publics et le seuil de zéro erreur.',
  'teacher.json : déclarer le code fixe utilisé et l’absence de modèle externe ou d’appel d’enseignement.',
  'failures.json : tester les données vides, nombres invalides, caractères Unicode mal formés et clés de service inhabituelles.',
  'candidates.json : conserver les quatre configurations délimitées et les tentatives rejetées.',
  'experience.json : noter les graines aléatoires, tailles de jeux et version du générateur; aucune preuve protégée.',
  'candidate.json : figer la grammaire retenue et l’empreinte SHA-256 du moteur avant la comparaison.',
  'tools.json : autoriser uniquement le moteur fixe; aucun code arbitraire, navigation ou mouvement de fonds.',
  'verifier.json : reproduire les sorties exactes et rejeter les entrées invalides; signaler l’absence de garde indépendante.',
  'security.json : vérifier l’absence de requêtes externes, clés, données personnelles et autorisations de portefeuille.',
  'economics.json : noter les coûts observés; laisser le prix du calcul, la revue humaine et la maintenance non mesurés.',
  'roles.json : distinguer producteur, vérificateur, responsable de l’acceptation et décideur d’admission; identités non authentifiées.',
  'rollback.json : garder la référence et démontrer l’abandon du candidat actif sans effet externe.',
  'evaluation.json : comparer le candidat figé aux deux références sur six nouveaux jeux publics.',
  'review.json : obtenir une revue attribuable séparément; aucune preuve indépendante n’est créée dans le navigateur.',
  'acceptance.json : exiger des preuves conformes aux termes figés; toutes les tâches restent des brouillons DRAFT.',
  'authority.json : maintenir HOLD et zéro autorisation jusqu’à une admission distincte, limitée, temporaire et révocable.',
  'renewal.json : proposer le prochain test et garder les enseignements; aucun héritage automatique de preuve ou d’autorité.',
];

function missionFor({ name = 'Atlas Ω', budget = '2100', now = new Date().toISOString() } = {}) {
  if (typeof name !== 'string' || !name.trim() || name.length > 48) throw Error('Use a name of 1–48 characters.');
  if (typeof budget !== 'string' || !/^[1-9][0-9]{0,6}$/.test(budget) || BigInt(budget) > 1000000n) {
    throw Error('Use a whole planning allowance from 1 to 1,000,000 AGIALPHA.');
  }
  if (!Number.isFinite(Date.parse(now))) throw Error('A valid clock is required.');
  const expiresAt = new Date(Date.parse(now) + 7 * 86400000).toISOString();
  return {
    schemaVersion: '1.0.0', kind: 'MissionConstitution', missionId: 'streaming-metrics-builder-v1',
    institutionId: 'local-successor-workshop', version: '1', title: name.trim().normalize('NFC'),
    principal: 'example-human-principal', beneficiary: 'Owner of this local synthetic mission',
    objective: 'Produce exact daily service metrics, compare bounded implementations, and prepare reviewable work orders.',
    incumbent: { id: 'alpha-current', version: alpha.VERSION, description: 'Measured one-pass Map baseline.' },
    alternatives: [{ id: 'alpha-beta', version: alpha.VERSION, description: 'Measured deterministic sort-and-reduce baseline; not a frontier AI comparator.' }],
    rights: [{ sourceId: 'synthetic-events', license: 'Apache-2.0 generator; synthetic nonpersonal outputs', dataClass: 'synthetic', permittedUses: ['mission-evaluation', 'fixture-export'], expiresAt }],
    hardGates: [
      { id: 'exact-output', description: 'All grouped counts and durations agree exactly.', maxViolations: 0 },
      { id: 'invalid-input', description: 'Malformed and unsupported records are rejected.', maxViolations: 0 },
      { id: 'no-external-effect', description: 'No network request, live job, payment or authority grant.', maxViolations: 0 },
    ],
    criticalFunctions: JOB_TEMPLATES.map(t => t.coverageKey),
    roles: { producer: 'example-producer', verifier: 'example-verifier', acceptor: 'example-acceptor', admitter: 'example-admitter' },
    budget: { unit: 'AGIALPHA', limitBaseUnits: (BigInt(budget) * 10n ** 18n).toString(), maxDurationMs: 60000, maxRetries: 0, maxJobs: 21 },
    expiresAt,
    authorityCeiling: { level: 'A0', permittedActions: ['inspect-local'], prohibitedActions: ['send-payment', 'post-live-job', 'access-private-data', 'self-admit'], externalEffects: false },
    allowedTools: ['fixed-aggregation-engine'], allowedActions: ['inspect-local'],
    rollback: { target: 'alpha-current', available: true, reason: 'Discard the local candidate and return to the retained fixed baseline.' },
    proofProtocol: { id: 'public-local-rehearsal', version: '1', mode: 'SYNTHETIC_REHEARSAL', formationOwner: 'example-producer', custodian: 'example-verifier', requiredIndependence: 'I0', minimumMargin: 0.05, criticalErrorCeiling: 0, scope: 'Public synthetic cases in one process; no independent proof, mission alpha or operational admission.' },
  };
}

async function compilePlan(options = {}) {
  const mission = missionFor(options);
  const jobs = createPortfolioJobs(mission).map((job, i) => ({
    ...job,
    objective: `${job.objective} Streaming-metrics deliverable: ${DELIVERABLES[i]}`,
    acceptance: { ...job.acceptance, predicate: `${DELIVERABLES[i]} Preserve failures and missing evidence. Separate review is required.` },
  }));
  const dependencies = [[], [0], [0], [0], [1, 2, 3], [4], [4], [1, 2, 5, 6], [3, 4], [7, 8], [9], [4, 6, 10], [10, 11], [1, 2, 9], [0, 13], [10, 12], [9, 11, 12, 13, 14, 15], [16], [17], [18], [19]];
  const edges = dependencies.flatMap((parents, i) => parents.map(j => ({ from: jobs[j].jobId, to: jobs[i].jobId, kind: 'evidence' })));
  for (const edge of edges) jobs.find(job => job.jobId === edge.to).authorizedInputs.push(edge.from);
  return compileJobs(mission, { jobs, edges, now: options.now });
}

async function buildPack(options = {}, { signal, onProgress = () => {} } = {}) {
  const now = options.now || new Date().toISOString();
  const request = alpha.newRequest({ max_events: options.events ?? 1000, seed: options.seed ?? 42, max_candidates: 4, language: options.language ?? 'en' });
  if (!/^[0-9a-f]{64}$/.test(options.engineSourceHash || '')) throw Error('Engine source identity is required.');
  onProgress('compile');
  const compilation = await compilePlan({ ...options, now });
  if (signal?.aborted) throw new DOMException('Cancelled', 'AbortError');
  onProgress('discover');
  const discovery = await alpha.discover(request, { signal });
  const frozen = await alpha.freeze(request, discovery, options.engineSourceHash);
  onProgress('evaluate');
  const evaluation = await alpha.evaluate(request, frozen, { signal });
  const record = {
    schema: 'successor-build-example/v1', createdAt: now, title: compilation.constitution.title,
    scope: 'LOCAL_REHEARSAL', request, compilation, discovery, frozen, evaluation,
    token: { symbol: 'AGIALPHA', chainId: 1, address: TOKEN, decimals: 18 },
    settlement: { status: 'NOT_CONNECTED', transactions: [], spentBaseUnits: '0', allowanceIs: 'ILLUSTRATIVE_NOT_FUNDED' },
    admission: { decision: 'HOLD', independentProof: false, authority: [], specialistASI: false },
    chronicle: [{ kind: 'local-observation', candidateRelease: frozen.release_hash, reusable: 'Configuration hypothesis only; rerun tests.', inheritedProof: false, inheritedAuthority: false }],
  };
  return { ...record, integrityDigest: await digestObject('successor-build-example.v1', record) };
}

function jobBriefs(pack) {
  if(pack.request.language==='fr')return `# ${pack.title} — Fiches de construction SUCCESSOR Ω\n\nRÉPÉTITION LOCALE. Brouillons DRAFT, empreintes non signées, zéro dépense.\nPreuve indépendante absente. Admission HOLD. Aucune autorité accordée.\n\nJeton commun sur Ethereum mainnet : ${TOKEN} (AGIALPHA, 18 décimales).\nBudget de planification seulement; frais, mises et gaz à estimer séparément.\n\n` +
    pack.compilation.graph.nodes.map((job,i)=>`## ${i+1}. ${FRENCH_TITLES[i]}\n\n${FRENCH_DELIVERABLES[i]}\n\nTermes canoniques du compilateur (anglais) : ${job.objective}\n\nCritère d’acceptation canonique (anglais) : ${job.acceptance.predicate}\n\nLimite de planification (unités de base AGIALPHA) : ${job.budget.limitBaseUnits}\nExpiration : ${job.expiresAt}\nProducteur : ${job.actor}\nVérificateur : ${job.verifier.identity}\nResponsable de l’acceptation : ${job.acceptance.owner}\nRetour arrière : ${job.rollback.target}\nEmpreinte non signée : ${job.digest}\n`).join('\n') +
    '\nSuite : organiser une évaluation protégée indépendante, mesurer tous les coûts, mettre en service l’intégration puis demander une décision humaine d’admission distincte. Le jeton commun ne relie pas automatiquement les marchés.\n';
  return `# ${pack.title} — SUCCESSOR Ω build briefs\n\nLOCAL REHEARSAL. DRAFT work, unsigned commitments, zero funds spent.\nIndependent proof absent. Admission HOLD. No authority is granted.\n\nShared Ethereum mainnet token: ${TOKEN} (AGIALPHA, 18 decimals).\nPlanning allowance only; fees, stakes and gas require separate estimates before commissioning.\n\n` +
    pack.compilation.graph.nodes.map((job, i) => `## ${i + 1}. ${JOB_TEMPLATES[i].title}\n\n${job.objective}\n\nAcceptance: ${job.acceptance.predicate}\n\nPlanning limit (AGIALPHA base units): ${job.budget.limitBaseUnits}\nExpiry: ${job.expiresAt}\nProducer: ${job.actor}\nVerifier: ${job.verifier.identity}\nAcceptance owner: ${job.acceptance.owner}\nRollback: ${job.rollback.target}\nUnsigned commitment: ${job.digest}\n`).join('\n') +
    '\nNext: arrange independent protected evaluation, measure full costs, resolve commissioning, then request a separate human admission decision. Sharing the token does not bridge the two markets.\n';
}

return {TOKEN,DELIVERABLES,FRENCH_TITLES,FRENCH_DELIVERABLES,missionFor,compilePlan,buildPack,jobBriefs};
})();
__modules["implementation/vendor/alpha/examples/successor-workbench/engine.mjs"] = (() => {
// SPDX-License-Identifier: Apache-2.0
const {canonical, digest, parseBounded} = __modules["implementation/vendor/alpha/docs/assets/successor/engine.mjs"];
const {missionFor} = __modules["implementation/vendor/alpha/examples/build-successor/model.mjs"];
const {compileJobs} = __modules["implementation/vendor/alpha/examples/build-successor/vendor/agijobs/compiler.mjs"];
const {createPortfolioJobs} = __modules["implementation/vendor/alpha/examples/build-successor/vendor/agijobs/templates.mjs"];

const VERSION = 'successor-workbench/v1';
const REGISTRY = Object.freeze([
  { id: 'reliability', en: 'Repair a range utility', fr: 'Réparer un utilitaire', artifact: 'repair.patch', scope: 'Closed interval utilities in the documented finite source grammar.' },
  { id: 'performance', en: 'Compare real algorithms', fr: 'Comparer des algorithmes', artifact: 'benchmark.json', scope: 'Exact sorted unique integer values; sort/reduce versus Set/sort.' },
  { id: 'documentation', en: 'Check executable examples', fr: 'Vérifier des exemples exécutables', artifact: 'checked-examples.md', scope: 'Named URI and UTF-8 SDK operations in bounded JSON examples.' },
  { id: 'public-data', en: 'Turn data into a report', fr: 'Transformer des données en rapport', artifact: 'report.html', scope: 'Public or synthetic two-column CSV with exact integer amounts.' },
  { id: 'numerical', en: 'Reproduce a calculation', fr: 'Reproduire un calcul', artifact: 'numerical.json', scope: 'Polynomial integration using exact rational arithmetic and two quadrature rules.' },
]);

const clone = value => parseBounded(canonical(value));
function fields(value, keys, label) {
  if (!value || typeof value !== 'object' || Array.isArray(value) ||
      Object.keys(value).sort().join('|') !== [...keys].sort().join('|')) throw Error(`SCHEMA: ${label}`);
}
function integer(value, low, high, label) {
  if (!Number.isSafeInteger(value) || value < low || value > high) throw Error(`BOUNDS: ${label}`);
}
function text(value, maximum, label) {
  if (typeof value !== 'string' || !value.trim() || value.length > maximum) throw Error(`TEXT: ${label}`);
}
function html(value) { return String(value).replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char])); }
function file(name, type, content) { return { name, type, content }; }
function jsonFile(name, object) { return file(name, 'application/json', JSON.stringify(object, null, 2) + '\n'); }

function example(family = 'reliability') {
  const inputs = {
    reliability: { source: 'export function contains(value, low, high) { return low < value && value < high; }', low: 0, high: 10, cases: [-1, 0, 1, 5, 9, 10, 11] },
    performance: { values: [8, 3, 8, 1, 0, -3, 3, 12, 0, 7], repetitions: 7, repeats: 100 },
    documentation: { markdown: '# URI helper examples\n\n```successor-example\n{"operation":"url-encode","input":"hello world","expected":"hello+world"}\n```\n\n```successor-example\n{"operation":"url-decode","input":"hello%20world","expected":"hello world"}\n```\n' },
    'public-data': { csv: 'group,amount\nResearch,120\nSoftware,85\nResearch,35\nDocumentation,60\nSoftware,-5\n', unit: 'synthetic units' },
    numerical: { coefficients: [0, 0, 1], lower: 0, upper: 3, steps: 12, tolerancePpm: 1 },
  };
  if (!Object.hasOwn(inputs, family)) throw Error('UNSUPPORTED_FAMILY');
  return { schema: VERSION, family, name: 'My SUCCESSOR Ω', language: 'en', owner: 'local-owner',
    rights: { dataClass: 'synthetic', source: 'Included public example', license: 'Apache-2.0' },
    reviewMinutes: 10, inputs: clone(inputs[family]) };
}

function validate(spec, adapter = null) {
  fields(spec, ['schema','family','name','language','owner','rights','reviewMinutes','inputs'], 'mission');
  if (spec.schema !== VERSION || !(REGISTRY.some(item => item.id === spec.family) || adapter?.manifest.id === spec.family)) throw Error('UNSUPPORTED_VERSION_OR_FAMILY');
  text(spec.name, 64, 'name'); text(spec.owner, 128, 'owner');
  if (!['en','fr'].includes(spec.language)) throw Error('LANGUAGE');
  fields(spec.rights, ['dataClass','source','license'], 'rights');
  if (!['public','licensed-nonpersonal','synthetic'].includes(spec.rights.dataClass)) throw Error('INPUT_RIGHTS');
  text(spec.rights.source, 1000, 'source'); text(spec.rights.license, 1000, 'license');
  integer(spec.reviewMinutes, 1, 120, 'review capacity');
  const value = spec.inputs;
  if (adapter) {
    adapter.validate(clone(value));
  } else if (spec.family === 'reliability') {
    fields(value, ['source','low','high','cases'], 'reliability input');
    text(value.source, 2000, 'source'); rangeProgram(value.source);
    integer(value.low, -1000000, 1000000, 'low'); integer(value.high, value.low, 1000000, 'high');
    if (!Array.isArray(value.cases) || value.cases.length < 1 || value.cases.length > 2000) throw Error('CASES');
    value.cases.forEach(n => integer(n, -1000001, 1000001, 'case'));
  } else if (spec.family === 'performance') {
    fields(value, ['values','repetitions','repeats'], 'performance input');
    if (!Array.isArray(value.values) || value.values.length < 1 || value.values.length > 2000) throw Error('VALUES');
    value.values.forEach(n => integer(n, -1000000, 1000000, 'value'));
    integer(value.repetitions, 3, 15, 'repetitions'); integer(value.repeats, 1, 500, 'repeats');
  } else if (spec.family === 'documentation') {
    fields(value, ['markdown'], 'documentation input'); text(value.markdown, 100000, 'markdown');
    const matches = [...value.markdown.matchAll(/```successor-example\s*\n([\s\S]*?)\n```/g)];
    if (!matches.length || matches.length > 40) throw Error('EXAMPLES: use 1–40 successor-example JSON blocks');
    for (const match of matches) validateDocExample(parseBounded(match[1]));
  } else if (spec.family === 'public-data') {
    fields(value, ['csv','unit'], 'data input'); text(value.csv, 100000, 'csv'); text(value.unit, 80, 'unit');
    readRows(value.csv);
  } else {
    fields(value, ['coefficients','lower','upper','steps','tolerancePpm'], 'numerical input');
    if (!Array.isArray(value.coefficients) || !value.coefficients.length || value.coefficients.length > 7) throw Error('COEFFICIENTS');
    value.coefficients.forEach(n => integer(n, -1000, 1000, 'coefficient'));
    integer(value.lower, -100, 99, 'lower'); integer(value.upper, value.lower + 1, 100, 'upper');
    integer(value.steps, 2, 1000, 'steps'); if (value.steps % 2) throw Error('EVEN_STEPS_REQUIRED');
    integer(value.tolerancePpm, 0, 1000000, 'absolute tolerance in millionths');
  }
  canonical(spec);
  return clone(spec);
}

async function semanticIdentity(spec, adapter = null) {
  const { name, language, ...semantic } = validate(spec, adapter);
  return digest('workbench-mission', semantic);
}

function rangeProgram(source) {
  const match = /^\s*export\s+function\s+contains\s*\(\s*value\s*,\s*low\s*,\s*high\s*\)\s*\{\s*return\s+low\s*(<=|<)\s*value\s*&&\s*value\s*(<=|<)\s*high\s*;\s*\}\s*$/.exec(source);
  if (!match) throw Error('SOURCE_GRAMMAR: only the documented bounded contains function is supported');
  return { lower: match[1], upper: match[2], execute: (value, low, high) =>
    (match[1] === '<=' ? low <= value : low < value) && (match[2] === '<=' ? value <= high : value < high) };
}
async function reliability(input, checkpoint) {
  const incumbent = rangeProgram(input.source);
  const cases = [...new Set([...input.cases, input.low - 1, input.low, input.high, input.high + 1])];
  const tests = cases.map(value => ({value, expected: value >= input.low && value <= input.high,
    actual: incumbent.execute(value, input.low, input.high)}));
  const attempts = [];
  for (const lower of ['<','<=']) for (const upper of ['<','<=']) {
    await checkpoint('testing');
    const source = `export function contains(value, low, high) { return low ${lower} value && value ${upper} high; }`;
    const method = rangeProgram(source);
    const failed = cases.filter(value => method.execute(value, input.low, input.high) !== (value >= input.low && value <= input.high));
    attempts.push({source, failed});
  }
  const selected = attempts.find(item => item.failed.length === 0);
  const defects = tests.filter(item => item.expected !== item.actual);
  const candidate = selected.source;
  const originalLines=input.source.trim().split(/\r?\n/);
  const patch = `--- a/contains.mjs\n+++ b/contains.mjs\n@@ -1,${originalLines.length} +1 @@\n${originalLines.map(line=>'-'+line).join('\n')}\n+${candidate}\n`;
  const checks = `// SPDX-License-Identifier: Apache-2.0\nimport assert from 'node:assert/strict';\nimport { contains } from './contains.mjs';\nfor (const c of ${JSON.stringify(tests.map(({value,expected})=>({value,expected})))}) assert.equal(contains(c.value, ${input.low}, ${input.high}), c.expected);\nconsole.log('All ${tests.length} fixed contract checks passed');\n`;
  return { decision: defects.length ? 'REPAIR_PROPOSED' : 'RETAIN_INCUMBENT', summary: {tests: tests.length, defects: defects.length, candidateFailures: 0},
    evidence: {tests, attempts, protectedCases: false, execution: 'Finite source grammar interpreted without eval or arbitrary host execution'},
    artifacts: [file('contains.mjs','text/javascript',candidate+'\n'), file('original.mjs','text/javascript',input.source+'\n'),
      file('check.mjs','text/javascript',checks),file('repair.patch','text/plain',defects.length ? patch : '# No repair needed.\n'),jsonFile('tests.json',tests)],
    limits: ['This adapter supports the declared range utility grammar only; arbitrary repositories need a separately isolated executor.', 'Public contract tests are engineering evidence, not independently protected qualification.'] };
}

async function performanceWork(input, checkpoint) {
  const sortUnique = values => values.slice().sort((a,b)=>a-b).filter((n,i,a)=>i===0 || n!==a[i-1]);
  const setUnique = values => [...new Set(values)].sort((a,b)=>a-b);
  const expected = sortUnique(input.values);
  const samples = { sort: [], set: [] };
  for (let r=0;r<input.repetitions;r++) {
    for (const name of (r%2 ? ['set','sort'] : ['sort','set'])) {
      await checkpoint('benchmarking');
      const fn = name==='sort' ? sortUnique : setUnique;
      const start = globalThis.performance.now(); let actual;
      for (let i=0;i<input.repeats;i++) actual=fn(input.values);
      samples[name].push(Math.max(0,Math.round((globalThis.performance.now()-start)*1000)));
      if (canonical(actual)!==canonical(expected)) throw Error('CRITICAL_CORRECTNESS_FAILURE');
    }
  }
  const median = values => [...values].sort((a,b)=>a-b)[Math.floor(values.length/2)];
  const selected = median(samples.set) < median(samples.sort) ? 'set' : 'sort';
  const report = { samplesMicrosecondsPerBatch: samples, batchRepeats: input.repeats,
    medianMicroseconds: {sort: median(samples.sort),set: median(samples.set)}, selected, output: expected,
    resourceTradeoff: 'Set retains a hash table and a unique-value array; sort copies and sorts all input values. Peak memory is not measured.' };
  return {decision: selected==='sort'?'RETAIN_INCUMBENT':'CANDIDATE_FASTER_IN_THIS_RUN',summary:{inputCount:input.values.length,outputCount:expected.length,correct:true},
    evidence:report,artifacts:[jsonFile('benchmark.json',report),jsonFile('values.json',input.values),
      file('unique.mjs','text/javascript',`// SPDX-License-Identifier: Apache-2.0\nexport const unique = ${selected==='set' ? "values => [...new Set(values)].sort((a,b)=>a-b)" : "values => values.slice().sort((a,b)=>a-b).filter((n,i,a)=>i===0 || n!==a[i-1])"};\n`)],
    limits:['Device/JIT/order effects can dominate small timings. This result does not establish general superiority.', 'Peak memory, monetary cost and human savings are unmeasured.']};
}

function validateDocExample(value) {
  fields(value,['operation','input','expected'],'documentation example');
  if (!['url-encode','url-decode','utf8-bytes'].includes(value.operation)) throw Error('UNSUPPORTED_SDK_OPERATION');
  if (typeof value.input!=='string' || value.input.length>4000 || typeof value.expected!=='string') throw Error('SDK_INPUT');
}
function sdk(value) {
  if(value.operation==='url-encode')return encodeURIComponent(value.input);
  if(value.operation==='url-decode')return decodeURIComponent(value.input);
  return String(new TextEncoder().encode(value.input).length);
}
async function documentation(input, checkpoint) {
  const checks=[]; let offset=0; let repaired='';
  for (const match of input.markdown.matchAll(/```successor-example\s*\n([\s\S]*?)\n```/g)) {
    await checkpoint('checking-examples');
    const value=parseBounded(match[1]); let actual=null,error=null;
    try { actual=sdk(value); } catch { error='INVALID_URI_ENCODING'; }
    checks.push({index:checks.length+1,...value,actual,error,passed:error===null&&actual===value.expected});
    repaired+=input.markdown.slice(offset,match.index)+(error ? match[0] : '```successor-example\n'+JSON.stringify({...value,expected:actual})+'\n```');
    offset=match.index+match[0].length;
  }
  repaired+=input.markdown.slice(offset);
  const failures=checks.filter(c=>!c.passed), errors=checks.filter(c=>c.error);
  return {decision:errors.length?'REPAIR_REQUIRED':failures.length?'DOCUMENTATION_CORRECTION_PROPOSED':'RETAIN_INCUMBENT',
    summary:{examples:checks.length,incorrectExamples:failures.length,invalidInputs:errors.length},evidence:{checks,contract:'URI component encoding/decoding and UTF-8 byte count; actual standard-library execution'},
    artifacts:[file('original-examples.md','text/markdown',input.markdown),file('checked-examples.md','text/markdown',repaired),jsonFile('example-checks.json',checks)],
    limits:['Only the named SDK operations run. Markdown outside the example blocks remains inert.', 'Proposed expected-value corrections require review; original failures remain in the evidence.']};
}

function readRows(csv) {
  const lines=[]; let row=[],cell='',quoted=false,closed=false;
  for(let i=0;i<csv.length;i++) {
    const ch=csv[i];
    if(quoted){if(ch==='"'){if(csv[i+1]==='"'){cell+='"';i++;}else{quoted=false;closed=true;}}else cell+=ch;}
    else if(ch==='"'&&!cell&&!closed)quoted=true;
    else if(ch===','){row.push(cell);cell='';closed=false;}
    else if(ch==='\n'||ch==='\r'){if(ch==='\r'&&csv[i+1]==='\n')i++;row.push(cell);lines.push(row);row=[];cell='';closed=false;}
    else{if(closed||ch==='"')throw Error('CSV_QUOTING');cell+=ch;}
    if(lines.length>2001)throw Error('CSV_ROW_LIMIT');
  }
  if(quoted)throw Error('CSV_UNCLOSED_QUOTE');
  if(row.length||cell||closed){row.push(cell);lines.push(row);}
  if(canonical(lines.shift())!==canonical(['group','amount'])||!lines.length)throw Error('CSV_HEADER: group,amount');
  return lines.map((item,index)=>{
    if(item.length!==2||!item[0].trim()||item[0].length>100||!/^[-]?(0|[1-9][0-9]{0,8})$/.test(item[1]))throw Error(`CSV_ROW: ${index+2}`);
    const amount=Number(item[1]); integer(amount,-1000000,1000000,'amount');
    return {group:item[0],amount};
  });
}
function csvCell(value) { const raw=String(value);return '"'+(/^[=+\-@\t\r]/.test(raw)?"'"+raw:raw).replaceAll('"','""')+'"'; }
async function publicData(input, checkpoint) {
  const rows=readRows(input.csv), groups=new Map();
  for(const row of rows){await checkpoint('analysing');const old=groups.get(row.group)||{group:row.group,count:0,total:0,min:row.amount,max:row.amount};old.count++;old.total+=row.amount;old.min=Math.min(old.min,row.amount);old.max=Math.max(old.max,row.amount);groups.set(row.group,old);}
  const summary=[...groups.values()].sort((a,b)=>a.group<b.group?-1:a.group>b.group?1:0);
  const total=rows.reduce((sum,row)=>sum+row.amount,0);
  if(summary.reduce((sum,row)=>sum+row.total,0)!==total)throw Error('RECONCILIATION_FAILED');
  const report='<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>SUCCESSOR data report</title><style>body{font:18px system-ui;max-width:60rem;margin:3rem auto;padding:1rem}td,th{padding:.6rem;text-align:left;border-bottom:1px solid #aaa}table{border-collapse:collapse}</style><h1>Public-data report</h1><p>'+html(rows.length)+' rows · '+html(input.unit)+' · exact total '+html(total)+'</p><table><thead><tr><th>Group</th><th>Count</th><th>Total</th><th>Minimum</th><th>Maximum</th></tr></thead><tbody>'+summary.map(row=>'<tr>'+[row.group,row.count,row.total,row.min,row.max].map(v=>'<td>'+html(v)+'</td>').join('')+'</tr>').join('')+'</tbody></table><p>Descriptive results for the supplied data only. Coverage and causal interpretation require review.</p></html>';
  return {decision:'REPORT_READY_FOR_REVIEW',summary:{rows:rows.length,groups:summary.length,total,unit:input.unit},evidence:{groups:summary,reconciled:true},
    artifacts:[file('report.html','text/html',report),file('summary.csv','text/csv','group,count,total,min,max\n'+summary.map(row=>[csvCell(row.group),row.count,row.total,row.min,row.max].join(',')).join('\n')+'\n'),jsonFile('analysis.json',{total,groups:summary})],
    limits:['Exact descriptive arithmetic does not establish population coverage or causality.', 'CSV labels are escaped against formula interpretation; the source remains in the mission specification.']};
}

function fraction(n,d=1n){if(d===0n)throw Error('ZERO_DENOMINATOR');if(d<0n){n=-n;d=-d;}let a=n<0n?-n:n,b=d;while(b){const c=a%b;a=b;b=c;}return [n/(a||1n),d/(a||1n)];}
function add(a,b){return fraction(a[0]*b[1]+b[0]*a[1],a[1]*b[1]);}
function mul(a,b){return fraction(a[0]*b[0],a[1]*b[1]);}
function abs(a){return [a[0]<0n?-a[0]:a[0],a[1]];}
function rationalText(a){return `${a[0]}/${a[1]}`;}
function polynomial(coefficients,x){let result=[0n,1n];for(const c of [...coefficients].reverse())result=add(mul(result,x),[BigInt(c),1n]);return result;}
async function numerical(input,checkpoint){
  const h=fraction(BigInt(input.upper-input.lower),BigInt(input.steps));let trap=[0n,1n],simpson=[0n,1n];
  for(let i=0;i<=input.steps;i++){await checkpoint('integrating');const y=polynomial(input.coefficients,add([BigInt(input.lower),1n],mul(h,[BigInt(i),1n])));trap=add(trap,mul(y,[i===0||i===input.steps?1n:2n,1n]));simpson=add(simpson,mul(y,[i===0||i===input.steps?1n:i%2?4n:2n,1n]));}
  trap=mul(trap,mul(h,[1n,2n]));simpson=mul(simpson,mul(h,[1n,3n]));
  let exact=[0n,1n];input.coefficients.forEach((c,i)=>{const n=BigInt(i+1);exact=add(exact,fraction(BigInt(c)*(BigInt(input.upper)**n-BigInt(input.lower)**n),n));});
  const error=value=>abs(add(value,[-exact[0],exact[1]]));const tolerance=fraction(BigInt(input.tolerancePpm),1000000n);
  const passes=value=>{const e=error(value);return e[0]*tolerance[1]<=tolerance[0]*e[1];};
  const evidence={analytic:rationalText(exact),trapezoid:rationalText(trap),simpson:rationalText(simpson),
    absoluteErrors:{trapezoid:rationalText(error(trap)),simpson:rationalText(error(simpson))},absoluteTolerance:rationalText(tolerance),
    passes:{trapezoid:passes(trap),simpson:passes(simpson)},arithmetic:'Exact reduced BigInt rational numbers; coefficients in increasing powers'};
  return {decision:passes(simpson)?'WITHIN_DECLARED_TOLERANCE':'REPAIR_REQUIRED',summary:{steps:input.steps,degree:input.coefficients.length-1,...evidence.passes},
    evidence,artifacts:[jsonFile('numerical.json',evidence),jsonFile('calculation-input.json',input)],
    limits:['This reconstructs polynomial quadrature under stated assumptions, not an arbitrary scientific paper.', 'Input uncertainty, physical-model validity and external replication are unmeasured.']};
}

const HANDLERS = {reliability,performance:performanceWork,documentation,'public-data':publicData,numerical};

async function plan(spec, now = new Date().toISOString(), adapter = null) {
  const checked=validate(spec,adapter), identity=await semanticIdentity(checked,adapter);
  const mission=missionFor({name:checked.name,budget:'1',now});
  mission.missionId='work-'+identity.slice(0,24); mission.title=checked.name;
  mission.objective=(adapter?.manifest || REGISTRY.find(item=>item.id===checked.family)).scope;
  mission.budget.limitBaseUnits='0';mission.budget.maxJobs=7;
  mission.proofProtocol.minimumMargin=0;
  mission.allowedTools=['fixed-workbench-'+checked.family];
  mission.rights[0].dataClass=checked.rights.dataClass==='synthetic'?'synthetic':'public-licensed-nonpersonal';
  mission.rights[0].license=checked.rights.license;mission.rights[0].sourceId='mission-input';
  const proposed=createPortfolioJobs(mission), grouped=new Map();
  for(const job of proposed){if(!grouped.has(job.family))grouped.set(job.family,[]);grouped.get(job.family).push(job);}
  const jobs=[...grouped.entries()].map(([family,items])=>({...items[0],jobId:mission.missionId+':'+family,
    objective:items.map(item=>item.objective).join(' '),covers:items.flatMap(item=>item.covers),
    acceptance:{...items[0].acceptance,predicate:'Review the exact input, delivered artifacts and retained failures for: '+items.map(item=>item.objective).join(' ')}}));
  const order=['constitution','evidence','formation','challenge','verification','admission','renewal'];
  jobs.sort((a,b)=>order.indexOf(a.family)-order.indexOf(b.family));
  const edges=jobs.slice(1).map((job,i)=>({from:jobs[i].jobId,to:job.jobId,kind:'evidence'}));
  for(const edge of edges)jobs.find(job=>job.jobId===edge.to).authorizedInputs.push(edge.from);
  return compileJobs(mission,{jobs,edges,now});
}

async function run(spec, {sourceHash,signal,onProgress=()=>{},onCheckpoint=async()=>{},clock=()=>globalThis.performance.now(),adapter=null}={}) {
  const input=validate(spec,adapter);
  if(!/^[a-f0-9]{64}$/.test(sourceHash||''))throw Error('SOURCE_IDENTITY_REQUIRED');
  const started=clock();let count=0;
  const checkpoint=async phase=>{
    await onCheckpoint();
    if(signal?.aborted)throw Error('CANCELLED');
    if(clock()-started>60000)throw Error('TIME_BUDGET_EXCEEDED');
    if(count++%25===0){onProgress(phase);await new Promise(resolve=>setTimeout(resolve,0));}
  };
  await checkpoint('planning');
  const missionDigest=await semanticIdentity(input,adapter), createdAt=new Date().toISOString();
  const frozen={schema:VERSION,missionDigest,sourceHash,adapter:input.family,adapterVersion:adapter?.manifest.version || 1,
    model:null,provider:null,authority:[],inputPolicy:input.rights,reviewMinutes:input.reviewMinutes};
  const releaseDigest=await digest('workbench-release',frozen);
  const compilation=await plan(input,createdAt,adapter);
  const result=await (adapter?.execute || HANDLERS[input.family])(input.inputs,checkpoint);
  fields(result,['decision','summary','evidence','artifacts','limits'],'adapter output');
  text(result.decision,128,'decision');
  if(!Array.isArray(result.artifacts)||result.artifacts.length<1||result.artifacts.length>12)throw Error('ARTIFACT_COUNT');
  await checkpoint('verifying');
  const artifacts=await Promise.all(result.artifacts.map(async artifact=>({...artifact,digest:await digest('workbench-artifact',artifact)})));
  const body={schema:VERSION,spec:input,createdAt,frozen,releaseDigest,compilation,result:{...result,artifacts},
    economics:{elapsedMilliseconds:Math.max(0,Math.round(clock()-started)),providerSpendBaseUnits:'0',settlementSpendBaseUnits:'0',
      computeCost:null,humanMinutes:null,reviewCapacityMinutes:input.reviewMinutes,allowanceIs:'UNFUNDED'},
    evaluation:{scope:'PUBLIC_LOCAL_EXECUTION',independentProof:false,admission:'HOLD',authority:[],settlement:'NOT_CONNECTED'},
    chronicle:[{kind:'local-result',decision:result.decision,missionDigest,releaseDigest,inheritedProof:false,inheritedAuthority:false}]};
  const pack={...body,integrityDigest:await digest('workbench-pack',body)};
  await inspectPack(pack,adapter);
  return pack;
}

async function inspectPack(value, adapter = null) {
  fields(value,['schema','spec','createdAt','frozen','releaseDigest','compilation','result','economics','evaluation','chronicle','integrityDigest'],'pack');
  validate(value.spec,adapter);
  const {integrityDigest,...body}=value;
  if(integrityDigest!==await digest('workbench-pack',body))throw Error('PACK_INTEGRITY');
  if(value.frozen.missionDigest!==await semanticIdentity(value.spec,adapter)||value.releaseDigest!==await digest('workbench-release',value.frozen))throw Error('PACK_BINDING');
  if(!Array.isArray(value.result.artifacts)||value.result.artifacts.length>12)throw Error('PACK_ARTIFACTS');
  for(const artifact of value.result.artifacts){fields(artifact,['name','type','content','digest'],'artifact');
    if(['mission.json','evidence.json','READ_ME.txt','lifecycle.json','signed-receipt.json','source-key.txt'].includes(artifact.name)||
       /^(con|prn|aux|nul|com[0-9]|lpt[0-9])(\.|$)/i.test(artifact.name)||artifact.name.endsWith('.'))throw Error('RESERVED_ARTIFACT_NAME');
    if(!/^[A-Za-z0-9][A-Za-z0-9_.-]{0,79}$/.test(artifact.name)||!['text/javascript','text/plain','text/csv','text/html','text/markdown','application/json'].includes(artifact.type)||typeof artifact.content!=='string'||artifact.content.length>200000)throw Error('ARTIFACT_POLICY');
    const {digest:hash,...content}=artifact;if(hash!==await digest('workbench-artifact',content))throw Error('ARTIFACT_INTEGRITY');}
  if(new Set(value.result.artifacts.map(item=>item.name)).size!==value.result.artifacts.length)throw Error('DUPLICATE_ARTIFACT');
  if(canonical(value.compilation)!==canonical(await plan(value.spec,value.createdAt,adapter)))throw Error('JOB_BINDING');
  return {spec:clone(value.spec),history:{missionDigest:value.frozen.missionDigest,releaseDigest:value.releaseDigest,decision:value.result.decision},
    authentication:'UNAUTHENTICATED_HISTORICAL_IMPORT',activeProof:[],activeAuthority:[]};
}

function createWorkbench(adapters = []) {
  const installed = new Map();
  for(const adapter of adapters){
    fields(adapter,['manifest','validate','execute'],'installed adapter');
    const manifest=adapter.manifest;
    fields(manifest,['id','version','en','fr','scope','artifact'],'adapter manifest');
    if(!/^[a-z][a-z0-9-]{1,47}$/.test(manifest.id)||REGISTRY.some(item=>item.id===manifest.id)||installed.has(manifest.id))throw Error('ADAPTER_ID');
    integer(manifest.version,1,1000000,'adapter version');
    for(const key of ['en','fr','scope','artifact'])text(manifest[key],1000,key);
    if(typeof adapter.validate!=='function'||typeof adapter.execute!=='function')throw Error('ADAPTER_INTERFACE');
    installed.set(manifest.id,Object.freeze({...adapter,manifest:Object.freeze(clone(manifest))}));
  }
  const resolve=spec=>installed.get(spec.family)||null;
  return Object.freeze({registry:Object.freeze([...REGISTRY,...[...installed.values()].map(item=>item.manifest)]),
    validate:spec=>validate(spec,resolve(spec)),
    run:(spec,options)=>run(spec,{...options,adapter:resolve(spec)}),
    plan:(spec,now)=>plan(spec,now,resolve(spec)),
    inspectPack:pack=>inspectPack(pack,resolve(pack.spec))});
}

return {VERSION,REGISTRY,example,validate,semanticIdentity,plan,run,inspectPack,createWorkbench};
})();
__modules["implementation/adapters.mjs"] = (() => {
// SPDX-License-Identifier: Apache-2.0
const strictInt=(v,min,max,label)=>{if(!Number.isSafeInteger(v)||v<min||v>max)throw Error('INVALID_'+label);return v;};
const txt=(v,label,max=300)=>{if(typeof v!=='string'||!v.trim()||v.length>max)throw Error('INVALID_'+label);return v;};
const artifact=(name,type,content)=>({name,type,content});
const jsonArtifact=(name,value)=>artifact(name,'application/json',JSON.stringify(value,null,2)+'\n');
const safeCell=v=>'"'+(/^[=+\-@\t\r]/.test(String(v))?"'":'')+String(v).replaceAll('"','""')+'"';
function normalizeQuotes(input){
  txt(input.title,'TITLE');txt(input.base_currency,'BASE_CURRENCY',3);strictInt(input.deadline_days,0,365,'DEADLINE');
  if(!Array.isArray(input.items)||input.items.length<1||input.items.length>18)throw Error('ITEM_LIMIT');
  if(!Array.isArray(input.offers)||input.offers.length<1||input.offers.length>160)throw Error('OFFER_LIMIT');
  const items=input.items.map(i=>({id:txt(i.id,'ITEM_ID',60),label:txt(i.label,'ITEM_LABEL'),quantity:strictInt(i.quantity,1,10000,'QUANTITY')}));
  if(new Set(items.map(i=>i.id)).size!==items.length)throw Error('DUPLICATE_ITEM_ID');
  const vendors=Object.keys(input.shipping_minor||{}).sort();if(!vendors.length||vendors.length>12)throw Error('VENDOR_LIMIT');
  vendors.forEach(v=>strictInt(input.shipping_minor[v],0,100000000,'SHIPPING'));
  const excluded=[];
  const offers=input.offers.map((o,index)=>{
    const item=items.find(i=>i.id===o.item);if(!item)throw Error('UNKNOWN_ITEM');if(!vendors.includes(o.vendor))throw Error('UNKNOWN_VENDOR');
    strictInt(o.pack_units,1,10000,'PACK_UNITS');strictInt(o.pack_price_minor,0,100000000,'PRICE');strictInt(o.lead_days,0,365,'LEAD');
    const rate=input.fx?.[o.currency];if(!rate)throw Error('MISSING_FX_'+o.currency);
    strictInt(rate.num,1,1000000,'FX_NUM');strictInt(rate.den,1,1000000,'FX_DEN');txt(rate.source,'FX_SOURCE',500);
    const packs=Math.ceil(item.quantity/o.pack_units),n=BigInt(packs)*BigInt(o.pack_price_minor)*BigInt(rate.num),d=BigInt(rate.den);
    const cost=Number((2n*n+d)/(2n*d));strictInt(cost,0,1000000000000,'LINE_COST');
    const row={index,item:item.id,label:item.label,vendor:o.vendor,quantity:item.quantity,pack_units:o.pack_units,packs,delivered_units:packs*o.pack_units,source_currency:o.currency,source_pack_price_minor:o.pack_price_minor,landed_line_minor:cost,lead_days:o.lead_days,fx_source:rate.source};
    if(o.lead_days>input.deadline_days){excluded.push({...row,reason:'DELIVERY_DEADLINE'});return null;}return row;
  }).filter(Boolean);
  for(const i of items)if(!offers.some(o=>o.item===i.id))throw Error('NO_ELIGIBLE_OFFER_'+i.id);
  return {title:input.title,base_currency:input.base_currency,deadline_days:input.deadline_days,items,vendors,shipping:input.shipping_minor,offers,excluded};
}
function subsetSolve(n){
  let best=null,visited=0;
  for(let mask=1;mask<(1<<n.vendors.length);mask++){
    const permitted=new Set(n.vendors.filter((v,k)=>(mask&(1<<k))!==0)),selected=[];visited++;
    for(const item of n.items){const choices=n.offers.filter(o=>o.item===item.id&&permitted.has(o.vendor)).sort((a,b)=>a.landed_line_minor-b.landed_line_minor||a.index-b.index);if(!choices.length)break;selected.push(choices[0]);}
    if(selected.length!==n.items.length)continue;
    const used=[...new Set(selected.map(o=>o.vendor))].sort(),shipping=used.reduce((s,v)=>s+n.shipping[v],0),lines=selected.reduce((s,o)=>s+o.landed_line_minor,0),total=lines+shipping;
    if(!best||total<best.total_minor)best={total_minor:total,line_total_minor:lines,shipping_minor:shipping,selected,used_vendors:used};
  }
  if(!best)throw Error('INFEASIBLE');return {...best,algorithm:'exact-vendor-subset',states_visited:visited};
}
function enumerationSolve(n,budget=50000){
  const choices=n.items.map(i=>n.offers.filter(o=>o.item===i.id));const size=choices.reduce((v,c)=>v*c.length,1);
  if(size>budget)return {decision:'BUDGET_REFUSAL',combinations:size,budget};
  let best=null,visited=0;
  function walk(i,selected){if(i<choices.length){for(const o of choices[i])walk(i+1,[...selected,o]);return;}visited++;const used=[...new Set(selected.map(o=>o.vendor))],shipping=used.reduce((s,v)=>s+n.shipping[v],0),lines=selected.reduce((s,o)=>s+o.landed_line_minor,0),total=lines+shipping;if(!best||total<best.total_minor)best={total_minor:total,selected,used_vendors:used.sort()};}
  walk(0,[]);return {...best,algorithm:'exhaustive-cart',states_visited:visited};
}
async function quoteExecute(input,checkpoint){
  await checkpoint('normalizing-quotes');const n=normalizeQuotes(input);const result=subsetSolve(n);await checkpoint('checking-cart');
  const checks={one_offer_per_item:new Set(result.selected.map(o=>o.item)).size===n.items.length,quantities:result.selected.every(o=>o.delivered_units>=o.quantity),deadlines:result.selected.every(o=>o.lead_days<=n.deadline_days),exact_arithmetic:result.total_minor===result.line_total_minor+result.shipping_minor};
  if(!Object.values(checks).every(Boolean))throw Error('QUOTE_VERIFICATION');
  const cash=v=>(v/100).toFixed(2)+' '+n.base_currency;
  const rows=result.selected.map(o=>[o.label,o.vendor,o.quantity,o.delivered_units,o.packs,cash(o.landed_line_minor),o.lead_days]);
  const report='# '+n.title+'\n\n## Decision-ready quote comparison\n\nRecommended eligible cart: **'+cash(result.total_minor)+'**, including '+cash(result.shipping_minor)+' of fixed supplier shipping. No purchase was made.\n\n| Item | Supplier | Required units | Delivered units | Packs | Line cost | Delivery days |\n|---|---|---:|---:|---:|---:|---:|\n'+rows.map(r=>'| '+r.join(' | ')+' |').join('\n')+'\n\n## Verification and limits\n\nAll quantities, the delivery deadline and exact integer-currency totals pass the declared contract. The optimizer enumerates '+result.states_visited+' supplier subsets. '+n.excluded.length+' late offers were excluded.\n\nPrices, supplier names and exchange ratios in the included example are synthetic. For your own permitted quotes, the result is conditional on complete input prices, declared rates and fixed shipping. Taxes, uncertain inventory, quality differences, discounts and split-item purchases are outside this contract.\n';
  const csv='item,supplier,required_units,delivered_units,packs,line_cost,delivery_days\n'+rows.map(r=>r.map(safeCell).join(',')).join('\n')+'\n';
  return {decision:'QUOTE_REPORT_READY_FOR_REVIEW',summary:{items:n.items.length,offers:n.offers.length,total_minor:result.total_minor,currency:n.base_currency,excluded:n.excluded.length},evidence:{normalized:n,solution:result,checks,execution:'fresh local deterministic computation'},artifacts:[artifact('quote-report.md','text/markdown',report),artifact('recommended-cart.csv','text/csv',csv),jsonArtifact('quote-analysis.json',{normalized:n,solution:result,checks})],limits:['Synthetic examples do not establish realized customer savings or supplier availability.','Finite fixed-shipping model; no purchase or payment route executes.','A separate conventional MILP incumbent checks the confirmation optimum; in-browser computation alone does not rerun that incumbent.']};
}
function validateBrief(input){
  txt(input.title,'TITLE');if(!Array.isArray(input.facts)||!input.facts.length||input.facts.length>30)throw Error('FACT_LIMIT');
  if(!Array.isArray(input.questions)||!input.questions.length||input.questions.length>30)throw Error('QUESTION_LIMIT');
  const seen=new Map();for(const f of input.facts){txt(f.id,'FACT_ID');txt(f.occupation,'OCCUPATION');txt(f.measure,'MEASURE');txt(f.geography,'GEOGRAPHY');txt(f.currency,'CURRENCY');txt(f.coverage,'COVERAGE',1000);txt(f.source_url,'SOURCE_URL',2000);txt(f.source_year,'SOURCE_YEAR');txt(f.retrieved_at,'RETRIEVED');
    let u;try{u=new URL(f.source_url);}catch{throw Error('INVALID_SOURCE_URL');}if(u.protocol!=='https:'||!(u.hostname==='bls.gov'||u.hostname.endsWith('.bls.gov')))throw Error('SOURCE_HOST_NOT_ALLOWED');
    if(typeof f.value!=='string'||!/^\d+(?:\.\d+)?$/.test(f.value)||!Number.isFinite(Number(f.value)))throw Error('FACT_VALUE');if(seen.has(f.id)&&JSON.stringify(seen.get(f.id))!==JSON.stringify(f))throw Error('CONFLICTING_SOURCE_FACT');seen.set(f.id,f);
  }for(const id of input.questions)if(!seen.has(id))throw Error('MISSING_REQUESTED_FACT_'+id);
}
async function briefExecute(input,checkpoint){
  validateBrief(input);await checkpoint('checking-evidence-register');const facts=input.questions.map(id=>input.facts.find(f=>f.id===id));
  const rows=facts.map(f=>`| ${f.occupation} | ${f.measure} | ${Number(f.value).toLocaleString('en-US',{maximumFractionDigits:2})} ${f.currency} | ${f.source_year} | [${f.id}](${f.source_url}) |`);
  const brief='# '+input.title+'\n\n## Verified-input evidence brief\n\nThis briefing transforms a supplied, researched source register. It does not perform a new web search or model-authored synthesis.\n\n| Occupation/group | Measure | Value | Source period | Source |\n|---|---|---:|---|---|\n'+rows.join('\n')+'\n\n## Interpretation\n\n'+facts.map(f=>'- '+f.occupation+': '+f.measure+' is '+Number(f.value).toLocaleString('en-US')+' '+f.currency+' for '+f.geography+' ('+f.source_year+'). Coverage: '+f.coverage+' [Source]('+f.source_url+').').join('\n')+'\n\nThese sources describe labor-market compensation. They do not establish task duration, deliverable quality, a non-AI worker sample, attainable customer prices or realized savings. Mixing occupation-specific wages with broad occupational benefit groups requires an explicit allocation assumption.\n\n## Source provenance\n\n'+facts.map(f=>'- '+f.id+': retrieved '+f.retrieved_at+'; '+f.source_url).join('\n')+'\n';
  return {decision:'EVIDENCE_BRIEF_READY_FOR_REVIEW',summary:{facts:facts.length,sources:new Set(facts.map(f=>f.source_url)).size},evidence:{facts,requested:input.questions,all_requested_present:true,live_retrieval:false},artifacts:[artifact('evidence-brief.md','text/markdown',brief),jsonArtifact('source-register.json',facts)],limits:['Source correspondence to the fetched public pages is checked in the study source audit, not by this offline template.','This is structured factual document production, not evidence of open-ended autonomous research or original writing.']};
}
function validatePlan(input){
  txt(input.title,'TITLE');strictInt(input.deadline_minutes,1,100000,'DEADLINE');if(!Array.isArray(input.tasks)||!input.tasks.length||input.tasks.length>100)throw Error('TASK_LIMIT');
  const ids=new Set(input.tasks.map(t=>t.id));if(ids.size!==input.tasks.length)throw Error('DUPLICATE_TASK');
  for(const t of input.tasks){txt(t.id,'TASK_ID');txt(t.label,'TASK_LABEL');txt(t.resource,'RESOURCE');strictInt(t.duration_minutes,1,10000,'DURATION');if(!Array.isArray(t.deps)||t.deps.some(d=>!ids.has(d)))throw Error('MISSING_DEPENDENCY');}
  const visited=new Set(),active=new Set();function walk(id){if(active.has(id))throw Error('DEPENDENCY_CYCLE');if(visited.has(id))return;active.add(id);for(const dep of input.tasks.find(t=>t.id===id).deps)walk(dep);active.delete(id);visited.add(id);}for(const id of ids)walk(id);
}
async function planExecute(input,checkpoint){
  validatePlan(input);const pending=[...input.tasks],scheduled=[],byId=new Map(),resourceFree=new Map();
  while(pending.length){await checkpoint('scheduling');const ready=pending.filter(t=>t.deps.every(d=>byId.has(d))).sort((a,b)=>a.id.localeCompare(b.id));if(!ready.length)throw Error('DEPENDENCY_CYCLE');const task=ready[0],start=Math.max(resourceFree.get(task.resource)||0,...task.deps.map(d=>byId.get(d).finish));const row={...task,start,finish:start+task.duration_minutes};scheduled.push(row);byId.set(task.id,row);resourceFree.set(task.resource,row.finish);pending.splice(pending.indexOf(task),1);}
  const makespan=Math.max(...scheduled.map(t=>t.finish));if(makespan>input.deadline_minutes)throw Error('DEADLINE_INFEASIBLE_FOR_DECLARED_POLICY');
  const checks={all_tasks:scheduled.length===input.tasks.length,precedence:scheduled.every(t=>t.deps.every(d=>byId.get(d).finish<=t.start)),resources:scheduled.every((t,i)=>scheduled.slice(i+1).every(u=>u.resource!==t.resource||u.finish<=t.start||t.finish<=u.start))};if(!Object.values(checks).every(Boolean))throw Error('PLAN_VERIFICATION');
  const report='# '+input.title+'\n\n## Executable preparation plan\n\nThe declared tasks fit within **'+makespan+' planned minutes** and the '+input.deadline_minutes+' minute deadline. Durations are supplied planning estimates, not measured human time.\n\n| Task | Role/resource | Start | Finish | Predecessors |\n|---|---|---:|---:|---|\n'+scheduled.map(t=>'| '+t.label+' | '+t.resource+' | '+t.start+' | '+t.finish+' | '+(t.deps.join(', ')||'None')+' |').join('\n')+'\n\nAll precedence and single-capacity resource constraints pass. The deterministic list schedule is feasible for this input; it is not claimed globally optimal. No invitations, publishing, spending or external actions execute.\n';
  return {decision:'PLAN_READY_FOR_REVIEW',summary:{tasks:scheduled.length,makespan_minutes:makespan,deadline_minutes:input.deadline_minutes},evidence:{schedule:scheduled,checks,optimality:'NOT_CLAIMED'},artifacts:[artifact('operating-plan.md','text/markdown',report),artifact('schedule.csv','text/csv','id,resource,start,finish,dependencies\n'+scheduled.map(t=>[t.id,t.resource,t.start,t.finish,t.deps.join(';')].map(safeCell).join(',')).join('\n')+'\n'),jsonArtifact('schedule-analysis.json',{schedule:scheduled,checks})],limits:['Durations and resource availability are user assumptions; operational delivery was not observed.','The bounded list policy can reject a deadline even if another schedule exists.']};
}
const quoteAdapter={manifest:{id:'awe-quotes',version:2,en:'Compare a complete quote basket',fr:'Comparer un panier de devis',scope:'Exact fixed-shipping quote basket with explicit pack units, currency ratios and deadlines.',artifact:'quote-report.md'},validate:normalizeQuotes,execute:quoteExecute};
const briefAdapter={manifest:{id:'awe-brief',version:1,en:'Create a sourced evidence brief',fr:'Créer une note sourcée',scope:'Produce a structured brief from supplied verified BLS source records without open-ended research.',artifact:'evidence-brief.md'},validate:validateBrief,execute:briefExecute};
const planningAdapter={manifest:{id:'awe-plan',version:1,en:'Build a feasible operating plan',fr:'Construire un plan réalisable',scope:'Schedule declared tasks under dependencies and single-capacity role constraints.',artifact:'operating-plan.md'},validate:validatePlan,execute:planExecute};

return {normalizeQuotes,subsetSolve,enumerationSolve,quoteAdapter,briefAdapter,planningAdapter};
})();
__modules["demo/app.mjs"] = (() => {
// SPDX-License-Identifier: Apache-2.0
const {calculateScenario} = __modules["paper_support/demo_calculator.mjs"];
const {createWorkbench} = __modules["implementation/vendor/alpha/examples/successor-workbench/engine.mjs"];
const {parseBounded,canonical} = __modules["implementation/vendor/alpha/docs/assets/successor/engine.mjs"];
const {quoteAdapter,briefAdapter,planningAdapter,normalizeQuotes,enumerationSolve} = __modules["implementation/adapters.mjs"];
const DATA={"demo_source_hash":"5e0a8b6100b85b870bdd4658d75550b4a081a802c40b23f2c1bba6f27a4f22cc","upstream_commit":"a026e68413ab2e2d6086c758efc8abff723fdfe4","examples":{"Q1":{"schema":"successor-workbench/v1","family":"awe-quotes","name":"Meeting-room equipment cart","language":"en","owner":"AWE-2026-01-public-local","rights":{"dataClass":"synthetic","source":"AWE-2026-01 original synthetic structural fixture","license":"Apache-2.0"},"reviewMinutes":1,"inputs":{"title":"Public example: complete equipment quote comparison","base_currency":"USD","deadline_days":6,"items":[{"id":"item-01","label":"Monitor","quantity":15},{"id":"item-02","label":"Dock","quantity":11},{"id":"item-03","label":"Keyboard","quantity":12},{"id":"item-04","label":"Desk lamp","quantity":11}],"shipping_minor":{"Aster":2101,"Boreal":1596,"Cedar":1558},"fx":{"USD":{"num":1,"den":1,"source":"Synthetic identity rate"},"CAD":{"num":74,"den":100,"source":"Synthetic fixed ratio for reproducible example, not a market quote"},"EUR":{"num":108,"den":100,"source":"Synthetic fixed ratio for reproducible example, not a market quote"}},"offers":[{"item":"item-01","vendor":"Aster","pack_units":1,"pack_price_minor":11824,"currency":"USD","lead_days":2},{"item":"item-01","vendor":"Boreal","pack_units":1,"pack_price_minor":3281,"currency":"USD","lead_days":3},{"item":"item-01","vendor":"Cedar","pack_units":1,"pack_price_minor":7375,"currency":"USD","lead_days":1},{"item":"item-02","vendor":"Aster","pack_units":1,"pack_price_minor":13275,"currency":"USD","lead_days":3},{"item":"item-02","vendor":"Boreal","pack_units":1,"pack_price_minor":979,"currency":"USD","lead_days":4},{"item":"item-02","vendor":"Cedar","pack_units":1,"pack_price_minor":3797,"currency":"USD","lead_days":3},{"item":"item-03","vendor":"Aster","pack_units":1,"pack_price_minor":8833,"currency":"USD","lead_days":4},{"item":"item-03","vendor":"Boreal","pack_units":1,"pack_price_minor":2631,"currency":"USD","lead_days":1},{"item":"item-03","vendor":"Cedar","pack_units":1,"pack_price_minor":9994,"currency":"USD","lead_days":4},{"item":"item-04","vendor":"Aster","pack_units":1,"pack_price_minor":8171,"currency":"USD","lead_days":2},{"item":"item-04","vendor":"Boreal","pack_units":1,"pack_price_minor":4487,"currency":"USD","lead_days":1},{"item":"item-04","vendor":"Cedar","pack_units":1,"pack_price_minor":4506,"currency":"USD","lead_days":1}]}},"Q2":{"schema":"successor-workbench/v1","family":"awe-quotes","name":"Small lab: packs and currencies","language":"en","owner":"AWE-2026-01-public-local","rights":{"dataClass":"synthetic","source":"AWE-2026-01 original synthetic structural fixture","license":"Apache-2.0"},"reviewMinutes":1,"inputs":{"title":"Public example: complete equipment quote comparison","base_currency":"USD","deadline_days":6,"items":[{"id":"item-01","label":"Monitor","quantity":11},{"id":"item-02","label":"Dock","quantity":2},{"id":"item-03","label":"Keyboard","quantity":13},{"id":"item-04","label":"Desk lamp","quantity":2},{"id":"item-05","label":"USB hub","quantity":7},{"id":"item-06","label":"Cable pack","quantity":10}],"shipping_minor":{"Aster":1377,"Boreal":1295,"Cedar":821,"Delta":424},"fx":{"USD":{"num":1,"den":1,"source":"Synthetic identity rate"},"CAD":{"num":74,"den":100,"source":"Synthetic fixed ratio for reproducible example, not a market quote"},"EUR":{"num":108,"den":100,"source":"Synthetic fixed ratio for reproducible example, not a market quote"}},"offers":[{"item":"item-01","vendor":"Aster","pack_units":2,"pack_price_minor":16116,"currency":"USD","lead_days":1},{"item":"item-01","vendor":"Boreal","pack_units":1,"pack_price_minor":2091,"currency":"CAD","lead_days":2},{"item":"item-01","vendor":"Cedar","pack_units":2,"pack_price_minor":2857,"currency":"EUR","lead_days":2},{"item":"item-01","vendor":"Delta","pack_units":5,"pack_price_minor":3424,"currency":"USD","lead_days":3},{"item":"item-02","vendor":"Aster","pack_units":5,"pack_price_minor":17497,"currency":"USD","lead_days":2},{"item":"item-02","vendor":"Boreal","pack_units":2,"pack_price_minor":8423,"currency":"CAD","lead_days":1},{"item":"item-02","vendor":"Cedar","pack_units":5,"pack_price_minor":8096,"currency":"EUR","lead_days":4},{"item":"item-02","vendor":"Delta","pack_units":5,"pack_price_minor":3858,"currency":"USD","lead_days":1},{"item":"item-03","vendor":"Aster","pack_units":1,"pack_price_minor":12412,"currency":"USD","lead_days":4},{"item":"item-03","vendor":"Boreal","pack_units":2,"pack_price_minor":2434,"currency":"CAD","lead_days":4},{"item":"item-03","vendor":"Cedar","pack_units":2,"pack_price_minor":12214,"currency":"EUR","lead_days":3},{"item":"item-03","vendor":"Delta","pack_units":5,"pack_price_minor":3399,"currency":"USD","lead_days":3},{"item":"item-04","vendor":"Aster","pack_units":1,"pack_price_minor":15712,"currency":"USD","lead_days":1},{"item":"item-04","vendor":"Boreal","pack_units":2,"pack_price_minor":6393,"currency":"CAD","lead_days":1},{"item":"item-04","vendor":"Cedar","pack_units":5,"pack_price_minor":5156,"currency":"EUR","lead_days":1},{"item":"item-04","vendor":"Delta","pack_units":2,"pack_price_minor":15609,"currency":"USD","lead_days":1},{"item":"item-05","vendor":"Aster","pack_units":2,"pack_price_minor":9256,"currency":"USD","lead_days":1},{"item":"item-05","vendor":"Boreal","pack_units":5,"pack_price_minor":8535,"currency":"CAD","lead_days":1},{"item":"item-05","vendor":"Cedar","pack_units":5,"pack_price_minor":4095,"currency":"EUR","lead_days":4},{"item":"item-05","vendor":"Delta","pack_units":2,"pack_price_minor":17906,"currency":"USD","lead_days":2},{"item":"item-06","vendor":"Aster","pack_units":5,"pack_price_minor":5325,"currency":"USD","lead_days":1},{"item":"item-06","vendor":"Boreal","pack_units":2,"pack_price_minor":16216,"currency":"CAD","lead_days":4},{"item":"item-06","vendor":"Cedar","pack_units":5,"pack_price_minor":11673,"currency":"EUR","lead_days":1},{"item":"item-06","vendor":"Delta","pack_units":2,"pack_price_minor":6498,"currency":"USD","lead_days":2}]}},"Q4":{"schema":"successor-workbench/v1","family":"awe-quotes","name":"Fourteen-item expansion cart","language":"en","owner":"AWE-2026-01-public-local","rights":{"dataClass":"synthetic","source":"AWE-2026-01 original synthetic structural fixture","license":"Apache-2.0"},"reviewMinutes":1,"inputs":{"title":"Public example: complete equipment quote comparison","base_currency":"USD","deadline_days":6,"items":[{"id":"item-01","label":"Monitor","quantity":15},{"id":"item-02","label":"Dock","quantity":11},{"id":"item-03","label":"Keyboard","quantity":12},{"id":"item-04","label":"Desk lamp","quantity":5},{"id":"item-05","label":"USB hub","quantity":9},{"id":"item-06","label":"Cable pack","quantity":3},{"id":"item-07","label":"Webcam","quantity":10},{"id":"item-08","label":"Headset","quantity":5},{"id":"item-09","label":"Stand","quantity":6},{"id":"item-10","label":"Adapter","quantity":12},{"id":"item-11","label":"Network switch","quantity":3},{"id":"item-12","label":"Storage drive","quantity":3},{"id":"item-13","label":"Microphone","quantity":5},{"id":"item-14","label":"Router","quantity":4}],"shipping_minor":{"Aster":1605,"Boreal":1693,"Cedar":1233,"Delta":861},"fx":{"USD":{"num":1,"den":1,"source":"Synthetic identity rate"},"CAD":{"num":74,"den":100,"source":"Synthetic fixed ratio for reproducible example, not a market quote"},"EUR":{"num":108,"den":100,"source":"Synthetic fixed ratio for reproducible example, not a market quote"}},"offers":[{"item":"item-01","vendor":"Aster","pack_units":1,"pack_price_minor":3298,"currency":"USD","lead_days":1},{"item":"item-01","vendor":"Boreal","pack_units":1,"pack_price_minor":14509,"currency":"CAD","lead_days":4},{"item":"item-01","vendor":"Cedar","pack_units":1,"pack_price_minor":15757,"currency":"EUR","lead_days":4},{"item":"item-01","vendor":"Delta","pack_units":5,"pack_price_minor":15433,"currency":"USD","lead_days":1},{"item":"item-02","vendor":"Aster","pack_units":2,"pack_price_minor":3154,"currency":"USD","lead_days":4},{"item":"item-02","vendor":"Boreal","pack_units":1,"pack_price_minor":3578,"currency":"CAD","lead_days":4},{"item":"item-02","vendor":"Cedar","pack_units":5,"pack_price_minor":9027,"currency":"EUR","lead_days":1},{"item":"item-02","vendor":"Delta","pack_units":2,"pack_price_minor":12857,"currency":"USD","lead_days":1},{"item":"item-03","vendor":"Aster","pack_units":5,"pack_price_minor":4398,"currency":"USD","lead_days":2},{"item":"item-03","vendor":"Boreal","pack_units":5,"pack_price_minor":9282,"currency":"CAD","lead_days":4},{"item":"item-03","vendor":"Cedar","pack_units":2,"pack_price_minor":14458,"currency":"EUR","lead_days":2},{"item":"item-03","vendor":"Delta","pack_units":1,"pack_price_minor":10136,"currency":"USD","lead_days":3},{"item":"item-04","vendor":"Aster","pack_units":1,"pack_price_minor":10007,"currency":"USD","lead_days":2},{"item":"item-04","vendor":"Boreal","pack_units":1,"pack_price_minor":12609,"currency":"CAD","lead_days":4},{"item":"item-04","vendor":"Cedar","pack_units":2,"pack_price_minor":17671,"currency":"EUR","lead_days":4},{"item":"item-04","vendor":"Delta","pack_units":2,"pack_price_minor":11749,"currency":"USD","lead_days":2},{"item":"item-05","vendor":"Aster","pack_units":1,"pack_price_minor":4246,"currency":"USD","lead_days":3},{"item":"item-05","vendor":"Boreal","pack_units":5,"pack_price_minor":17399,"currency":"CAD","lead_days":4},{"item":"item-05","vendor":"Cedar","pack_units":1,"pack_price_minor":5628,"currency":"EUR","lead_days":1},{"item":"item-05","vendor":"Delta","pack_units":1,"pack_price_minor":10877,"currency":"USD","lead_days":2},{"item":"item-06","vendor":"Aster","pack_units":2,"pack_price_minor":5228,"currency":"USD","lead_days":4},{"item":"item-06","vendor":"Boreal","pack_units":5,"pack_price_minor":6342,"currency":"CAD","lead_days":2},{"item":"item-06","vendor":"Cedar","pack_units":5,"pack_price_minor":8016,"currency":"EUR","lead_days":2},{"item":"item-06","vendor":"Delta","pack_units":5,"pack_price_minor":11417,"currency":"USD","lead_days":3},{"item":"item-07","vendor":"Aster","pack_units":1,"pack_price_minor":4356,"currency":"USD","lead_days":4},{"item":"item-07","vendor":"Boreal","pack_units":1,"pack_price_minor":15589,"currency":"CAD","lead_days":4},{"item":"item-07","vendor":"Cedar","pack_units":2,"pack_price_minor":15189,"currency":"EUR","lead_days":4},{"item":"item-07","vendor":"Delta","pack_units":1,"pack_price_minor":13408,"currency":"USD","lead_days":2},{"item":"item-08","vendor":"Aster","pack_units":5,"pack_price_minor":1379,"currency":"USD","lead_days":3},{"item":"item-08","vendor":"Boreal","pack_units":2,"pack_price_minor":8210,"currency":"CAD","lead_days":3},{"item":"item-08","vendor":"Cedar","pack_units":5,"pack_price_minor":5622,"currency":"EUR","lead_days":1},{"item":"item-08","vendor":"Delta","pack_units":2,"pack_price_minor":5925,"currency":"USD","lead_days":4},{"item":"item-09","vendor":"Aster","pack_units":5,"pack_price_minor":11831,"currency":"USD","lead_days":1},{"item":"item-09","vendor":"Boreal","pack_units":2,"pack_price_minor":16206,"currency":"CAD","lead_days":4},{"item":"item-09","vendor":"Cedar","pack_units":5,"pack_price_minor":17455,"currency":"EUR","lead_days":4},{"item":"item-09","vendor":"Delta","pack_units":5,"pack_price_minor":12582,"currency":"USD","lead_days":2},{"item":"item-10","vendor":"Aster","pack_units":5,"pack_price_minor":12856,"currency":"USD","lead_days":2},{"item":"item-10","vendor":"Boreal","pack_units":2,"pack_price_minor":12415,"currency":"CAD","lead_days":1},{"item":"item-10","vendor":"Cedar","pack_units":2,"pack_price_minor":3037,"currency":"EUR","lead_days":4},{"item":"item-10","vendor":"Delta","pack_units":1,"pack_price_minor":8477,"currency":"USD","lead_days":4},{"item":"item-11","vendor":"Aster","pack_units":1,"pack_price_minor":3474,"currency":"USD","lead_days":4},{"item":"item-11","vendor":"Boreal","pack_units":2,"pack_price_minor":14511,"currency":"CAD","lead_days":1},{"item":"item-11","vendor":"Cedar","pack_units":5,"pack_price_minor":17505,"currency":"EUR","lead_days":3},{"item":"item-11","vendor":"Delta","pack_units":1,"pack_price_minor":11035,"currency":"USD","lead_days":3},{"item":"item-12","vendor":"Aster","pack_units":5,"pack_price_minor":2861,"currency":"USD","lead_days":3},{"item":"item-12","vendor":"Boreal","pack_units":5,"pack_price_minor":3386,"currency":"CAD","lead_days":2},{"item":"item-12","vendor":"Cedar","pack_units":2,"pack_price_minor":10549,"currency":"EUR","lead_days":2},{"item":"item-12","vendor":"Delta","pack_units":2,"pack_price_minor":15064,"currency":"USD","lead_days":3},{"item":"item-13","vendor":"Aster","pack_units":1,"pack_price_minor":16586,"currency":"USD","lead_days":1},{"item":"item-13","vendor":"Boreal","pack_units":1,"pack_price_minor":3178,"currency":"CAD","lead_days":1},{"item":"item-13","vendor":"Cedar","pack_units":1,"pack_price_minor":7207,"currency":"EUR","lead_days":1},{"item":"item-13","vendor":"Delta","pack_units":5,"pack_price_minor":7683,"currency":"USD","lead_days":3},{"item":"item-14","vendor":"Aster","pack_units":2,"pack_price_minor":2599,"currency":"USD","lead_days":1},{"item":"item-14","vendor":"Boreal","pack_units":1,"pack_price_minor":12094,"currency":"CAD","lead_days":2},{"item":"item-14","vendor":"Cedar","pack_units":1,"pack_price_minor":1369,"currency":"EUR","lead_days":2},{"item":"item-14","vendor":"Delta","pack_units":1,"pack_price_minor":2569,"currency":"USD","lead_days":2}]}}},"economics":{"study_id":"AWE-2026-01","schema":"awe-study-demo-economics/v1","input_sha256":{"sources.json":"c1186086faa57ebd3f498b9d950344e022c4569062794789c1b0532848fde99f","scenario_parameters.json":"39da84755804713eae96f8df3c719ab7278ab8cb69913e3cb31c775298d66e2e","economics_protocol.json":"902c883381c62b888736b431453caeeae5ddf3ac4bd463da062608a309027861","results/economic_results.json":"059873d57db82390e6c513e05a27a39b2e77e18a4c6a23f57abeecf246ea1226","automated_upkeep_protocol.json":"7dacc92e4e0046cbcc506f6f60a4b5f2f035775dce5fd22d17e09995c76531bd","automated_upkeep_clarification_v1_1.json":"0ddc845155aee134cdd45d8714bb73c0ed4836fb4a827897bb44bbdea089e69b","results/automated_upkeep_results.json":"b03807d825568abbcfe9059f2e655efbbe2a70f15aab032ca16bb7d22d13d742"},"status":"SCENARIO_LOOKUP_AND_FRESH_ARITHMETIC_NOT_OBSERVED_PRICES_OR_COSTS","currency":"USD","default_route":"modeled_tool_delivery","default_configuration":"original_upkeep","volume_basis":"Total attempted portfolio jobs/month; four families at 25% each. Quote unit cost uses a share of fixed costs allocated across that portfolio.","portfolio_family_weights":{"quotes":0.25,"brief":0.25,"plan":0.25,"software":0.25},"labels":{"modeled_tool_delivery":{"en":"Hypothetical hosted tool delivery","fr":"Livraison outillée avec hébergement hypothétique"},"modeled_model_extension":{"en":"Proposed model extension — NOT RUN","fr":"Extension proposée avec modèles — NON EXÉCUTÉE"},"actual_local_total_cost":{"en":"Actual local total cost: unknown","fr":"Coût total local réel : inconnu"},"arithmetic":{"en":"Fresh arithmetic using scenario assumptions","fr":"Nouveau calcul utilisant les hypothèses du scénario"}},"scenarios":{"efficient":{"model_token_multiplier":0.5,"extension_retry_probability":0.05,"extension_final_acceptance_probability":0.98,"tool_retry_probability":0.01,"tool_final_acceptance_probability":0.995,"normal_exception_probability":0.01,"normal_exception_minutes":8,"rare_exception_probability":0.001,"rare_exception_minutes":60,"shared_platform_archive_usd_per_month":20,"maintenance_hours_per_month":2,"business_admin_hours_per_month":2,"setup_development_hours":24,"common_shock_month_probability":0.02,"shock_extra_retry_probability":0.1,"shock_acceptance_retention":0.9,"shock_recovery_hours":2,"collection_fraction":0.99,"refund_fraction":0.01,"collection_delay_months":0,"customer_incremental_minutes":0},"reference":{"model_token_multiplier":1,"extension_retry_probability":0.2,"extension_final_acceptance_probability":0.9,"tool_retry_probability":0.05,"tool_final_acceptance_probability":0.98,"normal_exception_probability":0.05,"normal_exception_minutes":15,"rare_exception_probability":0.005,"rare_exception_minutes":180,"shared_platform_archive_usd_per_month":50,"maintenance_hours_per_month":8,"business_admin_hours_per_month":4,"setup_development_hours":64,"common_shock_month_probability":0.05,"shock_extra_retry_probability":0.2,"shock_acceptance_retention":0.8,"shock_recovery_hours":8,"collection_fraction":0.95,"refund_fraction":0.03,"collection_delay_months":1,"customer_incremental_minutes":3},"stress":{"model_token_multiplier":4,"extension_retry_probability":0.5,"extension_final_acceptance_probability":0.65,"tool_retry_probability":0.15,"tool_final_acceptance_probability":0.9,"normal_exception_probability":0.2,"normal_exception_minutes":45,"rare_exception_probability":0.02,"rare_exception_minutes":480,"shared_platform_archive_usd_per_month":200,"maintenance_hours_per_month":24,"business_admin_hours_per_month":8,"setup_development_hours":160,"common_shock_month_probability":0.2,"shock_extra_retry_probability":0.3,"shock_acceptance_retention":0.6,"shock_recovery_hours":24,"collection_fraction":0.8,"refund_fraction":0.1,"collection_delay_months":2,"customer_incremental_minutes":10}},"fees":{"fraction":0.03,"fixed_usd_per_collected_invoice":0.3},"customer_hourly_proxy_usd":46.89,"quote_unit_rows":[{"family":"quotes","family_name":"Quote comparison packet","scenario":"efficient","route":"modeled_tool_delivery","attempts_per_month":100,"expected_accepted_per_month":99.30099999999999,"assumed_final_acceptance_in_normal_month":0.995,"assumed_expected_acceptance":0.99301,"estimated_base_input_tokens":0,"estimated_base_billable_output_tokens":0,"modeled_attempts_per_requested_job":1.012,"marginal_execution_usd_per_accepted":0.03057371023453943,"recurring_delivery_usd_per_accepted":3.2280308536742446,"fully_loaded_pretax_usd_per_accepted":5.131430635805323,"adverse_month_fully_loaded_usd_per_accepted":7.761915190353932,"components_usd_per_accepted":{"model_tokens":0.0,"runtime":0.03057371023453943,"search":0.0,"normal_exceptions":0.06296009103634405,"rare_exceptions":0.04722006827725804,"platform_archive":0.20140784080724264,"maintenance":1.903399782131078,"business_administration":0.9444013655451607,"common_shock_recovery":0.03806799564262156,"setup_amortization":1.903399782131078},"setup_total_usd":2268.114021184778,"median_wage_hourly_usd":24.32,"estimated_employer_hourly_usd":35.41925455987312,"break_even_human_minutes_wage_only":12.659779529124975,"break_even_human_minutes_employer_proxy":8.692612026260056,"break_even_human_minutes_wage_with_extra_attention":12.659779529124975,"pretax_customer_price_floor_usd_including_modeled_noncollection_refund_fees":5.711732571343985,"interpretation":"Scenario calculation, not observed total cost or evidence of matched human productivity."},{"family":"quotes","family_name":"Quote comparison packet","scenario":"efficient","route":"modeled_tool_delivery","attempts_per_month":1000,"expected_accepted_per_month":993.01,"assumed_final_acceptance_in_normal_month":0.995,"assumed_expected_acceptance":0.99301,"estimated_base_input_tokens":0,"estimated_base_billable_output_tokens":0,"modeled_attempts_per_requested_job":1.012,"marginal_execution_usd_per_accepted":0.03057371023453943,"recurring_delivery_usd_per_accepted":0.44948156796075184,"fully_loaded_pretax_usd_per_accepted":0.6398215461738597,"adverse_month_fully_loaded_usd_per_accepted":0.919618654713785,"components_usd_per_accepted":{"model_tokens":0.0,"runtime":0.03057371023453943,"search":0.0,"normal_exceptions":0.06296009103634405,"rare_exceptions":0.04722006827725804,"platform_archive":0.020140784080724262,"maintenance":0.1903399782131078,"business_administration":0.09444013655451608,"common_shock_recovery":0.003806799564262156,"setup_amortization":0.1903399782131078},"setup_total_usd":2268.114021184778,"median_wage_hourly_usd":24.32,"estimated_employer_hourly_usd":35.41925455987312,"break_even_human_minutes_wage_only":1.578507104047351,"break_even_human_minutes_employer_proxy":1.0838537752266322,"break_even_human_minutes_wage_with_extra_attention":1.578507104047351,"pretax_customer_price_floor_usd_including_modeled_noncollection_refund_fees":0.9857129063277144,"interpretation":"Scenario calculation, not observed total cost or evidence of matched human productivity."},{"family":"quotes","family_name":"Quote comparison packet","scenario":"efficient","route":"modeled_tool_delivery","attempts_per_month":10000,"expected_accepted_per_month":9930.1,"assumed_final_acceptance_in_normal_month":0.995,"assumed_expected_acceptance":0.99301,"estimated_base_input_tokens":0,"estimated_base_billable_output_tokens":0,"modeled_attempts_per_requested_job":1.012,"marginal_execution_usd_per_accepted":0.03057371023453943,"recurring_delivery_usd_per_accepted":0.17162663938940254,"fully_loaded_pretax_usd_per_accepted":0.1906606372107133,"adverse_month_fully_loaded_usd_per_accepted":0.23538900114977046,"components_usd_per_accepted":{"model_tokens":0.0,"runtime":0.03057371023453943,"search":0.0,"normal_exceptions":0.06296009103634405,"rare_exceptions":0.04722006827725804,"platform_archive":0.0020140784080724264,"maintenance":0.01903399782131078,"business_administration":0.009444013655451607,"common_shock_recovery":0.0003806799564262156,"setup_amortization":0.019033997821310777},"setup_total_usd":2268.114021184778,"median_wage_hourly_usd":24.32,"estimated_employer_hourly_usd":35.41925455987312,"break_even_human_minutes_wage_only":0.4703798615395887,"break_even_human_minutes_employer_proxy":0.3229779501232896,"break_even_human_minutes_wage_with_extra_attention":0.4703798615395887,"pretax_customer_price_floor_usd_including_modeled_noncollection_refund_fees":0.5131109398260872,"interpretation":"Scenario calculation, not observed total cost or evidence of matched human productivity."},{"family":"quotes","family_name":"Quote comparison packet","scenario":"efficient","route":"modeled_model_extension","attempts_per_month":100,"expected_accepted_per_month":97.80399999999999,"assumed_final_acceptance_in_normal_month":0.98,"assumed_expected_acceptance":0.9780399999999999,"estimated_base_input_tokens":4000.0,"estimated_base_billable_output_tokens":1250.0,"modeled_attempts_per_requested_job":1.0519999999999998,"marginal_execution_usd_per_accepted":0.054318841765162974,"recurring_delivery_usd_per_accepted":3.300716655767721,"fully_loaded_pretax_usd_per_accepted":5.233250108033458,"adverse_month_fully_loaded_usd_per_accepted":7.908809583857081,"components_usd_per_accepted":{"model_tokens":0.02205022289476913,"runtime":0.03226861887039384,"search":0.0,"normal_exceptions":0.06392376589914524,"rare_exceptions":0.047942824424358925,"platform_archive":0.2044906138808229,"maintenance":1.9325334522657374,"business_administration":0.9588564884871785,"common_shock_recovery":0.03865066904531475,"setup_amortization":1.9325334522657371},"setup_total_usd":2268.114021184778,"median_wage_hourly_usd":24.32,"estimated_employer_hourly_usd":35.41925455987312,"break_even_human_minutes_wage_only":12.910978884950964,"break_even_human_minutes_employer_proxy":8.865093587761049,"break_even_human_minutes_wage_with_extra_attention":12.910978884950964,"pretax_customer_price_floor_usd_including_modeled_noncollection_refund_fees":5.818865854412309,"interpretation":"Scenario calculation, not observed total cost or evidence of matched human productivity."},{"family":"quotes","family_name":"Quote comparison packet","scenario":"efficient","route":"modeled_model_extension","attempts_per_month":1000,"expected_accepted_per_month":978.04,"assumed_final_acceptance_in_normal_month":0.98,"assumed_expected_acceptance":0.9780399999999999,"estimated_base_input_tokens":4000.0,"estimated_base_billable_output_tokens":1250.0,"modeled_attempts_per_requested_job":1.0519999999999998,"marginal_execution_usd_per_accepted":0.054318841765162974,"recurring_delivery_usd_per_accepted":0.47963855445657255,"fully_loaded_pretax_usd_per_accepted":0.6728918996831463,"adverse_month_fully_loaded_usd_per_accepted":0.9617840196101978,"components_usd_per_accepted":{"model_tokens":0.02205022289476913,"runtime":0.03226861887039384,"search":0.0,"normal_exceptions":0.06392376589914524,"rare_exceptions":0.047942824424358925,"platform_archive":0.02044906138808229,"maintenance":0.19325334522657373,"business_administration":0.09588564884871785,"common_shock_recovery":0.003865066904531475,"setup_amortization":0.19325334522657373},"setup_total_usd":2268.114021184778,"median_wage_hourly_usd":24.32,"estimated_employer_hourly_usd":35.41925455987312,"break_even_human_minutes_wage_only":1.6600951472446046,"break_even_human_minutes_employer_proxy":1.1398747512526253,"break_even_human_minutes_wage_with_extra_attention":1.6600951472446046,"pretax_customer_price_floor_usd_including_modeled_noncollection_refund_fees":1.0205091537070143,"interpretation":"Scenario calculation, not observed total cost or evidence of matched human productivity."},{"family":"quotes","family_name":"Quote comparison packet","scenario":"efficient","route":"modeled_model_extension","attempts_per_month":10000,"expected_accepted_per_month":9780.4,"assumed_final_acceptance_in_normal_month":0.98,"assumed_expected_acceptance":0.9780399999999999,"estimated_base_input_tokens":4000.0,"estimated_base_billable_output_tokens":1250.0,"modeled_attempts_per_requested_job":1.0519999999999998,"marginal_execution_usd_per_accepted":0.054318841765162974,"recurring_delivery_usd_per_accepted":0.1975307443254577,"fully_loaded_pretax_usd_per_accepted":0.21685607884811506,"adverse_month_fully_loaded_usd_per_accepted":0.26708146318550957,"components_usd_per_accepted":{"model_tokens":0.02205022289476913,"runtime":0.03226861887039384,"search":0.0,"normal_exceptions":0.06392376589914524,"rare_exceptions":0.047942824424358925,"platform_archive":0.0020449061388082288,"maintenance":0.019325334522657375,"business_administration":0.009588564884871786,"common_shock_recovery":0.00038650669045314746,"setup_amortization":0.019325334522657372},"setup_total_usd":2268.114021184778,"median_wage_hourly_usd":24.32,"estimated_employer_hourly_usd":35.41925455987312,"break_even_human_minutes_wage_only":0.5350067734739681,"break_even_human_minutes_employer_proxy":0.3673528676017826,"break_even_human_minutes_wage_with_extra_attention":0.5350067734739681,"pretax_customer_price_floor_usd_including_modeled_noncollection_refund_fees":0.5406734836364847,"interpretation":"Scenario calculation, not observed total cost or evidence of matched human productivity."},{"family":"quotes","family_name":"Quote comparison packet","scenario":"reference","route":"modeled_tool_delivery","attempts_per_month":100,"expected_accepted_per_month":97.02,"assumed_final_acceptance_in_normal_month":0.98,"assumed_expected_acceptance":0.9702,"estimated_base_input_tokens":0,"estimated_base_billable_output_tokens":0,"modeled_attempts_per_requested_job":1.06,"marginal_execution_usd_per_accepted":0.03277674706246135,"recurring_delivery_usd_per_accepted":11.992655199079287,"fully_loaded_pretax_usd_per_accepted":17.18772155695459,"adverse_month_fully_loaded_usd_per_accepted":30.438250665360297,"components_usd_per_accepted":{"model_tokens":0.0,"runtime":0.03277674706246135,"search":0.0,"normal_exceptions":0.6041280148423007,"rare_exceptions":0.7249536178107607,"platform_archive":0.5153576582148011,"maintenance":7.792599536812953,"business_administration":1.9332096474953617,"common_shock_recovery":0.3896299768406477,"setup_amortization":5.195066357875302},"setup_total_usd":6048.304056492741,"median_wage_hourly_usd":24.32,"estimated_employer_hourly_usd":35.41925455987312,"break_even_human_minutes_wage_only":42.40391831485507,"break_even_human_minutes_employer_proxy":29.115894906088887,"break_even_human_minutes_wage_with_extra_attention":48.188046604328754,"pretax_customer_price_floor_usd_including_modeled_noncollection_refund_fees":19.566317532983863,"interpretation":"Scenario calculation, not observed total cost or evidence of matched human productivity."},{"family":"quotes","family_name":"Quote comparison packet","scenario":"reference","route":"modeled_tool_delivery","attempts_per_month":1000,"expected_accepted_per_month":970.1999999999999,"assumed_final_acceptance_in_normal_month":0.98,"assumed_expected_acceptance":0.9702,"estimated_base_input_tokens":0,"estimated_base_billable_output_tokens":0,"modeled_attempts_per_requested_job":1.06,"marginal_execution_usd_per_accepted":0.03277674706246135,"recurring_delivery_usd_per_accepted":2.4249380616518987,"fully_loaded_pretax_usd_per_accepted":2.9444446974394287,"adverse_month_fully_loaded_usd_per_accepted":4.567138204291131,"components_usd_per_accepted":{"model_tokens":0.0,"runtime":0.03277674706246135,"search":0.0,"normal_exceptions":0.6041280148423007,"rare_exceptions":0.7249536178107607,"platform_archive":0.05153576582148011,"maintenance":0.7792599536812953,"business_administration":0.1933209647495362,"common_shock_recovery":0.038962997684064776,"setup_amortization":0.5195066357875302},"setup_total_usd":6048.304056492741,"median_wage_hourly_usd":24.32,"estimated_employer_hourly_usd":35.41925455987312,"break_even_human_minutes_wage_only":7.264255010130169,"break_even_human_minutes_employer_proxy":4.987871259337949,"break_even_human_minutes_wage_with_extra_attention":13.048383299603856,"pretax_customer_price_floor_usd_including_modeled_noncollection_refund_fees":3.616399437222205,"interpretation":"Scenario calculation, not observed total cost or evidence of matched human productivity."},{"family":"quotes","family_name":"Quote comparison packet","scenario":"reference","route":"modeled_tool_delivery","attempts_per_month":10000,"expected_accepted_per_month":9702.0,"assumed_final_acceptance_in_normal_month":0.98,"assumed_expected_acceptance":0.9702,"estimated_base_input_tokens":0,"estimated_base_billable_output_tokens":0,"modeled_attempts_per_requested_job":1.06,"marginal_execution_usd_per_accepted":0.03277674706246135,"recurring_delivery_usd_per_accepted":1.4681663479091602,"fully_loaded_pretax_usd_per_accepted":1.5201170114879132,"adverse_month_fully_loaded_usd_per_accepted":1.9800269581842151,"components_usd_per_accepted":{"model_tokens":0.0,"runtime":0.03277674706246135,"search":0.0,"normal_exceptions":0.6041280148423007,"rare_exceptions":0.7249536178107607,"platform_archive":0.005153576582148011,"maintenance":0.07792599536812954,"business_administration":0.01933209647495362,"common_shock_recovery":0.003896299768406477,"setup_amortization":0.05195066357875302},"setup_total_usd":6048.304056492741,"median_wage_hourly_usd":24.32,"estimated_employer_hourly_usd":35.41925455987312,"break_even_human_minutes_wage_only":3.7502886796576806,"break_even_human_minutes_employer_proxy":2.575068894662856,"break_even_human_minutes_wage_with_extra_attention":9.534416969131366,"pretax_customer_price_floor_usd_including_modeled_noncollection_refund_fees":2.0214076276460395,"interpretation":"Scenario calculation, not observed total cost or evidence of matched human productivity."},{"family":"quotes","family_name":"Quote comparison packet","scenario":"reference","route":"modeled_model_extension","attempts_per_month":100,"expected_accepted_per_month":89.1,"assumed_final_acceptance_in_normal_month":0.9,"assumed_expected_acceptance":0.891,"estimated_base_input_tokens":8000,"estimated_base_billable_output_tokens":2500,"modeled_attempts_per_requested_job":1.21,"marginal_execution_usd_per_accepted":0.09641975308641976,"recurring_delivery_usd_per_accepted":13.119398511949184,"fully_loaded_pretax_usd_per_accepted":18.77624854608007,"adverse_month_fully_loaded_usd_per_accepted":33.229845168947875,"components_usd_per_accepted":{"model_tokens":0.05567901234567901,"runtime":0.04074074074074074,"search":0.0,"normal_exceptions":0.657828282828283,"rare_exceptions":0.7893939393939394,"platform_archive":0.5611672278338945,"maintenance":8.485275051196327,"business_administration":2.105050505050505,"common_shock_recovery":0.42426375255981635,"setup_amortization":5.656850034130884},"setup_total_usd":6048.304056492741,"median_wage_hourly_usd":24.32,"estimated_employer_hourly_usd":35.41925455987312,"break_even_human_minutes_wage_only":46.322981610394905,"break_even_human_minutes_employer_proxy":31.80684988331499,"break_even_human_minutes_wage_with_extra_attention":52.1071098998686,"pretax_customer_price_floor_usd_including_modeled_noncollection_refund_fees":21.34518314230691,"interpretation":"Scenario calculation, not observed total cost or evidence of matched human productivity."},{"family":"quotes","family_name":"Quote comparison packet","scenario":"reference","route":"modeled_model_extension","attempts_per_month":1000,"expected_accepted_per_month":891.0,"assumed_final_acceptance_in_normal_month":0.9,"assumed_expected_acceptance":0.891,"estimated_base_input_tokens":8000,"estimated_base_billable_output_tokens":2500,"modeled_attempts_per_requested_job":1.21,"marginal_execution_usd_per_accepted":0.09641975308641976,"recurring_delivery_usd_per_accepted":2.7012176289726963,"fully_loaded_pretax_usd_per_accepted":3.2669026323857846,"adverse_month_fully_loaded_usd_per_accepted":5.059078266894787,"components_usd_per_accepted":{"model_tokens":0.05567901234567901,"runtime":0.04074074074074074,"search":0.0,"normal_exceptions":0.657828282828283,"rare_exceptions":0.7893939393939394,"platform_archive":0.05611672278338945,"maintenance":0.8485275051196326,"business_administration":0.2105050505050505,"common_shock_recovery":0.04242637525598164,"setup_amortization":0.5656850034130885},"setup_total_usd":6048.304056492741,"median_wage_hourly_usd":24.32,"estimated_employer_hourly_usd":35.41925455987312,"break_even_human_minutes_wage_only":8.05979267858335,"break_even_human_minutes_employer_proxy":5.534113023519523,"break_even_human_minutes_wage_with_extra_attention":13.843920968057033,"pretax_customer_price_floor_usd_including_modeled_noncollection_refund_fees":3.9774945491442164,"interpretation":"Scenario calculation, not observed total cost or evidence of matched human productivity."},{"family":"quotes","family_name":"Quote comparison packet","scenario":"reference","route":"modeled_model_extension","attempts_per_month":10000,"expected_accepted_per_month":8910.0,"assumed_final_acceptance_in_normal_month":0.9,"assumed_expected_acceptance":0.891,"estimated_base_input_tokens":8000,"estimated_base_billable_output_tokens":2500,"modeled_attempts_per_requested_job":1.21,"marginal_execution_usd_per_accepted":0.09641975308641976,"recurring_delivery_usd_per_accepted":1.6593995406750472,"fully_loaded_pretax_usd_per_accepted":1.715968041016356,"adverse_month_fully_loaded_usd_per_accepted":2.242001576689478,"components_usd_per_accepted":{"model_tokens":0.05567901234567901,"runtime":0.04074074074074074,"search":0.0,"normal_exceptions":0.657828282828283,"rare_exceptions":0.7893939393939394,"platform_archive":0.005611672278338945,"maintenance":0.08485275051196327,"business_administration":0.021050505050505052,"common_shock_recovery":0.004242637525598164,"setup_amortization":0.05656850034130884},"setup_total_usd":6048.304056492741,"median_wage_hourly_usd":24.32,"estimated_employer_hourly_usd":35.41925455987312,"break_even_human_minutes_wage_only":4.233473785402194,"break_even_human_minutes_employer_proxy":2.906839337539976,"break_even_human_minutes_wage_with_extra_attention":10.01760207487588,"pretax_customer_price_floor_usd_including_modeled_noncollection_refund_fees":2.2407256898279466,"interpretation":"Scenario calculation, not observed total cost or evidence of matched human productivity."},{"family":"quotes","family_name":"Quote comparison packet","scenario":"stress","route":"modeled_tool_delivery","attempts_per_month":100,"expected_accepted_per_month":82.80000000000001,"assumed_final_acceptance_in_normal_month":0.9,"assumed_expected_acceptance":0.8280000000000001,"estimated_base_input_tokens":0,"estimated_base_billable_output_tokens":0,"modeled_attempts_per_requested_job":1.2100000000000002,"marginal_execution_usd_per_accepted":0.043840579710144933,"recurring_delivery_usd_per_accepted":57.41638678045571,"fully_loaded_pretax_usd_per_accepted":72.6345431222752,"adverse_month_fully_loaded_usd_per_accepted":144.98798865689275,"components_usd_per_accepted":{"model_tokens":0.0,"runtime":0.043840579710144933,"search":0.0,"normal_exceptions":8.494565217391303,"rare_exceptions":9.06086956521739,"platform_archive":2.4154589371980673,"maintenance":27.392681415275092,"business_administration":4.530434782608695,"common_shock_recovery":5.47853628305502,"setup_amortization":15.218156341819498},"setup_total_usd":15120.760141231855,"median_wage_hourly_usd":24.32,"estimated_employer_hourly_usd":35.41925455987312,"break_even_human_minutes_wage_only":179.1970636240342,"break_even_human_minutes_employer_proxy":123.042470585302,"break_even_human_minutes_wage_with_extra_attention":198.47749125561316,"pretax_customer_price_floor_usd_including_modeled_noncollection_refund_fees":104.70480333660228,"interpretation":"Scenario calculation, not observed total cost or evidence of matched human productivity."},{"family":"quotes","family_name":"Quote comparison packet","scenario":"stress","route":"modeled_tool_delivery","attempts_per_month":1000,"expected_accepted_per_month":828.0000000000001,"assumed_final_acceptance_in_normal_month":0.9,"assumed_expected_acceptance":0.8280000000000001,"estimated_base_input_tokens":0,"estimated_base_billable_output_tokens":0,"modeled_attempts_per_requested_job":1.2100000000000002,"marginal_execution_usd_per_accepted":0.043840579710144933,"recurring_delivery_usd_per_accepted":21.58098650413253,"fully_loaded_pretax_usd_per_accepted":23.10280213831448,"adverse_month_fully_loaded_usd_per_accepted":38.79779886568927,"components_usd_per_accepted":{"model_tokens":0.0,"runtime":0.043840579710144933,"search":0.0,"normal_exceptions":8.494565217391303,"rare_exceptions":9.06086956521739,"platform_archive":0.24154589371980675,"maintenance":2.739268141527509,"business_administration":0.45304347826086955,"common_shock_recovery":0.547853628305502,"setup_amortization":1.52181563418195},"setup_total_usd":15120.760141231855,"median_wage_hourly_usd":24.32,"estimated_employer_hourly_usd":35.41925455987312,"break_even_human_minutes_wage_only":56.99704474913112,"break_even_human_minutes_employer_proxy":39.13600513403449,"break_even_human_minutes_wage_with_extra_attention":76.27747238071007,"pretax_customer_price_floor_usd_including_modeled_noncollection_refund_fees":33.53850881941735,"interpretation":"Scenario calculation, not observed total cost or evidence of matched human productivity."},{"family":"quotes","family_name":"Quote comparison packet","scenario":"stress","route":"modeled_tool_delivery","attempts_per_month":10000,"expected_accepted_per_month":8280.0,"assumed_final_acceptance_in_normal_month":0.9,"assumed_expected_acceptance":0.8280000000000001,"estimated_base_input_tokens":0,"estimated_base_billable_output_tokens":0,"modeled_attempts_per_requested_job":1.2100000000000002,"marginal_execution_usd_per_accepted":0.043840579710144933,"recurring_delivery_usd_per_accepted":17.997446476500212,"fully_loaded_pretax_usd_per_accepted":18.149628039918408,"adverse_month_fully_loaded_usd_per_accepted":28.17877988656893,"components_usd_per_accepted":{"model_tokens":0.0,"runtime":0.043840579710144933,"search":0.0,"normal_exceptions":8.494565217391303,"rare_exceptions":9.06086956521739,"platform_archive":0.024154589371980676,"maintenance":0.27392681415275094,"business_administration":0.04530434782608696,"common_shock_recovery":0.0547853628305502,"setup_amortization":0.15218156341819497},"setup_total_usd":15120.760141231855,"median_wage_hourly_usd":24.32,"estimated_employer_hourly_usd":35.41925455987312,"break_even_human_minutes_wage_only":44.77704286164081,"break_even_human_minutes_employer_proxy":30.745358588907738,"break_even_human_minutes_wage_with_extra_attention":64.05747049321975,"pretax_customer_price_floor_usd_including_modeled_noncollection_refund_fees":26.421879367698857,"interpretation":"Scenario calculation, not observed total cost or evidence of matched human productivity."},{"family":"quotes","family_name":"Quote comparison packet","scenario":"stress","route":"modeled_model_extension","attempts_per_month":100,"expected_accepted_per_month":59.80000000000001,"assumed_final_acceptance_in_normal_month":0.65,"assumed_expected_acceptance":0.5980000000000001,"estimated_base_input_tokens":32000,"estimated_base_billable_output_tokens":10000,"modeled_attempts_per_requested_job":1.56,"marginal_execution_usd_per_accepted":0.5060869565217391,"recurring_delivery_usd_per_accepted":79.94499708063098,"fully_loaded_pretax_usd_per_accepted":101.01629047699643,"adverse_month_fully_loaded_usd_per_accepted":201.53644583262076,"components_usd_per_accepted":{"model_tokens":0.4278260869565217,"runtime":0.07826086956521738,"search":0.0,"normal_exceptions":11.761705685618727,"rare_exceptions":12.54581939799331,"platform_archive":3.34448160535117,"maintenance":37.928328113457816,"business_administration":6.272909698996655,"common_shock_recovery":7.585665622691566,"setup_amortization":21.071293396365455},"setup_total_usd":15120.760141231855,"median_wage_hourly_usd":24.32,"estimated_employer_hourly_usd":35.41925455987312,"break_even_human_minutes_wage_only":249.21782190048464,"break_even_human_minutes_employer_proxy":171.12097654043623,"break_even_human_minutes_wage_with_extra_attention":268.49824953206354,"pretax_customer_price_floor_usd_including_modeled_noncollection_refund_fees":145.483175972696,"interpretation":"Scenario calculation, not observed total cost or evidence of matched human productivity."},{"family":"quotes","family_name":"Quote comparison packet","scenario":"stress","route":"modeled_model_extension","attempts_per_month":1000,"expected_accepted_per_month":598.0000000000001,"assumed_final_acceptance_in_normal_month":0.65,"assumed_expected_acceptance":0.5980000000000001,"estimated_base_input_tokens":32000,"estimated_base_billable_output_tokens":10000,"modeled_attempts_per_requested_job":1.56,"marginal_execution_usd_per_accepted":0.5060869565217391,"recurring_delivery_usd_per_accepted":30.3267505441835,"fully_loaded_pretax_usd_per_accepted":32.43387988382005,"adverse_month_fully_loaded_usd_per_accepted":54.50387535249285,"components_usd_per_accepted":{"model_tokens":0.4278260869565217,"runtime":0.07826086956521738,"search":0.0,"normal_exceptions":11.761705685618727,"rare_exceptions":12.54581939799331,"platform_archive":0.334448160535117,"maintenance":3.7928328113457814,"business_administration":0.6272909698996655,"common_shock_recovery":0.7585665622691565,"setup_amortization":2.1071293396365456},"setup_total_usd":15120.760141231855,"median_wage_hourly_usd":24.32,"estimated_employer_hourly_usd":35.41925455987312,"break_even_human_minutes_wage_only":80.0177957660034,"break_even_human_minutes_employer_proxy":54.942793607911945,"break_even_human_minutes_wage_with_extra_attention":99.29822339758236,"pretax_customer_price_floor_usd_including_modeled_noncollection_refund_fees":46.94522971813225,"interpretation":"Scenario calculation, not observed total cost or evidence of matched human productivity."},{"family":"quotes","family_name":"Quote comparison packet","scenario":"stress","route":"modeled_model_extension","attempts_per_month":10000,"expected_accepted_per_month":5980.000000000001,"assumed_final_acceptance_in_normal_month":0.65,"assumed_expected_acceptance":0.5980000000000001,"estimated_base_input_tokens":32000,"estimated_base_billable_output_tokens":10000,"modeled_attempts_per_requested_job":1.56,"marginal_execution_usd_per_accepted":0.5060869565217391,"recurring_delivery_usd_per_accepted":25.36492589053875,"fully_loaded_pretax_usd_per_accepted":25.575638824502406,"adverse_month_fully_loaded_usd_per_accepted":39.800618304480054,"components_usd_per_accepted":{"model_tokens":0.4278260869565217,"runtime":0.07826086956521738,"search":0.0,"normal_exceptions":11.761705685618727,"rare_exceptions":12.54581939799331,"platform_archive":0.033444816053511704,"maintenance":0.37928328113457815,"business_administration":0.06272909698996655,"common_shock_recovery":0.07585665622691566,"setup_amortization":0.21071293396365456},"setup_total_usd":15120.760141231855,"median_wage_hourly_usd":24.32,"estimated_employer_hourly_usd":35.41925455987312,"break_even_human_minutes_wage_only":63.097793152555276,"break_even_human_minutes_employer_proxy":43.32497531465952,"break_even_human_minutes_wage_with_extra_attention":82.37822078413421,"pretax_customer_price_floor_usd_including_modeled_noncollection_refund_fees":37.091435092675866,"interpretation":"Scenario calculation, not observed total cost or evidence of matched human productivity."}],"portfolio_upkeep_rows":[{"scenario":"efficient","route":"modeled_tool_delivery","attempts_per_month":100,"status":"MODELED_NOT_RUN","original_fully_loaded_pretax_usd_per_accepted":5.139074063363958,"automated_upkeep_fully_loaded_pretax_usd_per_accepted":3.312813824682655,"automated_upkeep_recurring_usd_per_accepted":1.0921807455297299,"additional_setup_usd_assumed":378.01900353079634,"original_shared_upkeep_admin_monthly_usd":282.7895017653982,"replacement_shared_monthly_usd":69.93845017653982,"replacement_components_monthly_usd":{"automatic_repair_model":0.235,"automatic_repair_runtime":0.12,"residual_repair":18.900950176539812,"scheduled_regressions":0.8999999999999999,"source_refresh":0.348,"automatic_bookkeeping":0.2,"residual_administration":49.234500000000004},"residual_upkeep_hours_per_month_assumed":0.19999999999999996,"residual_admin_hours_per_month_assumed":1.05,"actual_maintenance_success_or_spending":"NOT_MEASURED"},{"scenario":"efficient","route":"modeled_tool_delivery","attempts_per_month":1000,"status":"MODELED_NOT_RUN","original_fully_loaded_pretax_usd_per_accepted":0.6474649737324945,"automated_upkeep_fully_loaded_pretax_usd_per_accepted":0.46483894986436414,"automated_upkeep_recurring_usd_per_accepted":0.24277564194907178,"additional_setup_usd_assumed":378.01900353079634,"original_shared_upkeep_admin_monthly_usd":282.7895017653982,"replacement_shared_monthly_usd":69.93845017653982,"replacement_components_monthly_usd":{"automatic_repair_model":0.235,"automatic_repair_runtime":0.12,"residual_repair":18.900950176539812,"scheduled_regressions":0.8999999999999999,"source_refresh":0.348,"automatic_bookkeeping":0.2,"residual_administration":49.234500000000004},"residual_upkeep_hours_per_month_assumed":0.19999999999999996,"residual_admin_hours_per_month_assumed":1.05,"actual_maintenance_success_or_spending":"NOT_MEASURED"},{"scenario":"efficient","route":"modeled_tool_delivery","attempts_per_month":10000,"status":"MODELED_NOT_RUN","original_fully_loaded_pretax_usd_per_accepted":0.19830406476934817,"automated_upkeep_fully_loaded_pretax_usd_per_accepted":0.18004146238253516,"automated_upkeep_recurring_usd_per_accepted":0.15783513159100593,"additional_setup_usd_assumed":378.01900353079634,"original_shared_upkeep_admin_monthly_usd":282.7895017653982,"replacement_shared_monthly_usd":69.93845017653982,"replacement_components_monthly_usd":{"automatic_repair_model":0.235,"automatic_repair_runtime":0.12,"residual_repair":18.900950176539812,"scheduled_regressions":0.8999999999999999,"source_refresh":0.348,"automatic_bookkeeping":0.2,"residual_administration":49.234500000000004},"residual_upkeep_hours_per_month_assumed":0.19999999999999996,"residual_admin_hours_per_month_assumed":1.05,"actual_maintenance_success_or_spending":"NOT_MEASURED"},{"scenario":"efficient","route":"modeled_model_extension","attempts_per_month":100,"status":"MODELED_NOT_RUN","original_fully_loaded_pretax_usd_per_accepted":5.274527049671836,"automated_upkeep_fully_loaded_pretax_usd_per_accepted":3.420313848153575,"automated_upkeep_recurring_usd_per_accepted":1.1656914871768822,"additional_setup_usd_assumed":378.01900353079634,"original_shared_upkeep_admin_monthly_usd":282.7895017653982,"replacement_shared_monthly_usd":69.93845017653982,"replacement_components_monthly_usd":{"automatic_repair_model":0.235,"automatic_repair_runtime":0.12,"residual_repair":18.900950176539812,"scheduled_regressions":0.8999999999999999,"source_refresh":0.348,"automatic_bookkeeping":0.2,"residual_administration":49.234500000000004},"residual_upkeep_hours_per_month_assumed":0.19999999999999996,"residual_admin_hours_per_month_assumed":1.05,"actual_maintenance_success_or_spending":"NOT_MEASURED"},{"scenario":"efficient","route":"modeled_model_extension","attempts_per_month":1000,"status":"MODELED_NOT_RUN","original_fully_loaded_pretax_usd_per_accepted":0.714168841321525,"automated_upkeep_fully_loaded_pretax_usd_per_accepted":0.5287475211696988,"automated_upkeep_recurring_usd_per_accepted":0.30328528507202956,"additional_setup_usd_assumed":378.01900353079634,"original_shared_upkeep_admin_monthly_usd":282.7895017653982,"replacement_shared_monthly_usd":69.93845017653982,"replacement_components_monthly_usd":{"automatic_repair_model":0.235,"automatic_repair_runtime":0.12,"residual_repair":18.900950176539812,"scheduled_regressions":0.8999999999999999,"source_refresh":0.348,"automatic_bookkeeping":0.2,"residual_administration":49.234500000000004},"residual_upkeep_hours_per_month_assumed":0.19999999999999996,"residual_admin_hours_per_month_assumed":1.05,"actual_maintenance_success_or_spending":"NOT_MEASURED"},{"scenario":"efficient","route":"modeled_model_extension","attempts_per_month":10000,"status":"MODELED_NOT_RUN","original_fully_loaded_pretax_usd_per_accepted":0.25813302048649384,"automated_upkeep_fully_loaded_pretax_usd_per_accepted":0.23959088847131124,"automated_upkeep_recurring_usd_per_accepted":0.2170446648615443,"additional_setup_usd_assumed":378.01900353079634,"original_shared_upkeep_admin_monthly_usd":282.7895017653982,"replacement_shared_monthly_usd":69.93845017653982,"replacement_components_monthly_usd":{"automatic_repair_model":0.235,"automatic_repair_runtime":0.12,"residual_repair":18.900950176539812,"scheduled_regressions":0.8999999999999999,"source_refresh":0.348,"automatic_bookkeeping":0.2,"residual_administration":49.234500000000004},"residual_upkeep_hours_per_month_assumed":0.19999999999999996,"residual_admin_hours_per_month_assumed":1.05,"actual_maintenance_success_or_spending":"NOT_MEASURED"},{"scenario":"reference","route":"modeled_tool_delivery","attempts_per_month":100,"status":"MODELED_NOT_RUN","original_fully_loaded_pretax_usd_per_accepted":17.195915743720203,"automated_upkeep_fully_loaded_pretax_usd_per_accepted":12.292652117851075,"automated_upkeep_recurring_usd_per_accepted":6.448202465241362,"additional_setup_usd_assumed":756.0380070615927,"original_shared_upkeep_admin_monthly_usd":943.5980070615926,"replacement_shared_monthly_usd":404.88020282463714,"replacement_components_monthly_usd":{"automatic_repair_model":1.88,"automatic_repair_runtime":0.48,"residual_repair":302.4152028246371,"scheduled_regressions":0.8999999999999999,"source_refresh":0.456,"automatic_bookkeeping":0.28,"residual_administration":98.46900000000001},"residual_upkeep_hours_per_month_assumed":3.2,"residual_admin_hours_per_month_assumed":2.1,"actual_maintenance_success_or_spending":"NOT_MEASURED"},{"scenario":"reference","route":"modeled_tool_delivery","attempts_per_month":1000,"status":"MODELED_NOT_RUN","original_fully_loaded_pretax_usd_per_accepted":2.952638884205044,"automated_upkeep_fully_loaded_pretax_usd_per_accepted":2.462312521618131,"automated_upkeep_recurring_usd_per_accepted":1.87786755635716,"additional_setup_usd_assumed":756.0380070615927,"original_shared_upkeep_admin_monthly_usd":943.5980070615926,"replacement_shared_monthly_usd":404.88020282463714,"replacement_components_monthly_usd":{"automatic_repair_model":1.88,"automatic_repair_runtime":0.48,"residual_repair":302.4152028246371,"scheduled_regressions":0.8999999999999999,"source_refresh":0.456,"automatic_bookkeeping":0.28,"residual_administration":98.46900000000001},"residual_upkeep_hours_per_month_assumed":3.2,"residual_admin_hours_per_month_assumed":2.1,"actual_maintenance_success_or_spending":"NOT_MEASURED"},{"scenario":"reference","route":"modeled_tool_delivery","attempts_per_month":10000,"status":"MODELED_NOT_RUN","original_fully_loaded_pretax_usd_per_accepted":1.5283111982535287,"automated_upkeep_fully_loaded_pretax_usd_per_accepted":1.4792785619948374,"automated_upkeep_recurring_usd_per_accepted":1.4208340654687404,"additional_setup_usd_assumed":756.0380070615927,"original_shared_upkeep_admin_monthly_usd":943.5980070615926,"replacement_shared_monthly_usd":404.88020282463714,"replacement_components_monthly_usd":{"automatic_repair_model":1.88,"automatic_repair_runtime":0.48,"residual_repair":302.4152028246371,"scheduled_regressions":0.8999999999999999,"source_refresh":0.456,"automatic_bookkeeping":0.28,"residual_administration":98.46900000000001},"residual_upkeep_hours_per_month_assumed":3.2,"residual_admin_hours_per_month_assumed":2.1,"actual_maintenance_success_or_spending":"NOT_MEASURED"},{"scenario":"reference","route":"modeled_model_extension","attempts_per_month":100,"status":"MODELED_NOT_RUN","original_fully_loaded_pretax_usd_per_accepted":18.86010657077143,"automated_upkeep_fully_loaded_pretax_usd_per_accepted":13.520997289269488,"automated_upkeep_recurring_usd_per_accepted":7.1570410008722405,"additional_setup_usd_assumed":756.0380070615927,"original_shared_upkeep_admin_monthly_usd":943.5980070615926,"replacement_shared_monthly_usd":404.88020282463714,"replacement_components_monthly_usd":{"automatic_repair_model":1.88,"automatic_repair_runtime":0.48,"residual_repair":302.4152028246371,"scheduled_regressions":0.8999999999999999,"source_refresh":0.456,"automatic_bookkeeping":0.28,"residual_administration":98.46900000000001},"residual_upkeep_hours_per_month_assumed":3.2,"residual_admin_hours_per_month_assumed":2.1,"actual_maintenance_success_or_spending":"NOT_MEASURED"},{"scenario":"reference","route":"modeled_model_extension","attempts_per_month":1000,"status":"MODELED_NOT_RUN","original_fully_loaded_pretax_usd_per_accepted":3.350760657077142,"automated_upkeep_fully_loaded_pretax_usd_per_accepted":2.816849728926948,"automated_upkeep_recurring_usd_per_accepted":2.180454100087224,"additional_setup_usd_assumed":756.0380070615927,"original_shared_upkeep_admin_monthly_usd":943.5980070615926,"replacement_shared_monthly_usd":404.88020282463714,"replacement_components_monthly_usd":{"automatic_repair_model":1.88,"automatic_repair_runtime":0.48,"residual_repair":302.4152028246371,"scheduled_regressions":0.8999999999999999,"source_refresh":0.456,"automatic_bookkeeping":0.28,"residual_administration":98.46900000000001},"residual_upkeep_hours_per_month_assumed":3.2,"residual_admin_hours_per_month_assumed":2.1,"actual_maintenance_success_or_spending":"NOT_MEASURED"},{"scenario":"reference","route":"modeled_model_extension","attempts_per_month":10000,"status":"MODELED_NOT_RUN","original_fully_loaded_pretax_usd_per_accepted":1.799826065707714,"automated_upkeep_fully_loaded_pretax_usd_per_accepted":1.7464349728926947,"automated_upkeep_recurring_usd_per_accepted":1.6827954100087223,"additional_setup_usd_assumed":756.0380070615927,"original_shared_upkeep_admin_monthly_usd":943.5980070615926,"replacement_shared_monthly_usd":404.88020282463714,"replacement_components_monthly_usd":{"automatic_repair_model":1.88,"automatic_repair_runtime":0.48,"residual_repair":302.4152028246371,"scheduled_regressions":0.8999999999999999,"source_refresh":0.456,"automatic_bookkeeping":0.28,"residual_administration":98.46900000000001},"residual_upkeep_hours_per_month_assumed":3.2,"residual_admin_hours_per_month_assumed":2.1,"actual_maintenance_success_or_spending":"NOT_MEASURED"},{"scenario":"stress","route":"modeled_tool_delivery","attempts_per_month":100,"status":"MODELED_NOT_RUN","original_fully_loaded_pretax_usd_per_accepted":72.64550326720274,"automated_upkeep_fully_loaded_pretax_usd_per_accepted":66.25133655789361,"automated_upkeep_recurring_usd_per_accepted":48.75045676480119,"additional_setup_usd_assumed":2268.114021184778,"original_shared_upkeep_admin_monthly_usd":2643.2340211847777,"replacement_shared_monthly_usd":1924.7875158885836,"replacement_components_monthly_usd":{"automatic_repair_model":22.56,"automatic_repair_runtime":1.44,"residual_repair":1701.0855158885836,"scheduled_regressions":0.8999999999999999,"source_refresh":1.104,"automatic_bookkeeping":0.76,"residual_administration":196.93800000000002},"residual_upkeep_hours_per_month_assumed":18.0,"residual_admin_hours_per_month_assumed":4.2,"actual_maintenance_success_or_spending":"NOT_MEASURED"},{"scenario":"stress","route":"modeled_tool_delivery","attempts_per_month":1000,"status":"MODELED_NOT_RUN","original_fully_loaded_pretax_usd_per_accepted":23.113762283242018,"automated_upkeep_fully_loaded_pretax_usd_per_accepted":22.474345612311105,"automated_upkeep_recurring_usd_per_accepted":20.72425763300186,"additional_setup_usd_assumed":2268.114021184778,"original_shared_upkeep_admin_monthly_usd":2643.2340211847777,"replacement_shared_monthly_usd":1924.7875158885836,"replacement_components_monthly_usd":{"automatic_repair_model":22.56,"automatic_repair_runtime":1.44,"residual_repair":1701.0855158885836,"scheduled_regressions":0.8999999999999999,"source_refresh":1.104,"automatic_bookkeeping":0.76,"residual_administration":196.93800000000002},"residual_upkeep_hours_per_month_assumed":18.0,"residual_admin_hours_per_month_assumed":4.2,"actual_maintenance_success_or_spending":"NOT_MEASURED"},{"scenario":"stress","route":"modeled_tool_delivery","attempts_per_month":10000,"status":"MODELED_NOT_RUN","original_fully_loaded_pretax_usd_per_accepted":18.160588184845942,"automated_upkeep_fully_loaded_pretax_usd_per_accepted":18.09664651775285,"automated_upkeep_recurring_usd_per_accepted":17.921637719821923,"additional_setup_usd_assumed":2268.114021184778,"original_shared_upkeep_admin_monthly_usd":2643.2340211847777,"replacement_shared_monthly_usd":1924.7875158885836,"replacement_components_monthly_usd":{"automatic_repair_model":22.56,"automatic_repair_runtime":1.44,"residual_repair":1701.0855158885836,"scheduled_regressions":0.8999999999999999,"source_refresh":1.104,"automatic_bookkeeping":0.76,"residual_administration":196.93800000000002},"residual_upkeep_hours_per_month_assumed":18.0,"residual_admin_hours_per_month_assumed":4.2,"actual_maintenance_success_or_spending":"NOT_MEASURED"},{"scenario":"stress","route":"modeled_model_extension","attempts_per_month":100,"status":"MODELED_NOT_RUN","original_fully_loaded_pretax_usd_per_accepted":101.54324699873555,"automated_upkeep_fully_loaded_pretax_usd_per_accepted":92.68978540123061,"automated_upkeep_recurring_usd_per_accepted":68.45779799541035,"additional_setup_usd_assumed":2268.114021184778,"original_shared_upkeep_admin_monthly_usd":2643.2340211847777,"replacement_shared_monthly_usd":1924.7875158885836,"replacement_components_monthly_usd":{"automatic_repair_model":22.56,"automatic_repair_runtime":1.44,"residual_repair":1701.0855158885836,"scheduled_regressions":0.8999999999999999,"source_refresh":1.104,"automatic_bookkeeping":0.76,"residual_administration":196.93800000000002},"residual_upkeep_hours_per_month_assumed":18.0,"residual_admin_hours_per_month_assumed":4.2,"actual_maintenance_success_or_spending":"NOT_MEASURED"},{"scenario":"stress","route":"modeled_model_extension","attempts_per_month":1000,"status":"MODELED_NOT_RUN","original_fully_loaded_pretax_usd_per_accepted":32.96083640555918,"automated_upkeep_fully_loaded_pretax_usd_per_accepted":32.07549024580868,"automated_upkeep_recurring_usd_per_accepted":29.652291505226653,"additional_setup_usd_assumed":2268.114021184778,"original_shared_upkeep_admin_monthly_usd":2643.2340211847777,"replacement_shared_monthly_usd":1924.7875158885836,"replacement_components_monthly_usd":{"automatic_repair_model":22.56,"automatic_repair_runtime":1.44,"residual_repair":1701.0855158885836,"scheduled_regressions":0.8999999999999999,"source_refresh":1.104,"automatic_bookkeeping":0.76,"residual_administration":196.93800000000002},"residual_upkeep_hours_per_month_assumed":18.0,"residual_admin_hours_per_month_assumed":4.2,"actual_maintenance_success_or_spending":"NOT_MEASURED"},{"scenario":"stress","route":"modeled_model_extension","attempts_per_month":10000,"status":"MODELED_NOT_RUN","original_fully_loaded_pretax_usd_per_accepted":26.102595346241536,"automated_upkeep_fully_loaded_pretax_usd_per_accepted":26.014060730266486,"automated_upkeep_recurring_usd_per_accepted":25.771740856208282,"additional_setup_usd_assumed":2268.114021184778,"original_shared_upkeep_admin_monthly_usd":2643.2340211847777,"replacement_shared_monthly_usd":1924.7875158885836,"replacement_components_monthly_usd":{"automatic_repair_model":22.56,"automatic_repair_runtime":1.44,"residual_repair":1701.0855158885836,"scheduled_regressions":0.8999999999999999,"source_refresh":1.104,"automatic_bookkeeping":0.76,"residual_administration":196.93800000000002},"residual_upkeep_hours_per_month_assumed":18.0,"residual_admin_hours_per_month_assumed":4.2,"actual_maintenance_success_or_spending":"NOT_MEASURED"}],"cash_reference_1_5":[{"assumed_price_usd":1,"scenario":"reference","configuration":"original_upkeep","month":0,"requested_attempts":0,"funded_attempts":0,"modeled_accepted":0,"suspended":false,"booked_revenue_usd":0,"collected_cash_usd":0,"refunds_usd":0,"payment_fees_usd":0,"modeled_bad_debt_written_off_usd":0,"recurring_cash_expenses_usd":0,"cash_change_usd":0,"cash_balance_usd":7444.507222244016,"cumulative_obligation_reserve_usd":0,"operating_reserve_target_usd":4963.0048148293445,"available_generated_surplus_usd":0,"gross_pending_receivables_usd":0,"candidate_admitted":false,"construction_spend_usd":0},{"assumed_price_usd":1,"scenario":"reference","configuration":"original_upkeep","month":1,"requested_attempts":1000,"funded_attempts":1000,"modeled_accepted":891.0,"suspended":false,"booked_revenue_usd":891.0,"collected_cash_usd":0.0,"refunds_usd":0.0,"payment_fees_usd":0.0,"modeled_bad_debt_written_off_usd":0.0,"recurring_cash_expenses_usd":2481.5024074146722,"cash_change_usd":-2481.5024074146722,"cash_balance_usd":4963.004814829344,"cumulative_obligation_reserve_usd":0.0,"operating_reserve_target_usd":4963.0048148293445,"available_generated_surplus_usd":0,"gross_pending_receivables_usd":891.0,"candidate_admitted":false,"construction_spend_usd":0},{"assumed_price_usd":1,"scenario":"reference","configuration":"original_upkeep","month":2,"requested_attempts":1000,"funded_attempts":1000,"modeled_accepted":891.0,"suspended":false,"booked_revenue_usd":891.0,"collected_cash_usd":846.4499999999999,"refunds_usd":25.393499999999996,"payment_fees_usd":279.32849999999996,"modeled_bad_debt_written_off_usd":44.55000000000007,"recurring_cash_expenses_usd":2481.5024074146722,"cash_change_usd":-1939.7744074146722,"cash_balance_usd":3023.2304074146714,"cumulative_obligation_reserve_usd":0.0,"operating_reserve_target_usd":4963.0048148293445,"available_generated_surplus_usd":0,"gross_pending_receivables_usd":891.0,"candidate_admitted":false,"construction_spend_usd":0},{"assumed_price_usd":1,"scenario":"reference","configuration":"original_upkeep","month":3,"requested_attempts":1000,"funded_attempts":1000,"modeled_accepted":891.0,"suspended":false,"booked_revenue_usd":891.0,"collected_cash_usd":846.4499999999999,"refunds_usd":25.393499999999996,"payment_fees_usd":279.32849999999996,"modeled_bad_debt_written_off_usd":44.55000000000007,"recurring_cash_expenses_usd":2481.5024074146722,"cash_change_usd":-1939.7744074146722,"cash_balance_usd":1083.4559999999992,"cumulative_obligation_reserve_usd":0.0,"operating_reserve_target_usd":4963.0048148293445,"available_generated_surplus_usd":0,"gross_pending_receivables_usd":891.0,"candidate_admitted":false,"construction_spend_usd":0},{"assumed_price_usd":1,"scenario":"reference","configuration":"original_upkeep","month":4,"requested_attempts":1000,"funded_attempts":409,"modeled_accepted":364.419,"suspended":false,"booked_revenue_usd":364.419,"collected_cash_usd":846.4499999999999,"refunds_usd":25.393499999999996,"payment_fees_usd":279.32849999999996,"modeled_bad_debt_written_off_usd":44.55000000000007,"recurring_cash_expenses_usd":1624.4918299146723,"cash_change_usd":-1082.7638299146724,"cash_balance_usd":0.6921700853270067,"cumulative_obligation_reserve_usd":0.0,"operating_reserve_target_usd":4963.0048148293445,"available_generated_surplus_usd":0,"gross_pending_receivables_usd":364.419,"candidate_admitted":false,"construction_spend_usd":0},{"assumed_price_usd":1,"scenario":"reference","configuration":"original_upkeep","month":5,"requested_attempts":1000,"funded_attempts":0,"modeled_accepted":0.0,"suspended":true,"booked_revenue_usd":0.0,"collected_cash_usd":346.19804999999997,"refunds_usd":10.3859415,"payment_fees_usd":114.24535649999999,"modeled_bad_debt_written_off_usd":18.220950000000016,"recurring_cash_expenses_usd":0,"cash_change_usd":221.56675199999998,"cash_balance_usd":222.258922085327,"cumulative_obligation_reserve_usd":55.391687999999995,"operating_reserve_target_usd":4963.0048148293445,"available_generated_surplus_usd":0,"gross_pending_receivables_usd":0.0,"candidate_admitted":false,"construction_spend_usd":0},{"assumed_price_usd":1,"scenario":"reference","configuration":"original_upkeep","month":6,"requested_attempts":1000,"funded_attempts":0,"modeled_accepted":0.0,"suspended":true,"booked_revenue_usd":0.0,"collected_cash_usd":0.0,"refunds_usd":0.0,"payment_fees_usd":0.0,"modeled_bad_debt_written_off_usd":0.0,"recurring_cash_expenses_usd":0,"cash_change_usd":0.0,"cash_balance_usd":222.258922085327,"cumulative_obligation_reserve_usd":55.391687999999995,"operating_reserve_target_usd":4963.0048148293445,"available_generated_surplus_usd":0,"gross_pending_receivables_usd":0.0,"candidate_admitted":false,"construction_spend_usd":0},{"assumed_price_usd":1,"scenario":"reference","configuration":"original_upkeep","month":7,"requested_attempts":1000,"funded_attempts":0,"modeled_accepted":0.0,"suspended":true,"booked_revenue_usd":0.0,"collected_cash_usd":0.0,"refunds_usd":0.0,"payment_fees_usd":0.0,"modeled_bad_debt_written_off_usd":0.0,"recurring_cash_expenses_usd":0,"cash_change_usd":0.0,"cash_balance_usd":222.258922085327,"cumulative_obligation_reserve_usd":55.391687999999995,"operating_reserve_target_usd":4963.0048148293445,"available_generated_surplus_usd":0,"gross_pending_receivables_usd":0.0,"candidate_admitted":false,"construction_spend_usd":0},{"assumed_price_usd":1,"scenario":"reference","configuration":"original_upkeep","month":8,"requested_attempts":1000,"funded_attempts":0,"modeled_accepted":0.0,"suspended":true,"booked_revenue_usd":0.0,"collected_cash_usd":0.0,"refunds_usd":0.0,"payment_fees_usd":0.0,"modeled_bad_debt_written_off_usd":0.0,"recurring_cash_expenses_usd":0,"cash_change_usd":0.0,"cash_balance_usd":222.258922085327,"cumulative_obligation_reserve_usd":55.391687999999995,"operating_reserve_target_usd":4963.0048148293445,"available_generated_surplus_usd":0,"gross_pending_receivables_usd":0.0,"candidate_admitted":false,"construction_spend_usd":0},{"assumed_price_usd":1,"scenario":"reference","configuration":"original_upkeep","month":9,"requested_attempts":1000,"funded_attempts":0,"modeled_accepted":0.0,"suspended":true,"booked_revenue_usd":0.0,"collected_cash_usd":0.0,"refunds_usd":0.0,"payment_fees_usd":0.0,"modeled_bad_debt_written_off_usd":0.0,"recurring_cash_expenses_usd":0,"cash_change_usd":0.0,"cash_balance_usd":222.258922085327,"cumulative_obligation_reserve_usd":55.391687999999995,"operating_reserve_target_usd":4963.0048148293445,"available_generated_surplus_usd":0,"gross_pending_receivables_usd":0.0,"candidate_admitted":false,"construction_spend_usd":0},{"assumed_price_usd":1,"scenario":"reference","configuration":"original_upkeep","month":10,"requested_attempts":1000,"funded_attempts":0,"modeled_accepted":0.0,"suspended":true,"booked_revenue_usd":0.0,"collected_cash_usd":0.0,"refunds_usd":0.0,"payment_fees_usd":0.0,"modeled_bad_debt_written_off_usd":0.0,"recurring_cash_expenses_usd":0,"cash_change_usd":0.0,"cash_balance_usd":222.258922085327,"cumulative_obligation_reserve_usd":55.391687999999995,"operating_reserve_target_usd":4963.0048148293445,"available_generated_surplus_usd":0,"gross_pending_receivables_usd":0.0,"candidate_admitted":false,"construction_spend_usd":0},{"assumed_price_usd":1,"scenario":"reference","configuration":"original_upkeep","month":11,"requested_attempts":1000,"funded_attempts":0,"modeled_accepted":0.0,"suspended":true,"booked_revenue_usd":0.0,"collected_cash_usd":0.0,"refunds_usd":0.0,"payment_fees_usd":0.0,"modeled_bad_debt_written_off_usd":0.0,"recurring_cash_expenses_usd":0,"cash_change_usd":0.0,"cash_balance_usd":222.258922085327,"cumulative_obligation_reserve_usd":55.391687999999995,"operating_reserve_target_usd":4963.0048148293445,"available_generated_surplus_usd":0,"gross_pending_receivables_usd":0.0,"candidate_admitted":false,"construction_spend_usd":0},{"assumed_price_usd":1,"scenario":"reference","configuration":"original_upkeep","month":12,"requested_attempts":1000,"funded_attempts":0,"modeled_accepted":0.0,"suspended":true,"booked_revenue_usd":0.0,"collected_cash_usd":0.0,"refunds_usd":0.0,"payment_fees_usd":0.0,"modeled_bad_debt_written_off_usd":0.0,"recurring_cash_expenses_usd":0,"cash_change_usd":0.0,"cash_balance_usd":222.258922085327,"cumulative_obligation_reserve_usd":55.391687999999995,"operating_reserve_target_usd":4963.0048148293445,"available_generated_surplus_usd":0,"gross_pending_receivables_usd":0.0,"candidate_admitted":false,"construction_spend_usd":0},{"assumed_price_usd":5,"scenario":"reference","configuration":"original_upkeep","month":0,"requested_attempts":0,"funded_attempts":0,"modeled_accepted":0,"suspended":false,"booked_revenue_usd":0,"collected_cash_usd":0,"refunds_usd":0,"payment_fees_usd":0,"modeled_bad_debt_written_off_usd":0,"recurring_cash_expenses_usd":0,"cash_change_usd":0,"cash_balance_usd":7444.507222244016,"cumulative_obligation_reserve_usd":0,"operating_reserve_target_usd":4963.0048148293445,"available_generated_surplus_usd":0,"gross_pending_receivables_usd":0,"candidate_admitted":false,"construction_spend_usd":0},{"assumed_price_usd":5,"scenario":"reference","configuration":"original_upkeep","month":1,"requested_attempts":1000,"funded_attempts":1000,"modeled_accepted":891.0,"suspended":false,"booked_revenue_usd":4455.0,"collected_cash_usd":0.0,"refunds_usd":0.0,"payment_fees_usd":0.0,"modeled_bad_debt_written_off_usd":0.0,"recurring_cash_expenses_usd":2481.5024074146722,"cash_change_usd":-2481.5024074146722,"cash_balance_usd":4963.004814829344,"cumulative_obligation_reserve_usd":0.0,"operating_reserve_target_usd":4963.0048148293445,"available_generated_surplus_usd":0,"gross_pending_receivables_usd":4455.0,"candidate_admitted":false,"construction_spend_usd":0},{"assumed_price_usd":5,"scenario":"reference","configuration":"original_upkeep","month":2,"requested_attempts":1000,"funded_attempts":1000,"modeled_accepted":891.0,"suspended":false,"booked_revenue_usd":4455.0,"collected_cash_usd":4232.25,"refunds_usd":126.9675,"payment_fees_usd":380.9025,"modeled_bad_debt_written_off_usd":222.75,"recurring_cash_expenses_usd":2481.5024074146722,"cash_change_usd":1242.8775925853279,"cash_balance_usd":6205.882407414671,"cumulative_obligation_reserve_usd":310.71939814633197,"operating_reserve_target_usd":4963.0048148293445,"available_generated_surplus_usd":0,"gross_pending_receivables_usd":4455.0,"candidate_admitted":false,"construction_spend_usd":0},{"assumed_price_usd":5,"scenario":"reference","configuration":"original_upkeep","month":3,"requested_attempts":1000,"funded_attempts":1000,"modeled_accepted":891.0,"suspended":false,"booked_revenue_usd":4455.0,"collected_cash_usd":4232.25,"refunds_usd":126.9675,"payment_fees_usd":380.9025,"modeled_bad_debt_written_off_usd":222.75,"recurring_cash_expenses_usd":2481.5024074146722,"cash_change_usd":1242.8775925853279,"cash_balance_usd":7448.759999999999,"cumulative_obligation_reserve_usd":621.4387962926639,"operating_reserve_target_usd":4963.0048148293445,"available_generated_surplus_usd":0,"gross_pending_receivables_usd":4455.0,"candidate_admitted":false,"construction_spend_usd":0},{"assumed_price_usd":5,"scenario":"reference","configuration":"original_upkeep","month":4,"requested_attempts":1000,"funded_attempts":1000,"modeled_accepted":891.0,"suspended":false,"booked_revenue_usd":4455.0,"collected_cash_usd":4232.25,"refunds_usd":126.9675,"payment_fees_usd":380.9025,"modeled_bad_debt_written_off_usd":222.75,"recurring_cash_expenses_usd":2481.5024074146722,"cash_change_usd":1242.8775925853279,"cash_balance_usd":8691.637592585328,"cumulative_obligation_reserve_usd":932.1581944389959,"operating_reserve_target_usd":4963.0048148293445,"available_generated_surplus_usd":0,"gross_pending_receivables_usd":4455.0,"candidate_admitted":false,"construction_spend_usd":0},{"assumed_price_usd":5,"scenario":"reference","configuration":"original_upkeep","month":5,"requested_attempts":1000,"funded_attempts":1000,"modeled_accepted":891.0,"suspended":false,"booked_revenue_usd":4455.0,"collected_cash_usd":4232.25,"refunds_usd":126.9675,"payment_fees_usd":380.9025,"modeled_bad_debt_written_off_usd":222.75,"recurring_cash_expenses_usd":2481.5024074146722,"cash_change_usd":1242.8775925853279,"cash_balance_usd":9934.515185170658,"cumulative_obligation_reserve_usd":1242.8775925853279,"operating_reserve_target_usd":4963.0048148293445,"available_generated_surplus_usd":0,"gross_pending_receivables_usd":4455.0,"candidate_admitted":false,"construction_spend_usd":0},{"assumed_price_usd":5,"scenario":"reference","configuration":"original_upkeep","month":6,"requested_attempts":1000,"funded_attempts":1000,"modeled_accepted":891.0,"suspended":false,"booked_revenue_usd":4455.0,"collected_cash_usd":4232.25,"refunds_usd":126.9675,"payment_fees_usd":380.9025,"modeled_bad_debt_written_off_usd":222.75,"recurring_cash_expenses_usd":2481.5024074146722,"cash_change_usd":1242.8775925853279,"cash_balance_usd":11177.392777755987,"cumulative_obligation_reserve_usd":1553.5969907316598,"operating_reserve_target_usd":4963.0048148293445,"available_generated_surplus_usd":0,"gross_pending_receivables_usd":4455.0,"candidate_admitted":false,"construction_spend_usd":0},{"assumed_price_usd":5,"scenario":"reference","configuration":"original_upkeep","month":7,"requested_attempts":1000,"funded_attempts":1000,"modeled_accepted":891.0,"suspended":false,"booked_revenue_usd":4455.0,"collected_cash_usd":4232.25,"refunds_usd":126.9675,"payment_fees_usd":380.9025,"modeled_bad_debt_written_off_usd":222.75,"recurring_cash_expenses_usd":2481.5024074146722,"cash_change_usd":1242.8775925853279,"cash_balance_usd":12420.270370341317,"cumulative_obligation_reserve_usd":1864.3163888779918,"operating_reserve_target_usd":4963.0048148293445,"available_generated_surplus_usd":0,"gross_pending_receivables_usd":4455.0,"candidate_admitted":false,"construction_spend_usd":0},{"assumed_price_usd":5,"scenario":"reference","configuration":"original_upkeep","month":8,"requested_attempts":1000,"funded_attempts":1000,"modeled_accepted":891.0,"suspended":false,"booked_revenue_usd":4455.0,"collected_cash_usd":4232.25,"refunds_usd":126.9675,"payment_fees_usd":380.9025,"modeled_bad_debt_written_off_usd":222.75,"recurring_cash_expenses_usd":2481.5024074146722,"cash_change_usd":1242.8775925853279,"cash_balance_usd":13663.147962926647,"cumulative_obligation_reserve_usd":2175.035787024324,"operating_reserve_target_usd":4963.0048148293445,"available_generated_surplus_usd":0,"gross_pending_receivables_usd":4455.0,"candidate_admitted":false,"construction_spend_usd":0},{"assumed_price_usd":5,"scenario":"reference","configuration":"original_upkeep","month":9,"requested_attempts":1000,"funded_attempts":1000,"modeled_accepted":891.0,"suspended":false,"booked_revenue_usd":4455.0,"collected_cash_usd":4232.25,"refunds_usd":126.9675,"payment_fees_usd":380.9025,"modeled_bad_debt_written_off_usd":222.75,"recurring_cash_expenses_usd":2481.5024074146722,"cash_change_usd":1242.8775925853279,"cash_balance_usd":14906.025555511977,"cumulative_obligation_reserve_usd":2485.7551851706557,"operating_reserve_target_usd":4963.0048148293445,"available_generated_surplus_usd":0,"gross_pending_receivables_usd":4455.0,"candidate_admitted":false,"construction_spend_usd":0},{"assumed_price_usd":5,"scenario":"reference","configuration":"original_upkeep","month":10,"requested_attempts":1000,"funded_attempts":1000,"modeled_accepted":891.0,"suspended":false,"booked_revenue_usd":4455.0,"collected_cash_usd":4232.25,"refunds_usd":126.9675,"payment_fees_usd":380.9025,"modeled_bad_debt_written_off_usd":222.75,"recurring_cash_expenses_usd":2481.5024074146722,"cash_change_usd":1242.8775925853279,"cash_balance_usd":16148.903148097306,"cumulative_obligation_reserve_usd":2796.4745833169877,"operating_reserve_target_usd":4963.0048148293445,"available_generated_surplus_usd":0,"gross_pending_receivables_usd":4455.0,"candidate_admitted":false,"construction_spend_usd":0},{"assumed_price_usd":5,"scenario":"reference","configuration":"original_upkeep","month":11,"requested_attempts":1000,"funded_attempts":1000,"modeled_accepted":891.0,"suspended":false,"booked_revenue_usd":4455.0,"collected_cash_usd":4232.25,"refunds_usd":126.9675,"payment_fees_usd":380.9025,"modeled_bad_debt_written_off_usd":222.75,"recurring_cash_expenses_usd":2481.5024074146722,"cash_change_usd":1242.8775925853279,"cash_balance_usd":17391.780740682636,"cumulative_obligation_reserve_usd":3107.1939814633197,"operating_reserve_target_usd":4963.0048148293445,"available_generated_surplus_usd":791.7754804825445,"gross_pending_receivables_usd":4455.0,"candidate_admitted":false,"construction_spend_usd":0},{"assumed_price_usd":5,"scenario":"reference","configuration":"original_upkeep","month":12,"requested_attempts":1000,"funded_attempts":1000,"modeled_accepted":891.0,"suspended":false,"booked_revenue_usd":4455.0,"collected_cash_usd":4232.25,"refunds_usd":126.9675,"payment_fees_usd":380.9025,"modeled_bad_debt_written_off_usd":222.75,"recurring_cash_expenses_usd":2481.5024074146722,"cash_change_usd":1242.8775925853279,"cash_balance_usd":18634.658333267966,"cumulative_obligation_reserve_usd":3417.9133796096517,"operating_reserve_target_usd":4963.0048148293445,"available_generated_surplus_usd":1723.9336749215404,"gross_pending_receivables_usd":4455.0,"candidate_admitted":false,"construction_spend_usd":0}],"cash_metadata":[{"scenario":"reference","route":"modeled_model_extension","attempts_per_month_target":1000,"assumed_price_usd":1,"status":"CASH_CONSTRAINED_SIMULATION_NO_PAYMENTS_OBSERVED","initial_external_endowment_usd":13492.811278736757,"setup_cash_outflow_at_month_zero_usd":6048.304056492741,"variable_cost_per_funded_attempt_usd":1.4501025,"fixed_commitment_if_operating_month_usd":1031.3999074146723,"limits":"Expected-state affordability, not a tail-risk guarantee. Future month commitments assumed suspendible; no credit, new borrowing or hidden negative cash is allowed."},{"scenario":"reference","route":"modeled_model_extension","attempts_per_month_target":1000,"assumed_price_usd":5,"status":"CASH_CONSTRAINED_SIMULATION_NO_PAYMENTS_OBSERVED","initial_external_endowment_usd":13492.811278736757,"setup_cash_outflow_at_month_zero_usd":6048.304056492741,"variable_cost_per_funded_attempt_usd":1.4501025,"fixed_commitment_if_operating_month_usd":1031.3999074146723,"limits":"Expected-state affordability, not a tail-risk guarantee. Future month commitments assumed suspendible; no credit, new borrowing or hidden negative cash is allowed."}],"price_grid_usd":[1,5,15,50],"attempt_volume_grid":[100,1000,10000],"rates_sources":[{"id":"BLS_OEWS_2025","title":"National employment and wage data by occupation, May 2025","publisher":"US Bureau of Labor Statistics","url":"https://www.bls.gov/news.release/ocwage.t01.htm","ref_ids":["turn3view1","turn4view0","turn4view1","turn4view2","turn4view3"],"data_period":"May 2025","publication_date":"2026-05-15","geography":"United States","currency":"USD","methodology":"OEWS establishment survey; employment counts include full-time and part-time wage/salary jobs, exclude self-employed; wage rates exclude nonwage employer benefits. Annual wages use 2,080-hour full-time year.","ai_usage_established":false,"task_duration_established":false},{"id":"BLS_ECEC_2026Q2","title":"Employer costs for employee compensation, private industry by occupational group, June 2026","publisher":"US Bureau of Labor Statistics","url":"https://www.bls.gov/news.release/ecec.t04.htm","ref_ids":["turn3view2"],"data_period":"June 2026","publication_date":"2026-09-09","geography":"United States, private industry","currency":"USD","methodology":"National Compensation Survey, employer costs per hour worked; total includes wages and salaries, paid leave, supplemental pay, insurance, retirement, legally required benefits. Multipliers applied to narrower OEWS occupations are approximations and do not include office overhead.","ai_usage_established":false,"task_duration_established":false},{"id":"OPENAI_SOL_20261025","title":"GPT-6.1 Sol model pricing","publisher":"OpenAI","url":"https://developers.openai.com/api/docs/models/gpt-6.1-sol","ref_ids":["turn11view0","turn12view0"],"data_period":"Retrieved 2026-10-25","currency":"USD","methodology":"Published standard short-context API rates. No paid provider calls executed by this study. Prices are not usage or success measurements.","input_usd_per_million_tokens":2,"output_usd_per_million_tokens":10,"cached_input_usd_per_million_tokens":0.1,"short_context_max_input_tokens":272000},{"id":"OPENAI_TOOLS_20261025","title":"OpenAI API pricing, tools and model tariffs","publisher":"OpenAI","url":"https://developers.openai.com/api/docs/pricing","ref_ids":["turn11view1","turn12view1","turn12view2"],"data_period":"Retrieved 2026-10-25","currency":"USD","web_search_usd_per_call":0.01,"hosted_container_1gb_usd_per_20min_session":0.03,"file_search_storage_usd_per_gb_day":0.1,"methodology":"Search content input tokens are also billed. Hosted containers are a scenario route, not a claim that local research execution incurred these charges. Free allowances are not used to infer scalable zero cost."}],"limits":["Unknown actual costs are not zero.","Production acceptance is assumed, not inferred from fixtures.","Payment delay means expected economic contribution is not available monthly cash.","Customer savings require equivalent work, quality, revision and acceptance responsibilities.","Automatic-upkeep output is portfolio-level; do not substitute it into the quote-only row.","No simulated margin or funding result establishes a customer payment or capability promotion."]},"capability":{"manifest":{"capability_id":"awe-fixed-shipping-quote-v2","version":2,"source":"quote-v2.mjs","source_sha256":"d2d33a7e2e7e84b397c7a02ecf5c2511240c262c4a9b11a7294ac4612d2b8ca8","parent":{"id":"awe-fixed-shipping-quote-v1","source_sha256":"4e0907f314dd0addae455f4b52e2c65f109898846016e1e386e844974986e8d9"},"dependencies":[{"path":"../adapters.mjs","sha256":"db6750be9f6147d9af663a2d7dae0dde448be367dcae18aa53ccdf3a79b49f74"}],"applicability":{"data":"permitted public/licensed nonpersonal or synthetic","items_max":18,"vendors_max":12,"offer_limit":160,"price_model":"One selected offer per item; ceil quantity/pack; integer minor units; supplied rational currency ratio; once-per-used-vendor fixed shipping; no split sourcing/tax/discount/availability inference"},"verification":["Q1-Q4 exact independent MILP total agreement","Twelve bounded injection checks in main study, not universal defect coverage","Shipping-externality regression rejects greedy candidate"],"construction":{"observed":"Template file emission and invocation only","original_kernel_authoring_cost_usd":null,"original_model_usage":null},"rollback":"Use retained v1 for its narrower scope or independent conventional MILP; archive v2 capsule without deleting predecessor.","production_economic_admission":"HOLD","permission_authority":[],"settlement":"NOT_CONNECTED","automated_discovery":"NOT_RUN"},"events":{"protocol_sha256":"59a2e71b5674414fd7745674ec6c15573ea0fb451df699697dc74db429f7976a","events":[{"stage":"construct-v1","method":"Emit static audited allowlist template","wall_ms":0.24667399999999873,"cpu_us":211,"source_sha256":"4e0907f314dd0addae455f4b52e2c65f109898846016e1e386e844974986e8d9","model_calls":0,"kernel_authoring_cost_usd":null},{"stage":"useful-development-result","input":"inputs/development-quote.json","total_minor":119734,"wall_ms":0.6894380000000027,"capability":"quote-v1.mjs"},{"stage":"fresh-mission-actual-reuse","task_id":"Q1","total_minor":142509,"wall_ms":0.20846700000000595,"capability":"quote-v1.mjs"},{"stage":"challenger-rejects-candidate","candidate":"rejected-greedy.mjs","observed_total_minor":2200,"feasible_counterexample_minor":1300,"decision":"REJECT","retained_regression":"shipping-regression-input.json","reason":"Selecting each cheapest line independently can incur multiple fixed supplier charges."},{"stage":"changed-requirement","task_id":"Q2","old_capability_result":"V1_SCOPE_PACK_OR_CURRENCY","requirement":"Pack quantities and explicit nonidentity currency ratios"},{"stage":"bounded-successor-construction","method":"Compose preexisting audited normalizer and exact vendor-subset specialist using allowlisted capsule template","wall_ms":0.3935109999999966,"cpu_us":315,"source_sha256":"d2d33a7e2e7e84b397c7a02ecf5c2511240c262c4a9b11a7294ac4612d2b8ca8","model_calls":0,"kernel_authoring_cost_usd":null,"discovery":"No new algorithm discovered"},{"stage":"fresh-successor-use","task_id":"Q2","total_minor":52012,"wall_ms":0.6439409999999981,"capability":"quote-v2.mjs","states":15,"conventional_MILP":"AVAILABLE_AND_RETAINED"},{"stage":"fresh-successor-use","task_id":"Q4","total_minor":263590,"wall_ms":2.4829849999999993,"capability":"quote-v2.mjs","states":15,"conventional_MILP":"AVAILABLE_AND_RETAINED"}],"claim":"Observed bounded executable retention, fresh reuse and template-based successor composition. Not autonomous research discovery, commercial self-financing or self-acceleration."},"independent_audit":{"checks":[{"name":"v2_source_hash","passed":true},{"name":"v1_source_hash","passed":true},{"name":"Q2-independent-MILP","passed":true,"total_minor":52012},{"name":"Q4-independent-MILP","passed":true,"total_minor":263590},{"name":"shipping-regression-MILP","passed":true,"incumbent_total_minor":1300,"rejected_candidate_minor":2200}],"passed":5,"total":5,"independence":"Conventional independently implemented solver; same research team."}},"transfer_extension":{"study_id":"AWE-2026-01","extension_id":"AWE-TRANSFER-02","reporting_amendment":"v1.1","checked_utc":"2026-10-25T16:19:55.329087+00:00","status":"EXECUTED_LOCAL_ONLY","records":[{"id":"T1","input_sha256":"8ddbddd13d50e5df057789c3381c347f89820907d0babc6026381a548939ea42","accepted":true,"total_minor":527567,"parent_status":"SUPPORTED","parent_total_minor":527567,"independent_milp":{"total_minor":527567,"solver":"SciPy HiGHS MILP","status":0,"mip_gap":0.0,"nodes":0},"contract_checks":{"total_minor":527567,"solver":"SciPy HiGHS MILP","status":0,"mip_gap":0.0,"nodes":0},"wall_ms":53.641203000000004,"provider_calls":0,"actual_full_cost_usd":null},{"id":"T2","input_sha256":"3e655e285366f25daa1eebb4e8ac0fc15555a73d6fdc8fc9a7bb9558d32594c4","accepted":true,"total_minor":375298,"parent_status":"SUPPORTED","parent_total_minor":375298,"independent_milp":{"total_minor":375298,"solver":"SciPy HiGHS MILP","status":0,"mip_gap":0.0,"nodes":0},"contract_checks":{"total_minor":375298,"solver":"SciPy HiGHS MILP","status":0,"mip_gap":0.0,"nodes":0},"wall_ms":53.12160800000001,"provider_calls":0,"actual_full_cost_usd":null},{"id":"T3","input_sha256":"c44613d5c82f10e3d76e80e66ba55a9c5ddf4a68a2dae85a871db1ed6b999233","accepted":true,"total_minor":1491817,"parent_status":"V1_COMBINATION_BUDGET","parent_total_minor":null,"independent_milp":{"total_minor":1491817,"solver":"SciPy HiGHS MILP","status":0,"mip_gap":0.0,"nodes":1},"contract_checks":{"total_minor":1491817,"solver":"SciPy HiGHS MILP","status":0,"mip_gap":0.0,"nodes":1},"wall_ms":143.73804499999997,"provider_calls":0,"actual_full_cost_usd":null},{"id":"T4","input_sha256":"e2de04da01b1a98e9bc463d700ec197a27812f4275ccf418893e3148f5ecb3a0","accepted":true,"total_minor":1441037,"parent_status":"V1_COMBINATION_BUDGET","parent_total_minor":null,"independent_milp":{"total_minor":1441037,"solver":"SciPy HiGHS MILP","status":0,"mip_gap":0.0,"nodes":1},"contract_checks":{"total_minor":1441037,"solver":"SciPy HiGHS MILP","status":0,"mip_gap":0.0,"nodes":1},"wall_ms":68.96824299999997,"provider_calls":0,"actual_full_cost_usd":null},{"id":"T5","input_sha256":"010c8e3b98d4be057b3f8e0115286c1d45552dff03e244fe8f68faa089987583","accepted":true,"total_minor":154698,"parent_status":"V1_SCOPE_PACK_OR_CURRENCY","parent_total_minor":null,"independent_milp":{"total_minor":154698,"solver":"SciPy HiGHS MILP","status":0,"mip_gap":0.0,"nodes":0},"contract_checks":{"total_minor":154698,"solver":"SciPy HiGHS MILP","status":0,"mip_gap":0.0,"nodes":0},"wall_ms":45.350270999999964,"provider_calls":0,"actual_full_cost_usd":null},{"id":"T6","input_sha256":"2be034c841d4b8681c6d3f033eb20c6db149d7512ea9404f98963b5fc8c4e0a4","accepted":true,"total_minor":272594,"parent_status":"V1_SCOPE_PACK_OR_CURRENCY","parent_total_minor":null,"independent_milp":{"total_minor":272594,"solver":"SciPy HiGHS MILP","status":0,"mip_gap":0.0,"nodes":0},"contract_checks":{"total_minor":272594,"solver":"SciPy HiGHS MILP","status":0,"mip_gap":0.0,"nodes":0},"wall_ms":63.25159000000002,"provider_calls":0,"actual_full_cost_usd":null},{"id":"T7","input_sha256":"42af972cb671fcf2db3d51e595058558593a6ea41f096a281d0e4fea8d9edb56","accepted":true,"total_minor":377911,"parent_status":"V1_SCOPE_PACK_OR_CURRENCY","parent_total_minor":null,"independent_milp":{"total_minor":377911,"solver":"SciPy HiGHS MILP","status":0,"mip_gap":0.0,"nodes":0},"contract_checks":{"total_minor":377911,"solver":"SciPy HiGHS MILP","status":0,"mip_gap":0.0,"nodes":0},"wall_ms":61.43212900000003,"provider_calls":0,"actual_full_cost_usd":null},{"id":"T8","input_sha256":"353164e03bbacecfebd5cd95ed4cde2a829310c3697fabd7c1a4899284532214","accepted":true,"total_minor":557427,"parent_status":"V1_SCOPE_PACK_OR_CURRENCY","parent_total_minor":null,"independent_milp":{"total_minor":557427,"solver":"SciPy HiGHS MILP","status":0,"mip_gap":0.0,"nodes":0},"contract_checks":{"total_minor":557427,"solver":"SciPy HiGHS MILP","status":0,"mip_gap":0.0,"nodes":0},"wall_ms":54.434420000000046,"provider_calls":0,"actual_full_cost_usd":null}],"cases":8,"accepted":8,"parent_supported":2,"parent_scope_or_budget_refusals":6,"unexpected_workflow_failures":0,"original_reporting_failures":1,"freeze_sha256":"23a56221e66aec4ebf8194264beae58c37d9fa00b62d9e56cd24da2d6c10cec6","claim":"Newly generated inputs after capsule/extension-source freeze. Existing conventional MILP remains capable. No algorithm discovery, economic promotion, new job-family breadth or self-financing evidence."}};
const $=id=>document.getElementById(id);
const english=Object.fromEntries([...document.querySelectorAll('[data-i18n]')].map(el=>[el.dataset.i18n,el.innerHTML]));
const french={skip:'Aller à la démonstration',offline:'Exécution sur votre appareil',eyebrow:'L’ÉCONOMIE DU TRAVAIL AUTONOME',hero1:'Un résultat utile.',hero2:'Une meilleure suite.',heroText:'Choisissez un panier complet d’équipement. Vérifiez chaque calcul. Gardez une méthode réutilisable pour la prochaine tâche.',try:'Essayer',stop:'Arrêter',useOwn:'Utiliser mes devis',firstPromise:'Sans compte. Sans clé. Sans paiement. Aucun achat effectué.',firstMission:'VOTRE PREMIER RÉSULTAT UTILE',example:'EXEMPLE',previewTitle:'Un panier.<br>Des choix transparents.',previewText:'Comparez fournisseurs, lots, taux de change et délais dans une recommandation complète.',monitor:'Écrans',keyboard:'Claviers',moreItems:'Autres articles',requestedItems:'articles demandés',offers:'offres',suppliers:'fournisseurs',syntheticNotice:'Les prix, fournisseurs et taux inclus sont des exemples synthétiques.',ready:'À votre rythme. Le calcul se fait ici, sur votre appareil.',fresh:'NOUVEAU CALCUL LOCAL',resultTitle:'Votre comparaison, prête à vérifier.',verified:'Critères déclarés vérifiés',basketTotal:'Panier recommandé',goodsNotService:'Il s’agit du prix des articles de l’exemple, et non du coût d’exécution d’AGI ALPHA.',quantityCheck:'Quantités demandées couvertes',deadlineCheck:'Contrainte de livraison respectée',solverCheck:'Recherche complète des sous-ensembles de fournisseurs',localCostUnknown:'Coût réel complet : inconnu',selectedCart:'Le panier sélectionné',item:'Article',supplier:'Fournisseur',required:'Demandé',delivered:'Livré',packs:'Lots',lineCost:'Coût de la ligne',days:'Jours',takeResult:'Emportez votre résultat',downloadCsv:'Télécharger le CSV',downloadReport:'Télécharger le rapport',downloadEvidence:'Exporter les preuves',yourInputs:'VOS DONNÉES AUTORISÉES',inputTitle:'Comparez vos propres devis.',inputIntro:'Collez une offre par ligne. Utilisez des données publiques, synthétiques ou non personnelles sous licence. Tout reste sur cet appareil.',basketName:'Nom du panier',deliveryLimit:'Délai maximal en jours',quoteCsv:'Devis au format CSV',csvLimit:'Jusqu’à 18 articles, 12 fournisseurs et 160 offres',formatHelp:'Format CSV et exemple court',formatText:'Les prix et frais de livraison utilisent des montants décimaux. La livraison est un montant fixe par fournisseur, en USD. fx_to_usd est le taux explicite vers l’USD; utilisez 1 pour l’USD. Les quantités d’un article, frais d’un fournisseur et taux d’une devise répétés doivent être identiques.',boundaryText:'Le calcul exclut les taxes, remises, stocks incertains, différences de qualité et achats fractionnés. Seules les données déclarées sont évaluées.',permission:'Je suis autorisé à utiliser ces devis non personnels et les taux indiqués.',compareQuotes:'Comparer ces devis',openCsv:'Ouvrir un fichier CSV',restoreExample:'Rétablir l’exemple',retainedEyebrow:'CE QUE LA PROCHAINE TÂCHE PEUT RÉUTILISER',capabilityTitle:'Gardez la méthode. Réutilisez-la.',scopeLabel:'CAPACITÉ DÉLIMITÉE',capabilityIntro:'L’actif utile est une procédure exécutable : normaliser les quantités, respecter les contraintes et comparer des paniers complets.',cap1title:'Un résultat à conserver',cap1text:'Un panier clair, des calculs vérifiables et des preuves exportables. La tâche actuelle produit un résultat utilisable.',cap1foot:'Résultat utile + provenance',cap2title:'Une procédure réutilisable',cap2text:'Le même adaptateur vérifié traite de nouvelles données. Lots, taux fournis et frais fixes restent explicites.',cap2foot:'Méthode exécutable + portée + retour arrière',cap3title:'Une mission plus grande',cap3text:'Réutilisez la méthode sur 14 articles et 56 offres. Il s’agit d’un nouveau calcul local sur un autre exemple figé.',nextMission:'Exécuter la mission suivante',recordedTitle:'Examiner la construction et le rejet enregistrés',recorded:'ÉTUDE ENREGISTRÉE',recordedText:'L’étude a conservé une première procédure délimitée, l’a réutilisée sur de nouvelles données, puis a observé son refus face à de nouveaux besoins de lots et de devises. Un successeur a ensuite été assemblé à partir d’outils audités existants et testé sur de nouvelles tâches. Cette composition utilisait des modèles de code bornés; la découverte autonome n’a pas été exécutée.',rejectedGreedy:'Rejeté : choisir chaque ligne la moins chère',validBasket:'Panier valide : inclure la livraison',recordedLimits:'Le candidat rejeté reste dans les preuves. Un solveur MILP conventionnel a aussi résolu les grandes missions et reste disponible. Le coût initial des outils est inconnu; leur promotion en production reste suspendue.',exportCapability:'Exporter les preuves de capacité enregistrées',economicsEyebrow:'DES HYPOTHÈSES ÉCONOMIQUES À EXAMINER',economicsTitle:'Changez les hypothèses.<br>Voyez la conclusion évoluer.',simulation:'SIMULATION · COÛT NON OBSERVÉ',economicsIntro:'L’exécution locale n’a ni facture mesurée ni coût complet établi. Ces scénarios distincts modélisent la livraison, les échecs, l’assistance, l’entretien et les coûts initiaux. Ils ne calculent pas le prix des équipements.',scenario:'Scénario opérationnel',efficient:'Efficace',reference:'Référence',stress:'Sous tension',volume:'Tâches du portefeuille par mois',deliveryRoute:'Mode de livraison hypothétique',routeTool:'Outil délimité hébergé',routeModel:'Extension avec modèles — NON EXÉCUTÉE',hypotheticalPrice:'Prix hypothétique du service · USD',humanMinutes:'Solution humaine · minutes',extraAttention:'Attention supplémentaire du client · minutes',deliveryEconomics:'ÉCONOMIE DE LIVRAISON MODÉLISÉE',fullCost:'Coût complet par résultat accepté',marginal:'Exécution marginale',recurring:'Livraison récurrente',collectedNet:'Recette nette encaissée attendue',contribution:'Contribution avant impôts, coût complet déduit',cashLimit:'La contribution n’est pas de la trésorerie disponible. Obligations, délais d’encaissement, fonds de roulement et réserves restent à considérer. Aucun paiement client n’a été observé.',customerView:'LA COMPARAISON DU CLIENT',humanAlternative:'Coût du travail humain',customerOutlay:'Prix du service + attention supplémentaire',qualityLimit:'La comparaison exige une portée et une qualité équivalentes. Aucun essai humain chronométré et apparié n’a été réalisé. Le prix est hypothétique; cette démo est gratuite.',equivalentScope:'Supposer une portée et une qualité équivalentes pour la comparaison humaine.',volumeBasis:'Le volume couvre quatre familles à 25 % chacune; les coûts fixes sont partagés.',allAssumptions:'Voir les hypothèses sélectionnées et le détail des coûts',upkeepLimit:'Ces résultats utilisent les hypothèses initiales d’entretien partagé. L’entretien automatisé est une sensibilité distincte, non exécutée, présentée dans l’article. Il n’est pas substitué ici. Prix, acceptation, exceptions et demande ne sont pas des observations de production.',exportEconomics:'Exporter le scénario et les calculs',advancedEvidence:'Preuves avancées, limites et reprise',observedTitle:'Ce qui a réellement été observé',observed1:'24 cas structurels : 16 résultats délimités acceptés et 8 refus attendus.',observed2:'4 optima de devis concordent avec un solveur conventionnel distinct.',observed3:'12 défauts injectés connus ont été détectés. Cela ne garantit pas l’exhaustivité.',observed4:'Exécution authentifiée de l’entreprise avec modèles/Harness/Fleet : NON EXÉCUTÉE.',boundariesTitle:'Autorisations et interprétation',boundary1:'Données publiques, synthétiques ou non personnelles sous licence uniquement.',boundary2:'Aucun compte, clé API, portefeuille, contrat ou mécanisme de jeton n’est utilisé.',boundary3:'L’intégrité des preuves locales est vérifiée; elles ne constituent pas une preuve indépendante authentifiée.',boundary4:'Aucune vente, autonomie financière ou auto-accélération observée n’est revendiquée.',importEvidence:'Importer un fichier de preuves JSON',importLimit:'L’import est un historique enregistré. Relancez ses données pour un nouveau calcul.',executionLog:'Journal d’exécution et identités des sources',sources:'Sources',researchEdition:'AWE-2026-01 · Édition de recherche',footer:'Des résultats utiles. Des méthodes vérifiables. Des conclusions méritées.'};
const messages={en:{running:'Comparing complete baskets and checking the result…',complete:'Your result is ready. The local calculation and evidence-integrity check completed.',stopped:'Stopped. You can run again. Any previous completed result remains clearly marked.',failed:'The comparison could not complete. Correct the stated input issue, then try again.',imported:'Evidence imported and integrity-checked. This is recorded history, not a fresh run or authenticated proof.',rerun:'Run again',previous:'PREVIOUS COMPLETED RESULT',importLabel:'IMPORTED RECORDED EXECUTION',daysMax:n=>`Up to ${n} days`,covered:n=>`${n} items covered`,states:n=>`${n.toLocaleString('en-US')} subsets`,elapsed:(ms,calls)=>`${ms.toFixed(1)} ms in this browser · ${calls} provider calls`,subtotal:(lines,ship)=>`${lines} in goods + ${ship} shipping`,cartContext:(items,offers)=>`${items} items · ${offers} eligible offers`,studyChecked:'The recorded study independently checked this exact example with a conventional MILP solver. This fresh run performs the local declared checks and pack-integrity check.',customChecked:'Your input was evaluated by the complete bounded solver and declared local checks. The separate conventional MILP was run on study examples, not on your custom input.',importChecked:'This imported result passed integrity inspection. It is unauthenticated historical evidence. Run its inputs again to obtain fresh computation.',excluded:n=>`${n} offer(s) excluded by the delivery deadline.`,rightsNeeded:'Confirm that you may use these nonpersonal quotes before running them.',invalidCsv:s=>`Please correct the CSV: ${s}`,invalidFile:'The file is too large or could not be read. CSV limit: 200 KB; evidence limit: 2 MB.',evidenceOnly:'Only a quote-comparison evidence pack can be displayed here.',restored:'The included example has been restored.',csvOpened:'CSV opened locally. Check the fields and permission statement, then compare.',formatError:(line,message)=>`row ${line}: ${message}`,csvHeader:'The header must match the documented ten-column format.',emptyCsv:'Add at least one offer.',inputTitle:'My equipment comparison',recordedTransfer:'Separate fresh-input transfer extension: 8/8 successor outcomes and 2/8 parent outcomes; the conventional MILP achieved 8/8. This is recorded evidence, not an economic promotion.',invalidEconomic:'Enter valid nonnegative durations and a service price from 0.01 to 1,000 USD.',acceptance:p=>`Assumed final acceptance ${p}`,collection:p=>`Collection ${p}`,refund:p=>`Refund ${p}`,costComponents:'Cost components / accepted output',assumptions:'Selected assumptions',customerSaving:v=>`Under these assumptions, the customer spends ${v} less.`,customerLoss:v=>`Under these assumptions, the customer spends ${v} more.`,wageNote:(w,h)=>`Human labor reference: ${w}/hour, US procurement-clerk median wage, May 2025; benefits excluded. Extra attention valued at the separate ${h}/hour compensation proxy. Neither source establishes task duration or worker AI usage.`,positiveMargin:'A positive modeled contribution could support obligations and reserves before any new construction. It does not demonstrate collected cash or self-financing.',negativeMargin:'No modeled full-cost surplus at this price. Increasing activity alone does not repair a negative per-output contribution.',routeNotRun:'Additional model-based intake and checking were NOT RUN. Their usage and acceptance are scenario inputs.',routeToolNote:'Hypothetical hosted delivery of this bounded tool. Actual local full cost remains unknown.',costFloor:'Modeled break-even service price',expectedVolume:'Expected accepted quote share / month',collectionDelay:'Collection delay · months',normalExceptions:'Normal exception probability × minutes',rareExceptions:'Rare exception probability × minutes',shock:'Correlated adverse-month probability',setup:'Shared setup hours',maintenance:'Shared upkeep hours / month',admin:'Shared administration hours / month',customerMinutes:'Extra customer attention · minutes',humanDuration:'Assumed human task duration · minutes',servicePrice:'Hypothetical service price · USD',fee:'Payment fee on collected invoices',frameNote:'UI checkpoints yield to the display to allow cancellation. Browser demo timing is not the frozen batch timing.',noNetwork:'No external network requests are made by this file.',sourceHash:'Demo source identity',runtimePin:'AGI ALPHA runtime commit',fullCost:'Actual local total cost: unknown',exportFailure:'There is no completed result to export yet.'},fr:{running:'Comparaison des paniers complets et vérification du résultat…',complete:'Votre résultat est prêt. Le calcul local et la vérification d’intégrité sont terminés.',stopped:'Arrêté. Vous pouvez relancer. Tout résultat précédent reste clairement indiqué.',failed:'La comparaison n’a pas abouti. Corrigez le problème indiqué, puis réessayez.',imported:'Preuves importées et intégrité vérifiée. Il s’agit d’un historique enregistré, pas d’un nouveau calcul ni d’une preuve authentifiée.',rerun:'Relancer',previous:'RÉSULTAT PRÉCÉDENT TERMINÉ',importLabel:'EXÉCUTION ENREGISTRÉE IMPORTÉE',daysMax:n=>`Au plus ${n} jours`,covered:n=>`${n} articles couverts`,states:n=>`${n.toLocaleString('fr-CA')} sous-ensembles`,elapsed:(ms,calls)=>`${ms.toFixed(1).replace('.',',')} ms dans ce navigateur · ${calls} appel de modèle`,subtotal:(lines,ship)=>`${lines} d’articles + ${ship} de livraison`,cartContext:(items,offers)=>`${items} articles · ${offers} offres admissibles`,studyChecked:'L’étude enregistrée a vérifié cet exemple exact avec un solveur MILP conventionnel distinct. Ce nouveau calcul exécute les contrôles locaux déclarés et la vérification d’intégrité.',customChecked:'Vos données ont été évaluées par le solveur borné complet et les contrôles locaux déclarés. Le solveur MILP distinct a été exécuté sur les exemples de l’étude, pas sur vos données.',importChecked:'L’intégrité de ce résultat importé est vérifiée. Il reste un historique non authentifié. Relancez ses données pour un nouveau calcul.',excluded:n=>`${n} offre(s) exclue(s) par le délai de livraison.`,rightsNeeded:'Confirmez votre autorisation d’utiliser ces devis non personnels avant de les traiter.',invalidCsv:s=>`Veuillez corriger le CSV : ${s}`,invalidFile:'Le fichier est trop volumineux ou illisible. Limite CSV : 200 ko; preuves : 2 Mo.',evidenceOnly:'Seul un dossier de comparaison de devis peut être affiché ici.',restored:'L’exemple inclus a été rétabli.',csvOpened:'CSV ouvert localement. Vérifiez les champs et l’autorisation, puis comparez.',formatError:(line,message)=>`ligne ${line} : ${message}`,csvHeader:'L’en-tête doit respecter le format documenté de dix colonnes.',emptyCsv:'Ajoutez au moins une offre.',inputTitle:'Ma comparaison d’équipement',recordedTransfer:'Extension distincte sur de nouvelles données : 8/8 résultats pour le successeur et 2/8 pour le parent; le MILP conventionnel obtient 8/8. Ce sont des preuves enregistrées, pas une promotion économique.',invalidEconomic:'Saisissez des durées valides et non négatives, et un prix de service de 0,01 à 1 000 USD.',acceptance:p=>`Acceptation finale supposée ${p}`,collection:p=>`Encaissement ${p}`,refund:p=>`Remboursement ${p}`,costComponents:'Composantes par résultat accepté',assumptions:'Hypothèses sélectionnées',customerSaving:v=>`Selon ces hypothèses, le client dépense ${v} de moins.`,customerLoss:v=>`Selon ces hypothèses, le client dépense ${v} de plus.`,wageNote:(w,h)=>`Référence humaine : ${w}/heure, salaire médian des commis aux achats aux États-Unis, mai 2025; avantages exclus. L’attention supplémentaire utilise un indicateur distinct de ${h}/heure. Ces sources n’établissent ni la durée de la tâche ni l’usage de l’IA.`,positiveMargin:'Une contribution modélisée positive pourrait soutenir obligations et réserves avant toute nouvelle construction. Elle ne démontre ni trésorerie encaissée ni autonomie financière.',negativeMargin:'Aucun surplus modélisé au coût complet à ce prix. Augmenter le volume ne corrige pas à lui seul une contribution négative par résultat.',routeNotRun:'L’intake et les vérifications supplémentaires avec modèles n’ont PAS ÉTÉ EXÉCUTÉS. Usage et acceptation restent des hypothèses.',routeToolNote:'Livraison hébergée hypothétique de cet outil délimité. Le coût local complet réel reste inconnu.',costFloor:'Prix de service d’équilibre modélisé',expectedVolume:'Devis acceptés attendus par mois',collectionDelay:'Délai d’encaissement · mois',normalExceptions:'Probabilité d’exception courante × minutes',rareExceptions:'Probabilité d’exception rare × minutes',shock:'Probabilité d’un mois adverse corrélé',setup:'Heures initiales partagées',maintenance:'Heures d’entretien partagé par mois',admin:'Heures d’administration partagée par mois',customerMinutes:'Attention supplémentaire du client · minutes',humanDuration:'Durée supposée de la tâche humaine · minutes',servicePrice:'Prix hypothétique du service · USD',fee:'Frais sur les factures encaissées',frameNote:'Les points de contrôle cèdent l’affichage pour permettre l’arrêt. Le temps de cette démo n’est pas celui du lot expérimental figé.',noNetwork:'Ce fichier n’effectue aucune requête réseau externe.',sourceHash:'Identité des sources de la démo',runtimePin:'Commit du runtime AGI ALPHA',fullCost:'Coût total local réel : inconnu',exportFailure:'Aucun résultat terminé à exporter.'}};
const componentLabels={en:{model_tokens:'Model usage',runtime:'Execution infrastructure',search:'Search',normal_exceptions:'Ordinary exceptions',rare_exceptions:'Rare exceptions',platform_archive:'Platform and archive',maintenance:'Shared upkeep',business_administration:'Shared administration',common_shock_recovery:'Correlated recovery',setup_amortization:'Setup allocation'},fr:{model_tokens:'Usage des modèles',runtime:'Infrastructure d’exécution',search:'Recherche',normal_exceptions:'Exceptions courantes',rare_exceptions:'Exceptions rares',platform_archive:'Plateforme et archives',maintenance:'Entretien partagé',business_administration:'Administration partagée',common_shock_recovery:'Reprise corrélée',setup_amortization:'Répartition initiale'}};
const itemFrench={'Monitor':'Écran','Dock':'Station d’accueil','Keyboard':'Clavier','Desk lamp':'Lampe de bureau','USB hub':'Concentrateur USB','Cable pack':'Lot de câbles','Webcam':'Webcam','Headset':'Casque','Stand':'Support','Adapter':'Adaptateur','Network switch':'Commutateur réseau','Storage drive':'Disque de stockage','Microphone':'Microphone','Router':'Routeur'};
const wb=createWorkbench([quoteAdapter,briefAdapter,planningAdapter]);
const ui={lang:'en',busy:false,controller:null,pack:null,kind:'fresh',elapsed:null,activeSpec:structuredClone(DATA.examples.Q2),logs:[],statusKey:'ready',custom:false,economic:null};
const t=(key,...args)=>{const value=messages[ui.lang][key]??(ui.lang==='fr'?french[key]:english[key])??key;return typeof value==='function'?value(...args):value;};
const money=v=>new Intl.NumberFormat(ui.lang==='fr'?'fr-CA':'en-US',{style:'currency',currency:'USD',currencyDisplay:'code',minimumFractionDigits:2,maximumFractionDigits:2}).format(v);
const count=v=>new Intl.NumberFormat(ui.lang==='fr'?'fr-CA':'en-US',{maximumFractionDigits:1}).format(v);
const pct=v=>new Intl.NumberFormat(ui.lang==='fr'?'fr-CA':'en-US',{style:'percent',maximumFractionDigits:2}).format(v);
const set=(id,text)=>{$(id).textContent=text;};
const make=(tag,text,cls)=>{const el=document.createElement(tag);if(text!==undefined)el.textContent=text;if(cls)el.className=cls;return el;};
function status(key,kind='normal',detail=''){ui.statusKey=key;ui.statusDetail=detail;$('status-line').className='status-line '+kind;set('status',t(key)+(detail?' '+detail:''));set('status-icon',kind==='failed'?'!':kind==='running'?'◌':'✦');}
function log(event,data={}){ui.logs.push({at:new Date().toISOString(),event,...data});ui.logs=ui.logs.slice(-150);set('execution-log',JSON.stringify({demo_source_hash:DATA.demo_source_hash,upstream_commit:DATA.upstream_commit,provider_calls:0,settlement_calls:0,authenticated_enterprise:'NOT_RUN',full_cost_usd:null,events:ui.logs},null,2));}
function setLanguage(lang){ui.lang=lang;document.documentElement.lang=lang;document.title=lang==='fr'?'AGI ALPHA — Un résultat utile. Une meilleure suite.':'AGI ALPHA — Useful work. A better next task.';for(const el of document.querySelectorAll('[data-i18n]'))el.innerHTML=(lang==='fr'?french[el.dataset.i18n]:english[el.dataset.i18n])??english[el.dataset.i18n];$('lang-en').setAttribute('aria-pressed',String(lang==='en'));$('lang-fr').setAttribute('aria-pressed',String(lang==='fr'));$('close-input').setAttribute('aria-label',lang==='fr'?'Fermer l’éditeur':'Close input editor');document.querySelector('.table-scroll').setAttribute('aria-label',lang==='fr'?'Tableau du panier sélectionné, défilement horizontal disponible':'Selected cart table, horizontal scrolling available');document.querySelector('.mission-preview').setAttribute('aria-label',lang==='fr'?'Mission d’exemple':'Example mission');if(ui.pack)renderResult();if(ui.pack&&!ui.busy)$('run').querySelector('span').textContent=t('rerun');if(ui.statusKey==='ready')set('status',lang==='fr'?french.ready:english.ready);else set('status',t(ui.statusKey)+(ui.statusDetail?' '+ui.statusDetail:''));renderEconomics();renderMeta();if(DATA.transfer_extension)set('recorded-transfer',t('recordedTransfer'));}
function renderMeta(){set('evidence-meta',`${t('sourceHash')}: ${DATA.demo_source_hash}\n${t('runtimePin')}: ${DATA.upstream_commit}\n${t('fullCost')} · ${t('noNetwork')}\n${t('frameNote')}`);$('evidence-meta').style.whiteSpace='pre-wrap';}
function setBusy(busy){ui.busy=busy;for(const id of ['run','run-custom','next-mission','restore-example','custom-open','csv-file','evidence-file'])$(id).disabled=busy;$('stop').hidden=!busy;}
function sourceEquivalent(spec){for(const [id,example] of Object.entries(DATA.examples))if(canonical(spec.inputs)===canonical(example.inputs))return id;return null;}
function renderResult(){if(!ui.pack)return;const p=ui.pack,e=p.result.evidence,s=e.solution,n=e.normalized;$('result-section').hidden=false;set('execution-kind',ui.kind==='import'?t('importLabel'):ui.kind==='previous'?t('previous'):ui.lang==='fr'?french.fresh:english.fresh);set('basket-total',money(s.total_minor/100));set('basket-subtotal',t('subtotal',money(s.line_total_minor/100),money(s.shipping_minor/100)));set('quantity-check',t('covered',n.items.length));set('deadline-check',t('daysMax',n.deadline_days));set('solver-check',t('states',s.states_visited));set('execution-detail',ui.kind==='import'?(ui.lang==='fr'?'Historique importé · aucun nouvel appel':'Imported history · no new call'):t('elapsed',ui.elapsed??p.economics.elapsedMilliseconds,0));set('cart-context',t('cartContext',n.items.length,n.offers.length));const body=$('cart-body');body.replaceChildren();for(const o of s.selected){const tr=document.createElement('tr'),label=ui.lang==='fr'&&sourceEquivalent(p.spec)?itemFrench[o.label]||o.label:o.label;for(const [i,value] of [label,o.vendor,o.quantity,o.delivered_units,o.packs,money(o.landed_line_minor/100),o.lead_days].entries())tr.append(make('td',value,i>=2?'number':undefined));body.append(tr);}set('verification-context',(ui.kind==='import'?t('importChecked'):sourceEquivalent(p.spec)?t('studyChecked'):t('customChecked'))+' '+t('excluded',n.excluded.length));$('run').querySelector('span').textContent=t('rerun');}
async function runSpec(spec,{scroll=true}={}){if(ui.busy)return;const prior=ui.pack;ui.activeSpec=structuredClone(spec);ui.activeSpec.language=ui.lang;ui.controller=new AbortController();setBusy(true);status('running','running');$('input-error').hidden=true;if(prior){ui.kind='previous';renderResult();}const started=performance.now();let checkpoints=0;log('run-start',{input_items:spec.inputs.items?.length,source_class:spec.rights.dataClass});try{const result=await wb.run(ui.activeSpec,{sourceHash:DATA.demo_source_hash,signal:ui.controller.signal,onProgress:phase=>log('phase',{phase}),onCheckpoint:async()=>{checkpoints++;await new Promise(resolve=>requestAnimationFrame(resolve));}});await wb.inspectPack(result);ui.pack=result;ui.kind='fresh';ui.elapsed=performance.now()-started;renderResult();status('complete');log('run-complete',{checkpoints,elapsed_ms:ui.elapsed,total_minor:result.result.evidence.solution.total_minor,integrity_digest:result.integrityDigest,provider_calls:0,full_cost_usd:null,model_orchestration:'NOT_RUN'});if(scroll){$('result-section').scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth'});$('result-title').focus({preventScroll:true});}}catch(error){if(error.message==='CANCELLED'){status('stopped');log('cancelled',{checkpoints});}else{const detail=friendlyError(error);status('failed','failed',detail);log('refused',{error:error.message});$('input-error').hidden=false;set('input-error',detail);}}finally{setBusy(false);}}
function friendlyError(error){const text=String(error.message||error);const pair={VENDOR_LIMIT:['Use at most 12 suppliers.','Utilisez au plus 12 fournisseurs.'],ITEM_LIMIT:['Use 1–18 requested items.','Utilisez de 1 à 18 articles.'],OFFER_LIMIT:['Use 1–160 offers.','Utilisez de 1 à 160 offres.'],INPUT_RIGHTS:['Only permitted public, synthetic or licensed nonpersonal inputs are supported.','Seules les données publiques, synthétiques ou non personnelles sous licence sont admises.'],PACK_INTEGRITY:['Evidence integrity failed. Use the original export.','L’intégrité des preuves est invalide. Utilisez l’export original.']};if(pair[text])return pair[text][ui.lang==='fr'?1:0];if(text.startsWith('NO_ELIGIBLE_OFFER'))return ui.lang==='fr'?'Au moins un article n’a aucune offre respectant le délai. Ajustez le délai ou les devis.':'At least one item has no offer meeting the deadline. Adjust the deadline or the quotes.';if(text.startsWith('MISSING_FX'))return ui.lang==='fr'?'Un taux de change explicite manque pour une devise.':'An explicit exchange ratio is missing for one currency.';return text;}
function download(name,text,type='application/json'){const blob=new Blob([text],{type}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1500);log('export',{name,bytes:blob.size});}
function report(){const p=ui.pack,s=p.result.evidence.solution,n=p.result.evidence.normalized;const esc=v=>String(v).replaceAll('|','\\|').replace(/[\r\n]+/g,' ').replaceAll('<','&lt;').replaceAll('>','&gt;');const fr=ui.lang==='fr';let txt=`# ${fr?'Comparaison de devis':'Quote comparison'} — AGI ALPHA\n\n${fr?'Panier recommandé':'Recommended basket'}: **${money(s.total_minor/100)}** (${fr?'dont livraison':'including shipping'} ${money(s.shipping_minor/100)}).\n\n${fr?'Aucun achat effectué. Coût local réel complet : inconnu.':'No purchase made. Actual local full cost: unknown.'}\n\n| ${fr?'Article | Fournisseur | Demandé | Livré | Lots | Coût | Jours':'Item | Supplier | Required | Delivered | Packs | Cost | Days'} |\n|---|---|---:|---:|---:|---:|---:|\n`;for(const row of s.selected)txt+='| '+[fr&&sourceEquivalent(p.spec)?itemFrench[row.label]||row.label:row.label,row.vendor,row.quantity,row.delivered_units,row.packs,money(row.landed_line_minor/100),row.lead_days].map(esc).join(' | ')+' |\n';txt+='\n'+t('boundaryText')+'\n\n'+(sourceEquivalent(p.spec)?t('syntheticNotice'):'')+'\n\n'+t('noNetwork')+'\n\n'+(fr?'Identité des preuves natives':'Native evidence identity')+': `'+p.integrityDigest+'`\n\n'+(fr?'Ce rapport traduit les champs structurés; le dossier natif complet conserve ses artefacts originaux.':'This report renders the structured fields in the selected language; the full native evidence pack preserves its original artifacts.')+'\n';return txt;}
const csvHeader=['item_id','item','quantity','vendor','pack_units','pack_price','currency','fx_to_usd','shipping','delivery_days'];
const csvEscape=v=>'"'+String(v).replaceAll('"','""')+'"';
function inputCsv(input){return csvHeader.join(',')+'\n'+input.offers.map(o=>{const item=input.items.find(i=>i.id===o.item),rate=input.fx[o.currency];return [o.item,item.label,item.quantity,o.vendor,o.pack_units,(o.pack_price_minor/100).toFixed(2),o.currency,String(rate.num/rate.den),(input.shipping_minor[o.vendor]/100).toFixed(2),o.lead_days].map(csvEscape).join(',');}).join('\n')+'\n';}
function parseCsv(text){if(new TextEncoder().encode(text).length>200000)throw Error(t('invalidFile'));text=text.replace(/^\ufeff/,'');const rows=[];let row=[],cell='',quoted=false,closed=false;for(let i=0;i<text.length;i++){const ch=text[i];if(quoted){if(ch==='"'){if(text[i+1]==='"'){cell+='"';i++;}else{quoted=false;closed=true;}}else cell+=ch;}else if(ch==='"'&&!cell&&!closed)quoted=true;else if(ch===','){row.push(cell);cell='';closed=false;}else if(ch==='\n'||ch==='\r'){if(ch==='\r'&&text[i+1]==='\n')i++;row.push(cell);if(row.some(x=>x.trim()))rows.push(row);row=[];cell='';closed=false;}else{if(closed||ch==='"')throw Error(t('formatError',rows.length+1,ui.lang==='fr'?'guillemets invalides':'invalid quoting'));cell+=ch;}if(rows.length>161)throw Error('OFFER_LIMIT');}if(quoted)throw Error(ui.lang==='fr'?'Guillemet non fermé.':'Unclosed CSV quote.');if(row.length||cell||closed){row.push(cell);if(row.some(x=>x.trim()))rows.push(row);}if(JSON.stringify(rows.shift()?.map(s=>s.trim()))!==JSON.stringify(csvHeader))throw Error(t('csvHeader'));if(!rows.length)throw Error(t('emptyCsv'));return rows;}
function integerText(value,min,max,label){if(!/^\d+$/.test(value))throw Error(label+': '+(ui.lang==='fr'?'entier requis':'integer required'));const n=Number(value);if(!Number.isSafeInteger(n)||n<min||n>max)throw Error(label+': '+min+'–'+max);return n;}
function cents(value,label){if(!/^\d+(?:\.\d{1,2})?$/.test(value))throw Error(label+': '+(ui.lang==='fr'?'montant positif, deux décimales au plus':'nonnegative amount, at most two decimals'));const [a,b='']=value.split('.'),v=Number(a)*100+Number(b.padEnd(2,'0'));if(!Number.isSafeInteger(v)||v>100000000)throw Error(label+': '+(ui.lang==='fr'?'hors limites':'out of bounds'));return v;}
function ratio(value){if(!/^\d+(?:\.\d{1,6})?$/.test(value))throw Error('fx_to_usd: '+(ui.lang==='fr'?'décimal positif, six chiffres au plus':'positive decimal, at most six fractional digits'));const[a,b='']=value.split('.');let n=Number(a+b),d=10**b.length;const gcd=(a,b)=>b?gcd(b,a%b):a,g=gcd(n,d);n/=g;d/=g;if(!Number.isSafeInteger(n)||n<1||n>1000000||d>1000000)throw Error('fx_to_usd: '+(ui.lang==='fr'?'taux hors limites':'ratio out of bounds'));return {num:n,den:d,source:ui.lang==='fr'?'Taux déclaré par l’utilisateur; non actualisé':'User-declared ratio; not refreshed'};}
function csvSpec(){const rows=parseCsv($('csv-input').value),items=new Map(),shipping=Object.create(null),fx=Object.create(null),offers=[];for(const [i,cells]of rows.entries()){try{if(cells.length!==10)throw Error(ui.lang==='fr'?'dix colonnes requises':'ten columns required');const[id,label,q,vendor,pack,price,currency,rate,ship,days]=cells.map(v=>v.trim());if(!/^[A-Za-z0-9_-]{1,60}$/.test(id))throw Error('item_id: A–Z, 0–9, _ -');if(!label||label.length>300||!vendor||vendor.length>60)throw Error(ui.lang==='fr'?'article ou fournisseur invalide':'invalid item or supplier');const quantity=integerText(q,1,10000,'quantity'),entry={id,label,quantity};if(items.has(id)&&JSON.stringify(items.get(id))!==JSON.stringify(entry))throw Error(ui.lang==='fr'?'quantité ou libellé contradictoire pour le même article':'conflicting quantity or label for the same item');items.set(id,entry);const fee=cents(ship,'shipping');if(Object.hasOwn(shipping,vendor)&&shipping[vendor]!==fee)throw Error(ui.lang==='fr'?'frais de livraison contradictoires':'conflicting supplier shipping');shipping[vendor]=fee;if(!/^[A-Z]{3}$/.test(currency))throw Error('currency: '+(ui.lang==='fr'?'code de trois majuscules':'three uppercase letters'));const r=ratio(rate);if(currency==='USD'&&(r.num!==r.den))throw Error(ui.lang==='fr'?'Le taux USD doit être 1.':'USD ratio must be 1.');if(fx[currency]&&(fx[currency].num!==r.num||fx[currency].den!==r.den))throw Error(ui.lang==='fr'?'taux contradictoires pour la même devise':'conflicting ratios for one currency');fx[currency]=r;offers.push({item:id,vendor,pack_units:integerText(pack,1,10000,'pack_units'),pack_price_minor:cents(price,'pack_price'),currency,lead_days:integerText(days,0,365,'delivery_days')});}catch(e){throw Error(t('formatError',i+2,e.message));}}const title=$('input-name').value.trim()||t('inputTitle'),deadline=integerText($('input-deadline').value,0,365,'deadline');return {schema:'successor-workbench/v1',family:'awe-quotes',name:title.slice(0,64),language:ui.lang,owner:'local-user',rights:{dataClass:'licensed-nonpersonal',source:'User-declared permitted quote CSV processed locally',license:'User-declared authorization for nonpersonal data'},reviewMinutes:1,inputs:{title,base_currency:'USD',deadline_days:deadline,items:[...items.values()],shipping_minor:shipping,fx,offers}};}
function restoreExample(){ui.activeSpec=structuredClone(DATA.examples.Q2);ui.custom=false;$('csv-input').value=inputCsv(DATA.examples.Q2.inputs);$('input-name').value=t('inputTitle');$('input-deadline').value='6';$('input-permission').checked=false;$('input-error').hidden=true;status('restored');}
function openInput(){$('input-section').hidden=false;$('input-section').scrollIntoView({behavior:'smooth'});$('input-title').focus({preventScroll:true});}
function renderEconomics(){const econ=DATA.economics,scenario=$('economic-scenario').value,volume=Number($('economic-volume').value),route=$('economic-route').value,s=econ.scenarios[scenario],row=econ.quote_unit_rows.find(r=>r.scenario===scenario&&r.route===route&&r.attempts_per_month===volume),P=Number($('economic-price').value),human=Number($('economic-human').value),attention=Number($('economic-attention').value);if(!row||!$('economic-price').value||P<.01||P>1000||!Number.isFinite(P)||!$('economic-human').value||human<0||human>10000||!Number.isFinite(human)||!$('economic-attention').value||attention<0||attention>600||!Number.isFinite(attention)){ui.economic=null;for(const id of ['economic-full','economic-marginal','economic-recurring','economic-net','economic-contribution','economic-human-cost','economic-outlay'])set(id,'—');set('economic-customer-result',t('invalidEconomic'));$('export-economics').disabled=true;return;}$('export-economics').disabled=false;const equivalent=$('economic-scope').checked,computed=calculateScenario(econ,{scenario,route,attemptsPerMonth:volume,price:P,humanMinutes:human,humanHourlyWage:row.median_wage_hourly_usd,extraCustomerMinutes:attention,equivalentScope:equivalent});const full=row.fully_loaded_pretax_usd_per_accepted,net=computed.netReceiptPerAccepted,margin=computed.fullContributionPerAccepted,wage=row.median_wage_hourly_usd,humanCost=human*wage/60,outlay=P+attention*econ.customer_hourly_proxy_usd/60,saving=humanCost-outlay;ui.economic={calculator_result:computed,equivalent_scope_assumed:equivalent,status:'FRESH_ARITHMETIC_ON_SCENARIO_ASSUMPTIONS_NOT_OBSERVED_COST_OR_SALES',scenario,route,attempts_per_month:volume,assumed_price_usd:P,assumed_human_minutes:human,assumed_customer_extra_minutes:attention,unit_row:row,scenario_assumptions:s,fees:econ.fees,customer_hourly_proxy_usd:econ.customer_hourly_proxy_usd,expected_net_collected_receipt_per_accepted_usd:net,full_cost_pretax_contribution_usd:margin,assumed_human_labor_cost_usd:humanCost,assumed_customer_outlay_usd:outlay,modeled_customer_saving_usd:saving,actual_local_full_cost_usd:null,observed_customer_payments:0,source_hashes:econ.input_sha256};set('economic-full',money(full));set('economic-marginal',money(row.marginal_execution_usd_per_accepted));set('economic-recurring',money(row.recurring_delivery_usd_per_accepted));set('economic-net',money(net));set('economic-contribution',money(margin));$('contribution').classList.toggle('negative',margin<0);set('economic-human-cost',equivalent?money(humanCost):'—');set('economic-outlay',equivalent?money(outlay):'—');set('economic-customer-result',equivalent?(saving>=0?t('customerSaving',money(saving)):t('customerLoss',money(-saving))):(ui.lang==='fr'?'Comparaison indisponible : la portée ou la qualité n’est pas équivalente.':'Comparison unavailable: scope or quality is not equivalent.'));$('economic-customer-result').classList.toggle('negative',!equivalent||saving<0);set('economic-wage-note',t('wageNote',money(wage),money(econ.customer_hourly_proxy_usd)));set('economic-state',margin>0?t('positiveMargin'):t('negativeMargin'));$('economic-state').classList.toggle('negative',margin<=0);const max=Math.max(humanCost,outlay,1);$('human-bar').style.width=(equivalent?100*humanCost/max:0)+'%';$('outlay-bar').style.width=(equivalent?100*outlay/max:0)+'%';const assumptions=$('economic-assumptions');assumptions.replaceChildren();for(const label of [t('acceptance',pct(row.assumed_expected_acceptance)),t('collection',pct(s.collection_fraction)),t('refund',pct(s.refund_fraction)),route==='modeled_model_extension'?t('routeNotRun'):t('routeToolNote')])assumptions.append(make('span',label));const palette=['#ad8cff','#cebae8','#6b5790','#648778','#af9d74','#7f7196','#a785bb','#7a6e9c','#9f768a','#bfa3db'];const bars=$('cost-bars');bars.replaceChildren();for(const [i,[key,value]]of Object.entries(row.components_usd_per_accepted).entries()){if(value<=0)continue;const bar=make('i');bar.style.flex=String(value);bar.style.background=palette[i%palette.length];bar.title=componentLabels[ui.lang][key]+': '+money(value);bars.append(bar);}const table=document.createElement('table'),body=document.createElement('tbody');const add=(label,value)=>{const tr=document.createElement('tr');tr.append(make('td',label));tr.append(make('td',value,'number'));body.append(tr);};add(t('costComponents'),'USD');for(const [key,value]of Object.entries(row.components_usd_per_accepted))add(componentLabels[ui.lang][key]||key,money(value));add(t('costFloor'),money(row.pretax_customer_price_floor_usd_including_modeled_noncollection_refund_fees));add(t('expectedVolume'),count(computed.expectedAcceptedQuoteSharePerMonth));add(t('collectionDelay'),s.collection_delay_months);add(t('normalExceptions'),pct(s.normal_exception_probability)+' × '+s.normal_exception_minutes);add(t('rareExceptions'),pct(s.rare_exception_probability)+' × '+s.rare_exception_minutes);add(t('shock'),pct(s.common_shock_month_probability));add(t('setup'),s.setup_development_hours);add(t('maintenance'),s.maintenance_hours_per_month);add(t('admin'),s.business_admin_hours_per_month);add(t('fee'),pct(econ.fees.fraction)+' + '+money(econ.fees.fixed_usd_per_collected_invoice));add(t('servicePrice'),money(P));add(t('humanDuration'),human);add(t('customerMinutes'),attention);table.append(body);$('assumptions-table').replaceChildren(table);}
$('run').addEventListener('click',()=>runSpec(ui.activeSpec));$('stop').addEventListener('click',()=>ui.controller?.abort());$('lang-en').addEventListener('click',()=>setLanguage('en'));$('lang-fr').addEventListener('click',()=>setLanguage('fr'));$('custom-open').addEventListener('click',openInput);$('close-input').addEventListener('click',()=>{$('input-section').hidden=true;$('custom-open').focus();});$('restore-example').addEventListener('click',restoreExample);$('csv-input').addEventListener('input',()=>{ui.custom=true;});$('run-custom').addEventListener('click',async()=>{try{if(!$('input-permission').checked)throw Error(t('rightsNeeded'));const spec=csvSpec();wb.validate(spec);await runSpec(spec);}catch(e){$('input-error').hidden=false;set('input-error',friendlyError(e));log('input-refused',{reason:e.message});}});$('next-mission').addEventListener('click',()=>{ui.activeSpec=structuredClone(DATA.examples.Q4);log('retained-adapter-reused',{capability:'awe-quotes-v2',fresh_input:'Q4',automatic_construction:false});runSpec(ui.activeSpec);});$('csv-file').addEventListener('change',async event=>{const file=event.target.files[0];if(!file)return;try{if(file.size>200000)throw Error(t('invalidFile'));$('csv-input').value=await file.text();ui.custom=true;$('input-permission').checked=false;status('csvOpened');}catch(e){$('input-error').hidden=false;set('input-error',e.message);}event.target.value='';});$('evidence-file').addEventListener('change',async event=>{const file=event.target.files[0];if(!file)return;try{if(file.size>2000000)throw Error(t('invalidFile'));const pack=parseBounded(await file.text());if(pack.spec?.family!=='awe-quotes')throw Error(t('evidenceOnly'));await wb.inspectPack(pack);ui.pack=pack;ui.activeSpec=structuredClone(pack.spec);ui.kind='import';ui.elapsed=null;renderResult();status('imported');log('import-verified',{integrity_digest:pack.integrityDigest,authentication:'UNAUTHENTICATED_HISTORICAL_IMPORT',active_authority:[]});$('result-section').scrollIntoView({behavior:'smooth'});$('result-title').focus({preventScroll:true});}catch(e){status('failed','failed',friendlyError(e));log('import-rejected',{reason:e.message});}event.target.value='';});$('export-csv').addEventListener('click',()=>{if(!ui.pack)return;const a=ui.pack.result.artifacts.find(a=>a.name==='recommended-cart.csv');download('AGI_ALPHA_recommended_cart.csv',a.content,'text/csv;charset=utf-8');});$('export-report').addEventListener('click',()=>{if(ui.pack)download('AGI_ALPHA_quote_report_'+ui.lang+'.md',report(),'text/markdown;charset=utf-8');});$('export-evidence').addEventListener('click',()=>{if(ui.pack)download('AGI_ALPHA_local_evidence.json',JSON.stringify(ui.pack,null,2),'application/json');});$('export-capability').addEventListener('click',()=>download('AGI_ALPHA_recorded_capability.json',JSON.stringify({recorded_study:true,...DATA.capability,transfer_extension:DATA.transfer_extension||null},null,2)));$('export-economics').addEventListener('click',()=>{if(ui.economic)download('AGI_ALPHA_economic_scenario.json',JSON.stringify(ui.economic,null,2));});for(const id of ['economic-scenario','economic-volume','economic-route','economic-price','economic-human','economic-attention','economic-scope'])$(id).addEventListener('input',()=>{if(id==='economic-scenario')$('economic-attention').value=String(DATA.economics.scenarios[$('economic-scenario').value].customer_incremental_minutes);renderEconomics();});
if(DATA.transfer_extension){const p=make('p',t('recordedTransfer'),'fine-print');p.id='recorded-transfer';document.querySelector('.recorded-content').insertBefore(p,$('export-capability'));}
$('csv-input').value=inputCsv(DATA.examples.Q2.inputs);renderEconomics();renderMeta();log('ready',{source_hash:DATA.demo_source_hash,offline:true});
window.__AWE_QA__={state:()=>({busy:ui.busy,language:ui.lang,kind:ui.kind,total_minor:ui.pack?.result.evidence.solution.total_minor,integrity_digest:ui.pack?.integrityDigest,economic:ui.economic,logs:ui.logs}),start:()=>runSpec(ui.activeSpec,{scroll:false}),stop:()=>ui.controller?.abort(),setLanguage,parseCsv,csvSpec,sourceHash:DATA.demo_source_hash,recorded:DATA.capability};

return {};
})();