# AGI ALPHA — Useful work. A better next task.

Open **AGI_ALPHA_Autonomous_Work_Economy.html** in a modern browser. The complete application is in that one file; no server, installation, account, API key or network connection is needed. Web Crypto is used locally for the inherited evidence-integrity checks. No purchase, provider call, wallet action or payment is made.

## What the visitor can do

- Click **Try it now / Essayer** to execute the six-item quote example through the actual pinned AGI ALPHA Workbench and new bounded quote adapter.
- Inspect the complete **520.12 USD** synthetic cart, shipping, quantities, pack sizes, delivery constraint, source arithmetic and verification boundary.
- Paste permitted quote CSV or open a CSV file and obtain a fresh result; duplicate item information, supplier fees and currency ratios must agree.
- Export a real CSV, an English or French report, or the native integrity-bound evidence JSON.
- Import a saved evidence JSON. It remains clearly labeled recorded, unauthenticated history; changing the file is detected. Run its inputs again for a fresh execution.
- Stop via a real AbortController and recover with a fresh invocation.
- Run the fourteen-item next mission using the retained adapter, obtaining **2,635.90 USD** on the included synthetic fixture.
- Inspect the recorded bounded capability construction, rejected greedy candidate and separate fresh-input transfer record without presenting those records as a new experiment.
- Explore three economic scenarios, three portfolio-volume levels, two delivery routes, hypothetical service price, alternative human duration, extra attention and the equal-scope condition. The route using model-mediated intake/checking is visibly **NOT RUN**.

The equipment basket price is not an AGI ALPHA execution cost. **Actual local full cost is unknown** and is prominently displayed. All delivery costs and financial contributions in the economics section are scenario calculations. No collected customer payment, automatic investment, production promotion or self-acceleration is claimed.

## Design and accessibility

The app provides English and French interfaces, a responsive cosmic-purple visual system, keyboard focus, an initial skip link, text labels, live status, contrast-conscious colors and reduced-motion support. The narrow-screen cart scrolls within its labeled table region rather than widening the page. Uploaded input labels are rendered as text; output CSV uses the inherited formula-escaping mechanism. The Markdown language export escapes table separators and HTML delimiters.

The first screen focuses on the useful outcome. Native runtime details, exact source identities, evidence interpretation and import/recovery live in an advanced disclosure.

## Exact source and economics

`build-manifest.json` identifies the exact source closure, styles, template, embedded economic inputs and final HTML hash. The actual runtime comes from Alpha commit `a026e68413ab2e2d6086c758efc8abff723fdfe4`, unmodified. The native source closure and original adapters are bundled, not reimplemented as a simulated connection.

Economic rows are copied from `paper_support/demo_economics.json`, and fresh arithmetic calls the independently tested `paper_support/demo_calculator.mjs`. The displayed volume is the **entire four-family portfolio**, with a 25% quote share and fixed costs allocated across the portfolio. The default economic view is the reference hosted-tool scenario at 1,000 attempted portfolio jobs/month and a hypothetical 5 USD service price. The human-duration control starts at the separately labeled 15-minute assumption; it is not a sourced or observed task duration. Neither the scenario nor its usage, acceptance, handling time or demand is observed production performance.

The optional automated-upkeep portfolio sensitivity is described as separate and not substituted into a quote-unit result. A cash ledger is not fabricated from unit contribution. When scope/quality equivalence is unchecked, the customer comparison is suppressed.

## Build

From the full companion directory structure:

```bash
python3 demo/build.py
```

The builder performs a deterministic topological transform of the existing static JavaScript modules into isolated closures. It supports only the import/export forms used by the inspected source and rejects other forms. It does not use `eval`, external packages, CDNs or network assets. `app.mjs` is a source template whose data placeholder is populated by this build. `bundle.js` is the generated inspectable JavaScript.

The full upstream Apache 2.0 license is embedded in the standalone HTML and also provided as `UPSTREAM-LICENSE.txt`.

## Actual browser QA

Final standalone HTML SHA256: `f75064f420ea09d0d7c7d7d685e36dfa583eef017201ae8d74c321cf3dbf5536`. The successful pre-license-comment receipt is preserved as `qa-report-v2-pre-spdx.json`; the final receipt below covers the licensed publication bytes.

`qa-report.json` is tied to the exact final HTML SHA256 and records **25/25 passing checks** in Playwright Chromium at 1440px and 360px widths. The checks cover actual default/custom computations, the next mission, exports, historical import, tamper rejection, stop and recovery, economic formula correspondence, negative-margin behavior, unequal-scope suppression, French display and localized report export, no page overflow, keyboard focus, no browser errors and no external network requests.

The initial QA found a six-pixel French narrow-screen overflow. It was corrected by adjusting the narrow French headline and grid minimum widths. That unsuccessful earlier receipt is preserved as `qa-report-v1-mobile-overflow.json`.

Browser launch required the environment's normal auto-reviewed permission escalation; no account or persistent browser profile was accessed. `qa.cjs` references the existing local headless Chromium executable used in this environment. Reproduction elsewhere should provide an installed compatible Playwright Chromium. The browser package itself is not included in this application.

Screenshots were produced and visually inspected as temporary internal QA artifacts under `/tmp/awe_demo_qa`; they are not application dependencies or deliverables.

## Remaining boundaries

The local browser run measures its own display-paced wall time, including checkpoints that yield to permit cancellation. It is not the frozen batch's benchmark time. The inherited runtime keeps admission on HOLD and does not confer authenticated proof or execution authority.

The quote contract uses supplied rational currency ratios and integer minor-unit arithmetic, fixed per-supplier shipping, one offer per item and rounded-up pack quantities. Taxes, discounts, inventory uncertainty, quality assessment and split purchases are outside the contract. The separately executed MILP checked the study fixtures; a visitor's custom input is not represented as independently re-solved by MILP in this browser.

The original assistant/developer effort, original model authoring usage and local hosting economics are unmetered. This useful bounded tool is not evidence that the complete authenticated autonomous enterprise has executed.
