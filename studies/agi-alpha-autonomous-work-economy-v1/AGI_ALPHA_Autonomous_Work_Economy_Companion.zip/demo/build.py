# SPDX-License-Identifier: Apache-2.0
import json,re,hashlib,datetime
from pathlib import Path
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent
app=ROOT/'app.mjs'
modules={};order=[]
pattern=re.compile(r'^import\s+([\s\S]*?)\s+from\s+[\'"]([^\'"]+)[\'"];',re.MULTILINE)
def module_id(path):return str(path.relative_to(BASE))
def visit(path):
    path=path.resolve()
    if path in modules:return
    if not path.is_relative_to(BASE):raise ValueError('Module outside study')
    text=path.read_text();imports=list(pattern.finditer(text));modules[path]={'text':text,'imports':imports}
    for m in imports:visit((path.parent/m[2]).resolve())
    order.append(path)
visit(app)
module_manifest=[{'path':module_id(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in order]
manifest={'bundle_method':'Deterministic topological transform of static named/namespace imports and named declaration exports; sources preserved unchanged. No arbitrary eval, external dependency, minifier or network asset.','sources':module_manifest,'style_sha256':hashlib.sha256((ROOT/'style.css').read_bytes()).hexdigest(),'template_sha256':hashlib.sha256((ROOT/'index.template.html').read_bytes()).hexdigest()}
source_hash=hashlib.sha256(json.dumps(manifest,sort_keys=True,separators=(',',':')).encode()).hexdigest()
transfer=BASE/'extension/runs/confirmation-v1/acceptance-reporting-v1.1.json'
data={'demo_source_hash':source_hash,'upstream_commit':'a026e68413ab2e2d6086c758efc8abff723fdfe4','examples':{id:json.loads((BASE/'implementation/inputs'/f'{id}.json').read_text()) for id in ['Q1','Q2','Q4']},'economics':json.loads((BASE/'paper_support/demo_economics.json').read_text()),'capability':{'manifest':json.loads((BASE/'implementation/capabilities/manifest.json').read_text()),'events':json.loads((BASE/'implementation/capabilities/events.json').read_text()),'independent_audit':json.loads((BASE/'implementation/capabilities/independent-audit.json').read_text())},'transfer_extension':json.loads(transfer.read_text()) if transfer.exists() else None}
chunks=['"use strict";\nconst __modules = Object.create(null);']
for p in order:
    text=modules[p]['text']
    def replace_import(m):
        dep=module_id((p.parent/m[2]).resolve());spec=m[1].strip()
        if spec.startswith('{'):
            bindings=spec[1:-1].strip();bindings=re.sub(r'\b(\w+)\s+as\s+(\w+)\b',r'\1: \2',bindings)
            return 'const {'+bindings+'} = __modules['+json.dumps(dep)+'];'
        match=re.fullmatch(r'\*\s+as\s+(\w+)',spec)
        if match:return 'const '+match[1]+' = __modules['+json.dumps(dep)+'];'
        raise ValueError('Unsupported import '+spec)
    text=pattern.sub(replace_import,text)
    names=re.findall(r'^export\s+(?:async\s+)?(?:function|class|const|let|var)\s+(\w+)',text,re.MULTILINE)
    text=re.sub(r'^export\s+(?=(?:async\s+)?(?:function|class|const|let|var)\b)','',text,flags=re.MULTILINE)
    if re.search(r'^\s*(?:import|export)\s',text,re.MULTILINE):raise ValueError('Unhandled module syntax '+str(p))
    if p==app:text=text.replace('/*__DATA__*/',json.dumps(data,ensure_ascii=False,separators=(',',':')))
    chunks.append('__modules['+json.dumps(module_id(p))+'] = (() => {\n'+text+'\nreturn {'+','.join(names)+'};\n})();')
bundle='/*\n'+(BASE/'implementation/vendor/alpha/LICENSE').read_text().replace('*/','* /')+'\n*/\n'+'\n'.join(chunks)
if '</script' in bundle.lower():bundle=re.sub('</script','<\\/script',bundle,flags=re.IGNORECASE)
html=(ROOT/'index.template.html').read_text().replace('/*__STYLE__*/',(ROOT/'style.css').read_text()).replace('/*__BUNDLE__*/',bundle)
(ROOT/'AGI_ALPHA_Autonomous_Work_Economy.html').write_text(html)
(ROOT/'bundle.js').write_text(bundle)
manifest['demo_source_hash']=source_hash
manifest['generated_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
manifest['html_sha256']=hashlib.sha256(html.encode()).hexdigest()
manifest['embedded_economics_input_hashes']=data['economics']['input_sha256']
(ROOT/'build-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(ROOT/'UPSTREAM-LICENSE.txt').write_text((BASE/'implementation/vendor/alpha/LICENSE').read_text())
print(json.dumps({'html':str(ROOT/'AGI_ALPHA_Autonomous_Work_Economy.html'),'bytes':len(html.encode()),'modules':len(order),'source_hash':source_hash}))
