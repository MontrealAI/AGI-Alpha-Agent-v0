import hashlib,json
from decimal import Decimal as D,getcontext
from pathlib import Path
getcontext().prec=45
ROOT=Path(__file__).resolve().parents[1]
E=ROOT/'economics'
P=json.loads((E/'scenario_parameters.json').read_text(),parse_float=D)
S=json.loads((E/'sources.json').read_text(),parse_float=D)
R=json.loads((E/'results/economic_results.json').read_text(),parse_float=D)
O={x['id']:x for x in S['occupations']}
G=S['compensation_groups']
T={x['id']:x for x in S['sources']}
F={x['id']:x for x in P['families']}
dev=O['software_developers']['median_hourly_wage_usd']*G['professional']['total_hourly_usd']/G['professional']['wage_hourly_usd']
support=G['private_industry_all']['total_hourly_usd']
issues=[]
checks=0
def check(label,actual,expected,tolerance=D('1e-8')):
    global checks
    checks+=1
    if abs(D(actual)-D(expected))>tolerance:issues.append({'check':label,'actual':str(actual),'expected':str(expected)})
derived={}
for row in R['unit_results']:
    family=F[row['family']];s=P['scenarios'][row['scenario']];n=D(row['attempts_per_month'])
    extension=row['route']=='modeled_model_extension';prefix='extension' if extension else 'tool'
    normal=s[prefix+'_final_acceptance_probability'];shock=s['common_shock_month_probability']
    expected_accepted=n*normal*(1-shock+shock*s['shock_acceptance_retention'])
    expected_calls=n*(1+s[prefix+'_retry_probability']*(1-shock)+min(1,s[prefix+'_retry_probability']+s['shock_extra_retry_probability'])*shock)
    tokens_in=sum(x['input_tokens'] for x in family['estimated_model_stages'])*s['model_token_multiplier'] if extension else D(0)
    tokens_out=sum(x['billable_output_tokens_including_reasoning'] for x in family['estimated_model_stages'])*s['model_token_multiplier'] if extension else D(0)
    tokens=(tokens_in*T['OPENAI_SOL_20261025']['input_usd_per_million_tokens']+tokens_out*T['OPENAI_SOL_20261025']['output_usd_per_million_tokens'])/D(1000000)
    session=family['hosted_20min_sessions']*T['OPENAI_TOOLS_20261025']['hosted_container_1gb_usd_per_20min_session']
    search=family['estimated_web_search_calls']*T['OPENAI_TOOLS_20261025']['web_search_usd_per_call'] if extension else D(0)
    setup=s['setup_development_hours']*dev
    monthly={'model_tokens':tokens*expected_calls,'runtime':session*expected_calls,'search':search*expected_calls,'normal_exceptions':n*s['normal_exception_probability']*s['normal_exception_minutes']*support/60,'rare_exceptions':n*s['rare_exception_probability']*s['rare_exception_minutes']*support/60,'platform_archive':s['shared_platform_archive_usd_per_month'],'maintenance':s['maintenance_hours_per_month']*dev,'business_administration':s['business_admin_hours_per_month']*support,'common_shock_recovery':shock*s['shock_recovery_hours']*dev,'setup_amortization':setup/D(P['numerical_grid']['amortization_months'])}
    full=sum(monthly.values())/expected_accepted
    key=(row['family'],row['scenario'],row['route'],row['attempts_per_month']);derived[key]=full
    check(str(key)+' full',row['fully_loaded_pretax_usd_per_accepted'],full)
    for k,v in monthly.items():check(str(key)+' '+k,row['components_usd_per_accepted'][k],v/expected_accepted)
    check(str(key)+' normal_acceptance',row['assumed_final_acceptance_in_normal_month'],normal)
    check(str(key)+' expected_acceptance',row['assumed_expected_acceptance'],expected_accepted/n)
    occ=O[family['occupation_id']];group=G[occ['cost_group']]
    check(str(key)+' wage_mapping',row['median_wage_hourly_usd'],occ['median_hourly_wage_usd'])
    check(str(key)+' employer_proxy',row['estimated_employer_hourly_usd'],occ['median_hourly_wage_usd']*group['total_hourly_usd']/group['wage_hourly_usd'])
    check(str(key)+' break_even',row['break_even_human_minutes_wage_only'],60*full/occ['median_hourly_wage_usd'])
for row in R['portfolio']:
    full=sum(f['weight']*derived[(f['id'],row['scenario'],row['route'],row['attempts_per_month'])] for f in P['families'])
    check('portfolio '+str((row['scenario'],row['route'],row['attempts_per_month'])),row['fully_loaded_pretax_usd_per_accepted'],full)
    check('portfolio component sum',sum(row['components_usd_per_accepted'].values()),full)
for ledger in R['cash_constrained_ledgers']:
    cash=ledger['initial_external_endowment_usd']-ledger['setup_cash_outflow_at_month_zero_usd'];ar=D(0)
    for t in ledger['trace']:
        expected=cash+t['collected_cash_usd']-t['refunds_usd']-t['payment_fees_usd']-t['recurring_cash_expenses_usd']-t['construction_spend_usd']
        check('cash balance',t['cash_balance_usd'],expected)
        check('cash delta',t['cash_change_usd'],t['cash_balance_usd']-cash)
        ar+=t['booked_revenue_usd']-t['collected_cash_usd']-t['modeled_bad_debt_written_off_usd']
        check('receivables',t['gross_pending_receivables_usd'],ar)
        checks+=2
        if t['cash_balance_usd']<D('-1e-8'):issues.append({'check':'negative cash','ledger':ledger['scenario'],'month':t['month']})
        if t['cumulative_obligation_reserve_usd']>t['cash_balance_usd']+D('1e-8'):issues.append({'check':'unbacked obligations','ledger':ledger['scenario'],'month':t['month']})
        cash=t['cash_balance_usd']
hashes={}
for name,value in R['input_sha256'].items():
    actual=hashlib.sha256((E/name).read_bytes()).hexdigest();hashes[name]=actual;checks+=1
    if actual!=value:issues.append({'check':'result input hash','path':name})
for f in R['observed']['families']:
    checks+=1
    if f['production_acceptance_estimate'] is not None:issues.append({'check':'fixture production estimate','family':f['family']})
source_expected={'procurement_clerks':(55810,'25.18','24.32'),'technical_writers':(45500,'46.62','43.46'),'planning_clerks':(390160,'29.88','28.68'),'computer_programmers':(92230,'50.56','48.26'),'software_developers':(1687890,'71.20','65.38')}
for k,(employment,mean,median) in source_expected.items():
    check('primary-source employment '+k,O[k]['employment'],employment)
    check('primary-source mean wage '+k,O[k]['mean_hourly_wage_usd'],D(mean))
    check('primary-source median wage '+k,O[k]['median_hourly_wage_usd'],D(median))
check('tariff input',T['OPENAI_SOL_20261025']['input_usd_per_million_tokens'],2)
check('tariff output',T['OPENAI_SOL_20261025']['output_usd_per_million_tokens'],10)
check('tariff search',T['OPENAI_TOOLS_20261025']['web_search_usd_per_call'],D('.01'))
check('tariff container',T['OPENAI_TOOLS_20261025']['hosted_container_1gb_usd_per_20min_session'],D('.03'))
reference=sum(f['weight']*derived[(f['id'],'reference','modeled_model_extension',1000)] for f in P['families'])
out={'study_id':'AWE-2026-01','audit':'Independent same-session Decimal recomputation; not external peer review','calculation_implementation':'Does not import or invoke economics/analyze.py; derives monthly expected resource totals then divides by expected acceptance.','result_sha256':hashlib.sha256((E/'results/economic_results.json').read_bytes()).hexdigest(),'input_sha256':hashes,'checks':checks,'issues':issues,'reference_full_cost_per_accepted_usd':str(reference),'developer_proxy_per_hour_usd':str(dev),'unit_rows':len(R['unit_results']),'portfolio_rows':len(R['portfolio']),'constrained_ledger_months':sum(len(x['trace']) for x in R['cash_constrained_ledgers']),'minimum_cash_balance_usd':str(min(t['cash_balance_usd'] for l in R['cash_constrained_ledgers'] for t in l['trace'])),'source_urls':['https://www.bls.gov/news.release/ocwage.t01.htm','https://www.bls.gov/news.release/ecec.t04.htm','https://developers.openai.com/api/docs/models/gpt-6.1-sol','https://developers.openai.com/api/docs/pricing'],'production_acceptance':'Assumed parameters only; no fixture rate imported. Static function/dataflow review confirms unit calculations are built before observed import.','limits':['Price and wage source identities verified; assumed usage, quality, production acceptance, exceptions and customer behavior not validated by source prices.','Market capacity ceiling uses normal-month reference acceptance 0.90, whereas reference operating costs use shock-adjusted 0.891; interpret market ceiling as normal-rate planning cap.','Eligible hosted-container sessions may have by-minute billing with five-minute minimum; frozen scenarios explicitly charge one or more20-minute sessions and are not claimed actual invoices.','No economics input or output file modified.']}
Path(__file__).with_name('economic_crosscheck.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'checks':checks,'issues':issues,'reference':str(reference),'minimum_cash':out['minimum_cash_balance_usd']},indent=2))

