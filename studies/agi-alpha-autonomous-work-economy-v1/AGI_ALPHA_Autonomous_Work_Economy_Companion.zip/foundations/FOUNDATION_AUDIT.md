# AWE-2026-01 — Foundation and token-route source audit

Observation date: 25 October 2026. Scope: current public source, release metadata and published historical deployment records. This is a separate same-session source review, not an external security audit. No on-chain transaction, signing, credential creation, live deployment modification or fresh RPC inspection occurred.

## 1. Pinned foundations

| Repository | Main commit inspected | Published metadata observed |
| --- | --- | --- |
| AGI-Alpha-Agent-v0 | a026e68413ab2e2d6086c758efc8abff723fdfe4 | v1.43.0; published 25 Oct 2026 01:19 UTC |
| AGIJobManager | 5d5670df9dbbc79da115e0a44b71989f34df58c1 | v1.20.2; published 24 Oct 2026 22:39 UTC; exact same source |
| AGIJobsv0 | bc4abbd5c28f3672275b13300e40ea26c820b8ee | discovery-v2.1.0-rc.21; published 24 Oct 2026 20:16 UTC; exact same source; prerelease |
| AGI-Fleet-Linux | 45759fb096faf8988f58ae5ea71248d0f35a97c7 | v0.1.0-local-skills-preview.5; published 16 Oct 2026; development prerelease |

These observations identify sources and published metadata. They do not requalify release packages or installed tuples. Exact trees and metadata are in foundation_audit.json. The initial source inventory contains 31 byte-verified files; the final inventory adds the publication guide and three implementation files. All source URLs in source_manifest.json are immutable. Direct Git network access failed at the environment proxy; permitted GitHub connector reads supplied these public files without changing credentials.

## 2. Reusable executable boundary

The actual current native workbench is [examples/successor-workbench/engine.mjs](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/blob/a026e68413ab2e2d6086c758efc8abff723fdfe4/examples/successor-workbench/engine.mjs). Its seven-module JavaScript closure and Apache license are materialized under source/AGI-Alpha-Agent-v0. A dynamic import completed successfully; mission acceptance belongs to the separately instrumented implementation study.

Its finite built-in families are range-utility repair, sorted integer deduplication comparison, URI/UTF-8 documentation examples, two-column integer CSV reports and polynomial numerical reproduction. These are explicit grammars, not general software repair or occupations. Exported interfaces include example, validate, semanticIdentity, plan, run, inspectPack and createWorkbench. The latter is the existing extension seam for an independently bounded adapter with validate/execute methods and a versioned manifest.

run binds the exact input, source hash, family, allowed local action and output hashes, builds a typed zero-budget job graph, executes a selected specialist, validates the artifact pack and records elapsed time. It supports abort signals and bounded checkpoints, a 60-second bound, at most 12 artifacts and bounded names/types/content. Its economics correctly leave computeCost and humanMinutes null; model/provider are null; provider and settlement spend are zero for this local route. reviewMinutes is declared review capacity, not observed job labor. Its evaluation explicitly remains PUBLIC_LOCAL_EXECUTION, HOLD and NOT_CONNECTED.

A valid hash does not establish semantic correctness. The study must independently check its actual deliverables. Vendoring or calling this component is genuine component reuse; it does not execute the complete authenticated Harness, provider orchestration, four-repository Fleet path or any held operator action. Those tests remain NOT RUN unless separately performed with already approved resources. The [architecture](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/blob/a026e68413ab2e2d6086c758efc8abff723fdfe4/docs/agent/SUCCESSOR_ARCHITECTURE.md) and [operations guide](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/blob/a026e68413ab2e2d6086c758efc8abff723fdfe4/docs/agent/SUCCESSOR_OPERATIONS.md) distinguish the native protocol, journal, role authorization, source studies and transport boundaries.

## 3. Currency and authority map

### Local research route

No token is needed to run the bounded local specialist. No escrow, collateral, transaction gas, token payout or treasury function is executed by this study. This nonuse fact must remain separate from provider/compute/development/maintenance costs, which cannot be inferred as zero. The utility of a token route therefore needs its own claim, not a universal requirement attached to local work.

### Manager: USDC, six decimals

[AGIJobManager.sol](https://github.com/MontrealAI/AGIJobManager/blob/5d5670df9dbbc79da115e0a44b71989f34df58c1/contracts/AGIJobManager.sol), [JobSettlement.sol](https://github.com/MontrealAI/AGIJobManager/blob/5d5670df9dbbc79da115e0a44b71989f34df58c1/contracts/utils/JobSettlement.sol) and [USDC_PAYOUT_SPLIT.md](https://github.com/MontrealAI/AGIJobManager/blob/5d5670df9dbbc79da115e0a44b71989f34df58c1/docs/USDC_PAYOUT_SPLIT.md) establish full employer escrow and separate bond reserves. A successful job distributes the original escrow basis: 30% to wallet30, 10% to wallet10, the snapshotted validator pool and the residual to the agent. The validator default is 8%; owner-set limits are 1–60%. With default reviewed settlement and ignoring rounding, the agent receives 52%. Unallocated validator budget and dust can return to the agent. Explicit buyer acceptance and no-validator paths differ; do not force the default 52% onto every case.

Buyer-win refunds, expiry and cancellations do not earn success-wallet shares. Failed outgoing payments become reserved beneficiary claims; an entitlement is not collected cash. The owner cannot redirect those claims. Successful-job escrow is not retained as manager treasury revenue. Settlement-wallet rotation is restricted to paused intake and no outstanding job/bond reserves. ETH gas is separate.

Consequences: select the contractual recipient before modeling provider revenue; do not count gross job escrow as the agent enterprise's proceeds; distinguish treasury donations from operating income and include bond/claim liquidity delays where applicable.

### Ascension: AGIALPHA, eighteen decimals

[AscensionToken.sol](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/blob/a026e68413ab2e2d6086c758efc8abff723fdfe4/contracts/ascension/AscensionToken.sol) fixes the canonical token and enforces exact deposits, sends and supply-burning checks. [AscensionJobMarket.sol](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/blob/a026e68413ab2e2d6086c758efc8abff723fdfe4/contracts/ascension/AscensionJobMarket.sol) escrows bounties, locks bidder stake at max(bounty/10, minimumStake), and binds validation to the result hash. Two selected approving validators trigger payment; the validator gross pool is 5% of awarded price and the worker receives the residual gross. Each recipient's payout burns floor(gross/100); integer rounding applies. Missing review quorum refunds without treating absent review as proof of defective work. Late or rejected work may slash the agent bond.

[AscensionAccess.sol](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/blob/a026e68413ab2e2d6086c758efc8abff723fdfe4/contracts/ascension/AscensionAccess.sol) requires live ENS ownership plus an expiring governor-issued admission. Role roots are alpha.agi.eth, alpha.agent.agi.eth and alpha.club.agi.eth, with a registered child under the corresponding root. These are not interchangeable with another product's naming rules. [AscensionRiskOracle.sol](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/blob/a026e68413ab2e2d6086c758efc8abff723fdfe4/contracts/ascension/AscensionRiskOracle.sol) additionally requires validator stake, active eligibility and explicitly reserved review capacity.

### MARK reserve: plan-restricted financing

[AscensionMark.sol](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/blob/a026e68413ab2e2d6086c758efc8abff723fdfe4/contracts/ascension/AscensionMark.sol) lets admitted participants buy funding lots; funding-phase sales are reversible. The green business/seed owner blooms the campaign. Routing is then restricted by business/ENS authority, live risk approval, the plan's Merkle proof, time horizon and remaining reserve. Job refunds return to reserve through collect. Closed campaigns return unused reserve pro rata to lot holders.

This is bounded commissioning financed by contributions. Buying lots is external financing, collecting unused escrow is a refund, and reclaiming unused reserve is capital return. None is operating profit. The code does not grant a general agent unrestricted treasury access or automatically reinvest future customer revenue.

### Jobs v0: AGIALPHA escrow, fee and staking mechanisms

[Constants.sol](https://github.com/MontrealAI/AGIJobsv0/blob/bc4abbd5c28f3672275b13300e40ea26c820b8ee/contracts/v2/Constants.sol) identifies token 0xA61a3B3a130a9c20768EEBF97E21515A6046a1fA and eighteen decimals. The controller delegates to fixed implementation modules. [StakeManagerBase.sol](https://github.com/MontrealAI/AGIJobsv0/blob/bc4abbd5c28f3672275b13300e40ea26c820b8ee/contracts/v2/implementation/StakeManagerBase.sol) and [StakeManagerEscrow.sol](https://github.com/MontrealAI/AGIJobsv0/blob/bc4abbd5c28f3672275b13300e40ea26c820b8ee/contracts/v2/implementation/StakeManagerEscrow.sol) hold employer escrow, reserve validator rewards, bound settlement by escrow, apply configured payout factors/burns and forward fees. Any multiplier above the base reward requires operatorRewardPool backing; this is not money created by capability growth. General stake and per-job collateral are different constraints.

[FeePool.sol](https://github.com/MontrealAI/AGIJobsv0/blob/bc4abbd5c28f3672275b13300e40ea26c820b8ee/contracts/v2/FeePool.sol) burns a configured fraction of received job fees and accumulates the net. Distribution uses boosted stake in a configured reward role, initially Platform. Claims depend on that accounting; holding tokens alone is not an unconditional right to enterprise revenue. Treasury allowlists, authorized rewarders and governance withdrawal permissions are explicit. Withdrawal destinations are restricted to the configured treasury or burn destination. Operator-pool funding and withdrawal are governance controlled. This is not an automatic profit reinvestment API.

Do not combine Manager's USDC waterfall, Ascension's payout burn and Jobs v0's FeePool deductions into one imaginary route. Collateral is working capital; charge loss/financing/lock costs appropriately rather than treating all locked principal as consumed delivery cost. No price appreciation, token issuance or circular transfer is profit.

## 4. Implementation, tests and deployment are separate evidence

| Route | Inspected implementation | Historical deployment evidence | Fresh verification in this study |
| --- | --- | --- | --- |
| Alpha/Ascension | Current source and contract graph inspected | 18-Oct manifest reports exact matches for five contracts and completed graph-authority readback; activationAllowed, readyForPublicFunding and fullyProductionReady false; no global pause | NOT RUN |
| Manager | Current USDC manager and settlement source inspected | 17-Oct owner-reported 8815 projection: notLiveState true; six Exact Match/three Similar Match; intake paused; paid work not qualified | NOT RUN |
| Jobs v0 | Current fixed controller/escrow/fee sources inspected | 18-Oct record: 25 exact-source contracts, 46 named getter checks, eight managed modules paused; production approval/activation false | NOT RUN |
| Fleet | Current instructions, README and release metadata inspected | Local Skills alpha.5 development preview; full 22-case acceptance and physical/endurance/provider commissioning open | NOT RUN |

The source audit did not rerun full contract tests, independently audit historical receipts or observe current chain state. Published deployment sources differ from current repository mains and must retain their original identities.

Sources: [Alpha manifest](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/blob/a026e68413ab2e2d6086c758efc8abff723fdfe4/deployments/ethereum-mainnet/2026-10-18/manifest.json), [Manager projection](https://github.com/MontrealAI/AGIJobManager/blob/5d5670df9dbbc79da115e0a44b71989f34df58c1/config/mainnet/manager-8815-2026-10-17.json), [Jobs deployment record](https://github.com/MontrealAI/AGIJobsv0/blob/bc4abbd5c28f3672275b13300e40ea26c820b8ee/docs/production/mainnet-2026-10-18/README.md), [Fleet release](https://github.com/MontrealAI/AGI-Fleet-Linux/releases/tag/v0.1.0-local-skills-preview.5).

## 5. Coordination and additive publication

All 344 comments observed on [issue #4850](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/issues/4850) are retained as a dated source snapshot. Active ownership includes #4899 for integration/security/release, #4907 for the product ledger and automated task/cost contract, the Economics owner for sourced rates/frozen economic scenarios, and Productive Capital #4908/#4909 for its separate paper/companion. Their source histories, negative findings and held-operation decisions remain unchanged by this review.

The intended shared product contract is examples/successor-alpha/automated-costs.mjs. A read at #4907's then-current 0255ebf0a3289e1011f3a8fad165baf140480241 returned 404: its ownership was announced, but its exact interface was not published at that head. Use a clearly noncanonical study adapter and reconcile once an exact public contract identity exists. Do not claim compatibility from a promised path.

The [paper publication guide](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/blob/a026e68413ab2e2d6086c758efc8abff723fdfe4/docs/agent/PAPER_UPLOADS.md) admits original PDF/TeX through the maintained importer and deterministic catalog/README/homepage/worker generation. Originals are immutable. Passive-paper checks do not qualify software. New HTML experiences and executable companions require the full appropriate source lane; the overlay waits for a matching public software baseline and verifies served bytes. Companion links must resolve to actual exact research release downloads. A research release does not override the active software owner's qualification or publication sequence.

No coordination comment, PR, release, ownership change or mutation was performed by this audit subtask. Root retains authorized coordination responsibility.

