# SPDX-License-Identifier: Apache-2.0
import argparse,hashlib,json,zipfile
from collections import defaultdict
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'deliverables'
STAMP=(2026,10,25,0,0,0)
ROOT_FILES={'README.md','START_HERE.md','LICENSE','reproduce.py'}
DIRECTORIES={'implementation','economics','extension','foundations','demo','figures','paper_support','verification','paper'}
BLOCK_PARTS={'.git','__pycache__','raw','qa','importer_repo','locked-deps','node_modules','screenshots','rendered','helpers','private'}
BLOCK_SUFFIXES={'.pyc','.pyo','.docx','.doc','.aux','.log','.blg','.bbl','.out','.toc','.fls','.fdb_latexmk','.synctex','.gz','.png','.jpg','.jpeg','.webp'}
PUB_FIXED={'README.md','audit_delivery_evidence.py','delivery-evidence-audit.json','source-registry-audit.json','source-verification.json','source_manifest.json','paper-metadata.json','paper-import-receipt.json','import-preparation-failure-v1.json','paper-pr-body.md','companion-pr-body.md','paper-tree-entries.json'}
PUB_BLOCK_WORDS={'raw','token','transfer','materializ','base_tree','cache_assets','coordination-refresh','base_commit'}
EXPECTED={'paper/AGI_ALPHA_Autonomous_Work_Economy.pdf':'ca381b9e558d251a3587ed7e76879038ff69b2029feb32d19318eaaac3ea1f7a','paper/AGI_ALPHA_Autonomous_Work_Economy.tex':'342126d69b0a6fd07b464cb97af91ad02cd3fe4008a8a0f448a7c100d506ebd1','demo/AGI_ALPHA_Autonomous_Work_Economy.html':'f75064f420ea09d0d7c7d7d685e36dfa583eef017201ae8d74c321cf3dbf5536'}
def digest(data):return hashlib.sha256(data).hexdigest()
def eligible(path):
 rel=path.relative_to(ROOT);parts=rel.parts
 if any(part in BLOCK_PARTS or part.startswith('.') for part in parts):return False
 if path.suffix.lower() in BLOCK_SUFFIXES:return False
 if any(s in path.name for s in ['build-pass','texput.']):return False
 if parts[0]=='verification' and path.name.startswith(('archive-candidate','archive-final','package-inventory')):return False
 if parts[0]=='paper_support' and path.name=='validation_excerpt.pdf':return False
 if len(parts)==1:return path.name in ROOT_FILES
 if parts[0] in DIRECTORIES:return True
 if parts[0]=='publication':
  if len(parts)>2 and parts[1]=='shared-contract':return True
  if len(parts)!=2:return False
  if path.name in PUB_FIXED:return True
  lower=path.name.lower()
  if any(word in lower for word in PUB_BLOCK_WORDS):return False
  return path.suffix in {'.json','.md'} and any(word in lower for word in ['receipt','status','audit','review','proof','handoff','validation']) and path.stat().st_size<350000
 return False

def write_archive(name,files):
 names=sorted(files)
 manifest=''.join(digest(files[n])+'  '+n+'\n' for n in names).encode()
 payload=dict(files);payload['SHA256SUMS']=manifest
 target=OUT/name
 with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9,strict_timestamps=True) as z:
  for n in sorted(payload):
   info=zipfile.ZipInfo(n,STAMP);info.compress_type=zipfile.ZIP_DEFLATED;info.create_system=3;info.external_attr=0o100644<<16;info.flag_bits|=0x800
   z.writestr(info,payload[n],compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
 with zipfile.ZipFile(target) as z:
  assert z.namelist()==sorted(payload)
  for n in payload:assert z.read(n)==payload[n]
 categories=defaultdict(lambda:{'files':0,'bytes':0})
 inventory=[]
 for n in sorted(payload):
  category=n.split('/')[0] if '/' in n else 'root'
  categories[category]['files']+=1;categories[category]['bytes']+=len(payload[n]);inventory.append({'path':n,'bytes':len(payload[n]),'sha256':digest(payload[n])})
 return {'file':str(target),'sha256':digest(target.read_bytes()),'archive_bytes':target.stat().st_size,'uncompressed_bytes':sum(map(len,payload.values())),'files':len(payload),'categories':dict(sorted(categories.items())),'inventory':inventory,'manifest':'SHA256SUMS','zip_timestamp':list(STAMP),'archive_order':'lexicographic UTF-8 relative paths','compression':'DEFLATE level 9','permissions':'regular 0644','source_bytes_preserved':True}

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--final',action='store_true');args=parser.parse_args();OUT.mkdir(exist_ok=True)
 for path,expected in EXPECTED.items():assert digest((ROOT/path).read_bytes())==expected,'Frozen final identity mismatch: '+path
 files={str(p.relative_to(ROOT)):p.read_bytes() for p in sorted(ROOT.rglob('*')) if p.is_file() and eligible(p)}
 if 'reproduce.py' not in files:raise RuntimeError('Missing portable reproduction entry point')
 suffix='' if args.final else '.candidate'
 companion=write_archive('AGI_ALPHA_Autonomous_Work_Economy_Companion'+suffix+'.zip',files)
 latex={'AGI_ALPHA_Autonomous_Work_Economy.tex':(ROOT/'paper/AGI_ALPHA_Autonomous_Work_Economy.tex').read_bytes(),'references.bib':(ROOT/'paper/references.bib').read_bytes(),'awe-references.bib':(ROOT/'paper/awe-references.bib').read_bytes(),'LICENSE':(ROOT/'LICENSE').read_bytes()}
 for p in sorted((ROOT/'figures').glob('*.tex')):latex['figures/'+p.name]=p.read_bytes()
 for p in sorted((ROOT/'paper_support/data').glob('*')):
  if p.is_file():latex['figure-data/'+p.name]=p.read_bytes()
 for p in sorted((ROOT/'paper_support/tables').glob('*.tex')):latex['tables/'+p.name]=p.read_bytes()
 latex['verification/standalone-tex-compile.json']=(ROOT/'verification/standalone-tex-compile.json').read_bytes()
 latex['README.md']=b'''# Standalone LaTeX source\n\nCompile AGI_ALPHA_Autonomous_Work_Economy.tex with standard TeX Live:\n\n    pdflatex -interaction=nonstopmode -halt-on-error AGI_ALPHA_Autonomous_Work_Economy.tex\n    bibtex AGI_ALPHA_Autonomous_Work_Economy\n    pdflatex -interaction=nonstopmode -halt-on-error AGI_ALPHA_Autonomous_Work_Economy.tex\n    pdflatex -interaction=nonstopmode -halt-on-error AGI_ALPHA_Autonomous_Work_Economy.tex\n\nThe single manuscript embeds its bibliography and all three figure sources. It was tested in a new directory containing only that .tex: 23 pages, no undefined references/citations, no overfull boxes, and identical extracted layout text to the final paper PDF. The receipt is included. Standard installed TeX packages are required; no project-side input file is needed for this compilation.\n\nSeparate bibliography, reusable vector figure sources, tables and source data are provided for editing and inspection. The compiled paper PDF and executable research are in the complete companion. No original manuscript bytes were changed while making this archive. SHA256SUMS covers every other file in this archive.\n'''
 latex_receipt=write_archive('AGI_ALPHA_Autonomous_Work_Economy_LaTeX'+suffix+'.zip',latex)
 receipt={'stage':'FINAL' if args.final else 'CANDIDATE_AWAITING_FINAL_PUBLICATION_RECEIPTS','companion':companion,'latex':latex_receipt,'excluded':['Private DOCX and research leads','Raw issue/repository snapshots','Publication materialization helpers and token transfer material','Bulk upstream checkout and installed dependencies','Git metadata and caches','Browser screenshots and rendered PDF pages','TeX auxiliary/log files','Prior intermediate archives'],'notes':['Frozen source/evidence/manifests copied byte for byte.','Top-level SHA256SUMS is the delivered-content inventory.','Candidate is not final publication status.']}
 receipt_path=OUT/('archive-final-inventory.json' if args.final else 'archive-candidate-inventory.json');receipt_path.write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps({k:{x:v[x] for x in ['file','sha256','archive_bytes','uncompressed_bytes','files','categories']} for k,v in [('companion',companion),('latex',latex_receipt)]},indent=2))
if __name__=='__main__':main()
