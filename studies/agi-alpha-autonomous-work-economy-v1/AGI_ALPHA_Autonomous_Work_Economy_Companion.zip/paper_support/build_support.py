"""Export frozen AWE economics for publication; never modifies economics inputs."""
import csv
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ECON = HERE.parent / "economics"
DATA = HERE / "data"
TABLES = HERE / "tables"
DATA.mkdir(exist_ok=True)
TABLES.mkdir(exist_ok=True)

def read(name):
    return json.loads((ECON / name).read_text())

P = read("scenario_parameters.json")
S = read("sources.json")
R = read("results/economic_results.json")
U = read("results/automated_upkeep_results.json")
O = {o["id"]: o for o in S["occupations"]}
UPKEEP = {(r["scenario"], r["route"], r["attempts_per_month"]): r for r in U["results"]}
INPUT_NAMES = ["sources.json", "scenario_parameters.json", "economics_protocol.json",
               "results/economic_results.json", "automated_upkeep_protocol.json",
               "automated_upkeep_clarification_v1_1.json", "results/automated_upkeep_results.json"]
INPUT_HASHES = {n: hashlib.sha256((ECON / n).read_bytes()).hexdigest() for n in INPUT_NAMES}

def write_csv(name, rows):
    with (DATA / name).open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

def write_json(name, value):
    (HERE / name).write_text(json.dumps(value, indent=2) + "\n")

def table(name, caption, label, columns, header, rows, note):
    # All text passed here is deliberately valid LaTeX, with units in captions.
    body = "\n".join(" & ".join(map(str, row)) + r" \\" for row in rows)
    value = (r"\begin{table}[tbp]" + "\n" + r"\centering\small" + "\n"
             + r"\caption{" + caption + "}\n" + r"\label{" + label + "}\n"
             + r"\begin{tabular}{" + columns + "}\n" + r"\toprule" + "\n"
             + " & ".join(header) + r" \\" + "\n" + r"\midrule" + "\n" + body
             + "\n" + r"\bottomrule" + "\n" + r"\end{tabular}" + "\n"
             + r"\par\smallskip\begin{minipage}{0.97\linewidth}\footnotesize "
             + note + "\n" + r"\end{minipage}" + "\n" + r"\end{table}" + "\n")
    (TABLES / name).write_text(value)

tiers, volumes = [], []
for row in R["portfolio"]:
    key = row["scenario"], row["route"], row["attempts_per_month"]
    for config in ["original_upkeep", "automatic_upkeep_sensitivity"]:
        recurring = (row["recurring_delivery_usd_per_accepted"] if config == "original_upkeep"
                     else UPKEEP[key]["automated_upkeep_recurring_usd_per_accepted"])
        full = (row["fully_loaded_pretax_usd_per_accepted"] if config == "original_upkeep"
                else UPKEEP[key]["automated_upkeep_fully_loaded_pretax_usd_per_accepted"])
        marginal = row["marginal_execution_usd_per_accepted"]
        record = dict(configuration=config, scenario=row["scenario"], route=row["route"],
                      attempts_per_month=row["attempts_per_month"],
                      expected_accepted_per_month=row["expected_accepted_per_month"],
                      marginal_usd_per_accepted=marginal,
                      recurring_usd_per_accepted=recurring,
                      fully_loaded_pretax_usd_per_accepted=full,
                      recurring_addition_over_marginal_usd=recurring - marginal,
                      setup_addition_over_recurring_usd=full - recurring,
                      status="MODELED_NOT_OBSERVED")
        volumes.append(record)
        if row["attempts_per_month"] == 1000:
            tiers.append(record)
write_csv("cost_tiers_1000.csv", tiers)
write_csv("cost_vs_volume.csv", volumes)

cash_rows, cash_metadata = [], []
for ledger in R["cash_constrained_ledgers"]:
    if ledger["scenario"] != "reference" or ledger["assumed_price_usd"] not in [1, 5]:
        continue
    price = ledger["assumed_price_usd"]
    metadata = {k: v for k, v in ledger.items() if k != "trace"}
    cash_metadata.append(metadata)
    opening = {k: 0 for k in ledger["trace"][0]}
    opening.update(month=0, suspended=False, candidate_admitted=False,
                   cash_balance_usd=ledger["initial_external_endowment_usd"] - ledger["setup_cash_outflow_at_month_zero_usd"],
                   operating_reserve_target_usd=ledger["trace"][0]["operating_reserve_target_usd"])
    for row in [opening] + ledger["trace"]:
        cash_rows.append(dict(assumed_price_usd=price, scenario="reference",
                              configuration="original_upkeep", **row))
write_csv("cash_reference_1_5.csv", cash_rows)

family_rows = [u for u in R["unit_results"] if u["scenario"] == "reference"
               and u["route"] == "modeled_model_extension" and u["attempts_per_month"] == 1000]
write_csv("family_thresholds_reference.csv", [{k: r[k] for k in [
    "family", "median_wage_hourly_usd", "estimated_employer_hourly_usd",
    "fully_loaded_pretax_usd_per_accepted", "break_even_human_minutes_wage_only",
    "break_even_human_minutes_employer_proxy", "break_even_human_minutes_wage_with_extra_attention"
]} for r in family_rows])

market_rows = []
occupation_rows = []
for m in R["market"]:
    market_rows.append(dict(scenario=m["scenario"], **m["totals"],
                           **{f"expected_capacity_capped_revenue_at_price_{p}": v
                              for p, v in m["capacity_cap_with_reference_common_shocks_by_assumed_price"].items()}))
    for d in m["occupations"]:
        o = O[d["occupation_id"]]
        occupation_rows.append(dict(scenario=m["scenario"], soc=o["soc"],
                                    occupation=o["occupation"], mean_hourly_wage_usd=o["mean_hourly_wage_usd"],
                                    median_hourly_wage_usd=o["median_hourly_wage_usd"],
                                    assumed_annual_hours=P["market"]["scenarios"][m["scenario"]]["annual_hours"], **d))
write_csv("market_funnel.csv", market_rows)
write_csv("market_occupations.csv", occupation_rows)
write_json("data/figure_data.json", {
    "study_id": "AWE-2026-01", "status": "FROZEN_SCENARIO_EXPORT_NOT_NEW_EXPERIMENT",
    "currency": "USD", "input_sha256": INPUT_HASHES,
    "cost_tiers_1000": tiers, "cost_vs_volume": volumes,
    "cash_reference_1_5": cash_rows, "cash_metadata": cash_metadata,
    "market_funnel": market_rows, "market_assumptions": P["market"]["scenarios"],
    "market_occupations": occupation_rows,
    "figure_notes": {
        "tiers": "Nested tiers: stack marginal, recurring addition, setup addition; do not stack the three cumulative totals.",
        "volume": "Attempted jobs per month excludes their extra computational retry passes. Same assumed mix and acceptance across family rows.",
        "cash": "Month 0 cash is external endowment less setup outflow. No customer payments observed. Original upkeep only; future monthly commitments assumed suspendible.",
        "market": "Annual wage-equivalent is employment times mean hourly wage times assumed hours, not observed payroll or GDP. Filters are assumptions.",
        "auto_upkeep": "Separately frozen NOT_RUN sensitivity; no cash ledger recomputed for it."
    }
})

scenarios = P["scenario_labels"]
labels = {"efficient": "Efficient", "reference": "Reference", "stress": "Stress"}
rows = []
assumption_fields = [
    ("Model-token multiplier", "model_token_multiplier", lambda x: f"{x:g}"),
    ("Extension normal acceptance", "extension_final_acceptance_probability", lambda x: f"{100*x:g}\\%"),
    ("Extension retry probability", "extension_retry_probability", lambda x: f"{100*x:g}\\%"),
    ("Monthly common-shock probability", "common_shock_month_probability", lambda x: f"{100*x:g}\\%"),
    ("Shock acceptance retention", "shock_acceptance_retention", lambda x: f"{100*x:g}\\%"),
    ("Maintenance hours/month", "maintenance_hours_per_month", lambda x: str(x)),
    ("Administration hours/month", "business_admin_hours_per_month", lambda x: str(x)),
    ("Shared setup hours", "setup_development_hours", lambda x: str(x)),
    ("Platform/archive USD/month", "shared_platform_archive_usd_per_month", lambda x: str(x)),
    ("Collection fraction", "collection_fraction", lambda x: f"{100*x:g}\\%"),
    ("Refund fraction", "refund_fraction", lambda x: f"{100*x:g}\\%"),
    ("Collection delay (months)", "collection_delay_months", lambda x: str(x)),
    ("Additional customer minutes", "customer_incremental_minutes", lambda x: str(x))]
for title, key, fmt in assumption_fields:
    rows.append([title] + [fmt(P["scenarios"][s][key]) for s in scenarios])
for title, prob, minutes in [("Normal exception: probability / min", "normal_exception_probability", "normal_exception_minutes"),
                             ("Rare exception: probability / min", "rare_exception_probability", "rare_exception_minutes")]:
    rows.append([title] + [f"{100*P['scenarios'][s][prob]:g}\\% / {P['scenarios'][s][minutes]}" for s in scenarios])
table("economic_assumptions.tex", "Selected production assumptions; none is an observed production frequency.",
      "tab:ec-assumptions", "lrrr", ["Assumption", "Efficient", "Reference", "Stress"], rows,
      "At most one computational retry; shock extra-retry probabilities are 0.10/0.20/0.30 and recovery hours 2/8/24. "
      "Tool-route normal acceptance is 0.995/0.98/0.90 and retry probability 0.01/0.05/0.15. "
      "Setup is shared across four families and recovered over 12 months. Fees are assumed 3\\% plus USD 0.30 per collected invoice.")

rows = []
for cfg, title in [("original_upkeep", "Original"), ("automatic_upkeep_sensitivity", "Automatic upkeep")]:
    for s in scenarios:
        r = next(r for r in tiers if r["configuration"] == cfg and r["scenario"] == s and r["route"] == "modeled_model_extension")
        rows.append([title, labels[s]] + [f"{r[k]:.3f}" for k in ["marginal_usd_per_accepted", "recurring_usd_per_accepted", "fully_loaded_pretax_usd_per_accepted"]])
table("cost_tiers.tex", "Model-extension costs at 1,000 attempted jobs/month (USD per accepted result).",
      "tab:ec-tiers", "llrrr", ["Configuration", "Scenario", "Marginal", "Recurring", "Full"], rows,
      "All figures are modeled, pre-tax costs. Recurring and full are cumulative tiers. Payment fees, refunds, and noncollection enter the receipt ledger separately. "
      "Automatic upkeep is a separately frozen NOT RUN sensitivity; original cash ledgers are unchanged.")

rows = []
for route, title in [("modeled_tool_delivery", "Hosted tool"), ("modeled_model_extension", "Model extension")]:
    for s in scenarios:
        vals = [next(r for r in R["portfolio"] if r["route"] == route and r["scenario"] == s and r["attempts_per_month"] == v)["fully_loaded_pretax_usd_per_accepted"] for v in [100, 1000, 10000]]
        rows.append([title, labels[s]] + [f"{v:.3f}" for v in vals])
table("cost_volume.tex", "Original-upkeep full cost versus attempted monthly volume (USD per accepted result).",
      "tab:ec-volume", "llrrr", ["Modeled route", "Scenario", "100", "1,000", "10,000"], rows,
      "The hosted-tool route prices a hypothetical deployment of observed bounded software. The model-extension route adds unexecuted semantic stages. "
      "Neither route is an observed invoice. All volumes assume demand, qualification, and an equal four-family mix.")

family_names = {"quotes": "Quotes", "brief": "Fact brief", "plan": "Plan", "software": "Source repair"}
rows = [[family_names[r["family"]], f"{r['fully_loaded_pretax_usd_per_accepted']:.3f}"] + [f"{r[k]:.2f}" for k in ["break_even_human_minutes_wage_only", "break_even_human_minutes_employer_proxy", "break_even_human_minutes_wage_with_extra_attention"]] for r in family_rows]
table("family_thresholds.tex", "Reference extension: human break-even minutes at 1,000 attempts/month.",
      "tab:ec-thresholds", "lrrrr", ["Family", "Cost USD", "Wage", "Employer", r"Wage + attention"], rows,
      "Wage-only uses occupation median hourly earnings; employer uses a broad ECEC total/wage multiplier. "
      "The final column adds three customer minutes at USD 46.89/hour to the automated cost. "
      "These thresholds do not measure how long competent humans require, and exclude price markup.")

reference_market = next(m for m in R["market"] if m["scenario"] == "reference")
occ_short = {"procurement_clerks": "Procurement clerks", "technical_writers": "Technical writers",
             "planning_clerks": "Planning clerks", "computer_programmers": "Computer programmers"}
rows=[]
for item in reference_market["occupations"]:
    o=O[item["occupation_id"]]
    rows.append([occ_short[o["id"]], o["soc"], f"{o['employment']:,}", f"{o['mean_hourly_wage_usd']:.2f}",
                 f"{o['median_hourly_wage_usd']:.2f}", f"{item['annualized_wage_equivalent_usd']/1e9:.3f}"])
table("labor_sources.tex", "U.S. occupational neighbors and annual wage-equivalent at an assumed 1,800 hours.",
      "tab:ec-labor", "llrrrr", ["Occupation", "SOC", "Jobs", "Mean/h", "Median/h", "USD bn"], rows,
      "BLS May 2025 OEWS, released May 2026; hourly wages are USD and exclude nonwage benefits \\cite{blsoews2025,blsoewsfaq}. "
      "Employment includes full- and part-time wage/salary jobs and excludes self-employment. "
      "The last column is employment $\\times$ mean hourly wage $\\times$ assumed annual hours; it is not observed payroll or GDP.")

market_labels=["conservative", "reference", "expansive"]
rows=[["Annual hours"]+[str(P["market"]["scenarios"][s]["annual_hours"]) for s in market_labels]]
for oid in P["market"]["selected_occupation_ids"]:
    rows.append([f"Digital share: {occ_short[oid].lower()}"]+[f"{100*P['market']['scenarios'][s]['digital_share'][oid]:g}\\%" for s in market_labels])
for title,key in [("Supported share of digital tasks", "supported_task_share"), ("Permitted-input share", "permission_input_share"),
                  ("Adoption", "adoption"), ("Provider share", "provider_share"), ("Price / human labor value", "price_capture_of_human_labor")]:
    rows.append([title]+[f"{100*P['market']['scenarios'][s][key]:g}\\%" for s in market_labels])
rows.append(["Capacity: attempted jobs/month"]+[f"{P['market']['scenarios'][s]['capacity_attempts_per_month']:,}" for s in market_labels])
table("market_assumptions.tex", "Bottom-up market filters: all entries are assumptions.",
      "tab:ec-market-assumptions", "lrrr", ["Input", "Conservative", "Reference", "Expansive"], rows,
      "These filters are not measured occupation time shares or customer behavior. Capacity is a conditional planning input, "
      "and does not establish qualified throughput, demand, or available finance.")

market_specs = [("Annual wage-equivalent (USD bn)", "annualized_wage_equivalent_usd", 1e9, 3),
                ("Digital task value (USD bn)", "digital_task_wage_equivalent_usd", 1e9, 3),
                ("Technically supported (USD m)", "technically_supported_scenario_usd", 1e6, 3),
                ("Permitted-input subset (USD m)", "permitted_input_scenario_usd", 1e6, 3),
                ("Adopted labor value (USD m)", "adopted_serviceable_labor_value_usd", 1e6, 3),
                ("Provider revenue before caps (USD)", "unconstrained_provider_revenue_scenario_usd", 1, 2)]
rows=[]
for title,key,scale,digits in market_specs:
    rows.append([title]+[f"{next(m for m in R['market'] if m['scenario']==s)['totals'][key]/scale:,.{digits}f}" for s in market_labels])
table("market_results.tex", "Selected-occupation opportunity sensitivities; potential annual values, not forecasts.",
      "tab:ec-market-results", "lrrr", ["Stage", "Conservative", "Reference", "Expansive"], rows,
      "Reference provider revenue is USD 14,479.56 before capacity and collections. "
      "Using shock-adjusted assumed acceptance 0.891, the reference capacity ceiling at a USD 1 price is USD 10,692/year. "
      "The market funnel and unit-cost price/volume grids are independent sensitivities, not a jointly validated demand forecast.")

rows=[]
for price in [1,5]:
    ledger=next(l for l in R["cash_constrained_ledgers"] if l["scenario"]=="reference" and l["assumed_price_usd"]==price)
    trace=ledger["trace"]
    suspended=next((str(r["month"]) for r in trace if r["suspended"]), "None")
    rows.append([str(price), f"{sum(r['funded_attempts'] for r in trace):,}", suspended,
                 f"{trace[-1]['cash_balance_usd']:,.2f}", f"{trace[-1]['available_generated_surplus_usd']:,.2f}"])
table("cash_summary.tex", "Cash-constrained reference ledger over 12 months; original upkeep only.",
      "tab:ec-cash", "rrrrr", ["Price USD", "Funded jobs", "First suspension", "Final cash USD", "Earned surplus USD"], rows,
      "Both start with USD 13,492.81 external endowment, including USD 6,048.30 setup, collection-delay working capital, and a two-month reserve. "
      "No receipts are observed. Funded jobs exclude computational retry passes. Surplus preserves setup recovery, operating reserves, and an illustrative obligation allowance. "
      "The USD 5 case can finance the assumed candidate in month 11; neither case admits an investment.")

# Compact interface for a client that prefers exact frozen lookup over reimplementing cost accounting.
demo = {
    "study_id": "AWE-2026-01", "schema": "awe-study-demo-economics/v1",
    "input_sha256": INPUT_HASHES,
    "status": "SCENARIO_LOOKUP_AND_FRESH_ARITHMETIC_NOT_OBSERVED_PRICES_OR_COSTS",
    "currency": "USD", "default_route": "modeled_tool_delivery", "default_configuration": "original_upkeep",
    "volume_basis": "Total attempted portfolio jobs/month; four families at 25% each. Quote unit cost uses a share of fixed costs allocated across that portfolio.",
    "portfolio_family_weights": {f["id"]: f["weight"] for f in P["families"]},
    "labels": {
        "modeled_tool_delivery": {"en": "Hypothetical hosted tool delivery", "fr": "Livraison outillée avec hébergement hypothétique"},
        "modeled_model_extension": {"en": "Proposed model extension — NOT RUN", "fr": "Extension proposée avec modèles — NON EXÉCUTÉE"},
        "actual_local_total_cost": {"en": "Actual local total cost: unknown", "fr": "Coût total local réel : inconnu"},
        "arithmetic": {"en": "Fresh arithmetic using scenario assumptions", "fr": "Nouveau calcul utilisant les hypothèses du scénario"}
    },
    "scenarios": P["scenarios"], "fees": {"fraction": .03, "fixed_usd_per_collected_invoice": .30},
    "customer_hourly_proxy_usd": R["rates"]["support_hourly_usd"],
    "quote_unit_rows": [r for r in R["unit_results"] if r["family"] == "quotes"],
    "portfolio_upkeep_rows": U["results"],
    "cash_reference_1_5": cash_rows, "cash_metadata": cash_metadata,
    "price_grid_usd": P["numerical_grid"]["prices_usd"],
    "attempt_volume_grid": P["numerical_grid"]["attempts_per_month"],
    "rates_sources": [s for s in S["sources"] if s["id"] in ["BLS_OEWS_2025", "BLS_ECEC_2026Q2", "OPENAI_SOL_20261025", "OPENAI_TOOLS_20261025"]],
    "limits": ["Unknown actual costs are not zero.", "Production acceptance is assumed, not inferred from fixtures.",
               "Payment delay means expected economic contribution is not available monthly cash.",
               "Customer savings require equivalent work, quality, revision and acceptance responsibilities.",
               "Automatic-upkeep output is portfolio-level; do not substitute it into the quote-only row.",
               "No simulated margin or funding result establishes a customer payment or capability promotion."]
}
write_json("demo_economics.json", demo)
(HERE / "economics_references.bib").write_bytes((ECON / "references.bib").read_bytes())

# Validate exports against frozen source values and separately evaluate the advertised receipt formula.
assert len(volumes) == 36 and len(tiers) == 12 and len(cash_rows) == 26
assert len(demo["quote_unit_rows"]) == 18
for r in demo["quote_unit_rows"]:
    s=P["scenarios"][r["scenario"]]
    floor=r["pretax_customer_price_floor_usd_including_modeled_noncollection_refund_fees"]
    net=s["collection_fraction"]*((1-s["refund_fraction"]-.03)*floor-.30)
    assert abs(net-r["fully_loaded_pretax_usd_per_accepted"]) < 1e-10
for record in tiers:
    assert abs(record["marginal_usd_per_accepted"] + record["recurring_addition_over_marginal_usd"]
               + record["setup_addition_over_recurring_usd"] - record["fully_loaded_pretax_usd_per_accepted"]) < 1e-10
write_json("export_validation.json", {"status": "PASS", "input_sha256": INPUT_HASHES,
                                    "checks": {"volume_rows": 36, "tier_rows": 12, "cash_rows_including_month_zero": 26,
                                               "quote_rows": 18, "quote_price_floor_equalities": 18, "tier_stack_equalities": 12},
                                    "scope": "Publication export integrity and interface arithmetic, not new execution or independent economic validation."})
print("PASS: frozen exports, tables, citations and demo lookup generated without modifying economics/.")
