# Economics manuscript and demo support

This directory exports the frozen `../economics/` evidence. It does not modify any frozen source, protocol, scenario, result, or previous edition.

## Manuscript

`economics_sections.tex` is an insertable section with explicit equations, evidence boundaries, source identities, and quantitative tables. It requires `amsmath`, `booktabs`, and `url` or `hyperref`. Set `\AWEpaperSupportPath` to this directory relative to the LaTeX working directory before including it. Its default is `../paper_support`. Bibliography: `economics_references.bib`; citation keys are identical to the frozen economics bibliography.

Every table under `tables/` is generated directly from the frozen JSON. Whole-table notes distinguish per-attempt volume, per-accepted cost, hypothetical hosted tool deployment, unexecuted model extension, automatic-upkeep sensitivity, and unobserved customer behavior. All USD values are nominal and pre-tax unless explicitly identified as reserves or receipts. Additional source-refresh runtime clarification changed no numerical result.

The economic section deliberately does **not** call the original capsule sequence a held-out test: it reused confirmation inputs. Root is adding a separate prospective transfer extension; report its evidence and count separately.

The final interoperability paragraph concerns the additive adapter under `../publication/shared-contract/`, based on the pinned open PR 4907 candidate. Its fully loaded/recurring totals align subject to integer rounding, but shared **marginal** includes variable human exceptions while the study's **marginal execution** excludes them. Shared aggregate-wage thresholds are not substitutes for the paper's family-specific human comparisons. Schema validation is pure arithmetic, not proof of an authenticated runtime or a merged release.

## Figure data

- `data/cost_tiers_1000.csv`: both routes and upkeep configurations, all three scenarios. Marginal/recurring/full are cumulative tiers; use the incremental columns for a stacked bar.
- `data/cost_vs_volume.csv`: the existing 100/1,000/10,000 monthly attempt grid, both routes and upkeep configurations. No interpolation or new economic assumption is introduced.
- `data/cash_reference_1_5.csv`: the **original-upkeep model-extension reference** cash-constrained USD 1/USD 5 trajectories. Month zero is external cash after setup, not customer income.
- `data/family_thresholds_reference.csv`: the four-family reference thresholds.
- `data/market_funnel.csv` and `data/market_occupations.csv`: exact bottom-up stage values and occupational source facts.
- `data/figure_data.json`: same exports with source hashes, assumptions, ledger metadata, and plotting notes.

Do not graph three cumulative cost tiers as additive segments. Do not relabel the original cash traces as automatic-upkeep results. Do not combine the reference market/provider share with all profitable high-volume price scenarios as if demand were jointly established.

## Demo

`demo_economics.json` contains exact quote-row lookups, bilingual status labels, source metadata, and the separate portfolio sensitivities. `demo_interface.md` specifies accounting and presentation. `demo_calculator.mjs` is a pure function for fresh interactive arithmetic, with no external operations. Changing a slider is not recorded execution, an accepted deliverable, or a customer transaction.

## Reproduction

Run `python3 paper_support/build_support.py` from the study root. It only writes this directory. `export_validation.json` records export-integrity checks and source hashes. The underlying independent economics audits remain in `../foundations/`; these export checks are not a new independent review of the economics.
