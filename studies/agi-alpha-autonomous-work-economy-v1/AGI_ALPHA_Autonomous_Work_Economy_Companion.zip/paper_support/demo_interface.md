# Economics interface for the offline demo

Use `demo_economics.json` as a frozen lookup. It contains the 18 quote rows: two modeled deployment routes, three scenario assumptions, and three monthly attempt volumes. It is an additive study interface, **not** the shared AGI ALPHA runtime schema.

## Display and default

Default to **Hypothetical hosted tool delivery** (`modeled_tool_delivery`) and the original upkeep assumptions. That is the closest monetary scenario to the deterministic quote calculator. The actual local total cost remains **unknown**. Its hosted-session cost is assumed, not a bill for the browser or local run.

Offer **Proposed model extension — NOT RUN** (`modeled_model_extension`) separately if desired. That row prices unexecuted model-mediated intake, explanation, and checking. It does not establish that those calls deliver equal quality.

The automatic-upkeep rows are a **separate portfolio sensitivity**, not a quote-only result. Do not substitute their costs into a quote row. No financial ledger was recomputed for them. The optional separate display must say that repair success and residual effort are unmeasured.

Select exactly one quote row matching `scenario`, `route`, and `attempts_per_month`. Use existing numeric fields unchanged. Label volume as **portfolio jobs per month**, excluding internal retry passes; `modeled_attempts_per_requested_job` records those passes. The frozen cost allocation assumes four workflow families at 25% each, with fixed costs shared across the whole portfolio. Expected accepted portfolio output is `N * assumed_expected_acceptance`; the expected quote share is one quarter of that total. Do not label the row's `expected_accepted_per_month` as measured quote output, and do not substitute the fixture acceptance percentage. The calculator exposes `expectedAcceptedPortfolioPerMonth` and `expectedAcceptedQuoteSharePerMonth` explicitly; its original `expectedAcceptedPerMonth` field is a portfolio-total alias.

## Fresh arithmetic

For price `P`, scenario `s`, and selected row `u`:

```javascript
const c = s.collection_fraction;
const z = s.refund_fraction;
const v = .03; // Assumed payment fee fraction.
const f0 = .30; // USD per collected invoice, assumed.
const netReceiptPerAccepted = c * ((1 - z - v) * P - f0);
const fullContributionPerAccepted =
  netReceiptPerAccepted - u.fully_loaded_pretax_usd_per_accepted;
const recurringContributionPerAccepted =
  netReceiptPerAccepted - u.recurring_delivery_usd_per_accepted;
const priceFloor =
  (u.fully_loaded_pretax_usd_per_accepted + c * f0) /
  (c * (1 - z - v));
const alternativeLaborValue = humanMinutes * humanHourlyWage / 60;
const automatedCustomerOutlay =
  P + extraCustomerMinutes * customerHourlyValue / 60;
const conditionalCustomerDifference =
  alternativeLaborValue - automatedCustomerOutlay;
const priceBreakEvenHumanMinutes =
  60 * automatedCustomerOutlay / humanHourlyWage;
```

The bundled `demo_calculator.mjs` implements these formulas and rejects invalid ranges. `priceFloor` must match the existing `pretax_customer_price_floor_usd_including_modeled_noncollection_refund_fees` field. Eighteen such equalities are checked in `build_support.py`.

This contribution is **expected economic contribution before tax or the illustrative obligation reserve**. It is not the amount of collected money available this month: receivables, delays, setup at month zero, working capital, and reserves must use the ledger. Never multiply it into a self-financing claim.

The household/customer comparison assumes equivalent task scope, quality, revisions, intake, and acceptance responsibilities. User-entered time and wage are assumptions, not observations of competent human performance or quotes from a human provider. Positive `conditionalCustomerDifference` means “lower modeled outlay under these inputs,” not “proven savings.” If scope differs, show that comparison as unavailable.

Default extra customer attention from the selected scenario; reference is three minutes. The default customer-hour value is the broad US private-industry compensation proxy USD 46.89/hour. The quote-family median wage defaults to USD 24.32/hour. Users may edit them, with a persistent “Fresh arithmetic using scenario assumptions” label. Price changes do not rerun an experiment.

## Cash and reinvestment

`cash_reference_1_5` is the frozen, cash-constrained reference extension ledger at prices USD 1 and USD 5, original upkeep only. A month-zero row is added as an export convenience: external endowment minus setup, not earned cash. `cash_metadata` retains both amounts. Do not interpolate a new cash path from endpoint differences, and do not substitute the selected quote row into this four-family portfolio ledger.

No candidate is admitted. At the assumed USD 5 price, sufficient earned surplus exists in month 11 for the illustrative eight-hour budget, but no monetary benefit justifies promotion. At USD 1, production contracts and first suspends in month five. No customer receipts, financial transactions, or scheduled paid actions occurred.

## Required visible qualifications

- **Actual total cost: unknown.** Runtime provider call count zero does not include authoring, construction, or the local host bill.
- **Scenario, not forecast.** Acceptance, exception rates, upkeep, price, demand, and collection behavior are assumptions.
- **Model extension: NOT RUN.** Interactive arithmetic is not authenticated orchestration.
- **Human time: user assumption.** Break-even is a threshold, not an observed duration.
- **Financing does not justify promotion.** No modeled growth or automatic investment is reported.

All copied rows carry source hashes. Wage facts are BLS May 2025; employer-cost proxies are June 2026; model/tool prices were retrieved October 25, 2026. Nominal USD, without an implicit inflation or currency conversion. The sources do not establish surveyed workers' AI use.
