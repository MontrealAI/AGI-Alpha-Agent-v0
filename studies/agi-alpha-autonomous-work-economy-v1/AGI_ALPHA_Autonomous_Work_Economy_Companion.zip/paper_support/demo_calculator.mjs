/** Pure scenario arithmetic. No provider calls, collection, or experiment execution. */
export function calculateScenario(data, options = {}) {
  const {
    scenario = 'reference', route = 'modeled_tool_delivery', attemptsPerMonth = 1000,
    price = 5, humanMinutes = 15, humanHourlyWage = 24.32,
    customerHourlyValue = data.customer_hourly_proxy_usd,
    extraCustomerMinutes = data.scenarios[scenario]?.customer_incremental_minutes,
    equivalentScope = true,
  } = options;
  const row = data.quote_unit_rows.find(r => r.scenario === scenario && r.route === route && r.attempts_per_month === attemptsPerMonth);
  if (!row) throw new RangeError('Select one frozen route, scenario, and monthly volume.');
  for (const [name, value] of Object.entries({price, humanMinutes, humanHourlyWage, customerHourlyValue, extraCustomerMinutes})) {
    if (!Number.isFinite(value) || value < 0 || (name === 'humanHourlyWage' && value === 0)) {
      throw new RangeError(`${name} must be finite and nonnegative; the human hourly wage must exceed zero.`);
    }
  }
  const s = data.scenarios[scenario], c = s.collection_fraction, z = s.refund_fraction;
  const {fraction: v, fixed_usd_per_collected_invoice: f0} = data.fees;
  const netReceiptPerAccepted = c * ((1 - z - v) * price - f0);
  const fullContributionPerAccepted = netReceiptPerAccepted - row.fully_loaded_pretax_usd_per_accepted;
  const recurringContributionPerAccepted = netReceiptPerAccepted - row.recurring_delivery_usd_per_accepted;
  const priceFloor = (row.fully_loaded_pretax_usd_per_accepted + c * f0) / (c * (1 - z - v));
  const alternativeLaborValue = humanMinutes * humanHourlyWage / 60;
  const automatedCustomerOutlay = price + extraCustomerMinutes * customerHourlyValue / 60;
  return {
    status: 'FRESH_ARITHMETIC_ON_FROZEN_ASSUMPTIONS', scenario, route,
    configuration: 'original_upkeep', currency: 'USD',
    assumptions: {scenario, route, attemptsPerMonth, price, humanMinutes, humanHourlyWage,
      customerHourlyValue, extraCustomerMinutes, equivalentScope}, input_sha256: data.input_sha256, row,
    netReceiptPerAccepted, fullContributionPerAccepted, recurringContributionPerAccepted, priceFloor,
    expectedAcceptedPerMonth: attemptsPerMonth * row.assumed_expected_acceptance,
    expectedAcceptedPortfolioPerMonth: attemptsPerMonth * row.assumed_expected_acceptance,
    expectedAcceptedQuoteSharePerMonth: attemptsPerMonth * row.assumed_expected_acceptance * data.portfolio_family_weights.quotes,
    volumeBasis: data.volume_basis,
    collectionDelayMonths: s.collection_delay_months,
    customerComparison: equivalentScope ? {
      status: 'CONDITIONAL_ON_EQUAL_SCOPE_AND_QUALITY', alternativeLaborValue, automatedCustomerOutlay,
      conditionalCustomerDifference: alternativeLaborValue - automatedCustomerOutlay,
      priceBreakEvenHumanMinutes: 60 * automatedCustomerOutlay / humanHourlyWage,
    } : {status: 'UNAVAILABLE_SCOPE_NOT_EQUIVALENT'},
    actualLocalTotalCost: null, observedPayments: false, capabilityPromotion: false,
    warning: 'Economic contribution is not currently collected or reinvestable cash. Production inputs and customer time are assumptions.',
  };
}
