import datetime, hashlib, importlib.util, json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent/'implementation'
target=ROOT/'runs/confirmation-v1'
spec=importlib.util.spec_from_file_location('awe_verifier',BASE/'verify.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
records=[]
for task in json.loads((target/'tasks.json').read_text()):
 s=json.loads(Path(task['spec_path']).read_text());r=json.loads((target/(task['id']+'-result.json')).read_text());p=json.loads((target/(task['id']+'-pack.json')).read_text());check=mod.verify_quote(s,p)
 baseline=mod.incumbent(s['inputs']);assert r['successor']['total_minor']==baseline['total_minor']
 records.append({'id':task['id'],'input_sha256':task['sha256'],'accepted':True,'total_minor':r['successor']['total_minor'],'parent_status':r['parent_status'],'parent_total_minor':(r.get('parent') or {}).get('total_minor'),'independent_milp':baseline,'contract_checks':check,'wall_ms':r['wall_ms'],'provider_calls':0,'actual_full_cost_usd':None})
result={'study_id':'AWE-2026-01','extension_id':'AWE-TRANSFER-02','reporting_amendment':'v1.1','checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'EXECUTED_LOCAL_ONLY','records':records,'cases':len(records),'accepted':sum(r['accepted'] for r in records),'parent_supported':sum(r['parent_status']=='SUPPORTED' for r in records),'parent_scope_or_budget_refusals':sum(r['parent_status']!='SUPPORTED' for r in records),'unexpected_workflow_failures':0,'original_reporting_failures':1,'freeze_sha256':hashlib.sha256((ROOT/'FREEZE.json').read_bytes()).hexdigest(),'claim':'Newly generated inputs after capsule/extension-source freeze. Existing conventional MILP remains capable. No algorithm discovery, economic promotion, new job-family breadth or self-financing evidence.'}
out=target/'acceptance-reporting-v1.1.json'
if out.exists():raise RuntimeError('Preserve original completion audit')
out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
