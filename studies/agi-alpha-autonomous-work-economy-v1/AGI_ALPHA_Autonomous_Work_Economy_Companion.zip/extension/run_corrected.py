import argparse, datetime, hashlib, importlib.util, json, random, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
BASE=ROOT.parent/'implementation'
def dump(p,d): p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def spec(seed,n,m,mixed):
 r=random.Random(seed);vendors=[f'Vendor-{j+1}' for j in range(m)]
 items=[{'id':f'part-{i+1:02d}','label':f'Equipment item {i+1}','quantity':r.randint(1,30)} for i in range(n)]
 offers=[{'item':i['id'],'vendor':v,'pack_units':r.choice([1,2,4,6]) if mixed else 1,'pack_price_minor':r.randint(20,24000),'currency':r.choice(['USD','CAD','EUR']) if mixed else 'USD','lead_days':1 if j==0 else r.randint(1,9)} for i in items for j,v in enumerate(vendors)]
 if mixed: offers[0]['pack_units']=2;offers[0]['currency']='CAD'
 return {'schema':'successor-workbench/v1','family':'awe-quotes-transfer','name':f'Prospective transfer {seed}','language':'en','owner':'AWE-2026-01-public-local','rights':{'dataClass':'synthetic','source':'Prospective generator frozen after retained capsule, before these inputs','license':'Apache-2.0'},'reviewMinutes':1,'inputs':{'title':f'Transfer basket {seed}','base_currency':'USD','deadline_days':6,'items':items,'shipping_minor':{v:r.randint(0,5000) for v in vendors},'fx':{'USD':{'num':1,'den':1,'source':'Synthetic identity'},'CAD':{'num':37,'den':50,'source':'Synthetic reproducible ratio, not a quote'},'EUR':{'num':27,'den':25,'source':'Synthetic reproducible ratio, not a quote'}},'offers':offers}}
def freeze():
 p=ROOT/'FREEZE.json'
 if p.exists(): raise RuntimeError('Freeze already exists')
 files=[ROOT/'run.py',ROOT/'run.mjs',ROOT/'protocol.json',BASE/'adapters.mjs',BASE/'verify.py',BASE/'capabilities/quote-v1.mjs',BASE/'capabilities/quote-v2.mjs']
 files += list((BASE/'vendor/alpha').rglob('*.mjs'))
 dump(p,{'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':{str(f.relative_to(ROOT.parent)):sha(f) for f in files},'before_input_generation':True})
 print(json.dumps({'freeze_sha256':sha(p),'files':len(files)}))
def confirm(run_id):
 frozen=json.loads((ROOT/'FREEZE.json').read_text())
 for name,digest in frozen['files'].items():
  if sha(ROOT.parent/name)!=digest: raise RuntimeError('Frozen source changed: '+name)
 target=ROOT/'runs'/run_id
 target.mkdir(parents=True,exist_ok=False)
 protocol=json.loads((ROOT/'protocol.json').read_text())
 tasks=[]
 for j,row in enumerate(protocol['cases']):
  s=spec(**row);p=target/f'T{j+1}.json';dump(p,s);tasks.append({'id':f'T{j+1}','spec_path':str(p),'sha256':sha(p)})
 dump(target/'tasks.json',tasks)
 subprocess.run(['node',str(ROOT/'run.mjs'),str(target)],check=True)
 v=importlib.util.spec_from_file_location('awe_verifier',BASE/'verify.py');mod=importlib.util.module_from_spec(v);v.loader.exec_module(mod)
 records=[]
 for task in tasks:
  s=json.loads(Path(task['spec_path']).read_text());run=json.loads((target/(task['id']+'-result.json')).read_text());pack=json.loads((target/(task['id']+'-pack.json')).read_text())
  check=mod.verify_quote(s,pack);actual=run['successor']['total_minor'];expected=check['total_minor'] if 'total_minor' in check else mod.incumbent(s['inputs'])['total_minor']
  if actual!=expected: raise RuntimeError('Successor mismatch')
  records.append({'id':task['id'],'input_sha256':task['sha256'],'accepted':True,'total_minor':actual,'parent_status':run['parent_status'],'parent_total_minor':(run.get('parent') or {}).get('total_minor'),'independent_milp':check,'wall_ms':run['wall_ms'],'successor_sha256':sha(BASE/'capabilities/quote-v2.mjs'),'provider_calls':0,'actual_total_cost_usd':None})
 summary={'study_id':'AWE-2026-01','extension_id':'AWE-TRANSFER-02','status':'EXECUTED_LOCAL_ONLY','freeze_sha256':sha(ROOT/'FREEZE.json'),'cases':len(records),'accepted':sum(r['accepted'] for r in records),'parent_supported':sum(r['parent_status']=='SUPPORTED' for r in records),'parent_scope_or_budget_refusals':sum(r['parent_status']!='SUPPORTED' for r in records),'records':records,'claim':'Newly generated inputs after capsule and extension-source freeze; bounded conditional transfer, not novel discovery, full authenticated operation or economic promotion. Separate from primary 24-case census.'}
 dump(target/'acceptance.json',summary);print(json.dumps(summary))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--freeze',action='store_true');p.add_argument('--run-id');a=p.parse_args()
 if a.freeze:freeze()
 elif a.run_id and a.run_id.replace('-','').isalnum():confirm(a.run_id)
 else:p.error('Choose --freeze or a new --run-id')
