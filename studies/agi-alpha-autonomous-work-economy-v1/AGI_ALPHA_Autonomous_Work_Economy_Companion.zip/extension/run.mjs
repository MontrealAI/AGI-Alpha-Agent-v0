import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {createWorkbench} from '../implementation/vendor/alpha/examples/successor-workbench/engine.mjs';
import {normalizeQuotes} from '../implementation/adapters.mjs';
import {solve as parentSolve} from '../implementation/capabilities/quote-v1.mjs';
import {solve} from '../implementation/capabilities/quote-v2.mjs';
const target=process.argv[2];
const tasks=JSON.parse(await fs.readFile(path.join(target,'tasks.json'),'utf8'));
const sourceHash=crypto.createHash('sha256').update(await fs.readFile(new URL('./FREEZE.json',import.meta.url))).digest('hex');
const save=async(p,d)=>fs.writeFile(path.join(target,p),JSON.stringify(d,null,2)+'\n');
const csv=x=>'"'+String(x).replaceAll('"','""')+'"';
const adapter={manifest:{id:'awe-quotes-transfer',version:1,en:'Retained quote capability',fr:'Capacité de devis conservée',scope:'Prospective transfer using fixed retained capsule',artifact:'quote-report.md'},validate:normalizeQuotes,execute:async(input,checkpoint)=>{
 await checkpoint('invoke-retained-capsule');const n=normalizeQuotes(input),r=solve(input);
 await checkpoint('package-and-check');const checks={one_offer_per_item:new Set(r.selected.map(x=>x.item)).size===n.items.length,quantities:r.selected.every(x=>x.delivered_units>=x.quantity),deadlines:r.selected.every(x=>x.lead_days<=n.deadline_days),exact_arithmetic:r.total_minor===r.line_total_minor+r.shipping_minor};
 if(!Object.values(checks).every(Boolean))throw Error('TRANSFER_CONTRACT');
 const report='# '+input.title+'\n\nRecommended cart: '+(r.total_minor/100).toFixed(2)+' USD. Synthetic example; no purchasing.\n\n'+r.selected.map(x=>x.label+': '+x.vendor+', '+x.delivered_units+' units, '+(x.landed_line_minor/100).toFixed(2)+' USD.').join('\n')+'\n\nShipping '+(r.shipping_minor/100).toFixed(2)+' USD. Retained capsule actually executed; independent MILP checked separately.\n';
 return {decision:'QUOTE_REPORT_READY_FOR_REVIEW',summary:{total_minor:r.total_minor,items:n.items.length},evidence:{normalized:n,solution:r,checks},artifacts:[{name:'quote-report.md',type:'text/markdown',content:report},{name:'quote-analysis.json',type:'application/json',content:JSON.stringify({normalized:n,solution:r,checks},null,2)+'\n'},{name:'recommended-cart.csv',type:'text/csv',content:'item,vendor,quantity,line_minor\n'+r.selected.map(x=>[x.item,x.vendor,x.delivered_units,x.landed_line_minor].map(csv).join(',')).join('\n')+'\n'}],limits:['Synthetic inputs','Full authenticated workflow NOT RUN','Conventional MILP retained','Economic admission HOLD']};}};
const wb=createWorkbench([adapter]);
for(const task of tasks){const s=JSON.parse(await fs.readFile(task.spec_path,'utf8'));let parent=null,parent_status='SUPPORTED';try{parent=parentSolve(s.inputs);}catch(e){parent_status=e.message;}
 const t=performance.now();const pack=await wb.run(s,{sourceHash});await wb.inspectPack(pack);const wall_ms=performance.now()-t;const successor=pack.result.evidence.solution;
 await save(task.id+'-pack.json',pack);await save(task.id+'-result.json',{parent,parent_status,successor,wall_ms,provider_calls:0,total_cost_usd:null});
}
