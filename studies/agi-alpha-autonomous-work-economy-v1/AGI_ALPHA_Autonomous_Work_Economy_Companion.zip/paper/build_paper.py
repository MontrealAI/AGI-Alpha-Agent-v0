import csv, json, re
from pathlib import Path
ROOT=Path(__file__).resolve().parent
STUDY=ROOT.parent
support=STUDY/'paper_support'
body=(ROOT/'body.tex').read_text()
econ=(support/'economics_sections.tex').read_text()
econ=re.sub(r'(?m)^%[^\n]*\n','',econ)
econ=econ.replace('\\providecommand{\\AWEpaperSupportPath}{../paper_support}','').replace('\\section{Economic evaluation}','').replace('\\label{sec:economics}','')
econ=re.sub(r'\\input\{\\AWEpaperSupportPath/tables/([^}]+)\}',lambda m:(support/'tables'/m[1]).read_text(),econ)
body=body.replace('ECONOMICS_SECTION_PLACEHOLDER',econ)
body=body.replace('\\paragraph{Additive schema interoperability.}', '\\paragraph{Schema compatibility.}').replace('\\texttt{alpha-automated-costs/v1}', '\\path{alpha-automated-costs/v1}')
costs=list(csv.DictReader((support/'data/cost_vs_volume.csv').open()))
results=json.loads((STUDY/'economics/results/economic_results.json').read_text())
portfolio=results['portfolio']
def coords(rows,x,y):return ' '.join(f'({r[x]},{r[y]})' for r in rows)
print('Portfolio keys:',list(portfolio[0]))
costlines=[]
for scenario,color,mark in [('efficient','teal','square*'),('reference','purple','*'),('stress','coral','triangle*')]:
 rows=[r for r in portfolio if r['route']=='modeled_model_extension' and r['scenario']==scenario]
 xv='attempts_per_month';yv='fully_loaded_pretax_usd_per_accepted'
 if yv not in rows[0]:yv=next(k for k in rows[0] if 'full' in k and 'cost' in k)
 costlines.append(r'\addplot+[color='+color+',mark='+mark+',line width=1.2pt] coordinates {'+coords(rows,xv,yv)+'};\n'+r'\addlegendentry{'+scenario.title()+'}')
costfig=r'''\begin{tikzpicture}
\begin{axis}[width=0.96\linewidth,height=6.0cm,xmode=log,ymode=log,xmin=90,xmax=12000,ymin=0.2,ymax=150,xtick={100,1000,10000},xticklabels={100,"1,000","10,000"},xlabel={Attempted portfolio jobs per month},ylabel={Modeled USD per accepted output},grid=major,grid style={gray!18},axis line style={gray!50},tick label style={font=\small},label style={font=\small},legend style={at={(0.5,1.04)},anchor=south,legend columns=3,draw=none,font=\small}]
'''+ '\n'.join(costlines)+r'''
\end{axis}\end{tikzpicture}'''
costfig=costfig.replace('{100,"1,000","10,000"}','{100,{1,000},{10,000}}')
transferfig=r'''\begin{tikzpicture}
\begin{axis}[width=0.96\linewidth,height=5.4cm,ybar,bar width=27pt,ymin=0,ymax=9,ytick={0,2,4,6,8},symbolic x coords={Installed v1,Retained v2,Conventional MILP},xtick=data,ylabel={Accepted new baskets out of eight},nodes near coords,point meta=y,grid=major,grid style={gray!15},axis line style={gray!50},tick label style={font=\small},label style={font=\small},enlarge x limits=0.25]
\addplot[fill=purple!75,draw=purple] coordinates {(Installed v1,2) (Retained v2,8) (Conventional MILP,8)};
\end{axis}\end{tikzpicture}'''
cashlines=[]
for price,color,mark in [(1,'coral','square*'),(5,'purple','*')]:
 ledger=next(r for r in results['cash_constrained_ledgers'] if r['scenario']=='reference' and r['assumed_price_usd']==price)
 rows=[{'month':0,'cash_balance_usd':ledger['initial_external_endowment_usd']-ledger['setup_cash_outflow_at_month_zero_usd']},*ledger['trace']]
 cashlines.append(r'\addplot+[color='+color+',mark='+mark+',line width=1.2pt] coordinates {'+coords(rows,'month','cash_balance_usd')+'};\n'+r'\addlegendentry{Assumed price USD '+str(price)+'}')
cashfig=r'''\begin{tikzpicture}
\begin{axis}[width=0.96\linewidth,height=5.8cm,xmin=0,xmax=12,ymin=0,xlabel={Month},ylabel={Modeled cash balance (USD)},xtick={0,2,4,6,8,10,12},scaled y ticks=false,y tick label style={/pgf/number format/fixed,/pgf/number format/precision=0},grid=major,grid style={gray!18},axis line style={gray!50},tick label style={font=\small},label style={font=\small},legend style={at={(0.5,1.04)},anchor=south,legend columns=2,draw=none,font=\small}]
'''+ '\n'.join(cashlines)+r'''
\end{axis}\end{tikzpicture}'''
figs={'awe-costs.tex':costfig,'awe-transfer.tex':transferfig,'awe-cash.tex':cashfig}
body=body.replace('\\subsection{Human thresholds and customer value}',r'''\begin{figure}[htbp]\centering\input{awe-costs.tex}
\caption{Prospective model-extension full cost under original upkeep. Both axes are logarithmic. Fixed-cost dilution depends on unobserved qualified demand; this is a scenario grid, not a learning curve or a measured invoice.}\label{fig:costs}
\end{figure}
\subsection{Human thresholds and customer value}''')
body=body.replace('\\subsection{Restricted bottom-up opportunity}',r'''\begin{figure}[htbp]\centering\input{awe-cash.tex}
\caption{Cash-constrained reference simulations. Month zero is external funding less setup. Cash includes restricted obligations and reserves and is not synonymous with reinvestable surplus. No customer payments were observed.}\label{fig:cash}
\end{figure}
\subsection{Restricted bottom-up opportunity}''')
bib=(support/'economics_references.bib').read_text()
extra=[('alphaevolve2025','Alexander Novikov and others','AlphaEvolve: A Coding Agent for Scientific and Algorithmic Discovery','2025','https://arxiv.org/abs/2506.13131'),('criticgpt2024','Nat McAleese and others','LLM Critics Help Catch LLM Bugs','2024','https://arxiv.org/abs/2407.00215'),('scipymilp','{SciPy developers}','scipy.optimize.milp: Mixed-Integer Linear Programming','2026','https://docs.scipy.org/doc/scipy/reference/generated/scipy.optimize.milp.html')]
repos={'alphasource':('AGI-Alpha-Agent-v0','a026e68413ab2e2d6086c758efc8abff723fdfe4'),'managersource':('AGIJobManager','5d5670df9dbbc79da115e0a44b71989f34df58c1'),'jobssource':('AGIJobsv0','bc4abbd5c28f3672275b13300e40ea26c820b8ee'),'fleetsource':('AGI-Fleet-Linux','45759fb096faf8988f58ae5ea71248d0f35a97c7')}
for key,(name,commit) in repos.items():extra.append((key,'{MONTREAL.AI}',name+': Pinned Public Source','2026','https://github.com/MontrealAI/'+name+'/tree/'+commit))
manifest=json.loads((STUDY/'foundations/source_manifest.json').read_text())
for key,path in [('managercontract','contracts/AGIJobManager.sol'),('ascensioncontract','contracts/ascension/AscensionJobMarket.sol'),('markcontract','contracts/ascension/AscensionMark.sol'),('feepoolcontract','contracts/v2/FeePool.sol')]:
 row=next(r for r in manifest if r['path']==path);extra.append((key,'{MONTREAL.AI}',path.replace('_',r'\_')+': Inspected Contract Source','2026',row['source_url']))
for key,author,title,year,url in extra:bib+='\n@misc{'+key+',\n author={'+author+'},\n title={'+title+'},\n year={'+year+'},\n howpublished={\\url{'+url+'}},\n note={Accessed October 25, 2026.}\n}\n'
(ROOT/'references.bib').write_text(bib)
embedded=''
for name,text in {'awe-references.bib':bib,**figs}.items():
 (ROOT/name).write_text(text+'\n');embedded+='\\begin{filecontents*}[overwrite]{'+name+'}\n'+text+'\n\\end{filecontents*}\n'
preamble=r'''\documentclass[11pt,letterpaper]{article}
\usepackage[T1]{fontenc}
\usepackage[utf8]{inputenc}
\usepackage{mathpazo}
\usepackage[scaled=0.92]{helvet}
\usepackage{microtype}
\usepackage[margin=0.85in,headheight=15pt]{geometry}
\usepackage{amsmath,amssymb,booktabs,tabularx,longtable,array,enumitem}
\usepackage[table]{xcolor}
\usepackage{graphicx,tikz,pgfplots,tcolorbox,fancyhdr,seqsplit,placeins}
\usetikzlibrary{arrows.meta,positioning,calc}
\pgfplotsset{compat=1.18}
\usepackage[numbers,sort&compress]{natbib}
\usepackage{xurl}
\usepackage[colorlinks=true,linkcolor=purple,citecolor=purple,urlcolor=teal,bookmarksopen=true]{hyperref}
\definecolor{purple}{HTML}{5824A7}
\definecolor{deep}{HTML}{180D31}
\definecolor{lavender}{HTML}{F4F0FC}
\definecolor{teal}{HTML}{137B86}
\definecolor{coral}{HTML}{A5483E}
\definecolor{ink}{HTML}{202333}
\hypersetup{pdftitle={AGI ALPHA FLYWHEEL: The Autonomous Work Economy},pdfauthor={Vincent Boucher - MONTREAL.AI},pdfsubject={AWE-2026-01: bounded delivery, capability transfer, and conditional economics},pdfkeywords={AGI ALPHA, autonomous work, unit economics, capability transfer, reproducibility}}
\urlstyle{same}
\setlength{\parindent}{0pt}
\setlength{\parskip}{5.3pt}
\setlength{\tabcolsep}{5pt}
\renewcommand{\arraystretch}{1.17}
\setlist{nosep,leftmargin=1.5em}
\pagestyle{fancy}\fancyhf{}
\fancyhead[L]{\sffamily\scriptsize\color{purple}AGI ALPHA FLYWHEEL}
\fancyhead[R]{\sffamily\scriptsize\color{gray}AWE-2026-01\quad |\quad Research edition 1.0}
\fancyfoot[L]{\sffamily\scriptsize\color{gray}The Autonomous Work Economy}
\fancyfoot[R]{\sffamily\small\thepage}
\renewcommand{\headrulewidth}{0.3pt}
\color{ink}
\raggedbottom
\setlength{\emergencystretch}{1.5em}
\renewcommand{\topfraction}{0.9}
\renewcommand{\textfraction}{0.05}
\renewcommand{\floatpagefraction}{0.75}
\makeatletter\setlength{\@fptop}{0pt}\setlength{\@fpsep}{15pt}\setlength{\@fpbot}{0pt plus 1fil}\makeatother
\begin{document}
\hypersetup{pageanchor=false}
\begin{titlepage}
\begin{tikzpicture}[remember picture,overlay]
\fill[deep] (current page.south west) rectangle (current page.north east);
\fill[purple!50!deep] ($(current page.north east)+(-1.0,-1.8)$) circle (4.7cm);
\draw[white!15,line width=0.6pt] ($(current page.north east)+(-2.6,-2.4)$) circle (5.7cm);
\draw[white!12,line width=0.6pt] ($(current page.north east)+(-2.6,-2.4)$) circle (7.2cm);
\foreach \x/\y/\r in {1/1/.025,3/2/.018,5/1.4/.025,8/1/.02,12/2/.025,16/1/.025,2/6/.018,17/8/.02,16/12/.025,2/16/.02,18/19/.02,4/23/.02,13/24/.02}{\fill[white!70] ($(current page.north west)+(\x,-\y)$) circle (\r cm);}
\end{tikzpicture}
\color{white}\sffamily
\vspace*{0.6cm}
{\small\bfseries MONTREAL.AI\hfill RESEARCH EDITION 1.0}\par
\vspace{1.4cm}
{\large\color{white!75}AGI ALPHA FLYWHEEL\quad $\infty$}\par
\vspace{0.4cm}
{\fontsize{37}{41}\selectfont\bfseries THE AUTONOMOUS\\WORK ECONOMY}\par
\vspace{0.7cm}
{\Large From Useful Outcomes to\\Expanding Productive Capability}\par
\vspace{0.8cm}
\rule{2.0cm}{1.0pt}\par
\vspace{0.3cm}
{\large SUCCESSOR $\Omega$ HARNESS}\par
{\small\bfseries ACTIVATE. EVOLVE. SCALE.}\par
\vspace{0.3cm}
{\small Powered by TRANSFORMATIONAL INTELLIGENCE $\infty$\\and the applicable \$AGIALPHA utility.}\par
\vfill
\begin{minipage}{0.94\linewidth}
{\large\bfseries Useful work. Inspectable evidence. Earned growth.}\par
\vspace{0.35cm}
{\normalsize An executable study of bounded digital work, retained capabilities,\\conditional unit economics and cash-constrained reinvestment.}\par
\vspace{0.5cm}
{\small 24 primary structural cases\quad $\cdot$\quad 8 separate transfer probes}\par
{\small Observed local delivery\quad $\cdot$\quad Modeled enterprise economics}\par
\vspace{0.7cm}
{\small Vincent Boucher\quad $\cdot$\quad MONTREAL.AI\\25 October 2026\quad |\quad Study AWE-2026-01}
\end{minipage}
\vspace*{0.3cm}
\end{titlepage}
\hypersetup{pageanchor=true}
\setcounter{page}{1}
\begin{center}{\Large\bfseries AGI ALPHA FLYWHEEL: The Autonomous Work Economy}\par
\small Vincent Boucher $\cdot$ MONTREAL.AI\quad |\quad 25 October 2026
\end{center}
\section*{Abstract}
Automated digital work can produce immediate customer value without first proving universal capability or self-acceleration. We study the connection between bounded useful delivery, complete operating cost, retained executable capability, and reinvestment. A frozen 24-case engineering census executes four artifact families through the existing AGI ALPHA Workbench: 16 supported cases deliver contract-accepted packets, and eight intended negative cases are refused. Separate algorithms verify acceptance; a conventional MILP confirms every quote optimum. An executable capability is retained and reused, an incorrect greedy candidate is rejected, and an allowlisted successor is composed. On eight separately frozen new transfer baskets, the successor and conventional MILP solve all eight; the initial capsule supports two and refuses six. This establishes bounded transfer and installed-workflow enablement, not novel algorithm discovery. Actual full enterprise costs remain unknown. Price-calibrated economic sensitivities model missing operations, failures, shared upkeep and residual attention. At an assumed 1,000 attempted monthly jobs, reference model-extension full cost is USD 3.351 per accepted result; a separately frozen automatic-upkeep configuration yields USD 2.817. Neither is an observed cost. Human comparisons use source-backed break-even time because matched non-AI task durations are unavailable. Cash-constrained simulations distinguish external funding, collected proceeds, reserves and financeable investment; no candidate is economically admitted without demonstrated monetized benefit. The study delivers an offline bilingual working demonstration, source, protocols, raw evidence and reproducible analysis. Authenticated enterprise execution, realized self-financing and self-acceleration remain unestablished.

\section*{R\'esum\'e}
Cette \'etude relie des livrables utiles, leur co\^ut complet, la r\'eutilisation de capacit\'es ex\'ecutables et le financement de nouvelles capacit\'es. Le protocole principal comprend 24 cas structur\'es: 16 livrables sont accept\'es selon leur contrat et huit entr\'ees hors p\'erim\`etre sont refus\'ees. Une exp\'erience distincte porte sur huit nouveaux paniers de devis. Les comparaisons \`a la main-d'\oe uvre reposent sur des seuils de rentabilit\'e conditionnels, sans dur\'ees humaines invent\'ees. Les co\^uts et encaissements de l'entreprise sont mod\'elis\'es; aucun paiement client ni autofinancement r\'ealis\'e n'est observ\'e. La d\'emonstration bilingue produit un r\'esultat local inspectable. L'auto-acc\'el\'eration n'est pas \'etablie.

\begin{tcolorbox}[colback=lavender,colframe=purple,title={Reading the evidence}]
\textbf{Observed} denotes actual local execution or an inspected artifact. \textbf{Sourced} denotes external published data. \textbf{Estimated/assumed} denotes a declared model input. \textbf{Unknown} remains unknown. \textbf{NOT RUN} denotes an unperformed operational test. A recorded artifact, a simulation and a fresh execution are never interchangeable.
\end{tcolorbox}
\clearpage
\tableofcontents
\clearpage
'''
document=embedded+preamble+body+r'''
\FloatBarrier
\begingroup\small\raggedright\setlength{\bibsep}{2pt}\setlength{\parskip}{0pt}
\bibliographystyle{unsrtnat}
\bibliography{awe-references}
\endgroup
\end{document}
'''
document=document.replace('\u2013','--').replace('\u2014','---').replace('\u2011','-').replace('\u2019',"'").replace('\u201c','``').replace('\u201d',"''")
(ROOT/'AGI_ALPHA_Autonomous_Work_Economy.tex').write_text(document)
for name,text in figs.items():
 stem=name.removesuffix('.tex');p=STUDY/'figures'/f'{stem}.tex'
 p.write_text(r'\documentclass[tikz,border=7pt]{standalone}'+'\n'+r'\usepackage{pgfplots}\pgfplotsset{compat=1.18}\definecolor{purple}{HTML}{5824A7}\definecolor{teal}{HTML}{137B86}\definecolor{coral}{HTML}{A5483E}'+'\n'+r'\begin{document}\begin{minipage}{16cm}'+text+r'\end{minipage}\end{document}'+'\n')
print('Wrote standalone manuscript and three figure sources',len(document))
