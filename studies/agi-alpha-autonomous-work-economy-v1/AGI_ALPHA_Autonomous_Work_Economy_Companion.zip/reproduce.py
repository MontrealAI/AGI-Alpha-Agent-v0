import argparse, hashlib, json, shutil, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text())
def main():
 p=argparse.ArgumentParser(description='Reproduce AWE-2026-01 in a new directory, preserving supplied evidence.');p.add_argument('--output',type=Path,required=True);a=p.parse_args();out=a.output.resolve()
 if out.exists():raise SystemExit('Choose a new output directory; existing data are never overwritten.')
 if out==ROOT or ROOT in out.parents:raise SystemExit('Choose an output directory outside the companion tree.')
 out.mkdir(parents=True)
 for name in ['implementation','economics','extension','foundations']:
  shutil.copytree(ROOT/name,out/name,ignore=shutil.ignore_patterns('__pycache__','raw'))
 (out/'publication').mkdir()
 for name in ['audit_delivery_evidence.py','delivery-evidence-audit.json','source-registry-audit.json']:
  src=ROOT/'publication'/name
  if src.exists():shutil.copy2(src,out/'publication'/name)
 shutil.copytree(ROOT/'publication/shared-contract',out/'publication/shared-contract')
 commands=[['node','--version'],[sys.executable,'implementation/run.py','--run-id','verification-reproduction'],[sys.executable,'extension/run_corrected.py','--run-id','verification-reproduction'],['node','implementation/check-controls.mjs'],[sys.executable,'economics/analyze.py'],[sys.executable,'economics/automated_upkeep.py'],[sys.executable,'foundations/economic_crosscheck.py'],[sys.executable,'publication/audit_delivery_evidence.py'],['node','publication/shared-contract/evaluate_adapter.mjs']]
 logs=[]
 for i,cmd in enumerate(commands):
  r=subprocess.run(cmd,cwd=out,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
  log=out/f'command-{i+1}.txt';log.write_text(r.stdout);logs.append({'command':cmd,'returncode':r.returncode,'log':log.name})
  if r.returncode:print(r.stdout[-3000:]);raise SystemExit(r.returncode)
 original=read(ROOT/'implementation/runs/confirmation-v1/acceptance.json');repeated=read(out/'implementation/runs/verification-reproduction/acceptance.json')
 assert all(original[k]==repeated[k] for k in ['accepted','expected_refusals','unexpected_failures'])
 transfer=read(out/'extension/runs/verification-reproduction/acceptance.json');assert transfer['accepted']==8 and transfer['parent_supported']==2
 old=read(ROOT/'economics/results/economic_results.json');new=read(out/'economics/results/economic_results.json')
 for x,y in zip(old['portfolio'],new['portfolio']):
  for k in ['fully_loaded_pretax_usd_per_accepted','recurring_delivery_usd_per_accepted','marginal_execution_usd_per_accepted']:assert abs(x[k]-y[k])<1e-10
 result={'study_id':'AWE-2026-01','status':'PASS','primary_accepted':repeated['accepted'],'primary_expected_refusals':repeated['expected_refusals'],'new_input_transfer_accepted':transfer['accepted'],'parent_supported':transfer['parent_supported'],'economic_rows_reproduced':len(new['portfolio']),'commands':logs,'limits':['Repetition of frozen cases adds no task breadth.','Wall times and run identities can differ.','No paid provider calls, transactions or authenticated enterprise test performed.','Original observed-run costs remain unknown.']}
 (out/'REPRODUCTION.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
if __name__=='__main__':main()
