# AWE-2026-01 additive publication preparation

## Trusted source and execution status

The paper importer is unchanged source from Alpha main
`61659dd275fb865203d20233e93ed50fa4dcd265`, tree
`c80977fd61b243162f7ee619d7ab3d28206a9ade`.
The current catalog contains 21 records; the proposed
`agi-alpha-autonomous-work-economy-v1` ID is unused. Existing author conventions
include `Vincent Boucher · MONTREAL.AI`, matching the requested attribution.

Read instructions are preserved at `importer_repo/AGENTS.md`,
`importer_repo/docs/agent/PAPER_UPLOADS.md`, and
`importer_repo/docs/agent/FAST_RELEASE_POLICY.md`.
The maintained lock requires pypdf 6.21.2. It was installed with hash checking
into the isolated `locked-deps/` directory. Initial restricted-network installation
failed; the approved normal network retry succeeded. No lock or requirement was
changed. The unchanged importer **passes its baseline `check`** with that version.

All 437 lightweight cache assets, 37 original PDF/TeX files and required local
resource references were retrieved. The required closure comprises 476 paths and
329 distinct Git blobs, all verified against exact public Git identities. Together
with instruction and policy source, 498 blob paths are present. The exact signed
base commit and all 792 tree objects were reconstructed with matching Git IDs.
Unrelated blob content is absent; no fake content or placeholder file was used.
This is a partial local object store, shallow at the trusted base, for a complete
introduced-transition proof. It is not a full runtime checkout.

`source_manifest.json`, `materialization-receipts.json`, `base_tree.json`,
`base_commit_provenance.json` and `git-materialization.json` preserve provenance.
`materialization-failures.json` is empty. The reproduction downloader reads only
immutable public raw-source URLs and checks every retrieved Git blob before use.

## Run the unchanged importer when manuscript files are final

From the study root, with final filenames substituted:

```sh
python3 publication/import_paper.py --pdf paper/paper.pdf --tex paper/paper.tex
```

`paper-metadata.json` is outside the materialized repository and is not a proposed
commit path. It supplies bilingual summaries and the new versioned ID. The PDF
title is taken from its actual metadata. The wrapper invokes the existing command:

```sh
python -m scripts.research_papers check
python -m scripts.research_papers add --pdf FINAL.pdf --tex FINAL.tex --metadata ../paper-metadata.json
python -m scripts.research_papers check
```

It checks unchanged prior catalog rows and exact original PDF/TeX bytes, then
creates a local validation commit with precisely eight changed paths. It invokes
the unchanged trusted `scripts.paper_changes --prove` implementation over the
exact trusted base and complete one-commit introduced history. The locally created
commit is validation evidence only; it is not a remote publication commit.

On success it writes `paper-import-receipt.json` and `paper-tree-entries.json`.
The latter supplies the immutable base tree, expected resulting tree, each changed
path/mode/type/Git blob identity/SHA256, and each actual local file location. Root
can create the corresponding blobs and tree through the GitHub connector, confirm
the returned tree equals `expected_tree`, then create the authorized draft branch
and PR. A refreshed main requires regeneration/reproof, not an unreviewed overwrite.

## Proposed draft PR A: passive paper and TeX

Title: **[alpha_factory] Add the Autonomous Work Economy study**

Exactly eight paths:

1. `docs/papers/agi-alpha-autonomous-work-economy-v1.pdf`
2. `docs/papers/agi-alpha-autonomous-work-economy-v1.tex`
3. `docs/research-papers.json`
4. `README.md` (only maintained paper block)
5. `docs/index.html` (only maintained paper block)
6. `docs/service-worker.js`
7. `docs/assets/service-worker.js`
8. `docs/alpha_factory_v1/demos/alpha_agi_insight_v1/service-worker.js`

Use one complete, reviewed import commit. Prior PDFs, TeX, catalog records and
public URLs remain unchanged. No release-version bump is required for a proved
paper-only transition. The draft description is in `paper-pr-body.md`.

Required hosted checks and reviewer/owner disposition remain independent. The
paper-site overlay waits for its matching public software release and actual
served-byte verification. Passing passive-paper validation is not software,
browser, Fleet, Harness or economic-production qualification.

## Proposed draft PR B: executable study companion and experience

Title: **[alpha_factory] Add the Autonomous Work Economy companion**

Proposed source root:
`studies/agi-alpha-autonomous-work-economy-v1/`.
Proposed public experience:
`docs/reports/agi-alpha-autonomous-work-economy-v1/index.html`.

This is a software/mixed change and requires full source qualification through
the existing #4899 integration/release owner. New JavaScript/HTML, companion code,
its source closures and tests cannot use the passive-paper fast lane. Preserve
all frozen evidence, old releases, owner branches and original restrictions.
The draft description is in `companion-pr-body.md`.

Do not include this preparation's `importer_repo/`, `.git`, `locked-deps/`, bulk
downloaded papers or generated cache inputs in the study companion. Include the
study's actual implementation, protocols, raw run evidence, economics, paper source,
publication/source manifests, bounded independent audit scripts/reports and shared
contract adapter as appropriate. The importer closure is reproducible from its
manifest and need not be duplicated as study runtime code.

The catalog's optional experience resource must bind the actual qualified HTML
bytes. A research companion link must use a real canonical release-download ZIP,
with actual SHA256 and byte size, and source evidence must identify the same
release tag. An intended URL is not a verified asset. Preserve normal public
software/research-release and website sequencing; do not publish placeholders or
attach new executable bytes to an already accepted release.

## Coordination and current schema

`coordination-refresh.json` records #4850 after root comment 6400040494. The one
later observed comment, 6400115264, is the Product owner's correction handoff,
not an AWE approval. Product PR #4907 progressed to
`846b12762dc69e1317103116b37529461d3902fe`; its cost module is byte-identical to
our inspected `d12e955909cb5b52a5225c39d4f7fab4a5f93d50` pin (Git blob
`91da2937ba129793b21652f68560e8bd4aa32f56`). Its broader corrected workflow was
not run or qualified by this study. Main remained `61659dd...` at refresh.

`shared-contract/README.md` documents actual schema execution, unknown preservation,
integer-BPS/micro rounding, the differing marginal-tier definitions and aggregate
human-baseline limits. None of these additions changes primary economic freezes.

## Independent operational evidence review

`audit_delivery_evidence.py` makes 472 checks without importing the original
verifier. It verifies the complete primary selection (24 cases: 16 accepted local
contracts and eight expected refusals), original inputs, artifact exports, source
facts, schedules, finite repairs and the separate eight-case transfer extension.
Every one of the 12 accepted quote baskets is independently solved using an exact
dynamic program over items and used-vendor masks, distinct from candidate
enumeration and the existing HiGHS MILP. All objectives and line/pack/FX/shipping
calculations agree. The extension's original reporting failure and its one-line
null-parent correction remain explicit; all frozen source hashes match.

These are bounded same-session checks, not external peer review, customer
acceptance, full-cost observation or operational-readiness evidence.
