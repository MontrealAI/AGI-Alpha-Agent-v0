[See the repository disclaimer](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/blob/main/docs/DISCLAIMER_SNIPPET.md)

# Summary

The Autonomous Work Economy paper needs inspectable executable evidence and a
practical way to obtain a bounded useful deliverable. This additive companion
provides the frozen study protocol, original inputs and outputs, pinned Alpha
workbench reuse, independent acceptance and economic analysis, retained quote
capabilities, and an English/French inspection experience.

Proposed source root: `studies/agi-alpha-autonomous-work-economy-v1/`.
Proposed experience: `docs/reports/agi-alpha-autonomous-work-economy-v1/index.html`.
The final exact path manifest and dependency identities must accompany this draft.

The original 24-case primary census and later eight-case transfer extension remain
separate. Accepted artifacts, expected refusals, the original extension reporting
failure, recovery amendment and rejected capability candidate are preserved.
Model-mediated intake and authenticated execution remain NOT RUN. Scenario prices,
acceptance and demand are labeled; actual full cost and customer payments remain
unobserved. No automatic paid action or treasury authority is added.

An additive adapter executes the maintained Product #4907 shared cost contract
against copies of study evidence and assumptions. Unknown costs remain unknown;
stage coverage, precise rounding and differing marginal-tier definitions are
documented. This does not replace the owner's schema or frozen research values.

Coordination: #4850. Existing #4899 release/scanner and #4907 Product ownership
remains intact. The passive PDF/TeX import is a separate PR.

# Checks

- [ ] Required full source qualification — pending exact final companion source.
- [ ] Existing-owner integration and exact-head review — pending.
- [ ] Hosted browser, accessibility, stop/recovery/export and installed acceptance — report actual final receipts only.
- [ ] Required lint, integrity, security and release checks — pending; no inherited pass claimed.
- [ ] Actual public release assets and served-byte verification — not performed by this draft preparation.

# Testing

Study-scoped deterministic evidence and independent arithmetic audits are included,
with reproducible commands. A separate same-session reviewer performed 472 checks
over complete primary selection, original input identities, exported artifacts,
source facts, schedules and extension freezes. A third exact dynamic program
recomputed all 12 accepted quote objectives and their pack/FX/shipping arithmetic.
These scientific checks are not full software qualification or external peer review.

The new experience and executable files require the full lane. No passive-paper
classification, historical green run or economic calculation grants release
readiness. Existing source-specific checks and normal owner/release sequencing
remain mandatory. Catalog experience or companion links must point to actual
qualified bytes and verified release assets, never prospective placeholders.
