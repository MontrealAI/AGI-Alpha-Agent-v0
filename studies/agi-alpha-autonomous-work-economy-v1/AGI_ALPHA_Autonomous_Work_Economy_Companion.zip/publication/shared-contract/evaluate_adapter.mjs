// SPDX-License-Identifier: Apache-2.0
import fs from 'node:fs';
import {fileURLToPath} from 'node:url';
import {inspectAutomatedCosts,evaluateAutomatedCosts} from './automated-costs.mjs';
const home=fileURLToPath(new URL('.',import.meta.url));
const reports={};
for(const name of ['modeled-extension-record','observed-trace-record']) {
  const input=JSON.parse(fs.readFileSync(home+name+'.json','utf8'));
  inspectAutomatedCosts(input);
  reports[name]=evaluateAutomatedCosts(input);
}
const observed=reports['observed-trace-record'];
if(observed.scenarios.some(s=>s.costs.fullyLoadedMicrosPerAccepted!==null||s.comparison.fullyLoaded.outcome!=='unknown')) throw Error('Actual unknowns incorrectly became economic conclusions');
const model=reports['modeled-extension-record'];
if(model.scenarios.some(s=>s.humanBaselineMicrosPerAccepted!==null||s.comparison.fullyLoaded.outcome!=='unknown')) throw Error('Human duration was fabricated');
const reference=model.scenarios.find(s=>s.name==='base');
if(reference.volume.acceptedPerMonth!==891||Math.abs(reference.costs.fullyLoadedMicrosPerAccepted/1e6-3.3507606570771428)>0.000002) throw Error('Reference mapping differs beyond micro rounding');
fs.writeFileSync(home+'adapter-results.json',JSON.stringify({status:'VALIDATED_PURE_ARITHMETIC_ONLY',checks:['Two exact-schema records admitted','Observed monetary costs remain null','Human comparisons remain unknown','Reference acceptance denominator891','Reference cost within2microUSD of frozen primary'],reports},null,2)+'\n');
console.log(JSON.stringify({status:'PASS',referenceMicros:reference.costs.fullyLoadedMicrosPerAccepted,referenceBreakEvenMinutes:reference.comparison.fullyLoaded.breakEvenHumanMinutes,observedCost:observed.scenarios[0].costs.fullyLoadedMicrosPerAccepted}));
