#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Additive mapping; primary study inputs and results are never changed."""
from pathlib import Path
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR
import hashlib, json

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
D=Decimal
read=lambda path:json.loads(path.read_text(),parse_float=D)
P=read(ROOT/'economics/scenario_parameters.json')
S=read(ROOT/'economics/sources.json')
T={x['id']:x for x in S['sources']}
O={x['id']:x for x in S['occupations']}
G=S['compensation_groups']
DEV=O['software_developers']['median_hourly_wage_usd']*G['professional']['total_hourly_usd']/G['professional']['wage_hourly_usd']
SUPPORT=G['private_industry_all']['total_hourly_usd']
STAGES=['preparation','planning','execution','verification','correction','packaging','reporting','recovery']
def ceil(n):return int(D(n).to_integral_value(rounding=ROUND_CEILING))
def fact(value,reference,basis='estimated'):return {'value':value,'basis':basis,'reference':reference}
def unknown(reference):return fact(None,reference,'unknown')
def save(name,data):
    (HERE/name).write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')

scenarios=[];quantization=[]
slots={'reference':'base','efficient':'conservative','stress':'stress'}
stage_map={'quotes':['preparation','verification','reporting'],'brief':['preparation','execution','verification'],'plan':['planning','verification','reporting'],'software':['preparation','execution','verification','packaging']}
for source_name,slot in slots.items():
    s=P['scenarios'][source_name]
    ref='AWE-ECON-parameters-v1.0 '+source_name+'; assumption, unmeasured production quantity. '
    p=D(s['extension_final_acceptance_probability'])*(1-D(s['common_shock_month_probability'])+D(s['common_shock_month_probability'])*D(s['shock_acceptance_retention']))
    bps=int((p*10000).to_integral_value(rounding=ROUND_FLOOR))
    if D(bps)/10000!=p:quantization.append({'scenario':source_name,'original_acceptance':str(p),'mapped_acceptance':str(D(bps)/10000),'reason':'Shared contract uses integer BPS; round acceptance downward only in this adapter, preserving original primary calculations.'})
    attempts=1+D(s['extension_retry_probability'])+D(s['common_shock_month_probability'])*D(s['shock_extra_retry_probability'])
    ops=[]
    for f in P['families']:
        for i,m in enumerate(f['estimated_model_stages']):
            budget=D(m['input_tokens'])*T['OPENAI_SOL_20261025']['input_usd_per_million_tokens']+D(m['billable_output_tokens_including_reasoning'])*T['OPENAI_SOL_20261025']['output_usd_per_million_tokens']
            ops.append({'id':f['id']+'-model-'+str(i+1),'stage':stage_map[f['id']][i],'frequency':'attempt','unitsPerOccurrencePpm':fact(ceil(D(f['weight'])*D(s['model_token_multiplier'])*1000000),ref+'Portfolio weight and token multiplier.'),'unitCostMicros':fact(ceil(budget),ref+m['name']+' budget times sourced OpenAI short-context tariff.'),'implementation':'modeled'})
        ops.append({'id':f['id']+'-hosted-runtime','stage':'execution','frequency':'attempt','unitsPerOccurrencePpm':fact(ceil(D(f['weight'])*f['hosted_20min_sessions']*1000000),ref+'Hosted full-session count, not a measured invoice.'),'unitCostMicros':fact(ceil(T['OPENAI_TOOLS_20261025']['hosted_container_1gb_usd_per_20min_session']*1000000),'OpenAI tool tariff, retrieved 2026-10-25.','sourced'),'implementation':'modeled'})
        if f['estimated_web_search_calls']:
            ops.append({'id':f['id']+'-search','stage':'preparation','frequency':'attempt','unitsPerOccurrencePpm':fact(ceil(D(f['weight'])*f['estimated_web_search_calls']*1000000),ref+'Assumed search count.'),'unitCostMicros':fact(ceil(T['OPENAI_TOOLS_20261025']['web_search_usd_per_call']*1000000),'OpenAI search-call tariff, retrieved 2026-10-25.','sourced'),'implementation':'modeled'})
    for stage in STAGES:
        if stage not in {r['stage'] for r in ops}:
            ops.append({'id':stage+'-included-runtime','stage':stage,'frequency':'request','unitsPerOccurrencePpm':fact(0,ref+'No additional independent operation charge: deterministic handling is included in hosted sessions; complete repeated work is priced by attempts; exceptions below.'),'unitCostMicros':fact(0,ref+'No duplicated allocation.'),'implementation':'implemented'})
    residual=[]
    for prefix,stage in [('normal','correction'),('rare','recovery')]:
        residual.append({'id':prefix+'-exception','stage':stage,'exceptionsPerRequestPpm':fact(ceil(D(s[prefix+'_exception_probability'])*1000000),ref+'Expected exception frequency.'),'minutesPerException':fact(int(s[prefix+'_exception_minutes']),ref+'Handling duration.'),'hourlyCostMicros':fact(ceil(SUPPORT*1000000),'BLS ECEC June2026 all-private total compensation proxy.','sourced')})
    monthly=[]
    rows=[('platform-archive','capacity',D(s['shared_platform_archive_usd_per_month'])),('shared-maintenance','maintenance',D(s['maintenance_hours_per_month'])*DEV),('business-admin','business',D(s['business_admin_hours_per_month'])*SUPPORT),('correlated-shock-recovery','maintenance',D(s['common_shock_month_probability'])*D(s['shock_recovery_hours'])*DEV)]
    for key,kind,amount in rows:monthly.append({'id':key,'kind':kind,'amountMicros':fact(ceil(amount*1000000),ref+'Shared monthly amount with original labor proxy; rounded upward to micros.'),'allocationBps':fact(10000,ref+'100% across this four-family portfolio, charged once.')})
    human=sum(D(f['weight'])*O[f['occupation_id']]['median_hourly_wage_usd']*G[O[f['occupation_id']]['cost_group']]['total_hourly_usd']/G[O[f['occupation_id']]['cost_group']]['wage_hourly_usd'] for f in P['families'])
    scenarios.append({'name':slot,'capacityRequestsPerMonth':fact(1000,ref+'Stated 1000 attempted requests/month configuration.'),'utilizationBps':fact(10000,ref+'Full utilization at this scenario row; no demand inference.'),'acceptanceBps':fact(bps,ref+'Shock-adjusted production acceptance, never fixture acceptance; BPS floor documented separately.'),'attemptsPerRequestPpm':fact(ceil(attempts*1000000),ref+'Initial attempt plus independent retry and correlated-shock retry expectation.'),'operations':ops,'residual':residual,'monthly':monthly,'investments':[{'id':'setup-development','kind':'development','amountMicros':fact(ceil(D(s['setup_development_hours'])*DEV*1000000),ref+'Original setup hours times developer employer-cost proxy, rounded upward to micros.'),'allocationBps':fact(10000,ref+'Shared portfolio construction allocated once.'),'amortizationMonths':fact(int(P['numerical_grid']['amortization_months']),ref+'Original finite amortization.')}],'humanBaseline':{'minutesPerAccepted':unknown('No observed matched traditional non-AI task duration; retain break-even only.'),'hourlyCostMicros':fact(ceil(human*1000000),'Equal-weight labor proxy from four matched BLS OEWS median wages times ECEC employer-cost factors; estimated mapping, no duration or quality proof.')}})
save('modeled-extension-record.json',{'schema':'alpha-automated-costs/v1','offeringId':'AWE-extension-portfolio-1000','currency':'USD','scenarios':scenarios})

actual=[]
for name in ['base','conservative','stress']:
    ops=[{'id':stage+'-actual-unmetered','stage':stage,'frequency':'request','unitsPerOccurrencePpm':unknown('Actual stage occurrence count not priced or measured separately.'),'unitCostMicros':unknown('Current local trace does not establish full monetary stage cost.'),'implementation':'implemented'} for stage in STAGES]
    ops.append({'id':'observed-provider-calls','stage':'execution','frequency':'request','unitsPerOccurrencePpm':fact(0,'confirmation-v1 reports zero provider calls in this local batch; does not include assistant authoring.','measured'),'unitCostMicros':unknown('No observed provider invoice; not a statement of free production.'),'implementation':'implemented'})
    actual.append({'name':name,'capacityRequestsPerMonth':unknown('No measured production capacity or demand.'),'utilizationBps':unknown('No measured production utilization.'),'acceptanceBps':unknown('Structural-fixture acceptance is not production acceptance.'),'attemptsPerRequestPpm':unknown('No observed production retry frequency.'),'operations':ops,'residual':[{'id':'production-exceptions','stage':'recovery','exceptionsPerRequestPpm':unknown('Production exception frequency unobserved.'),'minutesPerException':unknown('Production handling time unmeasured.'),'hourlyCostMicros':unknown('Actual exception labor expense unmeasured.')}],'monthly':[{'id':'host-maintenance-admin','kind':'maintenance','amountMicros':unknown('Host, maintenance and administration cash costs unmeasured.'),'allocationBps':unknown('Production allocation unknown.')}],'investments':[{'id':'study-authoring-development','kind':'development','amountMicros':unknown('Assistant authoring/model spend and human development effort unmetered.'),'allocationBps':unknown('Research versus reusable production allocation unknown.'),'amortizationMonths':unknown('Actual productive lifetime not observed.')}],'humanBaseline':{'minutesPerAccepted':unknown('No matched traditional-human observation.'),'hourlyCostMicros':unknown('No actual customer alternative price observed.')}})
save('observed-trace-record.json',{'schema':'alpha-automated-costs/v1','offeringId':'AWE-local-trace-unknown-cost','currency':'USD','scenarios':actual})
save('mapping-provenance.json',{'study_id':'AWE-2026-01','contract_commit':'d12e955909cb5b52a5225c39d4f7fab4a5f93d50','contract_status':'Open PR4907 candidate, not merged or deployed','slot_correspondence':slots,'slot_warning':'The shared caller-defined slot conservative carries the original efficient scenario solely for schema interoperability; it is NOT relabeled an economically conservative forecast. Original names remain in every modeled fact reference.','quantization':quantization,'reference_expected_primary_full_usd':'3.35076065707714284498208477110878924226206384','scope':'Only schema validation and pure arithmetic execute. No authenticated model orchestration, payment, customer behavior or production success is inferred.','cost_basis_mapping':'Study assumptions map to shared estimated with explicit unmeasured-assumption references; unknown stays null.','tier_semantics':'Shared marginal includes normal and rare human exceptions ($1.627500 reference); study marginal execution excludes them ($0.180278). Recurring/full align apart from quantization; marginal names must not be equated.','human_baseline_scope':'Shared break-even3.833699min uses illustrative aggregate wage; not any family-specific primary threshold. Human duration and savings remain unknown.','inputs':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'economics/scenario_parameters.json',ROOT/'economics/sources.json',ROOT/'implementation/measures.json',HERE/'automated-costs.mjs']}})
print('Wrote two additive shared-schema records and mapping provenance.')
