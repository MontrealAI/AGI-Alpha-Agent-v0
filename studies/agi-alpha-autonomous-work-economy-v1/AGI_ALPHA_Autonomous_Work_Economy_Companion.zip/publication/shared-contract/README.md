# Additive shared-cost interoperability

This directory executes the unchanged `alpha-automated-costs/v1` module from
Alpha PR #4907 at commit `d12e955909cb5b52a5225c39d4f7fab4a5f93d50`.
The PR was open and unmerged when retrieved. It is a source candidate, not an
installed runtime or deployment qualification. The module has no imports.

```sh
python3 publication/shared-contract/build_adapter.py
node publication/shared-contract/evaluate_adapter.mjs
```

The first record represents the original model-extension scenarios at 1,000
attempted requests per month. The second represents actual trace evidence with
unmeasured monetary inputs retained as `null`. Both pass the existing schema and
pure arithmetic implementation. No provider call, payment or scheduled action is
performed. Original study parameters and results remain unchanged.

## Mapping limits

- The contract requires caller-defined slots `base`, `conservative` and `stress`.
  This adapter maps original `reference`, `efficient` and `stress` respectively.
  The `conservative` slot is only a schema correspondence; the original efficient
  scenario is not renamed an economically conservative forecast. Every fact
  retains its original scenario name in its provenance reference.
- The shared contract accepts integer basis points. Efficient acceptance 0.97804
  therefore maps downward to 0.978 only in this adapter. Reference 0.891 and stress
  0.598 are exact. Monetary inputs round upward to integer micros; the reference
  full output is 3,350,761 micros ($3.350761), compared with the primary unrounded
  $3.350760657. Primary analysis remains authoritative for its frozen numbers.
- **Marginal tier definitions differ.** Shared
  `marginalMicrosPerAccepted` includes expected normal and rare human exceptions
  in variable cost: $1.627500 for the reference. The study's marginal execution
  cost is $0.180278 and excludes these exceptions until its recurring tier.
  Shared and study recurring/full tiers align apart from quantization; their
  marginal labels must not be substituted or presented as equivalent.
- The shared human baseline uses an illustrative equal-weight aggregate wage
  proxy. Its 3.833699-minute reference break-even is not a family-specific
  threshold and must not replace the paper's occupation-matched thresholds.
  Human task duration is unknown in both records, so savings comparisons remain
  `unknown` throughout.
- Study `assumed` inputs map to shared `estimated` facts with explicit
  `assumption, unmeasured` references because the shared vocabulary has no
  `assumed` value. Actual host cost, authoring cost, development effort,
  production utilization, acceptance and handling remain unknown.
- Eight workflow stages are present. Additional zero-charge stage rows in the
  modeled record explicitly allocate deterministic handling to already charged
  hosted execution and repeated passes. They do not represent measured zero
  economic effort or permission to omit actual work.

The agreement establishes arithmetic interoperability with a maintained owner
candidate. It does not establish full authenticated execution, customer
acceptance, live operating economics, self-financing or self-acceleration.
