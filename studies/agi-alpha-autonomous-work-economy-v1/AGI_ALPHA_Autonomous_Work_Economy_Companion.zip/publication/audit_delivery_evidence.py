#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Independent read-only evidence audit with a third exact quote algorithm."""
import json,hashlib,itertools,re,difflib
from pathlib import Path
from fractions import Fraction
from urllib.parse import quote,unquote_to_bytes
BASE=Path(__file__).resolve().parents[1]
OUT=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text())
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
checks=[]
def require(test,label):
    if not test:raise AssertionError(label)
    checks.append(label)
def quote_check(inp,s,identity):
    quantities={i['id']:i['quantity'] for i in inp['items']}
    vendors=sorted(inp['shipping_minor']);bits={v:1<<i for i,v in enumerate(vendors)}
    choices={k:[] for k in quantities};source={}
    for index,o in enumerate(inp['offers']):
        if o['lead_days']>inp['deadline_days']:continue
        packs=(quantities[o['item']]+o['pack_units']-1)//o['pack_units']
        fx=inp['fx'][o['currency']]
        amount=Fraction(packs*o['pack_price_minor']*fx['num'],fx['den'])
        cost=(amount+Fraction(1,2)).numerator//(amount+Fraction(1,2)).denominator
        row=(index,o['vendor'],cost,packs,packs*o['pack_units'])
        choices[o['item']].append(row);source[index]=(o,row)
    # State=vendors already used; transitions add one original eligible offer/item.
    # This dynamic program differs from both candidate vendor-subset enumeration
    # and the original independent HiGHS MILP verifier.
    states={0:0}
    for item in quantities:
        nxt={}
        for mask,amount in states.items():
            for _,vendor,cost,_,_ in choices[item]:
                key=mask|bits[vendor];value=amount+cost
                nxt[key]=min(nxt.get(key,value),value)
        states=nxt
    best=min(cost+sum(inp['shipping_minor'][v] for v in vendors if mask&bits[v]) for mask,cost in states.items())
    require(best==s['total_minor'],identity+' exact dynamic-program optimum')
    require(len(s['selected'])==len(quantities),identity+' item count')
    require({r['item'] for r in s['selected']}==set(quantities),identity+' item coverage')
    subtotal=0;used=set()
    for r in s['selected']:
        o,z=source[r['index']]
        require((r['item'],r['vendor'],r['quantity'],r['packs'],r['delivered_units'],r['landed_line_minor'])==(o['item'],o['vendor'],quantities[o['item']],z[3],z[4],z[2]),identity+' source line '+str(r['index']))
        subtotal+=z[2];used.add(o['vendor'])
    shipping=sum(inp['shipping_minor'][v] for v in used)
    require(subtotal==s['line_total_minor'] and shipping==s['shipping_minor'] and subtotal+shipping==s['total_minor'],identity+' exact landed arithmetic')
    require(sorted(used)==s['used_vendors'],identity+' used vendor list')
    return {'id':identity,'total_minor':best,'lines_minor':subtotal,'shipping_minor':shipping,'method':'Independent exact dynamic program over items and used-vendor masks'}

I=BASE/'implementation';run=I/'runs/confirmation-v1'
freeze=read(I/'input-freeze.json');inventory=read(I/'task-inventory.json');accept=read(run/'acceptance.json')
require(digest(I/'protocol.json')==freeze['protocol_sha256'],'primary protocol freeze')
require(digest(I/'task-inventory.json')==freeze['inventory_sha256'],'primary inventory freeze')
for row in freeze['inputs']:require(digest(I/row['path'])==row['sha256'],'primary input freeze '+row['id'])
require(len(inventory)==len(accept['records'])==24,'primary size24')
require([r['task_id'] for r in accept['records']]==[r['id'] for r in inventory],'every selected primary case retained once')
require(sum(r['delivered'] for r in accept['records'])==accept['accepted']==16,'primary accepted16')
require(sum(r['outcome']=='EXPECTED_REFUSAL' for r in accept['records'])==accept['expected_refusals']==8,'primary refusals8')
quote_rows=[]
for task,record in zip(inventory,accept['records']):
    spec=read(I/task['path']);p=run/task['id']/'pack.json'
    if not record['delivered']:
        require(task['expected']=='explicit-refusal' and task['expected_reason'] in record['reason'],task['id']+' expected refusal identity');continue
    require(task['expected']=='supported-delivery',task['id']+' supported selection')
    pack=read(p);artifacts={a['name']:a['content'] for a in pack['result']['artifacts']}
    for name,content in artifacts.items():require((run/task['id']/name).read_text()==content,task['id']+' exported artifact '+name)
    if task['family']=='quotes':
        sol=json.loads(artifacts['quote-analysis.json'])['solution'];quote_rows.append(quote_check(spec['inputs'],sol,task['id']))
    elif task['family']=='brief':
        facts=json.loads(artifacts['source-register.json']);original={f['id']:f for f in spec['inputs']['facts']}
        require([x['id'] for x in facts]==spec['inputs']['questions'],task['id']+' requested facts')
        for fact in facts:
            expected=dict(original[fact['id']]);expected['value']=str(expected['value'])
            require(fact==expected,task['id']+' exact source record '+fact['id'])
            require(fact['source_url'] in artifacts['evidence-brief.md'] and fact['source_year'] in artifacts['evidence-brief.md'],task['id']+' visible source provenance')
    elif task['family']=='planning':
        rows=json.loads(artifacts['schedule-analysis.json'])['schedule'];source={t['id']:t for t in spec['inputs']['tasks']};byid={r['id']:r for r in rows}
        require(len(rows)==len(source) and set(byid)==set(source),task['id']+' complete schedule')
        for row in rows:
            expected=source[row['id']]
            require(row['finish']-row['start']==expected['duration_minutes'] and row['start']>=0,task['id']+' duration '+row['id'])
            require(row['resource']==expected['resource'] and row['deps']==expected['deps'],task['id']+' preserved contract '+row['id'])
            require(all(byid[d]['finish']<=row['start'] for d in expected['deps']),task['id']+' precedence '+row['id'])
        require(all(a['resource']!=b['resource'] or a['finish']<=b['start'] or b['finish']<=a['start'] for a,b in itertools.combinations(rows,2)),task['id']+' resource exclusion')
        require(max(r['finish'] for r in rows)<=spec['inputs']['deadline_minutes'],task['id']+' deadline')
    elif task['family']=='reliability':
        require('low <= value && value <= high' in artifacts['contains.mjs'],task['id']+' closed-boundary expression')
        require(artifacts['original.mjs'].strip()==spec['inputs']['source'].strip(),task['id']+' source preserved')
    else:
        for block in re.findall(r'```successor-example\s*\n([\s\S]*?)\n```',artifacts['checked-examples.md']):
            example=json.loads(block);v=example['input'];op=example['operation']
            expected=quote(v,safe="~()*!.'") if op=='url-encode' else unquote_to_bytes(v).decode('utf-8') if op=='url-decode' else str(len(v.encode('utf-8')))
            require(example['expected']==expected,task['id']+' independent documentation result')

E=BASE/'extension';er=E/'runs/confirmation-v1';ef=read(E/'FREEZE.json');ep=read(E/'protocol.json');ea=read(er/'acceptance-reporting-v1.1.json');am=read(E/'REPORTING_AMENDMENT_v1_1.json')
for path,sha in ef['files'].items():require(digest(BASE/path)==sha,'extension frozen source '+path)
require(digest(E/'FREEZE.json')==ea['freeze_sha256'],'extension freeze identity')
require(digest(E/'run.py')==am['original_script_sha256'] and digest(E/'run_corrected.py')==am['corrected_script_sha256'],'original and amended script identities')
before=(E/'run.py').read_text();after=(E/'run_corrected.py').read_text()
require(before.replace("run.get('parent',{}).get('total_minor')","(run.get('parent') or {}).get('total_minor')")==after,'only null-parent reporting guard changed')
tasks=read(er/'tasks.json');require(len(tasks)==len(ea['records'])==ep['sample_size']==8,'extension exactly8cases')
require([r['id'] for r in tasks]==[r['id'] for r in ea['records']],'every extension case retained once')
extension_rows=[]
for task,row in zip(tasks,ea['records']):
    name=task['id'];inp=er/(name+'.json');result=read(er/(name+'-result.json'))
    require(digest(inp)==task['sha256']==row['input_sha256'],name+' fresh input identity')
    outcome=quote_check(read(inp)['inputs'],result['successor'],name)
    require(outcome['total_minor']==row['total_minor']==row['independent_milp']['total_minor'],name+' accepted objective matches evidence')
    require(result['parent_status']==row['parent_status'],name+' preserved parent result')
    extension_rows.append(outcome)
require(sum(r['parent_status']=='SUPPORTED' for r in ea['records'])==2,'parent supported2')
require(sum(r['parent_status']=='V1_COMBINATION_BUDGET' for r in ea['records'])==2,'parent budget refusals2')
require(sum(r['parent_status']=='V1_SCOPE_PACK_OR_CURRENCY' for r in ea['records'])==4,'parent scope refusals4')
require(ea['accepted']==8 and ea['original_reporting_failures']==1,'extension accepts8 and retains reporting failure1')
report={'study_id':'AWE-2026-01','review':'Independent same-session artifact/arithmetic audit, not external peer review or operational qualification','checks':len(checks),'issues':[],'primary':{'cases':24,'accepted':16,'expected_refusals':8,'unexpected':0,'quotes':quote_rows},'extension':{'id':'AWE-TRANSFER-02','cases':8,'accepted':8,'parent_supported':2,'parent_budget_refusals':2,'parent_scope_refusals':4,'original_reporting_failures':1,'quotes':extension_rows},'limits':['Primary24 and subsequent8 probes are distinct frozen studies, not32 primary independent jobs.','Quotes are synthetic structural fixtures; exact objective checks do not establish customer value, market price, generalized sourcing or real purchasing.','Local timestamps and source identities support the recorded sequence; no external preregistration or blinded independence.','No actual full cost, production acceptance, authenticated executor or payment is established.']}
(OUT/'delivery-evidence-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'checks':len(checks),'issues':[],'primary_cases':24,'extension_cases':8,'quote_cases_recomputed':len(quote_rows)+len(extension_rows)}))
