# AGI ALPHA FLYWHEEL — The Autonomous Work Economy

**From Useful Outcomes to Expanding Productive Capability**  
**SUCCESSOR Ω HARNESS · ACTIVATE. EVOLVE. SCALE.**  
Powered by TRANSFORMATIONAL INTELLIGENCE ∞ and the applicable $AGIALPHA utility.

Study **AWE-2026-01**, research edition 1.0, 25 October 2026. Vincent Boucher · MONTREAL.AI.

## Start with a useful outcome

Open `demo/AGI_ALPHA_Autonomous_Work_Economy.html` in a modern browser and choose **Try it now / Essayer**. The complete page works offline. It computes a quote basket using the pinned AGI ALPHA Workbench, lets you supply permitted offer CSV, and exports a cart, localized report and integrity-bound evidence. No account, API key, wallet, payment or purchase is involved. Included supplier names, prices and exchange ratios are synthetic.

The example's **USD 520.12** is the price of the modeled equipment basket, **not the cost of running AGI ALPHA**. Full observed enterprise cost remains unknown. The page distinguishes fresh local computation, recorded evidence and economic simulation.

## What this contribution establishes

| Claim | Evidence and limit |
|---|---|
| Bounded local delivery | 24 frozen structural cases: 16 contract-accepted artifacts, eight intended refusals, no unexpected primary failures. Four related families; no occupation-wide generalization. |
| Source/runtime reuse | Actual `createWorkbench → plan/run → inspectPack` through a seven-module pinned Alpha source closure. No upstream source edits. |
| Capability transfer | Executable capsule retention, reuse, a rejected greedy candidate and allowlisted successor composition. A later eight-case new-input extension gives successor 8/8, initial capsule 2/8 and conventional MILP 8/8. |
| Human-work economics | Sourced wage-based break-even thresholds; no matched human task times or equivalent customer acceptance observed. |
| Full delivery cost | Price-calibrated scenarios with explicit usage, quality, exceptions, upkeep and utilization assumptions. No observed full enterprise invoice. |
| Reinvestment | Cash-constrained conditional financeability, without admitting an investment whose monetary benefit is unestablished. No customer payments or actual reinvestment. |
| Self-acceleration | Not established. Higher-order method discovery and full authenticated operation were not run. |

At an assumed 1,000 attempted portfolio jobs/month, the original model-extension scenarios give USD **0.714 / 3.351 / 32.961** fully loaded pre-tax cost per accepted output. The separate automatic-upkeep sensitivity gives **0.529 / 2.817 / 32.075**. These are efficient/reference/stress assumptions, not measurements or confidence intervals. Payment fees, refunds and noncollection enter the receipt ledger separately. Market and price/volume grids are independent sensitivities; they do not establish mutually consistent demand.

## Read the complete study

`paper/AGI_ALPHA_Autonomous_Work_Economy.pdf` contains the question, protocol, results, exact economic equations, source metadata, cost/cash/market scenarios, token-route audit, scorecard and limits. `paper/AGI_ALPHA_Autonomous_Work_Economy.tex` is standalone: it embeds its bibliography and three figure sources with standard LaTeX `filecontents`. The bibliography and reusable vector figures are also supplied separately.

To compile in a new directory with TeX Live, copy the standalone `.tex` there and run:

```sh
pdflatex -interaction=nonstopmode -halt-on-error AGI_ALPHA_Autonomous_Work_Economy.tex
bibtex AGI_ALPHA_Autonomous_Work_Economy
pdflatex -interaction=nonstopmode -halt-on-error AGI_ALPHA_Autonomous_Work_Economy.tex
pdflatex -interaction=nonstopmode -halt-on-error AGI_ALPHA_Autonomous_Work_Economy.tex
```

## Reproduce without changing the supplied evidence

Node 22+ with Web Crypto, Python 3.11–3.13, NumPy and SciPy are required for the native experiment and independent MILP. Exact observed versions are recorded in `implementation/requirements.txt` and the execution receipts. The browser demo requires none of these installations.

From the extracted companion, choose a new output directory outside this tree:

```sh
python3 reproduce.py --output /tmp/awe-reproduction-01
```

The script copies the necessary source/evidence to that new directory, executes a new native run and the corrected transfer reporter, regenerates economics, runs the independent numerical and delivery audits, and exercises the exact shared cost-schema adapter. It refuses an existing output directory and makes no provider or blockchain calls. Outcomes and arithmetic should agree; performance, timestamps and integrity identities can vary. Repetition adds no independent task breadth.

`implementation/run.py` also supports independent new run IDs. Original raw traces preserve `independent_acceptance: PENDING`; the later acceptance file supplies the assessed outcome without rewriting raw history. Absolute scratch paths in historical trace metadata are provenance, not portable input locations; the reproduction scripts generate fresh local paths.

## Package map

| Directory | Contents |
|---|---|
| `implementation/` | Frozen protocol, 24 inputs, actual runtime source, adapters, original and repeated traces, output artifacts, independent verifiers, fault checks and capsule sequence. |
| `extension/` | Separate eight-case prospective transfer freeze, new inputs, packs, initial reporting failure, documented correction and complete acceptance audit. |
| `economics/` | Dated source registry, assumptions, freezes, analysis code, full original results, cash-constrained amendment and separately frozen automatic-upkeep variant. |
| `foundations/` | Four-repository source audit, immutable identities, scoped contract/deployment findings and independent Decimal economic check. |
| `publication/shared-contract/` | Exact upstream product-contract candidate and tested study adapter. Its marginal tier differs from this paper's definition; see its README. |
| `publication/` | Independent delivery/source checks and concrete publication preparation/proof receipts where available. It does not include the bulk repository materialization or installed validator. |
| `demo/` | Standalone HTML, original application sources, reproducible bundler, license, actual browser QA and preserved initial mobile failure. |
| `paper/`, `figures/`, `paper_support/` | Publication-ready manuscript, complete source, bibliography, vector figures and auditable figure data. |
| `verification/` | Integrated source/claim/layout/reproduction receipts and publication-status metadata. |

## Important preserved failures and boundaries

The per-item greedy quote candidate costs USD 22 versus a valid USD 13 cart and is rejected. The original transfer reporter failed while formatting a legitimate null parent result after all eight outputs existed; its frozen source and outputs remain, with a separately versioned reporting-only correction. Initial French mobile QA found a six-pixel overflow; the final demo fixes it and preserves the failed receipt.

The runtime records `PUBLIC_LOCAL_EXECUTION`, admission `HOLD`, no model/provider identity, unknown full costs and settlement `NOT_CONNECTED`. The authenticated Harness/Fleet/provider route, new human trial, real customer payments, fresh chain readback and self-acceleration remain unperformed or unestablished as specified in the paper. Research-assistant authoring/model usage and original kernel engineering were external unmetered inputs, not free production resources.

USDC Manager, AGIALPHA Ascension and AGIALPHA Jobs-v0 routes have distinct permissions and deductions. None is executed locally. Token issuance, treasury transfers, principal refunds and speculative appreciation are not profit. No new paid commitments, credentials, financial transactions, security changes, deployed-contract changes or held-operation retries were introduced.

## Independence and additive publication

Implementation, economics and verification used separate algorithms/agents within one shared research session. This is not external blinded peer review. Existing research/release owners, source freezes, negative results and public URLs are preserved. Passive paper publication and executable demo/companion qualification are separate handoffs through Alpha issue #4850. A draft branch or local pass is not a public installation; see the current publication receipt for exact status.

Original study code is Apache 2.0. Upstream notices are retained. Statistical facts are attributed to their sources. No private motivational material is included.
