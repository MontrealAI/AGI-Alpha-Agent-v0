import hashlib, json
from pathlib import Path

H=Path(__file__).resolve().parent
S=json.loads((H/'sources.json').read_text())
P=json.loads((H/'scenario_parameters.json').read_text())
A=json.loads((H/'automated_upkeep_protocol.json').read_text())
C=json.loads((H/'automated_upkeep_clarification_v1_1.json').read_text())
R=json.loads((H/'results/economic_results.json').read_text())
Q=A['assumptions']
T={r['id']:r for r in S['sources']}
dev=R['rates']['developer_employer_proxy_hourly_usd']
support=R['rates']['support_hourly_usd']
pin=T['OPENAI_SOL_20261025']['input_usd_per_million_tokens']/1e6
pout=T['OPENAI_SOL_20261025']['output_usd_per_million_tokens']/1e6
runtime=T['OPENAI_TOOLS_20261025']['hosted_container_1gb_usd_per_20min_session']
search=T['OPENAI_TOOLS_20261025']['web_search_usd_per_call']
results=[]
for r in R['portfolio']:
    s=P['scenarios'][r['scenario']]
    opportunities=s['maintenance_hours_per_month']
    repair_model=opportunities*(Q['input_tokens_per_automatic_repair']*pin+Q['billable_output_tokens_per_automatic_repair_including_reasoning']*pout)*s['model_token_multiplier']
    repair_runtime=opportunities*Q['hosted_20min_sessions_per_automatic_repair']*runtime
    residual_repair_hours=opportunities*(1-Q['automated_success_probability'][r['scenario']])*Q['failed_automatic_repair_human_hours']
    residual_repair_cost=residual_repair_hours*dev
    regression_cost=Q['scheduled_regression_sessions_per_month']*runtime
    source_cost=Q['public_source_refresh_batches_per_month']*((Q['input_tokens_per_source_refresh']*pin+Q['billable_output_tokens_per_source_refresh']*pout)*s['model_token_multiplier']+Q['search_calls_per_source_refresh']*search+C['hosted_20min_sessions_per_source_refresh_batch']*runtime)
    bookkeeping_cost=Q['bookkeeping_batches_per_month']*((Q['input_tokens_per_bookkeeping_batch']*pin+Q['billable_output_tokens_per_bookkeeping_batch']*pout)*s['model_token_multiplier']+Q['hosted_20min_sessions_per_bookkeeping_batch']*runtime)
    residual_admin_hours=s['business_admin_hours_per_month']*((1-Q['administration_automatable_fraction'])+Q['administration_automatable_fraction']*(1-Q['administration_automation_success_probability']))
    residual_admin_cost=residual_admin_hours*support
    old_shared=opportunities*dev+s['business_admin_hours_per_month']*support
    new_shared=sum([repair_model,repair_runtime,residual_repair_cost,regression_cost,source_cost,bookkeeping_cost,residual_admin_cost])
    extra_setup=Q['additional_setup_hours'][r['scenario']]*dev
    accepted=r['expected_accepted_per_month']
    full=r['fully_loaded_pretax_usd_per_accepted']+(new_shared-old_shared)/accepted+extra_setup/P['numerical_grid']['amortization_months']/accepted
    recurring=r['recurring_delivery_usd_per_accepted']+(new_shared-old_shared)/accepted
    results.append({'scenario':r['scenario'],'route':r['route'],'attempts_per_month':r['attempts_per_month'],'status':'MODELED_NOT_RUN',
                    'original_fully_loaded_pretax_usd_per_accepted':r['fully_loaded_pretax_usd_per_accepted'],
                    'automated_upkeep_fully_loaded_pretax_usd_per_accepted':full,'automated_upkeep_recurring_usd_per_accepted':recurring,
                    'additional_setup_usd_assumed':extra_setup,'original_shared_upkeep_admin_monthly_usd':old_shared,
                    'replacement_shared_monthly_usd':new_shared,'replacement_components_monthly_usd':{
                        'automatic_repair_model':repair_model,'automatic_repair_runtime':repair_runtime,'residual_repair':residual_repair_cost,
                        'scheduled_regressions':regression_cost,'source_refresh':source_cost,'automatic_bookkeeping':bookkeeping_cost,'residual_administration':residual_admin_cost},
                    'residual_upkeep_hours_per_month_assumed':residual_repair_hours,'residual_admin_hours_per_month_assumed':residual_admin_hours,
                    'actual_maintenance_success_or_spending':'NOT_MEASURED'})
    assert abs(full-recurring-(r['setup_total_usd']+extra_setup)/(P['numerical_grid']['amortization_months']*accepted))<1e-8
out={'study_id':'AWE-2026-01','protocol_sha256':hashlib.sha256((H/'automated_upkeep_protocol.json').read_bytes()).hexdigest(),
     'clarification_sha256':hashlib.sha256((H/'automated_upkeep_clarification_v1_1.json').read_bytes()).hexdigest(),
     'original_result_sha256':hashlib.sha256((H/'results/economic_results.json').read_bytes()).hexdigest(),'results':results,
     'limits':A['claim_limit'],'reproduction':'python3 economics/analyze.py && python3 economics/automated_upkeep.py'}
(H/'results/automated_upkeep_results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps([r for r in results if r['route']=='modeled_model_extension' and r['attempts_per_month']==1000],indent=2))
