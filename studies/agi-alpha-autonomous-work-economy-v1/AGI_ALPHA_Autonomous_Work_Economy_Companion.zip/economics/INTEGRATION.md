# Additive economic companion

This directory is a study-specific analysis for AWE-2026-01. Its JSON is not the shared product economics schema, an on-chain ABI, a replacement for Product PR #4907, or a change to another study's frozen costs.

The foundation audit's exact pinned lookup found that `examples/successor-alpha/automated-costs.mjs` was not yet present at the inspected #4907 head. Integration with that owner's final contract therefore remains pending reconciliation. The additive publication can preserve this directory unchanged and link its methodology and outputs.

Entry point: `python3 economics/analyze.py`. Inputs: the source registry, methods freeze, scenario freeze and explicit amendments. Output schema contains `unit_results`, `portfolio`, `market`, `unconstrained_funding_gap_diagnostics`, `cash_constrained_ledgers`, `observed`, `input_sha256` and `checks`.

For presentation, every monetary row from `unit_results`/`portfolio` must retain a visible **Modeled** label. The observed section contains runtime, artifact bytes and contract acceptance only; its local monetary costs are null. A separate `acceptance.json` sidecar supersedes PENDING fields retained in immutable raw execution records. Do not overwrite raw records to make subsequent acceptance appear contemporaneous.

Price, volume, acceptance, customer attention and exception controls can be exposed interactively. Use the complete component sum, including shared upkeep and setup allocation, with all-attempt costs divided by accepted outputs. Price-based customer savings require the customer's alternative time and wage, not just the enterprise's marginal model bill.

The cash-constrained ledger allows no negative cash and no new borrowing. Its commitment suspension assumption is explicit. The unconstrained diagnostic is retained solely to expose funding gaps. Markets and cash/volume scenarios are independent sensitivity modules; combining them into a forecast requires actual demand and pricing evidence.

No token route is executed. Source-verified route details belong to the separate foundations audit. An on-chain extension must specify asset decimals, actual split, gas, claims and collateral restrictions independently, rather than adding a generic token fee to the local study.
