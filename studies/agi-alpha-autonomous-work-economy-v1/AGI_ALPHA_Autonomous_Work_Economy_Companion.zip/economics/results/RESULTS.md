# AWE-2026-01 economic calculation results

These are prospective cost and cash scenarios. Source tariffs calibrate prices; production usage, acceptance, exception prevalence, demand and collections remain estimated or assumed. The actual total cost of the research and a live model enterprise is unknown.

## Equal portfolio, 1,000 attempted jobs/month

| Scenario | Modeled route | Marginal/accepted | Recurring/accepted | Fully loaded pretax/accepted | Adverse month full/accepted | Minimum pretax customer price |
|---|---|---:|---:|---:|---:|---:|
| efficient | modeled_tool_delivery | $0.04 | $0.46 | $0.65 | $0.93 | $0.99 |
| efficient | modeled_model_extension | $0.10 | $0.52 | $0.71 | $1.01 | $1.06 |
| reference | modeled_tool_delivery | $0.04 | $2.43 | $2.95 | $4.58 | $3.63 |
| reference | modeled_model_extension | $0.18 | $2.79 | $3.35 | $5.18 | $4.07 |
| stress | modeled_tool_delivery | $0.05 | $21.59 | $23.11 | $38.82 | $33.55 |
| stress | modeled_model_extension | $1.03 | $30.85 | $32.96 | $55.44 | $47.70 |

## Reference model-extension family thresholds

| Workflow | Full cost/accepted | Wage-only break-even minutes | Employer proxy minutes | Wage-only minutes including 3 extra user minutes |
|---|---:|---:|---:|---:|
| Quote comparison packet | $3.27 | 8.06 | 5.53 | 13.84 |
| Source-grounded fact brief | $3.36 | 4.64 | 3.21 | 7.87 |
| Dependency and resource plan | $3.28 | 6.85 | 4.70 | 11.76 |
| Bounded source repair packet | $3.50 | 4.36 | 3.01 | 7.27 |

No matched human timings were collected. These thresholds are conditions for an economic advantage, not measured time savings. Customer price and enterprise cost are distinct. The raw kernel computes quickly but its local monetary cost and all authoring costs are unmetered.

## Financial result

All customer payments in the ledger are simulated. Initial cash is external endowment. Booked invoices do not become reinvestable cash until modeled collection. A 25% illustrative obligation reserve is restricted, not presented as an assessed tax. With no established monetary transfer gain, the null investment policy admits no candidate; financeability and value justification are separate.

## Market scope

The market calculation is a four-occupation, task-filtered illustrative subset, not total US digital work. OEWS annual wages use 2,080-hour annualization; they are not observed payroll totals. Task shares, permissions, adoption, price capture and capacity are assumptions. See sources.json and scenario_parameters.json for every input.
