import argparse, csv, hashlib, json, math, statistics
from pathlib import Path

HERE = Path(__file__).resolve().parent

def read(name):
    return json.loads((HERE / name).read_text())

S = read('sources.json')
P = read('scenario_parameters.json')
A = read('economics_amendment_v1_1.json')
O = {v['id']: v for v in S['occupations']}
T = {v['id']: v for v in S['sources']}
G = S['compensation_groups']
SUPPORT = G['private_industry_all']['total_hourly_usd']
DEVELOPER = O['software_developers']['median_hourly_wage_usd'] * G['professional']['total_hourly_usd'] / G['professional']['wage_hourly_usd']

def unit(family, scenario, route, volume):
    s = P['scenarios'][scenario]
    model = route == 'modeled_model_extension'
    rt = 'extension' if model else 'tool'
    r, p, q = s[rt + '_retry_probability'], s[rt + '_final_acceptance_probability'], s['common_shock_month_probability']
    rbad = min(1, r + s['shock_extra_retry_probability'])
    pbad = p * s['shock_acceptance_retention']
    pe = (1-q)*p + q*pbad
    attempts_per_job = 1 + (1-q)*r + q*rbad
    assert 0 < pe <= 1 and 0 <= r <= 1 and p >= 1-r
    ins = sum(v['input_tokens'] for v in family['estimated_model_stages']) * s['model_token_multiplier'] if model else 0
    outs = sum(v['billable_output_tokens_including_reasoning'] for v in family['estimated_model_stages']) * s['model_token_multiplier'] if model else 0
    model_cost = (ins*T['OPENAI_SOL_20261025']['input_usd_per_million_tokens']+outs*T['OPENAI_SOL_20261025']['output_usd_per_million_tokens'])/1e6
    runtime_cost = family['hosted_20min_sessions'] * T['OPENAI_TOOLS_20261025']['hosted_container_1gb_usd_per_20min_session']
    search_cost = family['estimated_web_search_calls'] * T['OPENAI_TOOLS_20261025']['web_search_usd_per_call'] if model else 0
    base = model_cost+runtime_cost+search_cost
    assert s['normal_exception_probability']+s['rare_exception_probability'] <= 1
    exception_minutes = s['normal_exception_probability']*s['normal_exception_minutes']+s['rare_exception_probability']*s['rare_exception_minutes']
    exception_cost = exception_minutes*SUPPORT/60
    fixed_parts = {
        'platform_archive': s['shared_platform_archive_usd_per_month'],
        'maintenance': s['maintenance_hours_per_month']*DEVELOPER,
        'business_administration': s['business_admin_hours_per_month']*SUPPORT,
        'common_shock_recovery': q*s['shock_recovery_hours']*DEVELOPER,
    }
    setup = s['setup_development_hours']*DEVELOPER
    recurring = (base*attempts_per_job+exception_cost+sum(fixed_parts.values())/volume)/pe
    marginal = base*attempts_per_job/pe
    full = recurring+setup/(P['numerical_grid']['amortization_months']*volume*pe)
    components = {
        'model_tokens': model_cost*attempts_per_job/pe,
        'runtime': runtime_cost*attempts_per_job/pe,
        'search': search_cost*attempts_per_job/pe,
        'normal_exceptions': s['normal_exception_probability']*s['normal_exception_minutes']*SUPPORT/60/pe,
        'rare_exceptions': s['rare_exception_probability']*s['rare_exception_minutes']*SUPPORT/60/pe,
        **{k: v/volume/pe for k,v in fixed_parts.items()},
        'setup_amortization': setup/(P['numerical_grid']['amortization_months']*volume*pe),
    }
    assert abs(sum(components.values())-full)<1e-8
    occ = O[family['occupation_id']]
    wage = occ['median_hourly_wage_usd']
    group = G[occ['cost_group']]
    loaded = wage*group['total_hourly_usd']/group['wage_hourly_usd']
    badfixed = sum(v for k,v in fixed_parts.items() if k != 'common_shock_recovery') + s['shock_recovery_hours']*DEVELOPER
    badfull = (base*(1+rbad)+exception_cost+badfixed/volume+setup/(P['numerical_grid']['amortization_months']*volume))/pbad
    customer_extra = s['customer_incremental_minutes']*SUPPORT/60
    fee = P['numerical_grid']['payment_fee_fraction']
    fee_fixed = P['numerical_grid']['payment_fee_fixed_usd']
    collect, refund = s['collection_fraction'], s['refund_fraction']
    price_floor = (full + collect*fee_fixed)/(collect*(1-refund-fee))
    return {
        'family':family['id'],'family_name':family['name'],'scenario':scenario,'route':route,'attempts_per_month':volume,
        'expected_accepted_per_month':volume*pe,'assumed_final_acceptance_in_normal_month':p,'assumed_expected_acceptance':pe,
        'estimated_base_input_tokens':ins,'estimated_base_billable_output_tokens':outs,'modeled_attempts_per_requested_job':attempts_per_job,
        'marginal_execution_usd_per_accepted':marginal,'recurring_delivery_usd_per_accepted':recurring,
        'fully_loaded_pretax_usd_per_accepted':full,'adverse_month_fully_loaded_usd_per_accepted':badfull,
        'components_usd_per_accepted':components,'setup_total_usd':setup,
        'median_wage_hourly_usd':wage,'estimated_employer_hourly_usd':loaded,
        'break_even_human_minutes_wage_only':full*60/wage,'break_even_human_minutes_employer_proxy':full*60/loaded,
        'break_even_human_minutes_wage_with_extra_attention':(full+customer_extra)*60/wage,
        'pretax_customer_price_floor_usd_including_modeled_noncollection_refund_fees':price_floor,
        'interpretation':'Scenario calculation, not observed total cost or evidence of matched human productivity.'
    }

def portfolio(rows, scenario, route, volume):
    selected = [r for r in rows if r['scenario']==scenario and r['route']==route and r['attempts_per_month']==volume]
    fields = ['expected_accepted_per_month','marginal_execution_usd_per_accepted','recurring_delivery_usd_per_accepted','fully_loaded_pretax_usd_per_accepted','adverse_month_fully_loaded_usd_per_accepted','pretax_customer_price_floor_usd_including_modeled_noncollection_refund_fees']
    out = {'scenario':scenario,'route':route,'attempts_per_month':volume,'portfolio_weights':'Equal 25% attempt mix of four families'}
    out.update({f:statistics.mean(r[f] for r in selected) for f in fields})
    out['setup_total_usd'] = selected[0]['setup_total_usd']
    out['components_usd_per_accepted'] = {k:statistics.mean(r['components_usd_per_accepted'][k] for r in selected) for k in selected[0]['components_usd_per_accepted']}
    return out

def ledger(summary, price):
    s = P['scenarios'][summary['scenario']]
    n = summary['expected_accepted_per_month']
    recurring_monthly = n*summary['recurring_delivery_usd_per_accepted']
    setup = summary['setup_total_usd']
    reserve = P['numerical_grid']['reserve_months']*recurring_monthly
    endowment = setup + reserve + s['collection_delay_months']*recurring_monthly
    cash = endowment-setup
    gross_booked = n*price
    collected_invoice = gross_booked*s['collection_fraction']
    invoice_count = n*s['collection_fraction']
    cum_generated = 0
    obligations = 0
    candidate_cost = P['financial_policy']['candidate_construction_hours']*DEVELOPER
    candidate_upkeep = P['financial_policy']['candidate_maintenance_hours_per_month']*DEVELOPER
    trace = []
    for m in range(1,P['numerical_grid']['cash_projection_months']+1):
        receipts = collected_invoice if m>s['collection_delay_months'] else 0
        payment_fees = receipts*P['numerical_grid']['payment_fee_fraction'] + (invoice_count*P['numerical_grid']['payment_fee_fixed_usd'] if receipts else 0)
        refunds = receipts*s['refund_fraction']
        change = receipts-refunds-payment_fees-recurring_monthly
        previous = cash
        cash += change
        cum_generated += change
        obligation_increment = max(0,change)*A['changes']['obligation_reserve_fraction_of_positive_operating_cash_margin']
        obligations += obligation_increment
        generated_after_setup_and_obligations = cum_generated-setup-obligations
        available = max(0,min(cash-reserve-obligations, generated_after_setup_and_obligations))
        can_finance = m>=P['financial_policy']['candidate_start_after_month'] and available>=candidate_cost
        horizon = max(0,P['numerical_grid']['cash_projection_months']-m-P['financial_policy']['candidate_benefit_delay_months'])
        units = horizon*n
        success_prob = 1-P['financial_policy']['candidate_failure_probability']
        required_gain = (candidate_cost+horizon*candidate_upkeep)/(units*success_prob) if units*success_prob>0 else None
        trace.append({'month':m,'booked_revenue_usd':gross_booked,'collected_cash_usd':receipts,
                      'modeled_bad_debt_written_off_usd':gross_booked-receipts if m>s['collection_delay_months'] else 0,
                      'refunds_usd':refunds,'payment_fees_usd':payment_fees,'recurring_cash_expenses_usd':recurring_monthly,
                      'cash_change_usd':change,'cash_balance_usd':cash,'obligation_reserve_increment_usd':obligation_increment,
                      'cumulative_obligation_reserve_usd':obligations,'operating_reserve_target_usd':reserve,
                      'cumulative_work_generated_pretax_cash_usd':cum_generated,'generated_cash_after_setup_recovery_and_obligations_usd':generated_after_setup_and_obligations,
                      'available_generated_surplus_usd':available,'candidate_financeable':can_finance,'candidate_admitted':False,'construction_spend_usd':0,
                      'candidate_decision':'REJECT_PENDING_TRANSFER_VALUE_EVIDENCE' if can_finance else 'INSUFFICIENT_EARNED_SURPLUS_OR_EARLY',
                      'contingent_required_savings_per_accepted_usd':required_gain,
                      'accounts_receivable_gross_usd':gross_booked*min(m,s['collection_delay_months']),
                      'liquidity_shortfall_usd':max(0,-cash)})
        assert abs(cash-previous-change)<1e-8
    return {'scenario':summary['scenario'],'route':summary['route'],'attempts_per_month':summary['attempts_per_month'],'assumed_price_usd':price,
            'status':'SIMULATION_NO_CUSTOMER_PAYMENTS','externally_endowed_initial_cash_usd':endowment,'setup_cash_outflow_at_month_zero_usd':setup,
            'candidate_construction_cost_usd_assumed':candidate_cost,'candidate_upkeep_per_month_usd_assumed':candidate_upkeep,
            'actual_constructed_capability_cost_usd':None,'trace':trace,
            'limits':'Expected-state cash path; ordinary/rare/common-shock expected expenses included. Monthly shocks remain correlated and explicit adverse-month cost is separate; no claim that this deterministic path represents liquidity quantiles. No gains are automatically attributed to investments.'}

def market():
    answer=[]
    for label,m in P['market']['scenarios'].items():
        detail=[]
        for oid in P['market']['selected_occupation_ids']:
            o=O[oid]
            baseline=o['employment']*o['mean_hourly_wage_usd']*m['annual_hours']
            digital=baseline*m['digital_share'][oid]
            technical=digital*m['supported_task_share']
            permitted=technical*m['permission_input_share']
            serviceable=permitted*m['adoption']
            detail.append({'occupation_id':oid,'employment':o['employment'],'annualized_wage_equivalent_usd':baseline,
                           'digital_task_wage_equivalent_usd':digital,'technically_supported_scenario_usd':technical,
                           'permitted_input_scenario_usd':permitted,'adopted_serviceable_labor_value_usd':serviceable,
                           'unconstrained_provider_revenue_scenario_usd':serviceable*m['provider_share']*m['price_capture_of_human_labor']})
        totals={k:sum(d[k] for d in detail) for k in detail[0] if k not in ['occupation_id','employment']}
        capacity={str(price):min(totals['unconstrained_provider_revenue_scenario_usd'],m['capacity_attempts_per_month']*12*P['scenarios']['reference']['extension_final_acceptance_probability']*price) for price in P['numerical_grid']['prices_usd']}
        expected_p=P['scenarios']['reference']['extension_final_acceptance_probability']*((1-P['scenarios']['reference']['common_shock_month_probability'])+P['scenarios']['reference']['common_shock_month_probability']*P['scenarios']['reference']['shock_acceptance_retention'])
        expected_capacity={str(price):min(totals['unconstrained_provider_revenue_scenario_usd'],m['capacity_attempts_per_month']*12*expected_p*price) for price in P['numerical_grid']['prices_usd']}
        answer.append({'scenario':label,'occupations':detail,'totals':totals,'capacity_capped_obtainable_annual_revenue_by_assumed_price':capacity,
                       'capacity_basis':'Original cap uses reference normal-month assumed acceptance0.90; not shock-adjusted expected capacity.',
                       'capacity_cap_with_reference_common_shocks_by_assumed_price':expected_capacity,
                       'source_status':'Employment/wage externally sourced; annual hours and all successive filters are assumptions; potential values, not realized revenues.'})
    return answer

def constrained_ledger(summary, price):
    s = P['scenarios'][summary['scenario']]
    volume = summary['attempts_per_month']
    pe = summary['expected_accepted_per_month']/volume
    variable_keys = ['model_tokens','runtime','search','normal_exceptions','rare_exceptions']
    variable = sum(summary['components_usd_per_accepted'][k] for k in variable_keys)*pe
    fixed = sum(v for k,v in summary['components_usd_per_accepted'].items() if k not in variable_keys+['setup_amortization'])*pe*volume
    recurring_target = fixed+variable*volume
    reserve_target = P['numerical_grid']['reserve_months']*recurring_target
    setup = summary['setup_total_usd']
    endowment = setup+reserve_target+s['collection_delay_months']*recurring_target
    cash = endowment-setup
    obligations = generated = 0
    pending = {}
    trace = []
    fee_fraction = P['numerical_grid']['payment_fee_fraction']
    fee_fixed = P['numerical_grid']['payment_fee_fixed_usd']
    def paid(gross, invoices):
        receipts = gross*s['collection_fraction']
        refunds = receipts*s['refund_fraction']
        fees = receipts*fee_fraction+invoices*s['collection_fraction']*fee_fixed
        return receipts, refunds, fees
    for month in range(1,P['numerical_grid']['cash_projection_months']+1):
        previous = cash
        receivables_opening = sum(v[0] for v in pending.values())
        due_gross, due_count = pending.pop(month,(0,0))
        receipts, refunds, fees = paid(due_gross,due_count)
        cash += receipts-refunds-fees
        liquid = max(0,cash-obligations)
        count = min(volume,max(0,math.floor((liquid-fixed)/variable))) if liquid>=fixed else 0
        spent = fixed+count*variable if count>0 else 0
        cash -= spent
        accepted = count*pe
        booked = accepted*price
        if s['collection_delay_months']==0:
            receipt_now, refund_now, fee_now = paid(booked,accepted)
            receipts += receipt_now; refunds += refund_now; fees += fee_now
            cash += receipt_now-refund_now-fee_now
            due_gross += booked
        else:
            pending[month+s['collection_delay_months']] = (booked,accepted)
        change = receipts-refunds-fees-spent
        generated += change
        reserve_increment = max(0,change)*A['changes']['obligation_reserve_fraction_of_positive_operating_cash_margin']
        obligations += reserve_increment
        available = max(0,min(cash-reserve_target-obligations,generated-setup-obligations))
        trace.append({'month':month,'requested_attempts':volume,'funded_attempts':count,'modeled_accepted':accepted,'suspended':count==0,
                      'booked_revenue_usd':booked,'collected_cash_usd':receipts,'refunds_usd':refunds,'payment_fees_usd':fees,
                      'modeled_bad_debt_written_off_usd':due_gross-receipts,
                      'recurring_cash_expenses_usd':spent,'cash_change_usd':change,'cash_balance_usd':cash,
                      'cumulative_obligation_reserve_usd':obligations,'operating_reserve_target_usd':reserve_target,
                      'available_generated_surplus_usd':available,'gross_pending_receivables_usd':sum(v[0] for v in pending.values()),
                      'candidate_admitted':False,'construction_spend_usd':0})
        assert cash>=-1e-8 and obligations<=cash+1e-8
        assert abs(cash-previous-change)<1e-8
        assert abs(receivables_opening+booked-due_gross-sum(v[0] for v in pending.values()))<1e-8
    return {'scenario':summary['scenario'],'route':summary['route'],'attempts_per_month_target':volume,'assumed_price_usd':price,
            'status':'CASH_CONSTRAINED_SIMULATION_NO_PAYMENTS_OBSERVED','initial_external_endowment_usd':endowment,
            'setup_cash_outflow_at_month_zero_usd':setup,'variable_cost_per_funded_attempt_usd':variable,'fixed_commitment_if_operating_month_usd':fixed,
            'trace':trace,'limits':'Expected-state affordability, not a tail-risk guarantee. Future month commitments assumed suspendible; no credit, new borrowing or hidden negative cash is allowed.'}

def observed(path):
    if not path or not (path/'raw.jsonl').exists():
        return {'status':'NOT_IMPORTED'}
    raw=[json.loads(s) for s in (path/'raw.jsonl').read_text().splitlines()]
    acc=json.loads((path/'acceptance.json').read_text())
    decisions={r['task_id']:r for r in acc['records']}
    summary=[]
    for family in sorted(set(r['family'] for r in raw)):
        selected=[r for r in raw if r['family']==family]
        delivered=[r for r in selected if decisions[r['task_id']]['delivered']]
        summary.append({'family':family,'cases':len(selected),'accepted':len(delivered),'expected_refusals':sum(decisions[r['task_id']]['outcome']=='EXPECTED_REFUSAL' for r in selected),
                       'all_cases_elapsed_ms':sum(r['elapsed_ms'] for r in selected),'accepted_case_mean_elapsed_ms':statistics.mean(r['elapsed_ms'] for r in delivered),
                       'accepted_artifact_bytes':sum(r['artifact_bytes'] for r in delivered),'all_case_provider_calls':sum(r['provider_calls'] for r in selected),
                       'observed_local_cash_cost_usd':None,'production_acceptance_estimate':None})
    specialist=json.loads((path/'specialist-comparison.json').read_text())
    seconds=[]
    bycase=[]
    for task in sorted(set(r['task_id'] for r in specialist['samples'])):
        cases=[r for r in specialist['samples'] if r['task_id']==task]
        candidate=statistics.median(r['candidate']['elapsed_ms'] for r in cases)
        incumbent=statistics.median(r['incumbent']['elapsed_ms'] for r in cases)
        bycase.append({'task_id':task,'candidate_median_ms':candidate,'incumbent_median_ms':incumbent,'saved_ms':incumbent-candidate})
        seconds.append((incumbent-candidate)/1000)
    saved=statistics.mean(seconds)
    proportional_hourly=T['OPENAI_TOOLS_20261025']['hosted_container_1gb_usd_per_20min_session']*3
    equivalent_savings=saved*proportional_hourly/3600
    candidatecost=P['financial_policy']['candidate_construction_hours']*DEVELOPER
    payback=candidatecost/equivalent_savings if equivalent_savings>0 else None
    return {'status':'MEASURED_BOUNDED_LOCAL_EXECUTION','families':summary,'source_raw_sha256':hashlib.sha256((path/'raw.jsonl').read_bytes()).hexdigest(),
            'source_acceptance_sha256':hashlib.sha256((path/'acceptance.json').read_bytes()).hexdigest(),
            'scope':'Preselected contract fixtures; no representative production sampling or end-to-end authenticated model execution.',
            'specialist_timing':bycase,'economic_interpretation':{
                'hypothetical_proportional_runtime_rate_usd_per_hour':proportional_hourly,'mean_solver_seconds_saved':saved,
                'hypothetical_proportional_runtime_savings_per_call_usd':equivalent_savings,
                'dedicated_same_container_session_billed_savings_usd':0,
                'assumed_8hour_construction_cost_usd':candidatecost,'proportional_payback_calls_ignoring_maintenance':payback,
                'actual_construction_cost_usd':None,
                'claim':'Solver latency improves on four controlled cases; this alone does not establish an economically admissible investment. Newly enabled work could have additional value, unmeasured here.'}}

def write_csv(path, rows):
    flat=[{k:v for k,v in r.items() if not isinstance(v,(dict,list))} for r in rows]
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(flat[0])); w.writeheader(); w.writerows(flat)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--observed',type=Path,default=HERE.parent/'implementation/runs/confirmation-v1')
    ap.add_argument('--out',type=Path,default=HERE/'results')
    args=ap.parse_args(); args.out.mkdir(parents=True,exist_ok=True)
    rows=[unit(f,s,r,n) for f in P['families'] for s in P['scenario_labels'] for r in ['modeled_tool_delivery','modeled_model_extension'] for n in P['numerical_grid']['attempts_per_month']]
    summaries=[portfolio(rows,s,r,n) for s in P['scenario_labels'] for r in ['modeled_tool_delivery','modeled_model_extension'] for n in P['numerical_grid']['attempts_per_month']]
    ledgers=[ledger(v,price) for v in summaries if v['attempts_per_month']==1000 and v['route']=='modeled_model_extension' for price in P['numerical_grid']['prices_usd']]
    constrained=[constrained_ledger(v,price) for v in summaries if v['attempts_per_month']==1000 and v['route']=='modeled_model_extension' for price in P['numerical_grid']['prices_usd']]
    result={'study_id':P['study_id'],'status':'SCENARIOS_NOT_OBSERVED_COMMERCIAL_OUTCOMES',
            'input_sha256':{n:hashlib.sha256((HERE/n).read_bytes()).hexdigest() for n in ['sources.json','economics_protocol.json','scenario_parameters.json','economics_amendment_v1_1.json','economics_amendment_v1_2.json']},
            'rates':{'support_hourly_usd':SUPPORT,'developer_employer_proxy_hourly_usd':DEVELOPER},
            'unit_results':rows,'portfolio':summaries,'market':market(),'unconstrained_funding_gap_diagnostics':ledgers,'cash_constrained_ledgers':constrained,'observed':observed(args.observed),
            'checks':{'component_arithmetic':'PASS','cash_conservation':'PASS','constrained_nonnegative_cash':'PASS','production_acceptance_from_fixtures':'NOT_INFERRED','actual_total_cost':'UNKNOWN'}}
    (args.out/'economic_results.json').write_text(json.dumps(result,indent=2)+'\n')
    write_csv(args.out/'unit_costs.csv',rows)
    write_csv(args.out/'portfolio_costs.csv',summaries)
    text=['# AWE-2026-01 economic calculation results','',
          'These are prospective cost and cash scenarios. Source tariffs calibrate prices; production usage, acceptance, exception prevalence, demand and collections remain estimated or assumed. The actual total cost of the research and a live model enterprise is unknown.','',
          '## Equal portfolio, 1,000 attempted jobs/month','',
          '| Scenario | Modeled route | Marginal/accepted | Recurring/accepted | Fully loaded pretax/accepted | Adverse month full/accepted | Minimum pretax customer price |',
          '|---|---|---:|---:|---:|---:|---:|']
    for r in summaries:
        if r['attempts_per_month']==1000:
            text.append('| '+r['scenario']+' | '+r['route']+' | '+ ' | '.join('$'+format(r[k],'.2f') for k in ['marginal_execution_usd_per_accepted','recurring_delivery_usd_per_accepted','fully_loaded_pretax_usd_per_accepted','adverse_month_fully_loaded_usd_per_accepted','pretax_customer_price_floor_usd_including_modeled_noncollection_refund_fees'])+' |')
    text+=['','## Reference model-extension family thresholds','','| Workflow | Full cost/accepted | Wage-only break-even minutes | Employer proxy minutes | Wage-only minutes including 3 extra user minutes |','|---|---:|---:|---:|---:|']
    for r in rows:
        if r['scenario']=='reference' and r['route']=='modeled_model_extension' and r['attempts_per_month']==1000:
            text.append('| '+r['family_name']+' | $'+format(r['fully_loaded_pretax_usd_per_accepted'],'.2f')+' | '+ ' | '.join(format(r[k],'.2f') for k in ['break_even_human_minutes_wage_only','break_even_human_minutes_employer_proxy','break_even_human_minutes_wage_with_extra_attention'])+' |')
    text+=['','No matched human timings were collected. These thresholds are conditions for an economic advantage, not measured time savings. Customer price and enterprise cost are distinct. The raw kernel computes quickly but its local monetary cost and all authoring costs are unmetered.','','## Financial result','','All customer payments in the ledger are simulated. Initial cash is external endowment. Booked invoices do not become reinvestable cash until modeled collection. A 25% illustrative obligation reserve is restricted, not presented as an assessed tax. With no established monetary transfer gain, the null investment policy admits no candidate; financeability and value justification are separate.','','## Market scope','','The market calculation is a four-occupation, task-filtered illustrative subset, not total US digital work. OEWS annual wages use 2,080-hour annualization; they are not observed payroll totals. Task shares, permissions, adoption, price capture and capacity are assumptions. See sources.json and scenario_parameters.json for every input.']
    (args.out/'RESULTS.md').write_text('\n'.join(text)+'\n')
    print(json.dumps({'outputs':str(args.out),'portfolio_1000':[r for r in summaries if r['attempts_per_month']==1000],'checks':result['checks']},indent=2))

if __name__=='__main__': main()
