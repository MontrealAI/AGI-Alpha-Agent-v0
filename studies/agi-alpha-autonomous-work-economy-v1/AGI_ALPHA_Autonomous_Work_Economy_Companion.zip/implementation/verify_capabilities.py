# SPDX-License-Identifier: Apache-2.0
import json, hashlib
from pathlib import Path
from verify import incumbent
ROOT=Path(__file__).resolve().parent
manifest=json.loads((ROOT/'capabilities/manifest.json').read_text())
checks=[]
checks.append({'name':'v2_source_hash','passed':hashlib.sha256((ROOT/'capabilities/quote-v2.mjs').read_bytes()).hexdigest()==manifest['source_sha256']})
checks.append({'name':'v1_source_hash','passed':hashlib.sha256((ROOT/'capabilities/quote-v1.mjs').read_bytes()).hexdigest()==manifest['parent']['source_sha256']})
for id in ['Q2','Q4']:
    inp=json.loads((ROOT/'inputs'/f'{id}.json').read_text())['inputs'];out=json.loads((ROOT/'capabilities'/f'{id}-successor-output.json').read_text());baseline=incumbent(inp);checks.append({'name':id+'-independent-MILP','passed':out['total_minor']==baseline['total_minor'],'total_minor':out['total_minor']})
trap=json.loads((ROOT/'capabilities/shipping-regression-input.json').read_text());reference=incumbent(trap);checks.append({'name':'shipping-regression-MILP','passed':reference['total_minor']==1300,'incumbent_total_minor':reference['total_minor'],'rejected_candidate_minor':2200})
result={'checks':checks,'passed':sum(c['passed'] for c in checks),'total':len(checks),'independence':'Conventional independently implemented solver; same research team.'}
(ROOT/'capabilities/independent-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
if not all(c['passed'] for c in checks):raise SystemExit(1)
