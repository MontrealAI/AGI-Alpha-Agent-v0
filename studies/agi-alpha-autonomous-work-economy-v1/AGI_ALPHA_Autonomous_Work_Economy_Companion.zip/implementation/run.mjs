// SPDX-License-Identifier: Apache-2.0
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {createWorkbench} from './vendor/alpha/examples/successor-workbench/engine.mjs';
import {quoteAdapter,briefAdapter,planningAdapter,normalizeQuotes,subsetSolve,enumerationSolve} from './adapters.mjs';
const root=path.dirname(fileURLToPath(import.meta.url));
const json=async p=>JSON.parse(await fs.readFile(path.join(root,p),'utf8'));
const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const save=async(p,v)=>{await fs.mkdir(path.dirname(p),{recursive:true});await fs.writeFile(p,JSON.stringify(v,null,2)+'\n');};
const runId=process.argv[2]||'confirmation-v1';
if(!/^[a-z0-9-]{1,60}$/.test(runId))throw Error('INVALID_RUN_ID');
const out=path.join(root,'runs',runId);
try{await fs.access(out);throw Error('Run exists; use a new replication ID.');}catch(e){if(e.code!=='ENOENT')throw e;}
const freeze=await json('input-freeze.json'),inventory=await json('task-inventory.json');
if(sha(await fs.readFile(path.join(root,'protocol.json')))!==freeze.protocol_sha256)throw Error('PROTOCOL_CHANGED');
if(sha(await fs.readFile(path.join(root,'task-inventory.json')))!==freeze.inventory_sha256)throw Error('INVENTORY_CHANGED');
for(const input of freeze.inputs)if(sha(await fs.readFile(path.join(root,input.path)))!==input.sha256)throw Error('INPUT_CHANGED_'+input.id);
const vendor=await json('vendor/manifest.json');for(const f of vendor.files)if(sha(await fs.readFile(path.join(root,'vendor/alpha',f.path)))!==f.sha256)throw Error('VENDOR_CHANGED_'+f.path);
const sourceFiles=['adapters.mjs','run.mjs',...vendor.files.map(f=>'vendor/alpha/'+f.path)],sources=[];
for(const name of sourceFiles)sources.push({path:name,sha256:sha(await fs.readFile(path.join(root,name)))});
const sourceHash=sha(JSON.stringify(sources));
await fs.mkdir(out,{recursive:true});
await save(path.join(out,'code-freeze.json'),{sourceHash,files:sources,frozen_at_utc:new Date().toISOString(),input_freeze_sha256:sha(await fs.readFile(path.join(root,'input-freeze.json')))});
const wb=createWorkbench([quoteAdapter,briefAdapter,planningAdapter]),records=[];
const batchCpu=process.cpuUsage(),batchStart=performance.now();
for(const task of inventory){
  const raw=await json(task.path),spec=structuredClone(raw),preparation=[];
  if(spec.family==='awe-brief'){for(const f of spec.inputs.facts)f.value=String(f.value);preparation.push('Numeric source values serialized as exact decimal text for upstream integer-only canonical transport; original JSON preserved.');}
  const dir=path.join(out,task.id);await fs.mkdir(dir,{recursive:true});
  const start=performance.now(),cpu=process.cpuUsage(),phases=[];let checkpoints=0,pack=null,error=null;
  try{pack=await wb.run(spec,{sourceHash,onProgress:p=>phases.push(p),onCheckpoint:async()=>{checkpoints++;}});await wb.inspectPack(pack);await save(path.join(dir,'pack.json'),pack);for(const a of pack.result.artifacts)await fs.writeFile(path.join(dir,a.name),a.content);}
  catch(e){error=e.message;await save(path.join(dir,'failure.json'),{error,input_hash:task.sha256,recovery:'Correct missing/invalid input and create a fresh mission; no automatic assumption or permission expansion.'});}
  const used=process.cpuUsage(cpu);const record={study_id:'AWE-2026-01',run_id:runId,task_id:task.id,family:task.family,expected:task.expected,expected_reason:task.expected_reason,input_sha256:task.sha256,started_at_utc:new Date(Date.now()-(performance.now()-start)).toISOString(),elapsed_ms:performance.now()-start,cpu_user_us:used.user,cpu_system_us:used.system,checkpoints,phases,preparation,output_decision:pack?.result.decision||'REFUSED',error,artifact_count:pack?.result.artifacts.length||0,artifact_bytes:pack?pack.result.artifacts.reduce((n,a)=>n+Buffer.byteLength(a.content),0):0,integrity_digest:pack?.integrityDigest||null,provider_calls:0,provider_tokens:0,settlement_calls:0,measured_run_human_interventions:0,authoring_human_minutes:null,authoring_model_tokens:null,production_human_minutes:null,local_compute_cost_usd:null,independent_acceptance:'PENDING',full_authenticated_workflow:'NOT_RUN'};
  records.push(record);await fs.appendFile(path.join(out,'raw.jsonl'),JSON.stringify(record)+'\n');
}
const used=process.cpuUsage(batchCpu);await save(path.join(out,'execution-summary.json'),{study_id:'AWE-2026-01',run_id:runId,tasks:records.length,elapsed_ms:performance.now()-batchStart,cpu_user_us:used.user,cpu_system_us:used.system,artifact_bytes:records.reduce((s,r)=>s+r.artifact_bytes,0),sourceHash,protocol_sha256:freeze.protocol_sha256,environment:{node:process.version,platform:process.platform,architecture:process.arch},provider_calls:0,settlement_calls:0,authenticated_executor:'NOT_RUN',human_minutes:null,compute_cost_usd:null,authoring_cost_usd:null});
const dev=await json('inputs/development-quote.json'),devN=normalizeQuotes(dev.inputs),base=enumerationSolve(devN),retained=subsetSolve(devN);let sequence=[];
sequence.push({stage:'development',input:'inputs/development-quote.json',incumbent:base,retained,agreement:base.total_minor===retained.total_minor});
for(const id of ['Q1','Q2','Q4']){const s=await json('inputs/'+id+'.json'),n=normalizeQuotes(s.inputs);sequence.push({stage:id==='Q1'?'fresh-reuse':id==='Q2'?'changed-pack-currency-requirement':'larger-enabling-input',task_id:id,installed_v1:enumerationSolve(n),successor_v2:subsetSolve(n)});}
await save(path.join(out,'capability-sequence.json'),{capability_id:'awe-quote-normalization-and-fixed-shipping-v2',sequence,method_origin:'Conventional exact combinatorial optimization; study implementation, not a novel optimization algorithm.',promotion:'SCOPE_VALIDATION_PENDING; economic production promotion HOLD',strong_incumbent:'Independent SciPy MILP retained for paired verification; not superseded by construction.',construction_model_tokens:null,construction_human_minutes:null,upkeep_cost_usd:null,automated_discovery:'NOT_RUN',enabling_claim:'Only relative to installed exhaustive v1 and its 50,000-combination policy; not beyond a conventional MILP solver.'});
console.log(JSON.stringify({run_id:runId,tasks:records.length,outputs:out,sourceHash}));
