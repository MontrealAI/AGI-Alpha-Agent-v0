# AWE-2026-01 — Executable bounded-work companion

**AGI ALPHA FLYWHEEL · The Autonomous Work Economy**

This companion actually executes deterministic digital-work components through the existing AGI ALPHA SUCCESSOR Workbench. It produces reviewable artifacts, retains failures, constructs bounded executable capability capsules, and checks outcomes using separate Python logic and a conventional optimization solver.

The authenticated Harness/Fleet/model-provider enterprise route is **NOT RUN**. These results do not establish a complete autonomous enterprise, open-ended agent research, real customer payments, self-financing, or self-acceleration. A deterministic artifact workflow is not a substitute for those missing tests.

## What was executed

The prospectively frozen structural inventory contains 24 cases: six each for quotes, evidence briefs, operational planning and software maintenance. Each family has four declared supported cases and two deliberately unsupported or invalid cases. This is a small engineering census; cases share templates, are authored by the study team, and are not a representative sample of jobs or occupations.

| Workflow | Useful local deliveries | Expected refusals | What the output contains |
|---|---:|---:|---|
| Quote comparison | 4 | 2 | Complete fixed-shipping baskets, explicit pack/currency normalization, deadline checks, Markdown recommendation, CSV and audit JSON |
| Source-register evidence briefs | 4 | 2 | Cited occupation facts, source periods/coverage and limits; no new open-web search or model synthesis |
| Operational plans | 4 | 2 | Feasible dependency/resource schedule, Markdown instructions, CSV and evidence JSON |
| Finite software maintenance | 4 | 2 | Existing native Alpha range repair/retention or SDK-example correction, originals, checkable patch/examples and evidence |
| **Total** | **16** | **8** | **Zero unexpected confirmation failures** |

Safe refusals are reported separately and do not count as useful deliveries. All 24 cases remain in `runs/confirmation-v1/raw.jsonl`; the later `acceptance.json` is the authoritative independent-algorithm assessment. The raw file preserves its original `PENDING` acceptance field rather than rewriting history.

The flagship Q2 basket includes six requested items and 24 offers from four synthetic suppliers. It selects a **520.12 USD** cart including **26.22 USD** of shipping. Synthetic currency ratios and prices make this a reproducible example, not a live procurement recommendation or observed saving. Q4 selects a **2,635.90 USD** fourteen-item basket. Both totals match an independently implemented SciPy HiGHS mixed-integer program.

## Reproduce

Requirements: Node.js 22+ with Web Crypto, Python 3.11–3.13, NumPy and SciPy. The recorded environment was Node 24.22.1 and Python 3.12.14 on Linux x64. Exact numerical dependency versions are in `requirements.txt`. Dependencies must already be available or be installed separately; reproduction itself makes no model-provider, blockchain or external service calls.

```bash
python3 run.py --run-id replication-01
```

This invokes the actual Workbench, writes a fresh run directory, independently verifies every case, audits twelve intentional semantic faults, and compares the quote solver with the retained conventional MILP. It refuses to overwrite an existing run. Exact optimum/acceptance results should agree; wall times, CPU usage, execution timestamps and integrity identities can vary.

Read the original evidence in `runs/confirmation-v1/`. Do not regenerate or overwrite `inputs/`, `input-freeze.json` or `protocol.json`. `prepare.py` documents how the original synthetic cases were made and refuses to replace frozen inputs. Any changed task design needs a separate version and amendment.

## Foundation actually used

The vendored source closure comes from:

- Repository: https://github.com/MontrealAI/AGI-Alpha-Agent-v0
- Commit: `a026e68413ab2e2d6086c758efc8abff723fdfe4`
- Entry point: `examples/successor-workbench/engine.mjs`
- API: `createWorkbench`, `plan`, `run`, `inspectPack`

Seven JavaScript modules and the original Apache 2.0 license are preserved under `vendor/alpha/`; SHA256 identities are in `vendor/manifest.json`. Source retrieval was separately checked against Git blob identities by the foundations audit. The three new adapters use the upstream extension seam. Software maintenance invokes the native `reliability` and `documentation` handlers. No upstream runtime source was modified.

The existing Workbench compiles its native job plan, binds mission and source identities, checkpoints execution, packages artifacts, and checks pack integrity. It correctly records `PUBLIC_LOCAL_EXECUTION`, `independentProof: false`, `admission: HOLD`, `model: null`, `provider: null`, and `settlement: NOT_CONNECTED`. A plan compilation does not mean the seven conceptual role jobs independently executed as model agents.

The upstream canonical transport allows integer numbers only. During preparation, source wage numbers are represented as exact decimal strings; the untouched original input JSON remains frozen. This transport conversion is recorded per brief and changes no factual value.

## Scope and acceptance

Quotes support at most 18 items, 12 vendors and 160 offers. Each item selects one offer, packs are rounded up, rational supplied exchange rates are rounded half-up once per line into integer target minor units, and fixed shipping is charged once for each used supplier. No inventory inference, quality ranking, taxes, discounts, partial splits or purchasing action is implemented.

Evidence briefs transform a verified source register into a structured report. Offline checking verifies source identity fields, source presence and exact factual preservation. It does not independently re-fetch the source during each run, assess original prose quality, or demonstrate autonomous open-ended research. The BLS source register is public; employment is a count, not currency. Wage observations do not establish duration, worker AI usage or equivalent deliverable quality.

Plans use a deterministic list scheduler. Inputs contain assumed durations and single-capacity resources. Acceptance checks task coverage, every predecessor edge, time arithmetic, resource collisions and the deadline. A feasible schedule is not a proof of global scheduling optimality. A deadline refusal means the declared policy could not satisfy it, not that every possible schedule is infeasible.

Software tasks are constrained to the existing finite interval-function grammar and named URI/UTF-8 example operations. Arbitrary repository repair and host-code execution are unsupported. The original failures and originals are retained. This evidence must not be generalized to software engineering occupations.

## Verification and reviewer independence

`verify.py` uses separately implemented Python normalization and acceptance checks. The quote incumbent is SciPy HiGHS MILP with the identical objective and constraints. Four quote cases are each checked once for acceptance and then in nine paired repetitions after warm-up. Alternate method order is recorded. The specialized subset solver is faster in these small cases; this excludes process startup, engineering, maintenance and Workbench packaging and does not prove lower total cost.

Twelve known injected semantic faults were all detected, with no false alarm on the sixteen unmodified supported cases. The injection set is deliberately constructed and small; it does not estimate production defect recall or completeness. Independent-algorithm checking by the same team is not blinded external review. The parent publication audit separately inspects arithmetic, sources and selected artifacts.

`control-checks.json` records five actual upstream checks: stop cancellation, recovery using a fresh invocation, export/import integrity, rejection of a tampered export, and rejection of a disallowed input classification. Imported history remains unauthenticated and conveys no active authority.

## Executable capability sequence

`capabilities/protocol.json` freezes a separate, additive bounded construction experiment. It leaves the original 24-case confirmation unchanged.

1. Emit and invoke `quote-v1.mjs` from a fixed audited capsule template on a development cart.
2. Actually reuse that executable capsule on fresh Q1 input.
3. Construct and reject `rejected-greedy.mjs`: independently choosing the cheapest line costs 22.00 on the shipping regression, while a valid cart costs 13.00. Preserve this failure as a regression fixture.
4. Apply Q2's changed pack/currency requirement. The v1 capsule explicitly refuses its scope.
5. Emit `quote-v2.mjs` by composing the already-authored exact normalizer and vendor-subset specialist using an allowlisted template.
6. Execute the new capsule on Q2 and Q4, then verify the results independently against MILP.

This is actual bounded executable composition, retention and reuse. It is **not** observed autonomous algorithm discovery. The original specialist kernels were authored with assistant assistance and supplied as external resources; their creation cost was not metered. Template-emission milliseconds cannot be substituted for total capability construction cost. A conventional MILP can solve the larger case too, so enabling is only relative to the initial installed workflow and its constraints, not beyond conventional methods. Economic production promotion remains **HOLD** and the strongest incumbent is retained.

The source hashes, applicability conditions, rejection evidence, verification and rollback are in `capabilities/manifest.json`, `events.json` and `independent-audit.json`. `capability-sequence.mjs` refuses to overwrite existing capability evidence; rerun it only in a separate copied workspace with a distinct protocol identity if changing the sequence.

## Costs and human involvement

The observed main batch produced 111,669 artifact bytes in approximately 626.53 ms of batch wall time in this environment. The batch made zero provider calls and zero settlement calls. These are facts about this local run, not a complete cost for an automated digital worker.

`measures.json` separates per-family wall time, artifact volume and acceptance. Host economics, assistant authoring/model tokens, input preparation, research engineering, user acceptance and production exception handling are unknown (`null`), not zero. No human intervention occurred *inside the single automated batch*; humans still select the mission, supply permitted inputs, and decide whether the deliverable serves their needs.

The native `reviewMinutes: 1` is a required unfunded capacity field. It is neither one measured minute of labor nor a charge. Model-based preparation/research/correction and production exceptions need separate measured execution or clearly labeled economic scenarios. No collected revenue, real customer payments, treasury transfer or reinvestment occurred.

## Browser integration

A browser demo can import `createWorkbench` from the vendored entry point and the three adapters from `adapters.mjs`, then execute the included Q2 specification using the source hash recorded in `runs/confirmation-v1/code-freeze.json`. Use a real `AbortController`, show the resulting artifacts and cost unknowns, and preserve an export/import path through `inspectPack`. Render untrusted labels as text, impose upload limits and call the runtime's bounded parser before accepting imports. The actual output is fresh deterministic computation; any chart of hypothetical economic conditions must be separately labeled simulation.

## License

Original study code is Apache 2.0. Upstream source license notices are retained. BLS figures are sourced US federal statistical data. No private research lead or motivational attribution is included in this companion.
