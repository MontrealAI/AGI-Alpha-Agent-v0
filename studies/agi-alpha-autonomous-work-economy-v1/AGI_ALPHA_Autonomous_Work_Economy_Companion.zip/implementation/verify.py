# SPDX-License-Identifier: Apache-2.0
import json, math, re, time, sys, hashlib, subprocess, copy, statistics, platform
from pathlib import Path
from fractions import Fraction
from urllib.parse import quote, unquote_to_bytes
import numpy as np
from scipy.optimize import milp, LinearConstraint, Bounds
import scipy
ROOT=Path(__file__).resolve().parent

def read(p): return json.loads(p.read_text())
def write(p,v): p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def require(condition,message):
    if not condition: raise ValueError(message)

def norm(input):
    items={i['id']:i for i in input['items']};offers=[]
    for idx,o in enumerate(input['offers']):
        if o['lead_days']>input['deadline_days']:continue
        rate=input['fx'][o['currency']];packs=-(-items[o['item']]['quantity']//o['pack_units'])
        exact=Fraction(packs*o['pack_price_minor']*rate['num'],rate['den'])
        cost=math.floor(exact+Fraction(1,2))
        offers.append({'index':idx,'item':o['item'],'vendor':o['vendor'],'cost':cost,'packs':packs,'units':packs*o['pack_units']})
    return items,offers

def incumbent(input):
    items,offers=norm(input);vendors=sorted(input['shipping_minor']);n=len(offers);m=len(vendors)
    costs=[o['cost'] for o in offers]+[input['shipping_minor'][v] for v in vendors]
    rows=[];lo=[];hi=[]
    for item in items:
        rows.append([1 if o['item']==item else 0 for o in offers]+[0]*m);lo.append(1);hi.append(1)
    for k,o in enumerate(offers):
        row=[0]*(n+m);row[k]=1;row[n+vendors.index(o['vendor'])]=-1;rows.append(row);lo.append(-np.inf);hi.append(0)
    result=milp(np.array(costs,dtype=float),integrality=np.ones(n+m),bounds=Bounds(np.zeros(n+m),np.ones(n+m)),constraints=LinearConstraint(np.array(rows),np.array(lo),np.array(hi)),options={'time_limit':10,'mip_rel_gap':0})
    require(result.success,'MILP did not establish an optimum')
    value=int(round(result.fun));require(abs(result.fun-value)<1e-5,'Noninteger objective')
    return {'total_minor':value,'solver':'SciPy HiGHS MILP','status':int(result.status),'mip_gap':float(result.mip_gap),'nodes':int(result.mip_node_count)}

def artifacts(pack):return {a['name']:a['content'] for a in pack['result']['artifacts']}
def verify_quote(spec,pack):
    a=artifacts(pack);data=json.loads(a['quote-analysis.json']);s=data['solution'];inp=spec['inputs'];items,offers=norm(inp);byidx={o['index']:o for o in offers}
    require(len(s['selected'])==len(items),'Wrong item count');require({r['item'] for r in s['selected']}==set(items),'Missing/duplicate item')
    total=0;vendors=set()
    for row in s['selected']:
        o=byidx[row['index']];require(o['item']==row['item'] and o['vendor']==row['vendor'],'Wrong source offer');require(row['quantity']==items[o['item']]['quantity'],'Quantity changed');require(row['landed_line_minor']==o['cost'],'Currency/pack arithmetic');require(row['delivered_units']==o['units'] and o['units']>=row['quantity'],'Delivered units');require(row['packs']==o['packs'],'Pack count');total+=o['cost'];vendors.add(o['vendor'])
    ship=sum(inp['shipping_minor'][v] for v in vendors);require(total==s['line_total_minor'] and ship==s['shipping_minor'] and total+ship==s['total_minor'],'Landed total mismatch')
    baseline=incumbent(inp);require(baseline['total_minor']==s['total_minor'],'Not optimum against conventional MILP')
    require(f'{s["total_minor"]/100:.2f}' in a['quote-report.md'],'Report amount missing')
    return baseline

def verify_brief(spec,pack):
    a=artifacts(pack);facts=json.loads(a['source-register.json']);orig=spec['inputs'];byid={f['id']:f for f in orig['facts']};require([f['id'] for f in facts]==orig['questions'],'Requested evidence missing')
    for f in facts:
        expected=copy.deepcopy(byid[f['id']]);expected['value']=str(expected['value']);require(f==expected,'Source record altered');require(f['source_url'] in a['evidence-brief.md'],'Citation omitted');require(f['occupation'] in a['evidence-brief.md'],'Occupation omitted');require(f['source_year'] in a['evidence-brief.md'],'Source period omitted')
    require('do not establish task duration' in a['evidence-brief.md'],'Duration limitation omitted')
    return {'source_records':len(facts),'arithmetic':'No ungrounded wage-to-duration conversion'}

def verify_plan(spec,pack):
    a=artifacts(pack);data=json.loads(a['schedule-analysis.json']);rows=data['schedule'];input=spec['inputs'];source={t['id']:t for t in input['tasks']};byid={r['id']:r for r in rows}
    require(len(rows)==len(source) and set(byid)==set(source),'Schedule coverage')
    for r in rows:
        t=source[r['id']];require(r['duration_minutes']==t['duration_minutes'] and r['resource']==t['resource'] and r['deps']==t['deps'],'Task contract altered');require(r['start']>=0 and r['finish']-r['start']==t['duration_minutes'],'Duration arithmetic')
        for d in t['deps']:require(byid[d]['finish']<=r['start'],'Precedence violated')
    for i,r in enumerate(rows):
        for q in rows[i+1:]:require(r['resource']!=q['resource'] or r['finish']<=q['start'] or q['finish']<=r['start'],'Resource overlap')
    require(max(r['finish'] for r in rows)<=input['deadline_minutes'],'Deadline exceeded')
    return {'feasible':True,'optimality':'NOT_CLAIMED'}

def verify_software(spec,pack):
    a=artifacts(pack);inp=spec['inputs']
    if spec['family']=='reliability':
        src=a['contains.mjs'];m=re.fullmatch(r'\s*export function contains\(value, low, high\) \{ return low (<=|<) value && value (<=|<) high; \}\s*',src);require(m is not None,'Repair outside finite grammar')
        for value in range(inp['low']-2,inp['high']+3):
            actual=(inp['low']<=value if m[1]=='<=' else inp['low']<value) and (value<=inp['high'] if m[2]=='<=' else value<inp['high']);require(actual==(inp['low']<=value<=inp['high']),'Boundary defect retained')
        require(a['original.mjs'].strip()==inp['source'].strip(),'Original source not preserved')
        require('check.mjs' in a and 'repair.patch' in a,'Incomplete maintenance package')
        return {'independent_values_checked':inp['high']-inp['low']+5}
    blocks=re.findall(r'```successor-example\s*\n([\s\S]*?)\n```',a['checked-examples.md']);require(len(blocks)>0,'No examples')
    for b in blocks:
        row=json.loads(b);s=row['input']
        if row['operation']=='url-encode':expected=quote(s,safe="~()*!.'")
        elif row['operation']=='url-decode':require(re.search(r'%(?![0-9a-fA-F]{2})',s) is None,'Malformed URI');expected=unquote_to_bytes(s).decode('utf-8')
        else:expected=str(len(s.encode('utf-8')))
        require(row['expected']==expected,'Incorrect documented example')
    require(a['original-examples.md']==inp['markdown'],'Original examples not preserved')
    return {'independent_examples_checked':len(blocks)}

def verifier(task):return verify_quote if task['family']=='quotes' else verify_brief if task['family']=='brief' else verify_plan if task['family']=='planning' else verify_software

def changed_artifact(pack,name,change):
    p=copy.deepcopy(pack)
    for a in p['result']['artifacts']:
        if a['name']==name:a['content']=change(a['content'])
    return p

def main():
    runid=sys.argv[1] if len(sys.argv)>1 else 'confirmation-v1';out=ROOT/'runs'/runid
    if (out/'acceptance.json').exists():raise SystemExit('Acceptance record already exists; preserve it.')
    inventory=read(ROOT/'task-inventory.json');raw=[json.loads(s) for s in (out/'raw.jsonl').read_text().splitlines()];byid={r['task_id']:r for r in raw};records=[];valid=[]
    start=time.perf_counter();cpu=time.process_time()
    for task in inventory:
        spec=read(ROOT/task['path']);r=byid[task['id']];pack=read(out/task['id']/'pack.json') if (out/task['id']/'pack.json').exists() else None
        try:
            if task['expected']=='explicit-refusal':
                errors=[r['error'] or '']
                if pack:errors+=[c.get('error') or '' for c in pack['result']['evidence'].get('checks',[]) if isinstance(c,dict)]
                require(any(task['expected_reason'] in e for e in errors),'Expected refusal reason not observed')
                records.append({'task_id':task['id'],'outcome':'EXPECTED_REFUSAL','delivered':False,'reason':next(e for e in errors if task['expected_reason'] in e)})
            else:
                require(pack is not None,'No delivered pack: '+str(r['error']));check=verifier(task)(spec,pack);records.append({'task_id':task['id'],'outcome':'ACCEPTED_LOCAL_CONTRACT','delivered':True,'check':check});valid.append((task,spec,pack))
        except Exception as e:records.append({'task_id':task['id'],'outcome':'UNEXPECTED_FAILURE','delivered':False,'reason':str(e)})
    write(out/'acceptance.json',{'study_id':'AWE-2026-01','run_id':runid,'records':records,'accepted':sum(r['delivered'] for r in records),'expected_refusals':sum(r['outcome']=='EXPECTED_REFUSAL' for r in records),'unexpected_failures':sum(r['outcome']=='UNEXPECTED_FAILURE' for r in records),'verifier_seconds':time.perf_counter()-start,'verifier_cpu_seconds':time.process_time()-cpu,'independence':'Separate Python checks and HiGHS solver, same study team; not blinded external review.','scipy_version':scipy.__version__,'python_version':platform.python_version()})
    def mutate_json(text,fn):
        obj=json.loads(text);fn(obj);return json.dumps(obj)
    challenges=[];cstart=time.perf_counter()
    chosen={t['id']:(t,s,p) for t,s,p in valid}
    for id,filename,change,name in [
        ('Q2','quote-analysis.json',lambda t:mutate_json(t,lambda d:d['solution'].__setitem__('total_minor',d['solution']['total_minor']+1)),'one-cent-total'),
        ('Q2','quote-analysis.json',lambda t:mutate_json(t,lambda d:d['solution']['selected'][0].__setitem__('delivered_units',0)),'short-delivery'),
        ('Q2','quote-analysis.json',lambda t:mutate_json(t,lambda d:d['solution']['selected'][0].__setitem__('landed_line_minor',0)),'missing-line-cost'),
        ('B3','source-register.json',lambda t:mutate_json(t,lambda d:d.pop()),'omitted-source-record'),
        ('B3','source-register.json',lambda t:mutate_json(t,lambda d:d[0].__setitem__('value','1')),'altered-source-value'),
        ('B3','source-register.json',lambda t:mutate_json(t,lambda d:d[0].__setitem__('source_url','https://example.invalid')),'wrong-source-url'),
        ('P4','schedule-analysis.json',lambda t:mutate_json(t,lambda d:d['schedule'][2].__setitem__('start',0)),'precedence-damage'),
        ('P4','schedule-analysis.json',lambda t:mutate_json(t,lambda d:d['schedule'].pop()),'omitted-task'),
        ('P4','schedule-analysis.json',lambda t:mutate_json(t,lambda d:d['schedule'][0].__setitem__('finish',9999)),'duration-damage'),
        ('S1','contains.mjs',lambda t:t.replace('low <= value','low < value'),'lower-boundary'),
        ('S1','contains.mjs',lambda t:t.replace('value <= high','value < high'),'upper-boundary'),
        ('S3','checked-examples.md',lambda t:t.replace('release%20notes%20%26%20evidence','wrong'),'wrong-uri-example')]:
        if id not in chosen:continue
        task,spec,pack=chosen[id];damaged=changed_artifact(pack,filename,change);detected=False;reason=None
        try:verifier(task)(spec,damaged)
        except Exception as e:detected=True;reason=str(e)
        challenges.append({'task_id':id,'injected_defect':name,'detected':detected,'reason':reason,'integrity_check_deliberately_bypassed':'Semantic challenge test; production inspectPack also rejects tampering independently.'})
    write(out/'challenge-audit.json',{'challenges':challenges,'detected':sum(c['detected'] for c in challenges),'missed':sum(not c['detected'] for c in challenges),'false_alarms_on_unmodified_supported_cases':sum(r['outcome']=='UNEXPECTED_FAILURE' for r in records if next(t for t in inventory if t['id']==r['task_id'])['expected']=='supported-delivery'),'seconds':time.perf_counter()-cstart,'limits':'Twelve intentional, known fault injections assess these checks only; no statistical claim about unknown defects or production review recall.'})
    bridge=subprocess.Popen(['node',str(ROOT/'solver-bridge.mjs')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True);timings=[]
    def candidate(inp):
        bridge.stdin.write(json.dumps(inp)+'\n');bridge.stdin.flush();result=json.loads(bridge.stdout.readline());require('error' not in result,'Candidate error');return result
    for id in ['Q1','Q2','Q3','Q4']:
        inp=read(ROOT/'inputs'/f'{id}.json')['inputs'];candidate(inp);incumbent(inp)
        for repeat in range(9):
            result={}
            for name in (['candidate','incumbent'] if repeat%2==0 else ['incumbent','candidate']):
                if name=='candidate':v=candidate(inp)
                else:
                    t=time.perf_counter();v=incumbent(inp);v['elapsed_ms']=(time.perf_counter()-t)*1000
                result[name]=v
            require(result['candidate']['total_minor']==result['incumbent']['total_minor'],'Paired optimum mismatch');timings.append({'task_id':id,'repeat':repeat,'order':'candidate-first' if repeat%2==0 else 'incumbent-first',**result})
    bridge.stdin.close();bridge.wait(timeout=5)
    summaries=[]
    for id in ['Q1','Q2','Q3','Q4']:
        values=[r for r in timings if r['task_id']==id];summaries.append({'task_id':id,'candidate_median_ms':statistics.median(r['candidate']['elapsed_ms'] for r in values),'incumbent_median_ms':statistics.median(r['incumbent']['elapsed_ms'] for r in values),'paired_agreement':all(r['candidate']['total_minor']==r['incumbent']['total_minor'] for r in values)})
    write(out/'specialist-comparison.json',{'repetitions_per_case':9,'warmup_calls_per_method_per_case':1,'timing_scope':'In-process normalization + solver only; node IPC excluded; cold process startup and workbench packaging not included. Alternating method order.','samples':timings,'summary':summaries,'limits':'Four synthetic cases, same host/session, candidate bounded to <=12 vendors; no general speed ranking or total-cost superiority. MILP remains the conventional fallback.'})
    print(json.dumps({'accepted':sum(r['delivered'] for r in records),'refusals':sum(r['outcome']=='EXPECTED_REFUSAL' for r in records),'unexpected':sum(r['outcome']=='UNEXPECTED_FAILURE' for r in records),'challenge_detected':sum(c['detected'] for c in challenges),'challenge_count':len(challenges),'specialist_medians':summaries}))
if __name__=='__main__':main()
