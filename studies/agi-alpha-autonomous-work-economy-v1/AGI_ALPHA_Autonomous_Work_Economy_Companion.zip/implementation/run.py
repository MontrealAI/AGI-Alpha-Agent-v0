# SPDX-License-Identifier: Apache-2.0
import argparse, datetime, json, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description='Reproduce AWE-2026-01 bounded local confirmation without overwriting frozen evidence.')
parser.add_argument('--run-id',default='replication-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S').lower())
args=parser.parse_args()
if not (ROOT/'input-freeze.json').exists():raise SystemExit('The distributed frozen inputs are required; do not regenerate confirmation inputs.')
for command in [['node',str(ROOT/'run.mjs'),args.run_id],[sys.executable,str(ROOT/'verify.py'),args.run_id]]:
    subprocess.run(command,cwd=ROOT,check=True)
print(json.dumps({'run_id':args.run_id,'evidence':str(ROOT/'runs'/args.run_id),'reference':'runs/confirmation-v1','claim':'Compare acceptance and exact outputs; timings and integrity identities include fresh execution timestamps and vary.'}))
