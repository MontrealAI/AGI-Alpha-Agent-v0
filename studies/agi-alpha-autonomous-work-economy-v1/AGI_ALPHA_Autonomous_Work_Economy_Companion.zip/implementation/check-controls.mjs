// SPDX-License-Identifier: Apache-2.0
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createWorkbench} from './vendor/alpha/examples/successor-workbench/engine.mjs';
import {quoteAdapter,briefAdapter,planningAdapter} from './adapters.mjs';
const root=path.dirname(fileURLToPath(import.meta.url)),read=async p=>JSON.parse(await fs.readFile(path.join(root,p),'utf8'));
const spec=await read('inputs/Q1.json'),sourceHash=(await read('runs/confirmation-v1/code-freeze.json')).sourceHash,wb=createWorkbench([quoteAdapter,briefAdapter,planningAdapter]);
const checks=[];const controller=new AbortController();controller.abort();
try{await wb.run(spec,{sourceHash,signal:controller.signal});checks.push({name:'stop',passed:false});}catch(e){checks.push({name:'stop',passed:e.message==='CANCELLED',observed:e.message});}
const pack=await wb.run(spec,{sourceHash});checks.push({name:'recover_with_fresh_mission',passed:pack.result.summary.items===4,missionDigest:pack.frozen.missionDigest});
const imported=await wb.inspectPack(JSON.parse(JSON.stringify(pack)));checks.push({name:'export_import_integrity',passed:imported.authentication==='UNAUTHENTICATED_HISTORICAL_IMPORT'&&imported.activeAuthority.length===0,authentication:imported.authentication});
const corrupt=JSON.parse(JSON.stringify(pack));corrupt.result.artifacts[0].content+='tampered';
try{await wb.inspectPack(corrupt);checks.push({name:'reject_tampered_export',passed:false});}catch(e){checks.push({name:'reject_tampered_export',passed:e.message==='PACK_INTEGRITY',observed:e.message});}
const privateSpec=JSON.parse(JSON.stringify(spec));privateSpec.rights.dataClass='private';
try{wb.validate(privateSpec);checks.push({name:'input_permission_boundary',passed:false});}catch(e){checks.push({name:'input_permission_boundary',passed:e.message==='INPUT_RIGHTS',observed:e.message});}
const result={executed_at_utc:new Date().toISOString(),checks,passed:checks.filter(c=>c.passed).length,total:checks.length,scope:'Actual pinned Alpha local Workbench stop/recovery/export integrity and input policy; not authenticated execution or cryptographic identity.'};
await fs.writeFile(path.join(root,'control-checks.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result));if(checks.some(c=>!c.passed))process.exitCode=1;
