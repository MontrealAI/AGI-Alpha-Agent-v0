# Public example: complete equipment quote comparison

## Decision-ready quote comparison

Recommended eligible cart: **2635.90 USD**, including 53.92 USD of fixed supplier shipping. No purchase was made.

| Item | Supplier | Required units | Delivered units | Packs | Line cost | Delivery days |
|---|---|---:|---:|---:|---:|---:|
| Monitor | Delta | 15 | 15 | 3 | 462.99 USD | 1 |
| Dock | Aster | 11 | 12 | 6 | 189.24 USD | 4 |
| Keyboard | Aster | 12 | 15 | 3 | 131.94 USD | 2 |
| Desk lamp | Delta | 5 | 6 | 3 | 352.47 USD | 2 |
| USB hub | Boreal | 9 | 10 | 2 | 257.51 USD | 4 |
| Cable pack | Boreal | 3 | 5 | 1 | 46.93 USD | 2 |
| Webcam | Aster | 10 | 10 | 10 | 435.60 USD | 4 |
| Headset | Aster | 5 | 5 | 1 | 13.79 USD | 3 |
| Stand | Aster | 6 | 10 | 2 | 236.62 USD | 1 |
| Adapter | Cedar | 12 | 12 | 6 | 196.80 USD | 4 |
| Network switch | Aster | 3 | 3 | 3 | 104.22 USD | 4 |
| Storage drive | Boreal | 3 | 5 | 1 | 25.06 USD | 2 |
| Microphone | Delta | 5 | 5 | 1 | 76.83 USD | 3 |
| Router | Aster | 4 | 4 | 2 | 51.98 USD | 1 |

## Verification and limits

All quantities, the delivery deadline and exact integer-currency totals pass the declared contract. The optimizer enumerates 15 supplier subsets. 0 late offers were excluded.

Prices, supplier names and exchange ratios in the included example are synthetic. For your own permitted quotes, the result is conditional on complete input prices, declared rates and fixed shipping. Taxes, uncertain inventory, quality differences, discounts and split-item purchases are outside this contract.
