# Public SDK guide

```successor-example
{"operation":"url-encode","input":"release notes & evidence","expected":"release+notes+%26+evidence"}
```

```successor-example
{"operation":"url-decode","input":"caf%C3%A9%20guide","expected":"café guide"}
```
