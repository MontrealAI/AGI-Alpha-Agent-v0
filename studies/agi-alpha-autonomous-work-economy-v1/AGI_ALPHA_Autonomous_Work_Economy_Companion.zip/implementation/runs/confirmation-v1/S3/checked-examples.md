# Public SDK guide

```successor-example
{"operation":"url-encode","input":"release notes & evidence","expected":"release%20notes%20%26%20evidence"}
```

```successor-example
{"operation":"url-decode","input":"caf%C3%A9%20guide","expected":"café guide"}
```
