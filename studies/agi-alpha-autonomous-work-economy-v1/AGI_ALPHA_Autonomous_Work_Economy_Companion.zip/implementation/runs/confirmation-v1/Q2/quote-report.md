# Public example: complete equipment quote comparison

## Decision-ready quote comparison

Recommended eligible cart: **520.12 USD**, including 26.22 USD of fixed supplier shipping. No purchase was made.

| Item | Supplier | Required units | Delivered units | Packs | Line cost | Delivery days |
|---|---|---:|---:|---:|---:|---:|
| Monitor | Delta | 11 | 15 | 3 | 102.72 USD | 3 |
| Dock | Delta | 2 | 5 | 1 | 38.58 USD | 1 |
| Keyboard | Delta | 13 | 15 | 3 | 101.97 USD | 3 |
| Desk lamp | Cedar | 2 | 5 | 1 | 55.68 USD | 1 |
| USB hub | Cedar | 7 | 10 | 2 | 88.45 USD | 4 |
| Cable pack | Aster | 10 | 10 | 2 | 106.50 USD | 1 |

## Verification and limits

All quantities, the delivery deadline and exact integer-currency totals pass the declared contract. The optimizer enumerates 15 supplier subsets. 0 late offers were excluded.

Prices, supplier names and exchange ratios in the included example are synthetic. For your own permitted quotes, the result is conditional on complete input prices, declared rates and fixed shipping. Taxes, uncertain inventory, quality differences, discounts and split-item purchases are outside this contract.
