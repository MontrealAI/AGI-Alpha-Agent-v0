# Invalid example

```successor-example
{"operation":"url-decode","input":"%E0%A4%A","expected":"ok"}
```
