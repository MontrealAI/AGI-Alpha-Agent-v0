# Public example: complete equipment quote comparison

## Decision-ready quote comparison

Recommended eligible cart: **1328.45 USD**, including 35.22 USD of fixed supplier shipping. No purchase was made.

| Item | Supplier | Required units | Delivered units | Packs | Line cost | Delivery days |
|---|---|---:|---:|---:|---:|---:|
| Monitor | Aster | 3 | 5 | 1 | 122.21 USD | 3 |
| Dock | Aster | 9 | 10 | 2 | 305.72 USD | 2 |
| Keyboard | Cedar | 15 | 15 | 3 | 175.96 USD | 4 |
| Desk lamp | Aster | 3 | 5 | 1 | 152.26 USD | 3 |
| USB hub | Aster | 5 | 5 | 5 | 130.60 USD | 6 |
| Cable pack | Boreal | 6 | 10 | 2 | 79.31 USD | 3 |
| Webcam | Boreal | 4 | 5 | 1 | 94.76 USD | 4 |
| Headset | Delta | 12 | 15 | 3 | 232.41 USD | 2 |

## Verification and limits

All quantities, the delivery deadline and exact integer-currency totals pass the declared contract. The optimizer enumerates 15 supplier subsets. 10 late offers were excluded.

Prices, supplier names and exchange ratios in the included example are synthetic. For your own permitted quotes, the result is conditional on complete input prices, declared rates and fixed shipping. Taxes, uncertain inventory, quality differences, discounts and split-item purchases are outside this contract.
