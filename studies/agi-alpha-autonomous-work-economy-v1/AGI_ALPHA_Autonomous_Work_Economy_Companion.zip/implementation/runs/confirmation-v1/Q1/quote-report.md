# Public example: complete equipment quote comparison

## Decision-ready quote comparison

Recommended eligible cart: **1425.09 USD**, including 15.96 USD of fixed supplier shipping. No purchase was made.

| Item | Supplier | Required units | Delivered units | Packs | Line cost | Delivery days |
|---|---|---:|---:|---:|---:|---:|
| Monitor | Boreal | 15 | 15 | 15 | 492.15 USD | 3 |
| Dock | Boreal | 11 | 11 | 11 | 107.69 USD | 4 |
| Keyboard | Boreal | 12 | 12 | 12 | 315.72 USD | 1 |
| Desk lamp | Boreal | 11 | 11 | 11 | 493.57 USD | 1 |

## Verification and limits

All quantities, the delivery deadline and exact integer-currency totals pass the declared contract. The optimizer enumerates 7 supplier subsets. 0 late offers were excluded.

Prices, supplier names and exchange ratios in the included example are synthetic. For your own permitted quotes, the result is conditional on complete input prices, declared rates and fixed shipping. Taxes, uncertain inventory, quality differences, discounts and split-item purchases are outside this contract.
