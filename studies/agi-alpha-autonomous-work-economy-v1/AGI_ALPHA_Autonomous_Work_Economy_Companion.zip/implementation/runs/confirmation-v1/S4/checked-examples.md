# Bilingual SDK guide

```successor-example
{"operation":"utf8-bytes","input":"café","expected":"5"}
```

```successor-example
{"operation":"utf8-bytes","input":"Ω ∞","expected":"6"}
```
