# Bilingual SDK guide

```successor-example
{"operation":"utf8-bytes","input":"café","expected":"4"}
```

```successor-example
{"operation":"utf8-bytes","input":"Ω ∞","expected":"3"}
```
