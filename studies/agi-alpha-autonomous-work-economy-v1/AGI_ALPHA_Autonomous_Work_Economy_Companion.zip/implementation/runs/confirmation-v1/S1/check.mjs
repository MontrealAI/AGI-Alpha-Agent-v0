// SPDX-License-Identifier: Apache-2.0
import assert from 'node:assert/strict';
import { contains } from './contains.mjs';
for (const c of [{"value":-26,"expected":false},{"value":-25,"expected":true},{"value":-24,"expected":true},{"value":0,"expected":true},{"value":37,"expected":true},{"value":38,"expected":true},{"value":39,"expected":false}]) assert.equal(contains(c.value, -25, 38), c.expected);
console.log('All 7 fixed contract checks passed');
