# Technical-writing labor reference

## Verified-input evidence brief

This briefing transforms a supplied, researched source register. It does not perform a new web search or model-authored synthesis.

| Occupation/group | Measure | Value | Source period | Source |
|---|---|---:|---|---|
| Technical writers | Mean hourly wage | 46.62 USD | May 2025 | [27-3042-mean-hourly](https://www.bls.gov/news.release/ocwage.t01.htm) |
| Technical writers | Employment | 45,500 people | May 2025 | [27-3042-employment](https://www.bls.gov/news.release/ocwage.t01.htm) |

## Interpretation

- Technical writers: Mean hourly wage is 46.62 USD for United States (May 2025). Coverage: Wage and salary employment; wages exclude employer benefits; no task duration or worker AI-use classification. [Source](https://www.bls.gov/news.release/ocwage.t01.htm).
- Technical writers: Employment is 45,500 people for United States (May 2025). Coverage: Wage and salary employment; wages exclude employer benefits; no task duration or worker AI-use classification. [Source](https://www.bls.gov/news.release/ocwage.t01.htm).

These sources describe labor-market compensation. They do not establish task duration, deliverable quality, a non-AI worker sample, attainable customer prices or realized savings. Mixing occupation-specific wages with broad occupational benefit groups requires an explicit allocation assumption.

## Source provenance

- 27-3042-mean-hourly: retrieved 2026-10-25; https://www.bls.gov/news.release/ocwage.t01.htm
- 27-3042-employment: retrieved 2026-10-25; https://www.bls.gov/news.release/ocwage.t01.htm
