// SPDX-License-Identifier: Apache-2.0
import assert from 'node:assert/strict';
import { contains } from './contains.mjs';
for (const c of [{"value":-101,"expected":false},{"value":-100,"expected":true},{"value":-99,"expected":true},{"value":0,"expected":true},{"value":99,"expected":true},{"value":100,"expected":true},{"value":101,"expected":false}]) assert.equal(contains(c.value, -100, 100), c.expected);
console.log('All 7 fixed contract checks passed');
