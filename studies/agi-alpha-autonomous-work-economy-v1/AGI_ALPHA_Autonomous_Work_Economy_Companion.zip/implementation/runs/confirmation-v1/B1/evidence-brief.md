# Software-delivery labor reference

## Verified-input evidence brief

This briefing transforms a supplied, researched source register. It does not perform a new web search or model-authored synthesis.

| Occupation/group | Measure | Value | Source period | Source |
|---|---|---:|---|---|
| Software developers | Mean hourly wage | 71.2 USD | May 2025 | [15-1252-mean-hourly](https://www.bls.gov/news.release/ocwage.t01.htm) |
| Software developers | Mean annual wage | 148,100 USD | May 2025 | [15-1252-mean-annual](https://www.bls.gov/news.release/ocwage.t01.htm) |

## Interpretation

- Software developers: Mean hourly wage is 71.2 USD for United States (May 2025). Coverage: Wage and salary employment; wages exclude employer benefits; no task duration or worker AI-use classification. [Source](https://www.bls.gov/news.release/ocwage.t01.htm).
- Software developers: Mean annual wage is 148,100 USD for United States (May 2025). Coverage: Wage and salary employment; wages exclude employer benefits; no task duration or worker AI-use classification. [Source](https://www.bls.gov/news.release/ocwage.t01.htm).

These sources describe labor-market compensation. They do not establish task duration, deliverable quality, a non-AI worker sample, attainable customer prices or realized savings. Mixing occupation-specific wages with broad occupational benefit groups requires an explicit allocation assumption.

## Source provenance

- 15-1252-mean-hourly: retrieved 2026-10-25; https://www.bls.gov/news.release/ocwage.t01.htm
- 15-1252-mean-annual: retrieved 2026-10-25; https://www.bls.gov/news.release/ocwage.t01.htm
