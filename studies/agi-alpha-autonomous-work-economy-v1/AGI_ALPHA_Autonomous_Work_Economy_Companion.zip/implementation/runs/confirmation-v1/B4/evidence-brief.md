# Analysis and operations labor reference

## Verified-input evidence brief

This briefing transforms a supplied, researched source register. It does not perform a new web search or model-authored synthesis.

| Occupation/group | Measure | Value | Source period | Source |
|---|---|---:|---|---|
| Bookkeeping, accounting, and auditing clerks | Employment | 1,373,680 people | May 2025 | [43-3031-employment](https://www.bls.gov/news.release/ocwage.t01.htm) |
| Bookkeeping, accounting, and auditing clerks | Mean annual wage | 53,560 USD | May 2025 | [43-3031-mean-annual](https://www.bls.gov/news.release/ocwage.t01.htm) |
| Management analysts | Employment | 898,280 people | May 2025 | [13-1111-employment](https://www.bls.gov/news.release/ocwage.t01.htm) |
| Management analysts | Mean annual wage | 113,790 USD | May 2025 | [13-1111-mean-annual](https://www.bls.gov/news.release/ocwage.t01.htm) |

## Interpretation

- Bookkeeping, accounting, and auditing clerks: Employment is 1,373,680 people for United States (May 2025). Coverage: Wage and salary employment; wages exclude employer benefits; no task duration or worker AI-use classification. [Source](https://www.bls.gov/news.release/ocwage.t01.htm).
- Bookkeeping, accounting, and auditing clerks: Mean annual wage is 53,560 USD for United States (May 2025). Coverage: Wage and salary employment; wages exclude employer benefits; no task duration or worker AI-use classification. [Source](https://www.bls.gov/news.release/ocwage.t01.htm).
- Management analysts: Employment is 898,280 people for United States (May 2025). Coverage: Wage and salary employment; wages exclude employer benefits; no task duration or worker AI-use classification. [Source](https://www.bls.gov/news.release/ocwage.t01.htm).
- Management analysts: Mean annual wage is 113,790 USD for United States (May 2025). Coverage: Wage and salary employment; wages exclude employer benefits; no task duration or worker AI-use classification. [Source](https://www.bls.gov/news.release/ocwage.t01.htm).

These sources describe labor-market compensation. They do not establish task duration, deliverable quality, a non-AI worker sample, attainable customer prices or realized savings. Mixing occupation-specific wages with broad occupational benefit groups requires an explicit allocation assumption.

## Source provenance

- 43-3031-employment: retrieved 2026-10-25; https://www.bls.gov/news.release/ocwage.t01.htm
- 43-3031-mean-annual: retrieved 2026-10-25; https://www.bls.gov/news.release/ocwage.t01.htm
- 13-1111-employment: retrieved 2026-10-25; https://www.bls.gov/news.release/ocwage.t01.htm
- 13-1111-mean-annual: retrieved 2026-10-25; https://www.bls.gov/news.release/ocwage.t01.htm
