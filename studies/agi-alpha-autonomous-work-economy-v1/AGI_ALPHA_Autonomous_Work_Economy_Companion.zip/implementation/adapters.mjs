// SPDX-License-Identifier: Apache-2.0
const strictInt=(v,min,max,label)=>{if(!Number.isSafeInteger(v)||v<min||v>max)throw Error('INVALID_'+label);return v;};
const txt=(v,label,max=300)=>{if(typeof v!=='string'||!v.trim()||v.length>max)throw Error('INVALID_'+label);return v;};
const artifact=(name,type,content)=>({name,type,content});
const jsonArtifact=(name,value)=>artifact(name,'application/json',JSON.stringify(value,null,2)+'\n');
const safeCell=v=>'"'+(/^[=+\-@\t\r]/.test(String(v))?"'":'')+String(v).replaceAll('"','""')+'"';
export function normalizeQuotes(input){
  txt(input.title,'TITLE');txt(input.base_currency,'BASE_CURRENCY',3);strictInt(input.deadline_days,0,365,'DEADLINE');
  if(!Array.isArray(input.items)||input.items.length<1||input.items.length>18)throw Error('ITEM_LIMIT');
  if(!Array.isArray(input.offers)||input.offers.length<1||input.offers.length>160)throw Error('OFFER_LIMIT');
  const items=input.items.map(i=>({id:txt(i.id,'ITEM_ID',60),label:txt(i.label,'ITEM_LABEL'),quantity:strictInt(i.quantity,1,10000,'QUANTITY')}));
  if(new Set(items.map(i=>i.id)).size!==items.length)throw Error('DUPLICATE_ITEM_ID');
  const vendors=Object.keys(input.shipping_minor||{}).sort();if(!vendors.length||vendors.length>12)throw Error('VENDOR_LIMIT');
  vendors.forEach(v=>strictInt(input.shipping_minor[v],0,100000000,'SHIPPING'));
  const excluded=[];
  const offers=input.offers.map((o,index)=>{
    const item=items.find(i=>i.id===o.item);if(!item)throw Error('UNKNOWN_ITEM');if(!vendors.includes(o.vendor))throw Error('UNKNOWN_VENDOR');
    strictInt(o.pack_units,1,10000,'PACK_UNITS');strictInt(o.pack_price_minor,0,100000000,'PRICE');strictInt(o.lead_days,0,365,'LEAD');
    const rate=input.fx?.[o.currency];if(!rate)throw Error('MISSING_FX_'+o.currency);
    strictInt(rate.num,1,1000000,'FX_NUM');strictInt(rate.den,1,1000000,'FX_DEN');txt(rate.source,'FX_SOURCE',500);
    const packs=Math.ceil(item.quantity/o.pack_units),n=BigInt(packs)*BigInt(o.pack_price_minor)*BigInt(rate.num),d=BigInt(rate.den);
    const cost=Number((2n*n+d)/(2n*d));strictInt(cost,0,1000000000000,'LINE_COST');
    const row={index,item:item.id,label:item.label,vendor:o.vendor,quantity:item.quantity,pack_units:o.pack_units,packs,delivered_units:packs*o.pack_units,source_currency:o.currency,source_pack_price_minor:o.pack_price_minor,landed_line_minor:cost,lead_days:o.lead_days,fx_source:rate.source};
    if(o.lead_days>input.deadline_days){excluded.push({...row,reason:'DELIVERY_DEADLINE'});return null;}return row;
  }).filter(Boolean);
  for(const i of items)if(!offers.some(o=>o.item===i.id))throw Error('NO_ELIGIBLE_OFFER_'+i.id);
  return {title:input.title,base_currency:input.base_currency,deadline_days:input.deadline_days,items,vendors,shipping:input.shipping_minor,offers,excluded};
}
export function subsetSolve(n){
  let best=null,visited=0;
  for(let mask=1;mask<(1<<n.vendors.length);mask++){
    const permitted=new Set(n.vendors.filter((v,k)=>(mask&(1<<k))!==0)),selected=[];visited++;
    for(const item of n.items){const choices=n.offers.filter(o=>o.item===item.id&&permitted.has(o.vendor)).sort((a,b)=>a.landed_line_minor-b.landed_line_minor||a.index-b.index);if(!choices.length)break;selected.push(choices[0]);}
    if(selected.length!==n.items.length)continue;
    const used=[...new Set(selected.map(o=>o.vendor))].sort(),shipping=used.reduce((s,v)=>s+n.shipping[v],0),lines=selected.reduce((s,o)=>s+o.landed_line_minor,0),total=lines+shipping;
    if(!best||total<best.total_minor)best={total_minor:total,line_total_minor:lines,shipping_minor:shipping,selected,used_vendors:used};
  }
  if(!best)throw Error('INFEASIBLE');return {...best,algorithm:'exact-vendor-subset',states_visited:visited};
}
export function enumerationSolve(n,budget=50000){
  const choices=n.items.map(i=>n.offers.filter(o=>o.item===i.id));const size=choices.reduce((v,c)=>v*c.length,1);
  if(size>budget)return {decision:'BUDGET_REFUSAL',combinations:size,budget};
  let best=null,visited=0;
  function walk(i,selected){if(i<choices.length){for(const o of choices[i])walk(i+1,[...selected,o]);return;}visited++;const used=[...new Set(selected.map(o=>o.vendor))],shipping=used.reduce((s,v)=>s+n.shipping[v],0),lines=selected.reduce((s,o)=>s+o.landed_line_minor,0),total=lines+shipping;if(!best||total<best.total_minor)best={total_minor:total,selected,used_vendors:used.sort()};}
  walk(0,[]);return {...best,algorithm:'exhaustive-cart',states_visited:visited};
}
async function quoteExecute(input,checkpoint){
  await checkpoint('normalizing-quotes');const n=normalizeQuotes(input);const result=subsetSolve(n);await checkpoint('checking-cart');
  const checks={one_offer_per_item:new Set(result.selected.map(o=>o.item)).size===n.items.length,quantities:result.selected.every(o=>o.delivered_units>=o.quantity),deadlines:result.selected.every(o=>o.lead_days<=n.deadline_days),exact_arithmetic:result.total_minor===result.line_total_minor+result.shipping_minor};
  if(!Object.values(checks).every(Boolean))throw Error('QUOTE_VERIFICATION');
  const cash=v=>(v/100).toFixed(2)+' '+n.base_currency;
  const rows=result.selected.map(o=>[o.label,o.vendor,o.quantity,o.delivered_units,o.packs,cash(o.landed_line_minor),o.lead_days]);
  const report='# '+n.title+'\n\n## Decision-ready quote comparison\n\nRecommended eligible cart: **'+cash(result.total_minor)+'**, including '+cash(result.shipping_minor)+' of fixed supplier shipping. No purchase was made.\n\n| Item | Supplier | Required units | Delivered units | Packs | Line cost | Delivery days |\n|---|---|---:|---:|---:|---:|---:|\n'+rows.map(r=>'| '+r.join(' | ')+' |').join('\n')+'\n\n## Verification and limits\n\nAll quantities, the delivery deadline and exact integer-currency totals pass the declared contract. The optimizer enumerates '+result.states_visited+' supplier subsets. '+n.excluded.length+' late offers were excluded.\n\nPrices, supplier names and exchange ratios in the included example are synthetic. For your own permitted quotes, the result is conditional on complete input prices, declared rates and fixed shipping. Taxes, uncertain inventory, quality differences, discounts and split-item purchases are outside this contract.\n';
  const csv='item,supplier,required_units,delivered_units,packs,line_cost,delivery_days\n'+rows.map(r=>r.map(safeCell).join(',')).join('\n')+'\n';
  return {decision:'QUOTE_REPORT_READY_FOR_REVIEW',summary:{items:n.items.length,offers:n.offers.length,total_minor:result.total_minor,currency:n.base_currency,excluded:n.excluded.length},evidence:{normalized:n,solution:result,checks,execution:'fresh local deterministic computation'},artifacts:[artifact('quote-report.md','text/markdown',report),artifact('recommended-cart.csv','text/csv',csv),jsonArtifact('quote-analysis.json',{normalized:n,solution:result,checks})],limits:['Synthetic examples do not establish realized customer savings or supplier availability.','Finite fixed-shipping model; no purchase or payment route executes.','A separate conventional MILP incumbent checks the confirmation optimum; in-browser computation alone does not rerun that incumbent.']};
}
function validateBrief(input){
  txt(input.title,'TITLE');if(!Array.isArray(input.facts)||!input.facts.length||input.facts.length>30)throw Error('FACT_LIMIT');
  if(!Array.isArray(input.questions)||!input.questions.length||input.questions.length>30)throw Error('QUESTION_LIMIT');
  const seen=new Map();for(const f of input.facts){txt(f.id,'FACT_ID');txt(f.occupation,'OCCUPATION');txt(f.measure,'MEASURE');txt(f.geography,'GEOGRAPHY');txt(f.currency,'CURRENCY');txt(f.coverage,'COVERAGE',1000);txt(f.source_url,'SOURCE_URL',2000);txt(f.source_year,'SOURCE_YEAR');txt(f.retrieved_at,'RETRIEVED');
    let u;try{u=new URL(f.source_url);}catch{throw Error('INVALID_SOURCE_URL');}if(u.protocol!=='https:'||!(u.hostname==='bls.gov'||u.hostname.endsWith('.bls.gov')))throw Error('SOURCE_HOST_NOT_ALLOWED');
    if(typeof f.value!=='string'||!/^\d+(?:\.\d+)?$/.test(f.value)||!Number.isFinite(Number(f.value)))throw Error('FACT_VALUE');if(seen.has(f.id)&&JSON.stringify(seen.get(f.id))!==JSON.stringify(f))throw Error('CONFLICTING_SOURCE_FACT');seen.set(f.id,f);
  }for(const id of input.questions)if(!seen.has(id))throw Error('MISSING_REQUESTED_FACT_'+id);
}
async function briefExecute(input,checkpoint){
  validateBrief(input);await checkpoint('checking-evidence-register');const facts=input.questions.map(id=>input.facts.find(f=>f.id===id));
  const rows=facts.map(f=>`| ${f.occupation} | ${f.measure} | ${Number(f.value).toLocaleString('en-US',{maximumFractionDigits:2})} ${f.currency} | ${f.source_year} | [${f.id}](${f.source_url}) |`);
  const brief='# '+input.title+'\n\n## Verified-input evidence brief\n\nThis briefing transforms a supplied, researched source register. It does not perform a new web search or model-authored synthesis.\n\n| Occupation/group | Measure | Value | Source period | Source |\n|---|---|---:|---|---|\n'+rows.join('\n')+'\n\n## Interpretation\n\n'+facts.map(f=>'- '+f.occupation+': '+f.measure+' is '+Number(f.value).toLocaleString('en-US')+' '+f.currency+' for '+f.geography+' ('+f.source_year+'). Coverage: '+f.coverage+' [Source]('+f.source_url+').').join('\n')+'\n\nThese sources describe labor-market compensation. They do not establish task duration, deliverable quality, a non-AI worker sample, attainable customer prices or realized savings. Mixing occupation-specific wages with broad occupational benefit groups requires an explicit allocation assumption.\n\n## Source provenance\n\n'+facts.map(f=>'- '+f.id+': retrieved '+f.retrieved_at+'; '+f.source_url).join('\n')+'\n';
  return {decision:'EVIDENCE_BRIEF_READY_FOR_REVIEW',summary:{facts:facts.length,sources:new Set(facts.map(f=>f.source_url)).size},evidence:{facts,requested:input.questions,all_requested_present:true,live_retrieval:false},artifacts:[artifact('evidence-brief.md','text/markdown',brief),jsonArtifact('source-register.json',facts)],limits:['Source correspondence to the fetched public pages is checked in the study source audit, not by this offline template.','This is structured factual document production, not evidence of open-ended autonomous research or original writing.']};
}
function validatePlan(input){
  txt(input.title,'TITLE');strictInt(input.deadline_minutes,1,100000,'DEADLINE');if(!Array.isArray(input.tasks)||!input.tasks.length||input.tasks.length>100)throw Error('TASK_LIMIT');
  const ids=new Set(input.tasks.map(t=>t.id));if(ids.size!==input.tasks.length)throw Error('DUPLICATE_TASK');
  for(const t of input.tasks){txt(t.id,'TASK_ID');txt(t.label,'TASK_LABEL');txt(t.resource,'RESOURCE');strictInt(t.duration_minutes,1,10000,'DURATION');if(!Array.isArray(t.deps)||t.deps.some(d=>!ids.has(d)))throw Error('MISSING_DEPENDENCY');}
  const visited=new Set(),active=new Set();function walk(id){if(active.has(id))throw Error('DEPENDENCY_CYCLE');if(visited.has(id))return;active.add(id);for(const dep of input.tasks.find(t=>t.id===id).deps)walk(dep);active.delete(id);visited.add(id);}for(const id of ids)walk(id);
}
async function planExecute(input,checkpoint){
  validatePlan(input);const pending=[...input.tasks],scheduled=[],byId=new Map(),resourceFree=new Map();
  while(pending.length){await checkpoint('scheduling');const ready=pending.filter(t=>t.deps.every(d=>byId.has(d))).sort((a,b)=>a.id.localeCompare(b.id));if(!ready.length)throw Error('DEPENDENCY_CYCLE');const task=ready[0],start=Math.max(resourceFree.get(task.resource)||0,...task.deps.map(d=>byId.get(d).finish));const row={...task,start,finish:start+task.duration_minutes};scheduled.push(row);byId.set(task.id,row);resourceFree.set(task.resource,row.finish);pending.splice(pending.indexOf(task),1);}
  const makespan=Math.max(...scheduled.map(t=>t.finish));if(makespan>input.deadline_minutes)throw Error('DEADLINE_INFEASIBLE_FOR_DECLARED_POLICY');
  const checks={all_tasks:scheduled.length===input.tasks.length,precedence:scheduled.every(t=>t.deps.every(d=>byId.get(d).finish<=t.start)),resources:scheduled.every((t,i)=>scheduled.slice(i+1).every(u=>u.resource!==t.resource||u.finish<=t.start||t.finish<=u.start))};if(!Object.values(checks).every(Boolean))throw Error('PLAN_VERIFICATION');
  const report='# '+input.title+'\n\n## Executable preparation plan\n\nThe declared tasks fit within **'+makespan+' planned minutes** and the '+input.deadline_minutes+' minute deadline. Durations are supplied planning estimates, not measured human time.\n\n| Task | Role/resource | Start | Finish | Predecessors |\n|---|---|---:|---:|---|\n'+scheduled.map(t=>'| '+t.label+' | '+t.resource+' | '+t.start+' | '+t.finish+' | '+(t.deps.join(', ')||'None')+' |').join('\n')+'\n\nAll precedence and single-capacity resource constraints pass. The deterministic list schedule is feasible for this input; it is not claimed globally optimal. No invitations, publishing, spending or external actions execute.\n';
  return {decision:'PLAN_READY_FOR_REVIEW',summary:{tasks:scheduled.length,makespan_minutes:makespan,deadline_minutes:input.deadline_minutes},evidence:{schedule:scheduled,checks,optimality:'NOT_CLAIMED'},artifacts:[artifact('operating-plan.md','text/markdown',report),artifact('schedule.csv','text/csv','id,resource,start,finish,dependencies\n'+scheduled.map(t=>[t.id,t.resource,t.start,t.finish,t.deps.join(';')].map(safeCell).join(',')).join('\n')+'\n'),jsonArtifact('schedule-analysis.json',{schedule:scheduled,checks})],limits:['Durations and resource availability are user assumptions; operational delivery was not observed.','The bounded list policy can reject a deadline even if another schedule exists.']};
}
export const quoteAdapter={manifest:{id:'awe-quotes',version:2,en:'Compare a complete quote basket',fr:'Comparer un panier de devis',scope:'Exact fixed-shipping quote basket with explicit pack units, currency ratios and deadlines.',artifact:'quote-report.md'},validate:normalizeQuotes,execute:quoteExecute};
export const briefAdapter={manifest:{id:'awe-brief',version:1,en:'Create a sourced evidence brief',fr:'Créer une note sourcée',scope:'Produce a structured brief from supplied verified BLS source records without open-ended research.',artifact:'evidence-brief.md'},validate:validateBrief,execute:briefExecute};
export const planningAdapter={manifest:{id:'awe-plan',version:1,en:'Build a feasible operating plan',fr:'Construire un plan réalisable',scope:'Schedule declared tasks under dependencies and single-capacity role constraints.',artifact:'operating-plan.md'},validate:validatePlan,execute:planExecute};
