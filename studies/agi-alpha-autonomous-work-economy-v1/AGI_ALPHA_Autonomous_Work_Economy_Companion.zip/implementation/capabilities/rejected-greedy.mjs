// SPDX-License-Identifier: Apache-2.0
import {normalizeQuotes} from '../adapters.mjs';
export function solve(input){const n=normalizeQuotes(input),selected=n.items.map(i=>n.offers.filter(o=>o.item===i.id).sort((a,b)=>a.landed_line_minor-b.landed_line_minor)[0]);const vendors=[...new Set(selected.map(o=>o.vendor))];return {total_minor:selected.reduce((s,o)=>s+o.landed_line_minor,0)+vendors.reduce((s,v)=>s+n.shipping[v],0),selected};}
