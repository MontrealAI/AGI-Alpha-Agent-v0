// SPDX-License-Identifier: Apache-2.0
import {normalizeQuotes,enumerationSolve} from '../adapters.mjs';
export function solve(input){
 if(input.offers.some(o=>o.pack_units!==1||o.currency!==input.base_currency))throw Error('V1_SCOPE_PACK_OR_CURRENCY');
 const result=enumerationSolve(normalizeQuotes(input),50000);
 if(result.decision==='BUDGET_REFUSAL')throw Error('V1_COMBINATION_BUDGET');
 return result;
}
