// SPDX-License-Identifier: Apache-2.0
import {normalizeQuotes,subsetSolve} from '../adapters.mjs';
export const solve=input=>subsetSolve(normalizeQuotes(input));
