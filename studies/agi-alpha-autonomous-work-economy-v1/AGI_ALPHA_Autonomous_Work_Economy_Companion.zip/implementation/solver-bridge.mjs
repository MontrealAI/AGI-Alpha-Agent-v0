// SPDX-License-Identifier: Apache-2.0
import readline from 'node:readline';
import {normalizeQuotes,subsetSolve} from './adapters.mjs';
for await(const line of readline.createInterface({input:process.stdin,crlfDelay:Infinity})){
 try{const input=JSON.parse(line),start=performance.now(),result=subsetSolve(normalizeQuotes(input));console.log(JSON.stringify({total_minor:result.total_minor,elapsed_ms:performance.now()-start}));}
 catch(e){console.log(JSON.stringify({error:e.message}));}
}
