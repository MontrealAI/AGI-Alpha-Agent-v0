# SPDX-License-Identifier: Apache-2.0
import json, random, hashlib, datetime, copy
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def write(path,obj):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')

def spec(family,title,inputs,public=False):
    return {'schema':'successor-workbench/v1','family':family,'name':title,'language':'en','owner':'AWE-2026-01-public-local','rights':{'dataClass':'public' if public else 'synthetic','source':'US BLS public source register' if public else 'AWE-2026-01 original synthetic structural fixture','license':'US federal public data' if public else 'Apache-2.0'},'reviewMinutes':1,'inputs':inputs}

def quotes(seed,n=4,v=3,mixed=False,late=False):
    rng=random.Random(seed);vendors=['Aster','Boreal','Cedar','Delta'][:v]
    items=[{'id':f'item-{i+1:02d}','label':['Monitor','Dock','Keyboard','Desk lamp','USB hub','Cable pack','Webcam','Headset','Stand','Adapter','Network switch','Storage drive','Microphone','Router'][i], 'quantity':rng.randint(2,15)} for i in range(n)]
    offers=[]
    for item in items:
        for j,vendor in enumerate(vendors):
            offers.append({'item':item['id'],'vendor':vendor,'pack_units':rng.choice([1,2,5]) if mixed else 1,'pack_price_minor':rng.randint(700,18000),'currency':['USD','CAD','EUR','USD'][j] if mixed else 'USD','lead_days':rng.randint(2,9) if late else rng.randint(1,4)})
    return {'title':'Public example: complete equipment quote comparison','base_currency':'USD','deadline_days':6,'items':items,'shipping_minor':{v:rng.randint(400,2200) for v in vendors},'fx':{'USD':{'num':1,'den':1,'source':'Synthetic identity rate'},'CAD':{'num':74,'den':100,'source':'Synthetic fixed ratio for reproducible example, not a market quote'},'EUR':{'num':108,'den':100,'source':'Synthetic fixed ratio for reproducible example, not a market quote'}},'offers':offers}

def planning(title,offset=0,n=6):
    rows=[('01-intake','Confirm scope','owner',10,[]),('02-assets','Prepare inputs','production',20,['01-intake']),('03-draft','Build deliverable','production',30,['02-assets']),('04-check','Check evidence','review',20,['03-draft']),('05-copy','Prepare clear instructions','editor',15,['02-assets']),('06-package','Package approved result','production',10,['04-check','05-copy']),('07-translate','Prepare French version','editor',25,['05-copy']),('08-language-check','Check terminology','review',15,['07-translate']),('09-accessibility','Check accessibility','review',15,['06-package']),('10-export','Prepare export bundle','production',5,['08-language-check','09-accessibility'])]
    tasks=[]
    ids={r[0] for r in rows[:n]}
    for id,label,resource,duration,deps in rows[:n]:tasks.append({'id':id,'label':label,'resource':resource,'duration_minutes':duration+offset,'deps':[d for d in deps if d in ids]})
    return {'title':title,'deadline_minutes':300,'tasks':tasks}

def main():
    if (ROOT/'input-freeze.json').exists():raise SystemExit('Inputs already frozen. Reuse them; amendments require a new study version.')
    cases=[]
    def add(id,family,title,inputs,accepted=True,reason=None,public=False):cases.append({'id':id,'family':family,'title':title,'expected':'supported-delivery' if accepted else 'explicit-refusal','expected_reason':reason,'spec':spec({'quotes':'awe-quotes','brief':'awe-brief','planning':'awe-plan'}.get(family,family),title,inputs,public)})
    add('Q1','quotes','Meeting-room equipment cart',quotes(5701,4,3))
    add('Q2','quotes','Small lab: packs and currencies',quotes(5702,6,4,True))
    add('Q3','quotes','Deadline-constrained studio cart',quotes(5703,8,4,True,True))
    add('Q4','quotes','Fourteen-item expansion cart',quotes(5704,14,4,True))
    q=quotes(5705,5,4,True);del q['fx']['EUR'];add('Q5','quotes','Missing conversion evidence',q,False,'MISSING_FX')
    q=quotes(5706,5,3);q['deadline_days']=0;add('Q6','quotes','No eligible delivery offer',q,False,'NO_ELIGIBLE_OFFER')
    facts=[]
    for soc,occupation,employment,hourly,annual,median in [('15-1252','Software developers',1687890,71.20,148100,65.38),('27-3042','Technical writers',45500,46.62,96970,43.46),('43-3031','Bookkeeping, accounting, and auditing clerks',1373680,25.75,53560,24.36),('13-1111','Management analysts',898280,54.71,113790,48.97)]:
        for measure,value,label in [('employment',employment,'Employment'),('mean-hourly',hourly,'Mean hourly wage'),('mean-annual',annual,'Mean annual wage')]:
            facts.append({'id':soc+'-'+measure,'occupation':occupation,'soc':soc,'measure':label,'value':value,'currency':'people' if measure=='employment' else 'USD','source_year':'May 2025','geography':'United States','coverage':'Wage and salary employment; wages exclude employer benefits; no task duration or worker AI-use classification.','source_url':'https://www.bls.gov/news.release/ocwage.t01.htm','retrieved_at':'2026-10-25','source_registry':'BLS_OEWS_2025'})
    requests=[['15-1252-mean-hourly','15-1252-mean-annual'],['27-3042-mean-hourly','27-3042-employment'],['15-1252-mean-hourly','27-3042-mean-hourly','43-3031-mean-hourly','13-1111-mean-hourly'],['43-3031-employment','43-3031-mean-annual','13-1111-employment','13-1111-mean-annual']]
    for i,ids in enumerate(requests,1):add(f'B{i}','brief',['Software-delivery labor reference','Technical-writing labor reference','Four-occupation compensation brief','Analysis and operations labor reference'][i-1],{'title':['Software-delivery labor reference','Technical-writing labor reference','Four-occupation compensation brief','Analysis and operations labor reference'][i-1],'questions':ids,'facts':[f for f in facts if f['id'] in ids]},public=True)
    b={'title':'Uncited source record','questions':[facts[0]['id']],'facts':[copy.deepcopy(facts[0])]};b['facts'][0]['source_url']='';add('B5','brief','Reject missing source attribution',b,False,'INVALID_SOURCE_URL',True)
    b={'title':'Contradictory evidence register','questions':[facts[0]['id']],'facts':[copy.deepcopy(facts[0]),copy.deepcopy(facts[0])]};b['facts'][1]['value']+=1;add('B6','brief','Reject conflicting source values',b,False,'CONFLICTING_SOURCE_FACT',True)
    for i,(title,n) in enumerate([('Release-preparation operating plan',6),('Bilingual evidence-pack plan',8),('Accessible publication plan',9),('Complete research delivery plan',10)],1):add(f'P{i}','planning',title,planning(title,i-1,n))
    p=planning('Cyclic task requirements');p['tasks'][0]['deps']=['06-package'];add('P5','planning','Reject circular dependency',p,False,'DEPENDENCY_CYCLE')
    p=planning('Insufficient scheduled capacity');p['deadline_minutes']=15;add('P6','planning','Reject infeasible declared schedule',p,False,'DEADLINE_INFEASIBLE')
    add('S1','reliability','Repair closed-range boundary defects',{'source':'export function contains(value, low, high) { return low < value && value < high; }','low':-25,'high':38,'cases':[-26,-25,-24,0,37,38,39]})
    add('S2','reliability','Retain a correct range implementation',{'source':'export function contains(value, low, high) { return low <= value && value <= high; }','low':-100,'high':100,'cases':[-101,-100,-99,0,99,100,101]})
    md='# Public SDK guide\n\n```successor-example\n{"operation":"url-encode","input":"release notes & evidence","expected":"release+notes+%26+evidence"}\n```\n\n```successor-example\n{"operation":"url-decode","input":"caf%C3%A9%20guide","expected":"café guide"}\n```\n'
    add('S3','documentation','Repair URI examples in a public guide',{'markdown':md})
    md='# Bilingual SDK guide\n\n```successor-example\n{"operation":"utf8-bytes","input":"café","expected":"4"}\n```\n\n```successor-example\n{"operation":"utf8-bytes","input":"Ω ∞","expected":"3"}\n```\n'
    add('S4','documentation','Repair UTF-8 documentation examples',{'markdown':md})
    add('S5','reliability','Reject arbitrary repository execution',{'source':'export function contains(value, low, high) { throw new Error("unbounded"); }','low':0,'high':1,'cases':[0,1]},False,'SOURCE_GRAMMAR')
    add('S6','documentation','Retain invalid URI failure for correction',{'markdown':'# Invalid example\n\n```successor-example\n{"operation":"url-decode","input":"%E0%A4%A","expected":"ok"}\n```\n'},False,'INVALID_URI_ENCODING')
    inventory=[]
    for c in cases:
        write(ROOT/'inputs'/f'{c["id"]}.json',c['spec']);raw=(ROOT/'inputs'/f'{c["id"]}.json').read_bytes();inventory.append({k:v for k,v in c.items() if k!='spec'}|{'path':f'inputs/{c["id"]}.json','sha256':hashlib.sha256(raw).hexdigest(),'scope':'synthetic structural case' if c['family']!='brief' else 'public sourced structured fact record'})
    write(ROOT/'task-inventory.json',inventory)
    write(ROOT/'public-facts.json',facts)
    dev=spec('awe-quotes','Development cart for capability retention',quotes(5601,3,3))
    write(ROOT/'inputs/development-quote.json',dev)
    freeze={'study_id':'AWE-2026-01','frozen_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'n':len(cases),'protocol_sha256':hashlib.sha256((ROOT/'protocol.json').read_bytes()).hexdigest(),'inventory_sha256':hashlib.sha256((ROOT/'task-inventory.json').read_bytes()).hexdigest(),'inputs':[{k:v for k,v in r.items() if k in ['id','path','sha256']} for r in inventory],'status':'FROZEN_BEFORE_CONFIRMATION','note':'Local freeze; same-team fixture authorship and no blinding. Development input excluded from n.'}
    write(ROOT/'input-freeze.json',freeze)
    print(json.dumps({'cases':len(cases),'frozen_at_utc':freeze['frozen_at_utc'],'protocol_sha256':freeze['protocol_sha256']}))
if __name__=='__main__':main()
