from __future__ import annotations
import copy
import itertools
import json
import sys
import tempfile
import unittest
from fractions import Fraction
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'experiments'))
from capacity_pilot import allocation, case, child_task, credit, digest, participation
from verify_capacity import verify, oracle_feasible, load
from credit_book import LocalCreditBook

class AllocationTests(unittest.TestCase):
    def test_aligned(self):
        z=allocation(case());self.assertEqual(z['allocated_times'],[9,10,11]);self.assertTrue(verify(z)['valid'])
    def test_equal_gain_different_delivery(self):
        a,b=allocation(case()),allocation(case('fragmented'))
        self.assertEqual(a['earned_credit'],b['earned_credit']);self.assertEqual(b['allocated_times'],[])
    def test_memory(self): self.assertEqual(allocation(case('memory-bound'))['allocated_times'],[])
    def test_expiry(self): self.assertEqual(allocation(case('expired'))['allocated_times'],[])
    def test_hardware(self): self.assertEqual(allocation(case('wrong-hardware'))['allocated_times'],[])
    def test_quality(self): self.assertEqual(allocation(case('quality-regression'))['earned_credit'],0)
    def test_confirmation(self): self.assertEqual(allocation(case('unconfirmed'))['earned_credit'],0)
    def test_overhead(self): self.assertEqual(allocation(case('overhead-erases-gain'))['earned_credit'],0)
    def test_consent(self): self.assertEqual(allocation(case('no-consent'))['earned_credit'],0)
    def test_idle_is_not_earned(self): self.assertEqual(allocation(case('pre-existing-idle-only'))['earned_credit'],0)
    def test_existing_commitment(self): self.assertEqual(allocation(case('already-committed'))['allocated_times'],[])
    def test_explicit_preemption(self):
        z=allocation(case('fragmented-preemptible'));self.assertEqual(z['allocated_times'],[9,11,13]);verify(z)
    def test_all_cases_verify(self):
        names=['aligned','fragmented','memory-bound','expired','wrong-hardware','quality-regression','unconfirmed','overhead-erases-gain','no-consent','pre-existing-idle-only','already-committed','fragmented-preemptible']
        for n in names:
            with self.subTest(n=n):verify(allocation(case(n)))
    def test_exhaustive_calendar_census(self):
        total=feasible=0
        for g in itertools.product(range(4),repeat=8):
            if sum(g)!=12:continue
            c=case();c['calendar']['incremental_release_cpu']=list(g);c['calendar']['primary_cpu']=[4-x for x in g]
            z=allocation(c); self.assertEqual(bool(z['allocated_times']),oracle_feasible(g));verify(z)
            total+=1;feasible+=bool(z['allocated_times'])
        self.assertEqual((total,feasible),(8092,7426))
    def test_child_optimality(self):
        z=allocation(case());z['child_result']=child_task();self.assertTrue(verify(z)['child_checked']);self.assertEqual(z['child_result']['value'],27)
    def test_child_after_no_schedule(self):
        z=allocation(case('fragmented'));z['child_result']=child_task()
        with self.assertRaises(ValueError):verify(z)

class CheckerTests(unittest.TestCase):
    def mutated(self, change):
        z=allocation(case());change(z)
        with self.assertRaises(ValueError):verify(z)
    def test_unknown_schema(self):self.mutated(lambda z:z.update(schema='new'))
    def test_unknown_field(self):self.mutated(lambda z:z.update(extra=True))
    def test_scope(self):self.mutated(lambda z:z.update(real_provider_delivery=True))
    def test_money_claim(self):self.mutated(lambda z:z.update(actual_native_settlement='claimed'))
    def test_gain(self):self.mutated(lambda z:z.update(gain=99))
    def test_credit(self):self.mutated(lambda z:z.update(earned_credit=4))
    def test_remaining(self):self.mutated(lambda z:z.update(remaining_credit=1))
    def test_consumed(self):self.mutated(lambda z:z.update(model_delivered_cpu=2))
    def test_duplicate_slot(self):self.mutated(lambda z:z.update(allocated_times=[9,9,10]))
    def test_nonconsecutive(self):self.mutated(lambda z:z.update(allocated_times=[9,11,12]))
    def test_before_issue(self):self.mutated(lambda z:z.update(allocated_times=[8,9,10]))
    def test_after_window(self):self.mutated(lambda z:z.update(allocated_times=[15,16,17]))
    def test_changed_case(self):self.mutated(lambda z:z['case']['evidence'].update(candidate_cpu=0))
    def test_rebound_overcommitment(self):
        def change(z):
            z['case']['calendar']['primary_cpu'][0]=4;z['case_digest']=digest(z['case'])
        self.mutated(change)
    def test_rebound_memory(self):
        def change(z):
            z['case']['calendar']['primary_memory'][0]=4;z['case_digest']=digest(z['case'])
        self.mutated(change)
    def test_boolean_quantity(self):self.mutated(lambda z:z.update(gain=True))
    def test_false_child_value(self):
        def change(z):
            z['child_result']=child_task();z['child_result']['value']+=1
        self.mutated(change)
    def test_json_duplicate_key(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'x.json';p.write_text('[{"x":1,"x":2}]')
            with self.assertRaises(ValueError):load(p)
    def test_json_nonfinite(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'x.json';p.write_text('[NaN]')
            with self.assertRaises(ValueError):load(p)
    def test_roundtrip(self):verify(json.loads(json.dumps(allocation(case()))))

class EconomicsTests(unittest.TestCase):
    def test_quarter(self):self.assertEqual(credit(12,1,4,100),3)
    def test_round_down(self):self.assertEqual(credit(11,1,4,100),2)
    def test_cap(self):self.assertEqual(credit(100,1,2,3),3)
    def test_zero(self):self.assertEqual(credit(0,1,4,3),0)
    def test_invalid_terms(self):
        for x in [(-1,1,4,3),(12,1,0,3),(12,5,4,3),(True,1,4,3),(12,1,4,-3)]:
            with self.assertRaises(ValueError):credit(*x)
    def test_participation(self):
        p=participation(*map(Fraction,[12,2,3,1,6,6]));self.assertEqual(p,{'lower':'1/6','upper':'3/4','feasible':True})
    def test_participation_infeasible(self):
        p=participation(Fraction(12),Fraction(2),Fraction(3),Fraction(1,8),Fraction(6),Fraction(6));self.assertFalse(p['feasible'])
    def test_invalid_fraction(self):
        with self.assertRaises(ValueError):participation(*map(Fraction,[12,2,3,0,6,6]))

class BookTests(unittest.TestCase):
    def test_initial(self):self.assertEqual(LocalCreditBook(3).snapshot()['available'],3)
    def test_reserve_close(self):
        b=LocalCreditBook(3);b.reserve('b',3);b.close('b',3);self.assertEqual(b.snapshot(),{'issued':3,'reserved':0,'consumed':3,'available':0})
    def test_no_double_spend(self):
        b=LocalCreditBook(3);b.reserve('b',3)
        with self.assertRaises(ValueError):b.reserve('c',1)
    def test_idempotent_reserve(self):
        b=LocalCreditBook(3);b.reserve('b',2);b.reserve('b',2);self.assertEqual(b.snapshot()['reserved'],2)
    def test_conflicting_reserve(self):
        b=LocalCreditBook(3);b.reserve('b',2)
        with self.assertRaises(ValueError):b.reserve('b',1)
    def test_partial_use(self):
        b=LocalCreditBook(3);b.reserve('b',3);b.close('b',1);self.assertEqual(b.snapshot()['available'],2)
    def test_terminal_idempotent(self):
        b=LocalCreditBook(3);b.reserve('b',3);b.close('b',1);b.close('b',1);self.assertEqual(b.snapshot()['consumed'],1)
    def test_terminal_conflict(self):
        b=LocalCreditBook(3);b.reserve('b',3);b.close('b',1)
        with self.assertRaises(ValueError):b.close('b',0)
    def test_replay_closed(self):
        b=LocalCreditBook(3);b.reserve('b',3);b.close('b',3)
        with self.assertRaises(ValueError):b.reserve('b',3)
    def test_unreserved_use(self):
        with self.assertRaises(ValueError):LocalCreditBook(3).close('b',1)
    def test_excess_use(self):
        b=LocalCreditBook(3);b.reserve('b',2)
        with self.assertRaises(ValueError):b.close('b',3)
    def test_parallel_reservation(self):
        b=LocalCreditBook(3)
        def f(i):
            try:b.reserve(str(i),3);return 1
            except ValueError:return 0
        with ThreadPoolExecutor(max_workers=8) as p:self.assertEqual(sum(p.map(f,range(8))),1)

if __name__=='__main__':unittest.main()
