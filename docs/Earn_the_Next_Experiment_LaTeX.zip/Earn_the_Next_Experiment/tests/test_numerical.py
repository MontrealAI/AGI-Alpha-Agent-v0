import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'experiments'))
import numerical_workload as w
import numpy as np

class NumericalTests(unittest.TestCase):
    def test_three_solvers(self):
        for n,q in [(1,1),(8,1),(8,12),(32,24)]:
            a,b,t=w.inputs(n,q)
            for f in (w.independent_requests,w.retained_factor,w.strong_batched):
                with self.subTest(n=n,q=q,solver=f.__name__):self.assertTrue(w.check(a,b,f(a,b),t)['accepted'])
    def test_wrong_output(self):
        a,b,t=w.inputs(8,3);self.assertFalse(w.check(a,b,np.zeros_like(b),t)['accepted'])
    def test_changed_matrix_identity(self):
        a,b,t=w.inputs(8,3);c=a.copy();c[0,0]+=1;self.assertNotEqual(w.fingerprint(a),w.fingerprint(c))
    def test_finite(self):
        a,b,t=w.inputs(8,3);x=t.copy();x[0,0]=np.nan;self.assertFalse(w.check(a,b,x,t)['accepted'])
    def test_bad_shape(self):
        a,b,t=w.inputs(8,3);self.assertFalse(w.check(a,b,t[:,:2],t)['accepted'])
    def test_deterministic_inputs(self):
        a,b,t=w.inputs(8,3);c,d,u=w.inputs(8,3);self.assertTrue(np.array_equal(a,c));self.assertTrue(np.array_equal(b,d))
    def test_invalid_dimensions(self):
        with self.assertRaises(ValueError):w.inputs(0,3)
    def test_ill_conditioning_not_planted(self):
        a,b,t=w.inputs(32,3);self.assertLess(np.linalg.cond(a),10)

if __name__=='__main__':unittest.main()
