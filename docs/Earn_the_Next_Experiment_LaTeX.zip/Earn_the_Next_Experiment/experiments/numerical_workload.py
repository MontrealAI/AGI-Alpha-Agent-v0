"""Executed pilot-workload control: repeated SPD systems, not autonomous discovery."""
from __future__ import annotations
import hashlib
import json
import os
import platform
import statistics
import sys
import time
from pathlib import Path
for _v in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[_v]='1'
import numpy as np
import scipy
from scipy.linalg import cho_factor, cho_solve


def inputs(n: int, rhs: int, seed: int=739) -> tuple[np.ndarray,np.ndarray,np.ndarray]:
    if n<1 or rhs<1 or n>512 or rhs>128:
        raise ValueError('bounded positive dimensions required')
    gen=np.random.default_rng(seed)
    raw=gen.standard_normal((n,n))
    a=np.ascontiguousarray(raw.T@raw+n*np.eye(n),dtype=np.float64)
    truth=gen.standard_normal((n,rhs))
    return a,np.ascontiguousarray(a@truth),truth


def fingerprint(a: np.ndarray) -> str:
    return hashlib.sha256(str((a.shape,a.dtype.str)).encode()+a.tobytes(order='C')).hexdigest()


def independent_requests(a: np.ndarray,b: np.ndarray) -> np.ndarray:
    return np.column_stack([cho_solve(cho_factor(a,lower=True,check_finite=True),b[:,i],check_finite=True)
                            for i in range(b.shape[1])])


def retained_factor(a: np.ndarray,b: np.ndarray) -> np.ndarray:
    # Identity construction is charged within this candidate's timed call.
    key=fingerprint(a)
    factor=cho_factor(a,lower=True,check_finite=True)
    if not key:
        raise ValueError('missing source identity')
    return np.column_stack([cho_solve(factor,b[:,i],check_finite=True) for i in range(b.shape[1])])


def strong_batched(a: np.ndarray,b: np.ndarray) -> np.ndarray:
    return cho_solve(cho_factor(a,lower=True,check_finite=True),b,check_finite=True)


def check(a: np.ndarray,b: np.ndarray,x: np.ndarray,truth: np.ndarray) -> dict[str,float|bool]:
    if x.shape!=b.shape or not np.isfinite(x).all():
        return {'accepted':False,'backward_error':float(1),'forward_error':float(1)}
    resid=a@x-b
    na=np.linalg.norm(a,ord=np.inf)
    ratios=[]
    for i in range(b.shape[1]):
        den=na*np.linalg.norm(x[:,i],ord=np.inf)+np.linalg.norm(b[:,i],ord=np.inf)
        ratios.append(float(np.linalg.norm(resid[:,i],ord=np.inf)/(den or 1)))
    be=max(ratios)
    fe=float(np.max(np.abs(x-truth)))
    return {'accepted':be<=1e-12 and fe<=1e-10,'backward_error':be,'forward_error':fe}


def run(out: Path) -> None:
    out.mkdir(parents=True,exist_ok=True)
    funcs={'independent_requests':independent_requests,'retained_factor':retained_factor,'strong_batched':strong_batched}
    records=[]
    for n,rhs in [(192,1),(192,24),(384,24)]:
        a,b,truth=inputs(n,rhs)
        for f in funcs.values():
            f(a,b)
        timings={k:[] for k in funcs}
        checks={}
        names=list(funcs)
        for rep in range(21):
            order=names[rep%3:]+names[:rep%3]
            for name in order:
                start=time.perf_counter_ns()
                x=funcs[name](a,b)
                elapsed=time.perf_counter_ns()-start
                timings[name].append(elapsed)
                verdict=check(a,b,x,truth)
                if not verdict['accepted']:
                    raise RuntimeError(f'numerical output failed: {name}')
                checks[name]=verdict
        records.append({'n':n,'rhs':rhs,'input_digest':fingerprint(a),'repetitions':21,
                        'factorizations':{'independent_requests':rhs,'retained_factor':1,'strong_batched':1},
                        'median_ms':{k:statistics.median(v)/1e6 for k,v in timings.items()},
                        'raw_ns':timings,'last_checks':checks})
    data={'scope':'local supplied-algorithm benchmark; no provider, earned credit, or native settlement',
          'environment':{'python':sys.version.split()[0],'numpy':np.__version__,'scipy':scipy.__version__,
                         'system':platform.system(),'machine':platform.machine(),'blas_threads_requested':1},
          'method':'one warmup per method/case; 21 cyclic-order repetitions; fresh factor each timed call; input generation/output check excluded equally; hash included for retained_factor',
          'cases':records}
    (out/'numerical_benchmark.json').write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'environment':data['environment'],'cases':[{k:r[k] for k in ('n','rhs','median_ms','last_checks')} for r in records]},indent=2))


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=Path(__file__).resolve().parents[1]/'reproduced_benchmark')
    args=parser.parse_args()
    if (args.output/'numerical_benchmark.json').exists():
        parser.error('output already contains a benchmark; choose a fresh output directory')
    run(args.output)
