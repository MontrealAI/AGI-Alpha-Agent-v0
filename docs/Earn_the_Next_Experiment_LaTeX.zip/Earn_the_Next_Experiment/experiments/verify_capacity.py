"""Separate certificate/child-result verifier; imports no planning implementation."""
from __future__ import annotations
import hashlib
import itertools
import json
from pathlib import Path
from typing import Any


def _n(v: Any) -> int:
    if type(v) is not int or not 0 <= v <= 10**9:
        raise ValueError('invalid nonnegative quantity')
    return v


def verify(z: dict[str, Any]) -> dict[str, Any]:
    required = {'schema','scope','case','case_digest','gain','earned_credit','allocated_times',
                'model_delivered_cpu','remaining_credit','primary_preserved',
                'real_provider_delivery','actual_native_settlement','child_result'}
    if type(z) is not dict or set(z) != required or z['schema'] != 'ifc-reference-certificate/v1':
        raise ValueError('unrecognized certificate shape')
    if z['scope'] != 'synthetic-exact; not provider delivery' or z['real_provider_delivery'] is not False or z['actual_native_settlement'] is not None:
        raise ValueError('scope must remain synthetic')
    c = z['case']
    expected = hashlib.sha256(json.dumps(c,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
    if expected != z['case_digest']:
        raise ValueError('case binding mismatch')
    e, a, k, r = [c[x] for x in ('evidence','agreement','calendar','request')]
    if c['scope'] != z['scope']:
        raise ValueError('case scope mismatch')
    for obj, key in [(e,'primary_outcomes_preserved'),(e,'confirmation_passed'),(a,'provider_consented'),(r,'preemptible')]:
        if type(obj[key]) is not bool:
            raise ValueError('exact booleans required')
    times = k['times']
    if not isinstance(times,list) or not 1 <= len(times) <= 256 or any(type(t) is not int for t in times) or times != sorted(set(times)):
        raise ValueError('ordered distinct bounded calendar required')
    for key in ('cpu_capacity','memory_capacity','primary_cpu','primary_memory','incremental_release_cpu','prior_awards_cpu','prior_awards_memory'):
        if len(k[key]) != len(times):
            raise ValueError('calendar shape mismatch')
        for v in k[key]:
            _n(v)
    for i in range(len(times)):
        if k['primary_cpu'][i]+k['prior_awards_cpu'][i] > k['cpu_capacity'][i] or k['primary_memory'][i]+k['prior_awards_memory'][i] > k['memory_capacity'][i]:
            raise ValueError('pre-existing overcommitment')
        if k['incremental_release_cpu'][i] > k['cpu_capacity'][i]-k['primary_cpu'][i]:
            raise ValueError('release exceeds physical headroom')
    gain = max(0, _n(e['baseline_cpu'])-_n(e['candidate_cpu'])-_n(e['incremental_overhead_cpu']))
    num, den, cap = [_n(a[x]) for x in ('share_num','share_den','credit_cap')]
    if den == 0 or num > den:
        raise ValueError('invalid share')
    if _n(a['issued']) < _n(e['epoch_closed']) or _n(a['expires']) <= a['issued']:
        raise ValueError('invalid chronology')
    gate = e['primary_outcomes_preserved'] and e['confirmation_passed'] and a['provider_consented']
    award = min(cap, (gain*num)//den) if gate else 0
    if _n(z['gain']) != gain or _n(z['earned_credit']) != award or z['primary_preserved'] is not e['primary_outcomes_preserved']:
        raise ValueError('incorrect credit or outcome flag')
    chosen = z['allocated_times']
    if type(chosen) is not list or len(chosen)>len(times) or any(type(t) is not int for t in chosen) or chosen != sorted(set(chosen)):
        raise ValueError('invalid allocation list')
    cpu, memory, duration = [_n(r[x]) for x in ('cpu','memory','duration')]
    if min(cpu, duration) == 0 or _n(r['deadline']) <= _n(r['release']):
        raise ValueError('invalid task shape')
    if chosen:
        if not gate or r['hardware'] != a['hardware'] or len(chosen) != duration:
            raise ValueError('unadmitted task')
        if not r['preemptible'] and chosen != list(range(chosen[0],chosen[0]+duration)):
            raise ValueError('noncontiguous nonpreemptible work')
        for t in chosen:
            if t not in times or t < max(r['release'],a['issued']+1) or t >= min(r['deadline'],a['expires']):
                raise ValueError('outside authorized window')
            i=times.index(t)
            if cpu+k['prior_awards_cpu'][i] > k['incremental_release_cpu'][i]:
                raise ValueError('double-counted or unearned release')
            if cpu+k['primary_cpu'][i]+k['prior_awards_cpu'][i] > k['cpu_capacity'][i] or memory+k['primary_memory'][i]+k['prior_awards_memory'][i] > k['memory_capacity'][i]:
                raise ValueError('resource overbooking')
    consumed=len(chosen)*cpu
    if consumed>award or _n(z['model_delivered_cpu'])!=consumed or _n(z['remaining_credit'])!=award-consumed:
        raise ValueError('credit conservation failure')
    child=z['child_result']
    if not chosen and child is not None:
        raise ValueError('unbacked child result')
    if child is not None:
        items=child['items']; budget=_n(child['budget']); selection=child['selected_indices']
        if not 1<=len(items)<=16 or selection!=sorted(set(selection)) or any(type(i) is not int or i<0 or i>=len(items) for i in selection):
            raise ValueError('invalid child selection')
        for w,v in items:
            _n(w);_n(v)
        best=max(sum(items[i][1] for i in range(len(items)) if mask>>i&1)
                 for mask in range(1<<len(items))
                 if sum(items[i][0] for i in range(len(items)) if mask>>i&1)<=budget)
        if sum(items[i][0] for i in selection)>budget or sum(items[i][1] for i in selection)!=child['value'] or child['value']!=best:
            raise ValueError('invalid or nonoptimal child result')
    return {'valid': True, 'model_delivered_cpu': consumed, 'child_checked': child is not None,
            'scope': 'finite-model consistency; neither source truth nor provider performance'}


def oracle_feasible(g: tuple[int, ...]) -> bool:
    # Exhaust all three-slot subsets, not the constructor's consecutive-start algorithm.
    for comb in itertools.combinations(range(len(g)),3):
        if comb[2]-comb[0]==2 and all(g[i]>=1 for i in comb):
            return True
    return False


def load(path: Path) -> list[dict[str, Any]]:
    if path.stat().st_size > 2_000_000:
        raise ValueError('file too large for reference checker')
    def pairs(xs: list[tuple[str,Any]]) -> dict[str,Any]:
        d:dict[str,Any]={}
        for k,v in xs:
            if k in d:
                raise ValueError('duplicate JSON key')
            d[k]=v
        return d
    data=json.loads(path.read_text(),object_pairs_hook=pairs,
                    parse_constant=lambda s: (_ for _ in ()).throw(ValueError('nonfinite JSON')))
    if not isinstance(data,list) or len(data)>100:
        raise ValueError('bounded certificate list required')
    return [verify(x) for x in data]


if __name__=='__main__':
    import sys
    p=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parents[1]/'results/allocation_cases.json'
    print(json.dumps(load(p),indent=2))
