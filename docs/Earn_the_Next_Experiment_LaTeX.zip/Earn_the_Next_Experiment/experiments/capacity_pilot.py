"""Exact local laboratory for an improvement-for-capacity pilot; no external actions."""
from __future__ import annotations
import hashlib
import itertools
import json
from fractions import Fraction
from pathlib import Path
from typing import Any

SCHEMA = 'ifc-reference-certificate/v1'
SCOPE = 'synthetic-exact; not provider delivery'


def digest(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def credit(gain: int, numerator: int, denominator: int, cap: int) -> int:
    vals = (gain, numerator, denominator, cap)
    if any(type(v) is not int for v in vals) or denominator <= 0 or min(gain, numerator, cap) < 0 or numerator > denominator:
        raise ValueError('nonnegative integer terms and share in [0,1] required')
    return min(cap, gain * numerator // denominator)


def participation(delta: Fraction, provider_unit_value: Fraction, network_unit_value: Fraction,
                  delivery_fraction: Fraction, provider_cost: Fraction, network_cost: Fraction) -> dict[str, Any]:
    if min(delta, provider_unit_value, network_unit_value, delivery_fraction) <= 0 or delivery_fraction > 1:
        raise ValueError('positive scale and values required, with delivery fraction at most one')
    if min(provider_cost, network_cost) < 0:
        raise ValueError('costs must be nonnegative')
    lo = network_cost / (delta * delivery_fraction * network_unit_value)
    hi = 1 - provider_cost / (delta * provider_unit_value)
    return {'lower': str(max(Fraction(0), lo)), 'upper': str(min(Fraction(1), hi)),
            'feasible': max(Fraction(0), lo) <= min(Fraction(1), hi)}


def request() -> dict[str, Any]:
    return {'id': 'mission-B', 'duration': 3, 'cpu': 1, 'memory': 1, 'hardware': 'reference-cpu',
            'release': 9, 'deadline': 17, 'preemptible': False,
            'purpose': 'evaluate a frozen public finite-model planning task'}


def case(name: str = 'aligned') -> dict[str, Any]:
    g = [2, 2, 2, 2, 1, 1, 1, 1]
    base = {
        'schema': 'ifc-reference-case/v1', 'scope': SCOPE, 'name': name,
        'evidence': {'primary_outcomes_preserved': True, 'confirmation_passed': True,
                     'baseline_cpu': 32, 'candidate_cpu': 18, 'incremental_overhead_cpu': 2,
                     'epoch_closed': 8, 'method': 'supplied-reformulation',
                     'seed_resources': {'cpu_units': 5, 'cash': 'not measured', 'human_time': 'not measured'}},
        'agreement': {'share_num': 1, 'share_den': 4, 'credit_cap': 3,
                      'provider_consented': True, 'issued': 8, 'expires': 17,
                      'hardware': 'reference-cpu', 'unit': 'reference CPU-slot',
                      'convert_earned_to_future': 'explicit assumed 1:1 service agreement'},
        'calendar': {'times': list(range(9, 17)), 'cpu_capacity': [4]*8, 'memory_capacity': [4]*8,
                     'primary_cpu': [4-x for x in g], 'primary_memory': [3]*8,
                     'incremental_release_cpu': g, 'prior_awards_cpu': [0]*8,
                     'prior_awards_memory': [0]*8,
                     'auxiliary_memory_origin': 'provider-authorized existing headroom; not created by the improvement'},
        'request': request(),
    }
    if name == 'fragmented':
        g = [3, 0, 3, 0, 3, 0, 3, 0]
        base['calendar']['incremental_release_cpu'] = g
        base['calendar']['primary_cpu'] = [4-x for x in g]
    elif name == 'memory-bound':
        base['calendar']['primary_memory'] = [4]*8
    elif name == 'expired':
        base['agreement']['expires'] = 9
    elif name == 'wrong-hardware':
        base['request']['hardware'] = 'required-gpu'
    elif name == 'quality-regression':
        base['evidence']['primary_outcomes_preserved'] = False
    elif name == 'unconfirmed':
        base['evidence']['confirmation_passed'] = False
    elif name == 'overhead-erases-gain':
        base['evidence']['incremental_overhead_cpu'] = 14
    elif name == 'no-consent':
        base['agreement']['provider_consented'] = False
    elif name == 'pre-existing-idle-only':
        base['evidence']['candidate_cpu'] = 30
    elif name == 'already-committed':
        base['calendar']['prior_awards_cpu'] = g
    elif name == 'fragmented-preemptible':
        base = case('fragmented')
        base['name'] = name
        base['request']['preemptible'] = True
    elif name != 'aligned':
        raise ValueError('unknown supplied case')
    return base


def allocation(c: dict[str, Any]) -> dict[str, Any]:
    e, a, k, r = (c[x] for x in ('evidence', 'agreement', 'calendar', 'request'))
    gain = max(0, e['baseline_cpu'] - e['candidate_cpu'] - e['incremental_overhead_cpu'])
    gate = e['primary_outcomes_preserved'] and e['confirmation_passed'] and a['provider_consented']
    earned = credit(gain, a['share_num'], a['share_den'], a['credit_cap']) if gate else 0
    selected: list[int] = []
    if gate and r['hardware'] == a['hardware'] and r['cpu'] * r['duration'] <= earned:
        indices = range(len(k['times']))
        options = itertools.combinations(indices, r['duration']) if r['preemptible'] else (
            tuple(range(i, i+r['duration'])) for i in range(len(k['times'])-r['duration']+1))
        for opt in options:
            okay = True
            for i in opt:
                t = k['times'][i]
                okay &= (t >= max(r['release'], a['issued']+1) and t < min(r['deadline'], a['expires'])
                         and k['incremental_release_cpu'][i] - k['prior_awards_cpu'][i] >= r['cpu']
                         and k['primary_cpu'][i] + k['prior_awards_cpu'][i] + r['cpu'] <= k['cpu_capacity'][i]
                         and k['primary_memory'][i] + k['prior_awards_memory'][i] + r['memory'] <= k['memory_capacity'][i])
            if okay:
                selected = [k['times'][i] for i in opt]
                break
    delivered = len(selected) * r['cpu']
    return {'schema': SCHEMA, 'scope': SCOPE, 'case': c, 'case_digest': digest(c),
            'gain': gain, 'earned_credit': earned, 'allocated_times': selected,
            'model_delivered_cpu': delivered, 'remaining_credit': earned-delivered,
            'primary_preserved': e['primary_outcomes_preserved'],
            'real_provider_delivery': False, 'actual_native_settlement': None,
            'child_result': None}


def census() -> dict[str, int]:
    total = possible = 0
    for g in itertools.product(range(4), repeat=8):
        if sum(g) != 12:
            continue
        c = case()
        c['calendar']['incremental_release_cpu'] = list(g)
        c['calendar']['primary_cpu'] = [4-x for x in g]
        cert = allocation(c)
        total += 1
        possible += bool(cert['allocated_times'])
    return {'profiles': total, 'feasible': possible, 'infeasible': total-possible,
            'horizon': 8, 'total_release_each': 12, 'credit_each': 3,
            'duration': 3}


# A separately predeclared child task. The selection method is ordinary dynamic programming.
def child_task() -> dict[str, Any]:
    items = [(3, 5), (4, 6), (5, 8), (8, 12), (9, 13), (2, 3), (6, 9), (7, 11)]
    budget = 17
    table = [[0]*(budget+1) for _ in range(len(items)+1)]
    for i, (cost, value) in enumerate(items, 1):
        for b in range(budget+1):
            table[i][b] = table[i-1][b]
            if cost <= b:
                table[i][b] = max(table[i][b], table[i-1][b-cost]+value)
    selection: list[int] = []
    b = budget
    for i in range(len(items), 0, -1):
        if table[i][b] != table[i-1][b]:
            selection.append(i-1)
            b -= items[i-1][0]
    return {'task': 'finite resource allocation', 'items': items, 'budget': budget,
            'selected_indices': sorted(selection), 'value': table[-1][-1],
            'algorithm': 'supplied dynamic programming',
            'scope': 'real local arithmetic; virtual resource schedule, not external delivery'}


def run(out: Path) -> None:
    out.mkdir(parents=True, exist_ok=True)
    names = ['aligned', 'fragmented', 'memory-bound', 'expired', 'wrong-hardware', 'quality-regression',
             'unconfirmed', 'overhead-erases-gain', 'no-consent', 'pre-existing-idle-only',
             'already-committed', 'fragmented-preemptible']
    records = [allocation(case(n)) for n in names]
    for rec in records:
        if rec['allocated_times']:
            rec['child_result'] = child_task()
    summary = [{'name': r['case']['name'], 'gain': r['gain'], 'credit': r['earned_credit'],
                'times': r['allocated_times'], 'model_delivered_cpu': r['model_delivered_cpu'],
                'child_value': r['child_result']['value'] if r['child_result'] else None} for r in records]
    economics = []
    for d in [Fraction(1), Fraction(1, 2), Fraction(1, 4), Fraction(1, 8)]:
        economics.append({'delivery_fraction': str(d), **participation(Fraction(12), Fraction(2), Fraction(3), d, Fraction(6), Fraction(6))})
    result = {'scope': SCOPE, 'cases': summary, 'census': census(), 'participation': economics,
              'seed_cost_recovered': False, 'notes': '5 seed CPU units exceed 3 model-delivered CPU units; cash and labor unmeasured'}
    for fn, data in [('allocation_cases.json', records), ('allocation_summary.json', result)]:
        (out/fn).write_text(json.dumps(data, indent=2, sort_keys=True, allow_nan=False)+'\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    import argparse
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=Path(__file__).resolve().parents[1]/'reproduced_exact')
    args=parser.parse_args()
    run(args.output)
