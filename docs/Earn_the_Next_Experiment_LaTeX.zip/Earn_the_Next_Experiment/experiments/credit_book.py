"""Single-process accounting reference, not a distributed provider authority."""
from __future__ import annotations
from threading import RLock


class LocalCreditBook:
    def __init__(self, issued: int):
        if type(issued) is not int or issued < 0:
            raise ValueError('invalid issued credit')
        self.issued=issued
        self.records:dict[str,dict[str,int|str]]={}
        self.lock=RLock()

    def snapshot(self) -> dict[str,int]:
        with self.lock:
            reserved=sum(int(r['reserved']) for r in self.records.values() if r['state']=='reserved')
            consumed=sum(int(r['used']) for r in self.records.values() if r['state']=='closed')
            return {'issued':self.issued,'reserved':reserved,'consumed':consumed,
                    'available':self.issued-reserved-consumed}

    def reserve(self, key: str, amount: int) -> None:
        if type(key) is not str or not 0<len(key)<=128 or type(amount) is not int or amount<=0:
            raise ValueError('bounded identity and positive integer amount required')
        with self.lock:
            if key in self.records:
                r=self.records[key]
                if r['state']=='reserved' and r['reserved']==amount:
                    return
                raise ValueError('operation identity already consumed or changed')
            if amount>self.snapshot()['available']:
                raise ValueError('insufficient uncommitted credit')
            self.records[key]={'state':'reserved','reserved':amount,'used':0}

    def close(self, key: str, used: int) -> None:
        if type(used) is not int or used<0:
            raise ValueError('invalid measured use')
        with self.lock:
            if key not in self.records:
                raise ValueError('unreserved operation')
            r=self.records[key]
            if r['state']=='closed':
                if r['used']==used:
                    return
                raise ValueError('inconsistent terminal record')
            if used>int(r['reserved']):
                raise ValueError('use exceeds reservation')
            r['used']=used
            r['state']='closed'
