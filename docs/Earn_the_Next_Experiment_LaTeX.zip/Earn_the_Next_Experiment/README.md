# Earn the Next Experiment
## Transformational Intelligence through an Improvement-for-Capacity Pilot

Vincent Boucher · MONTREAL.AI · October 2026

Project: https://github.com/MontrealAI/AGI-Alpha-Agent-v0

**Find your Alpha. Build your SUCCESSOR Ω.**

The paper specifies one pilot: improve a willing provider's public-input computational workload, independently establish the gain, receive a bounded service allocation under agreed terms, and use the actually delivered capacity on a second mission.

The supplied strategy is the conceptual basis. The formal model, reference code, local measurements, and operating templates are new additions. They are not a report of an external agreement or of Alpha autonomously discovering a new algorithm.

## Read and build

`Earn_the_Next_Experiment.pdf` is the paper. Its LaTeX source is standalone, with embedded tables and bibliography, no external figures or font files.

```sh
latexmk -pdf Earn_the_Next_Experiment.tex
```

## Reproduce

The exact laboratory and its checks use Python's standard library. The full suite also requires NumPy and SciPy. Recorded execution: Python 3.13.5, NumPy 2.3.5, SciPy 1.17.0 on Linux x86-64. Dependency versions are observations, not a replacement for Alpha's dependency locks.

```sh
python reproduce.py --exact-only
python reproduce.py
```

The first command runs 56 standard-library tests. The second runs all 64 tests, including the numerical-output checks. Both regenerate the two exact JSON results in a temporary directory, compare them byte-for-byte with retained evidence, and check all 12 case certificates.

New timings are optional and never overwrite the supplied benchmark:

```sh
python reproduce.py --benchmark-output /path/to/new/benchmark-directory
```

Direct commands are also available:

```sh
python experiments/capacity_pilot.py --output reproduced_exact
python experiments/verify_capacity.py reproduced_exact/allocation_cases.json
python experiments/numerical_workload.py --output reproduced_benchmark
```

The timing output directory must not already contain `numerical_benchmark.json`. Timings vary across runs and environments. Only the exact allocation outputs are expected to reproduce byte-identically.

## What the results mean

The exact model supplies 12 reference CPU units of gain, a 25% share, and a 3-credit cap. An aligned future calendar runs the 3-slot descendant; equal-total fragmented capacity cannot. All 8,092 profiles with eight entries in `{0,1,2,3}` summing to 12 are enumerated: 7,426 feasible, 666 infeasible for the fixed task. The proportion is not a real-world success estimate.

The local numerical study executes repeated positive-definite linear systems. Retaining a factor helps on repeated requests, but the ordinary batched library baseline is faster. No local millisecond is converted into modeled credit.

The child task's dynamic-programming result is independently verified against all 256 subsets. Its arithmetic is real; its 3-slot resource charge is virtual. The single-process credit book is neither a distributed ledger nor a provider-authority service.

## Practical files

- `PILOT_PLAYBOOK.md`: counterparties, gates, terms, experiments, delivery, closure.
- `IMPLEMENTATION_HANDOFF.md`: additive Alpha increment, responsibilities, acceptance.
- `templates/pilot_charter.json`: explicit null fields for genuinely missing parties and approvals.
- `CLAIMS.md`: supported claims, limitations, next empirical evidence.
- `source_notes/`: unchanged supplied brief and research provenance.
- `MANIFEST.sha256`: final file-integrity ledger, not a signature or semantic proof.

## Status

No external provider has been recruited or paid; no service agreement signed; no provider capacity earned or redeemed; no actual $AGIALPHA settlement observed. No repository, release, contract, wallet, ENS record, or prior paper was modified. The source is a research reference and proposed implementation guide, not a drop-in production adapter or security sandbox.
