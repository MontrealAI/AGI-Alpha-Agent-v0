"""Verify the supplied exact reference results and run the test suite without replacing evidence."""
from __future__ import annotations
import argparse
import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'experiments'))
from capacity_pilot import run
from verify_capacity import load

def main() -> int:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--exact-only',action='store_true',help='omit optional numerical tests; standard library only')
    parser.add_argument('--benchmark-output',type=Path,help='also run timings into a fresh output directory')
    args=parser.parse_args()
    comparisons=[]
    with tempfile.TemporaryDirectory(prefix='ifc-reproduction-') as d:
        out=Path(d)
        with contextlib.redirect_stdout(io.StringIO()):run(out)
        for name in ('allocation_cases.json','allocation_summary.json'):
            original=(ROOT/'results'/name).read_bytes(); fresh=(out/name).read_bytes()
            if original!=fresh:raise RuntimeError('exact reproduction differs: '+name)
            comparisons.append({'file':name,'sha256':hashlib.sha256(fresh).hexdigest(),'byte_identical':True})
        verdicts=load(out/'allocation_cases.json')
    env=os.environ.copy()
    for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):env[k]='1'
    pattern='test_pilot.py' if args.exact_only else 'test*.py'
    result=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-p',pattern,'-v'],cwd=ROOT,env=env,check=False)
    if result.returncode:return result.returncode
    if args.benchmark_output:
        subprocess.run([sys.executable,str(ROOT/'experiments/numerical_workload.py'),'--output',str(args.benchmark_output.resolve())],env=env,check=True)
    print(json.dumps({'exact_comparisons':comparisons,'certificates_checked':len(verdicts),
                      'scope':'reference reproduction, not external pilot qualification'},indent=2))
    return 0
if __name__=='__main__':raise SystemExit(main())
