# Proposed Alpha / SUCCESSOR Ω improvement-for-capacity increment

## Goal

Extend the existing project history with one admitted numerical task type, one real provider service adapter, and a two-epoch measurement-to-delivery workflow. Preserve existing modes and source/release security qualification. This document is not authorization to modify an active owner branch or publish a release.

Inspected Alpha main: `b44ba296e00500c91c1617fc942b5f0050ceabd6`. The inspected `docs/agent/SUCCESSOR_ALPHA.md` has blob `934159007cadd01e3d4c83f9ac8c8ebf67749b72`. Its browser/native Computer Use path distinguishes proposals from executed patches, provider results, and economic benefits. These snapshot observations do not establish a capacity exchange adapter.

## Reuse and add

Reuse the existing project identity, history/recovery, source binding, controlled native execution, and explicit commissioning where their qualified versions support the task. Avoid a parallel journal and second token.

Proposed records: `PrimaryPurpose`, `DescendantPurpose`, `ImprovementEvidence`, `ServiceAgreement`, `ServiceEntitlement`, `CapacityReservation`, `ConsumptionReceipt`, `DescendantOutcome`.

Each record includes schema, project/mission/epoch identity, source/environment identities, observed versus proposed status, linked evidence, actual approval origin, and current scope. A digest binds bytes, not semantic truth or authority. Unknown parties and approval fields remain null in preparation.

## State machine

`DRAFT -> TERMS_ACCEPTED -> DEVELOPMENT -> FROZEN -> CONFIRMATION -> GAIN_ACCEPTED -> CREDIT_EARNED -> RESERVED -> RUNNING -> CONSUMPTION_RECONCILED -> OUTCOME_REVIEWED`.

Every state also permits an appropriate rejected, failed, interrupted, disputed, or expired terminal/recovery path. Historical imports cannot restore active permissions. States must distinguish technical review from provider agreement, actual delivery, and beneficiary acceptance.

## Task A adapter

Start with one genuinely material public numerical workload. Proposed laboratory type: repeated SPD linear systems. Bind actual matrix content, dimensions, dtype, right-hand-side identity, expected outputs, residual/conditioning requirements, memory, concurrency, latency, and library environment. Allow a strong grouped/batched solver baseline to win. The provided numerical code is a control, not an autonomous model adapter.

Model proposals are data. Constructed programs require the existing qualified isolated execution path. No arbitrary host execution or provider credential collection is introduced. Code inspection in Chromium is not code execution.

## Provider adapter

Resolve missing provider/service API fields before implementation. Use approved external-app tools where available. Require accepted service terms and capacity calibration, one-use/exclusive reservation semantics, actual image/hardware/memory and time windows, metered consumption, idempotent update identifiers, interruption accounting, and expiry/recovery.

The local `credit_book.py` is intentionally insufficient for this component: it lacks persistence, distributed transaction control, external identity, provider API, and crash-safe telemetry. Do not deploy it as a provider service.

## User-facing view

English/French labels must make actual state unambiguous: proposal; benefit independently checked; service earned; reserved; delivered/consumed; second mission reviewed. Retain failures, costs, unpaid obligations, scopes, and instructions for reopening a portable history.

## Required acceptance

Run actual task A and strong comparisons, fresh confirmation, real reservation and expiry/refusal, partial-use failure and reconciliation, exact installed task B execution, independent output checks, full history reopen, and source/version readback. Required security, package, native, browser and publication gates remain intact.

Provider identity, signed terms, independent evaluator, seed budget, and delivery API are not supplied by this package. No current token, ENS policy, deployed contract, original paper, historical release, caller limit, or zero-allowance request is changed. AGIJobManager USDC and Alpha/Jobs-v0 AGIALPHA routes remain separate. No native settlement is claimed without its actual authorized transaction and evidence.

## Completion

One real external provider has retained an independently measured benefit, fulfilled an earned service allocation, and that actual allocation has supported a separately specified accepted descendant artifact. Costs and nonclaims remain explicit. This is an empirical milestone, not a claim of general transformational intelligence or token valuation.
