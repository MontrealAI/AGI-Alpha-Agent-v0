# Claim–evidence register

| Claim | Evidence in this package | Boundary |
|---|---|---|
| Resource acquisition can be made part of a bounded discovery mission | Paper protocol and nonbinding charter/playbook | Proposed external pilot, not completed |
| Equal aggregate release can have different usefulness | Exact profiles `(2,2,2,2,1,1,1,1)` and `(3,0,3,0,3,0,3,0)` | Fixed nonpreemptible three-slot descendant |
| Same credit can yield 3 modeled units or zero | Exact certificates and separate per-slot checker | Virtual schedule, not actual provider delivery |
| Complete census has 8,092 profiles, 7,426 feasible, 666 infeasible | All vectors in `{0,1,2,3}^8` summing to 12; independent subset oracle | No population inference or AI discovery trials |
| Retained factorization beats repeated reconstruction on tested batched inputs | Recorded raw elapsed timings and residual/reference-output checks | Supplied known method, not an AI invention; local kernel only |
| A stronger available control beats the proposed method | Batched library timings in all recorded cases | No general performance or business claim |
| Child result value 27 is correct | Actual dynamic programming; brute force all 256 subsets | Its nominal capacity charge is modeled, not metered |
| Local credit handling rejects tested duplicate/excess/conflicting uses | Local book and unit/concurrency tests | Single process, not durable distributed service or security audit |
| Positive model outcome repays seed | Not supported: 5 seed CPU units > 3 modeled delivered | Monetary and human costs unmeasured |
| Tests pass | 64 unittest methods in recorded environment; 56 standard-library-only methods | Tests establish their specified computations, not source truth |
| Exact results reproduce | Byte comparison of two deterministic JSON result files; all 12 certificates checked | Timing observations are not expected to be byte-identical |
| Integration exists in Alpha | Not supported; inspected snapshot plus proposed additive map | No repository writes, no releases, no installed provider adapter |
| $AGIALPHA gains demand or value | No evidence supplied | Separate empirical commercial step; no rights or valuation promise |

The supplied brief is preserved byte-for-byte in source_notes. New research synthesis, mathematics, code, data and local experiments are this manuscript's additions. External sources inform related work and methodology, not fabricated project results.
