# Transformational Intelligence: Learning to Change the Game

**Vincent Boucher · MONTREAL.AI · October 2026**

The central question is not only how an AI can find a better answer, but how it can discover that the original problem-solving setup is unnecessarily restrictive, construct a better one, and demonstrate its value under the purpose that justified the work.

## Read the paper

`Transformational_Intelligence.pdf` is the compiled manuscript. `Transformational_Intelligence.tex` is standalone: its bibliography is embedded, and its diagram is drawn with TikZ. No external images or bibliography file are required to compile it. `references.bib` is an editable companion for other publication workflows.

## What is demonstrated

The package executes an exact finite synthetic calculation, not a frontier-model experiment. In a specified two-world causal-identification model, passive observations cannot identify the world with greater than 50% prior-averaged accuracy. A permitted intervention policy attains 8191/8192 accuracy with at most twelve queries. A standard unrestricted optimal planner achieves the same result.

The model family, prior, action set, and frame distinction are supplied by the investigator. The program does not autonomously invent them. Its purpose is to distinguish a provable information restriction from weak reasoning, and to make the costs and controls explicit.

The general architecture, book-understanding study, benchmark families, and transfer claims are proposed research. They are not completed autonomous-discovery or deployment results.

## Reproduce the computation

Use Python 3.10 or newer; the released artifact was checked with Python 3.13.5. Only the Python standard library is required.

```bash
python -m unittest -v
python frame_lab.py --out results
```

The released suite contains **50 passing tests**. These exercise exact model behavior, Bellman/closed-form agreement, exhaustive trace enumeration, cost-sensitive stopping, negative controls, permission checks, complementary edits, statistical arithmetic, and selected invalid inputs. They do not establish model realism, general AI capability, or the security of a production system.

`frame_lab.py` writes `results/results.json` and `results/accuracy.csv`. Fractions in the JSON retain both exact and decimal forms. `results/tests.txt` records the executed test suite; elapsed time is machine-dependent. `results/run_output.txt` retains the console report.

Enumeration is deliberately bounded. The manuscript uses horizons 0, 1, 2, 4, 8, and 12. Each horizon m enumerates both worlds and all 2^m latent-bit sequences, including unused suffixes after early stopping. There are 8,192 equally weighted traces at m = 12. The policies never observe the latent bit or the hidden world label.

## Build the PDF

A TeX Live installation with `newtx`, TikZ, `natbib`, `algorithm`, `algpseudocode`, `microtype`, and the other packages named in the source is needed. No BibTeX run is necessary.

```bash
pdflatex -interaction=nonstopmode -halt-on-error Transformational_Intelligence.tex
pdflatex -interaction=nonstopmode -halt-on-error Transformational_Intelligence.tex
```

An additional run can be needed after substantial layout or cross-reference changes. The Makefile also supplies `make test`, `make results`, `make paper`, and `make clean` targets. Building the same content at another time may produce different PDF bytes because of metadata and TeX-environment differences; compare content as well as checksums.

## Navigate the contribution

The opening sections define the transformation and demonstrate a formulation-dependent information ceiling. The middle sections specify discovery of new formulations, complementary changes, purpose-preserving demonstrations, and accountable evaluator revision. The experimental sections distinguish better answers, better strategies, better discovery procedures, and genuine structural changes. The appendices provide exact derivations, statistical assumptions, a detailed book-understanding protocol, and transformation-record requirements.

See `CLAIMS_AND_EVIDENCE.md` for the status of each principal claim, and `REVISION_NOTES.md` for the substantive changes from the earlier strategy-discovery manuscript. `reference_metadata.json` mirrors the bibliography for editing; it is not an external review or a source-authenticity certificate.

## Scope and publication status

This is a research manuscript with a deterministic illustrative computation. No frontier-model performance, autonomous scientific novelty, real-world deployment, or external peer review is claimed. The causal distinction and statistical tools have established antecedents cited in the paper. The contribution is an operational synthesis and experimental program, supported by a transparent finite example.

Checksums in `MANIFEST.sha256` identify the released files. They establish byte identity, not scientific validity or experimental independence. No font files are distributed.
