# Claim–evidence register

This register distinguishes mathematical statements, executed computations, and proposed research. It is not an independent peer-review report.

| Claim | Evidence supplied | Scope and limits |
|---|---|---|
| Passive identification is at most 1/2 in the two-world example. | Theorem 3.1: both worlds induce the same passive transcript law; the uniform-prior calculation applies to any decision rule. | Requires the supplied model, independent initial information/randomness, and unconditional scoring. It is not a limit on all causal-identification tasks. |
| The active policy has accuracy 1 − 2^(−m−1). | Analytic derivation; exact Bellman recursion; independent trajectory enumeration using the simulator execution kernel. | Hypotheses, intervention set, and prior are supplied. No autonomous invention is demonstrated. |
| Expected active queries equal m/2 + 1 − 2^(−m). | Analytic geometric-series argument and exhaustive execution. | Fresh independent latent bits; stop at first disagreement or cap. Setup and model-acquisition costs are not included. |
| At m = 12, active accuracy is 8191/8192, with expected queries 28671/4096. | `results/results.json`, `accuracy.csv`, tests, and the paper's exact-results table. | Exact finite computation over 8,192 traces, not a sample of LLM performance. |
| The unrestricted optimal baseline matches the active policy. | Full-action Bellman optimizer and closed-form comparison. | This prevents interpreting the illustrative policy as a new improvement over optimal experimental design. |
| Action cost can make a shorter experiment or immediate stopping optimal. | Loss formula and decreasing marginal thresholds; exact cost table; threshold-tie tests. | The cost is expected query count in error-loss units, not measured operational lifecycle cost. |
| Uninformative transformations need not be adopted. | A changed null response kernel makes both labels observationally and interventionally identical; the planner stops. | A separate synthetic control, not the original causal model. |
| Unauthorized interventions are rejected in the reference code. | Action-set validation and direct execution/likelihood permission tests. | A small in-process reference check, not a production isolation or security guarantee. |
| Some beneficial joint changes are unreachable by accepting only improving single edits. | Constructed two-edit value function and exact tests: each single edit −1/8; both +1/2. | An elementary existence example, not proof that any particular exploration algorithm scales. |
| Fresh fixed-sample confirmation can control false promotions across adaptive proposals. | Appendix B theorem derived from Hoeffding's inequality and a union bound. | Conditional independence, bounded scores, prior freezing, and valid error accounting are essential. This does not validate the evaluator itself. |
| Per-policy measurement bias bounded by epsilon can reduce a claimed gain by 2 epsilon. | Direct inequality in Appendix B and a constructed arithmetic check. | The epsilon bound must be justified independently; no calibration study is claimed. |
| A new formulation can make verification cheaper. | Lifecycle accounting condition and proposed experiments. | A hypothesis and break-even identity, not measured savings. |
| An AI can learn transferable formulation-discovery skills. | Proposed campaign-level, factorial, and held-out-mechanism experiments. | Not demonstrated by this artifact. |
| Revising an inadequate evaluator can reveal useful solutions. | Proposed independently controlled instrument-change protocol. | Not a completed evaluator-comparison experiment; outcomes still require a valid bridge to purpose. |
| Source-first or interactive book understanding can outperform summary-then-critique. | Detailed prospective protocol with two distinct authorized charters, controls, and outcomes. | No reader study or frontier-model evaluation was run. |

## Artifact checks actually performed

The Python suite ran successfully with 50 tests. The released exact result tables were regenerated. LaTeX was compiled with all citations and cross-references resolved; the PDF was rendered and visually inspected. These checks address the supplied artifacts. They do not constitute external peer review or a machine-checked proof of every mathematical statement.
