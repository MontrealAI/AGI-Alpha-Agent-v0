# Substantive revision from the earlier strategy-discovery paper

The previous manuscript treated evidence-gated strategy discovery as the main architecture, with transformational intelligence as one extension. This revision changes the object of the paper.

**The formulation becomes the central object of invention.** The paper asks how an AI recognizes an unnecessarily restrictive representation, information policy, dependency structure, production process, task boundary, or measurement instrument. Verification supports discovery instead of defining the entire research agenda.

**A transformation can remove a task or narrow a search space.** Changing the game is not equated with adding more agents, more tools, or a larger search space. A useful reduction or an authorized change from an inherited artifact to its underlying purpose may be more consequential.

**The evaluator is no longer treated as permanently fixed.** Inadequate instruments can be challenged and revised through independent validation, authorization, and common-outcome comparisons. A candidate cannot approve itself by selecting an easier judge.

**The core distinction has an exact example.** A known two-world model makes the old-frame information limit provable and the intervention gain exactly computable. The ordinary unrestricted optimal planner is included and matches the result. The example therefore demonstrates the structural distinction without claiming autonomous discovery or a novel causal algorithm.

**Discovery may require complementary changes.** A constructed example shows why accepting only immediately improving single edits can block a beneficial combination. Exploratory alternatives are distinguished from deployment-approved methods.

**Evaluation targets causal attribution and transfer.** The revised protocol includes strong unrestricted baselines, frame/solver factorial comparisons, mechanism interventions, true-constraint negative controls, lifecycle cost, and independently replicated discovery campaigns.

**The original book example is reframed at the level of purpose.** The appendix distinguishes a strict request for a summary from a broader authorized goal of understanding. A different artifact is permissible only in the latter case or after explicit amendment.

**The evidence status remains explicit.** The artifact contains derivations and an executed finite calculation with tests. It does not claim general transformational intelligence, completed frontier-model experiments, or external peer review.
