from __future__ import annotations
import argparse, csv, json, math
from dataclasses import dataclass
from fractions import Fraction as F
from functools import lru_cache
from itertools import product
from pathlib import Path

ACTIONS = ('observe', 'do0', 'do1')
WORLDS = ('cause', 'confounded')


def require_int(value: int, minimum: int = 0, maximum: int | None = None) -> None:
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum or (maximum is not None and value > maximum):
        raise ValueError('Integer outside the permitted range')


def require_probability(value: float, strict: bool = False) -> None:
    if not math.isfinite(value) or (not 0 < value < 1 if strict else not 0 <= value <= 1):
        raise ValueError('Invalid probability')


@dataclass(frozen=True)
class Experiment:
    informative: bool = True
    permissions: tuple[str, ...] = ACTIONS

    def __post_init__(self) -> None:
        if not isinstance(self.informative, bool):
            raise ValueError('informative must be boolean')
        if len(set(self.permissions)) != len(self.permissions) or any(a not in ACTIONS for a in self.permissions):
            raise ValueError('Invalid permission set')

    def likelihood(self, action: str, outcome: int, world: str) -> F:
        if action not in self.permissions:
            raise PermissionError(f'Unauthorized action: {action}')
        if outcome not in (0, 1) or world not in WORLDS:
            raise ValueError('Invalid outcome or world')
        if action == 'observe' or world == 'confounded' or not self.informative:
            return F(1, 2)
        return F(int(outcome == int(action[-1])))

    def execute(self, action: str, world: str, latent: int) -> int:
        if action not in self.permissions:
            raise PermissionError(f'Unauthorized action: {action}')
        if world not in WORLDS or latent not in (0, 1):
            raise ValueError('Invalid simulation input')
        if action == 'observe' or world == 'confounded' or not self.informative:
            return latent
        return int(action[-1])


@dataclass(frozen=True)
class Plan:
    action: str
    risk: F
    expected_queries: F
    loss: F


def make_planner(experiment: Experiment, frame_actions: tuple[str, ...], query_cost: F = F(0)):
    if not isinstance(query_cost, F) or query_cost < 0:
        raise ValueError('query_cost must be a nonnegative Fraction')
    if len(set(frame_actions)) != len(frame_actions) or any(a not in ACTIONS for a in frame_actions):
        raise ValueError('Invalid frame')
    if not set(frame_actions).issubset(experiment.permissions):
        raise PermissionError('A frame cannot expand the permission set')

    @lru_cache(maxsize=None)
    def solve(p: F, remaining: int) -> Plan:
        if not isinstance(p, F) or not 0 <= p <= 1:
            raise ValueError('Belief must be a Fraction in [0,1]')
        require_int(remaining, 0, 32)
        stop = 'guess_cause' if p >= F(1, 2) else 'guess_confounded'
        risk = min(p, 1-p)
        options = [Plan(stop, risk, F(0), risk)]
        if remaining:
            for action in frame_actions:
                risk, queries = F(0), F(1)
                for outcome in (0, 1):
                    lc = experiment.likelihood(action, outcome, 'cause')
                    lf = experiment.likelihood(action, outcome, 'confounded')
                    q = p*lc + (1-p)*lf
                    if q:
                        child = solve(p*lc/q, remaining-1)
                        risk += q*child.risk
                        queries += q*child.expected_queries
                options.append(Plan(action, risk, queries, risk+query_cost*queries))
        return min(options, key=lambda plan: (plan.loss, plan.expected_queries, plan.action))

    return solve


def run_policy(experiment: Experiment, solve, world: str, latent: tuple[int, ...], prior: F = F(1, 2)) -> tuple[str, int]:
    if world not in WORLDS:
        raise ValueError('Invalid world')
    p, queries, horizon = prior, 0, len(latent)
    while True:
        plan = solve(p, horizon-queries)
        if plan.action.startswith('guess_'):
            return plan.action.removeprefix('guess_'), queries
        outcome = experiment.execute(plan.action, world, latent[queries])
        lc = experiment.likelihood(plan.action, outcome, 'cause')
        lf = experiment.likelihood(plan.action, outcome, 'confounded')
        q = p*lc+(1-p)*lf
        if not q:
            raise RuntimeError('Zero-probability observation')
        p, queries = p*lc/q, queries+1


def enumerate_policy(experiment: Experiment, solve, horizon: int) -> dict:
    require_int(horizon, 0, 16)
    correct, queries = 0, 0
    for world in WORLDS:
        for latent in product((0, 1), repeat=horizon):
            prediction, used = run_policy(experiment, solve, world, latent)
            correct += int(prediction == world)
            queries += used
    denominator = 2**(horizon+1)
    return {'accuracy': F(correct, denominator), 'expected_queries': F(queries, denominator), 'enumerated_traces': denominator}


def active_closed_form(horizon: int) -> tuple[F, F]:
    require_int(horizon, 0)
    return 1-F(1, 2**(horizon+1)), F(horizon, 2)+1-F(1, 2**horizon)


def error_allocation(alpha: float, attempt: int, claims: int = 1) -> float:
    require_probability(alpha, strict=True)
    require_int(attempt, 1)
    require_int(claims, 1)
    return alpha/(attempt*(attempt+1)*claims)


def lower_bound(mean: float, n: int, alpha: float) -> float:
    if not math.isfinite(mean) or not -1 <= mean <= 1:
        raise ValueError('Mean must be in [-1,1]')
    require_int(n, 1)
    require_probability(alpha, strict=True)
    return mean-math.sqrt(2*math.log(1/alpha)/n)


def corrected_bound(mean: float, n: int, alpha: float, calibration_error: float) -> float:
    require_probability(calibration_error)
    return lower_bound(mean, n, alpha)-2*calibration_error


def zero_failure_upper(n: int, beta: float) -> float:
    require_int(n, 1)
    require_probability(beta, strict=True)
    return -math.expm1(math.log(beta)/n)


def joint_value(edits: frozenset[str], gain: F = F(3, 4), setup: F = F(1, 8)) -> F:
    if not edits.issubset({'representation', 'checker'}) or gain < 0 or setup < 0:
        raise ValueError('Invalid complementary edit set')
    return (gain if len(edits) == 2 else F(0))-setup*len(edits)


def as_json(value):
    if isinstance(value, F):
        return {'exact': str(value), 'decimal': float(value)}
    if isinstance(value, dict):
        return {k: as_json(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [as_json(v) for v in value]
    return value


def build_results() -> dict:
    experiment = Experiment()
    passive = make_planner(experiment, ('observe',))
    active = make_planner(experiment, ACTIONS)
    rows = []
    for horizon in (0, 1, 2, 4, 8, 12):
        exact = enumerate_policy(experiment, active, horizon)
        expected_accuracy, expected_queries = active_closed_form(horizon)
        assert exact['accuracy'] == expected_accuracy and exact['expected_queries'] == expected_queries
        plan = active(F(1, 2), horizon)
        assert 1-plan.risk == exact['accuracy'] and plan.expected_queries == exact['expected_queries']
        rows.append({'horizon': horizon, 'passive_accuracy': 1-passive(F(1, 2), horizon).risk, **exact})
    cost_rows = []
    for query_cost in (F(0), F(1, 256), F(1, 64), F(1, 8), F(1, 4), F(1)):
        solve = make_planner(experiment, ACTIONS, query_cost)
        plan = solve(F(1, 2), 12)
        depths = tuple(m for m in range(13) if 1-active_closed_form(m)[0]+query_cost*active_closed_form(m)[1] == plan.loss)
        if not depths:
            raise AssertionError('Bellman and closed-form policies disagree')
        cost_rows.append({'query_cost': query_cost, 'max_horizon': 12, 'optimal_probe_caps': depths, 'action': plan.action,
                          'accuracy': 1-plan.risk, 'expected_queries': plan.expected_queries, 'loss': plan.loss,
                          'bellman_cache_states': solve.cache_info().currsize})
    null = make_planner(Experiment(informative=False), ACTIONS)
    try:
        make_planner(Experiment(permissions=('observe',)), ACTIONS)
        blocked = False
    except PermissionError:
        blocked = True
    return {'study_type': 'Exact finite synthetic calculation; no LLM calls; no autonomous discovery claim',
            'model': {'worlds': WORLDS, 'prior_cause': F(1,2), 'latent_probability': F(1,2),
                      'permissions_both_frames': ACTIONS, 'passive_frame': ('observe',), 'active_frame': ACTIONS,
                      'selection': 'Exact Bellman recursion; stop on equal loss when it uses fewer queries',
                      'scope': 'Known two-hypothesis model, at most 12 interaction steps; expected-query cost is not lifecycle cost'},
            'accuracy_table': rows, 'cost_table': cost_rows,
            'negative_controls': {'uninformative_interventions': {'accuracy': 1-null(F(1,2),12).risk,
                                   'queries': null(F(1,2),12).expected_queries},
                                  'unauthorized_frame_rejected': blocked,
                                  'unrestricted_optimal_baseline': 'The active Bellman planner is the unrestricted baseline; it exactly matches the transformed policy.'},
            'complementarity': {name: joint_value(frozenset(edits)) for name, edits in
                               [('neither', []), ('representation_only', ['representation']), ('checker_only', ['checker']),
                                ('both', ['representation', 'checker'])]},
            'inference_example': {'alpha_total': 0.05, 'attempt': 1, 'claims': 1,
                                  'per_claim_alpha': error_allocation(0.05,1), 'pairs': 2000, 'observed_gain': 0.10,
                                  'lcb': lower_bound(0.10,2000,error_allocation(0.05,1)),
                                  'calibration_epsilon': 0.01,
                                  'calibrated_lcb': corrected_bound(0.10,2000,error_allocation(0.05,1),0.01),
                                  'zero_failure_upper': zero_failure_upper(2000,0.025)}}


def main() -> None:
    parser = argparse.ArgumentParser(description='Reproduce exact synthetic results for the Transformational Intelligence paper.')
    parser.add_argument('--out', type=Path, default=Path(__file__).parent/'results')
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    results = build_results()
    (args.out/'results.json').write_text(json.dumps(as_json(results), indent=2)+'\n', encoding='utf-8')
    with (args.out/'accuracy.csv').open('w', newline='', encoding='utf-8') as stream:
        writer = csv.writer(stream)
        writer.writerow(['max_queries','passive_accuracy','active_accuracy','active_accuracy_exact','expected_queries','expected_queries_exact','enumerated_traces'])
        for row in results['accuracy_table']:
            writer.writerow([row['horizon'],float(row['passive_accuracy']),float(row['accuracy']),str(row['accuracy']),
                             float(row['expected_queries']),str(row['expected_queries']),row['enumerated_traces']])
    print(json.dumps(as_json(results), indent=2))


if __name__ == '__main__':
    main()
