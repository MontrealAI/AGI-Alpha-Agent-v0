import math, unittest
from fractions import Fraction as F
from itertools import product
from frame_lab import (ACTIONS, WORLDS, Experiment, active_closed_form, corrected_bound,
                       enumerate_policy, error_allocation, joint_value, lower_bound,
                       make_planner, require_int, run_policy, zero_failure_upper)


class FrameLabTests(unittest.TestCase):
    def test_01_observation_laws_identical(self):
        e = Experiment()
        for a in (0, 1): self.assertEqual(e.likelihood('observe',a,'cause'), e.likelihood('observe',a,'confounded'))
    def test_02_likelihoods_normalized(self):
        for informative, world, action in product((False,True),WORLDS,ACTIONS):
            self.assertEqual(sum(Experiment(informative).likelihood(action,y,world) for y in (0,1)), 1)
    def test_03_cause_interventions(self):
        e = Experiment()
        for a,u in product(('do0','do1'),(0,1)): self.assertEqual(e.execute(a,'cause',u),int(a[-1]))
    def test_04_confounder_interventions(self):
        for a,u in product(ACTIONS,(0,1)): self.assertEqual(Experiment().execute(a,'confounded',u),u)
    def test_05_passive_ceiling(self):
        solve = make_planner(Experiment(),('observe',))
        for n in range(13): self.assertEqual(solve(F(1,2),n).risk,F(1,2))
    def test_06_passive_stops(self):
        p = make_planner(Experiment(),('observe',))(F(1,2),12)
        self.assertEqual(p.expected_queries,0)
    def test_07_zero_horizon(self):
        self.assertEqual(active_closed_form(0),(F(1,2),F(0)))
    def test_08_one_probe(self):
        self.assertEqual(active_closed_form(1),(F(3,4),F(1)))
    def test_09_twelve_probes(self):
        self.assertEqual(active_closed_form(12),(F(8191,8192),F(28671,4096)))
    def test_10_exact_accuracy_all_caps(self):
        solve = make_planner(Experiment(),ACTIONS)
        for m in range(13): self.assertEqual(1-solve(F(1,2),m).risk,active_closed_form(m)[0])
    def test_11_exact_queries_all_caps(self):
        solve = make_planner(Experiment(),ACTIONS)
        for m in range(13): self.assertEqual(solve(F(1,2),m).expected_queries,active_closed_form(m)[1])
    def test_12_enumerated_replay(self):
        e = Experiment(); s = make_planner(e,ACTIONS)
        for m in range(9):
            r = enumerate_policy(e,s,m)
            self.assertEqual((r['accuracy'],r['expected_queries']),active_closed_form(m))
    def test_13_label_symmetry(self):
        e = Experiment()
        a,b = make_planner(e,('do0',)),make_planner(e,('do1',))
        for m in range(13): self.assertEqual(a(F(1,2),m).loss,b(F(1,2),m).loss)
    def test_14_including_observation_does_not_help(self):
        e = Experiment(); a,b = make_planner(e,('do0',)),make_planner(e,ACTIONS)
        for m in range(13): self.assertEqual(a(F(1,2),m).loss,b(F(1,2),m).loss)
    def test_15_known_cause_stops(self):
        self.assertEqual(make_planner(Experiment(),ACTIONS)(F(1),12).expected_queries,0)
    def test_16_known_confounder_stops(self):
        self.assertEqual(make_planner(Experiment(),ACTIONS)(F(0),12).expected_queries,0)
    def test_17_null_actions_do_not_help(self):
        p = make_planner(Experiment(False),ACTIONS)(F(1,2),12)
        self.assertEqual((p.risk,p.expected_queries),(F(1,2),F(0)))
    def test_18_permissions_reject_frame(self):
        with self.assertRaises(PermissionError): make_planner(Experiment(permissions=('observe',)),ACTIONS)
    def test_19_permissions_reject_execution(self):
        with self.assertRaises(PermissionError): Experiment(permissions=('observe',)).execute('do0','cause',0)
    def test_20_permissions_reject_likelihood(self):
        with self.assertRaises(PermissionError): Experiment(permissions=('observe',)).likelihood('do0',0,'cause')
    def test_21_cost_aware_stopping(self):
        p = make_planner(Experiment(),ACTIONS,F(1,64))(F(1,2),12)
        self.assertEqual((p.risk,p.expected_queries,p.loss),(F(1,64),F(111,32),F(143,2048)))
    def test_22_cost_aware_global_depth_check(self):
        for c in (F(0),F(1,256),F(1,64),F(1,8),F(1,4),F(1)):
            p = make_planner(Experiment(),ACTIONS,c)(F(1,2),12)
            values = [1-active_closed_form(m)[0]+c*active_closed_form(m)[1] for m in range(13)]
            self.assertEqual(p.loss,min(values))
    def test_23_expensive_actions_stop(self):
        for c in (F(1,4),F(1),F(10)):
            self.assertEqual(make_planner(Experiment(),ACTIONS,c)(F(1,2),12).expected_queries,0)
    def test_24_error_budget_telescopes(self):
        n = 10000
        self.assertAlmostEqual(sum(error_allocation(0.05,t) for t in range(1,n+1)),0.05*(1-1/(n+1)),12)
    def test_25_claim_budget(self):
        self.assertAlmostEqual(error_allocation(0.05,1,5),0.005)
    def test_26_lcb_example(self):
        self.assertAlmostEqual(lower_bound(.1,2000,.025),.03926385380916948,12)
    def test_27_calibration_lowers_gain(self):
        self.assertAlmostEqual(corrected_bound(.1,2000,.025,.01),lower_bound(.1,2000,.025)-.02)
    def test_28_sample_size_monotonicity(self):
        self.assertLess(lower_bound(.1,200,.025),lower_bound(.1,2000,.025))
    def test_29_smaller_alpha_is_stricter(self):
        self.assertLess(lower_bound(.1,2000,.005),lower_bound(.1,2000,.025))
    def test_30_zero_failure_formula(self):
        self.assertAlmostEqual(zero_failure_upper(2000,.025),1-.025**(1/2000),14)
    def test_31_complementarity_negative_singles(self):
        for name in ('representation','checker'): self.assertLess(joint_value(frozenset({name})),0)
    def test_32_complementarity_positive_pair(self):
        self.assertEqual(joint_value(frozenset({'representation','checker'})),F(1,2))
    def test_33_complementarity_noop(self): self.assertEqual(joint_value(frozenset()),0)
    def test_34_invalid_horizons(self):
        for n in (-1,True,1.2):
            with self.assertRaises(ValueError): active_closed_form(n)
    def test_35_invalid_probability(self):
        for a in (0,1,-.1,float('nan'),float('inf')):
            with self.assertRaises(ValueError): lower_bound(.1,20,a)
    def test_36_invalid_means(self):
        for d in (-2,2,float('nan'),float('inf')):
            with self.assertRaises(ValueError): lower_bound(d,20,.025)
    def test_37_invalid_n(self):
        for n in (0,-1,True,1.1):
            with self.assertRaises(ValueError): lower_bound(.1,n,.025)
    def test_38_invalid_query_cost(self):
        for c in (F(-1),.1,float('nan')):
            with self.assertRaises(ValueError): make_planner(Experiment(),ACTIONS,c)
    def test_39_invalid_beliefs(self):
        solve = make_planner(Experiment(),ACTIONS)
        for p in (F(-1),F(2),.5):
            with self.assertRaises(ValueError): solve(p,2)
    def test_40_invalid_actions(self):
        with self.assertRaises(ValueError): make_planner(Experiment(),('tamper',))
        with self.assertRaises(ValueError): Experiment(permissions=('observe','observe'))
    def test_41_incorrect_causal_hypothesis_can_be_rejected(self):
        e = Experiment(); solve = make_planner(e,('do0',))
        prediction,queries = run_policy(e,solve,'confounded',(1,0,0,0))
        self.assertEqual((prediction,queries),('confounded',1))
    def test_42_noisy_model_not_silently_equated(self):
        normal = make_planner(Experiment(True),ACTIONS)(F(1,2),4)
        null = make_planner(Experiment(False),ACTIONS)(F(1,2),4)
        self.assertNotEqual(normal.risk,null.risk)
    def test_43_invalid_calibration(self):
        with self.assertRaises(ValueError): corrected_bound(.1,200,.05,-.1)
    def test_44_empty_frame_stops(self):
        self.assertEqual(make_planner(Experiment(),())(F(1,2),12).expected_queries,0)
    def test_45_nonuniform_prior_passive_limit(self):
        self.assertEqual(make_planner(Experiment(),('observe',))(F(3,4),12).risk,F(1,4))
    def test_46_enumeration_is_bounded(self):
        with self.assertRaises(ValueError): enumerate_policy(Experiment(),None,17)
    def test_47_invalid_world_rejected(self):
        with self.assertRaises(ValueError): Experiment().execute('observe','invented',0)
    def test_48_double_edit_gain_exact(self):
        self.assertEqual(joint_value(frozenset({'representation','checker'}))-2*joint_value(frozenset({'representation'})),F(3,4))

    def test_49_cost_threshold_ties_choose_lower_cap(self):
        for k in range(10):
            c = F(1,2**(k+1)+2)
            p = make_planner(Experiment(),ACTIONS,c)(F(1,2),12)
            acc,queries = active_closed_form(k)
            self.assertEqual((p.risk,p.expected_queries),(1-acc,queries))
    def test_50_calibration_can_reverse_promotion(self):
        self.assertGreater(lower_bound(.1,2000,.025),.02)
        self.assertLessEqual(corrected_bound(.1,2000,.025,.01),.02)


if __name__ == '__main__':
    unittest.main(verbosity=2)
