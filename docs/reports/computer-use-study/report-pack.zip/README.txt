AGI Alpha — public report edition

Open START_HERE.html in a modern desktop browser. Read report.html for the complete English web report.
Use Print / Save PDF for a printable copy. The report itself does not run an AI agent.
This compact edition includes curated records, not the original 98-file archive or its full executable study.
No account, wallet or API key is required. External project/download links require a network connection.
Verify files with: sha256sum -c SHA256SUMS (or shasum -a 256 -c SHA256SUMS on macOS).
Checksums establish byte consistency, not independent authenticity or production readiness.
