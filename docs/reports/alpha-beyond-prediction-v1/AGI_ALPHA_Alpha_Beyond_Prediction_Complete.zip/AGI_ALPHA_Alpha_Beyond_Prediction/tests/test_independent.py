import copy, json, pathlib, sys, unittest
import numpy as np
from scipy.optimize import minimize
from scipy.special import xlogy
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'src'))
import laboratory as lab

def fixture(likelihood='gaussian'):
 xs=np.linspace(0,1,12)
 public={'schema':1,'id':'independent-review-fixture','family':'spectral-characterization','dim':2,'basis':[{'op':'const','value':1},{'op':'coord','axis':0}],'actions':[{'id':f'a{i}','points':[[float(x)]],'weights':[1.],'cost':1,'group':f'g{i//4}'} for i,x in enumerate(xs)],'likelihood':likelihood,'nuisance':[],'budget':24,'verify_count':4,'quality_threshold':.12,'prior_mean':[1.,1.],'prior_scale':5.,'available':[True]*12}
 if likelihood=='gaussian':public['noise_sd']=.03
 else:public.update({'background':.2,'exposure':3.})
 return public

def observer(public, verification_offset=0., future_offset=0., failure_first=False):
 A=np.array([[1.,a['points'][0][0]] for a in public['actions']]);theta=np.array([1.2,.7]);history=[]
 def sample(index,repeat,purpose):
  history.append((index,repeat,purpose));n=sum(p=='acquisition' for _,_,p in history)
  if failure_first and n==1 and purpose=='acquisition':return float('nan')
  value=float(A[index]@theta)
  if public['likelihood']=='poisson':value=float(round(public['exposure']*(public['background']+value)))
  if purpose=='verification':value+=verification_offset
  if purpose=='acquisition' and n>4:value+=future_offset
  return value
 return sample,history

class IndependentReview(unittest.TestCase):
 def test_expression_matches_independent_formulas(self):
  q=np.column_stack((np.linspace(-1,3,19),np.linspace(.1,.9,19)));x=q[:,0];z=q[:,1]
  basis=[{'op':'add','args':[{'op':'const','value':2},{'op':'mul','args':[{'op':'coord','axis':0},{'op':'coord','axis':1}]}]},{'op':'sin','arg':{'op':'coord','axis':0}},{'op':'cos','arg':{'op':'coord','axis':1}},{'op':'exp','arg':{'op':'coord','axis':1}},{'op':'gaussian','axis':0,'mu':.7,'sigma':.4},{'op':'causal_exp','axis':0,'rate':.8,'impulses':[[-.5,1.],[.6,-.3]]}]
  causal=np.where(x>=-.5,np.exp(-.8*(x+.5)),0)-.3*np.where(x>=.6,np.exp(-.8*(x-.6)),0)
  expected=np.column_stack((2+x*z,np.sin(x),np.cos(z),np.exp(z),np.exp(-.5*((x-.7)/.4)**2),causal))
  np.testing.assert_allclose(lab.basis_matrix(basis,q.tolist()),expected,atol=1e-14,rtol=1e-14)
 def test_aggregation_matches_explicit_quadrature(self):
  p=fixture();p['actions'][0]['points']=[[0.],[.25],[1.]];p['actions'][0]['weights']=[1/6,2/3,1/6]
  np.testing.assert_allclose(lab.construct(p).A[0],[1.,1/3],atol=1e-14)
 def test_weighted_gaussian_map_matches_augmented_lstsq(self):
  rng=np.random.default_rng(709)
  for _ in range(8):
   A=rng.normal(size=(9,3));y=rng.normal(size=9);var=rng.uniform(.03,.4,9);prior=rng.normal(size=3);scale=2.3
   B=np.vstack((A/np.sqrt(var)[:,None],np.eye(3)/scale));b=np.r_[y/np.sqrt(var),prior/scale]
   expected=np.linalg.lstsq(B,b,rcond=None)[0];actual,cov=lab.fit_gaussian(A,y,var,prior,scale,lab.Meter())
   np.testing.assert_allclose(actual,expected,atol=2e-12,rtol=2e-12);np.testing.assert_allclose(cov,np.linalg.solve(B.T@B,np.eye(3)),atol=2e-12,rtol=2e-12)
 def test_poisson_map_matches_independent_objective_optimizer(self):
  A=np.array([[1.,0.],[.2,1.],[1.,1.],[.3,.5],[.8,.1]]);y=np.array([0.,2.,7.,1.,0.]);exposure=2.;background=.2;prior=np.array([1.,1.]);scale=4.
  def objective(t):
   mu=exposure*(background+A@t)
   return float(np.sum(mu-xlogy(y,mu))+.5*np.sum((t-prior)**2)/scale**2)
  reference=minimize(objective,[.8,.9],method='SLSQP',bounds=[(0,None)]*2,options={'ftol':1e-12,'maxiter':2000})
  actual,cov,ok=lab.fit_poisson(A,y,exposure,background,prior,prior,scale,lab.Meter())
  self.assertTrue(reference.success);self.assertTrue(ok);self.assertLess(abs(objective(actual)-reference.fun),1e-8);np.testing.assert_allclose(actual,reference.x,atol=2e-6,rtol=2e-6);self.assertTrue(np.all(np.linalg.eigvalsh(cov)>0))
 def test_missing_or_empty_authority_never_acquires(self):
  p=fixture()
  for auth in (None,{}):
   obs,calls=observer(p);r=lab.solve(p,obs,authority=auth);self.assertEqual(calls,[]);self.assertEqual(r['status'],'abstained')
 def test_authority_expiry_stops_callbacks_at_boundary(self):
  p=fixture();obs,calls=observer(p);r=lab.solve(p,obs,authority=lab.make_authority(p,expires=5))
  self.assertEqual(len(calls),5);self.assertFalse(r['verification_pass']);self.assertTrue(all(e['tick']<5 for e in r['events'] if e['event'] in ('acquire','verify')))
 def test_delayed_authority_waits_without_unbilled_observations(self):
  p=fixture();obs,calls=observer(p);r=lab.solve(p,obs,authority=lab.make_authority(p,not_before=2,expires=8))
  self.assertEqual(r['costs']['wait_steps'],2);self.assertEqual(len(calls),6);self.assertTrue(all(e['tick']>=2 for e in r['events'] if e['event'] in ('acquire','verify')))
 def test_failure_retains_cost_and_serializes_strict_json(self):
  p=fixture();obs,calls=observer(p,failure_first=True);r=lab.solve(p,obs,authority=lab.make_authority(p));json.dumps(r,allow_nan=False)
  acquisitions=[e for e in r['events'] if e['event']=='acquire'];verification=[e for e in r['events'] if e['event']=='verify']
  self.assertEqual(r['costs']['recovery_events'],1);self.assertIsNone(acquisitions[0]['value']);self.assertEqual(r['costs']['acquisition_units'],sum(e['units'] for e in acquisitions));self.assertEqual(len(calls),len(acquisitions)+len(verification));self.assertEqual(r['costs']['acquisitions'],len(acquisitions));self.assertLessEqual(r['costs']['acquisition_units'],24);self.assertLessEqual(r['costs']['verification_acquisitions'],4)
 def test_costly_actions_respect_unit_budget(self):
  p=fixture()
  for i,a in enumerate(p['actions']):a['cost']=1+i%3
  obs,calls=observer(p);r=lab.solve(p,obs,authority=lab.make_authority(p));cost={a['id']:a['cost'] for a in p['actions']}
  for event,counter in [('acquire','acquisition_units'),('verify','verification_units')]:self.assertEqual(r['costs'][counter],sum(cost[e['action']] for e in r['events'] if e['event']==event))
  self.assertLessEqual(r['costs']['acquisition_units'],p['budget']);self.assertLessEqual(r['costs']['acquisition_units']+r['costs']['verification_units'],lab.make_authority(p)['max_units'])
 def test_future_observations_do_not_change_prior_actions(self):
  p=fixture('poisson');a,ha=observer(p);b,hb=observer(p,future_offset=20.)
  lab.solve(p,a,authority=lab.make_authority(p));lab.solve(p,b,authority=lab.make_authority(p))
  aa=[x for x in ha if x[2]=='acquisition'];bb=[x for x in hb if x[2]=='acquisition'];self.assertEqual(aa[:5],bb[:5])
 def test_verification_does_not_retrain_estimate_or_design(self):
  p=fixture();a,_=observer(p);b,_=observer(p,verification_offset=100.)
  ra=lab.solve(p,a,authority=lab.make_authority(p));rb=lab.solve(p,b,authority=lab.make_authority(p))
  np.testing.assert_array_equal(ra['theta'],rb['theta']);self.assertEqual(ra['selected_actions'],rb['selected_actions']);self.assertFalse(rb['verification_pass'])
 def test_equally_capable_representations_agree(self):
  for law in ['gaussian','poisson']:
   p=fixture(law);results=[]
   for method in ['aperture','modular','flat']:
    obs,_=observer(p);results.append(lab.solve(p,obs,method=method,authority=lab.make_authority(p)))
   for r in results[1:]:
    np.testing.assert_allclose(r['theta'],results[0]['theta'],atol=1e-10,rtol=1e-10);self.assertEqual(r['selected_actions'],results[0]['selected_actions']);self.assertEqual(r['verification_pass'],results[0]['verification_pass']);self.assertEqual(r['costs']['acquisition_units'],results[0]['costs']['acquisition_units'])
 def test_candidate_score_ledger_counts_executed_rows(self):
  p=fixture();obs,_=observer(p);r=lab.solve(p,obs,authority=lab.make_authority(p));self.assertEqual(r['costs']['candidate_scores'],len(p['actions'])*r['costs']['acquisitions']);self.assertLessEqual(r['costs']['feasible_candidates'],r['costs']['candidate_scores'])
 def test_flat_loader_rejects_nonmatrix_plan_tampering(self):
  original=lab.construct(fixture());payload=lab.lower_flat(original)
  for field in ('budget','costs','availability','threshold'):
   changed=copy.deepcopy(payload)
   if field=='budget':changed['contract']['budget']=48;changed['contract']['verify_count']=0
   elif field=='costs':changed['costs'][0]=0
   elif field=='availability':changed['available'][0]=False
   else:changed['contract']['quality_threshold']=1.
   with self.subTest(field=field),self.assertRaises(ValueError):lab.load_flat(changed,original)
 def test_restore_cannot_self_renew_or_change_mission(self):
  p=fixture();program=lab.construct(p);trusted=lab.make_authority(p,expires=10);bundle=lab.snapshot({'mission':p},{'program_hash':program.identity},{'program_hash':program.identity},copy.deepcopy(trusted))
  self.assertEqual(lab.restore(bundle,1,p['id'],trusted),bundle['payload'])
  with self.assertRaises(ValueError):lab.restore(bundle,1,p['id'])
  with self.assertRaises(ValueError):lab.restore(bundle,10,p['id'],trusted)
  with self.assertRaises(ValueError):lab.restore(bundle,1,'new-mission',trusted)
  changed=copy.deepcopy(bundle);changed['payload']['Authority']['expires']=100;changed['sha256']=lab.digest(changed['payload'])
  with self.assertRaises(ValueError):lab.restore(changed,11,p['id'],trusted)
  changed=copy.deepcopy(bundle);changed['payload']['Policy']['program_hash']='0'*64;changed['sha256']=lab.digest(changed['payload'])
  with self.assertRaises(ValueError):lab.restore(changed,1,p['id'],trusted)
 def test_nuisance_column_matches_independent_joint_map(self):
  p=fixture();x=np.array([a['points'][0][0] for a in p['actions']]);p['nuisance']=[{'name':'quadratic-drift','values':(x*x).tolist()}];X=np.column_stack((np.ones(len(x)),x,x*x));truth=np.array([1.2,.7,.2])
  def obs(i,r,purpose):return float(X[i]@truth)
  result=lab.solve(p,obs,authority=lab.make_authority(p));used=result['selected_actions'];B=np.vstack((X[used]/p['noise_sd'],np.eye(3)/p['prior_scale']));b=np.r_[(X[used]@truth)/p['noise_sd'],np.array([1.,1.,0.])/p['prior_scale']];expected=np.linalg.lstsq(B,b,rcond=None)[0]
  np.testing.assert_allclose(result['theta']+result['nuisance_estimate'],expected,atol=1e-10,rtol=1e-10)
 def test_invalid_poisson_counts_are_not_fit_or_accepted(self):
  for invalid in (-1.,.5):
   p=fixture('poisson');base,_=observer(p);attempts=[0]
   def obs(i,r,purpose):
    if purpose=='acquisition':
     attempts[0]+=1
     if attempts[0]==1:return invalid
    return base(i,r,purpose)
   result=lab.solve(p,obs,authority=lab.make_authority(p));self.assertGreaterEqual(result['costs']['recovery_events'],1)
   base,_=observer(p)
   def invalid_verification(i,r,purpose):return invalid if purpose=='verification' else base(i,r,purpose)
   result=lab.solve(p,invalid_verification,authority=lab.make_authority(p));self.assertFalse(result['verification_pass'])
 def test_health_quarantine_refits_survivors_and_keeps_sunk_cost(self):
  p=fixture();sample,_=observer(p);emitted=[False]
  def health(tick):
   if tick>=6 and not emitted[0]:
    emitted[0]=True;return [{'kind':'gain_suspect','groups':['g0','g2'],'exact_gain_disclosed':False}]
   return []
  result=lab.solve(p,sample,authority=lab.make_authority(p),on_tick=health);quarantine=[e for e in result['events'] if e['event']=='quarantine'];self.assertEqual(len(quarantine),1);self.assertGreater(quarantine[0]['removed_observations'],0);self.assertEqual(quarantine[0]['refund_units'],0)
  self.assertTrue(all(p['actions'][i]['group']=='g1' for i in result['selected_actions']));self.assertEqual(result['costs']['acquisition_units'],sum(e['units'] for e in result['events'] if e['event']=='acquire'));self.assertGreater(result['costs']['acquisitions'],len(result['selected_actions']))
  A=np.array([[1.,p['actions'][i]['points'][0][0]] for i in result['selected_actions']]);B=np.vstack((A/p['noise_sd'],np.eye(2)/p['prior_scale']));b=np.r_[(A@np.array([1.2,.7]))/p['noise_sd'],np.array([1.,1.])/p['prior_scale']];np.testing.assert_allclose(result['theta'],np.linalg.lstsq(B,b,rcond=None)[0],atol=1e-10,rtol=1e-10)
 def test_late_health_alert_requires_fresh_verification_without_extra_budget(self):
  p=fixture();sample,_=observer(p);emitted=[False]
  def health(tick):
   if tick>=26 and not emitted[0]:
    emitted[0]=True;return [{'kind':'gain_suspect','groups':['g1'],'exact_gain_disclosed':False}]
   return []
  result=lab.solve(p,sample,authority=lab.make_authority(p),on_tick=health);self.assertEqual(result['costs']['verification_acquisitions'],4);self.assertFalse(result['verification_pass']);self.assertTrue(any(e['event']=='quarantine' and e['new_verification_required']==4 for e in result['events']))
 def test_campaign_refusal_does_not_charge_a_switch_never_started(self):
  from campaign import replay
  cases=[]
  for i,family in enumerate(['spectral-characterization','causal-system-identification','spectral-characterization']):
   p=fixture();p['id']=f'independent-campaign-{i}';p['family']=family;cases.append({'public':p,'hidden':{'theta':[1.2,.7],'validation_points':[[0.],[.5],[1.]],'seed':709,'stress':'nominal'}})
  result=replay(cases,'frozen_specialist','eager',capacity=100,switch_units=3)
  self.assertEqual(result['used_units'],56);self.assertEqual(result['events'][1]['action'],'abstain')
 def test_input_contract_rejects_invalid_models(self):
  mutations=[lambda p:p.update(dim=0),lambda p:p.update(budget=49),lambda p:p['actions'][0].update(cost=0),lambda p:p.update(available=[True]),lambda p:p['basis'][0].update(op='unsupported'),lambda p:p.update(noise_sd=0)]
  for change in mutations:
   p=fixture();change(p)
   with self.assertRaises(ValueError):lab.construct(p)
 def test_common_calibration_error_can_pass_residual_check(self):
  p=fixture();A=np.array([[1.,a['points'][0][0]] for a in p['actions']]);theta=np.array([1.2,.7])
  def obs(i,r,purpose):return float(1.32*A[i]@theta)
  result=lab.solve(p,obs,authority=lab.make_authority(p));nrmse=np.linalg.norm(A@np.array(result['theta'])-A@theta)/np.linalg.norm(A@theta)
  self.assertTrue(result['verification_pass']);self.assertGreater(nrmse,.25)

if __name__=='__main__':unittest.main(verbosity=2)
