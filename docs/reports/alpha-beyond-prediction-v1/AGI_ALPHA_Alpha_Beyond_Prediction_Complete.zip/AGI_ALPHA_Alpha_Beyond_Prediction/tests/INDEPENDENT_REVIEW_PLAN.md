# Independent review plan prepared before implementation review

The reviewer had the method summary (array AST, callable conventional comparator, GLS/Poisson observation laws, 24 construction acquisitions plus 4 verification acquisitions) but had not inspected the core implementation or hidden scenario family when this plan was written. This is a separate assistant-agent review within the same project, not an external laboratory replication or human-expert trial.

## Claims that can be supported

The artifact can establish that a specified representation and bounded transformation set execute across the declared digital tasks; that their outputs satisfy defined numerical checks; that resource and authority boundaries are enforced; and that measured costs/coverage differ or agree on a frozen finite suite. It cannot establish unknown-family universality, optimality beyond a proven finite search, equal human engineering effort, economic profit, or physical validation.

## Acceptance checks

| ID | Independent check | Failure interpretation |
|---|---|---|
| R01 | Compare AST forward outputs against independently written NumPy/SciPy formulas on several valid input grids, including changed shapes and a boundary case. | Compilation changes the modeled experiment or silently loses dimensions. |
| R02 | Compare GLS estimates to direct whitening: form an SPD covariance independently, use its Cholesky factor to whiten both design and observations, then solve with NumPy least squares. Test correlated and diagonal covariance. | Proposed numerical result may stem from covariance/normalization mistakes. |
| R03 | Verify Poisson objective on positive means against the direct sum of `mu - y*log(mu)`; include zero counts. Compare solution to an ordinary optimizer with identical constraints and data. | A likelihood mismatch, invalid mean or changed feasible set invalidates comparison. |
| R04 | Test the known Gaussian/Poisson mathematical problem through both proposed and conventional representations; compare objectives and predictions within predeclared numerical tolerance. | Apparent advantage can be solver access, representation privilege or an implementation defect. |
| R05 | Audit acquisition IDs: at most 24 fitting and 4 verification observations, with no hidden truth in the policy input. Candidate scoring and numerical-Jacobian calls must appear only in the compute ledger. | Claimed quality or cost uses excess/unbilled evidence or conflates computation with measurement. |
| R06 | Use two possible futures with identical visible prefixes but different unrevealed outcomes/demands. Require identical policy actions over the shared prefix. | Policy leaks future information or uses a retrospective schedule as though observed online. |
| R07 | Perturb validation observations while holding construction observations fixed. Fitted parameters and pre-validation acquisition choices must remain unchanged. | Confirmation evidence is being used as training or adaptation feedback without declaring that access. |
| R08 | Force an invalid operator shape, infeasible rank, unavailable measurement and nonfinite input. Require explicit failure/abstention, with consumed resources retained. | Silent success, NaN acceptance or erased failure costs. |
| R09 | Inject a shared-component outage across task families; preserve unserved demand, recovery cost, capacity consumed, and any irreversible commitments. | Diversity is incorrectly treated as independence or outages are removed from the denominator. |
| R10 | Inspect every candidate pool, solver, quality threshold, validation allocation and uncertainty prior used by the implementable conventional comparator. Allow the same transformations and reusable interfaces. | A comparison against an artificially restricted asset menu cannot support superiority. |
| R11 | Compare against the specialist informed of each known scenario and a simple wait/abstain policy; label their information and authority separately. | An oracle is presented as implementable or waiting wins are suppressed. |
| R12 | Recompute totals from event-level records; separate physical/simulated acquisitions, objective evaluations, compilation/adaptation, validation, recovery, maintenance, wall/CPU time and unknown human cost. | Unexplained totals or invented tariffs undermine resource conclusions. |
| R13 | Recalculate coverage from the frozen quality predicate, not from the existence of a returned artifact; preserve all failed and refused cases. | Output production is conflated with valid useful delivery. |
| R14 | Inspect freeze/reveal hashes and chronological logs. Confirm no edits to the evaluated artifact or policy after held-out outcomes were inspected. Any repair becomes an explicitly separate exploratory result. | Held-out claims lose prospective chronology. |
| R15 | Restore an exported snapshot with fresh, expired and incompatible permissions. Require current authority validation and refusal for expired/incompatible grants. Evidence restoration must not itself grant authority. | Saved capabilities revive expired or task-incompatible permissions. |
| R16 | Reproduce the primary deterministic metrics from a clean output directory using the documented command and pinned inputs; distinguish approximate numeric equality from byte-identical timing logs. | Clean reproduction is unverified or a timing-sensitive hash falsely claims determinism. |

## Reporting rules

Report every failed check and the scope it affects. Separate mathematical equivalence from implementation-speed measurements. Summaries with equal scenario weights describe the test suite; they do not estimate a real demand distribution. Report scenario-wise differences and crossover conditions, including costs of unused flexibility. Any representation benefit that vanishes when replaced with a competent conventional implementation is a useful negative result.

For this run, engineering time supplied by the assistant system is not an observed human budget. Sharing a mathematical primitive library makes comparator access clearer but does not establish equal total engineering effort. Human construction, maintenance and review effort must remain unknown unless actually measured.
