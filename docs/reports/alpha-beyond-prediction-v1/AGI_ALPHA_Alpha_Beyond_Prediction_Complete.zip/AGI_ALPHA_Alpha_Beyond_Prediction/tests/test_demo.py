# SPDX-License-Identifier: Apache-2.0
"""Demo boundary tests; these do not rerun or alter the frozen confirmation."""
import copy
import hashlib
import http.client
import importlib.util
import json
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('writer11_demo_server',ROOT/'demo/server.py')
demo=importlib.util.module_from_spec(spec);spec.loader.exec_module(demo)
from experiments import development_case


class DemoBoundaries(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='demo-test-',dir=ROOT/'demo')
        self.addCleanup(self.tmp.cleanup)
        folder=Path(self.tmp.name)
        cases=[development_case('spectral-characterization',1,'nominal'),
               development_case('causal-system-identification',1,'nominal')]
        (folder/'cases.json').write_text(json.dumps(cases))
        (folder/'records.json').write_text('[]')
        self.session=demo.LaboratorySession(folder/'cases.json',folder/'records.json','development-test')

    def run_one(self):
        self.session.authorize(True)
        return self.session.run('aperture')

    def test_explicit_consent_precedes_any_evaluation(self):
        with patch.object(demo,'evaluate',side_effect=AssertionError('must not evaluate')):
            with self.assertRaisesRegex(ValueError,'No current authority'):self.session.run('aperture')
            for value in (False,None,1,'true'):
                with self.assertRaisesRegex(ValueError,'Explicit consent'):self.session.authorize(value)

    def test_actual_bounded_run_and_spent_grant(self):
        state=self.run_one();row=state['result']
        self.assertEqual(row['method'],'aperture')
        self.assertTrue(row['qualified'])
        self.assertEqual(row['costs']['acquisition_units'],24)
        self.assertEqual(row['costs']['verification_units'],4)
        self.assertEqual(row['demo_execution']['mode'],'computed now by local Python')
        self.assertEqual(row['demo_execution']['source']['laboratory_sha256'],demo.sha(ROOT/'src/laboratory.py'))
        self.assertTrue(self.session.grant_used)
        with self.assertRaisesRegex(ValueError,'spent'):self.session.run('aperture')

    def test_exact_restore_uses_current_authority_and_does_not_recharge(self):
        first=self.run_one()['result'];bundle=self.session.export()
        restored=self.session.restore_bundle(bundle)
        self.assertEqual(first,restored['result'])
        self.assertTrue(self.session.grant_used)
        self.assertFalse(self.session.history[-1]['authority_imported'])
        self.assertEqual(bundle['sha256'],demo.digest(bundle['payload']))

    def test_rehashed_authority_cannot_extend_current_permission(self):
        self.run_one();bundle=self.session.export()
        bundle['payload']['Authority']['expires']+=1000
        bundle['sha256']=demo.digest(bundle['payload'])
        with self.assertRaisesRegex(ValueError,'separately supplied unchanged current authority'):
            self.session.restore_bundle(bundle)

    def test_rehashed_scientific_proof_is_not_trusted(self):
        self.run_one();bundle=self.session.export()
        bundle['payload']['Proof']['record']['nrmse']=0
        bundle['sha256']=demo.digest(bundle['payload'])
        with self.assertRaisesRegex(ValueError,'not an exact artifact issued'):
            self.session.restore_bundle(bundle)

    def test_expired_permission_cannot_restore_but_evidence_can_export(self):
        self.run_one();bundle=self.session.export();self.session.expire()
        self.assertEqual(self.session.export(),bundle)
        with self.assertRaisesRegex(ValueError,'Current authority expired'):
            self.session.restore_bundle(bundle)

    def test_changed_mission_needs_new_authority_and_rejects_old_bundle(self):
        self.run_one();bundle=self.session.export();self.session.reveal()
        self.assertIsNone(self.session.grant)
        with self.assertRaisesRegex(ValueError,'No current authority'):self.session.restore_bundle(bundle)
        self.session.authorize(True)
        with self.assertRaisesRegex(ValueError,'different mission'):self.session.restore_bundle(bundle)

    def test_same_mission_new_authority_or_server_restart_rejects_old_bundle(self):
        self.run_one();bundle=self.session.export();self.session.authorize(True)
        self.assertIsNone(self.session.result)
        with self.assertRaisesRegex(ValueError,'separately supplied unchanged current authority'):
            self.session.restore_bundle(bundle)
        restarted=demo.LaboratorySession(self.session.cases_path,self.session.records_path,'development-test')
        restarted.authorize(True)
        with self.assertRaisesRegex(ValueError,'separately supplied unchanged current authority'):
            restarted.restore_bundle(bundle)

    def test_hindsight_cannot_be_executed_interactively(self):
        self.session.authorize(True)
        with self.assertRaisesRegex(ValueError,'recorded reference only'):self.session.run('hindsight')
        self.assertFalse(self.session.grant_used)

    def test_nonfinite_and_duplicate_json_are_refused(self):
        for raw in (b'{"a":1,"a":2}',b'{"a":NaN}',b'{"a":Infinity}'):
            with self.assertRaises(ValueError):demo.strict_json(raw)

    def test_actual_loopback_http_boundary_and_roundtrip(self):
        handler=type('IsolatedHandler',(demo.DemoHandler,),{'session':self.session})
        server=demo.HTTPServer(('127.0.0.1',0),handler)
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        def cleanup():
            server.shutdown();server.server_close();thread.join(timeout=2)
        self.addCleanup(cleanup)
        port=server.server_port
        def call(path,body=None,extra=None):
            headers={'Host':f'127.0.0.1:{port}'}
            if body is not None:headers.update({'Content-Type':'application/json','X-Writer11-Demo':'local'})
            headers.update(extra or {})
            connection=http.client.HTTPConnection('127.0.0.1',port,timeout=10)
            connection.request('GET' if body is None else 'POST',path,body=None if body is None else json.dumps(body),headers=headers)
            response=connection.getresponse();raw=response.read();status=response.status;ctype=response.getheader('Content-Type');connection.close()
            return status,json.loads(raw) if ctype.startswith('application/json') else raw
        self.assertEqual(call('/api/run',{'method':'aperture'})[0],400)
        self.assertEqual(call('/api/authorize',{'consent':True},{'Origin':'https://unrelated.invalid'})[0],403)
        self.assertEqual(call('/api/authorize',{'consent':True},{'X-Writer11-Demo':'wrong'})[0],403)
        self.assertIsNone(self.session.grant)
        self.assertEqual(call('/api/state',extra={'Host':f'localhost:{port}'})[0],403)
        self.assertEqual(call('/../../src/laboratory.py')[0],404)
        self.assertEqual(call('/')[0],200)
        self.assertEqual(call('/api/authorize',{'consent':True})[0],200)
        status,result=call('/api/run',{'method':'aperture'});self.assertEqual(status,200);self.assertTrue(result['result']['qualified'])
        status,bundle=call('/api/export');self.assertEqual(status,200)
        self.assertEqual(call('/api/restore',{'bundle':bundle})[0],200)
        self.assertEqual(call('/api/expire',{})[0],200)
        status,body=call('/api/restore',{'bundle':bundle});self.assertEqual(status,400);self.assertIn('Current authority expired',body['error'])

    def test_static_replay_is_bound_to_full_source_records(self):
        raw=(ROOT/'demo/replay-data.js').read_text()
        payload=json.loads(raw.removeprefix('window.WRITER11_REPLAY = ').rstrip().removesuffix(';'))
        self.assertEqual(payload['mode'],'recorded-replay')
        source=ROOT/payload['source']['records_path']
        self.assertEqual(hashlib.sha256(source.read_bytes()).hexdigest(),payload['source']['records_sha256'])
        rows=json.loads(source.read_text())
        for method in ('aperture','modular'):
            selected=[r for r in rows if r['method']==method]
            self.assertEqual(payload['aggregate'][method]['cases'],len(selected))
            self.assertEqual(payload['aggregate'][method]['qualified'],sum(bool(r['qualified']) for r in selected))
        for case in payload['cases']:
            for row in case['records']:
                original=next(r for r in rows if r['case_id']==case['id'] and r['method']==row['method'])
                for key,value in row.items():
                    if key!='trace_included':self.assertEqual(value,original[key])
                # The UI exports compact JSON, so its own largest imaging artifact fits the import bound.
                envelope={'World':{'mission':case['public']},'Policy':{'method':row['method']},
                          'Proof':{'record':row,'source':payload['source']},'Authority':{'scope':'none'}}
                self.assertLess(len(json.dumps(envelope,separators=(',',':')).encode()),250000)

if __name__=='__main__':unittest.main(verbosity=2)
