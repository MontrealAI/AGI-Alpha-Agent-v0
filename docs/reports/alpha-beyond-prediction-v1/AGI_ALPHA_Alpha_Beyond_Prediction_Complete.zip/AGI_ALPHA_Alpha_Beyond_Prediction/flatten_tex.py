"""Export one complete LaTeX body; accompanying figures are still required."""
from pathlib import Path
import hashlib
import json
import re

root = Path(__file__).resolve().parent
paper = root / 'paper'

def expand(name):
    text = (paper / name).read_text()
    return re.sub(r'\\input\{([^{}]+)\}', lambda match: expand(match.group(1)), text)

text = expand('alpha-beyond-prediction.tex')
bbl = (paper / 'build/alpha-beyond-prediction.bbl').read_text()
text = re.sub(r'\\bibliographystyle\{[^}]+\}\s*\\bibliography\{[^}]+\}', lambda match: bbl, text)
text = text.replace('../figures/', 'figures/')
text = ('% Complete flattened LaTeX; use the accompanying figures directory.\n'
        '% Canonical build: bash build_paper.sh. Sources and evidence are in the complete ZIP.\n' + text)
assert '\\input{' not in text and '\\bibliography{' not in text
output = root / 'AGI_ALPHA_Alpha_Beyond_Prediction.tex'
output.write_text(text)
print(json.dumps({'flattened_tex': str(output), 'bytes': output.stat().st_size,
                  'sha256': hashlib.sha256(output.read_bytes()).hexdigest()}))
