# Writer 11: Alpha Beyond Prediction — initial registration

Registered at the start of a fresh, bounded research lane, before confirmatory observations.
Project: AGI ALPHA. User-facing edition date: 23 October 2026 (America/Toronto).
Coordination: https://github.com/MontrealAI/AGI-Alpha-Agent-v0/issues/4850#issuecomment-6378901184

## Question
Can one constructed measurement/inverse capability change its representation and execution structure when the task changes, and when is flexibility useful or costly? The study does not predict a sector or estimate financial returns. An equally enabled conventional reusable implementation is the primary comparator; equality or a negative result is acceptable.

## Development decision
A separate development pilot found that standard SciPy fitting solves the public NIST Gauss1 generated reference dataset cheaply and accurately. Known-model nonlinear fitting is therefore not the proposed bottleneck. The final study will target structural measurement/inference changes and their verification. The pilot is not operational or physical evidence. Final selection, executable protocol, implementation, comparator and analysis will receive a second hash freeze before held-out reveal.

## Artifact
A finite, inspectable measurement-program compiler accepts typed mathematical expressions, aggregation actions, explicit likelihood, budgets and mission-specific authority. Spectral characterization and causal system identification are development families. A role-separated steward will reveal a materially different task family only after the complete freeze. Conventional implementations receive identical primitives, information, numerical solvers, actions and budgets. The program is an engineering synthesis, not a claim that modularity or experimental design is new.

## Prospective boundaries
This is same-session procedural role separation on a shared filesystem. It is not tamperproof preregistration, organizational independence, prospective market deployment or a distribution-free guarantee. All evaluation generators and results will be disclosed. Future-demand distributions are unknown. Scenario averages are finite test-suite summaries. Primary claims concern scientific quality, finite coverage, measured computational work and explicit synthetic resource units. Human engineering effort, model-provider resource consumption, willingness to pay and economic profit are not measured and must remain unknown.

## Preservation
Retain first attempts, failures and hash chronology. No post-reveal scientific tuning is allowed in the confirmatory analysis. Corrections must be separately labelled. Existing publication owner controls shared indexes, merge and Pages. No held operation, wallet, paid commitment, new credential or security setting is authorized.
