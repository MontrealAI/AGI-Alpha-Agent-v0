from __future__ import annotations
import hashlib, json, math
from pathlib import Path
import numpy as np

SCHEMA_VERSION = 1
FAMILY = 'coded_aperture_emission_imaging'
STRESS_CLASSES = ('normal', 'correlated_calibration_failure', 'unavailable_action_group', 'delayed_authority')
SEEDS = tuple(range(731031, 731039))

def gaussian(axis, mu, sigma):
    return {'op': 'gaussian', 'axis': axis, 'mu': float(mu), 'sigma': float(sigma)}

def field_basis(centers, widths):
    return [{'op': 'mul', 'args': [gaussian(0, c[0], w[0]), gaussian(1, c[1], w[1])]} for c, w in zip(centers, widths)]

def evaluate_independent(points, centers, widths):
    z = np.asarray(points, dtype=float)[:, None, :] - np.asarray(centers)[None, :, :]
    return np.exp(-0.5 * np.sum((z / np.asarray(widths)[None, :, :]) ** 2, axis=2))

def create_base(seed):
    rng = np.random.default_rng(seed)
    centers = np.array([(x, y) for y in (-0.43, 0.43) for x in (-0.62, 0., 0.62)])
    centers += rng.uniform(-0.045, 0.045, size=(6, 2))
    widths = rng.uniform(0.23, 0.33, size=(6, 2))
    theta = rng.uniform(0.35, 1.65, 6)
    grid = np.array([(x, y) for y in np.linspace(-1., 1., 13) for x in np.linspace(-1., 1., 13)])
    actions = []
    for i in range(30):
        bank = i % 3
        if bank == 0:
            x0, y0 = rng.uniform(-0.7, 0.7, 2)
            sx, sy = rng.uniform(0.35, 0.75, 2)
            mask = (abs(grid[:, 0] - x0) <= sx) & (abs(grid[:, 1] - y0) <= sy)
        elif bank == 1:
            phase = rng.uniform(0., 2 * math.pi)
            frequency = rng.choice((2., 3., 4.))
            angle = rng.uniform(0., math.pi)
            coord = grid[:, 0] * math.cos(angle) + grid[:, 1] * math.sin(angle)
            mask = np.cos(frequency * math.pi * coord + phase) > 0.
        else:
            mask = rng.uniform(0., 1., len(grid)) < rng.uniform(0.25, 0.6)
        points = grid[mask]
        if len(points) < 4:
            raise ValueError('Degenerate aperture; do not silently retry.')
        weights = np.ones(len(points)) / len(grid)
        actions.append({'id': f'mask-{i:02d}', 'points': points.tolist(), 'weights': weights.tolist(), 'cost': 1, 'group': f'bank-{bank}'})
    probe_points = np.array([(x, y) for y in np.linspace(-0.96, 0.96, 25) for x in np.linspace(-0.96, 0.96, 25)])
    validation_matrix = evaluate_independent(probe_points, centers, widths)
    design_matrix = np.vstack([np.asarray(a['weights']) @ evaluate_independent(a['points'], centers, widths) for a in actions])
    if np.linalg.matrix_rank(design_matrix) != 6:
        raise ValueError('Full design rank failed; retain failure, do not regenerate.')
    public = {'schema': SCHEMA_VERSION, 'family': FAMILY, 'likelihood': 'poisson', 'dim': 6,
              'basis': field_basis(centers, widths), 'actions': actions, 'nuisance': [],
              'exposure': 400., 'background': 0.05, 'budget': 24, 'verify_count': 4,
              'quality_threshold': 0.12, 'prior_mean': [1.] * 6, 'prior_scale': 1.5,
              'available': [True] * 30,
              'units': {'coordinates': 'dimensionless image-plane coordinates', 'latent': 'relative emission density',
                        'observation': 'synthetic photon count', 'cost': 'synthetic acquisition unit'},
              'task_description': 'Choose coded aperture measurements, estimate a nonnegative spatial emission field, and export an uncertainty-qualified reconstruction.'}
    hidden = {'theta': theta.tolist(), 'nuisance_truth': [], 'validation_points': probe_points.tolist(),
              'validation_matrix': validation_matrix.tolist(), 'independent_action_matrix': design_matrix.tolist(),
              'observation_stream': {'algorithm': 'sha256(case_id|action_id|repeat)->first_128_bits->PCG64->poisson', 'exposure': 400.},
              'quality_definition': 'RMSE(validation_matrix @ (estimate-theta)) / max(RMS(validation_matrix @ theta),1e-8)',
              'case_seed': seed, 'gain_by_group': {'bank-0': 1., 'bank-1': 1., 'bank-2': 1.}}
    return public, hidden

def generate_cases():
    cases = []
    for klass in STRESS_CLASSES:
        for i, seed in enumerate(SEEDS):
            public, hidden = create_base(seed)
            case_id = 'h-' + hashlib.sha256(f'{klass}|{seed}'.encode()).hexdigest()[:12]
            public['id'] = case_id
            hidden['stress_class'] = klass
            context = {'authority_not_before_step': 0, 'authority_expires_after_step': 96,
                       'waiting_cost_per_step': 1, 'switch_cost_units': 3, 'irreversible_acquisition': True,
                       'health_events': [], 'note': 'Simulator authority timing is not a grant of external authority.'}
            if klass == 'correlated_calibration_failure':
                hidden['gain_by_group'] = {'bank-0': 1.65, 'bank-1': 1.65, 'bank-2': 1.}
                hidden['failure_description'] = 'Two mask banks share a multiplicative gain fault; no oracle correction is given to an implementable policy.'
                context['health_events'] = [{'step': 12, 'kind': 'gain_suspect', 'groups': ['bank-0', 'bank-1'], 'exact_gain_disclosed': False}]
            if klass == 'unavailable_action_group':
                public['available'] = [a['group'] == 'bank-0' for a in public['actions']]
                hidden['failure_description'] = 'Two aperture banks are unavailable at mission admission; all available rows remain usable.'
            if klass == 'delayed_authority':
                context['authority_not_before_step'] = 2 + i % 3
                context['authority_expires_after_step'] = 32
            hidden['context'] = context
            cases.append({'public': public, 'hidden': hidden})
    if len(cases) != 32:
        raise ValueError('Case count changed.')
    return cases

def observe(case, action_index, repeat):
    public, hidden = case['public'], case['hidden']
    action = public['actions'][action_index]
    row = np.asarray(hidden['independent_action_matrix'][action_index])
    gain = hidden['gain_by_group'][action['group']]
    mean = public['exposure'] * (gain * float(row @ np.asarray(hidden['theta'])) + public['background'])
    key = f"{public['id']}|{action['id']}|{repeat}".encode()
    seed = int.from_bytes(hashlib.sha256(key).digest()[:16], 'big')
    return int(np.random.default_rng(seed).poisson(mean))

def score(case, theta):
    truth = np.asarray(case['hidden']['theta'])
    estimate = np.asarray(theta, dtype=float)
    if estimate.shape != truth.shape or not np.isfinite(estimate).all():
        return {'valid': False, 'nrmse': None, 'feasible': False, 'reason': 'estimate shape or finite-value violation'}
    probes = np.asarray(case['hidden']['validation_matrix'])
    truth_response = probes @ truth
    err = float(np.sqrt(np.mean((probes @ (estimate-truth)) ** 2)) / max(float(np.sqrt(np.mean(truth_response ** 2))), 1e-8))
    return {'valid': True, 'nrmse': err, 'feasible': bool(err <= case['public']['quality_threshold'])}

def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    cases = generate_cases()
    for case in cases:
        (args.output / (case['public']['id'] + '.json')).write_text(json.dumps(case, sort_keys=True, separators=(',', ':')) + '\n')
    metadata = {'cases': len(cases), 'family': FAMILY, 'classes': list(STRESS_CLASSES),
                'seeds': list(SEEDS), 'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                'scope': 'Synthetic finite digital laboratory; no physical validation or observed real demand.'}
    (args.output / 'MANIFEST.json').write_text(json.dumps(metadata, sort_keys=True, indent=2) + '\n')
    print(json.dumps(metadata))

if __name__ == '__main__':
    main()
