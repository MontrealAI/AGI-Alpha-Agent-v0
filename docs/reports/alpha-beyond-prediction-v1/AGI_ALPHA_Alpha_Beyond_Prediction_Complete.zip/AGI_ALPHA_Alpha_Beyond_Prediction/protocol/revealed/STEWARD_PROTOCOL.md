# Writer 11 held-out stewardship protocol

This is procedural role separation inside one automated research session. The builder and steward share a filesystem and model family. It is neither an independent organization, a human expert evaluation, tamperproof secrecy, nor evidence of anticipation of future real demand.

## Before disclosure

1. The builder publishes the supported finite grammar, input and output contracts, admissible information, validation semantics, and bounded resources. A task family can be structurally held out while its numerical primitives are supported in advance.
2. The steward prepares one structurally different family using only that grammar. The exact generator, parameters, scenarios, and outcomes remain undisclosed. The steward creates a ZIP and SHA-256 digest.
3. The builder freezes the implemented artifact, all comparator implementations, analysis, budgets, quality thresholds, statistical summaries, scenario-weight sensitivity and stopping rules. A content manifest binds each file by SHA-256. A dated note records that the builder has not inspected the hidden package.
4. The steward provides only the sealed package hash and metadata that cannot identify the family. The builder explicitly authorizes reveal after providing the freeze hash.

## Disclosure and execution

5. The steward records the supplied freeze hashes and reveal authorization verbatim in a local chronology record, then discloses the exact generator and scenarios. The original sealed archive is retained byte-for-byte.
6. All declared cases are executed, including failures. The first execution log remains authoritative. Restarts, infra failures, changed dependencies, and repairs are recorded; after-reveal implementation changes are exploratory unless a new unseen cohort is independently frozen.
7. Cases are scored by a validator that does not select the policy, fit parameters, or access future cases. Ground-truth values and held-out probes remain unavailable to the adaptive policy. Score all policies on paired instances with identical admissible observations and budgets.
8. Publish full raw outputs and a claim-to-artifact index. Mark simulator-only outcomes as synthetic; do not treat a simulation distribution as a calibrated demand forecast.

## Comparator requirements

The conventional modular comparator may construct every supported operator, interface, adaptation and reusable capability, with the same observations, priors, mathematical libraries, solver tolerances, and budgets. It may use the same compiled numerical kernels if that is the strongest straightforward implementation. Equal outcomes are an admissible and informative result. A named expert program is not an observed human-expert trial. Equal computational budgets do not establish equal human engineering effort, which must be measured or stated unknown.

Clairvoyant specialists have the final scenario in advance and are labeled an upper reference, not deployable ex ante alternatives. A static specialist and wait/abstain are lower-complexity references. Capability, adaptation and representation ablations must preserve all remaining information and budgets and each must be accompanied by the strongest conventional replacement.

## Scoring requirements

Predeclare feasibility before cost comparisons. Count verification, recovery and failed work. Report the components of construction, maintenance, execution, switching, validation, memory, wall time and human work separately rather than adding physically incompatible units. Use modeled tariffs only as clearly labeled scenario costs; never present them as observed prices, revenue or money saved. Report tail loss, all refusals, shared failures, capacity interactions and worst-case scenario-weight shifts. Report measured runtime separately from deterministic work units.
