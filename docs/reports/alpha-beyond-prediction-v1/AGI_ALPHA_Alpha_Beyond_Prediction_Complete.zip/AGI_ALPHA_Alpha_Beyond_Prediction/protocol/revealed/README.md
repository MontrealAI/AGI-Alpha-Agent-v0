# Revealed held-out family

The exact family is coded-aperture emission imaging. A nonnegative 2D spatial field is represented by six localized basis components. Thirty coded aperture actions integrate the field through rectangles, stripe masks, or sparse masks. Acquisition returns Poisson photon counts under known exposure and background. This differs from the development tasks in geometry, measurement aggregation, and likelihood; it still uses the predeclared finite operator grammar and is not a claim of arbitrary scientific transfer.

The original sealed generator and manifest are unchanged. The 32 cases comprise eight instances for each predeclared stress class: normal, correlated calibration failure, unavailable action group, and delayed authority. They use a paired set of latent fields and instrument layouts. The exact source, seeds and truths are now public for reproduction. During policy execution, only the public contract, selected measurement observations, current authority, and currently released health evidence are admissible.

`SEALED_HOLDOUT.zip` is the original 6,275-byte sealed object, SHA-256 `6bfc5076c2ea4b8f40acb01dac862e87975facdf71591a0f9768fa78cc6a13a4`. `SEALED_MANIFEST.json` hashes its original members. `materialize.py` and this README are post-reveal packaging helpers, not part of the original seal. They do not change generation or policy logic.

## Exact materialization

Run from the complete package root, using a new output path:

```bash
python protocol/revealed/materialize.py --output evidence/reproduced-heldout-cases.json
```

The expected output is 6,668,606 bytes with SHA-256 `4788d502763f3ec6d40e160a845d55c100d09e1f07390f0cd8610a350fe9da5a`. The helper refuses to overwrite an existing file. It calls the exact sealed generator and writes a deterministic JSON array. The generator's own CLI can alternatively emit separate case files and a manifest:

```bash
python protocol/revealed/generator.py --output evidence/reproduced-heldout-files
```

## Primary held-out run

```bash
PYTHONPATH=src python src/experiments.py confirm --cases evidence/heldout-reveal/cases-raw.json --output evidence/heldout-confirm
```

The root owns the first primary confirmation run; the steward did not duplicate it. All 32 interfaces were checked using the frozen constructor, and their derived operators agreed with independently coded analytical quadrature to maximum absolute error 2.7755575615628914e-17. This compatibility check did not fit any policy or score any experimental outcome.

The frozen evaluator normalizes explicit metadata aliases, preserves raw cases, uses the declared keyed count stream, and separates verification using repeat indices 1000+k. It exposes health events only at the current tick. Quarantine preserves sunk acquisition costs, excludes suspect observations, and requires fresh verification; it does not reveal or apply hidden calibration factors to operational policies. Hindsight privileges are labeled separately.

This is a fully synthetic finite digital laboratory. It is not physical validation, prospective deployment, real observed demand, a human-expert trial, or evidence of commercial adoption. Blindness was procedural role separation within one session and a shared filesystem.
