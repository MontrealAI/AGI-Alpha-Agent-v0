# Pre-freeze interface review

The steward reviewed only the builder public interface after sealing the generator. The sealed archive was not changed. No confirmation cases were generated or scored. Disclosure was restricted to compatibility metadata; the family, values, action identifiers, seeds, and generator source remained undisclosed.

- The initial schema did not cap quadrature at 32 points; the builder implementation added that cap. A bounded 256-point cap was recommended before freeze.
- Hidden metadata aliases must be normalized explicitly: nuisance_truth, case_seed, stress_class, gain_by_group and nested context authority times. Original input bytes must remain in evidence.
- Group gains are evaluator-only physical truth; policy access would invalidate the intended information boundary.
- A gain_suspect health event becomes visible once at its scheduled tick. It identifies suspect public action groups and explicitly supplies no exact calibration. Conservative quarantine, sunk-cost accounting, fit rebuilding using admissible surviving data, or abstention are legitimate. New model authority is not implied.
- The sealed keyed count stream is SHA-256(case ID | action ID | repeat), first 128 bits big-endian, PCG64, Poisson. Verification uses a documented disjoint repeat namespace fixed before freeze.
- A truth-informed design heuristic is not automatically an upper bound or optimized hindsight specialist.
- A matrix roundtrip performed after AST construction is a postconstruction representation substitute, not evidence that construction of the representation can be removed at zero cost.
- Residual verification is model-conditional; report true quality, verification and false acceptance separately.
