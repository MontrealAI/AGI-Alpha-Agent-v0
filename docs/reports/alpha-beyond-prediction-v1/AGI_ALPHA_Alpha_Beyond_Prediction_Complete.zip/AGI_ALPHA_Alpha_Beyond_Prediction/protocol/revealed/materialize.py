from pathlib import Path
import argparse, hashlib, json
from generator import generate_cases
p=argparse.ArgumentParser()
p.add_argument('--output',type=Path,required=True)
a=p.parse_args()
a.output.parent.mkdir(parents=True,exist_ok=True)
raw=(json.dumps(generate_cases(),sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()
with a.output.open('xb') as f:
    f.write(raw)
print(json.dumps({'path':str(a.output),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}))
