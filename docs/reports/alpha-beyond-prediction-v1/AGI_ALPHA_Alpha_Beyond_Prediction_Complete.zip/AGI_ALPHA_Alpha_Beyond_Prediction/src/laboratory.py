from __future__ import annotations
import hashlib
import json
import math
import time
from dataclasses import dataclass, field
from typing import Any, Callable
import numpy as np
from scipy.optimize import minimize

VERSION = 'aperture-1'
METHODS = ('aperture', 'modular', 'flat', 'uniform', 'gaussian_surrogate', 'frozen_specialist', 'wait', 'hindsight')

def digest(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()

@dataclass
class Meter:
    ast_nodes: int = 0
    rows_constructed: int = 0
    candidate_scores: int = 0
    feasible_candidates: int = 0
    solver_calls: int = 0
    objective_calls: int = 0
    acquisitions: int = 0
    acquisition_units: int = 0
    verification_acquisitions: int = 0
    verification_units: int = 0
    switching_events: int = 0
    recovery_events: int = 0
    wait_steps: int = 0
    setup_wall_s: float = 0.0
    total_wall_s: float = 0.0
    cpu_s: float = 0.0

def expression(node: dict[str, Any], points: np.ndarray, meter: Meter, depth: int = 0) -> np.ndarray:
    if depth > 16 or not isinstance(node, dict):
        raise ValueError('expression depth or type')
    meter.ast_nodes += 1
    op = node.get('op')
    if op == 'const':
        out = np.full(len(points), float(node['value']))
    elif op == 'coord':
        axis = node['axis']
        if isinstance(axis, bool) or not isinstance(axis, int) or not 0 <= axis < points.shape[1]:
            raise ValueError('coordinate axis')
        out = points[:, axis]
    elif op in ('add', 'mul'):
        args = node['args']
        if not isinstance(args, list) or not 1 <= len(args) <= 16:
            raise ValueError('expression arity')
        values = [expression(a, points, meter, depth + 1) for a in args]
        out = np.sum(values, axis=0) if op == 'add' else np.prod(values, axis=0)
    elif op in ('exp', 'sin', 'cos'):
        arg = expression(node['arg'], points, meter, depth + 1)
        if op == 'exp' and np.max(arg) > 40:
            raise ValueError('exponential overflow boundary')
        out = {'exp': np.exp, 'sin': np.sin, 'cos': np.cos}[op](arg)
    elif op == 'gaussian':
        sigma = float(node['sigma'])
        if not sigma > 0:
            raise ValueError('Gaussian width')
        out = np.exp(-0.5 * ((points[:, int(node['axis'])] - float(node['mu'])) / sigma) ** 2)
    elif op == 'causal_exp':
        t = points[:, int(node.get('axis', 0))]
        rate = float(node['rate'])
        if not rate > 0 or len(node['impulses']) > 32:
            raise ValueError('causal kernel')
        out = np.zeros(len(t))
        for onset, amplitude in node['impulses']:
            age = t - float(onset)
            out += float(amplitude) * np.exp(-rate * np.maximum(age, 0)) * (age >= 0)
    else:
        raise ValueError('unsupported expression: ' + str(op))
    if not np.isfinite(out).all() or np.max(np.abs(out), initial=0) > 1e12:
        raise ValueError('nonfinite or unbounded expression')
    return out

def basis_matrix(basis: list[dict[str, Any]], points: list[list[float]], meter: Meter | None = None) -> np.ndarray:
    q = np.asarray(points, dtype=float)
    if q.ndim != 2 or not 1 <= q.shape[1] <= 3 or not np.isfinite(q).all():
        raise ValueError('point matrix')
    return np.column_stack([expression(b, q, meter or Meter()) for b in basis])

@dataclass
class Program:
    public: dict[str, Any]
    A: np.ndarray
    Z: np.ndarray
    costs: np.ndarray
    available: np.ndarray
    identity: str
    meter: Meter

def construct(public: dict[str, Any], mode: str = 'aperture') -> Program:
    start = time.perf_counter()
    public = json.loads(json.dumps(public, allow_nan=False))
    p = public.get('dim')
    if public.get('schema') != 1 or type(p) is not int or not 1 <= p <= 8:
        raise ValueError('schema/dimension')
    if public.get('likelihood') not in ('gaussian', 'poisson'):
        raise ValueError('unsupported likelihood')
    actions, basis = public['actions'], public['basis']
    if len(basis) != p or not 1 <= len(actions) <= 160:
        raise ValueError('bounded model')
    if len({a['id'] for a in actions}) != len(actions):
        raise ValueError('duplicate action')
    if type(public['budget']) is not int or not 1 <= public['budget'] <= 48:
        raise ValueError('bounded acquisition budget')
    if type(public.get('verify_count', 4)) is not int or not 0 <= public.get('verify_count', 4) <= 8:
        raise ValueError('bounded verification')
    if not 0 < float(public['quality_threshold']) <= 1:
        raise ValueError('quality threshold')
    meter = Meter()
    rows, costs = [], []
    for action in actions:
        points, weights = action['points'], np.asarray(action['weights'], dtype=float)
        if not 1 <= len(points) <= 256 or weights.shape != (len(points),) or not np.isfinite(weights).all():
            raise ValueError('bounded aggregation')
        cost = action['cost']
        if type(cost) is not int or not 1 <= cost <= 8:
            raise ValueError('integer physical acquisition cost')
        # Both implementations use conventional NumPy operators and identical construction powers.
        values = basis_matrix(basis, points, meter)
        row = weights @ values if mode != 'modular' else np.sum(weights[:, None] * values, axis=0)
        rows.append(row)
        costs.append(cost)
        meter.rows_constructed += 1
    A = np.asarray(rows)
    if not np.isfinite(A).all():
        raise ValueError('invalid compiled operator')
    n = len(actions)
    nuisance = public.get('nuisance', [])
    Z = np.column_stack([np.asarray(z['values'], dtype=float) for z in nuisance]) if nuisance else np.zeros((n, 0))
    if Z.shape[0] != n or Z.shape[1] > 3 or not np.isfinite(Z).all():
        raise ValueError('nuisance interface')
    if public['likelihood'] == 'poisson':
        if np.min(A) < -1e-12 or Z.shape[1] or not float(public['exposure']) > 0 or float(public['background']) <= 0:
            raise ValueError('positive count model')
    elif not float(public['noise_sd']) > 0:
        raise ValueError('Gaussian noise scale')
    available = np.asarray(public.get('available', [True] * n))
    if available.dtype != bool or available.shape != (n,):
        raise ValueError('availability mask')
    prior = np.asarray(public['prior_mean'], dtype=float)
    if prior.shape != (p,) or not np.isfinite(prior).all() or not float(public['prior_scale']) > 0:
        raise ValueError('prior contract')
    meter.setup_wall_s = time.perf_counter() - start
    return Program(public, A, Z, np.asarray(costs), available, digest(public), meter)

def authority_ok(authority: dict[str, Any], program: Program, tick: int) -> tuple[bool, str]:
    if not isinstance(authority, dict):
        return False, 'missing explicit authority'
    if authority.get('schema') != 1 or authority.get('scope') != 'local-synthetic-measurement':
        return False, 'incompatible authority scope'
    if authority.get('live_actions') is not False:
        return False, 'live action authority is outside this artifact'
    if any(type(authority.get(k)) is not int for k in ('not_before', 'expires', 'max_units')):
        return False, 'invalid authority bounds'
    if authority.get('mission_id') != program.public['id'] or authority.get('plan_hash') != program.identity:
        return False, 'authority does not bind this immutable mission'
    if tick < authority.get('not_before', 0):
        return False, 'authority not yet active'
    if tick >= authority.get('expires', -1):
        return False, 'authority expired'
    if authority.get('max_units', -1) < program.public['budget'] + 8 * program.public.get('verify_count', 4):
        return False, 'authority budget insufficient'
    return True, 'permitted local synthetic work'

def make_authority(public: dict[str, Any], not_before: int = 0, expires: int = 128) -> dict[str, Any]:
    return {'schema': 1, 'scope': 'local-synthetic-measurement', 'mission_id': public['id'],
            'plan_hash': digest(public), 'not_before': not_before, 'expires': expires,
            'max_units': public['budget'] + 8 * public.get('verify_count', 4),
            'issuer': 'explicit bounded research fixture; not a credential', 'live_actions': False}

def lower_flat(program: Program) -> dict[str, Any]:
    metadata = {k: v for k, v in program.public.items() if k not in ('basis', 'nuisance', 'actions')}
    metadata['actions'] = [{k: a[k] for k in ('id', 'cost', 'group')} for a in program.public['actions']]
    return {'schema': 1, 'contract': metadata, 'matrix': program.A.tolist(), 'nuisance': program.Z.tolist(),
            'source_hash': program.identity, 'costs': program.costs.tolist(), 'available': program.available.tolist()}

def load_flat(payload: dict[str, Any], original: Program) -> Program:
    if digest(payload) != digest(lower_flat(original)):
        raise ValueError('flat payload differs from its immutable source plan')
    if payload.get('schema') != 1 or payload.get('source_hash') != original.identity:
        raise ValueError('flat representation provenance')
    A, Z = np.asarray(payload['matrix']), np.asarray(payload['nuisance'])
    if A.shape != original.A.shape or Z.shape != original.Z.shape or not np.array_equal(A, original.A) or not np.array_equal(Z, original.Z):
        raise ValueError('flat operator mismatch')
    return Program(payload['contract'], A, Z, np.asarray(payload['costs']), np.asarray(payload['available']),
                   original.identity, original.meter)

def fit_gaussian(A: np.ndarray, y: np.ndarray, variance: np.ndarray, prior: np.ndarray,
                 scale: float, meter: Meter) -> tuple[np.ndarray, np.ndarray]:
    meter.solver_calls += 1
    prior_precision = np.eye(A.shape[1]) / scale ** 2
    precision = prior_precision + A.T @ (A / variance[:, None])
    rhs = prior_precision @ prior + A.T @ (y / variance)
    cov = np.linalg.inv(precision)
    return cov @ rhs, cov

def fit_poisson(A: np.ndarray, y: np.ndarray, exposure: float, background: float,
                initial: np.ndarray, prior: np.ndarray, scale: float, meter: Meter) -> tuple[np.ndarray, np.ndarray, bool]:
    meter.solver_calls += 1
    precision = 1 / scale ** 2
    def objective(theta: np.ndarray) -> tuple[float, np.ndarray]:
        meter.objective_calls += 1
        mean = exposure * (background + A @ theta)
        if np.min(mean) <= 0:
            return 1e100, np.zeros_like(theta)
        delta = theta - prior
        loss = float(np.sum(mean - y * np.log(mean)) + .5 * precision * (delta @ delta))
        gradient = exposure * A.T @ (1 - y / mean) + precision * delta
        return loss, gradient
    opt = minimize(objective, np.maximum(initial, 1e-6), jac=True, method='L-BFGS-B',
                   bounds=[(0, None)] * len(prior), options={'ftol': 1e-12, 'gtol': 1e-8, 'maxiter': 400})
    theta = np.asarray(opt.x)
    weights = exposure / (background + A @ theta)
    cov = np.linalg.inv(A.T @ (A * weights[:, None]) + precision * np.eye(A.shape[1]))
    return theta, cov, bool(opt.success)

def solve(public: dict[str, Any], observe: Callable[[int, int, str], float], method: str = 'aperture',
          authority: dict[str, Any] | None = None, oracle_theta: list[float] | None = None,
          on_tick: Callable[[int], list[dict[str, Any]]] | None = None) -> dict[str, Any]:
    if method not in METHODS:
        raise ValueError('unknown method')
    wall, cpu = time.perf_counter(), time.process_time()
    if method == 'wait' or (method == 'frozen_specialist' and public['family'] != 'spectral-characterization'):
        meter = Meter()
        reason = 'wait-only policy' if method == 'wait' else 'family requires replacement'
        meter.total_wall_s, meter.cpu_s = time.perf_counter() - wall, time.process_time() - cpu
        return {'method': method, 'status': 'abstained', 'reason': reason, 'theta': None,
                'events': [{'event': 'abstain', 'tick': 0, 'reason': reason}], 'costs': vars(meter),
                'program_hash': digest(public), 'verification_pass': False}
    program = construct(public, 'modular' if method == 'modular' else 'aperture')
    if method == 'flat':
        program = load_flat(json.loads(json.dumps(lower_flat(program))), program)
    public, meter, A, Z = program.public, program.meter, program.A, program.Z
    p, n = public['dim'], len(A)
    events: list[dict[str, Any]] = []
    tick = 0
    allowed, reason = authority_ok(authority, program, tick)
    while not allowed and reason == 'authority not yet active' and tick < 3:
        events.append({'event': 'wait', 'tick': tick, 'reason': reason})
        tick += 1
        meter.wait_steps += 1
        allowed, reason = authority_ok(authority, program, tick)
    refused = not allowed or method == 'wait' or (method == 'frozen_specialist' and public['family'] != 'spectral-characterization')
    if refused:
        refusal = reason if not allowed else ('wait-only policy' if method == 'wait' else 'family requires replacement')
        events.append({'event': 'abstain', 'tick': tick, 'reason': refusal})
        meter.total_wall_s, meter.cpu_s = time.perf_counter() - wall, time.process_time() - cpu
        return {'method': method, 'status': 'abstained', 'reason': events[-1]['reason'], 'theta': None,
                'events': events, 'costs': vars(meter), 'program_hash': program.identity, 'verification_pass': False}
    prior = np.asarray(public['prior_mean'], dtype=float)
    scale = float(public['prior_scale'])
    likelihood = public['likelihood']
    X = np.column_stack([A, Z]) if likelihood == 'gaussian' else A
    extended_prior = np.r_[prior, np.zeros(Z.shape[1])] if likelihood == 'gaussian' else prior.copy()
    estimate = extended_prior.copy()
    covariance = np.eye(X.shape[1]) * scale ** 2
    repetitions = np.zeros(n, dtype=int)
    chosen, ys, solver_success = [], [], True
    available = program.available.copy()
    def refit() -> None:
        nonlocal estimate, covariance, solver_success
        if not chosen:
            estimate = extended_prior.copy()
            covariance = np.eye(X.shape[1]) * scale ** 2
            return
        used = np.asarray(chosen)
        observations = np.asarray(ys)
        if likelihood == 'gaussian':
            estimate, covariance = fit_gaussian(X[used], observations,
                                                np.full(len(used), public['noise_sd'] ** 2), extended_prior, scale, meter)
        elif method == 'gaussian_surrogate':
            variance_used = (public['background'] + A[used] @ np.maximum(prior, 0)) / public['exposure']
            estimate, covariance = fit_gaussian(A[used], observations / public['exposure'] - public['background'],
                                                variance_used, prior, scale, meter)
            estimate = np.maximum(estimate, 0)
        else:
            estimate, covariance, success = fit_poisson(A[used], observations, public['exposure'], public['background'],
                                                       estimate, prior, scale, meter)
            solver_success = solver_success and success
    def process_health(current_tick: int) -> bool:
        nonlocal chosen, ys
        changed = False
        for event in on_tick(current_tick) if on_tick is not None else []:
            changed = True
            if event.get('kind') != 'gain_suspect' or event.get('exact_gain_disclosed') is not False:
                raise ValueError('health update requires a new separately authorized model')
            groups = set(event['groups'])
            known = {a['group'] for a in public['actions']}
            if not groups <= known:
                raise ValueError('unknown action group in health evidence')
            banned = np.array([a['group'] in groups for a in public['actions']])
            available[banned] = False
            keep = [(i, y) for i, y in zip(chosen, ys) if not banned[i]]
            removed = len(chosen) - len(keep)
            chosen, ys = [x[0] for x in keep], [x[1] for x in keep]
            meter.recovery_events += 1
            events.append({'event': 'quarantine', 'tick': current_tick, 'groups': sorted(groups),
                           'removed_observations': removed, 'refund_units': 0, 'new_verification_required': public.get('verify_count', 4),
                           'plan_mutated': False, 'correction_factor_disclosed': False})
            refit()
        return changed
    for step in range(48):
        process_health(tick)
        allowed, reason = authority_ok(authority, program, tick)
        if not allowed:
            events.append({'event': 'authority_stop', 'tick': tick, 'reason': reason})
            break
        feasible = available & (repetitions < 3) & (program.costs <= public['budget'] - meter.acquisition_units)
        if not feasible.any():
            break
        if likelihood == 'gaussian':
            variance = np.full(n, float(public['noise_sd']) ** 2)
        else:
            design_theta = np.asarray(oracle_theta) if method == 'hindsight' and oracle_theta is not None else estimate[:p]
            variance = (float(public['background']) + A @ np.maximum(design_theta, 0)) / float(public['exposure'])
        if method == 'uniform':
            candidates = np.flatnonzero(feasible)
            index = int(candidates[(step * 7) % len(candidates)])
        else:
            gains = np.einsum('ij,jk,ik->i', X, covariance, X) / variance
            scores = np.log1p(np.maximum(gains, 0)) / program.costs
            scores[~feasible] = -np.inf
            meter.candidate_scores += n
            meter.feasible_candidates += int(feasible.sum())
            # Canonical tie-breaking makes all same-powers representations directly comparable.
            best = np.max(scores)
            index = int(np.flatnonzero(feasible & (scores >= best - 1e-11))[0])
        value = float(observe(index, int(repetitions[index]), 'acquisition'))
        meter.acquisitions += 1
        meter.acquisition_units += int(program.costs[index])
        repetitions[index] += 1
        chosen.append(index)
        ys.append(value)
        events.append({'event': 'acquire', 'tick': tick, 'action': public['actions'][index]['id'],
                       'repeat': int(repetitions[index] - 1), 'value': value if math.isfinite(value) else None,
                       'units': int(program.costs[index]), 'irreversible': True})
        valid_count = likelihood != 'poisson' or (value >= 0 and math.isfinite(value) and abs(value - round(value)) <= 1e-9)
        if not math.isfinite(value) or not valid_count:
            available[index] = False
            chosen.pop()
            ys.pop()
            meter.recovery_events += 1
            events.append({'event': 'recover', 'tick': tick, 'action': public['actions'][index]['id'], 'refund_units': 0,
                           'reason': 'nonfinite observation' if not math.isfinite(value) else 'invalid Poisson count'})
            tick += 1
            continue
        refit()
        tick += 1
    verification_scores = []
    for k in range(public.get('verify_count', 4)):
        if process_health(tick):
            verification_scores.clear()
        allowed, reason = authority_ok(authority, program, tick)
        indices = np.flatnonzero(available)
        if not allowed or not len(indices) or not len(chosen):
            break
        index = int(indices[(k * 11 + 3) % len(indices)])
        value = float(observe(index, k, 'verification'))
        meter.verification_acquisitions += 1
        meter.verification_units += int(program.costs[index])
        if likelihood == 'gaussian':
            mean = float(X[index] @ estimate)
            variance = float(public['noise_sd'] ** 2 + X[index] @ covariance @ X[index])
        else:
            mean = float(public['exposure'] * (public['background'] + A[index] @ estimate[:p]))
            variance = float(max(mean, 1e-8) + public['exposure'] ** 2 * A[index] @ covariance[:p, :p] @ A[index])
        valid_value = math.isfinite(value) and (likelihood != 'poisson' or (value >= 0 and abs(value - round(value)) <= 1e-9))
        score = (value - mean) ** 2 / max(variance, 1e-12) if valid_value else 1e100
        verification_scores.append(float(score))
        events.append({'event': 'verify', 'tick': tick, 'action': public['actions'][index]['id'],
                       'value': value if math.isfinite(value) else None, 'normalized_squared_residual': float(score),
                       'units': int(program.costs[index]), 'irreversible': True, 'observation_valid': valid_value})
        tick += 1
    passed = len(verification_scores) == public.get('verify_count', 4) and bool(verification_scores) and np.mean(verification_scores) <= 4
    meter.total_wall_s, meter.cpu_s = time.perf_counter() - wall, time.process_time() - cpu
    return {'method': method, 'status': 'completed' if chosen else 'no_capacity', 'theta': estimate[:p].tolist(),
            'nuisance_estimate': estimate[p:].tolist(), 'events': events, 'costs': vars(meter), 'program_hash': program.identity,
            'verification_pass': bool(passed), 'verification_statistic': float(np.mean(verification_scores)) if verification_scores else None,
            'solver_all_success': solver_success, 'selected_actions': chosen,
            'limitations': 'Bayesian design and residual checks are model-conditional; not a quality guarantee or authority grant.'}

def snapshot(world: dict[str, Any], policy: dict[str, Any], proof: dict[str, Any], authority: dict[str, Any]) -> dict[str, Any]:
    payload = {'schema': 1, 'World': world, 'Policy': policy, 'Proof': proof, 'Authority': authority}
    return {'payload': payload, 'sha256': digest(payload)}

def restore(bundle: dict[str, Any], tick: int, expected_mission: str,
            current_authority: dict[str, Any] | None = None) -> dict[str, Any]:
    payload = bundle['payload']
    if bundle.get('sha256') != digest(payload) or payload.get('schema') != 1:
        raise ValueError('snapshot integrity/version')
    program = construct(payload['World']['mission'])
    if program.public['id'] != expected_mission:
        raise ValueError('different mission requires fresh bounded authority')
    if current_authority is None or digest(payload['Authority']) != digest(current_authority):
        raise ValueError('restoration requires separately supplied unchanged current authority')
    ok, reason = authority_ok(payload['Authority'], program, tick)
    if not ok:
        raise ValueError(reason)
    if payload['Policy'].get('program_hash') != program.identity or payload['Proof'].get('program_hash') != program.identity:
        raise ValueError('incompatible program version')
    return json.loads(json.dumps(payload))
