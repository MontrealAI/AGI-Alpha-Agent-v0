from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
from laboratory import METHODS, basis_matrix, digest
from experiments import normalize_case, write_json

TIMING_KEYS = {'setup_wall_s', 'total_wall_s', 'cpu_s'}

def scientific_view(value):
    if isinstance(value, dict):
        return {k: scientific_view(v) for k, v in value.items() if k not in TIMING_KEYS}
    if isinstance(value, list):
        return [scientific_view(v) for v in value]
    return value

def verify(cases: list[dict], records: list[dict]) -> dict:
    by_id = {c['public']['id']: normalize_case(c) for c in cases}
    assert len(by_id) == len(cases)
    identities = {(r['case_id'], r['method']) for r in records}
    assert len(identities) == len(records) == len(cases) * len(METHODS)
    assert identities == {(i, m) for i in by_id for m in METHODS}
    errors, acqunits, verifyunits, recovered = [], 0, 0, 0
    for r in records:
        case = by_id[r['case_id']]
        public, hidden = case['public'], case['hidden']
        assert r['input_hash'] == digest(public)
        assert r['costs']['acquisition_units'] <= public['budget']
        assert r['costs']['verification_acquisitions'] <= public['verify_count']
        acquisitions = [e for e in r['events'] if e['event'] == 'acquire']
        verifications = [e for e in r['events'] if e['event'] == 'verify']
        assert r['costs']['acquisitions'] == len(acquisitions)
        assert r['costs']['verification_acquisitions'] == len(verifications)
        assert r['costs']['acquisition_units'] == sum(e['units'] for e in acquisitions)
        assert r['costs']['verification_units'] == sum(e['units'] for e in verifications)
        assert r['callback_count'] == len(acquisitions) + len(verifications)
        assert r['costs']['candidate_scores'] == (0 if r['method'] in ('uniform', 'wait') else len(public['actions']) * len(acquisitions))
        assert all(e.get('refund_units', 0) == 0 for e in r['events'])
        for e in acquisitions + verifications:
            assert hidden.get('not_before', 0) <= e['tick'] < hidden.get('expires', 128)
        if r['theta'] is not None:
            V = np.asarray(hidden['validation_matrix']) if 'validation_matrix' in hidden else basis_matrix(public['basis'], hidden['validation_points'])
            true = V @ np.asarray(hidden['theta'])
            error = float(np.sqrt(np.mean((V @ np.asarray(r['theta']) - true) ** 2)) / max(float(np.sqrt(np.mean(true ** 2))), 1e-8))
            assert abs(error - r['nrmse']) <= 1e-12
            assert r['scientific_pass'] == (error <= public['quality_threshold'])
            errors.append(error)
        else:
            assert r['scientific_pass'] is False
        assert r['qualified'] == (r['scientific_pass'] and r['verification_pass'])
        assert r['false_accept'] == (r['verification_pass'] and not r['scientific_pass'])
        acqunits += r['costs']['acquisition_units']
        verifyunits += r['costs']['verification_units']
        recovered += r['costs']['recovery_events']
    return {'passed': True, 'cases': len(cases), 'records': len(records), 'unique_identities': len(identities),
            'event_acquisition_units': acqunits, 'event_verification_units': verifyunits, 'recovery_events': recovered,
            'scientific_records_sha256': digest(scientific_view(records)),
            'scope': 'Quality recomputation and event/cost/authority consistency; independent formula checks are separate.'}

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--cases', type=Path, required=True)
    p.add_argument('--records', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--compare', type=Path)
    args = p.parse_args()
    records = json.loads(args.records.read_text())
    report = verify(json.loads(args.cases.read_text()), records)
    if args.compare:
        expected = json.loads(args.compare.read_text())
        report['exact_numerical_event_reproduction'] = scientific_view(records) == scientific_view(expected)
        assert report['exact_numerical_event_reproduction']
    write_json(args.output, report)
    print(json.dumps(report))

if __name__ == '__main__':
    main()
