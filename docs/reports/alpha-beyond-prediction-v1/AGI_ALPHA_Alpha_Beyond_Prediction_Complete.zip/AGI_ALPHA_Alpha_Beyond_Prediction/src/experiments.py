from __future__ import annotations
import argparse
import copy
import hashlib
import json
import os
import platform
import sys
import time
from pathlib import Path
import numpy as np
from laboratory import METHODS, Meter, basis_matrix, construct, digest, make_authority, restore, snapshot, solve

ROOT = Path(__file__).resolve().parents[1]
STRESSES = ('nominal', 'calibration_failure', 'capacity_loss', 'delayed_authority')

def development_case(family: str, seed: int, stress: str) -> dict:
    rng = np.random.default_rng(seed)
    if family == 'spectral-characterization':
        basis = [{'op': 'gaussian', 'axis': 0, 'mu': mu, 'sigma': width}
                 for mu, width in ((.18, .07), (.48, .09), (.78, .065))]
        coordinates = np.linspace(0, 1, 60)
        probes = np.linspace(0, 1, 161)[:, None].tolist()
        nuisance = [{'name': 'unknown-baseline', 'values': [1.] * 60}]
        sd = .035
    elif family == 'causal-system-identification':
        basis = [{'op': 'causal_exp', 'axis': 0, 'rate': rate, 'impulses': [[0, 1], [2, -.5], [4, 1.3]]}
                 for rate in (.3, 1.0, 2.5)]
        coordinates = np.linspace(.02, 8, 60)
        probes = np.linspace(.01, 8, 161)[:, None].tolist()
        nuisance = [{'name': 'unknown-drift', 'values': (coordinates / 8).tolist()}]
        sd = .03
    else:
        raise ValueError(family)
    actions = [{'id': f'm{i:02}', 'points': [[float(x)]], 'weights': [1.], 'cost': 1,
                'group': f'g{i // 15}'} for i, x in enumerate(coordinates)]
    public = {'schema': 1, 'id': f'{family}-{seed}-{stress}', 'family': family,
              'dim': 3, 'basis': basis, 'actions': actions, 'likelihood': 'gaussian', 'nuisance': nuisance,
              'noise_sd': sd, 'budget': 24, 'verify_count': 4, 'quality_threshold': .12,
              'prior_mean': [1., 1., 1.], 'prior_scale': 5., 'available': [True] * len(actions)}
    if stress == 'capacity_loss':
        public['available'] = [a['group'] != 'g1' for a in actions]
        public['budget'] = 12
    return {'public': public, 'hidden': {'theta': rng.uniform(.5, 2, 3).tolist(),
              'nuisance_theta': [float(rng.uniform(-.25, .25))], 'validation_points': probes,
              'gain': 1.32 if stress == 'calibration_failure' else 1., 'seed': seed,
              'stress': stress, 'not_before': 2 if stress == 'delayed_authority' else 0,
              'calibration_failure': stress == 'calibration_failure'}}

def noise_rng(case_id: str, seed: int, action: int, repeat: int, purpose: str) -> np.random.Generator:
    key = f'{case_id}/{seed}/{action}/{repeat}/{purpose}'.encode()
    return np.random.default_rng(int.from_bytes(hashlib.sha256(key).digest()[:8], 'little'))

def normalize_case(raw: dict) -> dict:
    case = copy.deepcopy(raw)
    hidden, public = case['hidden'], case['public']
    mapping = {'nuisance_truth': 'nuisance_theta', 'case_seed': 'seed', 'stress_class': 'stress'}
    for old, new in mapping.items():
        if old in hidden:
            hidden[new] = hidden[old]
    if 'case_seed' in hidden:
        hidden['sealed_stream'] = True
    context = hidden.get('context', case.get('context', {}))
    hidden['not_before'] = context.get('authority_not_before_step', hidden.get('not_before', 0))
    hidden['expires'] = context.get('authority_expires_after_step', hidden.get('expires', 128))
    hidden['health_events'] = context.get('health_events', hidden.get('health_events', []))
    if 'gain_by_group' in hidden:
        hidden['action_gains'] = [hidden['gain_by_group'].get(a['group'], 1.) for a in public['actions']]
    return case

def evaluate(case: dict, methods: tuple[str, ...] = METHODS) -> list[dict]:
    case = normalize_case(case)
    public, hidden = case['public'], case['hidden']
    program = construct(public)
    theta = np.asarray(hidden['theta'], dtype=float)
    nuisance = np.asarray(hidden.get('nuisance_theta', [0.] * program.Z.shape[1]))
    true_mean = program.A @ theta
    gain = hidden.get('gain', 1.)
    action_gains = np.asarray(hidden.get('action_gains', [gain] * len(true_mean)))
    if 'validation_matrix' in hidden:
        V = np.asarray(hidden['validation_matrix'], dtype=float)
    else:
        V = basis_matrix(public['basis'], hidden['validation_points'])
    truth = V @ theta
    calls = []
    def observe(action: int, repeat: int, purpose: str) -> float:
        calls.append((action, repeat, purpose))
        if hidden.get('sealed_stream', False):
            stream_repeat = repeat if purpose == 'acquisition' else 1000 + repeat
            key = f"{public['id']}|{public['actions'][action]['id']}|{stream_repeat}".encode()
            rng = np.random.Generator(np.random.PCG64(int.from_bytes(hashlib.sha256(key).digest()[:16], 'big')))
        else:
            rng = noise_rng(public['id'], int(hidden.get('seed', 1)), action, repeat, purpose)
        if action in hidden.get('failed_actions', []) and purpose == 'acquisition':
            return float('nan')
        if public['likelihood'] == 'gaussian':
            mean = action_gains[action] * true_mean[action]
            if program.Z.shape[1]:
                mean += program.Z[action] @ nuisance
            return float(mean + public['noise_sd'] * rng.normal())
        mean = public['exposure'] * (public['background'] + action_gains[action] * true_mean[action])
        return float(rng.poisson(max(mean, 0)))
    outputs = []
    for method in methods:
        calls.clear()
        method_public = copy.deepcopy(public)
        if method == 'hindsight':
            method_public['id'] += '-known-calibration'
            for i, action in enumerate(method_public['actions']):
                action['weights'] = [float(w * action_gains[i]) for w in action['weights']]
            mask = method_public.get('available', [True] * len(program.A))
            method_public['available'] = [v and i not in hidden.get('failed_actions', []) for i, v in enumerate(mask)]
        emitted = set()
        def on_tick(tick: int) -> list[dict]:
            permitted = []
            for i, event in enumerate(hidden.get('health_events', [])):
                if i not in emitted and event['step'] <= tick:
                    emitted.add(i)
                    permitted.append({k: v for k, v in event.items() if k != 'step'})
            return permitted
        authority = make_authority(method_public, int(hidden.get('not_before', 0)), int(hidden.get('expires', 128)))
        result = solve(method_public, observe, method, authority, hidden['theta'] if method == 'hindsight' else None,
                       None if method == 'hindsight' else on_tick)
        result['case_id'], result['family'], result['stress'] = public['id'], public['family'], hidden.get('stress', 'nominal')
        if result['theta'] is None:
            result['nrmse'], result['scientific_pass'], result['qualified'] = None, False, False
        else:
            error = float(np.sqrt(np.mean((V @ np.asarray(result['theta']) - truth) ** 2)) /
                          max(float(np.sqrt(np.mean(truth ** 2))), 1e-8))
            result['nrmse'] = error
            result['scientific_pass'] = error <= public['quality_threshold']
            result['qualified'] = result['scientific_pass'] and result['verification_pass']
        result['false_accept'] = result['verification_pass'] and not result['scientific_pass']
        result['callback_count'] = len(calls)
        result['input_hash'] = digest(public)
        result['oracle_privilege'] = ('true calibration operator, failed-action identities, latent vector for design weights; '
                                      'no future noise; greedy scenario specialist, not a proven mathematical bound') if method == 'hindsight' else None
        outputs.append(result)
    return outputs

def robust_summary(rows: list[dict]) -> dict:
    groups = {}
    for method in METHODS:
        selected = [r for r in rows if r['method'] == method]
        if not selected:
            continue
        errors = [r['nrmse'] for r in selected if r['nrmse'] is not None]
        groups[method] = {'cases': len(selected), 'scientific_pass': sum(r['scientific_pass'] for r in selected),
                         'qualified': sum(r['qualified'] for r in selected), 'verification_pass': sum(r['verification_pass'] for r in selected),
                         'false_accept': sum(r['false_accept'] for r in selected),
                         'abstained': sum(r['status'] == 'abstained' for r in selected),
                         'median_nrmse': float(np.median(errors)) if errors else None,
                         'p90_nrmse': float(np.quantile(errors, .9)) if errors else None,
                         'max_nrmse': max(errors) if errors else None,
                         'total_acquisition_units': sum(r['costs']['acquisition_units'] for r in selected),
                         'total_verification_units': sum(r['costs']['verification_units'] for r in selected),
                         'total_wall_s': sum(r['costs']['total_wall_s'] for r in selected),
                         'total_cpu_s': sum(r['costs']['cpu_s'] for r in selected),
                         'total_solver_calls': sum(r['costs']['solver_calls'] for r in selected),
                         'total_objective_calls': sum(r['costs']['objective_calls'] for r in selected),
                         'total_candidate_scores': sum(r['costs']['candidate_scores'] for r in selected)}
    pairs = {r['case_id']: r for r in rows if r['method'] == 'modular'}
    a = [r for r in rows if r['method'] == 'aperture' and r['case_id'] in pairs]
    paired = {'n': len(a), 'max_abs_quality_difference': max((abs(r['nrmse'] - pairs[r['case_id']]['nrmse'])
                  for r in a if r['nrmse'] is not None and pairs[r['case_id']]['nrmse'] is not None), default=0),
              'different_qualification': sum(r['qualified'] != pairs[r['case_id']]['qualified'] for r in a),
              'different_selected_actions': sum(r.get('selected_actions') != pairs[r['case_id']].get('selected_actions') for r in a),
              'mean_setup_overhead_s': float(np.mean([r['costs']['setup_wall_s'] - pairs[r['case_id']]['costs']['setup_wall_s'] for r in a])) if a else None}
    return {'methods': groups, 'paired_aperture_vs_modular': paired,
            'interpretation': 'Finite-suite descriptive statistics; scenario weights are not probabilities of real demand.'}

def authority_checks(case: dict) -> dict:
    public = case['public']
    program = construct(public)
    bundle = snapshot({'mission': public}, {'program_hash': program.identity, 'method': 'aperture'},
                      {'program_hash': program.identity, 'status': 'no scientific outcome implied'}, make_authority(public, expires=20))
    trusted = copy.deepcopy(bundle['payload']['Authority'])
    restored = restore(bundle, 1, public['id'], trusted)
    checks = {'roundtrip': restored == bundle['payload']}
    for label, tick, mission in [('expired_refused', 20, public['id']), ('new_mission_refused', 1, 'materially-new-opportunity')]:
        try:
            restore(bundle, tick, mission, trusted)
            checks[label] = False
        except ValueError:
            checks[label] = True
    changed = copy.deepcopy(bundle)
    changed['payload']['World']['mission']['budget'] += 1
    try:
        restore(changed, 1, public['id'], trusted)
        checks['tampering_refused'] = False
    except ValueError:
        checks['tampering_refused'] = True
    changed['sha256'] = digest(changed['payload'])
    try:
        restore(changed, 1, public['id'], trusted)
        checks['rehash_cannot_revive_authority'] = False
    except ValueError:
        checks['rehash_cannot_revive_authority'] = True
    renewal = copy.deepcopy(bundle)
    renewal['payload']['Authority']['expires'] = 999
    renewal['sha256'] = digest(renewal['payload'])
    try:
        restore(renewal, 21, public['id'], trusted)
        checks['editable_snapshot_cannot_renew'] = False
    except ValueError:
        checks['editable_snapshot_cannot_renew'] = True
    assert all(checks.values())
    return {'checks': checks, 'snapshot': bundle,
            'scope': 'Research artifact restore; distinct from native Alpha portable export/restore.'}

def write_json(path: Path, obj: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, allow_nan=False) + '\n')

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=['pilot', 'confirm', 'analyze', 'authority'])
    parser.add_argument('--output', type=Path)
    parser.add_argument('--cases', type=Path)
    args = parser.parse_args()
    out = args.output or ROOT / 'evidence' / args.command
    if args.command == 'authority':
        result = authority_checks(development_case('spectral-characterization', 1, 'nominal'))
        write_json(out / 'authority.json', result)
        print(json.dumps(result['checks']))
        return
    if args.command == 'analyze':
        rows = json.loads(args.cases.read_text())
        result = robust_summary(rows)
        write_json(out / 'summary.json', result)
        print(json.dumps(result))
        return
    start = time.perf_counter()
    if args.cases:
        cases = json.loads(args.cases.read_text())
    else:
        seeds = range(1, 3) if args.command == 'pilot' else range(101, 109)
        cases = [development_case(family, seed, stress) for family in ('spectral-characterization', 'causal-system-identification')
                 for stress in STRESSES for seed in seeds]
    rows = []
    for case in cases:
        rows.extend(evaluate(case))
    summary = robust_summary(rows)
    summary['by_family_stress'] = {f'{f}/{s}': robust_summary([r for r in rows if r['family'] == f and r['stress'] == s])
                                  for f in sorted({r['family'] for r in rows}) for s in sorted({r['stress'] for r in rows})}
    write_json(out / 'cases.json', cases)
    write_json(out / 'records.json', rows)
    write_json(out / 'summary.json', summary)
    import scipy
    environment = {'python': sys.version, 'numpy': np.__version__, 'scipy': scipy.__version__,
                   'platform': platform.platform(), 'elapsed_s': time.perf_counter() - start,
                   'cpu_threads_env': {k: os.getenv(k) for k in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS')},
                   'human_effort': None, 'model_provider_compute': None, 'economic_price': None}
    write_json(out / 'environment.json', environment)
    print(json.dumps({'cases': len(cases), 'records': len(rows), 'summary': summary['methods'], 'paired': summary['paired_aperture_vs_modular']}))

if __name__ == '__main__':
    main()
