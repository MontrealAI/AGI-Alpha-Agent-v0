from __future__ import annotations
import argparse
import copy
import json
from pathlib import Path
import numpy as np
from experiments import evaluate, robust_summary, write_json
from laboratory import digest

def replay(cases: list[dict], method: str, strategy: str, capacity: int = 90, switch_units: int = 3) -> dict:
    remaining, last_family, last_verification = capacity, None, None
    events, records = [], []
    for tick, case in enumerate(cases):
        public = case['public']
        switch = switch_units if last_family is not None and last_family != public['family'] else 0
        quote = public['budget'] + public.get('verify_count', 4) * max(a['cost'] for a in public['actions'])
        event = {'tick': tick, 'new_mission_id': public['id'], 'plan_hash': digest(public),
                 'family': public['family'], 'current_evidence': {'last_verification': last_verification},
                 'remaining_before': remaining, 'quoted_execution_bound': quote, 'switch_units': switch}
        if strategy == 'wait' or (strategy == 'defer_first' and tick == 0):
            event.update(action='wait', units=0)
        elif strategy == 'stop_on_failed_verification' and last_verification is False:
            event.update(action='abstain', reason='past observed verification failed', units=0)
        elif quote + switch > remaining:
            event.update(action='abstain', reason='current bounded mission exceeds remaining capacity', units=0)
        else:
            result = evaluate(case, (method,))[0]
            execution_units = result['costs']['acquisition_units'] + result['costs']['verification_units']
            if result['status'] == 'abstained':
                event.update(action='abstain', reason=result['reason'], units=execution_units, switch_units=0,
                             previous_capability_preserved=True)
                remaining -= execution_units
                events.append(event)
                continue
            units = execution_units + switch
            remaining -= units
            last_family = public['family']
            last_verification = result['verification_pass']
            result['costs']['switching_events'] = int(switch > 0)
            records.append(result)
            event.update(action='execute', units=units, execution_units=units-switch,
                         verification_observed=result['verification_pass'], scientific_evaluator_pass=result['scientific_pass'],
                         irrecoverable_units=units, future_cases_visible=False, fresh_fixture_authority=True)
        events.append(event)
    qualified = sum(r['qualified'] for r in records)
    used = capacity - remaining
    return {'method': method, 'strategy': strategy, 'capacity_units': capacity, 'switch_tariff': switch_units,
            'used_units': used, 'qualified': qualified, 'attempts': len(records),
            'verification_false_accepts': sum(r['false_accept'] for r in records), 'events': events,
            'reward_sensitivity': [{'abstract_reward_per_qualified': v, 'net_score': v * qualified - used}
                                   for v in (0, 16, 32, 64)],
            'scope': 'Prospectively frozen local simulation; not prospective demand or market deployment. Switching tariff is assumed.'}

def schedules(cases: list[dict]) -> list[tuple[str, list[dict]]]:
    families = sorted({c['public']['family'] for c in cases})
    def get(family: str, stress: str, index: int = 0) -> dict:
        matches = [c for c in cases if c['public']['family'] == family and c['hidden'].get('stress') == stress]
        if not matches:
            raise ValueError(f'missing registered stratum {family}/{stress}')
        return copy.deepcopy(sorted(matches, key=lambda c: c['public']['id'])[index % len(matches)])
    a, b, c = families
    return [('stable', [get(a, 'nominal', i) for i in range(3)]),
            ('shift', [get(a, 'nominal'), get(b, 'nominal'), get(c, 'nominal')]),
            ('shared-failure', [get(a, 'calibration_failure'), get(b, 'calibration_failure'), get(c, 'calibration_failure')]),
            ('capacity-delay', [get(a, 'capacity_loss'), get(b, 'delayed_authority'), get(c, 'capacity_loss')])]

def analyze_weights(rows: list[dict]) -> dict:
    strata = sorted({(r['family'], r['stress']) for r in rows})
    diffs = []
    for family, stress in strata:
        a = [r for r in rows if r['family'] == family and r['stress'] == stress and r['method'] == 'aperture']
        b = [r for r in rows if r['family'] == family and r['stress'] == stress and r['method'] == 'modular']
        diffs.append({'family': family, 'stress': stress,
                      'coverage_delta': np.mean([r['qualified'] for r in a]) - np.mean([r['qualified'] for r in b]),
                      'acquisition_delta': np.mean([r['costs']['acquisition_units'] + r['costs']['verification_units'] for r in a]) -
                                           np.mean([r['costs']['acquisition_units'] + r['costs']['verification_units'] for r in b])})
    return {'stratum_differences': diffs, 'min_coverage_delta': min(d['coverage_delta'] for d in diffs),
            'max_coverage_delta': max(d['coverage_delta'] for d in diffs),
            'interpretation': 'Convex mixtures of these observed strata only. No statement about unseen futures.'}

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--cases', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    cases = json.loads(args.cases.read_text())
    outputs = []
    for label, sequence in schedules(cases):
        for method in ('aperture', 'modular', 'frozen_specialist'):
            for strategy in ('eager', 'defer_first', 'stop_on_failed_verification', 'wait'):
                for capacity in (60, 90):
                    for tariff in (0, 3, 12):
                        row = replay(sequence, method, strategy, capacity, tariff)
                        row['schedule'] = label
                        outputs.append(row)
    write_json(args.output / 'campaigns.json', outputs)
    print(json.dumps({'campaigns': len(outputs), 'qualified': sum(x['qualified'] for x in outputs),
                      'note': 'Repeated sensitivity replays, not independent scientific observations.'}))

if __name__ == '__main__':
    main()
