# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations
import argparse, hashlib, json, math, sys, time, zipfile
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from experiments import authority_checks, development_case, noise_rng
from laboratory import basis_matrix, construct, digest, make_authority, solve
from harness_adapter import run_pipeline

def hash_bytes(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()

def read_bound(path: Path, maximum: int = 40_000_000) -> tuple[object, dict]:
    if path.stat().st_size > maximum:
        raise ValueError('evidence input exceeds integration byte bound')
    raw = path.read_bytes()
    return json.loads(raw), {'path':str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else path.name,
                             'bytes':len(raw),'sha256':hash_bytes(raw)}

def native_numbers(value: object) -> object:
    if isinstance(value, float):
        if not math.isfinite(value): raise ValueError('nonfinite native result')
        return format(value, '.17g')
    if isinstance(value, dict): return {str(k):native_numbers(v) for k,v in value.items()}
    if isinstance(value, (list,tuple)): return [native_numbers(v) for v in value]
    if isinstance(value, (np.integer, np.bool_)): return value.item()
    return value

def main() -> None:
    parser=argparse.ArgumentParser(description='Run a source-bound native seven-stage audit and one bounded development example; not a rerun of confirmation.')
    parser.add_argument('--freeze',type=Path,required=True)
    parser.add_argument('--records',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--extra-evidence',type=Path,action='append',default=[])
    parser.add_argument('--phase',choices=['development','postconfirmation-audit'],default='postconfirmation-audit')
    args=parser.parse_args()
    wall,cpu=time.perf_counter(),time.process_time()
    freeze,freeze_ref=read_bound(args.freeze.resolve())
    records,records_ref=read_bound(args.records.resolve())
    pilot,pilot_ref=read_bound(ROOT/'evidence/pilot/nist_results.json')
    source_manifest,source_ref=read_bound(Path(__file__).resolve().parent/'source_manifest.json')
    for item in source_manifest['files']:
        body=(Path(__file__).resolve().parent/item['package_path']).read_bytes()
        blob=hashlib.sha1(b'blob '+str(len(body)).encode()+b'\0'+body).hexdigest()
        if len(body)!=item['bytes'] or hash_bytes(body)!=item['sha256'] or blob!=item['git_blob']:
            raise ValueError('upstream source differs: '+item['package_path'])
    extra=[]
    for path in args.extra_evidence:
        _,ref=read_bound(path.resolve());extra.append(ref)
    if not isinstance(records,list) or not records:
        raise ValueError('actual completed scientific records required')
    identities=[(r['case_id'],r['method']) for r in records]
    if len(set(identities))!=len(identities):
        raise ValueError('duplicate scientific record identity')
    frozen_source={str(p.relative_to(ROOT)):hash_bytes(p.read_bytes()) for p in
                   [ROOT/'src/laboratory.py',ROOT/'src/experiments.py',Path(__file__),Path(__file__).with_name('harness_adapter.py')]}
    source_binding=digest({'code':frozen_source,'upstream':source_ref['sha256'],'freeze':freeze_ref['sha256']})
    case=development_case('spectral-characterization',1,'nominal')
    public,hidden=case['public'],case['hidden']
    prebuilt=construct(public)
    theta=np.asarray(hidden['theta']);nuisance=np.asarray(hidden['nuisance_theta'])
    means=prebuilt.A@theta+prebuilt.Z@nuisance
    observations={}
    for a in range(len(public['actions'])):
        for purpose,count in [('acquisition',3),('verification',4)]:
            for repeat in range(count):
                rng=noise_rng(public['id'],hidden['seed'],a,repeat,purpose)
                observations[(a,repeat,purpose)]=float(means[a]+public['noise_sd']*rng.normal())
    validation=basis_matrix(public['basis'],hidden['validation_points'])
    truth=validation@theta
    preparation={'wall_s':time.perf_counter()-wall,'cpu_s':time.process_time()-cpu,
                 'synthetic_observations_precomputed':len(observations),
                 'observations_are_computation_not_acquisitions':True}
    def execute() -> dict:
        observed=[]
        def observe(a: int, repeat: int, purpose: str) -> float:
            observed.append((a,repeat,purpose))
            return observations[(a,repeat,purpose)]
        result=solve(public,observe,'aperture',make_authority(public))
        error=float(np.sqrt(np.mean((validation@np.asarray(result['theta'])-truth)**2))/np.sqrt(np.mean(truth**2)))
        result.update({'case_id':public['id'],'nrmse':error,'scientific_pass':error<=public['quality_threshold'],
                       'callback_count':len(observed),'phase':'known-development-case-reexecution',
                       'confirmation_sample_member':False,'physical_measurements':False})
        return native_numbers(result)
    def renewal() -> dict:
        checked=authority_checks(case)
        return {'research_object_restore_checks':checked['checks'],'snapshot_sha256':checked['snapshot']['sha256'],
                'scope':checked['scope'],'native_portable_restore':'NOT_RUN; unavailable legacy dependency closure',
                'operational_authority':'none','fresh_opportunity':'requires a new immutable mission and explicit bounded authority'}
    handlers={
        'Identify':lambda:{'question':'Adaptable measurement capability when demand changes','freeze':freeze_ref,
                           'phase':args.phase,'chronology':'This trace audits completed study evidence; it did not plan or launch the confirmation sample.'},
        'Out-Learn':lambda:{'public_data_pilot':pilot_ref,'dataset':pilot['dataset'],
                            'pilot_interpretation':pilot['interpretation'],'upstream_source_manifest':source_ref},
        'Out-Think':lambda:{'scientific_records':records_ref,'record_count':len(records),'case_count':len({r['case_id'] for r in records}),
                            'methods':sorted({r['method'] for r in records}),
                            'comparison_scope':'Frozen scientific records; no outcome-dependent model tuning in this integration audit',
                            'extra_evidence':extra},
        'Out-Design':lambda:{'actual_constructed_program':construct(public).identity,'representation':'bounded expression basis and measurement operator',
                             'actions':len(public['actions']),'dimensions':public['dim'],'family':public['family'],'source':source_binding},
        'Out-Strategise':lambda:{'mission_id':public['id'],'acquisition_budget_units':public['budget'],'verification_readouts':public['verify_count'],
                                'authorization':make_authority(public),'new_scientific_confirmation_runs':0,
                                'native_resource_unit':'one handler call; not total CPU, money or detector acquisition cost'},
        'Out-Execute':execute,
        'Out-Evolve':renewal,
    }
    report=run_pipeline(handlers,args.output,source_binding=source_binding,mission_id='writer11-foundations-'+args.phase)
    report.update({'integration_scope':'Retrospective source-bound evidence audit plus one actual bounded development-case solve',
                   'confirmation_was_launched_by_this_dispatcher':False,'observed_scientific_records':records_ref,
                   'freeze':freeze_ref,'code':frozen_source,'preparation':preparation,
                   'integration_wall_s':time.perf_counter()-wall,'integration_cpu_s':time.process_time()-cpu,
                   'cost_boundary':'Includes input reads, source verification, closed observation precomputation, seven dispatch stages and output serialization up to receipt; final JSON and journal compression excluded.'})
    output=args.output
    (output/'receipt.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    journal_dir=output/'public-fixture-journal'
    with zipfile.ZipFile(output/'public-fixture-journal.zip','w',zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(journal_dir.rglob('*')):
            if path.is_file():archive.write(path,path.relative_to(output))
    with zipfile.ZipFile(output/'public-fixture-journal.zip') as archive:
        if archive.testzip() is not None:raise ValueError('native journal archive CRC failure')
    print(json.dumps({'status':'completed','seven_stages':True,'receipt':str(output/'receipt.json'),
                      'native_portable_restore':'NOT_RUN','research_object_restoration':'executed','scientific_confirmation_repeated':False}))

if __name__=='__main__':main()
