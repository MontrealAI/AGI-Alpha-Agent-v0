# Thin native foundations integration

This directory carries exact public source copies with their licenses and Git/SHA-256 identities, the source audit, historical fixture evidence, and a small local adapter. It does not modify upstream code or invoke a held facade. No remote execution, wallet, live transaction, new service credential or API token is created.

Run from the package root after the actual protocol freeze and scientific records exist:

```sh
python integration/run_foundations.py --freeze protocol/FINAL_FREEZE.json --records evidence/confirmation/records.json --output evidence/foundations
```

Supply the actual freeze/records paths if they differ. `--extra-evidence PATH` can bind additional JSON checker receipts. The command refuses an existing output directory and verifies every packaged source body against size, SHA-256 and Git blob identity before using it. Python dependencies are the package requirements plus Pydantic and cryptography.

The unchanged published `JobDispatcher` executes seven pure stage callbacks. The first stages bind and inspect completed scientific evidence; Out-Design constructs a real measurement operator; Out-Execute actually solves one previously known spectral development case through a closed observation callback; Out-Evolve executes the research artifact's World/Policy/Proof/Authority round-trip and refusal tests. Only explicit local output code outside callbacks writes files.

**Chronology:** this is a retrospective integration audit and separate bounded development-case reexecution. It does not claim that the dispatcher planned or launched the earlier confirmatory experiment. The new run is not counted as another confirmatory sample. Precomputing 420 closed synthetic observations is computational preparation, not 420 detector acquisitions. Actual readouts and verification costs remain in the solve result; integration and preparation CPU/wall timings are separate.

The adapter's native stage-call ledger measures seven calls, not their full scientific or economic cost. Public deterministic fixture identities are deliberately reproducible and must never be used as credentials. Signing local records proves neither organizational independence nor scientific validity.

Native `export_portable`/`restore_portable` remains **NOT_RUN** because the released lazy settlement import closure requires dependencies unavailable in the exhausted environment. The research artifact's distinct restoration tests are actually run. Historical native-export failures and local-EVM installation failure are retained in `historical/`; no EVM test success is claimed.

`source_manifest.json` identifies the 21 source files packaged for executable dispatch and source inspection. `SOURCE_AUDIT_MANIFEST.json` records the larger 74-file audit, with immutable retrieval URLs for source not repeated in this compact package. `SOURCE_AUDIT.md` explains all five contracts, the separate USDC6/AGIALPHA18 routes and the still-unconnected Fleet task-family extension. The TI PDF was read in full; its exact retrieval identity appears in that audit.
