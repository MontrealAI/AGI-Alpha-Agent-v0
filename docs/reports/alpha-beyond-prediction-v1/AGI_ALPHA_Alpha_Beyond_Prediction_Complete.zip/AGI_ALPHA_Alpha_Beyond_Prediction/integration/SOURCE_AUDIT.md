# Writer #11: verified project foundations

This is an additive source audit and bounded integration fixture. It is not a report of operational adoption, commercial value, live settlement, or independent organizational review. Source files were retrieved from public repositories. The local source manifest records Git blob identities, byte counts, SHA-256s, and immutable URLs. Files fetched through the text transport that acquired one extra terminal newline were restored to the exact expected Git blob before use; the normalization list is retained.

## Pinned sources and reuse rights

| Repository | Inspected commit | License | Relevant verified seam |
|---|---|---|---|
| [AGI-Alpha-Agent-v0](https://github.com/MontrealAI/AGI-Alpha-Agent-v0) | `197147ffd22c5ae13113162afffaf3ce9c10aa2e` | Apache-2.0, with existing per-file licenses preserved | `core/runtime/successor/jobs.py`, `protocol.py`, `state.py`; five Ascension contracts; current TI manuscript |
| [AGIJobManager](https://github.com/MontrealAI/AGIJobManager) | `c5958eae872458c2f3cac48fea0b4bbfadc6ac6c` | MIT | `scripts/integrations/transformational-work-request.mjs` validates native campaign bindings and creates an unfunded USDC proposal |
| [AGIJobsv0](https://github.com/MontrealAI/AGIJobsv0) | `9983478d42c32fe399f28dd9b0e0173f904b8a11` | MIT | `integrations/alpha-agent/transformational-work-request.mjs` validates native campaign bindings and creates an unfunded AGIALPHA proposal |
| [AGI-Fleet-Linux](https://github.com/MontrealAI/AGI-Fleet-Linux) | `45759fb096faf8988f58ae5ea71248d0f35a97c7` | MIT | `local-runtime/project/transfer.mjs` maps the fixed public-data total-checking family into bounded local execution and review |

These are observed source identities, not assertions that every repository is at a current production release or that all four interoperate on Writer #11's new numerical task. Full third-party license texts accompany retained source copies. The public-data license of the new numerical pilot must be audited separately; repository licenses do not grant rights to arbitrary external datasets.

## Complete Transformational Intelligence manuscript

The complete 24-page `docs/Transformational_Intelligence.pdf` was read, including references and appendices. Its Git blob is `1f95db3b087d8dd0712012d34ba700d7dd2e1382`, 305,040 bytes. The source defines a problem formulation as representations, assumptions/world model, information acquisition, executable policy language, and intermediate targets, while keeping the user's intent charter and permission boundary distinct. A transformation includes its construction, realization, and witness connecting the changed formulation to the original purpose.

The paper's finite causal example does not claim a new causal-discovery algorithm: an unrestricted conventional optimal planner matches the active policy. Its hypotheses on autonomous discovery and transfer remain prospective. Writer #11 must likewise distinguish a demonstrated implementation from learned autonomous invention or scientific novelty. The useful research implication is to diagnose a binding restriction, construct a changed representation or process, and test its incremental contribution against an equally equipped conventional builder while charging search, construction, confirmation, migration, execution, verification, and maintenance.

The requested seven-stage journey is realized by named callbacks in an unchanged published `JobDispatcher`. The source's seven job-family vocabulary differs from the stage names. This explicit mapping avoids pretending they are identical APIs:

| User-facing stage | Dispatcher family | Research responsibility |
|---|---|---|
| Identify | constitution | State the authorized question, scope, budget and stopping rule |
| Out-Learn | evidence | Inspect public inputs and prior knowledge |
| Out-Think | challenge | Diagnose the pilot bottleneck and conventional alternatives |
| Out-Design | formation | Construct the artifact and representation |
| Out-Strategise | admission | Admit only the frozen bounded experiment |
| Out-Execute | verification | Execute the experiment and its checks |
| Out-Evolve | renewal | Preserve evidence, rejected claims and supported successor scope |

This is an engineering mapping. All seven dispatcher families are required by the source compiler; it is not a claim that seven transactions or separate agents are scientifically necessary. Callback separation supplies local execution roles, not organizational independence.

## Five Ascension contracts

All roles below come from actual `contracts/ascension/*.sol` source at the pinned Alpha commit. They are not live-chain observations.

| Contract | Implemented behavior | Boundary relevant to this paper |
|---|---|---|
| AscensionAccess | Live ENS ownership plus expiring owner-set admission. Business root `alpha.agi.eth`; agent root `alpha.agent.agi.eth`; validator root `alpha.club.agi.eth`. Wrapped names require unexpired ownership. | Admission/ENS ownership is an eligibility check, not scientific competence or permission for a new task. No resolver-address bypass is used. |
| NovaSeed | Transferable ERC-721 storing capsule hash, immutable plan root, evidence hash, parent, bounded job count and creator. `seal` requires eligible business; a specified parent must be owned by the creator. | The stored commitment is not proof that the capsule is correct or profitable. No source setter mutates an existing genome or plan. A new opportunity needs a fresh seed and separately scoped authority. |
| AscensionRiskOracle | Validator stakes; a seven-day owner-bound review; quorum between 2 and 15; risk-basis-point threshold; expiration; duplicate-vote prevention; review-capacity reservation for jobs. `green` rechecks owner and validator eligibility. | Different eligible addresses and a quorum do not establish genuine organizational independence or ground truth. Expired or transferred approvals are invalid. |
| AscensionJobMarket | Bounded reputation-weighted auction; locked worker bond; three selected validators; artifact-bound votes; two-vote payout/rejection threshold; timeouts/refunds. Successful payouts split worker/reviewer gross amounts and burn one percent of each payout. Missing review quorum refunds without treating it as proof of failed work. | The contract pays according to protocol votes. It cannot establish the scientific correctness of a numerical artifact. No Writer #11 live job is posted or settled. |
| AscensionMark | `None → Funding → Bloomed → Closed`. Funding has a reversible linear-curve lot market. `bloom` requires target reserve, current green review, business ownership and ENS binding before funding expiry. After bloom, only immutable Merkle-plan jobs can be routed within remaining treasury and execution horizon. Collection, closure and pro-rata unused-capital return are explicit. | Bloom is a lifecycle transition, not wealth, realized profit or ownership of future opportunities. No committed plan can be silently expanded. Funding lots are not securities claims made by this paper. |

The shared `AscensionToken` requires canonical AGIALPHA code with 18 decimals, exact deposits/payouts and verified supply burning. Its source-supported utility is the token's use for validator/worker stakes, funded job bounties, campaign reserve, payout and burn accounting. This is neither evidence of token appreciation nor a necessity claim for the off-chain scientific artifact.

Manager's route is separately declared USDC, six decimals; its draft contains no transaction and reserves zero base units. Jobs' route is AGIALPHA, eighteen decimals. Both native inspectors require matching campaign/source/evaluation bindings, public-only inputs and explicit unfunded state. The new task is not automatically an admitted receiver family. Fleet's inspected current-main mapping only accepts the public-data row-total family; adapting a numerical experiment would require a new reviewed mapping and bounded authority. Therefore Manager/Jobs/Fleet integration for the new numerical task remains a source-backed extension boundary, not a functioning four-repository execution claim.

## Actual local integration evidence

`harness_adapter.py` imports the exact published `JobDispatcher`, `SuccessorStore`, protocol classes and signed journal. It installs only pure, explicitly supplied stage handlers. It does not invoke a held harness facade, API server, provider or network. Fixed public test bytes are used for local fixture identities; no service credential or random identity is generated, and no API token is created. These deliberately public fixture identities provide no trust outside this isolated test.

The third integration fixture completed all seven stage callbacks and all three refusal probes: expired assignment, incompatible environment, and mutation of sealed graph terms. The source ledger reserved seven stage calls, charged seven, released all reservations, and reported no overrun. The signed journal verified 46 events. These are integration-fixture callbacks, explicitly not the scientific experiment. The generic adapter can wrap the real experiment after its freeze without changing the dispatcher.

Two earlier fixtures also completed stage dispatch but failed at native portable export while resolving its lazy settlement import closure. Their source histories, stdout/stderr and complete SQLite journals are preserved in `harness-fixtures-failed-retained.zip`. The first lacked the source engine dependency; after exact source closure retrieval the second lacked installed `httpx`. Native portable export/restore remains **NOT_RUN**, rather than being replaced by mocked imports or patched upstream behavior. Customer-facing World/Policy/Proof/Authority restoration can be tested separately in the research artifact, with its distinct scope named. Source `restore_portable` requires an independently supplied source key/checkpoint, rejects active proofs/grants, and restores stopped with no active authority; those source properties are not reported as newly executed native restore results.

Local-EVM lifecycle execution was attempted using the exact pinned `tests/contracts/package-lock.json` and `npm ci --ignore-scripts --no-audit --no-fund`. Installation exited 1 with `ENOSPC` before completion; no contract test ran. The original logs and exit status remain. Only this task's incomplete 81 MB `node_modules` directory was removed. No alternate compiler, weakened test, live chain, wallet, or credential was substituted. Therefore the five-contract demonstration is **source audited / local EVM NOT_RUN** in this environment.

## Economic caveat and publication ownership

`docs/agent/INSIGHT_ATLAS.md` explicitly labels $15 quadrillion an editable scenario assumption, not measured wealth, valuation or forecast; its implementation table states verified economic value is zero. No currency, horizon or accessible market should be inferred where the source does not specify one. Writer #11 does not use that number to calculate revenue or value. Its software evidence remains interpretable without the motivating magnitude.

Issue [4850](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/issues/4850), especially [receiving boundary 6377105309](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/issues/4850#issuecomment-6377105309), assigns shared-index, merge and Pages publication to the existing coordinator. Independent isolated research may proceed; final exact artifacts and source identity must be handed to that coordinator for current-main intake. Held #4863/#4865 runtime boundaries and unrelated Fleet/release obligations are not cleared by this audit. No external mutation was made by the source-audit lane.
