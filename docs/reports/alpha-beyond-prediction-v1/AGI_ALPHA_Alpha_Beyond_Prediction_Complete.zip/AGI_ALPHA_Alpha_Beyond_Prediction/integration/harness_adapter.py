# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations
import base64, hashlib, json, os, sqlite3, sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Callable, Any
SOURCE = Path(__file__).resolve().parent / 'upstream'
sys.path.insert(0, str(SOURCE))
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat
from alpha_factory_v1.core.runtime.models import RuntimeConfig
from alpha_factory_v1.core.runtime.store import Journal, digest as journal_digest
from alpha_factory_v1.core.runtime.successor.protocol import Institution, MissionConstitution, ResourceBudget, CandidateReleaseManifest, JobContract, JobGraph, JobDependency, ExecutionAuthorization, canonical, digest
from alpha_factory_v1.core.runtime.successor.jobs import JobDispatcher, JobResult
from alpha_factory_v1.core.runtime.successor.state import SuccessorStore
from alpha_factory_v1.core.runtime.successor.trust import TrustAnchor, TrustRegistry, sign_record, JournalCheckpoint

STAGES = [('Identify', 'constitution'), ('Out-Learn', 'evidence'), ('Out-Think', 'challenge'), ('Out-Design', 'formation'), ('Out-Strategise', 'admission'), ('Out-Execute', 'verification'), ('Out-Evolve', 'renewal')]
ROLES = {'fixture-controller': {'controller','acceptance','authority','admission','control'}, 'fixture-producer': {'worker','producer'}, 'fixture-checker': {'worker','verifier','acceptance'}}

def fixture_key(name: str) -> Ed25519PrivateKey:
    return Ed25519PrivateKey.from_private_bytes(hashlib.sha256(('WRITER11-PUBLIC-TEST-FIXTURE-NOT-A-CREDENTIAL:' + name).encode()).digest())

def fixture_journal(path: Path, name: str) -> Journal:
    path.mkdir(parents=True, exist_ok=False)
    cfg = RuntimeConfig()
    (path / 'config.json').write_bytes(canonical(cfg.model_dump(mode='json')))
    (path / 'identity.key').write_bytes(hashlib.sha256(('WRITER11-PUBLIC-TEST-FIXTURE-NOT-A-CREDENTIAL:' + name).encode()).digest())
    with sqlite3.connect(path / 'journal.sqlite3') as cx:
        cx.execute('CREATE TABLE events(seq INTEGER PRIMARY KEY, mission TEXT NOT NULL, body TEXT NOT NULL, hash TEXT NOT NULL UNIQUE, signature TEXT NOT NULL)')
        cx.execute('CREATE INDEX events_mission ON events(mission,seq)')
    journal = Journal(path)
    with journal.transaction() as cx:
        journal.append(cx, '@control', {'state':'ready','config_hash':journal_digest(cfg.model_dump())})
    return journal

def write(path: Path, value: Any) -> None:
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def run_pipeline(handlers: dict[str, Callable[[], dict[str, Any]]], output: Path, *, source_binding: str, mission_id: str = 'writer11-adaptable-laboratory') -> dict[str, Any]:
    if set(handlers) != {s for s, _ in STAGES}: raise ValueError('All seven explicitly bounded stage handlers are required')
    output.mkdir(parents=True, exist_ok=False)
    keys = {name:fixture_key(name) for name in ROLES}
    trust = TrustRegistry({name:TrustAnchor(key.public_key().public_bytes(Encoding.Raw,PublicFormat.Raw).hex(),frozenset(ROLES[name])) for name,key in keys.items()})
    journal = fixture_journal(output / 'public-fixture-journal', 'journal-original')
    store = SuccessorStore(journal, trust)
    until = (datetime.now(timezone.utc) + timedelta(hours=2)).isoformat().replace('+00:00','Z')
    budget = ResourceBudget(limits={'stage_calls':7},units={'stage_calls':'one retained bounded pure handler call'},enforceable=['stage_calls'],unknown_costs=['human_effort','monetary_compute'])
    institution = Institution(id=mission_id, controller='fixture-controller',constitution=MissionConstitution(mission_id=mission_id,owner='user-authorized-local-research',objective='Construct and evaluate adaptable productive capability under deep uncertainty',scope='bounded offline digital laboratory; no wallet or external execution',prohibited_actions=['financial-transaction','network-send','live-deploy'],budget=budget,authority_ceiling='none'))
    store.create_institution(institution, {'stage_calls':7})
    environment = digest('writer11-environment', {'source':source_binding,'boundary':'offline-local-research'})
    release = CandidateReleaseManifest(release_id='writer11-research-v1',institution_id=mission_id,mission_id=mission_id,producer='fixture-producer',environment_digest=environment,budget=budget,configuration={'source_binding':source_binding})
    release_digest = digest('release', release)
    store.register_release(mission_id,release,request_id='freeze-writer11')
    jobs, edges = [], []
    for i,(stage,family) in enumerate(STAGES):
        jobid='stage-'+str(i+1)
        worker='fixture-checker' if family in {'challenge','verification','admission'} else 'fixture-producer'
        jobs.append(JobContract(job_id=jobid,family=family,worker=worker,acceptance_owner='fixture-controller',release_digest=release_digest,environment_digest=environment,inputs={} if i==0 else {'stage-'+str(i):'writer11-stage-evidence'},outputs={jobid:'writer11-stage-evidence'},critical_functions=[stage],resources={'stage_calls':1},valid_until=until,institution_id=mission_id,mission_id=mission_id,goal=stage,allowed_tools=['bounded-research-handler'],prohibited_effects=['financial-transaction','network-send','live-deploy']))
        if i: edges.append(JobDependency(source='stage-'+str(i),target=jobid,kind='evidence',required_type='writer11-stage-evidence'))
    graph=JobGraph(jobs=jobs,edges=edges,required_functions=[s for s,_ in STAGES])
    dispatcher=JobDispatcher(store,mission_id)
    dispatcher.seal(graph)
    checks=[]
    def refused(name: str, fn: Callable[[], Any]) -> None:
        try: fn()
        except (ValueError, RuntimeError) as exc: checks.append({'test':name,'refused':True,'reason':str(exc)});return
        raise AssertionError(name+' unexpectedly succeeded')
    def authorization(terms: JobContract, index: int) -> ExecutionAuthorization:
        return ExecutionAuthorization(authorization_id='authority-'+str(index),acting_identity=terms.worker,job_terms_digest=digest('job-terms',terms),release_digest=release_digest,environment_digest=environment,capabilities=['bounded-research-handler'],reservation_id='reservation-'+str(index),expires_at=until)
    expired=authorization(jobs[0],0).model_copy(update={'expires_at':'2000-01-01T00:00:00Z'})
    refused('expired_assignment',lambda:dispatcher.dispatch(jobs[0].job_id,sign_record(keys['fixture-controller'],'fixture-controller','execution',expired)))
    incompatible=authorization(jobs[0],0).model_copy(update={'environment_digest':'0'*64})
    refused('incompatible_environment',lambda:dispatcher.dispatch(jobs[0].job_id,sign_record(keys['fixture-controller'],'fixture-controller','execution',incompatible)))
    altered=graph.model_copy(update={'jobs':[jobs[0].model_copy(update={'goal':'materially different opportunity'})]+jobs[1:]})
    refused('immutable_graph_terms',lambda:dispatcher.seal(altered))
    retained=[]
    for i,((stage,_),terms) in enumerate(zip(STAGES,jobs),1):
        auth=authorization(terms,i)
        dispatcher.dispatch(terms.job_id,sign_record(keys['fixture-controller'],'fixture-controller','execution',auth))
        result=dispatcher.execute_tool(terms.job_id,tool='bounded-research-handler',actor=terms.worker,invocation_id='invocation-'+str(i),handler=handlers[stage],retain_result=True)
        accepted=JobResult(job_id=terms.job_id,authorization_id=auth.authorization_id,terms_digest=digest('job-terms',terms),output_digest=digest('writer11-stage-output',result),outputs=terms.outputs,accepted=True,accepted_by='fixture-controller',valid_until=until,permitted_uses=['dependency'],actual_resources={'stage_calls':1},candidate_verdict='technical-evidence-only')
        dispatcher.complete(sign_record(keys['fixture-controller'],'fixture-controller','job-acceptance',accepted))
        retained.append({'stage':stage,'family':terms.family,'authorization':auth.model_dump(mode='json'),'result':result,'acceptance':accepted.model_dump(mode='json')})
    source_state=store.read(mission_id)
    journal.verify()
    restoration = {'status':'NOT_RUN','reason':'Unchanged native export requires missing httpx through the legacy settlement import closure; no dependency installation after ENOSPC. Customer object restoration is a separate research-artifact test.'}
    write(output/'institution.json',institution.model_dump(mode='json'))
    write(output/'job-graph.json',graph.model_dump(mode='json'))
    write(output/'stage-evidence.json',retained)
    write(output/'authority.json',{'operational_authority':'none','scope':'explicitly synthetic local test identities; not external credentials','expires_at':until,'production_grants':[],'assignments':[r['authorization'] for r in retained]})
    report={'schema':'writer11-harness-receipt/v1','source_binding':source_binding,'runtime_integration':'unchanged published JobDispatcher and SuccessorStore','pipeline':[s for s,_ in STAGES],'tests':checks,'source_resources':source_state['resources'],'native_restoration':restoration,'journal':journal.verify(),'independent_organizational_validation':False,'settlement':'not-connected','real_currency_receipts':'0','local_fixture_identity':'public deterministic test bytes; never use as credentials','unknown_costs':['authoring model usage','human effort','hardware monetary costs']}
    write(output/'receipt.json',report)
    return report

if __name__ == '__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    handlers={stage:(lambda s=stage:{'stage':s,'status':'integration-fixture-only','scientific_experiment_run':False}) for stage,_ in STAGES}
    report=run_pipeline(handlers,args.output,source_binding=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),mission_id='writer11-integration-fixture')
    print(json.dumps(report,indent=2))
