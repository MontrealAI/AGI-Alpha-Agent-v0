import argparse, hashlib, json, pathlib, platform, time
started=time.perf_counter(); cpu_started=time.process_time()
import numpy as np
import scipy
from scipy.optimize import least_squares
ap=argparse.ArgumentParser();ap.add_argument('--data',type=pathlib.Path,required=True);ap.add_argument('--output',type=pathlib.Path,required=True);a=ap.parse_args()
raw=a.data.read_bytes();expected='20d0b85ffc73681ce9bdd69c566e53969a65e0e2192c3de16ad4a1dcfdca6c27'
if hashlib.sha256(raw).hexdigest()!=expected:raise SystemExit('Input hash differs from frozen NIST retrieval; refusing this reference comparison.')
lines=raw.decode().splitlines();start=next(i for i,s in enumerate(lines) if s.strip().startswith('Data:   y'))+1
xy=np.array([list(map(float,s.split())) for s in lines[start:] if len(s.split())==2])
if xy.shape!=(250,2) or not np.isfinite(xy).all():raise SystemExit('Unexpected dataset shape or nonfinite input.')
y,x=xy.T;cert=np.array([98.778210871,.010497276517,100.48990633,67.481111276,23.129773360,71.994503004,178.99805021,18.389389025]);a.output.mkdir(parents=True,exist_ok=True)
def forward(b):
 return b[0]*np.exp(-b[1]*x)+b[2]*np.exp(-((x-b[3])/b[4])**2)+b[5]*np.exp(-((x-b[6])/b[7])**2)
records=[]
for i,s in enumerate([[97,.009,100,65,20,70,178,16.5],[94,.0105,99,63,25,71,180,20]]):
 calls=[0]
 def residual(b):
  calls[0]+=1
  return forward(b)-y
 t=time.perf_counter();c=time.process_time();r=least_squares(residual,s,x_scale='jac',ftol=1e-12,xtol=1e-12,gtol=1e-12,max_nfev=500)
 wall=time.perf_counter()-t;cpu=time.process_time()-c;rss=float(r.fun@r.fun);rel=abs(rss/1315.8222432-1);param_rel=float(np.max(abs((r.x-cert)/cert)))
 records.append({'starting_values':i+1,'success':bool(r.success),'function_evaluations_reported':r.nfev,'total_residual_calls_including_jacobian':calls[0],'wall_seconds':wall,'process_seconds':cpu,'residual_sum_squares':rss,'rss_relative_error':rel,'parameters':r.x.tolist(),'max_parameter_relative_error_to_rounded_certification':param_rel,'validated':bool(r.success and rel<1e-8 and param_rel<1e-6)})
 np.savetxt(a.output/f'fitted_curve_start{i+1}.csv',np.column_stack((x,forward(r.x))),delimiter=',',header='x,fitted_response',comments='',fmt='%.12g')
report={'dataset':'NIST Gauss1, SRD 140','source_url':'https://www.itl.nist.gov/div898/strd/nls/data/LINKS/DATA/Gauss1.dat','reuse_scope':'Local numerical comparison invited by NIST dataset-specific How to Use instructions; input observations not redistributed.','raw_sha256':expected,'bytes':len(raw),'n':len(x),'certified_residual_sum_squares':1315.8222432,'boundary':'Generated public numerical reference data; no physical or commercial validation.','method':'scipy.optimize.least_squares with numerical Jacobian, NIST supplied model and both supplied initializations','python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,'records':records,'human_effort':'Unknown; no observed human trial or labor-cost comparison.','total_script_wall_seconds_after_stdlib_imports':time.perf_counter()-started,'total_script_process_seconds_after_stdlib_imports':time.process_time()-cpu_started,'accounting_boundary':'Includes numerical imports, data read, fits and curve writes; excludes interpreter startup and final JSON serialization. No new detector acquisitions.'}
(a.output/'results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'all_validated':all(r['validated'] for r in records),'records':records,'output':str(a.output)},indent=2))
if not all(r['validated'] for r in records):raise SystemExit(1)
