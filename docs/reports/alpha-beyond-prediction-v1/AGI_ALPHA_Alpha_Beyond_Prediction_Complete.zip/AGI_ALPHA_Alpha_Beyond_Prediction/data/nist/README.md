# Public-data pilot: NIST Gauss1

This is an intentionally ordinary numerical check, conducted before the confirmation study. A conventional SciPy nonlinear least-squares solver already solves this known-model problem in milliseconds; the main study must therefore investigate adaptation and verification constraints, not manufacture a fitting bottleneck.

## Source and permitted use

Rust, B. (1996), Gauss1, NIST Statistical Reference Datasets, SRD 140, [dataset](https://www.itl.nist.gov/div898/strd/nls/data/gauss1.shtml), collection DOI [10.18434/T43G6C](https://doi.org/10.18434/T43G6C).

The source explicitly labels these **generated data**, not an experiment on physical specimens. Two Gaussian peaks lie over a decaying exponential baseline. There are 250 observations and eight model parameters. The NIST [How to Use instructions](https://www.itl.nist.gov/div898/strd/general/howto.html) invite downloading a selected dataset, analyzing it, and comparing with certified values. That is this pilot's use. The collection is in the [free SRD catalog](https://www.nist.gov/srd/free-srd); it must not be described as non-SRD or blanket public domain. See [NIST rights](https://www.nist.gov/open/license) and [dataset disclaimer](https://www.itl.nist.gov/div898/strd/general/disclaim.html).

The package contains analysis results and retrieval instructions. It does not redistribute the input observations or per-observation residuals. The fitted-curve CSVs are derived model predictions, not NIST data or NIST-certified outputs. No endorsement is implied.

## Reproduce from the package root

The dataset download is explicit. Main synthetic experiments need no network. Requirements: the pinned NumPy/SciPy versions in the main environment file, or NumPy 2.3.5 and SciPy 1.17.0 as used for this pilot.

```bash
curl --fail --location 'https://www.itl.nist.gov/div898/strd/nls/data/LINKS/DATA/Gauss1.dat' -o data/nist/Gauss1.dat
python data/nist/reproduce.py --data data/nist/Gauss1.dat --output /tmp/writer11-nist-reproduction
```

The script requires the input SHA-256 `20d0b85ffc73681ce9bdd69c566e53969a65e0e2192c3de16ad4a1dcfdca6c27` (8,417 bytes), validates 250 observations, fits both official initializations, and writes fresh aggregate reports and fitted curves. The raw downloaded file and generated reproduction folder should not be committed or added to public packages. To inspect residuals locally, subtract the downloaded y values from the model predictions; do not imply any extra measurements were acquired.

## Results and accounting

`../../evidence/pilot/nist_results.json` records the instrumented run. Both starts yielded RSS approximately 1315.82224320338, versus the rounded certified value 1315.8222432: relative difference about 2.57e-12. The largest relative discrepancy in fitted parameters versus rounded reference parameters was below 9e-9. These are numerical-agreement measures, not statistical confidence intervals.

The residual function was called **54 and 64 times**, including finite-difference Jacobian work. SciPy's `nfev` fields of 6 and 8 do not count all these calls. Per-fit wall time was approximately 3--4 ms. Script time including numerical imports, data reading, both fits and CSV writes was about 1.004 s wall / 2.142 s CPU in the measured environment; interpreter startup and final JSON serialization were excluded. No human effort or economic cost was measured. Runtime is machine-dependent and must not be interpreted as a performance benchmark against another implementation.

`fitted_curve_start1.csv` and `fitted_curve_start2.csv` provide inspectable model outputs. The original pilot manifest in `../../evidence/pilot/original_pilot_manifest.json` preserves the first run's local-file hashes, including input and residual files intentionally omitted from this public package. Its timestamp is a local audit record, not an independent timestamp attestation.
