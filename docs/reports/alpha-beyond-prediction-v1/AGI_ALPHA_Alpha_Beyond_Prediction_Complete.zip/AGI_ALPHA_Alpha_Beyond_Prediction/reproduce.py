from __future__ import annotations
import argparse
import contextlib
import datetime
import gzip
import hashlib
import importlib.metadata
import importlib.util
import io
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import tempfile
import time
import traceback
import unittest

FREEZE_SHA256 = '147678382894e349fd53236e68447cb640110e25aa401ae5c7f19d0be6528076'
SEAL_SHA256 = '6bfc5076c2ea4b8f40acb01dac862e87975facdf71591a0f9768fa78cc6a13a4'
HIDDEN_SHA256 = '4788d502763f3ec6d40e160a845d55c100d09e1f07390f0cd8610a350fe9da5a'
THREAD_ENV = ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS')

def sha(data):
    return hashlib.sha256(data).hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n')

def read_json(path):
    if path.exists():
        return json.loads(path.read_text()), path
    compressed = path.with_suffix(path.suffix + '.gz')
    if compressed.exists():
        with gzip.open(compressed, 'rt') as stream:
            return json.load(stream), compressed
    raise FileNotFoundError(path)

def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

def main():
    parser = argparse.ArgumentParser(description='Reproduce Writer 11 frozen science using installed dependencies; no downloads or installation.')
    parser.add_argument('--output', type=Path, help='New output directory. Defaults to a fresh system temporary directory.')
    parser.add_argument('--keep-records', action='store_true', help='Also retain compressed rerun records; compact receipts are always retained.')
    args = parser.parse_args()
    if os.environ.get('WRITER11_REPRO_WORKER') != '1':
        env = dict(os.environ)
        env.update({name: '1' for name in THREAD_ENV})
        env['PYTHONDONTWRITEBYTECODE'] = '1'
        env['WRITER11_REPRO_WORKER'] = '1'
        return subprocess.call([sys.executable, str(Path(__file__).resolve()), *sys.argv[1:]], env=env)
    if any(os.environ.get(name) != '1' for name in THREAD_ENV):
        raise RuntimeError('Reproduction requires the wrapper-managed single-thread environment.')
    base = Path(__file__).resolve().parent
    output = args.output.resolve() if args.output else Path(tempfile.mkdtemp(prefix='writer11-reproduction-'))
    if args.output:
        output.mkdir(parents=True, exist_ok=False)
    started = time.perf_counter()
    receipt = {'status': 'running', 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
               'source_directory': str(base), 'output_directory': str(output), 'phases': {},
               'scope': 'Fresh output-directory execution using the current installed runtime; no fresh-machine install, physical validation, live execution or economic verification.'}
    def phase(name, start, details):
        value = {'elapsed_s': time.perf_counter() - start, **details}
        receipt['phases'][name] = value
        print(json.dumps({'phase': name, **value}), flush=True)
    try:
        t = time.perf_counter()
        frozen_path = base / 'protocol/FINAL_FREEZE.json'
        if sha(frozen_path.read_bytes()) != FREEZE_SHA256:
            raise RuntimeError('Final freeze identity mismatch.')
        frozen = json.loads(frozen_path.read_text())
        if len(frozen['files']) != 39:
            raise RuntimeError('Expected exactly 39 frozen identities.')
        for name, record in frozen['files'].items():
            data = (base / name).read_bytes()
            if sha(data) != record['sha256'] or len(data) != record['bytes']:
                raise RuntimeError('Frozen payload mismatch: ' + name)
        seal = base / 'protocol/revealed/SEALED_HOLDOUT.zip'
        if sha(seal.read_bytes()) != SEAL_SHA256:
            raise RuntimeError('Held-out archive identity mismatch.')
        import zipfile
        with zipfile.ZipFile(seal) as archive:
            if archive.testzip() is not None:
                raise RuntimeError('Held-out archive CRC failure.')
            sealed = json.loads(archive.read('SEALED_MANIFEST.json'))
            for name, expected in sealed['files'].items():
                if sha(archive.read(name)) != expected:
                    raise RuntimeError('Sealed member mismatch: ' + name)
            generator_path = base / 'protocol/revealed/generator.py'
            if generator_path.read_bytes() != archive.read('generator.py'):
                raise RuntimeError('Revealed generator differs from sealed source.')
        versions = {}
        for line in (base / 'requirements.txt').read_text().splitlines():
            if not line.strip():
                continue
            name, expected = line.split('==')
            versions[name] = importlib.metadata.version(name)
            if versions[name] != expected:
                raise RuntimeError(f'{name} version mismatch: installed {versions[name]}, required {expected}. Install the frozen requirements separately; this wrapper does not install packages.')
        phase('integrity', t, {'frozen_files': 39, 'freeze_sha256': FREEZE_SHA256, 'seal_sha256': SEAL_SHA256, 'dependency_versions': versions})
        sys.path.insert(0, str(base / 'src'))
        import numpy as np
        import scipy
        import experiments
        import check_results
        save(output / 'environment.json', {'python': sys.version, 'executable': sys.executable, 'platform': platform.platform(), 'numpy': np.__version__, 'scipy': scipy.__version__, 'dependency_versions': versions, 'thread_environment': {k: os.environ.get(k) for k in THREAD_ENV}, 'installed_runtime_reused': True, 'package_install_performed': False, 'wrapper_sha256': sha(Path(__file__).read_bytes())})
        generator = load_module('writer11_sealed_generator', generator_path)
        t = time.perf_counter()
        hidden = generator.generate_cases()
        hidden_bytes = (json.dumps(hidden, sort_keys=True, separators=(',', ':'), allow_nan=False) + '\n').encode()
        if sha(hidden_bytes) != HIDDEN_SHA256:
            raise RuntimeError('Regenerated held-out cases do not match the original reveal.')
        cases = [experiments.development_case(family, seed, stress)
                 for family in ('spectral-characterization', 'causal-system-identification')
                 for stress in experiments.STRESSES for seed in range(101, 109)] + hidden
        expected_cases, expected_cases_path = read_json(base / 'evidence/confirmation/cases.json')
        if cases != expected_cases or len(cases) != 96:
            raise RuntimeError('Exact 96-case values/order differ from original confirmation.')
        del expected_cases
        phase('case_generation', t, {'cases': len(cases), 'heldout_cases': len(hidden), 'heldout_bytes_sha256': sha(hidden_bytes), 'case_order_and_values_identical': True})
        t = time.perf_counter()
        test_module = load_module('writer11_scientific_tests', base / 'tests/test_independent.py')
        suite = unittest.defaultTestLoader.loadTestsFromModule(test_module)
        buffer = io.StringIO()
        test_result = unittest.TextTestRunner(stream=buffer, verbosity=2).run(suite)
        (output / 'science-tests.log').write_text(buffer.getvalue())
        if test_result.testsRun != 22 or not test_result.wasSuccessful():
            raise RuntimeError(f'Scientific tests failed or count changed: {test_result.testsRun} tests.')
        phase('scientific_tests', t, {'tests': test_result.testsRun, 'failures': len(test_result.failures), 'errors': len(test_result.errors)})
        t = time.perf_counter()
        rows = []
        for i, case in enumerate(cases):
            rows.extend(experiments.evaluate(case))
            if (i + 1) % 16 == 0:
                print(json.dumps({'progress_cases': i + 1, 'records': len(rows)}), flush=True)
        phase('confirmation', t, {'cases': len(cases), 'records': len(rows)})
        t = time.perf_counter()
        expected_rows, expected_records_path = read_json(base / 'evidence/confirmation/records.json')
        report = check_results.verify(cases, rows)
        exact = check_results.scientific_view(rows) == check_results.scientific_view(expected_rows)
        report['exact_numerical_event_reproduction'] = exact
        report['excluded_fields'] = sorted(check_results.TIMING_KEYS)
        save(output / 'SCIENTIFIC_COMPARISON.json', report)
        if not exact:
            differing = [{'row': i, 'case_id': r.get('case_id'), 'method': r.get('method')}
                         for i, (r, old) in enumerate(zip(rows, expected_rows))
                         if check_results.scientific_view(r) != check_results.scientific_view(old)]
            save(output / 'SCIENTIFIC_DIFFERENCES.json', {'differing_rows': differing, 'new_records': len(rows), 'reference_records': len(expected_rows)})
            with gzip.open(output / 'failed-reproduced-records.json.gz', 'wt') as stream:
                json.dump(rows, stream, separators=(',', ':'), allow_nan=False)
            raise RuntimeError('Exact non-timing reproduction failed; no tolerance was relaxed. See SCIENTIFIC_DIFFERENCES.json.')
        phase('scientific_comparison', t, {'exact_numerical_event_reproduction': exact, 'scientific_records_sha256': report['scientific_records_sha256']})
        timings = [{'case_id': r['case_id'], 'method': r['method'],
                    'reference': {k: old['costs'][k] for k in sorted(check_results.TIMING_KEYS)},
                    'reproduced': {k: r['costs'][k] for k in sorted(check_results.TIMING_KEYS)},
                    'difference': {k: r['costs'][k] - old['costs'][k] for k in sorted(check_results.TIMING_KEYS)}}
                   for r, old in zip(rows, expected_rows)]
        with gzip.open(output / 'timing-differences.json.gz', 'wt') as stream:
            json.dump(timings, stream, separators=(',', ':'), allow_nan=False)
        save(output / 'timing-summary.json', {k: {'reference_sum': sum(r['costs'][k] for r in expected_rows),
                                               'reproduced_sum': sum(r['costs'][k] for r in rows),
                                               'difference_sum': sum(r['costs'][k] - old['costs'][k] for r, old in zip(rows, expected_rows))}
                                            for k in sorted(check_results.TIMING_KEYS)})
        record_bytes = (json.dumps(rows, separators=(',', ':'), allow_nan=False) + '\n').encode()
        if args.keep_records:
            with gzip.open(output / 'reproduced-records.json.gz', 'wb') as stream:
                stream.write(record_bytes)
        t = time.perf_counter()
        audit_path = base / 'evidence/heldout-audit/audit_records.py'
        audit = load_module('writer11_record_audit', audit_path)
        fd, temporary_path = None, None
        try:
            if hasattr(os, 'memfd_create') and Path('/proc/self/fd').is_dir():
                fd = os.memfd_create('writer11-reproduction-records')
                remaining = memoryview(record_bytes)
                while remaining:
                    written = os.write(fd, remaining)
                    remaining = remaining[written:]
                os.lseek(fd, 0, os.SEEK_SET)
                record_path = Path(f'/proc/self/fd/{fd}')
            else:
                handle = tempfile.NamedTemporaryFile(prefix='writer11-records-', suffix='.json', dir=output, delete=False)
                handle.write(record_bytes)
                handle.close()
                temporary_path = Path(handle.name)
                record_path = temporary_path
            old_argv = sys.argv
            sys.argv = [str(audit_path), '--package', str(base), '--records', str(record_path), '--output', str(output / 'INDEPENDENT_RECORD_AUDIT.json')]
            audit_buffer = io.StringIO()
            with contextlib.redirect_stdout(audit_buffer):
                try:
                    audit.main()
                except SystemExit as exc:
                    if exc.code not in (None, 0):
                        raise RuntimeError('Independent held-out record audit failed.') from exc
            (output / 'record-audit.log').write_text(audit_buffer.getvalue())
        finally:
            if 'old_argv' in locals():
                sys.argv = old_argv
            if fd is not None:
                os.close(fd)
            if temporary_path is not None:
                temporary_path.unlink(missing_ok=True)
        audit_report = json.loads((output / 'INDEPENDENT_RECORD_AUDIT.json').read_text())
        if not audit_report['passed']:
            raise RuntimeError('Independent held-out record audit failed.')
        phase('independent_record_audit', t, {'records': audit_report['records'], 'checks': audit_report['checks'], 'passed': True})
        environment = {'python': sys.version, 'executable': sys.executable, 'platform': platform.platform(),
                       'numpy': np.__version__, 'scipy': scipy.__version__, 'dependency_versions': versions,
                       'thread_environment': {k: os.environ.get(k) for k in THREAD_ENV},
                       'installed_runtime_reused': True, 'package_install_performed': False,
                       'reference_cases_path': str(expected_cases_path.relative_to(base)),
                       'reference_records_path': str(expected_records_path.relative_to(base)),
                       'reference_records_stored_bytes_sha256': sha(expected_records_path.read_bytes()),
                       'reproduced_compact_record_bytes_sha256': sha(record_bytes),
                       'wrapper_sha256': sha(Path(__file__).read_bytes()), 'audit_sha256': sha(audit_path.read_bytes())}
        save(output / 'environment.json', environment)
        for name, record in frozen['files'].items():
            if sha((base / name).read_bytes()) != record['sha256']:
                raise RuntimeError('Frozen file changed during execution: ' + name)
        receipt.update({'status': 'passed', 'completed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                        'elapsed_s': time.perf_counter() - started, 'frozen_files_unchanged': True,
                        'scientific_records_sha256': report['scientific_records_sha256'],
                        'retained_full_records': args.keep_records,
                        'not_reproduced': ['fresh-machine dependency installation', 'physical measurements', 'commercial value or receipts', 'live contract actions', 'native integration campaign', 'paper typesetting', 'interactive demo browser acceptance', 'resource-replay supplement']})
        save(output / 'REPRODUCTION_RECEIPT.json', receipt)
        print(json.dumps({'status': receipt['status'], 'elapsed_s': receipt['elapsed_s'], 'output': str(output)}), flush=True)
        return 0
    except Exception as exc:
        receipt.update({'status': 'failed', 'completed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                        'elapsed_s': time.perf_counter() - started, 'error_type': type(exc).__name__, 'error': str(exc)})
        try:
            save(output / 'REPRODUCTION_RECEIPT.json', receipt)
            (output / 'failure.log').write_text(traceback.format_exc())
        except OSError:
            pass
        print(json.dumps({'status': 'failed', 'error_type': type(exc).__name__, 'error': str(exc), 'output': str(output)}), file=sys.stderr, flush=True)
        return 1

if __name__ == '__main__':
    raise SystemExit(main())
