import json,os,pathlib,sys
os.environ.setdefault('MPLCONFIGDIR',str(pathlib.Path(__file__).resolve().parent/'build/mpl-cache'))
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from matplotlib.colors import LinearSegmentedColormap
ROOT=pathlib.Path(__file__).resolve().parent
OUT=ROOT/'figures';OUT.mkdir(exist_ok=True)
rows=json.loads((ROOT/'evidence/confirmation/records.json').read_text())
summary=json.loads((ROOT/'evidence/confirmation/summary.json').read_text())
campaigns=json.loads((ROOT/'evidence/campaigns/campaigns.json').read_text())
purple='#6535B4';dark='#32165C';teal='#087F8C';amber='#B56A18';red='#B64055';ink='#242434';pale='#F3F0F8'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.labelsize':9,'axes.titlesize':10,'axes.titleweight':'bold','axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','pdf.fonttype':42,'savefig.facecolor':'white'})
methods=['aperture','modular','flat','uniform','gaussian_surrogate','frozen_specialist','wait','hindsight']
labels=['Aperture','Modular','Flat','Uniform','Gaussian\nsurrogate','Frozen\nspectral','Wait','Hindsight']
families=['spectral-characterization','causal-system-identification','coded_aperture_emission_imaging']
family_labels=['Spectral characterization','Causal system identification','Coded-aperture imaging']
aliases={'normal':'nominal','correlated_calibration_failure':'calibration_failure','unavailable_action_group':'capacity_loss'}
def save(fig,name):
 for ext in ('pdf','svg'):fig.savefig(OUT/f'{name}.{ext}',bbox_inches='tight',pad_inches=.12)
 plt.close(fig)

fig,ax=plt.subplots(figsize=(7.1,4.65));ax.set_xlim(0,10);ax.set_ylim(0,7);ax.axis('off')
def box(x,y,w,h,title,text,color=dark):
 ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=.12,rounding_size=.08',facecolor=pale,edgecolor=color,lw=1))
 ax.text(x+w/2,y+h*.72,title,ha='center',va='center',fontsize=10,color=color,fontweight='bold')
 ax.text(x+w/2,y+h*.30,text,ha='center',va='center',fontsize=8,color=ink,linespacing=1.5)
box(.2,3.15,3.0,1.55,'BEFORE DEMAND','Finite grammar • solver\nBudgets • evidence\nCurrent authority')
box(4.3,5.15,5.3,1.1,'SPECTRA','Localized response + unknown baseline',purple)
box(4.3,3.35,5.3,1.1,'DYNAMICS','Causal forcing history + unknown drift',teal)
box(4.3,1.55,5.3,1.1,'SPATIAL COUNTS','Integrated masks + Poisson likelihood',amber)
for y,c in [(5.7,purple),(3.9,teal),(2.1,amber)]:
 ax.add_patch(FancyArrowPatch((3.35,3.9),(4.15,y),arrowstyle='-|>',mutation_scale=13,color=c,lw=1.5,linestyle='--',connectionstyle='arc3,rad=0'))
ax.text(.2,2.02,'Compose a new program.\nStay inside the language.\nOutside it: stop or replace.',fontsize=8.3,color=ink,linespacing=1.45)
ax.text(.2,6.65,'CONSTRUCTION SPACE  /  schematic possible assignments',fontsize=10,color=dark,fontweight='bold')
ax.plot([.2,9.6],[1.15,1.15],color='#D4CCD9',lw=.8)
ax.text(.2,.94,'RECORDED SHIFT REPLAY  /  capacity 90 · switch tariff 3',fontsize=8.1,color=dark,fontweight='bold')
for x,title,c in [(.25,'DYNAMICS',teal),(3.65,'SPATIAL COUNTS',amber),(7.05,'SPECTRA',purple)]:
 ax.add_patch(FancyBboxPatch((x,.28),2.45,.41,boxstyle='round,pad=.05',facecolor=pale,edgecolor=c,lw=1))
 ax.text(x+1.225,.485,title,ha='center',va='center',fontsize=8,color=c,fontweight='bold')
for x in [2.8,6.2]:ax.add_patch(FancyArrowPatch((x,.485),(x+.72,.485),arrowstyle='-|>',mutation_scale=10,color=teal,lw=1.4))
ax.text(.2,-.02,'3 qualified outputs · 84 measurement units + 6 switching units · current authority at every commitment',fontsize=7.2,color=ink)
save(fig,'capability-branches')

fig,ax=plt.subplots(figsize=(7.1,3.05))
strata=['nominal','calibration_failure','capacity_loss','delayed_authority'];matrix=np.zeros((3,4));false=np.zeros((3,4),int)
for i,f in enumerate(families):
 for j,s in enumerate(strata):
  a=[r for r in rows if r['family']==f and r['method']=='aperture' and aliases.get(r['stress'],r['stress'])==s]
  matrix[i,j]=sum(r['qualified'] for r in a);false[i,j]=sum(r['false_accept'] for r in a)
cmap=LinearSegmentedColormap.from_list('coverage',['#F6EDF0','#D2CEE9',teal])
ax.imshow(matrix,vmin=0,vmax=8,cmap=cmap,aspect='auto')
for i in range(3):
 for j in range(4):
  color='white' if matrix[i,j]>=6 else ink
  ax.text(j,i-.13,f'{int(matrix[i,j])}/8 qualified',ha='center',va='center',fontsize=10,fontweight='bold',color=color)
  ax.text(j,i+.18,f'{false[i,j]} false accepts',ha='center',va='center',fontsize=8,color=color)
ax.set_xticks(range(4),['Nominal','Shared calibration\nfailure','Capacity / action\nbank loss','Delayed authority'])
ax.set_yticks(range(3),['Spectra','Dynamics','Spatial counts'])
ax.tick_params(length=0,pad=8)
for spine in ax.spines.values():spine.set_visible(False)
ax.set_title('Identical qualified coverage for Aperture and the conventional modular builder',loc='left',pad=16)
fig.text(.13,-.04,'Two spatial-count missions abstain on authority timing. Raw stress labels and different severities remain in the evidence.',fontsize=7.5,color=ink)
save(fig,'coverage-and-false-acceptance')

fig,axs=plt.subplots(1,3,figsize=(7.1,3.4),sharey=True)
short=['A','M','F','U','G','S','H'];selection=[m for m in methods if m!='wait']
for ax,f,fl in zip(axs,families,['Spectra','Dynamics','Spatial counts']):
 for j,m in enumerate(selection):
  a=[r for r in rows if r['family']==f and r['method']==m and r['nrmse'] is not None]
  for k,r in enumerate(a):
   jitter=((k*13%31)-15)/75
   ax.scatter(j+jitter,r['nrmse'],s=11,marker='x' if r['false_accept'] else 'o',color=red if r['false_accept'] else teal,alpha=.72,linewidths=.7)
  if a:ax.plot([j-.3,j+.3],[np.median([r['nrmse'] for r in a])]*2,color=dark,lw=1.7)
 ax.axhline(.12,color=amber,ls='--',lw=1.1)
 ax.set_yscale('log');ax.set_ylim(.002,1);ax.set_xticks(range(7),short);ax.set_title(fl);ax.grid(axis='y',alpha=.18)
axs[0].set_ylabel('Prediction NRMSE (log scale)')
fig.text(.10,-.02,'A Aperture · M Modular · F Flat · U Uniform · G Gaussian surrogate · S Frozen spectral · H Hindsight',fontsize=7.5)
fig.text(.10,-.09,'Each mark is one completed case. Red × = false acceptance; bars = medians; dashed line = 0.12 quality limit.',fontsize=7.5)
save(fig,'all-case-errors')

fig,axs=plt.subplots(1,2,figsize=(7.1,3.55),gridspec_kw={'width_ratios':[1.2,1]})
y=np.arange(len(methods));acq=[summary['methods'][m]['total_acquisition_units'] for m in methods];ver=[summary['methods'][m]['total_verification_units'] for m in methods]
axs[0].barh(y,acq,color=purple,label='Fitting acquisitions');axs[0].barh(y,ver,left=acq,color=teal,label='Verification')
axs[0].set_yticks(y,[s.replace('\n',' ') for s in labels]);axs[0].invert_yaxis();axs[0].set_xlabel('Synthetic resource units, all 96 missions');axs[0].set_title('Failures remain paid',loc='left');axs[0].legend(loc='upper left',bbox_to_anchor=(0,-.19),ncol=2,fontsize=7,frameon=False)
cpu=[summary['methods'][m]['total_cpu_s'] for m in methods]
axs[1].barh(y,cpu,color=[amber if m=='gaussian_surrogate' else '#8B80A6' for m in methods]);axs[1].set_yticks(y,[]);axs[1].invert_yaxis();axs[1].set_xlabel('Measured solve CPU seconds');axs[1].set_title('Compute is a separate unit',loc='left')
save(fig,'full-observed-costs')

fig,axs=plt.subplots(1,2,figsize=(7.1,3.1))
for schedule,col,label in [('stable',purple,'Stable demand'),('shift',teal,'Demand shift'),('shared-failure',red,'Shared failure')]:
 selected=[x for x in campaigns if x['method']=='aperture' and x['strategy']=='eager' and x['capacity_units']==90 and x['schedule']==schedule]
 selected.sort(key=lambda x:x['switch_tariff'])
 axs[0].plot([x['switch_tariff'] for x in selected],[x['qualified'] for x in selected],marker='o',color=col,label=label)
axs[0].set_xlabel('Assumed units per family switch');axs[0].set_ylabel('Qualified outputs / 3 demands');axs[0].set_xticks([0,3,12]);axs[0].set_yticks([0,1,2,3]);axs[0].legend(fontsize=7.4,frameon=False,loc='lower left');axs[0].set_title('Preserving options has a capacity cost',loc='left')
v=np.linspace(0,64,129)
for schedule,col,label in [('stable',purple,'Stable: 3 outputs / 84 units'),('shift',teal,'Shift: 3 outputs / 90 units'),('shared-failure',red,'Failure: 0 outputs / 90 units')]:
 x=next(x for x in campaigns if x['method']=='aperture' and x['strategy']=='eager' and x['capacity_units']==90 and x['switch_tariff']==3 and x['schedule']==schedule)
 axs[1].plot(v,v*x['qualified']-x['used_units'],color=col,label=label)
axs[1].axhline(0,color=ink,ls=':',label='Wait');axs[1].set_xlabel('Illustrative reward per qualified output');axs[1].set_ylabel('Abstract score (no monetary units)');axs[1].set_title('Waiting wins below the crossover',loc='left');axs[1].legend(fontsize=7,frameon=False,loc='upper left')
for ax in axs:ax.grid(alpha=.15)
fig.tight_layout(w_pad=2)
save(fig,'option-cost-crossovers')
print(json.dumps({'vector_figures':10,'directory':str(OUT)}))
