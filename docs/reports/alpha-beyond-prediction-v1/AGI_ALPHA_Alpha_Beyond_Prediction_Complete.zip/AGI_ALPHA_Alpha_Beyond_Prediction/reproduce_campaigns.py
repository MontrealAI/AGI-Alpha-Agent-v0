import hashlib,json,os,pathlib,subprocess,sys
root=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(root/'src'))
from experiments import normalize_case
label_map={'normal':'nominal','correlated_calibration_failure':'calibration_failure','unavailable_action_group':'capacity_loss','delayed_authority':'delayed_authority'}
source=root/'evidence/confirmation/cases.json'
target=root/(sys.argv[1] if len(sys.argv)>1 else 'evidence/campaigns')
target.mkdir(parents=True,exist_ok=False)
cases=[]
for raw in json.loads(source.read_text()):
 case=normalize_case(raw)
 original=case['hidden']['stress']
 case['hidden']['raw_stress_label']=original
 case['hidden']['stress']=label_map.get(original,original)
 if 'stress_class' in case['hidden']:case['hidden']['stress_class']=case['hidden']['stress']
 cases.append(case)
normalized=target/'cases-labels-only.json'
normalized.write_text(json.dumps(cases,separators=(',',':'))+'\n')
receipt={'scope':'Post-reveal metadata adapter only; frozen policy and replay source unchanged.','mapping':label_map,'original_cases_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'normalized_cases_sha256':hashlib.sha256(normalized.read_bytes()).hexdigest(),'first_attempt':'evidence/campaign-first-stderr.log: ValueError before any replay; raw hidden labels differed from frozen replay labels.','raw_labels_retained':True,'severity_warning':'Unavailable action bank and a reduced measurement budget are grouped for schedule lookup; they are not identical distributions.'}
(target/'LABEL_ADAPTER.json').write_text(json.dumps(receipt,indent=2)+'\n')
env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
with (target/'stdout.log').open('w') as out,(target/'stderr.log').open('w') as err:
 result=subprocess.run([sys.executable,str(root/'src/campaign.py'),'--cases',str(normalized),'--output',str(target)],env=env,stdout=out,stderr=err)
(target/'execution.json').write_text(json.dumps({'exit_code':result.returncode,'scientific_source_changed':False,'outcome_tuning':False},indent=2)+'\n')
print(json.dumps({'exit_code':result.returncode,'output':str(target)}))
sys.exit(result.returncode)
