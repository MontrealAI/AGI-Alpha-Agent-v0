# Writer #11: focused publication handoff

## Status and scope

This is a concrete intake document for the completed **Alpha Beyond Prediction** research package. It is not an attestation that a pull request has been opened, merged, or deployed. The designated repository is [MontrealAI/AGI-Alpha-Agent-v0](https://github.com/MontrealAI/AGI-Alpha-Agent-v0); its authorized site is [montrealai.github.io/AGI-Alpha-Agent-v0](https://montrealai.github.io/AGI-Alpha-Agent-v0/).

The proposed additive publication namespace is:

```text
docs/reports/alpha-beyond-prediction-v1/
```

Use a focused PR containing this namespaced report, its authoritative PDF, source/evidence package, and local/static demo. Preserve existing owners, canonical URLs, unrelated reports, repository-wide configuration and security settings. No shared catalog or index edit is included in this intake scope. A final public path is verified only after authorized intake and the project's Pages workflow complete.

## Ownership and applicable boundary

Coordination takes place in [issue #4850](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/issues/4850). The existing [receiving boundary in comment 6377105309](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/issues/4850#issuecomment-6377105309) leaves shared-index changes, qualified merge, and Pages publication with the established coordinator. A fresh current-main/ownership check is required at intake; the source commits audited for research do not replace it.

Held work **#4863 and #4865 remains held**. This contribution does not invoke the held harness facade, clear its restrictions, activate a provider, mutate security, generate service credentials, create live economic jobs, or settle a transaction. The unchanged released native dispatcher is used only for the explicitly bounded local fixture documented in the package. Existing Fleet/release owners retain their lanes. No alternate account, destination, or publication route may be used to evade a denial.

This research lane has prepared artifacts and source-backed evidence. Maintainer approval, required repository checks, merge authority and the authorized Pages workflow remain separate gates. A passing scientific test is not merge authorization.

## Exact deliverable set

| Deliverable | Package path / name |
|---|---|
| Authoritative paper | `AGI_ALPHA_Alpha_Beyond_Prediction.pdf` |
| Complete release archive | `AGI_ALPHA_Alpha_Beyond_Prediction_Complete.zip` |
| LaTeX entry and dependencies | `paper/alpha-beyond-prediction.tex`, included manuscript sections, `paper/references.bib`, vector figures |
| Scientific implementation and one-command reproduction | `src/`, `reproduce.py`, frozen `requirements.txt` |
| Frozen problem selection and chronology | `protocol/FINAL_FREEZE.json`, `PROTOCOL.md`, sealed archive and revealed generator; `evidence/heldout-reveal/` |
| Complete confirmation and replay | `evidence/confirmation/`, `evidence/campaigns/`, first-failure logs |
| Independent audits | `evidence/review/`, `evidence/heldout-audit/`, `tests/` |
| Demonstration | `demo/index.html`, `replay-data.js`, `server.py`, guide and validation |
| Source integration and rights | `integration/`, `LICENSE`, `PROVENANCE.md` |
| Reader-facing accounting and evidence map | `README.md`, `EVIDENCE_INDEX.md`, `COST_ACCOUNTING.md` |

The archive is produced outside the package directory so it cannot recursively include itself. Retain exact package/PDF hashes in the final release receipt. The PDF inside the ZIP remains authoritative if a standalone preview or storage service changes PDF bytes; never silently substitute the transformed copy.

## Prepared receiving assets

The following files are prepared locally for the proposed namespace; their existence does not attest deployment:

| Prepared file | Receiving path relative to `docs/reports/alpha-beyond-prediction-v1/` |
|---|---|
| `publication/index.html` | `index.html` |
| `publication/PAPER_METADATA.json` | `PAPER_METADATA.json` |
| `publication/static-demo/index.html` | `demo/index.html` |
| `publication/static-demo/replay-data.js` | `demo/replay-data.js` |

The passive landing page links sibling `AGI_ALPHA_Alpha_Beyond_Prediction.pdf`, flattened `AGI_ALPHA_Alpha_Beyond_Prediction.tex`, `AGI_ALPHA_Alpha_Beyond_Prediction_Complete.zip`, `README.md`, `EVIDENCE_INDEX.md`, `COST_ACCOUNTING.md`, and `PROVENANCE.md`. It includes an inline PDF object with a direct download fallback. These sibling artifacts must accompany the receiving page. English/French metadata is bilingual; the paper itself is English.

The landing page's visible disclaimer link is `../../DISCLAIMER_SNIPPET.md`. The public static-demo variant adds exactly one visible footer paragraph linking `../../../DISCLAIMER_SNIPPET.md`; every other HTML byte matches the tested local demo. Its replay file is byte-identical. [STATIC_DEMO_VARIANT.json](STATIC_DEMO_VARIANT.json) records the source/variant hashes, exact inserted HTML, and verified one-insertion difference. The local tested `demo/` remains unchanged. The static variant does not publish the Python server or imply live computation. Browser visual acceptance of these receiving assets remains unexecuted; source/syntax checks are identified separately.

## Review summary for a focused PR

**Suggested title:** `docs: publish Writer 11 Alpha Beyond Prediction research package`

**Problem.** Adaptability is often credited with future value without a construction-level comparison against equally capable conventional methods. Scientific verification can also be mistaken for scientific correctness.

**Contribution.** This isolated report supplies a bounded measurement-program constructor, three synthetic task families, a pre-reveal freeze, 96 cases and eight methods, public-data pilot outputs, exact source audits, a local interactive demo, and reproducible negative findings. It changes the available observation operator inside a declared language; it does not claim autonomous invention or universal preparedness.

**Observed result.** APERTURE and the conventional modular builder each qualify in 54/96 cases and choose the same actions. Forty of 94 residual-accepted APERTURE outputs miss the scientific threshold. Only 6/32 held-out imaging cases qualify. The conventional control shares inference/design machinery and is a supplied analytical program, not a human-expert trial. Costs retain their units, and unknown human/provider/maintenance prices remain unknown.

**Validation.** The primary run preserves all 768 records with 39 unchanged frozen identities. Pre-freeze review has 22 passing scientific tests; the held-out audit has 29,136 passing reconstruction checks; the demo has 12 passing bounded tests including actual loopback HTTP. The [executed numerical reproduction receipt](../evidence/reproduction/REPRODUCTION_RECEIPT.json) reports exact 96-case and 768-record non-timing agreement, repeated test/audit success, and unchanged frozen identities. Its new directory used 44 copied inputs plus three immutable reference-data hard links and reused the installed runtime; it is not a fresh-machine or full-package clean-room build. Use the final PDF build/inspection receipt to state typesetting and visual-review status precisely.

**Limitations.** The study is synthetic, same-session role-separated, and finite. Native portable restoration and local-EVM tests remain NOT_RUN with retained failures. Browser visual inspection of the demo could not be completed: no local browser binary was available, and cloud CUA could not reach the loopback server. Actual API and numerical behavior were tested. There are no live settlements, external Fleet numerical jobs, customers, paid commitments, realized receipts, or physical validation.

## Intake checks and exact commands

Before a qualified merge, the coordinator can inspect the final manifest and verify its bytes, compare the proposed namespace against current main, check source/license preservation, and apply repository-required review and CI. This list supplements the existing ownership boundary; it does not replace or weaken it.

```sh
python reproduce.py --output local-reproduction
python -m unittest discover -s tests -p test_demo.py -v
bash build_paper.sh
python demo/server.py
```

Use a new reproduction directory and the recorded dependencies. The demo binds `127.0.0.1` and needs explicit local consent per run. Static Pages hosting exposes prerecorded evidence, never the local Python server. A new task or opportunity requires a new immutable plan and bounded authority; no permission is inherited from a published artifact.

The label-only campaign adapter is post-reveal and explicitly disclosed. `cases-labels-only.json.gz` retains the original decompressed hash; do not call its compression a changed scientific input. The original NIST observations and residuals are intentionally excluded; retain their licensed retrieval instructions and derived outputs.

## Publication receipt requirements

The final publication record should state the exact PR/commit, satisfied checks/reviews, coordinator decision, merge outcome, Pages workflow run and verified URLs for the PDF, source, demo and evidence. Until those facts are verified, call links **proposed**. If an action is blocked, record the action, target, exact reason and pending owner/permission; keep the completed downloadable package available. Preserve the existing coordinator's authority and do not substitute a different route.
