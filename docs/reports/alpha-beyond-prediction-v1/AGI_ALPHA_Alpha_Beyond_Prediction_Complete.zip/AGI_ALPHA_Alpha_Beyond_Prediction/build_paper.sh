#!/usr/bin/env bash
# Rebuild the complete manuscript from supplied LaTeX and vector figures.
set -euo pipefail
paper_root="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
cd "$paper_root/paper"
mkdir -p build
export TEXMFVAR="$paper_root/paper/build/texmf-var"
export SOURCE_DATE_EPOCH=1792800000
export FORCE_SOURCE_DATE=1
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build alpha-beyond-prediction.tex >build/pass1.stdout.log
cd build
export BIBINPUTS="..:${BIBINPUTS:-}"
bibtex alpha-beyond-prediction >bibtex.stdout.log
cd ..
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build alpha-beyond-prediction.tex >build/pass2.stdout.log
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=build alpha-beyond-prediction.tex >build/pass3.stdout.log
cp build/alpha-beyond-prediction.pdf "$paper_root/AGI_ALPHA_Alpha_Beyond_Prediction.pdf"
python "$paper_root/flatten_tex.py"
python - <<'PY'
from pathlib import Path
import hashlib,json
p=Path('../AGI_ALPHA_Alpha_Beyond_Prediction.pdf')
print(json.dumps({'pdf':str(p.resolve()),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}))
PY
