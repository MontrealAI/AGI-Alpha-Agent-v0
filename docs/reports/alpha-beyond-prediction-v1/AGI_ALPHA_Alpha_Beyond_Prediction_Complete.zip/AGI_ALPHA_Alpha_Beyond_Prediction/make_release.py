"""Create a deterministic complete source/evidence ZIP; never edits frozen science."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
PREFIX = 'AGI_ALPHA_Alpha_Beyond_Prediction/'
DIRECTORIES = {'src', 'tests', 'protocol', 'evidence', 'integration', 'data', 'demo', 'paper', 'figures', 'publication'}
TOP_FILES = {'README.md', 'EVIDENCE_INDEX.md', 'PROVENANCE.md', 'COST_ACCOUNTING.md', 'LICENSE', 'requirements.txt',
             'reproduce.py', 'reproduce_campaigns.py', 'build_paper.sh', 'flatten_tex.py', 'make_figures.py', 'make_release.py',
             'AGI_ALPHA_Alpha_Beyond_Prediction.pdf', 'AGI_ALPHA_Alpha_Beyond_Prediction.tex'}

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def payloads():
    for path in sorted(ROOT.rglob('*')):
        if not path.is_file() or path.is_symlink():
            continue
        rel = path.relative_to(ROOT)
        if rel.parts[0] not in DIRECTORIES and str(rel) not in TOP_FILES:
            continue
        if any(part in {'__pycache__', 'build', '.pytest_cache', 'node_modules', '.git', '.rsync-tmp'} for part in rel.parts):
            continue
        if path.suffix in {'.pyc', '.pyo'} or 'pages' in rel.parts:
            continue
        if path.name in {'PACKAGE_MANIFEST.json', 'Gauss1.dat', 'Gauss1.txt'}:
            continue
        yield rel.as_posix(), path.read_bytes()

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--stage', choices=['manuscript-checkpoint', 'final'], default='final')
    args = p.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    if args.output.exists():
        raise FileExistsError('Choose a new archive path; prior editions are not overwritten.')
    files = dict(payloads())
    if 'AGI_ALPHA_Alpha_Beyond_Prediction.pdf' not in files:
        raise RuntimeError('The authoritative PDF must be included.')
    manifest = {'format': 'writer11-complete-package-v1', 'stage': args.stage,
                'scientific_freeze_sha256': sha((ROOT / 'protocol/FINAL_FREEZE.json').read_bytes()),
                'authoritative_pdf': 'AGI_ALPHA_Alpha_Beyond_Prediction.pdf',
                'files': {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in files.items()},
                'boundaries': ['Manifest verifies byte custody, not scientific truth.',
                               'The PDF inside this ZIP is authoritative if another service transforms a standalone PDF.',
                               'Raw NIST observations are not redistributed; their verified retrieval instructions are included.',
                               'Measured timings are not expected to reproduce byte for byte.']}
    files['PACKAGE_MANIFEST.json'] = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
    with zipfile.ZipFile(args.output, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9, strict_timestamps=True) as z:
        for name, data in sorted(files.items()):
            info = zipfile.ZipInfo(PREFIX + name, (2026, 10, 24, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.create_system = 3
            info.external_attr = (0o100644 << 16)
            z.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    with zipfile.ZipFile(args.output) as z:
        assert z.testzip() is None
        assert len(z.namelist()) == len(files) == len(set(z.namelist()))
        for name, data in files.items():
            assert z.read(PREFIX + name) == data, name
    data = args.output.read_bytes()
    print(json.dumps({'path': str(args.output.resolve()), 'bytes': len(data), 'sha256': sha(data),
                      'payload_files': len(manifest['files']), 'zip_members': len(files),
                      'pdf_sha256': manifest['files'][manifest['authoritative_pdf']]['sha256'], 'verified': True}))

if __name__ == '__main__':
    main()
