# Independent held-out record audit

The authoritative report is `RECORD_AUDIT_COMPLETE.json`: 256 records covering all 32 hidden cases and eight methods. It contains 29,136 checks, including 5,040 independently regenerated observations, 180 independently scored field predictions and 720 recomputed verification residuals. The maximum quality-score discrepancy was 5.551115123125783e-17 and maximum verification-residual discrepancy was 1.6431300764452317e-14. There were no failed checks and no changes to the 39 frozen source identities.

This audit reads the first primary-run outputs. It does not execute another policy run. The analytic forward operator, noise and truth evaluator come from the sealed steward generator; the covariance and verification-residual reconstruction is independently coded here. `INFORMATION_BOUNDARY_AUDIT.json` additionally records source and observed event-flow checks for delayed health evidence. These are same-session automated role-separated checks, not organizational or human independence.

Run from the package root:

```bash
python evidence/heldout-audit/audit_records.py --package . --records evidence/confirmation/records.json --output evidence/reproduced-record-audit.json
```

The original event/noise/quality-only successful audit remains as `RECORD_AUDIT.json`; the complete report adds direct reconstruction of verification statistics. The complete audit script is the authoritative reproducible audit implementation.

The held-out result is negative: APERTURE qualifies 6/32 cases, while its model-conditional verification accepts 30/32, yielding 24 false acceptances and two abstentions. Normal imaging qualifies 3/8; calibration-fault cases 0/8; unavailable action groups 1/8; delayed authority 2/8. This is evidence that residual consistency is not an agreed-quality certificate. The strongest modular implementation has the same qualification and chosen actions. Small solver-level numerical differences and one unsuccessful optimizer-status report in APERTURE remain visible.

`STRESS_LABEL_MAP.json` declares a semantics-only map for downstream scenario replay. It does not alter the scientific confirmation records, select cases, or assert that stress severity is identical across families. Because the map is added after scientific confirmation, downstream use must disclose this metadata repair and retain all raw labels.
