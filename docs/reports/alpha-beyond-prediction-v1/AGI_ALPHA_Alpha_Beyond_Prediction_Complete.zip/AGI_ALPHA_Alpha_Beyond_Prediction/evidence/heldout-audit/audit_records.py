from __future__ import annotations
import argparse, hashlib, importlib.util, json, math
from pathlib import Path
import numpy as np

METHODS=('aperture','modular','flat','uniform','gaussian_surrogate','frozen_specialist','wait','hindsight')

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--package',type=Path,required=True)
    p.add_argument('--records',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    args=p.parse_args()
    root=args.package
    path=root/'evidence/heldout-reveal/cases-raw.json'
    assert hashlib.sha256(path.read_bytes()).hexdigest()=='4788d502763f3ec6d40e160a845d55c100d09e1f07390f0cd8610a350fe9da5a'
    cases={c['public']['id']:c for c in json.loads(path.read_text())}
    spec=importlib.util.spec_from_file_location('audit_generator',root/'protocol/revealed/generator.py')
    generator=importlib.util.module_from_spec(spec);spec.loader.exec_module(generator)
    raw_records=json.loads(args.records.read_text())
    rows=[r for r in raw_records if r['case_id'] in cases]
    assert len(rows)==len(cases)*len(METHODS),(len(rows),len(cases)*len(METHODS))
    keys={(r['case_id'],r['method']) for r in rows}
    assert keys=={(c,m) for c in cases for m in METHODS}
    checks=[]; failures=[]; noise_checks=0; quality_checks=0; max_quality_diff=0.; residual_checks=0; max_residual_diff=0.
    for r in rows:
        cid,method=r['case_id'],r['method']
        c=cases[cid];pub,hid=c['public'],c['hidden']
        acts={a['id']:i for i,a in enumerate(pub['actions'])}
        available=np.asarray(pub['available'],dtype=bool).copy()
        start=hid['context']['authority_not_before_step'];end=hid['context']['authority_expires_after_step']
        acq=ver=acq_units=ver_units=0;used=[];quarantine_seen=False
        local=[]
        for ev in r['events']:
            tick=ev['tick']
            if ev['event']=='quarantine':
                local.append(ev['refund_units']==0)
                for group in ev['groups']:
                    available&=np.array([a['group']!=group for a in pub['actions']])
                    used=[i for i in used if pub['actions'][i]['group']!=group]
                quarantine_seen=True
            elif ev['event'] in ('acquire','verify'):
                i=acts[ev['action']]
                local.extend([bool(available[i]),start<=tick<end,ev['units']==pub['actions'][i]['cost'],ev['irreversible']])
                repeat=ev['repeat'] if ev['event']=='acquire' else 1000+ver
                expected=generator.observe(c,i,repeat)
                local.append(ev['value']==expected)
                noise_checks+=1
                if ev['event']=='acquire':
                    acq+=1;acq_units+=ev['units'];used.append(i)
                else:
                    ver+=1;ver_units+=ev['units']
        cost=r['costs']
        local.extend([acq==cost['acquisitions'],ver==cost['verification_acquisitions'],acq_units==cost['acquisition_units'],ver_units==cost['verification_units'],acq_units<=pub['budget'],ver<=pub['verify_count']])
        local.append(r['false_accept']==bool(r['verification_pass'] and not r['scientific_pass']))
        local.append(r['qualified']==bool(r['verification_pass'] and r['scientific_pass']))
        if r['theta'] is not None:
            score=generator.score(c,r['theta']);quality_checks+=1
            diff=abs(score['nrmse']-r['nrmse']);max_quality_diff=max(max_quality_diff,diff)
            local.extend([diff<1e-13,score['feasible']==r['scientific_pass']])
            local.append(used==r['selected_actions'])
            A=np.asarray(hid['independent_action_matrix'])
            if method=='hindsight':
                A=A*np.array([hid['gain_by_group'][a['group']] for a in pub['actions']])[:,None]
            chosen=np.asarray(used,dtype=int)
            theta=np.asarray(r['theta']);prior=np.asarray(pub['prior_mean']);precision=1/pub['prior_scale']**2
            if method=='gaussian_surrogate':
                variances=(pub['background']+A[chosen]@prior)/pub['exposure']
                covariance=np.linalg.inv(precision*np.eye(pub['dim'])+A[chosen].T@(A[chosen]/variances[:,None]))
            else:
                fisher=pub['exposure']/(pub['background']+A[chosen]@theta)
                covariance=np.linalg.inv(precision*np.eye(pub['dim'])+A[chosen].T@(A[chosen]*fisher[:,None]))
            scores=[]
            for ev in r['events']:
                if ev['event']!='verify':
                    continue
                i=acts[ev['action']]
                mean=pub['exposure']*(pub['background']+A[i]@theta)
                variance=max(mean,1e-8)+pub['exposure']**2*(A[i]@covariance@A[i])
                score=(ev['value']-mean)**2/max(variance,1e-12)
                difference=abs(float(score)-ev['normalized_squared_residual'])
                max_residual_diff=max(max_residual_diff,difference);residual_checks+=1
                local.append(difference<1e-9)
                scores.append(float(score))
            statistic=float(np.mean(scores)) if scores else None
            expected_verified=len(scores)==pub['verify_count'] and bool(scores) and statistic<=4
            local.append(expected_verified==r['verification_pass'])
            local.append((statistic is None and r['verification_statistic'] is None) or (statistic is not None and abs(statistic-r['verification_statistic'])<1e-9))
        else:
            local.extend([r['nrmse'] is None,not r['scientific_pass'],not r['qualified']])
        if not all(local):
            failures.append({'case_id':cid,'method':method,'failed_check_indices':[i for i,x in enumerate(local) if not x]})
        checks.append({'case_id':cid,'method':method,'checks':len(local),'passed':all(local),'noise_checks':acq+ver,'quarantine_seen':quarantine_seen})
    freeze=json.loads((root/'protocol/FINAL_FREEZE.json').read_text())
    frozen_bad=[n for n,meta in freeze['files'].items() if hashlib.sha256((root/n).read_bytes()).hexdigest()!=meta['sha256']]
    result={'records':len(rows),'unique_cases':len(cases),'methods':list(METHODS),'checks':sum(c['checks'] for c in checks),'noise_checks':noise_checks,'quality_checks':quality_checks,'maximum_quality_difference':max_quality_diff,'verification_residual_checks':residual_checks,'maximum_verification_residual_difference':max_residual_diff,'failures':failures,'frozen_source_mismatches':frozen_bad,'passed':not failures and not frozen_bad,'record_sha256':hashlib.sha256(args.records.read_bytes()).hexdigest(),'audit_script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'scope':'Independent recorded-event/noise/quality/budget/authority replay, not a second policy execution or independent organization.','per_record':checks}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='per_record'},indent=2))
    raise SystemExit(0 if result['passed'] else 1)

if __name__=='__main__':
    main()
