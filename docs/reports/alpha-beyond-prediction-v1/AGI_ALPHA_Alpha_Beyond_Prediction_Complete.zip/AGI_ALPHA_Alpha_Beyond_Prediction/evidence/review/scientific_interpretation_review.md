# Independent scientific interpretation review

## Scope and disposition

This review reads the completed confirmation records, replay records, frozen protocol and implementation. It does not tune or replace a scientific method, change a case, or rerun the confirmatory policy. The reviewer is a separate assistant role in the same session and shared filesystem, not an independent institution, recruited human expert, security auditor or publication approver.

**Scientific disposition:** the defensible outcome is an inspectable engineering implementation and a negative comparative result. The artifact constructs and executes several kinds of measurement program within its supplied finite language. It does **not** demonstrate a task-level advantage over the equally enabled conventional construction control, a total-cost advantage, or reliable scientific quality in the held-out family. Its residual verifier is an especially important failure case: every completed Aperture mission passes that check, including all 40 scientifically unacceptable answers.

The initial review occurred while the manuscript was being assembled. The completed-manuscript addendum below and `manuscript-claim-review.json` now bind the reviewed claim-bearing sections to their exact hashes. This review changes no frozen source.

## Recomputed primary outcomes

All counts below were recomputed directly from `evidence/confirmation/records.json`, rather than accepted from its summary. The file contains 768 distinct case/method records: 96 cases, three families of 32 cases, eight methods. No abstention is removed from coverage denominators.

| Method | Qualified / 96 | Residual check passes | False acceptances | Abstentions | Acquisition + verification units |
|---|---:|---:|---:|---:|---:|
| Aperture | 54 | 94 | 40 | 2 | 2,064 + 376 |
| Conventional modular control | 54 | 94 | 40 | 2 | 2,064 + 376 |
| Flat numerical replacement | 54 | 94 | 40 | 2 | 2,064 + 376 |
| Uniform acquisition | 50 | 94 | 44 | 2 | 2,064 + 376 |
| Gaussian surrogate | 54 | 94 | 40 | 2 | 2,064 + 376 |
| Restricted spectral specialist | 24 | 32 | 8 | 64 | 672 + 128 |
| Wait | 0 | 0 | 0 | 96 | 0 + 0 |
| Privileged hindsight specialist | 75 | 94 | 19 | 2 | 2,064 + 376 |

Aperture's qualified fraction is 54/96 = 56.25%. Its false-acceptance fraction among accepted outputs is **40/94 = 42.55%**, while its false-acceptance count divided by all missions is 40/96 = 41.67%. These denominators answer different questions and must not be interchanged. The two nonaccepted missions are authority refusals; the residual check rejects none of the 94 completed Aperture estimates.

| Aperture family | Qualified / 32 | False acceptances | Abstentions |
|---|---:|---:|---:|
| Spectral characterization | 24 | 8 | 0 |
| Causal system identification | 24 | 8 | 0 |
| Held-out coded-aperture emission imaging | 6 | 24 | 2 |

Each known family succeeds on all eight nominal, all eight capacity-loss and all eight delayed-authority cases, but fails scientific quality on all eight calibration-failure cases while passing verification. The held-out family qualifies 3/8 normal cases, 0/8 correlated-calibration cases, 1/8 unavailable-action-group cases and 2/8 delayed-authority cases. Two delayed-authority cases abstain. Low success in the new family must remain prominent; executing a valid operator is not the same outcome as delivering agreed scientific quality.

### Paired comparisons and what they identify

1. **Aperture versus modular:** no qualification discordance and no different recorded selected-action list in 96 paired cases. The maximum absolute NRMSE difference is `1.0459596535006277e-06`; numerical results are very close, not universally bitwise identical. Acquisition, verification, row-construction and scoring counts agree. Objective-call counts and measured time can differ. Thus a claim of identical *all* costs would be too strong.
2. **Aperture versus flat:** no qualification or selected-action discordance. This replacement still pays to construct the original operator, then removes the symbolic execution representation. It tests the necessity of symbolic structure after construction, not the cost of avoiding construction entirely.
3. **Aperture versus uniform:** four paired improvements and no paired losses in qualification. All four are in the held-out family, where uniform qualifies 2/32. This supports a finite-suite advantage for the conventional information-selection rule relative to this fixed-spread strategy. It does not identify an advantage of Aperture's architecture.
4. **Aperture versus Gaussian surrogate:** no qualification discordance in any case, although selected-action lists differ in 28 cases. The surrogate's recorded total wall time is 1.178 seconds versus 2.002 seconds for Aperture. This is one fixed-order run, not a randomized or repeated timing experiment. The surrogate does not dominate every quality measure: its held-out finite-error 90th percentile is 0.42648, versus 0.34975 for Aperture. A claim that exact Poisson fitting is necessary for the reported qualified coverage is contradicted by these observations.
5. **Aperture versus hindsight:** the privileged method adds 21 qualifications and loses none in this suite. It qualifies all 64 known-family cases but only 11/32 held-out cases. Extra calibration knowledge does not solve every low-count inverse problem at the fixed budget. The comparator is greedy and privileged, not a mathematical optimum or performance bound.
6. **Restricted specialist and wait:** these reveal the costs and coverage of refusing work. They must not replace the same-powers modular control as the basis for novelty. The specialist's lower aggregate median error is computed on a different set of 32 fitted missions; Aperture's median uses 94 fitted missions. Such medians cannot be interpreted as a common-task ranking without paired stratification.

### Narrowness of the main comparator

The conventional control has the same information, primitive access and adaptation powers. This meets the important requirement that it may build the new operator. However, it is not an independently engineered expert system. Both construction paths call the same `basis_matrix` expression interpreter and then share the entire solver, acquisition, health and authority code. The principal construction change is `weights @ values` versus `np.sum(weights[:, None] * values, axis=0)`. This is best described as a conventional construction/equivalence control. A tie is expected from its shared mathematics, and shared defects remain possible.

No observed human trial establishes equal implementation effort or equal total engineering budgets. This limitation prevents an economic or developer-productivity inference in either direction. The evidence also does not show that one representation is easier to maintain, understand, audit or extend.

## Scientific failure and uncertainty

The suite exposes two different failure mechanisms. Common calibration error defeats a self-consistent residual checker in all three scientific families. Low-count measurement uncertainty also produces unacceptable field estimates even when the operator and nominal likelihood can be executed. Neither failure should be relabeled as robust adaptation.

The record `h-d19003f77ccb` reports `solver_all_success=false` for Aperture and the flat replacement. Both have NRMSE 0.34552890915225054, fail scientific quality and pass the residual check. The modular control reports success with almost identical numerical quality. This numerical optimizer-status warning must remain in the evidence and should be mentioned in the results; there is no license to discard the case or silently repair the frozen solver. A successful solver return would not itself establish scientific quality.

All tail summaries are empirical summaries of the fixed suite, conditional on a finite estimate where NRMSE is available. They are not confidence intervals or probability statements about real future assignments. An observed median below 0.12 cannot substitute for per-case feasibility. The covariance used for count-design and residual checks is model-conditional Fisher/prior curvature, not a calibrated uncertainty certificate.

The construction language and all algorithms were supplied before reveal; the held-out mission composes them rather than inventing missing science. Spectral point measurements, causal temporal responses and aggregate count imaging have different operational meanings, but remain small finite-coefficient inverse problems. The structural test therefore does not establish arbitrary task transfer or broad prediction immunity.

## Costs, demand replay and economic interpretation

The ledger records useful resource dimensions, including sunk observations removed by quarantine. It does not measure complete economic cost. Initial shared implementation, human engineering and review effort, provider computation, physical instruments, energy, long-lived maintenance and prices remain unknown. Unknown entries are not zero. Synthetic acquisition units cannot be added to wall seconds or sold as dollars.

The 288 replay conditions are repeated sensitivity calculations on selected cases, not 288 independent scientific trials or observations of demand. I recomputed that Aperture and modular agree in qualified outputs, used units, completed attempts and false acceptances for every matched replay condition. The stop-on-failed-verification strategy cannot protect against a wrong estimate whose residual check passes. Waiting can avoid resource loss in the shared-failure schedule, but its omitted-opportunity cost is not priced.

The first replay attempt failed before execution because raw steward stress labels differed from the frozen replay lookup labels. `evidence/campaigns/LABEL_ADAPTER.json` preserves the post-reveal metadata adapter. It maps `normal` to `nominal`, `correlated_calibration_failure` to `calibration_failure`, and `unavailable_action_group` to `capacity_loss`. This does not change the scientific records or frozen policy. It is nevertheless an actual post-freeze reconciliation and must be disclosed explicitly. Losing an action bank is not the same severity or distribution as reducing an acquisition budget; the grouped labels must not conceal that distinction.

All reported switching tariffs and abstract output rewards are assumed. They supply conditional crossover examples only. With zero measured qualification and acquisition advantage over modular in every case and stratum, a positive additional architecture premium cannot be repaid by repeating those ties without some other measured benefit. No conclusion about commercial value, willingness to pay or realized receipts follows. The motivating $15 quadrillion number is absent from the equations and results and should remain so.

## Required manuscript clarifications communicated to the author

- Describe the verifier as accepting all 94 completed Aperture cases, including 40 scientific failures; distinguish accepted-output and all-mission denominators.
- Give the hidden-family 6/32 result and all stress strata prominently.
- Describe modular as a shared-implementation conventional construction/equivalence control; do not imply an observed human-expert trial or equal human engineering expenditure.
- In the information-score equation use an augmented row, for example `d_a=[A_a,Z_a]` for Gaussian missions and `d_a=A_a` for count missions. The actual covariance is joint target/nuisance for Gaussian missions, so writing `A_a C A_a^T` without that definition is dimensionally and operationally incomplete.
- Retain the unsuccessful optimizer-status record and explicitly disclose the replay label adapter.
- State finite-error denominators for tail summaries and keep timing descriptive.

## Figure recommendations

The most informative measured figure is a three-family by four-condition view of qualified, false-accepted and refused outputs, with eight cases in each cell. This exposes the broad Gaussian calibration failure and the much poorer held-out quality. Keep the modular tie visually explicit. A second measured view can show qualified outputs versus used synthetic units under capacity and switching sensitivity, with assumed tariffs marked as such. A conceptual branch diagram should be labeled an illustration and separated from the actual revealed path. Do not use a large success graphic for operator execution while minimizing scientific failure.

## Evidence identities at this review

These identities agree with the pre-freeze independent review for scientific source and protocol. The confirmation and replay files are post-reveal evidence; hashing them records provenance, not prospective independence.

| File | SHA-256 |
|---|---|
| `src/laboratory.py` | `9c59b1583353cab7c246f132e2c9f4ac6de77272df8ef65ccfe62b466c92ed4f` |
| `src/experiments.py` | `8874d25b245f9a3972dc3136a75907baa7ba596d6d5286492a270be2b3dd3e0f` |
| `src/campaign.py` | `dc1f3c2e3a5539c61ea43a9d6690e31b2e6a0242e368a118f7f4ba45d55de116` |
| `protocol/PROTOCOL.md` | `bb4971f053faaf635421a71fc75840e79a91e06df08b9fb51e70259344f895d2` |
| `evidence/confirmation/records.json` | `7544bb57d785a9f1b2fdb08ec52bc817a54b81601141113641ca10ab506e8e5c` |
| `evidence/confirmation/summary.json` | `6635855ca315383bc0d17cbc36720ef4201aa66db5db7f573fb90a6231afe08e` |
| `evidence/campaigns/campaigns.json` | `d1e692145b2b6ea4bdbc51bb0bd8a5d81b9d66b4d7514505e98d9d0eb19b5cbd` |
| `evidence/campaigns/LABEL_ADAPTER.json` | `d3689e6bc440ca6076843ecbc00b8876010c88304ec965039af42029d17f5d57` |

The earlier executable review remains in `INDEPENDENT_REVIEW.md`, `independent-review.json`, `independent-tests.txt`, and `tests/test_independent.py`. The held-out steward's separately coded observation, quality and residual reconstructions are recorded under `evidence/heldout-audit`; they provide additional checks, with the same-session independence limitation retained.

## Completed-manuscript addendum

The abstract, main manuscript, results, evidence appendix and bibliography were reviewed together against the frozen protocol, actual primary records, campaign records, reproduction receipt, held-out audit, local-demo validation receipt and native-integration receipt. All six requested scientific clarifications above are incorporated. The information-score equation now uses the augmented Gaussian row, the narrow construction-control implementation is explicit, and the optimizer warning and actual metadata repair are disclosed. A duplicate appendix inclusion was identified and removed by the manuscript owner.

The full acquired and verified action traces were additionally compared across Aperture and modular, including action identifiers, repetitions and ticks: no paired trace differs. Thus the action-tie statement is supported beyond the final surviving selected-action arrays.

`manuscript-claim-review.json` records the exact reviewed identities and recomputed central totals. Its disposition is **scientific claims consistent with recorded evidence and declared limits**. This assistant subsequently authored `paper/results.tex` from the independent interpretation findings. The final pass is therefore a content-consistency review by a contributor, not independent external peer review or maintainer approval. Subsequent formatting changes do not automatically inherit the exact hash identities in that receipt.

PDF layout inspection, the final ZIP rebuild and manifest, durable custody, maintainer review and public publication have separate owners and evidence. This scientific review does not claim those actions are complete or authorize a release. Source-native portable restoration, EVM execution, physical validation, market demand and human engineering cost remain explicitly unestablished.
