# Pre-freeze independent implementation review

**Result:** 22 independent tests passed on the unchanged source hashes recorded in `independent-review.json`. The test run completed at 2026-10-24T02:58:24Z. This review supports proceeding to the frozen, bounded experiment under the stated limitations. It does not establish future scientific performance, publication authority, or a formal security guarantee.

## Independence and scope

A separate assistant agent prepared `tests/INDEPENDENT_REVIEW_PLAN.md` before inspecting the numerical implementation. It then reviewed `src/laboratory.py`, `src/experiments.py`, `src/campaign.py`, and `protocol/PROTOCOL.md`, and wrote `tests/test_independent.py`. It did not inspect the sealed generator, hidden scenario files, or confirmatory results. This is separation of reviewer and implementation roles within one session and shared filesystem, not organizational independence or an observed human-expert study.

The reference checks use direct NumPy formulas, augmented least squares, and an independently specified Poisson objective optimized with numerical-gradient SLSQP. They do not merely call a second alias of the implementation under review. Small synthetic reviewer fixtures exercise acquisition, authority, failure, and health-event behavior. Those fixtures are validation inputs, not additional confirmatory scientific observations.

## Findings corrected before freeze

| Finding | Why it mattered | Verified correction |
|---|---|---|
| Nonfinite acquisition observations appeared as raw NaN in the event ledger. | Strict JSON export failed exactly when failure evidence was needed. | Nonfinite observations export as null; failed acquisitions retain their consumed units and recovery events. |
| Restore trusted the saved, editable Authority object without an external current grant. | Editing expiry and recomputing an ordinary content hash could renew permission. | Restore requires a separately supplied unchanged current authority and rechecks its bounds. The saved object cannot authorize its own renewal. |
| Missing or empty authority was silently replaced with a generated fixture grant. | An invalid authority request could become permitted measurement work. | Both missing and empty authority refuse before observation callbacks. |
| Scoring counters counted feasible actions while vectorized scoring evaluated every row. | Numerical computation was undercounted. | Executed scored rows and feasible candidates have separate counters. |
| Flat representation provenance checked only matrices. | Changed budgets, costs or availability could retain the old plan identity. | The full lowered object must match its canonical source-bound representation. |
| Finite negative or fractional Poisson observations were accepted as counts. | Invalid inputs could contaminate a fitted model or pass verification. | Invalid count acquisitions incur a recorded recovery without refund; invalid verification observations fail the check. |
| A campaign charged switching costs and changed its active family after an immediately refused mission. | The specialist was penalized for a switch it never performed. | Refused work records abstention without consuming a switch tariff or changing the active execution family. |

## What the tests establish

- Expression evaluation and weighted aggregation agree with independent numerical formulas on bounded inputs.
- Diagonal Gaussian MAP agrees with an independently augmented least-squares problem, including joint nuisance fitting.
- Poisson MAP agrees with the independently implemented objective/optimizer on a fixture containing zero counts.
- Proposed, modular and flat representations produce the same numerical outcome and chosen actions on the common Gaussian and Poisson fixtures.
- Fitting units, verification actions, attempted acquisitions, failed observations, scored rows and recovery counters reconcile with the event trace.
- Delayed authority consumes waiting steps without hidden observation calls; expiry stops measurements at its boundary.
- Observations disclosed later do not change earlier action choices in the tested prefix, and verification does not retrain the estimate or design.
- Health suspicion quarantines affected groups, removes their observations from fitting, recomputes from survivors, and retains sunk costs.
- A late health alert invalidates earlier verification. Four consumed verification actions do not become an unlimited new allowance; insufficient fresh verification fails.
- Snapshot restoration refuses expiry, a new mission, incompatible program binding, omitted current authority, and rehashed saved-authority renewal.
- A known common calibration error can still pass the residual check while failing independent scientific quality. This intentional test validates an explicit limitation, not a claimed detection ability.

## Scientific qualifications retained

The Gaussian routine implements diagonal weighted MAP with a supplied nuisance model. It is not a general dense-noise GLS engine. The count covariance uses expected Fisher information plus prior precision and is not an exact posterior. Residual acceptance is model-conditional and has no proved confidence level here.

The primary conventional builder has the same construction powers, mathematical primitives, solver and observation access. The restricted spectral specialist is an ablation. Shared mathematics is appropriate for isolating representation differences but does not measure equal engineering effort. Human/model authoring costs remain unknown.

The strengthened hindsight comparator knows true calibration and failed-action identities and uses latent parameters for greedy design. It is privileged, but its greedy objective does not prove a global statistical upper bound, and it may lose in individual noisy cases. The protocol states this distinction.

The fitting cap is measured in synthetic acquisition units, while four verification actions have separately charged costs. Switching tariffs and abstract rewards in the campaign are explicit assumptions. Their numerical scores cannot be interpreted as receipts, willingness to pay, human labor savings, or market returns.

Restore's protection depends on the caller supplying a genuinely separate current authority context. An interface that instead copies authority from an imported snapshot would violate that assumption. No live credentials, wallets, financial transactions, or external execution are exercised by these tests.

## Reproduce this review

From the package root:

```bash
python tests/test_independent.py
```

`independent-tests.txt` preserves the actual complete test output. `independent-review.json` records before/after SHA-256 values for all reviewed source, protocol and test files, their equality during the run, and the log hash. Timing in the test runner is descriptive and may vary. Later source changes require a new review record; they must not silently inherit these results.
