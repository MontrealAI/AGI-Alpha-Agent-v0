# Alpha Beyond Prediction: three-minute laboratory

The browser has two clearly labeled modes. **The local server executes the actual frozen Python numerical engine.** A static page, including GitHub Pages, only replays a compact selection of the published records. Neither mode uses a wallet, private data, an account, a paid service, or external APIs.

## Run locally

From the root of this research package, with the declared NumPy and SciPy dependencies installed:

```sh
python demo/server.py
```

Open **http://127.0.0.1:8765/**. Stop with Ctrl+C. The server binds the loopback address only. Use `--port 8766` if the default port is already occupied. The default inputs are `evidence/confirmation/cases.json` and `records.json`; these are already public synthetic cases. Running one of them interactively is a separate reexecution, not a new confirmation sample.

1. **0:00–0:45 — Reveal a mission.** Select a spectral characterization case, then use *Reveal a demand shift* to inspect system identification or coded-aperture emission imaging. The latter changes to a six-component Poisson imaging model with 30 weighted candidate actions. Each change creates a different immutable program and discards the previous permission.
2. **0:45–1:45 — Construct and execute.** Inspect the model and acquisition budget. Check the explicit local synthetic consent box, authorize one bounded run, and choose *Construct & run*. The server calls the current frozen implementation. Select the conventional modular builder to compare it with APERTURE; it has the same primitives, information, and budgets.
3. **1:45–3:00 — Inspect and preserve.** Read scientific error and model-based verification separately. Inspect acquisition, verification, recovery, waiting, construction, and CPU charges. Export the four objects; test restoration; choose *Expire & test refusal*. A passed residual check can coexist with failed scientific quality, which the interface marks in text and contrasting color.

For a known failure, choose an imaging case. For a shared calibration failure or delayed authority, select the corresponding stress label. The exact observed result is shown; no outcome is promised for a selected mission.

## Static replay

Open `demo/index.html` directly, or serve the package through the authorized project site. The banner states **RECORDED EVIDENCE REPLAY**. It exposes one case for each family/stress combination, all eight method records for those cases, the full source-record hash, and original timing. Only APERTURE event traces are embedded in the compact replay; other methods' complete traces remain in the evidence file. The page never labels these archived timings as new computation.

The static *restore* action restores a recorded view by selecting an existing packaged row. It grants no authority and ignores imported scientific values in favor of the packaged evidence. Live expiration and trusted-authority tests require the local server.

Regenerate the compact replay without running numerical experiments:

```sh
python demo/prepare_replay.py --cases evidence/confirmation/cases.json --records evidence/confirmation/records.json --phase confirmation
```

## Authority and restoration boundary

The server stores the current explicitly accepted grant separately from imported JSON. It binds that grant to the exact immutable mission, current server instance, generation, source-defined simulated expiry, a maximum of one run, and a 180-second monotonic deadline. Exporting preserves evidence after expiry; it does not extend permission. A new mission, a replacement grant, or a server restart requires fresh explicit authorization. Imported objects cannot renew the grant.

Live restoration accepts only an exact bundle issued by the current server session and validated against that separately retained current grant. This also rejects a user-edited Proof with a recomputed ordinary hash. An old export remains useful for inspection; authorize and recompute to establish evidence in a new session. Restoring an artifact never refunds the one-run allowance. The service does not create credentials or persist authentication material. Its fixed request marker is a same-origin request check, not a secret or an authorization token.

Requests are bounded to 256 KiB, reject duplicate and nonfinite JSON values, enforce the displayed loopback Host and same-origin POSTs, and expose only explicit static file routes. The service is a local research demonstration, not a multiuser deployment. It never accepts an arbitrary solver, source path, observer function, or external job destination from the browser.

## Accounting and evidence

The interface displays the engine's actual cost vector and separate timing for the bounded evaluator call including current-authority validation. Server startup, explicit authorization, HTTP serialization, UI rendering, and export are not metered. Instrument units, compute operations, and seconds remain distinct. Human engineering, maintenance, physical validation, and economic prices are unknown here; they are not assigned fabricated monetary values. Static comparisons retain the original run timing and the source-file hash. The hindsight specialist is an explicitly privileged archived reference and cannot be invoked as an implementable demo policy.

The scientific result remains negative on quality: APERTURE and the conventional modular builder each qualify in 54/96 confirmation cases. APERTURE has 40 false acceptances; its model-based check does not guarantee scientific correctness. These counts are computed from the bound published records, not from scenario probabilities.

Focused checks:

```sh
PYTHONDONTWRITEBYTECODE=1 python -m unittest discover -s tests -p test_demo.py -v
```

These tests execute only a bounded development fixture plus local HTTP requests. They test exact restoration, edited authority, forged Proof, expiration, new missions, replacement grants, restart, one-run limits, same-origin rules, source-bound replay, and numerical execution. They do not rerun confirmation. See `demo/validation.json` for what was actually run in the publishing environment, including the browser-inspection status.
