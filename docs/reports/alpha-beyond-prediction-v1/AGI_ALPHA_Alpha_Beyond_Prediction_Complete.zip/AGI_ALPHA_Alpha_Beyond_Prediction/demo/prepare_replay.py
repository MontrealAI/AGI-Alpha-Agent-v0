# SPDX-License-Identifier: Apache-2.0
import argparse, hashlib, json
from datetime import datetime, timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
def main():
    p=argparse.ArgumentParser();p.add_argument('--cases',type=Path,required=True);p.add_argument('--records',type=Path,required=True)
    p.add_argument('--phase',required=True);p.add_argument('--output',type=Path,default=Path(__file__).with_name('replay-data.js'));a=p.parse_args()
    a.cases=a.cases.resolve();a.records=a.records.resolve()
    cases=json.loads(a.cases.read_text());records=json.loads(a.records.read_text());chosen={}
    for case in cases:
        h=case['hidden'];key=(case['public']['family'],h.get('stress',h.get('stress_class','nominal')))
        if key not in chosen and len(chosen)<18:chosen[key]=case
    keep=['method','case_id','family','stress','status','reason','nrmse','scientific_pass','verification_pass','qualified','false_accept','costs','program_hash','input_hash','oracle_privilege','verification_statistic','solver_all_success']
    payload=[]
    for (family,stress),case in chosen.items():
        ident=case['public']['id'];rows=[]
        for row in records:
            if row['case_id']!=ident:continue
            compact={k:row[k] for k in keep if k in row}
            compact['trace_included']=row['method']=='aperture'
            if compact['trace_included']:compact['events']=row.get('events',[])
            rows.append(compact)
        if rows:payload.append({'id':ident,'family':family,'stress':stress,'public':case['public'],'records':rows})
    sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
    value={'schema':'writer11-recorded-demo/v1','mode':'recorded-replay','phase':a.phase,'prepared_at':datetime.now(timezone.utc).isoformat(),
           'source':{'cases_sha256':sha(a.cases),'records_sha256':sha(a.records),'packaged_engine_sha256':sha(ROOT/'src/laboratory.py'),
                     'cases_path':str(a.cases.relative_to(ROOT)) if a.cases.is_relative_to(ROOT) else a.cases.name,
                     'records_path':str(a.records.relative_to(ROOT)) if a.records.is_relative_to(ROOT) else a.records.name},
           'aggregate':{method:{'cases':sum(r['method']==method for r in records),
                                'qualified':sum(r['method']==method and bool(r.get('qualified')) for r in records),
                                'false_accept':sum(r['method']==method and bool(r.get('false_accept')) for r in records)}
                        for method in ('aperture','modular')},
           'cases':payload,'boundary':'Prerecorded evidence only. No Python engine, numerical recomputation, live authority or external action runs in this static view.'}
    a.output.write_text('window.WRITER11_REPLAY = '+json.dumps(value,separators=(',',':'),allow_nan=False)+';\n')
    print(json.dumps({'cases':len(payload),'bytes':a.output.stat().st_size,'phase':a.phase,'output':str(a.output)}))
if __name__=='__main__':main()
