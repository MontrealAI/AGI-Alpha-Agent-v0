# SPDX-License-Identifier: Apache-2.0
from __future__ import annotations
import argparse, copy, hashlib, json, sys, time
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib.parse import urlsplit

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from experiments import evaluate, normalize_case
from laboratory import METHODS, authority_ok, construct, digest, make_authority, restore, snapshot

def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def strict_json(raw: bytes):
    def pairs(items):
        result={}
        for key,value in items:
            if key in result:raise ValueError('Duplicate JSON key')
            result[key]=value
        return result
    return json.loads(raw,object_pairs_hook=pairs,parse_constant=lambda value:(_ for _ in ()).throw(ValueError('Nonfinite JSON value')))

def summary(row: dict) -> dict:
    names=['method','case_id','family','stress','status','reason','nrmse','scientific_pass','verification_pass','qualified','false_accept','costs','program_hash','input_hash','oracle_privilege','verification_statistic']
    return {name:row[name] for name in names if name in row}

class LaboratorySession:
    def __init__(self,cases_path: Path,records_path: Path,phase: str):
        self.cases_path,self.records_path=cases_path,records_path
        cases=strict_json(cases_path.read_bytes());records=strict_json(records_path.read_bytes())
        if not isinstance(cases,list) or not 1<=len(cases)<=256 or not isinstance(records,list) or len(records)>4096:
            raise ValueError('Bounded published case and record arrays required')
        self.cases={c['public']['id']:c for c in cases}
        if len(self.cases)!=len(cases):raise ValueError('Duplicate case identity')
        self.records={}
        for row in records:self.records.setdefault(row['case_id'],[]).append(row)
        self.aggregate={method:{'cases':sum(r['method']==method for r in records),
                               'qualified':sum(r['method']==method and bool(r.get('qualified')) for r in records),
                               'false_accept':sum(r['method']==method and bool(r.get('false_accept')) for r in records)}
                        for method in ('aperture','modular')}
        self.phase=phase
        self.epoch=datetime.now(timezone.utc).isoformat()
        self.source={'laboratory_sha256':sha(ROOT/'src/laboratory.py'),'evaluator_sha256':sha(ROOT/'src/experiments.py'),
                     'cases_sha256':sha(cases_path),'records_sha256':sha(records_path),'cases_path':str(cases_path.relative_to(ROOT)),
                     'records_path':str(records_path.relative_to(ROOT)),'phase':phase,'case_count':len(cases)}
        self.selected=next(iter(self.cases));self.grant=None;self.deadline=0.;self.tick=0
        self.grant_used=False;self.generation=0;self.result=None;self.last_bundle=None;self.exported={};self.history=[]
        self.changed=None

    def public(self):return self.cases[self.selected]['public']

    def state(self):
        active=bool(self.grant and time.monotonic()<self.deadline and self.tick<self.grant['expires'])
        descriptions=[]
        for ident,c in self.cases.items():
            h=normalize_case(c)['hidden'];p=c['public']
            descriptions.append({'id':ident,'family':p['family'],'stress':h.get('stress','nominal'),'likelihood':p['likelihood'],
                                 'actions':len(p['actions']),'dimensions':p['dim'],'budget':p['budget']})
        p=self.public()
        return {'mode':'live-local','selected':self.selected,'cases':descriptions,'public':p,'source':self.source,'aggregate':self.aggregate,
                'authority':{'current':copy.deepcopy(self.grant),'active':active,'used':self.grant_used,'tick':self.tick,
                             'expires_in_seconds':max(0,int(self.deadline-time.monotonic())) if self.grant else 0,
                             'scope':'one bounded local synthetic run; no external actions'},
                'result':self.result,'recorded':[summary(r) for r in self.records.get(self.selected,[])],
                'changed':self.changed,'can_export':self.last_bundle is not None,'history':self.history[-20:]}

    def select(self,ident: str):
        if ident not in self.cases:raise ValueError('Choose a published case')
        before=self.public();after=self.cases[ident]['public']
        self.changed={'from':before['family'],'to':after['family'],'before_likelihood':before['likelihood'],
                      'after_likelihood':after['likelihood'],'before_actions':len(before['actions']),'after_actions':len(after['actions']),
                      'immutable_plan_changed':digest(before)!=digest(after),'new_authority_required':True}
        self.selected=ident;self.grant=None;self.deadline=0.;self.tick=0;self.grant_used=False;self.result=None;self.last_bundle=None
        self.history.append({'event':'demand revealed','mission':ident,'old_authority_carried':False})
        return self.state()

    def reveal(self):
        families=list(dict.fromkeys(c['public']['family'] for c in self.cases.values()))
        current=self.public()['family'];target=families[(families.index(current)+1)%len(families)]
        options=[ident for ident,c in self.cases.items() if c['public']['family']==target]
        chosen=next((ident for ident in options if normalize_case(self.cases[ident])['hidden'].get('stress')=='nominal'),options[0])
        return self.select(chosen)

    def authorize(self,consent):
        if consent is not True:raise ValueError('Explicit consent to this one local synthetic run is required')
        h=normalize_case(self.cases[self.selected])['hidden']
        self.grant=make_authority(self.public(),int(h.get('not_before',0)),int(h.get('expires',128)))
        self.generation+=1
        self.grant.update({'session_epoch':self.epoch,'generation':self.generation,'maximum_runs':1})
        self.deadline=time.monotonic()+180;self.tick=0;self.grant_used=False;self.result=None;self.last_bundle=None
        self.history.append({'event':'explicit local authorization','mission':self.selected,'generation':self.generation})
        return self.state()

    def require_current(self,*,execute=False):
        if self.grant is None:raise ValueError('No current authority. Explicitly authorize this local mission first.')
        if time.monotonic()>=self.deadline:raise ValueError('Current authority expired. Imported evidence cannot renew it.')
        if execute and self.grant_used:raise ValueError('This one-run authority is spent. Authorize a new bounded run explicitly.')
        program=construct(self.public())
        allowed,reason=authority_ok(self.grant,program,max(self.tick,self.grant['not_before']))
        if not allowed:raise ValueError(reason)

    def run(self,method: str):
        wall,cpu=time.perf_counter(),time.process_time()
        if method not in METHODS or method=='hindsight':raise ValueError('Choose an implementable method; hindsight is a recorded reference only')
        self.require_current(execute=True)
        self.grant_used=True
        row=evaluate(copy.deepcopy(self.cases[self.selected]),(method,))[0]
        row['demo_execution']={'mode':'computed now by local Python','utc':datetime.now(timezone.utc).isoformat(),
                               'evaluation_wall_s':time.perf_counter()-wall,'evaluation_cpu_s':time.process_time()-cpu,
                               'timing_boundary':'Authority validation and bounded evaluator call. Server startup, explicit authorization, HTTP serialization, UI rendering and export are not metered.',
                               'source':self.source,'confirmation_rerun':False,
                               'scope':'Interactive reexecution of one published synthetic case; not a new confirmatory sample.'}
        self.tick=max((e.get('tick',0)+1 for e in row['events']),default=0)
        self.result=row
        self.history.append({'event':'bounded run completed','mission':self.selected,'method':method,
                             'acquisition_units':row['costs']['acquisition_units'],'verification_units':row['costs']['verification_units']})
        self.last_bundle=snapshot({'mission':copy.deepcopy(self.public()),'boundary':'published synthetic digital laboratory'},
                                  {'program_hash':digest(self.public()),'method':method},
                                  {'program_hash':digest(self.public()),'record':copy.deepcopy(row),'engine_source_sha256':self.source['laboratory_sha256']},
                                  copy.deepcopy(self.grant))
        self.exported[self.last_bundle['sha256']]=copy.deepcopy(self.last_bundle)
        if len(self.exported)>20:self.exported.pop(next(iter(self.exported)))
        return self.state()

    def export(self):
        if self.last_bundle is None:raise ValueError('Run or restore an artifact before exporting it')
        return copy.deepcopy(self.last_bundle)

    def restore_bundle(self,bundle):
        self.require_current()
        if not isinstance(bundle,dict):raise ValueError('A JSON object is required')
        restored=restore(bundle,self.tick,self.selected,copy.deepcopy(self.grant))
        known=self.exported.get(bundle.get('sha256'))
        if known is None or digest(known)!=digest(bundle):
            raise ValueError('Imported proof is not an exact artifact issued in this live session. Keep it for inspection; authorize and recompute to establish current evidence.')
        if restored['Proof']['engine_source_sha256']!=self.source['laboratory_sha256']:
            raise ValueError('Restored proof belongs to an incompatible engine source')
        self.result=copy.deepcopy(restored['Proof']['record']);self.last_bundle=copy.deepcopy(bundle)
        self.history.append({'event':'exact artifact restored','mission':self.selected,'authority_imported':False})
        return self.state()

    def expire(self):
        if self.grant is None:raise ValueError('No current grant to expire')
        self.deadline=0.;self.tick=self.grant['expires']
        self.history.append({'event':'permission expired','mission':self.selected})
        return self.state()

class DemoHandler(BaseHTTPRequestHandler):
    session: LaboratorySession
    server_version='Writer11Local/1'
    def log_message(self,fmt,*args):pass
    def reply(self,status,data,content_type='application/json; charset=utf-8'):
        raw=json.dumps(data,allow_nan=False,separators=(',',':')).encode() if not isinstance(data,bytes) else data
        self.send_response(status);self.send_header('Content-Type',content_type);self.send_header('Content-Length',str(len(raw)))
        self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Content-Security-Policy',"default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'")
        self.end_headers();self.wfile.write(raw)
    def host_allowed(self):
        return self.headers.get('Host')==f'127.0.0.1:{self.server.server_port}'
    def do_GET(self):
        if not self.host_allowed():self.reply(403,{'error':'Use the displayed loopback address'});return
        path=urlsplit(self.path).path
        try:
            if path=='/api/state':self.reply(200,self.session.state())
            elif path=='/api/export':self.reply(200,self.session.export())
            elif path in ('/','/index.html','/replay-data.js'):
                file=Path(__file__).with_name('replay-data.js' if path.endswith('.js') else 'index.html')
                self.reply(200,file.read_bytes(),'application/javascript; charset=utf-8' if path.endswith('.js') else 'text/html; charset=utf-8')
            else:self.reply(404,{'error':'Unknown local demo route'})
        except (ValueError,KeyError) as exc:self.reply(400,{'error':str(exc)})
    def do_POST(self):
        origin=f'http://127.0.0.1:{self.server.server_port}'
        if not self.host_allowed() or self.headers.get('Origin',origin)!=origin or self.headers.get('X-Writer11-Demo')!='local':
            self.reply(403,{'error':'This endpoint accepts same-origin local demo requests only'});return
        if self.headers.get('Content-Type','').split(';')[0]!='application/json':self.reply(415,{'error':'JSON required'});return
        try:
            length=int(self.headers.get('Content-Length','-1'))
            if not 0<=length<=262144:raise ValueError('Request must be at most 256 KiB')
            body=strict_json(self.rfile.read(length))
            if not isinstance(body,dict):raise ValueError('JSON object required')
            path=urlsplit(self.path).path
            if path=='/api/select':value=self.session.select(body.get('id'))
            elif path=='/api/reveal':value=self.session.reveal()
            elif path=='/api/authorize':value=self.session.authorize(body.get('consent'))
            elif path=='/api/run':value=self.session.run(body.get('method'))
            elif path=='/api/restore':value=self.session.restore_bundle(body.get('bundle'))
            elif path=='/api/expire':value=self.session.expire()
            else:self.reply(404,{'error':'Unknown local demo route'});return
            self.reply(200,value)
        except (ValueError,KeyError,TypeError,OverflowError) as exc:self.reply(400,{'error':str(exc)})
    def do_OPTIONS(self):self.reply(403,{'error':'Cross-origin requests are not enabled'})

def main():
    p=argparse.ArgumentParser();p.add_argument('--port',type=int,default=8765)
    p.add_argument('--cases',type=Path,default=ROOT/'evidence/confirmation/cases.json')
    p.add_argument('--records',type=Path,default=ROOT/'evidence/confirmation/records.json')
    p.add_argument('--phase',default='published-confirmation-reexecution');args=p.parse_args()
    if not 1024<=args.port<=65535:raise ValueError('Use a local port from 1024 to 65535')
    DemoHandler.session=LaboratorySession(args.cases.resolve(),args.records.resolve(),args.phase)
    with HTTPServer(('127.0.0.1',args.port),DemoHandler) as server:
        print(f'Writer #11 local laboratory: http://127.0.0.1:{args.port}/',flush=True)
        print('One explicitly authorized synthetic run at a time. Ctrl+C stops the server.',flush=True)
        try:server.serve_forever()
        except KeyboardInterrupt:pass

if __name__=='__main__':main()
