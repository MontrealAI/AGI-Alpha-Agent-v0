# Beyond the Original Problem
## Transformational Intelligence for Expanding What Is Possible

**Vincent Boucher · MONTREAL.AI · October 19, 2026 · Revised research manuscript**

> Recognize when the original problem formulation is unnecessarily restrictive—and discover a fundamentally different game to play.

This is a substantially revised and retitled edition of *Beyond Task Completion*. The central objective is discovery of better problem formulations that expand purpose-relative attainable outcomes. Eliminating unnecessary work and building reusable capabilities remain important consequences, not the definition of the research program.

## Contents

- `Beyond_the_Original_Problem.pdf`: 24-page manuscript.
- `Beyond_the_Original_Problem.tex`: standalone LaTeX with embedded tables and 25-reference bibliography. No external figure or separately supplied font file is needed.
- `experiments/`: new, exact finite query-design laboratory, constructor, algebraic controls, and a separately implemented checker.
- `results/`: exact outputs, portable contract and capability, and recorded execution reports.
- `tests/`: 45 new test methods, including an exhaustive test over 127 small query families.
- `legacy/`: unmodified sources and tests for the previous finite-controller laboratory, plus reproduced results; 54 retained tests.
- `CLAIMS.md`: what the evidence does and does not support.
- `REVISION_NOTES.md`: substantive changes, critique, and preserved originals.
- `research/`: source notes, execution environment, and internal quality record.
- `MANIFEST.sha256`: integrity hashes, not an authenticity signature or correctness proof.

## Reproduce both studies

The computational project uses only the Python standard library. It was executed with Python 3.13.5. The code uses features available in Python 3.10 and later; other versions have not been qualified in this session. No network, credentials, model provider, payment, or repository write is required.

From this directory:

```sh
python reproduce.py
```

The command checks the package manifest, regenerates both studies, executes both suites, validates both saved artifacts, and checks that the deterministic research outputs remain byte-identical to the supplied records. It does not rebuild the PDF. It prints summaries rather than the full result JSON. Use the individual commands for detailed output:

```sh
python experiments/run_game_study.py
python -m unittest discover -s tests -v
python experiments/check_game_artifact.py results/query_contract.json results/query_capability.json
cd legacy
python experiments/run_study.py
python -m unittest discover -s tests -v
python experiments/check_artifact.py results/capability.json
```

Do not use Python's `-O` switch; the retained study includes assertions used during verification. For research edits, `python reproduce.py --allow-changes` permits changed package hashes and changed deterministic results, while still running the studies, tests, and saved-artifact checks. It is not a verification of the supplied immutable package.

## Build the manuscript

A LaTeX distribution supplying the packages named in the source is required. TeX Live 2025 was used here. From the project directory:

```sh
latexmk -pdf Beyond_the_Original_Problem.tex
```

Alternatively run `pdflatex Beyond_the_Original_Problem.tex` twice. No BibTeX run is required. Building in another environment may produce a byte-different but semantically identical PDF; the manuscript's numerical results are checked through Python, not through PDF byte identity.

## The main result

The investigator supplies a noiseless, eight-bit finite world, seven required parity queries, and a common permitted probe catalogue. Two unnecessary restrictions interact:

| Intermediate target | Coordinate-only measurements | Permitted programmable measurements |
|---|---:|---:|
| Identify the complete world | 8 | 8 |
| Answer every required query | 8 | 3 |

The entries are exact minimum binary-probe counts. Changing either restriction alone leaves the requirement at eight; changing both reduces it to three. At a three-probe budget, optimal coordinate-only full-vector success is 1/8, while a permitted purpose-directed design achieves 1 in the specified uniform noiseless model.

The finite constructor tests 502 candidate probe sets, each against 256 worlds, and returns a three-probe decoder. The separate checker performs 1,792 required-output equalities. An ordinary unrestricted linear-algebra baseline matches the result. Two probes are insufficient; an additional authorized query requires four; changing prices can favor coordinate acquisition; noise invalidates the original certificate.

The retained dynamic study constructs a 16-state controller from a 1,024-state source and verifies the preservation conditions for every finite event sequence in its supplied deterministic model. Its two-state shortcut fails after four events. This study addresses future validity, not a universal savings guarantee.

## Research boundaries

These are finite-model computations and analytic arguments. They are not an LLM benchmark, a new sensing or automata-minimization algorithm, an autonomous natural-world discovery, or a measured runtime, financial, energy, or human-effort gain. The probe-budget comparison excludes the substantial cost of discovering and constructing the protocol. The manuscript states lifecycle and price boundaries separately.

The checkers are separately implemented within the same authored project. They are not external organizational review. A successful run checks the stated computations; it does not establish that the supplied models capture every real obligation, that a physical sensor implements the ideal query, or that a general discovery architecture has been delivered.

All research JSON is inert data. These programs are not a production sandbox or a generic execution adapter. The original *Transformational Intelligence* paper and URL, and the first-edition *Beyond Task Completion* files, were not overwritten. No changes, merges, releases, transactions, or deployments were made in the Alpha repository by this artifact.
