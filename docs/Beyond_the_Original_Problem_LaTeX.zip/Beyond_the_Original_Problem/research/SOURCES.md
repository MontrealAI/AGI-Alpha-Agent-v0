# Primary-source and scope notes

Research date: October 19, 2026. The manuscript's bibliography contains 25 references. Primary research papers, author manuscripts, publisher records, and official documentation were used. This is a targeted literature review, not a systematic search or a proof of scientific priority. No claim that this project is the first to discover task-directed measurement, abstraction, reusable skills, or editable improvement procedures is made.

## Conceptual and mathematical foundations

- Boden (1998), *Creativity and artificial intelligence*: publisher DOI `10.1016/S0004-3702(98)00055-1`. Basis for the distinction between exploring and transforming conceptual spaces.
- Ritchie (2006), *The transformational creativity hypothesis*: publisher DOI `10.1007/BF03037334`, New Generation Computing 24:241–266. Important methodological qualification: the conceptual distinction needs operationalization and evidence.
- Blackwell (1953), *Equivalent comparisons of experiments*: publisher DOI `10.1214/aoms/1177729032`. Prior decision-theoretic grounding for comparisons of information structures; not the source of a claimed new sensing result.
- Knoblock (1994), *Automatically generating abstractions for planning*: author manuscript at `https://usc-isi-i2.github.io/papers/knoblock94-aij.pdf`; Artificial Intelligence 68(2):243–302. Prior automated abstraction rather than an untouched research area.
- Hopcroft (1971), Stanford report CS-TR-71-190. Official report metadata at `https://i.stanford.edu/TR/CS-TR-71-190.html`; accessible original-report copy at `https://www.cs.cmu.edu/~cdm/resources/Hopcroft1971.pdf`. The laboratory uses simple partition refinement, not an implementation claiming Hopcroft's optimized asymptotic complexity.
- Dean and Givan (1997), *Model minimization in Markov decision processes*: author PDF `https://engineering.purdue.edu/~givan/papers/aaai97-2.pdf`. Relevant minimization and behavior-preservation precedent.
- Necula (1997), *Proof-carrying code*: DOI `10.1145/263699.263712`; original-paper copy at `https://homes.cs.washington.edu/~mernst/teaching/6.893/readings/necula-popl97.pdf`. The manuscript cites the separation between production and checkable evidence, not a general security theorem for its own JSON checker. The DOI endpoint was intermittently inaccessible through the browser; the university-hosted primary paper was available.

## Information acquisition: particularly close prior work

- Rainforth et al., *Modern Bayesian Experimental Design*: arXiv `2302.14545`; published Statistical Science 39(1):100–114 (2024), DOI `10.1214/23-STS915`. The open 2023 preprint still says “accepted”; the bibliography records the published journal information rather than treating that old status as current.
- Choudhury et al. (2025), *BED-LLM*: arXiv `2508.21184`. Direct precedent for language-model adaptive information gathering using experimental-design ideas. Its reported performance numbers are not reused as this project's results.
- Rossa, Phillips, and Rainforth (2026), *Action-BED*: arXiv `2606.23662v1`; primary full HTML at `https://arxiv.org/html/2606.23662v1`. Direct precedent for jointly optimizing design and downstream-action policies against task loss. This is why the revised related-work section explicitly disclaims inventing task-directed sensing or the idea of coupling sensing to decisions.
- Hay et al. (2012), *Selecting Computations: Theory and Applications*: arXiv `1207.5879`. Basis for relating investigative choices to metareasoning without assuming an oracle for experiment value.

## Abstraction, programs, and self-improving systems

- Acar, Blume, and Donham (2011), arXiv `1106.0478`: self-adjusting computation and maintained results.
- Ellis et al. (2020), DreamCoder, arXiv `2006.08381`: learned program abstractions and languages.
- Wang et al. (2023), Voyager, arXiv `2305.16291`: executable skill retention.
- Hu, Lu, and Clune (2024), ADAS, arXiv `2408.08435`: automated agent design.
- Jiayi Zhang et al. (2024), AFlow, arXiv `2410.10762`: automated workflow search.
- Agrawal et al. (2025), GEPA, arXiv `2507.19457`: reflective prompt evolution.
- Novikov et al. (2025), AlphaEvolve, arXiv `2506.13131`: model-generated programs and automated algorithmic evaluation.
- Jenny Zhang et al. (2025), Darwin Gödel Machine, arXiv `2505.22954`: empirically evaluated self-modifications. The inspected arXiv record included a March 2026 revision.
- Jenny Zhang et al. (2026), Hyperagents, arXiv `2603.19461`: editable meta-level modification procedures.

These are comparison targets and intellectual precedents. Their existence does not establish that the present project implements their capabilities, outperforms them, or demonstrates a general successor agent.

## Evaluation and implementation context

- Dwork et al. (2014), arXiv `1411.2664`: adaptive-data validity.
- Howard et al. (2021), Annals of Statistics 49(2):1055–1080; arXiv `1810.08240`: time-uniform confidence sequences. No numerical confidence interval is attached to the deterministic finite preservation checks.
- Xie et al. (2024), OSWorld, arXiv `2404.07972`: computer-environment outcome evaluation. No OSWorld score or model trial is reported in this manuscript.
- Google, official OR-Tools constraint-programming documentation: `https://developers.google.com/optimization/cp/`. Proposed natural-task baseline, not an experiment executed here.
- Boucher (2026), *Transformational Intelligence: Learning to Change the Game*: original supplied manuscript and retained public URL. Its contents were read for continuity; no rewrite of that publication or repository write was made.

## Citation boundary

The two exact laboratories, their tables, proofs specialized to those supplied models, failure witnesses, and operation counts are authored computations in this package. They are not extracted numerical results from the cited literature. The synthesis and proposed empirical design are not represented as externally peer reviewed.
