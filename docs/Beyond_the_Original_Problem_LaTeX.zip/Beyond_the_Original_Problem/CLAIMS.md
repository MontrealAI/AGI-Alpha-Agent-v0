# Claim–evidence register

Status: analytic arguments; executed exact finite studies; proposed empirical and implementation program. No external peer review or frontier-model experiment is claimed.

| Claim | Evidence | Limits |
|---|---|---|
| Internal task counts can change without changing required outcomes. | Label-refinement proposition in Section 2. | Internal labels only; not prescribed external obligations. |
| An outcome can require less information than complete world reconstruction. | Target-rank theorem, explicit seven-query family, and executable decoder. | Supplied finite linear noiseless model. The result is classical, not a new information theorem. |
| Two structural changes can be jointly useful when either alone is not. | Exact factorial minima 8, 8, 8, 3. Full reconstruction needs eight binary responses; coordinate-only answers need all coordinates; a permitted basis needs three. | One constructed mechanism; not the prevalence of complementarity in natural tasks. |
| At three probes, the optimal coordinate-only protocol succeeds on the entire answer vector with probability 1/8. | Enumeration of coordinate sets, conditional-rank calculation, and adaptive-policy argument in Appendix A. | Uniform static world, noiseless probes, no additional world-specific information. |
| Three permitted purpose-directed probes achieve exact answers in all 256 worlds. | `results/query_capability.json`; 1,792 output equalities in the separate checker; 8 reachable observations. | Acquisition-probe budget, not a same-total-computation victory. |
| The finite constructor finds an adequate protocol without receiving the winning basis. | Cardinality-ordered table search; 502 candidate sets, 256 candidate worlds each; portable decoder. | The investigator supplies the model, purpose, probe grammar, and search procedure. Not natural-model, instrument, or general AI invention. |
| The checker is separately implemented. | `experiments/verify_game.py` imports no constructor, rank, or scoring routine; validates against a separately passed expected contract. | Same authorship and source assumptions. No external organizational independence. It does not authenticate search history or prove optimality. |
| A strong ordinary method matches the three-probe result. | Algebraic minimum and row-space sufficiency control. | No claimed superiority over standard algebra or unrestricted optimal experimental design. |
| Two probes are insufficient. | Explicit indistinguishable worlds 3 and 4 with different required outputs; information lower bound. | Specified masks and finite model. |
| A new obligation can invalidate a previously sufficient capability. | Added query mask 1, worlds 7 and 8 counterexample, four-probe construction, failed stale binding. | The changed contract requires requalification. |
| A noiseless certificate is not a noisy-model guarantee. | Exact independent-flip calculation: 6859/8000 for three probes; 62618067611/64000000000 for nine-probe repetition. | Assumed independent 1/20 flips. Not a physical measurement or extension of the original certificate. |
| Costs can reverse the preferred protocol. | Complete finite price frontier: min(8, 6+alpha, 4+2alpha, 3alpha) = min(8, 3alpha). | Assumed probe prices. Construction, maintenance, and physical sensor costs are not thereby measured. |
| The dynamic study preserves every required finite output trace in its model. | Complete initial/output/transition map checks plus induction; main 11,265 semantic equalities. | Deterministic supplied model, correct interpretation, complete event/obligation scope. |
| Dynamic state cardinality decreases from 1,024 to 16. | Standard partition refinement and matching domain-aware baseline. | Live state index decreases from ten to four bits. Not a 64-fold total-memory or runtime gain. |
| A two-state current-answer shortcut fails in the dynamic model. | Four-event witness and rejected preservation certificate. | Concrete finite counterexample, not an empirical failure prevalence. |
| The implemented test suites pass. | 45 new and 54 retained unittest methods; recorded logs and fresh extracted-package rerun. | Tests check their specified computations, not all scientific, environmental, or operational assumptions. |
| An AI can learn useful reformulation on unfamiliar natural tasks. | H1–H6 and proposed same-permission, fresh-campaign evaluation design. | Hypothesis; not demonstrated by this package. |
| Discovery policies can improve themselves. | Campaign-level objective and factorial starting-policy/library protocol. | Research target; no measured self-improvement or general transformational intelligence result. |

## Accounting distinctions

An observed gain, evidence for a structural mechanism, a certified bound escape within a specified resource model, and improved autonomous discovery are different claims. This package supports an exact structural probe-budget separation and exact finite preservation statements. It does not support lifecycle-economic superiority or a new frontier-model capability.

A signed or hashed record binds bytes or principals; it does not establish semantic truth, authorization, statistical independence, or honest publication. The expected contract used by the query checker is supplied separately by its caller. It is not accepted merely because the candidate copied a purpose into its own output.
