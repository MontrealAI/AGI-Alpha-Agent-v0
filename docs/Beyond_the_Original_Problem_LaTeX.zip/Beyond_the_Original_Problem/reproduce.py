"""Reproduce the two exact laboratories and verify the supplied artifact package."""
from __future__ import annotations
import argparse
import hashlib
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
OUTPUTS = (
    'results/query_contract.json', 'results/query_capability.json',
    'results/query_verification.json', 'results/game_study.json',
    'legacy/results/capability.json', 'legacy/results/study.json',
    'legacy/results/state_table.tex',
)


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_manifest() -> int:
    manifest = ROOT / 'MANIFEST.sha256'
    if not manifest.is_file():
        raise ValueError('MANIFEST.sha256 is missing')
    count = 0
    seen = set()
    for line in manifest.read_text(encoding='utf-8').splitlines():
        match = re.fullmatch(r'([0-9a-f]{64})  (.+)', line)
        if not match:
            raise ValueError('Malformed manifest line')
        expected, name = match.groups()
        path = (ROOT / name).resolve()
        if not path.is_relative_to(ROOT) or name in seen:
            raise ValueError('Unsafe or duplicate manifest path')
        if not path.is_file() or digest(path) != expected:
            raise ValueError(f'Package hash mismatch: {name}')
        count += 1
        seen.add(name)
    return count


def run(label: str, args: list[str], cwd: Path, expected_tests: int | None = None) -> None:
    result = subprocess.run([sys.executable, *args], cwd=cwd, capture_output=True,
                            text=True, timeout=180, check=False)
    transcript = result.stdout + result.stderr
    if result.returncode:
        raise RuntimeError(f'{label} failed:\n{transcript}')
    if expected_tests is not None:
        matches = re.findall(r'Ran (\d+) tests? in', transcript)
        if not matches or int(matches[-1]) != expected_tests or '\nOK' not in transcript:
            raise RuntimeError(f'{label}: unexpected test summary\n{transcript}')
        print(f'PASS {label}: {expected_tests} tests')
    else:
        print(f'PASS {label}')


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--allow-changes', action='store_true',
                        help='Run edited research without enforcing original hashes or result identity.')
    args = parser.parse_args()
    if not __debug__:
        raise ValueError('Run without -O: the retained study uses verification assertions.')
    if sys.version_info < (3, 10):
        raise ValueError('Python 3.10 or later is required; recorded qualification used 3.13.5.')
    if not args.allow_changes:
        print(f'PASS package integrity: {verify_manifest()} manifest entries')
        before = {name: digest(ROOT / name) for name in OUTPUTS}
    run('new exact query study', ['experiments/run_game_study.py'], ROOT)
    run('new suite', ['-m', 'unittest', 'discover', '-s', 'tests', '-v'], ROOT, 45)
    run('separate query checker', ['experiments/check_game_artifact.py',
        'results/query_contract.json', 'results/query_capability.json'], ROOT)
    run('retained dynamic-state study', ['experiments/run_study.py'], ROOT / 'legacy')
    run('retained suite', ['-m', 'unittest', 'discover', '-s', 'tests', '-v'], ROOT / 'legacy', 54)
    run('separate dynamic-state checker', ['experiments/check_artifact.py',
        'results/capability.json'], ROOT / 'legacy')
    if not args.allow_changes:
        changed = [name for name, expected in before.items() if digest(ROOT / name) != expected]
        if changed:
            raise ValueError(f'Deterministic research outputs changed: {changed}')
        print(f'PASS deterministic output identity: {len(OUTPUTS)} files')
    print('RESULT: 99 tests passed. Exact finite-model claims only; no LLM or natural-workload experiment.')
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (ValueError, OSError, RuntimeError, subprocess.TimeoutExpired) as exc:
        print(f'ERROR: {exc}', file=sys.stderr)
        raise SystemExit(1)
