"""Check a saved capability against a separately selected expected contract."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
from verify_game import check


def _pairs(items: list[tuple]) -> dict:
    result = {}
    for key, value in items:
        if key in result:
            raise ValueError("duplicate JSON key")
        result[key] = value
    return result


def read_json(path: Path) -> dict:
    raw = path.read_bytes()
    if len(raw) > 2_000_000:
        raise ValueError("input exceeds two-megabyte local verification limit")
    value = json.loads(raw.decode("utf-8"), object_pairs_hook=_pairs,
                       parse_constant=lambda _: (_ for _ in ()).throw(ValueError("nonfinite JSON")))
    if type(value) is not dict:
        raise ValueError("top-level JSON object required")
    return value


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("contract", type=Path)
    parser.add_argument("capability", type=Path)
    args = parser.parse_args()
    try:
        result = check(read_json(args.contract), read_json(args.capability))
    except (ValueError, OSError, RecursionError) as exc:
        print(json.dumps({"valid": False, "reason": str(exc)}))
        return 1
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
