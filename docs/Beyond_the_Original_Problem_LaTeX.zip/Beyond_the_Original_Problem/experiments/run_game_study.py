"""Regenerate the deterministic new study and its portable evidence package."""
from __future__ import annotations
from fractions import Fraction
from pathlib import Path
import json
import random
from game_discovery import (make_contract, Contract, find_design, coordinate_frontier,
    all_binary_frontier, rank, minimum_retained_states, unresolved_pair,
    non_dominated_designs, cheapest_design, lifetime_value, algebraic_minimum)
from verify_game import check

ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    output = ROOT / "results"
    output.mkdir(exist_ok=True)
    contract = make_contract()
    capability = find_design(contract)
    validation = check(contract.payload(), capability)
    frontier = coordinate_frontier(contract)
    costs = non_dominated_designs(contract)
    probes = tuple(capability["probes"])
    extra = 1
    revised = Contract(contract.dimension, contract.queries + (extra,), contract.allowed_probes)
    revised_capability = find_design(revised)
    revised_validation = check(revised.payload(), revised_capability)
    relabelings = []
    for seed in range(5):
        rng = random.Random(seed)
        queries, allowed = list(contract.queries), list(contract.allowed_probes)
        rng.shuffle(queries)
        rng.shuffle(allowed)
        shuffled = Contract(contract.dimension, tuple(queries), tuple(allowed))
        result = find_design(shuffled)
        checked = check(shuffled.payload(), result)
        relabelings.append({"seed": seed, "probes": result["probes"],
                           "candidate_sets_evaluated": result["search"]["candidate_sets_evaluated"],
                           "output_equalities_checked": checked["output_equalities_checked"]})
    coordinates = tuple(1 << i for i in range(contract.dimension))
    full_contract = Contract(contract.dimension, coordinates, contract.allowed_probes)
    factorial = {
        "full_world_coordinate": len(algebraic_minimum(full_contract, coordinates)),
        "full_world_programmable": len(algebraic_minimum(full_contract, contract.allowed_probes)),
        "purpose_only_coordinate": len(algebraic_minimum(contract, coordinates)),
        "purpose_only_programmable": len(algebraic_minimum(contract, contract.allowed_probes)),
    }
    noise = Fraction(1, 20)
    majority_error = 3 * noise**2 - 2 * noise**3
    result = {
        "schema": "better-games-study/v2", "classification": "exact synthetic finite computation; no LLM calls",
        "main": {"dimension": contract.dimension, "queries": list(contract.queries),
                 "target_rank": rank(contract.queries), "allowed_probe_count": len(contract.allowed_probes),
                 "minimum_retained_states": minimum_retained_states(contract),
                 "selected_probes": capability["probes"], "search": capability["search"],
                 "validation": validation},
        "factorial_exact_probe_minima": factorial,
        "coordinate_frontier": frontier,
        "unrestricted_binary_frontier": all_binary_frontier(8, 3),
        "two_probe_counterexample": unresolved_pair(contract, probes[:2]),
        "new_obligation_counterexample": unresolved_pair(contract, probes, extra),
        "new_obligation": {"added_query": extra, "probe_count": len(revised_capability["probes"]),
                           "retained_states": minimum_retained_states(revised), "validation": revised_validation},
        "probe_price_frontier": costs,
        "price_choices": [cheapest_design(costs, Fraction(p)) for p in (1, 2, 3, 4)],
        "noise_sensitivity": {"independent_flip_probability": str(noise),
                             "three_probe_all_answers_success": str((1-noise)**3),
                             "nine_probe_majority_all_answers_success": str((1-majority_error)**3),
                             "warning": "noiseless certificate does not apply to these different noise models"},
        "identifier_order_checks": relabelings,
        "lifetime_illustrations": [{"horizon": h, "survival": str(p),
                    "net_value": str(lifetime_value(Fraction(120), Fraction(3), p, h))}
                    for h in (10, 50, 100, 500) for p in (Fraction(1), Fraction(99, 100), Fraction(9, 10))]
    }
    for name, item in (("query_contract.json", contract.payload()), ("query_capability.json", capability),
                       ("query_verification.json", validation), ("game_study.json", result)):
        (output / name).write_text(json.dumps(item, indent=2, sort_keys=True) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
