"""Exact finite experiment-design laboratory; no models, networks, or deployment.

The constructor searches supplied finite probe sets. It is not a general
transformational AI. All operation counts are logical counts, not currency.
"""
from __future__ import annotations
from collections import Counter, defaultdict
from dataclasses import dataclass
from fractions import Fraction
from hashlib import sha256
from itertools import combinations
import json
from typing import Iterable


def canonical(value: object) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode()


def fingerprint(value: object) -> str:
    return sha256(canonical(value)).hexdigest()


def exact_int(value: object, lower: int, upper: int, name: str) -> int:
    if type(value) is not int or not lower <= value <= upper:
        raise ValueError(f"{name} must be an exact integer in [{lower}, {upper}]")
    return value


def parity(world: int, mask: int) -> int:
    return (world & mask).bit_count() & 1


def signature(world: int, masks: Iterable[int]) -> int:
    return sum(parity(world, mask) << i for i, mask in enumerate(masks))


def span(masks: Iterable[int]) -> frozenset[int]:
    values = {0}
    for mask in masks:
        values |= {value ^ mask for value in tuple(values)}
    return frozenset(values)


def rank(masks: Iterable[int]) -> int:
    pivots: dict[int, int] = {}
    for mask in masks:
        value = mask
        while value:
            bit = value.bit_length() - 1
            if bit in pivots:
                value ^= pivots[bit]
            else:
                pivots[bit] = value
                break
    return len(pivots)


@dataclass(frozen=True)
class Contract:
    dimension: int
    queries: tuple[int, ...]
    allowed_probes: tuple[int, ...]

    def __post_init__(self) -> None:
        exact_int(self.dimension, 1, 10, "dimension")
        maximum = (1 << self.dimension) - 1
        for name, values in (("queries", self.queries), ("allowed_probes", self.allowed_probes)):
            if type(values) is not tuple or not values or len(values) > 20:
                raise ValueError(f"{name} must contain 1 to 20 masks in a tuple")
            for value in values:
                exact_int(value, 1, maximum, name)
            if len(values) != len(set(values)):
                raise ValueError(f"duplicate {name}")

    def payload(self) -> dict:
        return {"schema": "purpose-query-contract/v1", "dimension": self.dimension,
                "queries": list(self.queries), "allowed_probes": list(self.allowed_probes),
                "world_model": "uniform-static-binary-noiseless/v1",
                "required_output": "all-requested-parities-exactly"}

    @property
    def digest(self) -> str:
        return fingerprint(self.payload())


def make_contract(dimension: int = 8, basis: tuple[int, ...] = (255, 85, 51)) -> Contract:
    maximum = (1 << dimension) - 1
    for mask in basis:
        exact_int(mask, 1, maximum, "basis mask")
    queries = tuple(sorted(span(basis) - {0}))
    allowed = tuple(sorted(set(queries) | {1 << i for i in range(dimension)}))
    return Contract(dimension, queries, allowed)


def validate_probes(contract: Contract, probes: tuple[int, ...]) -> None:
    if type(probes) is not tuple or len(probes) != len(set(probes)):
        raise ValueError("probe sequence must be a tuple without repetitions")
    for probe in probes:
        exact_int(probe, 1, (1 << contract.dimension) - 1, "probe")
        if probe not in contract.allowed_probes:
            raise ValueError("probe outside the separately supplied contract")


def outcome_groups(contract: Contract, probes: tuple[int, ...]) -> dict[int, Counter]:
    validate_probes(contract, probes)
    groups: dict[int, Counter] = defaultdict(Counter)
    for world in range(1 << contract.dimension):
        groups[signature(world, probes)][signature(world, contract.queries)] += 1
    return dict(groups)


def sufficient_decoder(contract: Contract, probes: tuple[int, ...]) -> dict[int, int] | None:
    groups = outcome_groups(contract, probes)
    if any(len(counts) != 1 for counts in groups.values()):
        return None
    return {key: next(iter(counts)) for key, counts in groups.items()}


def optimal_success(contract: Contract, probes: tuple[int, ...]) -> Fraction:
    """Bayes-optimal full-output-vector success for a fixed probe set, uniform worlds."""
    return Fraction(sum(max(counts.values()) for counts in outcome_groups(contract, probes).values()),
                    1 << contract.dimension)


def find_design(contract: Contract, candidates: tuple[int, ...] | None = None) -> dict:
    """Exhaustive cardinality search; no rank or latent-basis annotation is used."""
    candidates = contract.allowed_probes if candidates is None else candidates
    validate_probes(contract, candidates)
    tried = 0
    for size in range(len(candidates) + 1):
        for probes in combinations(candidates, size):
            tried += 1
            decoder = sufficient_decoder(contract, probes)
            if decoder is not None:
                return {"schema": "purpose-query-capability/v1", "contract_digest": contract.digest,
                        "probes": list(probes),
                        "decoder": {str(key): value for key, value in sorted(decoder.items())},
                        "search": {"candidate_sets_evaluated": tried,
                                   "worlds_per_candidate": 1 << contract.dimension,
                                   "algorithm": "finite-enumeration-by-cardinality/v1"}}
    raise ValueError("no exact design exists in the supplied probe class")


def coordinate_frontier(contract: Contract) -> list[dict]:
    coordinates = tuple(1 << i for i in range(contract.dimension))
    if not set(coordinates) <= set(contract.allowed_probes):
        raise ValueError("coordinate frontier requires all coordinate probes")
    rows = []
    for budget in range(contract.dimension + 1):
        best = Fraction(-1)
        winner: tuple[int, ...] = ()
        for probes in combinations(coordinates, budget):
            score = optimal_success(contract, probes)
            if score > best:
                best, winner = score, probes
        rows.append({"budget": budget, "success": str(best), "probes": list(winner)})
    return rows


def all_binary_frontier(dimension: int, target_rank: int) -> list[dict]:
    exact_int(dimension, 1, 10, "dimension")
    exact_int(target_rank, 1, dimension, "target_rank")
    return [{"budget": k, "success": str(min(Fraction(1), Fraction(2**k, 2**target_rank)))}
            for k in range(dimension + 1)]


def unresolved_pair(contract: Contract, probes: tuple[int, ...], extra_query: int | None = None) -> dict | None:
    validate_probes(contract, probes)
    targets = contract.queries if extra_query is None else (exact_int(extra_query, 1,
              (1 << contract.dimension) - 1, "extra query"),)
    seen: dict[int, tuple[int, int]] = {}
    for world in range(1 << contract.dimension):
        observed, desired = signature(world, probes), signature(world, targets)
        if observed in seen and seen[observed][1] != desired:
            earlier, output = seen[observed]
            return {"worlds": [earlier, world], "same_observation": observed,
                    "different_outputs": [output, desired], "targets": list(targets)}
        seen.setdefault(observed, (world, desired))
    return None


def minimum_retained_states(contract: Contract) -> int:
    return len({signature(world, contract.queries) for world in range(1 << contract.dimension)})


def non_dominated_designs(contract: Contract) -> list[dict]:
    """Exact two-price frontier for coordinate versus noncoordinate probes.

    Uses ordinary linear algebra as a separate strong design algorithm. It is
    not the table-enumeration constructor and is not claimed to be novel.
    """
    if len(contract.allowed_probes) > 16:
        raise ValueError("cost enumeration limited to at most 16 allowed probes")
    targets = rank(contract.queries)
    feasible: dict[tuple[int, int], tuple[int, ...]] = {}
    for size in range(len(contract.allowed_probes) + 1):
        for probes in combinations(contract.allowed_probes, size):
            coordinate_count = sum(probe & (probe - 1) == 0 for probe in probes)
            pair = (coordinate_count, size - coordinate_count)
            if pair in feasible:
                continue
            if any(c <= pair[0] and p <= pair[1] for c, p in feasible):
                continue
            if rank(probes) == rank(probes + contract.queries):
                feasible[pair] = probes
    nondominated = [(pair, probes) for pair, probes in feasible.items()
                    if not any(other != pair and other[0] <= pair[0] and other[1] <= pair[1]
                               for other in feasible)]
    return [{"coordinate_probes": pair[0], "programmable_probes": pair[1], "probes": list(probes)}
            for pair, probes in sorted(nondominated)]


def cheapest_design(frontier: list[dict], programmable_price: Fraction) -> dict:
    if not isinstance(programmable_price, Fraction) or programmable_price <= 0:
        raise ValueError("programmable_price must be a positive Fraction")
    choice = min(frontier, key=lambda row: (Fraction(row["coordinate_probes"]) +
               programmable_price * row["programmable_probes"], len(row["probes"]), row["probes"]))
    return {**choice, "programmable_price": str(programmable_price),
            "total_probe_price": str(Fraction(choice["coordinate_probes"]) +
                                     programmable_price * choice["programmable_probes"])}


def lifetime_value(setup: Fraction, per_use_gain: Fraction, survival: Fraction, horizon: int) -> Fraction:
    if any(not isinstance(x, Fraction) for x in (setup, per_use_gain, survival)):
        raise ValueError("cost values must be Fractions")
    if setup < 0 or per_use_gain < 0 or not 0 <= survival <= 1:
        raise ValueError("invalid lifecycle assumptions")
    exact_int(horizon, 0, 10000, "horizon")
    return -setup + per_use_gain * sum((survival**t for t in range(horizon)), Fraction())


def algebraic_minimum(contract: Contract, candidates: tuple[int, ...]) -> tuple[int, ...]:
    """Strong ordinary linear-algebra control over the complete supplied probe class."""
    validate_probes(contract, candidates)
    for size in range(len(candidates) + 1):
        for probes in combinations(candidates, size):
            if rank(probes) == rank(probes + contract.queries):
                return probes
    raise ValueError("insufficient allowed experiment class")
