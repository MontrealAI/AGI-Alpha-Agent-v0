"""Separate exhaustive checker for the finite purpose-query capability.

This implementation does not import the constructor, its rank calculation, or
its scoring functions. The caller supplies the expected contract separately.
"""
from __future__ import annotations
import hashlib
import json
from typing import Any


def _integer(value: Any, minimum: int, maximum: int) -> int:
    if type(value) is not int or not minimum <= value <= maximum:
        raise ValueError("invalid exact integer")
    return value


def _parity(value: int, mask: int, dimension: int) -> int:
    total = 0
    for position in range(dimension):
        total += ((value >> position) & 1) * ((mask >> position) & 1)
    return total % 2


def check(contract: dict, capability: dict) -> dict:
    if type(contract) is not dict or type(capability) is not dict:
        raise ValueError("plain object required")
    if set(contract) != {"schema", "dimension", "queries", "allowed_probes", "world_model", "required_output"}:
        raise ValueError("unknown or missing contract field")
    if contract["schema"] != "purpose-query-contract/v1" or contract["world_model"] != "uniform-static-binary-noiseless/v1":
        raise ValueError("unsupported contract or world model")
    if contract["required_output"] != "all-requested-parities-exactly":
        raise ValueError("unsupported output contract")
    dimension = _integer(contract["dimension"], 1, 10)
    maximum = (1 << dimension) - 1
    for key in ("queries", "allowed_probes"):
        masks = contract[key]
        if type(masks) is not list or not 1 <= len(masks) <= 20:
            raise ValueError("invalid mask array")
        for mask in masks:
            _integer(mask, 1, maximum)
        if len(set(masks)) != len(masks):
            raise ValueError("duplicate contract mask")
    expected_fields = {"schema", "contract_digest", "probes", "decoder", "search"}
    if set(capability) != expected_fields or capability["schema"] != "purpose-query-capability/v1":
        raise ValueError("unknown or missing capability field")
    binding = hashlib.sha256(json.dumps(contract, sort_keys=True, separators=(",", ":"),
                                       ensure_ascii=True).encode()).hexdigest()
    if capability["contract_digest"] != binding:
        raise ValueError("contract binding mismatch")
    probes = capability["probes"]
    if type(probes) is not list or len(probes) > 10:
        raise ValueError("invalid probe array")
    for probe in probes:
        _integer(probe, 1, maximum)
        if probe not in contract["allowed_probes"]:
            raise ValueError("unpermitted probe")
    if len(probes) != len(set(probes)):
        raise ValueError("duplicate probe")
    decoder = capability["decoder"]
    if type(decoder) is not dict or not decoder or len(decoder) > 1024:
        raise ValueError("invalid decoder")
    for key, value in decoder.items():
        if type(key) is not str or not key.isascii() or not key.isdecimal() or str(int(key)) != key:
            raise ValueError("noncanonical observation key")
        _integer(int(key), 0, (1 << len(probes)) - 1)
        _integer(value, 0, (1 << len(contract["queries"])) - 1)
    metadata = capability["search"]
    if type(metadata) is not dict or set(metadata) != {"candidate_sets_evaluated", "worlds_per_candidate", "algorithm"}:
        raise ValueError("invalid search metadata")
    _integer(metadata["candidate_sets_evaluated"], 1, 1 << 20)
    if metadata["worlds_per_candidate"] != 1 << dimension or type(metadata["worlds_per_candidate"]) is not int:
        raise ValueError("invalid world-count metadata")
    if metadata["algorithm"] != "finite-enumeration-by-cardinality/v1":
        raise ValueError("unsupported producer metadata")
    observations = set()
    assertions = 0
    for world in range(1 << dimension):
        observed = sum(_parity(world, probe, dimension) << i for i, probe in enumerate(probes))
        observations.add(str(observed))
        if str(observed) not in decoder:
            raise ValueError("missing reachable observation")
        answer = decoder[str(observed)]
        for i, query in enumerate(contract["queries"]):
            assertions += 1
            if ((answer >> i) & 1) != _parity(world, query, dimension):
                raise ValueError(f"outcome mismatch at world {world}, query index {i}")
    if set(decoder) != observations:
        raise ValueError("unreachable extra decoder row")
    return {"valid": True, "worlds_checked": 1 << dimension,
            "output_equalities_checked": assertions, "reachable_observations": len(observations),
            "probe_count": len(probes), "scope": "supplied-static-noiseless-finite-contract-only",
            "optimality_checked": False, "search_history_authenticated": False}
