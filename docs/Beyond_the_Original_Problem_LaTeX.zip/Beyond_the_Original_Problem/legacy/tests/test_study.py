from __future__ import annotations
import copy
import json
from fractions import Fraction
from pathlib import Path
import random
import sys
import unittest
sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'experiments'))
from obligation_machine import (Machine, make_monitor, construct, explicit_projection,
    representative_quotient, future_witness, distinguishable_pairs, retained_value, contract_guard)
from verify_certificate import verify

class CoreTests(unittest.TestCase):
    def test_projection_certificate(self):
        m,meta=make_monitor(3,3); q,c=explicit_projection(m,meta)
        self.assertTrue(verify(m.as_dict(),q.as_dict(),c)['valid'])
    def test_current_output_merge_rejected(self):
        m,_=make_monitor(4,2); q,p=representative_quotient(m,m.output)
        c={'schema':'obligation-quotient-certificate/v1','source_sha256':m.fingerprint(),
           'target_sha256':q.fingerprint(),'map':list(p)}
        with self.assertRaises(ValueError): verify(m.as_dict(),q.as_dict(),c)
    def test_future_counterexample(self):
        m,_=make_monitor(4,2);q,_=representative_quotient(m,m.output)
        w=future_witness(m,q);self.assertEqual(len(w),4);self.assertNotEqual(m.run(w),q.run(w))
    def test_full_obligation_retains_states(self):
        m,_=make_monitor(3,3,contract='full-state');q,c,_=construct(m)
        self.assertEqual(q.n,m.n);verify(m.as_dict(),q.as_dict(),c)
    def test_contract_change_increases_memory(self):
        a,_=make_monitor(3,3);b,_=make_monitor(3,3,contract='ready-and-audit-bit')
        self.assertEqual(construct(a)[0].n*2,construct(b)[0].n)
    def test_guard_refuses_changed_contract(self):
        a,_=make_monitor(3,3);b,_=make_monitor(3,3,contract='ready-and-audit-bit')
        with self.assertRaises(ValueError): contract_guard(a.fingerprint(),b)
    def test_guard_preserves_valid_context(self):
        a,_=make_monitor(3,3);contract_guard(a.fingerprint(),a)
    def test_idempotent_minimization(self):
        m,_=make_monitor(3,3);q,_,_=construct(m);v,_,_=construct(q)
        self.assertEqual(q.as_dict(),v.as_dict())
    def test_replay_count_is_not_task_count(self):
        m,_=make_monitor(2,2);q,_,_=construct(m)
        self.assertEqual(len(q.run([0,1,2,3])),5)
    def test_zero_horizon(self): self.assertEqual(retained_value(120,3,Fraction(1),0),-120)
    def test_long_horizon(self): self.assertEqual(retained_value(120,3,Fraction(1),100),180)
    def test_short_horizon_loss(self): self.assertEqual(retained_value(120,3,Fraction(1),10),-90)
    def test_tie_not_positive(self): self.assertEqual(retained_value(120,3,Fraction(1),40),0)
    def test_no_survival(self): self.assertEqual(retained_value(120,3,Fraction(0),100),-117)
    def test_unfavorable_drift(self): self.assertLess(retained_value(120,3,Fraction(9,10),1000),0)
    def test_geometric_closed_form(self):
        p=Fraction(99,100);h=25
        self.assertEqual(retained_value(120,3,p,h),-120+3*(1-p**h)/(1-p))
    def test_negative_horizon(self):
        with self.assertRaises(ValueError): retained_value(120,3,Fraction(1),-1)
    def test_bad_survival(self):
        with self.assertRaises(ValueError): retained_value(120,3,Fraction(11,10),10)
    def test_bad_dimensions(self):
        with self.assertRaises(ValueError): make_monitor(0,0)
    def test_large_dimensions(self):
        with self.assertRaises(ValueError): make_monitor(13,0)
    def test_unknown_contract(self):
        with self.assertRaises(ValueError): make_monitor(1,1,contract='unapproved')
    def test_bad_event(self):
        m,_=make_monitor(2,2)
        with self.assertRaises(ValueError): m.run([4])
    def test_bool_event_not_int(self):
        m,_=make_monitor(2,2)
        with self.assertRaises(ValueError): m.run([True])
    def test_missing_event_is_detectable(self):
        m,_=make_monitor(2,2);q,_,_=construct(m)
        self.assertNotEqual(len(m.run([0,1,2])),len(q.run([0,1])))
    def test_portable_roundtrip(self):
        m,_=make_monitor(2,2);q,c,_=construct(m)
        data=json.loads(json.dumps({'s':m.as_dict(),'t':q.as_dict(),'c':c}))
        verify(data['s'],data['t'],data['c'])

for r,n in [(1,0),(1,3),(2,0),(2,2),(3,0),(3,3),(4,0),(4,3),(4,6),(5,2),(5,5),(6,4)]:
    def case(self,r=r,n=n):
        m,meta=make_monitor(r,n,seed=31);q,c,_=construct(m)
        verify(m.as_dict(),q.as_dict(),c)
        self.assertEqual(q.n,2**r)
        self.assertEqual(distinguishable_pairs(q),q.n*(q.n-1)//2)
        self.assertIsNone(future_witness(m,q))
        rng=random.Random(77)
        events=[rng.randrange(m.a) for _ in range(75)]
        self.assertEqual(m.run(events),q.run(events))
    setattr(CoreTests,f'test_exact_{r}_{n}',case)

mutations = {
    'source_hash':lambda s,t,c:c.update(source_sha256='0'*64),
    'target_hash':lambda s,t,c:c.update(target_sha256='0'*64),
    'schema':lambda s,t,c:c.update(schema='invented'),
    'map_bool':lambda s,t,c:c['map'].__setitem__(0,True),
    'map_short':lambda s,t,c:c['map'].pop(),
    'map_range':lambda s,t,c:c['map'].__setitem__(0,9999),
    'target_output':lambda s,t,c:t['output'].__setitem__(0,99),
    'source_edge':lambda s,t,c:s['transition'][0].__setitem__(0,9999),
    'target_extra':lambda s,t,c:t.update(authorization=True),
    'cert_extra':lambda s,t,c:c.update(permissions='all'),
    'source_initial':lambda s,t,c:s.update(initial=-1),
    'target_bool_output':lambda s,t,c:t['output'].__setitem__(0,True),
}
for name, mutate in mutations.items():
    def case(self,mutate=mutate):
        m,_=make_monitor(2,2);q,c,_=construct(m);s,t=m.as_dict(),q.as_dict()
        mutate(s,t,c)
        with self.assertRaises(ValueError): verify(s,t,c)
    setattr(CoreTests,'test_reject_'+name,case)

if __name__=='__main__': unittest.main()
