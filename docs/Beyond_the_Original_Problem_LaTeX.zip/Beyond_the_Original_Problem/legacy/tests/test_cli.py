from __future__ import annotations
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'experiments'))
from obligation_machine import make_monitor, construct

class ArtifactCLITests(unittest.TestCase):
    def invoke(self, text, events='0,1,2,3'):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'artifact.json'; path.write_text(text)
            return subprocess.run([sys.executable, str(ROOT/'experiments/check_artifact.py'),
                                   str(path), '--events', events], capture_output=True, text=True, timeout=10)
    def package(self):
        source,_=make_monitor(2,2); target, certificate,_=construct(source)
        return {'source':source.as_dict(),'target':target.as_dict(),'certificate':certificate,
                'generator':{},'research_scope':'test-only'}
    def test_accepted_roundtrip(self):
        result=self.invoke(json.dumps(self.package())); self.assertEqual(result.returncode,0,result.stderr)
        value=json.loads(result.stdout)
        self.assertTrue(value['valid']); self.assertFalse(value['external_authority_granted'])
        self.assertEqual(value['source_outputs'], value['target_outputs'])
    def test_tampered_artifact(self):
        data=self.package(); data['certificate']['map'][0]=9999
        self.assertEqual(self.invoke(json.dumps(data)).returncode,2)
    def test_duplicate_fields(self):
        self.assertEqual(self.invoke('{"source":{},"source":{}}').returncode,2)
    def test_input_budget(self):
        self.assertEqual(self.invoke(' '*2_000_001).returncode,2)
    def test_event_bounds(self):
        self.assertEqual(self.invoke(json.dumps(self.package()),'0,99999').returncode,2)

if __name__ == '__main__': unittest.main()
