"""Verify a bounded local JSON capability without executing imported code."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import sys
from obligation_machine import Machine
from verify_certificate import verify

MAX_BYTES = 2_000_000
MAX_REPLAY = 10_000

def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f'duplicate JSON field: {key}')
        result[key] = value
    return result

def load_artifact(path: Path):
    with path.open('rb') as stream:
        raw = stream.read(MAX_BYTES + 1)
    if len(raw) > MAX_BYTES:
        raise ValueError('artifact exceeds two-megabyte input budget')
    data = json.loads(raw.decode('utf-8'), object_pairs_hook=unique_object,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError('nonfinite JSON value')))
    expected = {'source', 'target', 'certificate', 'generator', 'research_scope'}
    if type(data) is not dict or set(data) != expected:
        raise ValueError('unexpected artifact fields')
    result = verify(data['source'], data['target'], data['certificate'])
    return data, result

def as_machine(value):
    return Machine(tuple(tuple(row) for row in value['transition']),
                   tuple(value['output']), value['initial'])

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('artifact', type=Path)
    parser.add_argument('--events', default='0,1,4,7', help='comma-separated event IDs; default is the main-study witness')
    args = parser.parse_args()
    try:
        data, result = load_artifact(args.artifact)
        raw_events = args.events.split(',') if args.events.strip() else []
        if len(raw_events) > MAX_REPLAY:
            raise ValueError('replay event budget exceeded')
        events = [int(event.strip()) for event in raw_events]
        source, target = as_machine(data['source']), as_machine(data['target'])
        before, after = source.run(events), target.run(events)
        if before != after:
            raise ValueError('replay disagrees despite certificate; investigate implementation')
        result.update(source_states=source.n, target_states=target.n,
                      replay_events=events, source_outputs=before, target_outputs=after,
                      external_authority_granted=False)
        print(json.dumps(result, indent=2, sort_keys=True))
        return 0
    except (OSError, UnicodeError, ValueError, TypeError, KeyError, RecursionError) as exc:
        print(f'Artifact rejected: {exc}', file=sys.stderr)
        return 2

if __name__ == '__main__':
    raise SystemExit(main())
