"""Separate certificate checker: no call into the partition-refinement constructor."""
from __future__ import annotations
import hashlib
import json


def _digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def _valid_machine(data):
    if type(data) is not dict or set(data) != {'transition','output','initial'}:
        raise ValueError('bad machine fields')
    output, edges, initial = data['output'], data['transition'], data['initial']
    if type(output) is not list or not 1 <= len(output) <= 4096 or type(edges) is not list:
        raise ValueError('bad dimensions')
    n = len(output)
    if len(edges) != n or type(initial) is not int or not 0 <= initial < n:
        raise ValueError('bad initial state or edge count')
    if any(type(x) is not int or x < 0 for x in output): raise ValueError('bad output')
    if type(edges[0]) is not list or not 1 <= len(edges[0]) <= 16: raise ValueError('bad alphabet')
    a = len(edges[0])
    for row in edges:
        if type(row) is not list or len(row) != a or any(type(s) is not int or not 0 <= s < n for s in row):
            raise ValueError('bad transition')
    return n, a


def verify(source, target, certificate):
    ns, a = _valid_machine(source); nt, b = _valid_machine(target)
    if a != b: raise ValueError('event alphabet changed')
    required = {'schema','source_sha256','target_sha256','map'}
    if type(certificate) is not dict or set(certificate) != required:
        raise ValueError('bad certificate fields')
    if certificate['schema'] != 'obligation-quotient-certificate/v1': raise ValueError('unknown schema')
    if certificate['source_sha256'] != _digest(source) or certificate['target_sha256'] != _digest(target):
        raise ValueError('digest mismatch')
    phi = certificate['map']
    if type(phi) is not list or len(phi) != ns or any(type(i) is not int or not 0 <= i < nt for i in phi):
        raise ValueError('invalid total map')
    if set(phi) != set(range(nt)): raise ValueError('non-surjective certificate')
    if phi[source['initial']] != target['initial']: raise ValueError('initial-state mismatch')
    for s in range(ns):
        if source['output'][s] != target['output'][phi[s]]:
            raise ValueError(f'output mismatch at state {s}')
        for e in range(a):
            if phi[source['transition'][s][e]] != target['transition'][phi[s]][e]:
                raise ValueError(f'future-obligation mismatch at state {s}, event {e}')
    return {'valid': True, 'checked_outputs': ns, 'checked_edges': ns * a,
            'checked_initial_states': 1, 'scope': 'exact supplied deterministic model, all finite words'}
