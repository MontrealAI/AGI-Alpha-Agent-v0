"""Reproduce the paper's finite-model results and portable capability artifact."""
from __future__ import annotations
from fractions import Fraction
from pathlib import Path
import json
import random
from obligation_machine import (make_monitor, construct, explicit_projection,
    representative_quotient, future_witness, distinguishable_pairs, retained_value)
from verify_certificate import verify

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'results'


def write(name, value):
    OUT.mkdir(exist_ok=True)
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def run():
    rows, all_checks, replay_outputs = [], 0, 0
    specs = [(1,0),(2,2),(3,3),(4,0),(4,4),(4,6),(5,5),(6,4)]
    for r, n in specs:
        copies = []
        for seed in range(5):
            raw, metadata = make_monitor(r, n, seed=seed)
            reduced, cert, ledger = construct(raw)
            checked = verify(raw.as_dict(), reduced.as_dict(), cert)
            engineered, engineered_cert = explicit_projection(raw, metadata)
            verify(raw.as_dict(), engineered.as_dict(), engineered_cert)
            assert reduced.n == engineered.n == 2**r
            assert distinguishable_pairs(reduced) == reduced.n * (reduced.n-1)//2
            assert future_witness(raw, reduced) is None
            rng = random.Random(10000 + seed)
            events = [rng.randrange(raw.a) for _ in range(1000)]
            assert raw.run(events) == reduced.run(events) == engineered.run(events)
            replay_outputs += len(events) + 1
            all_checks += checked['checked_outputs'] + checked['checked_edges'] + 1
            copies.append({'seed':seed,'states':reduced.n,'source_sha256':raw.fingerprint(),
                           'target_sha256':reduced.fingerprint(), 'certificate_checks':checked})
        self_edges = sum(t == s for s, row in enumerate(reduced.transition) for t in row)
        rows.append({'required_bits':r, 'nuisance_bits':n, 'source_states':raw.n,
            'target_states':reduced.n, 'source_edges':raw.n*raw.a,'target_edges':reduced.n*reduced.a,
            'working_state_bits_before':r+n,'working_state_bits_after':r,
            'state_cardinality_ratio':raw.n//reduced.n, 'self_loop_fraction':str(Fraction(self_edges,reduced.n*reduced.a)),
            'five_relabelings':copies})
    raw, metadata = make_monitor(4,6,seed=17)
    reduced, cert, ledger = construct(raw)
    checked = verify(raw.as_dict(), reduced.as_dict(),cert)
    unsafe, unsafe_map = representative_quotient(raw, raw.output)
    bad_word = future_witness(raw,unsafe)
    assert bad_word is not None
    full, _ = make_monitor(4,6,seed=17,contract='full-state')
    full_reduced, full_cert, _ = construct(full)
    verify(full.as_dict(),full_reduced.as_dict(),full_cert)
    assert full_reduced.n == full.n == 1024
    changed, _ = make_monitor(4,6,seed=17,contract='ready-and-audit-bit')
    changed_reduced, changed_cert, _ = construct(changed)
    verify(changed.as_dict(),changed_reduced.as_dict(),changed_cert)
    assert changed_reduced.n == 32
    try: verify(changed.as_dict(),reduced.as_dict(),cert)
    except ValueError: stale_rejected=True
    else: raise AssertionError('stale certificate accepted')
    main_rng = random.Random(771)
    word = [main_rng.randrange(raw.a) for _ in range(10000)]
    assert raw.run(word)==reduced.run(word)
    mutations = sum(metadata['event_bits'][e] >= 4 for e in word)
    artifact = {'source':raw.as_dict(),'target':reduced.as_dict(),'certificate':cert,
        'generator':{'required':4,'nuisance':6,'seed':17,'contract':'ready'},
        'research_scope':'Finite deterministic model only; no live permissions or provider calls.'}
    write('capability.json',artifact)
    controls = {'unsafe_current_output_states':unsafe.n, 'shortest_witness':list(bad_word),
        'witness_length':len(bad_word), 'source_witness_outputs':list(raw.run(bad_word)),
        'unsafe_witness_outputs':list(unsafe.run(bad_word)),
        'full_obligation_source_states':full.n,'full_obligation_target_states':full_reduced.n,
        'changed_contract_target_states':changed_reduced.n,'stale_certificate_rejected':stale_rejected}
    costs=[]
    # Illustrative accounting parameters, deliberately not labeled measured dollars or operations.
    for p in (Fraction(1),Fraction(99,100),Fraction(9,10)):
        for h in (10,50,100,500):
            value=retained_value(120,3,p,h)
            costs.append({'setup_units_assumed':120,'saving_units_per_valid_use_assumed':3,
                          'survival_probability_assumed':str(p),'horizon':h,
                          'net_value_exact':str(value),'net_value_decimal':float(value),
                          'construct_under_this_model':value>0})
    study = {'schema':'beyond-task-completion-study/v1','frontier_model_calls':0,
        'natural_workloads':0,'discovery_method':'standard finite partition refinement',
        'independent_external_review':False,'tested_relabelings':40,
        'sweep_certificate_checks':all_checks,'sweep_replay_outputs':replay_outputs,
        'rows':rows,'main':{'source_states':raw.n,'target_states':reduced.n,
            'source_edges':raw.n*raw.a,'target_edges':reduced.n*reduced.a,
            'checks':checked,'constructor_ledger':ledger,
            'main_replay_events':len(word),'main_replay_outputs':len(word)+1,
            'irrelevant_events_in_main_trace':mutations,
            'source_runtime_bits':10,'target_runtime_bits':4},
        'controls':controls,'illustrative_cost_scenarios':costs}
    write('study.json',study)
    lines=[]
    for row in rows:
        lines.append(f"{row['required_bits']} & {row['nuisance_bits']} & {row['source_states']:,} & {row['target_states']:,} & {row['state_cardinality_ratio']} & {row['self_loop_fraction']} \\\\")
    (OUT/'state_table.tex').write_text('\n'.join(lines)+'\n')
    print(json.dumps({k:study[k] for k in ['tested_relabelings','sweep_certificate_checks','sweep_replay_outputs','main','controls']},indent=2))

if __name__=='__main__':
    if not __debug__: raise RuntimeError('Run the study without -O: verification assertions are required')
    run()
