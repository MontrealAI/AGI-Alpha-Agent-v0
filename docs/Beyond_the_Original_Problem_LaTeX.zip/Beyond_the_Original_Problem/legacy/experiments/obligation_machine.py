"""Exact finite-state capability construction; standard-library research artifact."""
from __future__ import annotations
from dataclasses import dataclass
from collections import deque
from fractions import Fraction
import hashlib
import json
import random
from typing import Iterable

MAX_STATES, MAX_EVENTS = 4096, 16

@dataclass(frozen=True)
class Machine:
    transition: tuple[tuple[int, ...], ...]
    output: tuple[int, ...]
    initial: int = 0

    def __post_init__(self):
        n = len(self.output)
        if not 1 <= n <= MAX_STATES or len(self.transition) != n:
            raise ValueError('invalid state count')
        a = len(self.transition[0])
        if not 1 <= a <= MAX_EVENTS:
            raise ValueError('invalid event alphabet')
        if type(self.initial) is not int or not 0 <= self.initial < n:
            raise ValueError('invalid initial state')
        if any(type(v) is not int or v < 0 for v in self.output):
            raise ValueError('outputs must be nonnegative exact integers')
        for row in self.transition:
            if len(row) != a or any(type(s) is not int or not 0 <= s < n for s in row):
                raise ValueError('transition must be total and well typed')

    @property
    def n(self): return len(self.output)
    @property
    def a(self): return len(self.transition[0])
    def as_dict(self):
        return {'transition': [list(row) for row in self.transition],
                'output': list(self.output), 'initial': self.initial}
    def fingerprint(self):
        return hashlib.sha256(json.dumps(self.as_dict(), sort_keys=True,
                                        separators=(',', ':')).encode()).hexdigest()
    def run(self, events: Iterable[int], initial: int | None = None):
        s = self.initial if initial is None else initial
        if type(s) is not int or not 0 <= s < self.n: raise ValueError('bad state')
        outputs = [self.output[s]]
        for e in events:
            if type(e) is not int or not 0 <= e < self.a: raise ValueError('bad event')
            s = self.transition[s][e]
            outputs.append(self.output[s])
        return tuple(outputs)


def normalized(values):
    labels, result = {}, []
    for value in values:
        if value not in labels: labels[value] = len(labels)
        result.append(labels[value])
    return tuple(result)


def construct(machine: Machine):
    """Partition refinement; constructor receives no semantic relevance annotations."""
    blocks = normalized(machine.output)
    rounds, sizes = 0, [len(set(blocks))]
    while True:
        refined = normalized((machine.output[s], tuple(blocks[t] for t in machine.transition[s]))
                             for s in range(machine.n))
        rounds += 1
        sizes.append(len(set(refined)))
        if refined == blocks: break
        blocks = refined
    reps = [blocks.index(k) for k in range(len(set(blocks)))]
    target = Machine(tuple(tuple(blocks[t] for t in machine.transition[s]) for s in reps),
                     tuple(machine.output[s] for s in reps), blocks[machine.initial])
    cert = {'schema': 'obligation-quotient-certificate/v1', 'source_sha256': machine.fingerprint(),
            'target_sha256': target.fingerprint(), 'map': list(blocks)}
    ledger = {'initial_output_reads': machine.n,
              'refinement_output_reads': rounds * machine.n,
              'refinement_transition_reads': rounds * machine.n * machine.a,
              'construction_output_reads': target.n,
              'construction_transition_reads': target.n * target.a,
              'refinement_rounds': rounds, 'partition_sizes': sizes}
    return target, cert, ledger


def representative_quotient(machine: Machine, labels):
    """Deliberately unsafe comparison: merge on supplied current labels only."""
    blocks = normalized(labels)
    reps = [blocks.index(k) for k in range(len(set(blocks)))]
    return Machine(tuple(tuple(blocks[t] for t in machine.transition[s]) for s in reps),
                   tuple(machine.output[s] for s in reps), blocks[machine.initial]), blocks


def make_monitor(required: int, nuisance: int, *, seed: int = 0, contract: str = 'ready'):
    """Generate anonymized Boolean service monitors; not natural-world workloads."""
    if type(required) is not int or type(nuisance) is not int or required < 1 or nuisance < 0:
        raise ValueError('invalid monitor dimensions')
    width = required + nuisance
    if width > 12 or width > MAX_EVENTS: raise ValueError('model too large')
    if contract not in {'ready', 'ready-and-audit-bit', 'full-state'}:
        raise ValueError('unknown contract')
    if contract == 'ready-and-audit-bit' and nuisance == 0:
        raise ValueError('no audit bit')
    rng = random.Random(seed)
    encode = list(range(1 << width)); rng.shuffle(encode)
    event_bits = list(range(width)); rng.shuffle(event_bits)
    n, mask = 1 << width, (1 << required) - 1
    transitions, outputs = [None] * n, [None] * n
    for x in range(n):
        s = encode[x]
        transitions[s] = tuple(encode[x ^ (1 << bit)] for bit in event_bits)
        ready = int((x & mask) == mask)
        outputs[s] = x if contract == 'full-state' else (
            2 * ready + ((x >> required) & 1) if contract == 'ready-and-audit-bit' else ready)
    machine = Machine(tuple(transitions), tuple(outputs), encode[0])
    metadata = {'required': required, 'nuisance': nuisance, 'seed': seed,
                'contract': contract, 'encode': encode, 'event_bits': event_bits}
    return machine, metadata


def explicit_projection(machine: Machine, metadata):
    """Strong domain-aware control with the correct sufficient state supplied."""
    r, n = metadata['required'], metadata['nuisance']
    if metadata['contract'] == 'full-state': keep = r + n
    else: keep = r + int(metadata['contract'] == 'ready-and-audit-bit')
    reverse = {s: x for x, s in enumerate(metadata['encode'])}
    labels = [reverse[s] & ((1 << keep) - 1) for s in range(machine.n)]
    target, phi = representative_quotient(machine, labels)
    return target, {'schema': 'obligation-quotient-certificate/v1',
                    'source_sha256': machine.fingerprint(), 'target_sha256': target.fingerprint(),
                    'map': list(phi)}


def future_witness(left: Machine, right: Machine):
    """Breadth-first product search returns the shortest initial-state discrepancy."""
    if left.a != right.a: raise ValueError('different alphabets')
    first = (left.initial, right.initial)
    pending, seen = deque([(first, ())]), {first}
    while pending:
        (s, t), word = pending.popleft()
        if left.output[s] != right.output[t]: return word
        for e in range(left.a):
            pair = (left.transition[s][e], right.transition[t][e])
            if pair not in seen:
                seen.add(pair); pending.append((pair, word + (e,)))
    return None


def distinguishable_pairs(machine: Machine):
    """Independent table-filling minimality check, used only on small targets."""
    marked = {(i, j) for i in range(machine.n) for j in range(i)
              if machine.output[i] != machine.output[j]}
    changed = True
    while changed:
        changed = False
        for i in range(machine.n):
            for j in range(i):
                if (i, j) in marked: continue
                for a in range(machine.a):
                    p, q = machine.transition[i][a], machine.transition[j][a]
                    if (max(p, q), min(p, q)) in marked:
                        marked.add((i, j)); changed = True; break
    return len(marked)


def retained_value(setup: int, saving: int, survival: Fraction, horizon: int):
    if type(setup) is not int or type(saving) is not int or setup < 0 or saving < 0:
        raise ValueError('invalid costs')
    if not 0 <= survival <= 1 or type(horizon) is not int or horizon < 0:
        raise ValueError('invalid horizon or survival')
    return -Fraction(setup) + sum((Fraction(saving) * survival**i for i in range(horizon)), Fraction(0))


def contract_guard(saved: str, current: Machine):
    if type(saved) is not str or saved != current.fingerprint():
        raise ValueError('model/contract binding changed; revalidate before use')
