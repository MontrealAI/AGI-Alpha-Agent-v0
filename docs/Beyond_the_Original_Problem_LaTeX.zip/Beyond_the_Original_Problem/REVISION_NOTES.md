# Revision notes and internal critical review

## What changed at the center

The previous edition, *Beyond Task Completion*, foregrounded constructing capabilities that make recurring work unnecessary. The revised paper, *Beyond the Original Problem*, treats that as one consequence of a larger objective: recognizing a binding, unnecessary restriction in the original formulation, constructing an alternative, and demonstrating a purpose-grounded expansion of what can be achieved.

The title, abstract, opening page, formal target, primary experiment, architecture, research hypotheses, implementation interpretation, and conclusion were rebuilt around formulation discovery. The original definition is prominent on the first page. The original *Transformational Intelligence: Learning to Change the Game* manuscript and public link remain unchanged.

## Substantive additions

1. Four separated objects: authorized purpose, formulation, policy, and evaluator. The outcome projection, not the incumbent's whole internal trace, provides the comparison basis.
2. A purpose-relative attainable-set definition distinguishes an empirical gain from a structural mechanism claim and from a certified formulation-bound escape. A policy-transfer inclusion proposition makes resource assumptions explicit.
3. A new executed static-world study demonstrates the complementary removal of two restrictions. Its factorial probe minima are 8, 8, 8, 3. A complete probe-budget frontier and proofs address strong adaptive comparisons rather than a weak first answer.
4. A finite constructor, separate caller-contract checker, negative controls, probe-price frontier, noise sensitivity calculation, and 45 new test methods accompany the study.
5. The previous 54-test dynamic-state study is preserved and rerun as a complementary account of future validity, not the definition of the new thesis.
6. The architecture centers executable formulation–experiment pairs, evidence-linked restriction diagnosis, complementary changes, and extensible operators with explicit admission. The six hypotheses test discovery, mechanism, discernment, evidence acquisition, persistence, and campaign-level improvement.

## Critical objections addressed

| Objection | Response in this edition |
|---|---|
| “This only makes work disappear.” | The formal target is attainable outcomes under an authorized purpose. A transformation may require more work initially or enable a different outcome rather than reduce work. |
| “The winning solution was handed to the algorithm.” | The constructor receives the full finite model and allowed grammar, but not a winning basis. It enumerates 502 candidate sets. This supports limited finite-class construction, not general invention. Supplied ingredients are disclosed. |
| “It is just standard linear algebra.” | Yes, standard algebra matches the finite minimum. The contribution is the operational distinction and exact factorial/frontier demonstration, not a new algebraic algorithm. |
| “A better sensor is a hidden resource grant.” | Every method has the same external permission/interface. The coordinate-only limitation is an explicit internal formulation restriction. Probe prices and construction costs are separated. No new physical instrument is supplied for free to only one comparator. |
| “Eight to three exaggerates a performance gain.” | This is an exact binary-probe requirement, not runtime, energy, cost, or LLM performance. All seven answers remain required. The constructor's 128,512 candidate-world checks are disclosed. |
| “More agreeing critics could close the gap.” | Under the stated three-coordinate observation restriction, uniform unread-world uncertainty remains. The full-vector bound follows from a conditional-rank argument, not agreement. An unrestricted ordinary policy does match the new design. |
| “Immediate correctness proves future reuse.” | The retained dynamic-state counterexample and added-query trap show otherwise. Future obligations and requalification remain explicit. |
| “The candidate controls its contract.” | The query checker receives an expected contract separately, rejects stale bindings, and checks all required outputs. It does not claim to authenticate the human authority behind that contract. |
| “Separate code means independent review.” | The checker is separately implemented, not organizationally independent. Both laboratories share authorship and supplied-model assumptions. |
| “The agent can always tell a new story and win.” | The evaluation requires unchanged-purpose outcomes, strong unrestricted alternatives, mechanism tests, negative controls, full costs, and fresh confirmation. Legitimate refusal and incumbent victory remain possible. |

This is an internal methodological and artifact review. It is not external peer review and is not a certification of a subjective quality score.

## Originals preserved

The following original files were checked and not overwritten:

| Original | SHA-256 |
|---|---|
| `Beyond_Task_Completion.pdf` | `947adb63f81b2911a32f1a6616f5387201d96f73fda448aefac04b614cde59d8` |
| `Beyond_Task_Completion.tex` | `ad195147ebc57213af30f80f5ffb46447b58772d2ab77216db316838cbede8d4` |
| `Transformational_Intelligence.pdf` | `d7170e8217e3bf6aa1b84868c1c76c5994c6995c5297ed092d7e72a6430c664f` |
| `Transformational_Intelligence.tex` | `9d4a664d951d6b97f5136bf0b44f1ca458e90d585434a6a27a542694bb2ece5f` |

The revised files have a new basename. The retained `legacy/experiments` and `legacy/tests` code is copied unchanged from the original complete project. No repository commit, release, website publication, wallet action, or deployment is performed by this revision.
