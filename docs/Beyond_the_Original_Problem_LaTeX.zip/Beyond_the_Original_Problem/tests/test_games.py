from __future__ import annotations
import copy
from fractions import Fraction
from functools import lru_cache
from itertools import combinations, product
from pathlib import Path
import json
import subprocess
import sys
import tempfile
import unittest
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "experiments"))
from game_discovery import (Contract, make_contract, find_design, sufficient_decoder, optimal_success,
    coordinate_frontier, all_binary_frontier, span, rank, signature, unresolved_pair,
    minimum_retained_states, non_dominated_designs, cheapest_design, lifetime_value, algebraic_minimum)
from verify_game import check
from check_game_artifact import read_json


@lru_cache(None)
def fixture():
    contract = make_contract()
    return contract, find_design(contract)


class DesignTests(unittest.TestCase):
    def test_main_constructor(self):
        c, p = fixture()
        self.assertEqual(p["probes"], [51, 85, 153])
        self.assertEqual(p["search"]["candidate_sets_evaluated"], 502)
        self.assertEqual(check(c.payload(), p)["output_equalities_checked"], 1792)

    def test_retained_state_lower_bound(self):
        self.assertEqual(minimum_retained_states(fixture()[0]), 8)

    def test_strong_control_matches(self):
        c, p = fixture()
        self.assertEqual(len(algebraic_minimum(c, c.allowed_probes)), len(p["probes"]))

    def test_factorial_coordinate_purpose(self):
        c = fixture()[0]
        self.assertEqual(len(algebraic_minimum(c, tuple(1 << i for i in range(8)))), 8)

    def test_factorial_programmable_full_world(self):
        c = fixture()[0]
        full = Contract(8, tuple(1 << i for i in range(8)), c.allowed_probes)
        self.assertEqual(len(algebraic_minimum(full, full.allowed_probes)), 8)

    def test_coordinate_frontier(self):
        self.assertEqual([r["success"] for r in coordinate_frontier(fixture()[0])],
                         ["1/8"]*4 + ["1/4"]*2 + ["1/2"]*2 + ["1"])

    def test_any_binary_frontier(self):
        self.assertEqual([r["success"] for r in all_binary_frontier(8, 3)],
                         ["1/8", "1/4", "1/2"] + ["1"]*6)

    def test_frontier_attained_by_basis_prefixes(self):
        c, p = fixture()
        for k in range(4):
            self.assertEqual(optimal_success(c, tuple(p["probes"][:k])), min(Fraction(1), Fraction(2**k, 8)))

    def test_no_two_probe_design_in_supplied_class(self):
        c = fixture()[0]
        self.assertTrue(all(sufficient_decoder(c, probes) is None for probes in combinations(c.allowed_probes, 2)))

    def test_two_probe_counterexample(self):
        c, p = fixture()
        w = unresolved_pair(c, tuple(p["probes"][:2]))
        self.assertIsNotNone(w)
        self.assertEqual(w["worlds"], [3, 4])
        self.assertNotEqual(*w["different_outputs"])

    def test_added_obligation(self):
        c = fixture()[0]
        changed = Contract(8, c.queries + (1,), c.allowed_probes)
        p = find_design(changed)
        self.assertEqual(len(p["probes"]), 4)
        self.assertEqual(minimum_retained_states(changed), 16)
        self.assertEqual(check(changed.payload(), p)["output_equalities_checked"], 2048)

    def test_unasked_query_not_preserved(self):
        c, p = fixture()
        witness = unresolved_pair(c, tuple(p["probes"]), 1)
        self.assertEqual(witness["worlds"], [7, 8])

    def test_full_contract_prevents_reduction(self):
        c = Contract(3, (1, 2, 4), (1, 2, 3, 4, 5, 6, 7))
        self.assertEqual(len(find_design(c)["probes"]), 3)

    def test_one_dimensional_case(self):
        c = Contract(1, (1,), (1,))
        self.assertEqual(len(find_design(c)["probes"]), 1)
        self.assertTrue(check(c.payload(), find_design(c))["valid"])

    def test_all_nonempty_small_query_families(self):
        for size in range(1, 8):
            for queries in combinations(range(1, 8), size):
                with self.subTest(queries=queries):
                    c = Contract(3, queries, tuple(range(1, 8)))
                    p = find_design(c)
                    self.assertEqual(len(p["probes"]), rank(queries))
                    self.assertTrue(check(c.payload(), p)["valid"])

    def test_uninformative_experiment_class(self):
        c = Contract(2, (2,), (1,))
        with self.assertRaises(ValueError):
            find_design(c)

    def test_price_frontier(self):
        f = non_dominated_designs(fixture()[0])
        self.assertEqual([(p["coordinate_probes"], p["programmable_probes"]) for p in f],
                         [(0, 3), (4, 2), (6, 1), (8, 0)])
        for row in f:
            self.assertIsNotNone(sufficient_decoder(fixture()[0], tuple(row["probes"])))

    def test_prices_can_reverse_choice(self):
        f = non_dominated_designs(fixture()[0])
        self.assertEqual(cheapest_design(f, Fraction(1))["programmable_probes"], 3)
        self.assertEqual(cheapest_design(f, Fraction(3))["coordinate_probes"], 8)
        self.assertEqual(cheapest_design(f, Fraction(8, 3))["total_probe_price"], "8")

    def test_span_rank_agreement(self):
        for size in range(8):
            for values in combinations(range(1, 8), size):
                self.assertEqual(len(span(values)), 2**rank(values))

    def test_noise_accounting_by_exhaustion(self):
        e = Fraction(1, 20)
        exact = Fraction()
        for errors in product((0, 1), repeat=3):
            probability = Fraction(1)
            for flag in errors:
                probability *= e if flag else 1-e
            if not any(errors):
                exact += probability
        self.assertEqual(exact, Fraction(6859, 8000))
        self.assertEqual((1-(3*e**2-2*e**3))**3, Fraction(62618067611, 64000000000))


class ContractTests(unittest.TestCase):
    def test_dimension_type(self):
        for d in (True, 0, 11, 2.0):
            with self.assertRaises(ValueError):
                Contract(d, (1,), (1,))

    def test_mask_type_and_bounds(self):
        for mask in (True, 0, 4, 1.0):
            with self.assertRaises(ValueError):
                Contract(2, (mask,), (1, 2))

    def test_duplicate_masks(self):
        with self.assertRaises(ValueError):
            Contract(2, (1, 1), (1, 2))

    def test_unauthorized_probe(self):
        c = Contract(2, (1,), (1,))
        with self.assertRaises(ValueError):
            sufficient_decoder(c, (2,))

    def test_repeated_probe(self):
        with self.assertRaises(ValueError):
            sufficient_decoder(fixture()[0], (1, 1))

    def test_missing_query(self):
        with self.assertRaises(ValueError):
            Contract(2, (), (1, 2))

    def test_lifecycle_and_zero_horizon(self):
        self.assertEqual(lifetime_value(Fraction(120), Fraction(3), Fraction(1), 40), 0)
        self.assertEqual(lifetime_value(Fraction(120), Fraction(3), Fraction(1), 0), -120)
        self.assertEqual(lifetime_value(Fraction(120), Fraction(3), Fraction(0), 100), -117)

    def test_lifecycle_survival_sensitivity(self):
        self.assertLess(lifetime_value(Fraction(120), Fraction(3), Fraction(99,100), 50), 0)
        self.assertGreater(lifetime_value(Fraction(120), Fraction(3), Fraction(99,100), 100), 0)
        self.assertLess(lifetime_value(Fraction(120), Fraction(3), Fraction(9,10), 500), 0)

    def test_invalid_lifecycle_inputs(self):
        for args in ((Fraction(-1), Fraction(3), Fraction(1), 1),
                     (Fraction(1), Fraction(3), Fraction(2), 1),
                     (Fraction(1), Fraction(3), Fraction(1), True)):
            with self.assertRaises(ValueError):
                lifetime_value(*args)


class CheckerTests(unittest.TestCase):
    def setUp(self):
        c, p = fixture()
        self.c, self.p = c.payload(), copy.deepcopy(p)

    def test_decoder_corruption(self):
        self.p["decoder"]["0"] ^= 1
        with self.assertRaises(ValueError): check(self.c, self.p)

    def test_missing_decoder_row(self):
        del self.p["decoder"]["0"]
        with self.assertRaises(ValueError): check(self.c, self.p)

    def test_noncanonical_decoder_key(self):
        self.p["decoder"]["00"] = self.p["decoder"].pop("0")
        with self.assertRaises(ValueError): check(self.c, self.p)

    def test_decoder_bool(self):
        self.p["decoder"]["0"] = False
        with self.assertRaises(ValueError): check(self.c, self.p)

    def test_stale_contract(self):
        self.c["queries"].append(1)
        with self.assertRaises(ValueError): check(self.c, self.p)

    def test_contract_authority_not_from_package(self):
        self.p["contract_digest"] = "0"*64
        with self.assertRaises(ValueError): check(self.c, self.p)

    def test_changed_probe(self):
        self.p["probes"][0] = 1
        with self.assertRaises(ValueError): check(self.c, self.p)

    def test_duplicate_probe(self):
        self.p["probes"][1] = self.p["probes"][0]
        with self.assertRaises(ValueError): check(self.c, self.p)

    def test_unknown_capability_fields(self):
        self.p["execute"] = "ignored-command"
        with self.assertRaises(ValueError): check(self.c, self.p)

    def test_noise_not_covered_by_contract(self):
        self.c["world_model"] = "noisy"
        with self.assertRaises(ValueError): check(self.c, self.p)

    def test_claim_scope_is_explicit(self):
        result = check(self.c, self.p)
        self.assertFalse(result["optimality_checked"])
        self.assertFalse(result["search_history_authenticated"])

    def test_cli_accepts_expected_contract(self):
        with tempfile.TemporaryDirectory() as d:
            base = Path(d)
            (base/'c.json').write_text(json.dumps(self.c))
            (base/'p.json').write_text(json.dumps(self.p))
            result = subprocess.run([sys.executable, str(ROOT/'experiments/check_game_artifact.py'),
                                     str(base/'c.json'), str(base/'p.json')], capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            self.assertEqual(json.loads(result.stdout)["probe_count"], 3)

    def test_cli_rejects_forged_result(self):
        self.p["decoder"]["0"] = 1
        with tempfile.TemporaryDirectory() as d:
            base = Path(d)
            (base/'c.json').write_text(json.dumps(self.c))
            (base/'p.json').write_text(json.dumps(self.p))
            result = subprocess.run([sys.executable, str(ROOT/'experiments/check_game_artifact.py'),
                                     str(base/'c.json'), str(base/'p.json')], capture_output=True, text=True)
            self.assertEqual(result.returncode, 1)
            self.assertFalse(json.loads(result.stdout)["valid"])

    def test_json_rejects_duplicate_keys(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d)/'a.json'; p.write_text('{"x": 1, "x": 2}')
            with self.assertRaises(ValueError): read_json(p)

    def test_json_rejects_nonfinite_values(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d)/'a.json'; p.write_text('{"x": NaN}')
            with self.assertRaises(ValueError): read_json(p)

    def test_json_size_limit(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d)/'a.json'; p.write_bytes(b' '*2_000_001)
            with self.assertRaises(ValueError): read_json(p)


if __name__ == "__main__":
    unittest.main()
