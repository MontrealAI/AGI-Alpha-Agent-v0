"""Check a bounded inert JSON record; never execute imported instructions."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import sys
from checker import verify

MAX_BYTES = 1_000_000

def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f'duplicate JSON key: {key}')
        result[key] = value
    return result

def reject_constant(value):
    raise ValueError(f'nonfinite JSON constant: {value}')

def check_path(path: Path, *, optimal: bool = True) -> dict:
    with path.open('rb') as stream:
        raw = stream.read(MAX_BYTES + 1)
    if len(raw) > MAX_BYTES:
        raise ValueError('record exceeds the one-megabyte input bound')
    record = json.loads(raw.decode('utf-8'), object_pairs_hook=unique_object,
                        parse_constant=reject_constant)
    return verify(record, optimal=optimal)

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('record', type=Path)
    parser.add_argument('--trace-only', action='store_true',
                        help='check feasibility and accounting, without recomputing optimality')
    args = parser.parse_args()
    try:
        result = check_path(args.record, optimal=not args.trace_only)
    except (OSError, ValueError, UnicodeError, RecursionError) as exc:
        print(f'REJECTED: {exc}', file=sys.stderr)
        return 2
    print(json.dumps(result, sort_keys=True, indent=2))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
