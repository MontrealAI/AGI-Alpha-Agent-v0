"""Dimensional calculations, not feasibility or construction forecasts."""
import math
L_SUN=3.828e26
AU=149_597_870_700.0
SIGMA=5.670374419e-8

def positive(x,name):
    if type(x) not in (int,float) or not math.isfinite(x) or x<=0:
        raise ValueError(f'{name} must be finite and positive')
    return float(x)

def ledger(fraction:float,temperature:float=300.0,eta:float=0.3,emissivity:float=0.9,
           radius_au:float=1.0,collector_areal_mass:float=0.1,
           radiator_areal_mass:float=1.0,background:float=3.0)->dict:
    f=positive(fraction,'fraction');T=positive(temperature,'temperature')
    eta=positive(eta,'efficiency');ep=positive(emissivity,'emissivity')
    r=positive(radius_au,'radius');mc=positive(collector_areal_mass,'collector mass')
    mr=positive(radiator_areal_mass,'radiator mass');Tb=positive(background,'background')
    if f>1 or eta>1 or ep>1 or T<=Tb:raise ValueError('invalid physical parameter domain')
    intercepted=f*L_SUN
    area=4*math.pi*(r*AU)**2*f
    # All intercepted power is eventually dissipated inside the chosen boundary.
    radiating=intercepted/(ep*SIGMA*(T**4-Tb**4))
    return {'fraction':f,'temperature_K':T,'intercepted_W':intercepted,
            'gross_electric_W':eta*intercepted,'dissipated_W':intercepted,
            'projected_collector_m2':area,'emitting_area_lower_bound_m2':radiating,
            'collector_mass_kg':mc*area,'radiator_mass_lower_bound_kg':mr*radiating,
            'ideal_doublings_from_1TW':math.log2(intercepted/1e12)}

def recycling_multiplier(recovery:float)->float:
    if type(recovery) not in (int,float) or not math.isfinite(recovery) or not 0<=recovery<1:
        raise ValueError('recovery must be finite in [0,1)')
    return 1/(1-recovery)
