"""Strong comparator: purchase either installed project at any affordable period."""
from functools import lru_cache
from itertools import product
from production import Model

def solve_adaptive(m: Model):
    """Use availability dates (-1 means unpurchased); preserve service during qualification."""
    decisions={}
    @lru_cache(None)
    def value(t,k,c,r,ready_e,ready_f):
        if t==m.horizon:return k,c
        best=(-1,-1);act=None
        can_e=(0,1) if ready_e<0 and m.permit_energy else (0,)
        can_f=(0,1) if ready_f<0 and m.permit_fabrication else (0,)
        for pe,pf in product(can_e,can_f):
            fee=(pe+pf)*m.project_cost
            if fee>c:continue
            ne=t+m.setup_delay if pe else ready_e
            nf=t+m.setup_delay if pf else ready_f
            a=m.new_energy if 0<=ne<=t else m.base_energy
            b=m.new_fabrication if 0<=nf<=t else m.base_fabrication
            for u in range(min(k//a,k//b,c-fee,r),-1,-1):
                score=value(t+1,k+u,c-fee-u+m.receipt,r-u,ne,nf)
                if score>best:best,act=score,(pe,pf,u,ne,nf,fee)
        decisions[(t,k,c,r,ready_e,ready_f)]=act
        return best
    score=value(0,m.seed,m.cash,m.material,-1,-1)
    k,c,r,re,rf=m.seed,m.cash,m.material,-1,-1;rows=[]
    for t in range(m.horizon):
        pe,pf,u,ne,nf,fee=decisions[(t,k,c,r,re,rf)]
        rows.append({'period':t,'buy_energy':pe,'buy_fabrication':pf,'built':u,
                     'before':[k,c,r],'after':[k+u,c-fee-u+m.receipt,r-u],
                     'energy_ready':ne,'fabrication_ready':nf})
        k,c,r,re,rf=k+u,c-fee-u+m.receipt,r-u,ne,nf
    return {'score':list(score),'rows':rows,'states':value.cache_info().currsize}
