"""Separate raw-record verifier and forward enumerator. Does not import production.py."""
from __future__ import annotations
import hashlib,json
from typing import Any

MODEL_CAPS={'horizon':(0,8),'seed':(1,8),'cash':(0,80),'material':(0,40),
            'receipt':(0,8),'project_cost':(0,40),'setup_delay':(0,8),
            'base_energy':(1,8),'base_fabrication':(1,8),
            'new_energy':(1,8),'new_fabrication':(1,8)}

def integer(x:Any,low:int=0,high:int=10**6)->int:
    if type(x) is not int or x<low or x>high: raise ValueError('invalid integer')
    return x

def model(raw:Any)->dict:
    if type(raw) is not dict or set(raw)!=set(MODEL_CAPS)|{'permit_energy','permit_fabrication'}:
        raise ValueError('invalid model shape')
    for key,(lo,hi) in MODEL_CAPS.items(): integer(raw[key],lo,hi)
    for key in ('permit_energy','permit_fabrication'):
        if type(raw[key]) is not bool: raise ValueError('invalid permission type')
    if raw['new_energy']>raw['base_energy'] or raw['new_fabrication']>raw['base_fabrication']:
        raise ValueError('invalid installed project')
    return raw

def terms(m:dict,p:list)->tuple:
    if type(p) is not list or len(p)!=2:raise ValueError('invalid portfolio')
    for x in p:integer(x,0,1)
    if p[0] and not m['permit_energy']:raise ValueError('unpermitted energy project')
    if p[1] and not m['permit_fabrication']:raise ValueError('unpermitted fabrication project')
    fee=sum(p)*m['project_cost']
    if fee>m['cash']:raise ValueError('unfunded project')
    return (m['new_energy'] if p[0] else m['base_energy'],m['new_fabrication'] if p[1] else m['base_fabrication'],fee,m['setup_delay'] if any(p) else 0)

def forward_optimum(raw:dict,portfolio:list)->tuple[int,int]:
    m=model(raw);a,b,fee,delay=terms(m,portfolio)
    layer={(m['seed'],m['cash']-fee,m['material'])}
    for t in range(m['horizon']):
        nxt=set()
        for k,c,r in layer:
            for u in range(min(c,r)+1):
                if (t<delay and u) or a*u>k or b*u>k:continue
                nxt.add((k+u,c-u+m['receipt'],r-u))
        layer=nxt
    return max((k,c) for k,c,r in layer)

def verify(record:dict,optimal:bool=True)->dict:
    expected={'schema','model','model_sha256','portfolio','project_fee','energy_intensity',
              'fabrication_intensity','setup_delay','rows','score','final','search_states','scope'}
    if type(record) is not dict or set(record)!=expected or record['schema']!='production-frontier/1':
        raise ValueError('invalid record shape')
    if record['scope'] != 'exact-synthetic-model; not physical, economic, or AI performance evidence':
        raise ValueError('unsupported evidential scope')
    m=model(record['model']);a,b,fee,delay=terms(m,record['portfolio'])
    encoded=json.dumps(m,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
    if hashlib.sha256(encoded).hexdigest()!=record['model_sha256']:raise ValueError('model binding changed')
    for key,val in [('project_fee',fee),('energy_intensity',a),('fabrication_intensity',b),('setup_delay',delay)]:
        integer(record[key])
        if record[key]!=val:raise ValueError('project terms changed')
    if type(record['rows']) is not list or len(record['rows'])!=m['horizon']:raise ValueError('truncated trace')
    before={'capacity':m['seed'],'cash':m['cash']-fee,'material':m['material']}
    asserts=0
    rowkeys={'period','before','built','energy_used','fabrication_used','energy_available',
             'fabrication_available','legacy_service_delivered','net_receipt','after'}
    for t,row in enumerate(record['rows']):
        if type(row) is not dict or set(row)!=rowkeys:raise ValueError('invalid row shape')
        for key in rowkeys-{'before','after'}:integer(row[key])
        for key in ('before','after'):
            if type(row[key]) is not dict or set(row[key])!={'capacity','cash','material'}:raise ValueError('invalid stock vector')
            for v in row[key].values():integer(v)
        k,c,r=before['capacity'],before['cash'],before['material'];u=row['built']
        checks=[row['period']==t,row['before']==before,
                not(t<delay and u>0),row['energy_available']==k,row['fabrication_available']==k,
                row['energy_used']==a*u,row['fabrication_used']==b*u,
                a*u<=k,b*u<=k,u<=c,u<=r,row['legacy_service_delivered']==1,
                row['net_receipt']==m['receipt'],
                row['after']=={'capacity':k+u,'cash':c-u+m['receipt'],'material':r-u}]
        asserts+=len(checks)
        if not all(checks):raise ValueError('conservation, outcome, timing, or permission violation')
        before=row['after']
    if type(record['final']) is not dict or set(record['final'])!={'capacity','cash','material'}:raise ValueError('invalid final stock vector')
    for value in record['final'].values():integer(value)
    if record['final']!=before:raise ValueError('final stock vector changed')
    if type(record['score']) is not list or len(record['score'])!=2:raise ValueError('invalid score')
    for value in record['score']:integer(value)
    if record['score']!=[before['capacity'],before['cash']]:raise ValueError('false reported score')
    integer(record['search_states'],1)
    if optimal and tuple(record['score'])!=forward_optimum(m,record['portfolio']):raise ValueError('suboptimal declared plan')
    return {'valid':True,'periods':len(record['rows']),'semantic_assertions':asserts+2,
            'independent_forward_optimum_checked':optimal}

def adaptive_forward(raw:dict)->tuple[int,int]:
    """Separate breadth-first reachability for the flexible-procurement control."""
    m=model(raw)
    states={(m['seed'],m['cash'],m['material'],-1,-1)}
    for t in range(m['horizon']):
        nxt=set()
        for k,c,r,re,rf in states:
            for mask in range(4):
                pe=mask&1;pf=(mask>>1)&1
                if pe and (re!=-1 or not m['permit_energy']):continue
                if pf and (rf!=-1 or not m['permit_fabrication']):continue
                fee=(pe+pf)*m['project_cost']
                if fee>c:continue
                ne=t+m['setup_delay'] if pe else re
                nf=t+m['setup_delay'] if pf else rf
                a=m['new_energy'] if ne>=0 and ne<=t else m['base_energy']
                b=m['new_fabrication'] if nf>=0 and nf<=t else m['base_fabrication']
                for u in range(min(c-fee,r)+1):
                    if a*u<=k and b*u<=k:
                        nxt.add((k+u,c-fee-u+m['receipt'],r-u,ne,nf))
        states=nxt
    return max((k,c) for k,c,r,re,rf in states)
