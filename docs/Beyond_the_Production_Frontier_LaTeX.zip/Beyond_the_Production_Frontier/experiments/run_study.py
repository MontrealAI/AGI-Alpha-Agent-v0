from dataclasses import asdict, replace
from itertools import product
from pathlib import Path
import json
from production import Model,solve,solve_portfolio
from checker import verify,forward_optimum,adaptive_forward
from adaptive import solve_adaptive
from stellar import ledger,recycling_multiplier

ROOT=Path(__file__).resolve().parents[1]
def save(name,data):
    (ROOT/'results'/name).write_text(json.dumps(data,sort_keys=True,indent=2,allow_nan=False)+'\n')

def main():
    (ROOT/'results').mkdir(exist_ok=True)
    m=Model(); result=solve(m)
    audits=[verify(r) for r in result['portfolios']]
    save('main.json',result);save('capacity_certificate.json',result['winner'])
    cases={'cash_without_reformulation':replace(m,cash=80),
           'no_raw_material':replace(m,material=0),
           'no_recurring_receipts':replace(m,receipt=0),
           'insufficient_setup_funds':replace(m,cash=3),
           'larger_seed':replace(m,seed=2),
           'unpermitted_fabrication':replace(m,permit_fabrication=False),
           'unproductive_projects':replace(m,new_energy=2,new_fabrication=2),
           'long_qualification_delay':replace(m,setup_delay=6),
           'tight_material_stock':replace(m,material=6),
           'short_horizon':replace(m,horizon=1)}
    controls={}
    for name,model in cases.items():
        res=solve(model)
        for rec in res['portfolios']:verify(rec)
        controls[name]={'winner':res['winner']['portfolio'],'score':res['winner']['score'],
                        'material_remaining':res['winner']['final']['material'],
                        'portfolio_scores':[{'portfolio':r['portfolio'],'score':r['score']} for r in res['portfolios']]}
    save('controls.json',controls)
    flexible=[]
    for cash in (3,6,12):
        cfg=replace(m,cash=cash); record=solve_adaptive(cfg)
        assert tuple(record['score'])==adaptive_forward(asdict(cfg))
        flexible.append({'cash':cash,'result':record})
    save('adaptive_controls.json',flexible)
    rows=[];assertions=0
    for h,k,c,r in product((2,4,6),(1,2),(6,12,18),(0,6,20)):
        cfg=replace(m,horizon=h,seed=k,cash=c,material=r);res=solve(cfg)
        for record in res['portfolios']:
            audit=verify(record);assertions+=audit['semantic_assertions']
        rows.append({'horizon':h,'seed':k,'cash':c,'material':r,
                     'winner':res['winner']['portfolio'],'score':res['winner']['score'],
                     'states_explored':sum(p['search_states'] for p in res['portfolios'])})
    save('sweep.json',{'configurations':len(rows),'portfolio_checks':len(rows)*4,
                      'semantic_assertions':assertions,'rows':rows})
    physical={'constants':{'nominal_solar_luminosity_W':3.828e26,'AU_m':149597870700,
                          'sigma_W_m2_K4':5.670374419e-8},
              'assumptions':{'efficiency':.3,'emissivity':.9,'radius_AU':1,
                             'collector_kg_m2':.1,'radiator_kg_m2':1,'background_K':3,
                             'all_intercepted_energy_dissipated_inside_boundary':True},
              'rows':[ledger(f,T) for f in (1e-12,1e-6,1e-2,1.0) for T in (300.,600.)],
              'recycling':[{'recovery':r,'gross_processing_multiplier_bound':recycling_multiplier(r)} for r in (0.,.9,.99,.999)]}
    save('stellar_ledger.json',physical)
    print(json.dumps({'main_portfolios':[(r['portfolio'],r['score'],r['search_states']) for r in result['portfolios']],
                      'main_plan':[r['built'] for r in result['winner']['rows']],
                      'controls':controls,'sweep_count':len(rows),'sweep_assertions':assertions,
                      'physical_1percent':ledger(.01)},indent=2))
if __name__=='__main__':main()
