"""Exact finite production-network study; no external calls or real transactions."""
from __future__ import annotations
from dataclasses import asdict, dataclass
from functools import lru_cache
from itertools import product
from typing import Any
import hashlib
import json

@dataclass(frozen=True)
class Model:
    horizon: int = 6
    seed: int = 1
    cash: int = 12
    material: int = 20
    receipt: int = 2
    project_cost: int = 2
    setup_delay: int = 1
    base_energy: int = 2
    base_fabrication: int = 2
    new_energy: int = 1
    new_fabrication: int = 1
    permit_energy: bool = True
    permit_fabrication: bool = True

    def __post_init__(self):
        caps = {'horizon':8,'seed':8,'cash':80,'material':40,'receipt':8,
                'project_cost':40,'setup_delay':8,'base_energy':8,
                'base_fabrication':8,'new_energy':8,'new_fabrication':8}
        positive = {'seed','base_energy','base_fabrication','new_energy','new_fabrication'}
        for key, cap in caps.items():
            value = getattr(self,key)
            if type(value) is not int or not (int(key in positive) <= value <= cap):
                raise ValueError(f'invalid bounded integer: {key}')
        for key in ('permit_energy','permit_fabrication'):
            if type(getattr(self,key)) is not bool:
                raise ValueError(f'invalid boolean: {key}')
        if self.new_energy > self.base_energy or self.new_fabrication > self.base_fabrication:
            raise ValueError('the installed research catalogue only admits nonincreasing intensities')

    @classmethod
    def from_dict(cls, raw: dict[str, Any]):
        if type(raw) is not dict or set(raw) != set(cls.__dataclass_fields__):
            raise ValueError('model must contain exactly the declared fields')
        return cls(**raw)

def digest(obj: Any) -> str:
    data = json.dumps(obj,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
    return hashlib.sha256(data).hexdigest()

def portfolio_terms(m: Model, portfolio: tuple[int,int]):
    if type(portfolio) is not tuple or len(portfolio)!=2 or any(type(x) is not int or x not in (0,1) for x in portfolio):
        raise ValueError('invalid portfolio')
    p,q = portfolio
    if (p and not m.permit_energy) or (q and not m.permit_fabrication):
        raise ValueError('project outside permission scope')
    fee = (p+q)*m.project_cost
    if fee > m.cash:
        raise ValueError('unfunded project portfolio')
    return (m.new_energy if p else m.base_energy,
            m.new_fabrication if q else m.base_fabrication,
            fee, m.setup_delay if p or q else 0)

def solve_portfolio(m: Model, portfolio: tuple[int,int]) -> dict[str,Any]:
    a,b,fee,delay = portfolio_terms(m,portfolio)
    decisions: dict[tuple[int,int,int,int],int] = {}
    @lru_cache(None)
    def bellman(t:int,k:int,c:int,r:int) -> tuple[int,int]:
        if t == m.horizon:
            return k,c
        maximum = 0 if t < delay else min(k//a,k//b,c,r)
        best = (-1,-1)
        best_u = 0
        for u in range(maximum,-1,-1):
            value = bellman(t+1,k+u,c-u+m.receipt,r-u)
            if value > best:
                best,best_u = value,u
        decisions[(t,k,c,r)] = best_u
        return best
    score = bellman(0,m.seed,m.cash-fee,m.material)
    k,c,r=m.seed,m.cash-fee,m.material
    rows=[]
    for t in range(m.horizon):
        u=decisions[(t,k,c,r)]
        nxt={'capacity':k+u,'cash':c-u+m.receipt,'material':r-u}
        rows.append({'period':t,'before':{'capacity':k,'cash':c,'material':r},
                     'built':u,'energy_used':a*u,'fabrication_used':b*u,
                     'energy_available':k,'fabrication_available':k,
                     'legacy_service_delivered':1,'net_receipt':m.receipt,'after':nxt})
        k,c,r=nxt['capacity'],nxt['cash'],nxt['material']
    return {'schema':'production-frontier/1','model':asdict(m),'model_sha256':digest(asdict(m)),
            'portfolio':list(portfolio),'project_fee':fee,'energy_intensity':a,
            'fabrication_intensity':b,'setup_delay':delay,'rows':rows,
            'score':list(score),'final':{'capacity':k,'cash':c,'material':r},
            'search_states':bellman.cache_info().currsize,
            'scope':'exact-synthetic-model; not physical, economic, or AI performance evidence'}

def solve(m: Model) -> dict[str,Any]:
    valid=[];rejected=[]
    for port in product((0,1), repeat=2):
        try: valid.append(solve_portfolio(m,port))
        except ValueError as exc: rejected.append({'portfolio':list(port),'reason':str(exc)})
    winner=max(valid,key=lambda x:tuple(x['score']))
    return {'model':asdict(m),'winner':winner,'portfolios':valid,'rejected':rejected}
