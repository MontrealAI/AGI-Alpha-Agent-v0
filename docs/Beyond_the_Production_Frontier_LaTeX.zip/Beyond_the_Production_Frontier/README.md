# Beyond the Production Frontier
## Transformational Intelligence from Verified Discovery to Stellar-Scale Civilization

Vincent Boucher · MONTREAL.AI · October 19, 2026

**Find your Alpha. Build your SUCCESSOR Ω.**

Project: https://github.com/MontrealAI/AGI-Alpha-Agent-v0

The manuscript asks how an AI could discover and construct a different production setup, demonstrate its value, and turn actual surplus or released resources into the next useful capability. It distinguishes a scientific result, a profitable service, installed capacity, and a physical scale.

## Read and reproduce

`Beyond_the_Production_Frontier.pdf` is the paper. The matching standalone `.tex` embeds its bibliography and tables; no external image or bibliography file is needed.

From this directory, using Python 3.10 or later (recorded run: Python 3.13.5):

```bash
python experiments/run_study.py
python -m unittest discover -s tests -v
python experiments/check_artifact.py results/capacity_certificate.json
```

Only Python's standard library is required. The programs make no network or model calls, use no credentials, and execute no external transactions. The first command regenerates six JSON result files. The tests cover 83 defined test methods, including exact-model checks and mutation rejection. Test counts are not measures of real-world scientific evidence.

The artifact checker rejects invalid quantities, duplicate keys, nonfinite JSON constants, changed schema/scope, inconsistent records, missing service, and resource/timing violations. Its default also recomputes the fixed-portfolio optimum using a separately implemented forward enumerator. `--trace-only` explicitly omits the optimality comparison.

```bash
latexmk -pdf -interaction=nonstopmode -halt-on-error Beyond_the_Production_Frontier.tex
```

Alternatively, run `pdflatex` twice. A TeX installation needs the packages named in the preamble, including newtx, natbib, algorithms, booktabs, tabularx, and hyperref. No fonts are distributed as separate files in this archive.

## What was executed

The main six-period synthetic model begins with one expansion module, twelve cash units, twenty material units, and a required legacy service per period. Two supplied projects separately leave expansion blocked. Together, after paying four units and waiting a qualification period, they produce nineteen installed modules and two cash units. All six modeled service deliveries remain present.

A stronger flexible-procurement exact planner matches that result. At three initial cash units, a policy restricted to buying projects immediately cannot initiate expansion. The flexible planner waits for settled receipts, buys both projects, and reaches ten modules. This demonstrates why investment timing must be part of the comparison rather than hidden in an infeasibility claim.

Ten changed-assumption controls, 54 parameter configurations (216 portfolios), and three flexible-procurement treasury cases are included. The sweep records 12,528 semantic assertions. The source is deterministic and supplied; the optimizer did not invent or experimentally verify the processes.

The separate physical ledger computes power, collection area, emitting area, hypothetical material requirements, and scale ratios. It assumes a nominal solar luminosity, idealized geometry, stipulated efficiency/emissivity, and hypothetical temperatures and areal masses. Those calculations are not an orbital design, manufacturing plan, or timeline forecast.

## Scope and limits

This is a theoretical framework, an exact synthetic study, dimensional calculations, and an implementation/evaluation blueprint. It reports no frontier-model discovery, real revenue, physical construction, empirical autonomous industry, general superintelligence, or completed stellar-scale capability. The independently written checker shares authorship and the source assumptions; no external peer review is claimed.

The finite economy has indivisible one-period construction, no purchases of finished modules, no accumulation of unused flow capacity, no depreciation within its short horizon, and fixed net receipts. The physical parameters are explicit assumptions, not fitted engineering estimates. Changing these premises can change the result.

Existing papers, their links, repository history, contracts, and deployments remain unchanged. The proposed Alpha integration is described in `IMPLEMENTATION.md`; this archive does not install or release it.

## Evidence navigation

- `CLAIMS.md`: precise claims, evidence, and non-claims.
- `IMPLEMENTATION.md`: proposed mission/adapter contract, not deployed functionality.
- `SOURCES.md`: source roles and checked bibliographic references.
- `results/`: the six deterministic research outputs.
- `tests/`: artifact, model, and physical-accounting tests.
- `REPRODUCIBILITY.md`: recorded checks and environment.
- `MANIFEST.sha256`: integrity hashes. A hash is not a trusted signature or semantic proof.
