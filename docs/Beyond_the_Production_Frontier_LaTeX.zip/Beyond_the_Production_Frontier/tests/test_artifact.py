import copy
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'experiments'))
from production import Model, solve
from checker import verify
from check_artifact import check_path

class ArtifactIO(unittest.TestCase):
    def setUp(self):
        self.record = solve(Model())['winner']
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name) / 'record.json'
        self.path.write_text(json.dumps(self.record))

    def test_local_file(self):
        self.assertTrue(check_path(self.path)['independent_forward_optimum_checked'])

    def test_trace_only(self):
        self.assertFalse(check_path(self.path, optimal=False)['independent_forward_optimum_checked'])

    def test_duplicate_field(self):
        self.path.write_text('{"schema":"x","schema":"y"}')
        with self.assertRaises(ValueError): check_path(self.path)

    def test_nonfinite(self):
        self.path.write_text('{"x":NaN}')
        with self.assertRaises(ValueError): check_path(self.path)

    def test_oversize(self):
        self.path.write_bytes(b' ' * 1_000_001)
        with self.assertRaises(ValueError): check_path(self.path)

    def test_false_scope(self):
        record = copy.deepcopy(self.record)
        record['scope'] = 'physically validated industrial breakthrough'
        with self.assertRaises(ValueError): verify(record)

    def test_command_accepts_and_rejects(self):
        command = [sys.executable, str(ROOT / 'experiments/check_artifact.py'), str(self.path)]
        accepted = subprocess.run(command, capture_output=True, text=True, timeout=10)
        self.assertEqual(accepted.returncode, 0, accepted.stderr)
        self.record['rows'][1]['net_receipt'] = 999
        self.path.write_text(json.dumps(self.record))
        rejected = subprocess.run(command, capture_output=True, text=True, timeout=10)
        self.assertEqual(rejected.returncode, 2)
        self.assertIn('REJECTED:', rejected.stderr)

if __name__ == '__main__': unittest.main()
