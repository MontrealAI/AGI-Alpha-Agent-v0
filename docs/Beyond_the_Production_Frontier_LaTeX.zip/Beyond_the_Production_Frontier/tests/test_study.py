import copy,json,math,sys,unittest
from dataclasses import asdict,replace
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'experiments'))
from production import Model,solve,solve_portfolio,digest
from checker import verify,forward_optimum,adaptive_forward
from adaptive import solve_adaptive
from stellar import ledger,recycling_multiplier,L_SUN,AU,SIGMA

class ExactStudy(unittest.TestCase):
    def setUp(self):self.m=Model();self.r=solve(self.m)
    def test_factorial(self):self.assertEqual([x['score'][0] for x in self.r['portfolios']],[1,1,1,19])
    def test_cash_separate(self):self.assertEqual([x['score'][1] for x in self.r['portfolios']],[24,22,22,2])
    def test_plan(self):self.assertEqual([r['built'] for r in self.r['winner']['rows']],[0,1,2,4,8,3])
    def test_total_builds(self):self.assertEqual(sum(x['built'] for x in self.r['winner']['rows']),18)
    def test_material_conservation(self):self.assertEqual(self.r['winner']['final']['material'],2)
    def test_fee(self):self.assertEqual(self.r['winner']['project_fee'],4)
    def test_services(self):self.assertEqual(sum(x['legacy_service_delivered'] for x in self.r['winner']['rows']),6)
    def test_check_all_arms(self):
        for r in self.r['portfolios']:self.assertTrue(verify(r)['valid'])
    def test_cash_bound_tight(self):self.assertEqual(self.r['winner']['score'][0],1+12-4+5*2)
    def test_material_bound(self):self.assertEqual(solve(replace(self.m,material=6))['winner']['score'][0],7)
    def test_seed_outside_trap(self):self.assertGreater(solve_portfolio(replace(self.m,seed=2),(0,0))['score'][0],2)
    def test_horizon_zero(self):self.assertEqual(solve(replace(self.m,horizon=0))['winner']['score'],[1,12])
    def test_short_horizon_declines(self):self.assertEqual(solve(replace(self.m,horizon=1))['winner']['portfolio'],[0,0])
    def test_no_material_declines(self):self.assertEqual(solve(replace(self.m,material=0))['winner']['portfolio'],[0,0])
    def test_no_receipts(self):self.assertEqual(solve(replace(self.m,receipt=0))['winner']['score'],[9,0])
    def test_more_cash_no_recipe_no_build(self):self.assertEqual(solve_portfolio(replace(self.m,cash=80),(0,0))['score'],[1,92])
    def test_no_productive_change_declines(self):self.assertEqual(solve(replace(self.m,new_energy=2,new_fabrication=2))['winner']['portfolio'],[0,0])
    def test_long_delay_declines(self):self.assertEqual(solve(replace(self.m,setup_delay=6))['winner']['portfolio'],[0,0])
    def test_zero_delay_may_help(self):self.assertGreaterEqual(solve(replace(self.m,setup_delay=0))['winner']['score'][0],19)
    def test_permit_not_score(self):self.assertEqual(solve(replace(self.m,permit_fabrication=False))['winner']['portfolio'],[0,0])
    def test_all_wealth_not_capacity(self):self.assertGreater(self.r['portfolios'][0]['score'][1],self.r['winner']['score'][1])
    def test_timing_restriction_matters(self):
        m=replace(self.m,cash=3)
        self.assertEqual(solve(m)['winner']['score'][0],1)
        self.assertEqual(solve_adaptive(m)['score'],[10,2])
    def test_adaptive_matches_main(self):self.assertEqual(solve_adaptive(self.m)['score'],[19,2])
    def test_independent_flexible_comparison(self):
        for c in (3,6,12):
            m=replace(self.m,cash=c)
            self.assertEqual(tuple(solve_adaptive(m)['score']),adaptive_forward(asdict(m)))
    def test_independent_sweep(self):
        for h in (2,4,6):
            for k in (1,2):
                for c in (6,12,18):
                    for r in (0,6,20):
                        m=replace(self.m,horizon=h,seed=k,cash=c,material=r)
                        for a in solve(m)['portfolios']:self.assertTrue(verify(a)['valid'])
    def test_repeatability(self):self.assertEqual(self.r,solve(self.m))
    def test_json_roundtrip(self):self.assertTrue(verify(json.loads(json.dumps(self.r['winner'])))['valid'])

class Boundaries(unittest.TestCase):
    def setUp(self):self.r=solve(Model())['winner']
    def bad(self,path,value):
        x=copy.deepcopy(self.r);p=x
        for key in path[:-1]:p=p[key]
        p[path[-1]]=value
        with self.assertRaises(ValueError):verify(x)
    def test_false_cash(self):self.bad(['rows',1,'after','cash'],999)
    def test_false_capacity(self):self.bad(['rows',1,'after','capacity'],999)
    def test_false_material(self):self.bad(['rows',1,'after','material'],999)
    def test_false_energy(self):self.bad(['rows',1,'energy_used'],0)
    def test_false_fabrication(self):self.bad(['rows',1,'fabrication_used'],0)
    def test_future_capacity_borrowed(self):self.bad(['rows',1,'energy_available'],99)
    def test_missing_service(self):self.bad(['rows',1,'legacy_service_delivered'],0)
    def test_future_cash_borrowed(self):self.bad(['rows',1,'before','cash'],99)
    def test_made_up_receipt(self):self.bad(['rows',1,'net_receipt'],99)
    def test_qualification_skipped(self):self.bad(['rows',0,'built'],1)
    def test_bad_final(self):self.bad(['final','capacity'],20)
    def test_truncated_trace(self):self.bad(['rows'],self.r['rows'][:-1])
    def test_reordered_trace(self):self.bad(['rows'],list(reversed(self.r['rows'])))
    def test_boolean_score(self):self.bad(['score'],[True,2])
    def test_boolean_quantity(self):self.bad(['rows',1,'built'],True)
    def test_float_quantity(self):self.bad(['rows',1,'built'],1.0)
    def test_negative_quantity(self):self.bad(['rows',1,'built'],-1)
    def test_model_changed(self):self.bad(['model','receipt'],3)
    def test_permission_changed(self):self.bad(['model','permit_fabrication'],False)
    def test_model_extra(self):
        m=asdict(Model());m['extra']=0
        with self.assertRaises(ValueError):Model.from_dict(m)
    def test_fee_changed(self):self.bad(['project_fee'],0)
    def test_intensity_changed(self):self.bad(['energy_intensity'],0)
    def test_invalid_final_shape(self):self.bad(['final'],[])
    def test_unknown_schema(self):self.bad(['schema'],'arbitrary')
    def test_invalid_portfolio(self):self.bad(['portfolio'],[True,1])
    def test_false_score(self):self.bad(['score'],[20,2])
    def test_bounded_model(self):
        with self.assertRaises(ValueError):Model(horizon=10000)
    def test_boolean_model_field(self):
        with self.assertRaises(ValueError):Model(cash=True)
    def test_unfunded_portfolio(self):
        with self.assertRaises(ValueError):solve_portfolio(Model(cash=3),(1,1))
    def test_no_gain_regression_project(self):
        with self.assertRaises(ValueError):Model(new_energy=3)

class PhysicalAccounting(unittest.TestCase):
    def test_nominal_power(self):self.assertEqual(ledger(.01)['intercepted_W'],3.828e24)
    def test_efficiency(self):self.assertAlmostEqual(ledger(.01)['gross_electric_W']/3.828e24,.3)
    def test_final_dissipation_includes_work(self):self.assertEqual(ledger(.01)['dissipated_W'],ledger(.01)['intercepted_W'])
    def test_geometric_area(self):self.assertAlmostEqual(ledger(.01)['projected_collector_m2']/(4*math.pi*AU**2),.01)
    def test_linear_coverage(self):self.assertAlmostEqual(ledger(.02)['emitting_area_lower_bound_m2']/ledger(.01)['emitting_area_lower_bound_m2'],2)
    def test_temperature_fourth_power(self):self.assertAlmostEqual(ledger(.01,300)['emitting_area_lower_bound_m2']/ledger(.01,600)['emitting_area_lower_bound_m2'],16,places=5)
    def test_area_mass(self):self.assertEqual(ledger(.01)['collector_mass_kg'],.1*ledger(.01)['projected_collector_m2'])
    def test_double_radius_area(self):self.assertAlmostEqual(ledger(.01,radius_au=2)['projected_collector_m2']/ledger(.01)['projected_collector_m2'],4)
    def test_emissivity_lower_requires_more_area(self):self.assertGreater(ledger(.01,emissivity=.5)['emitting_area_lower_bound_m2'],ledger(.01)['emitting_area_lower_bound_m2'])
    def test_invalid_coverage(self):
        with self.assertRaises(ValueError):ledger(1.1)
    def test_invalid_temperature(self):
        with self.assertRaises(ValueError):ledger(.01,temperature=2)
    def test_nan(self):
        with self.assertRaises(ValueError):ledger(float('nan'))
    def test_infinite(self):
        with self.assertRaises(ValueError):ledger(.01,radius_au=float('inf'))
    def test_invalid_efficiency(self):
        with self.assertRaises(ValueError):ledger(.01,eta=1.1)
    def test_boolean_fraction(self):
        with self.assertRaises(ValueError):ledger(True)
    def test_ideal_doublings(self):self.assertAlmostEqual(ledger(1)['ideal_doublings_from_1TW'],math.log2(L_SUN/1e12))
    def test_no_recovery(self):self.assertEqual(recycling_multiplier(0),1)
    def test_ninety_percent_recovery(self):self.assertAlmostEqual(recycling_multiplier(.9),10)
    def test_perfect_recycling_not_finite(self):
        with self.assertRaises(ValueError):recycling_multiplier(1)

if __name__=='__main__':unittest.main()
