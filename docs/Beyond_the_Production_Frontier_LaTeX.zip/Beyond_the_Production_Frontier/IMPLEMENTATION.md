# Proposed Alpha / SUCCESSOR Ω integration

**Find your Alpha. Build your SUCCESSOR Ω.**

Implementation target: https://github.com/MontrealAI/AGI-Alpha-Agent-v0

This is a design contract. No repository changes, model calls, payments, deployments, or releases are performed by this paper.

## Read-only starting snapshot

Commit `9c7484d05cd257c657276d52f274e085488e9dcc` was inspected on October 19, 2026. Its README and `docs/agent/SUCCESSOR_ALPHA.md` connect opportunity discovery, competing strategies, problem reframing, configured Computer Use, and retained project history. They distinguish browser preparation, observed proposals, actual execution, independent review, and payment authority.

This paper does not infer a general code executor, formal prover, physical operator, calibrated economy, or fully integrated settlement service from that documentation. Current software publication and the proposed capability-to-capacity study are separate claims.

## One bounded first mission

Given a public, nonpersonal computational workload with an independently checkable output contract:

1. Reproduce the incumbent and count its actual resources.
2. Identify an inherited restriction and construct an alternative within the same authority boundary.
3. Run the candidate and strong unrestricted baselines with comparable input rights, tools, knowledge, and resources.
4. Freeze a finalist; independently check fresh cases and the hypothesized mechanism.
5. Retain accepted capability with its prerequisites, counterexamples, and recovery conditions.
6. Demonstrate an additional authorized outcome using actually released resources, or separately observed surplus and commissioned capacity.

A negative or inconclusive result is valid. Requiring the experiment to win would undermine the evidence.

## Versioned task boundary: proposed `production-network/v1`

A generic adapter should validate the input model, resource units, outcome contract, admitted recipes and alternative proposals, lead times, construction actions, evaluator custody, resource/cash ledger, and recovery policy. An implementation should extend existing journal and project-history infrastructure rather than fork parallel trust and accounting systems.

A model proposal is data until admitted. It cannot redefine a physical coefficient as true, declare its own evaluator calibrated, expand its permissions, or transform a zero-money request into spending authority.

## Capability-to-capacity record

Each record needs the following fields, with explicit unknown values rather than fabricated numbers:

| Field group | Required substance |
|---|---|
| Purpose | Beneficiary, original outcome, nonnegotiable obligations, horizon, authority, and budget. |
| Formulation | Named incumbent, restriction, proposed changed process, and supplied versus discovered information. |
| Evidence | Source/artifact/model versions, independent checks, fresh conditions, failed attempts, and uncertainty. |
| Resource ledger | Time, compute, energy, material, human effort, external supplies, maintenance, and shared costs without double counting. |
| Economic record | Forecast, invoice, receipt, realized margin, reserve, and unencumbered cash as distinct states where relevant. |
| Capacity conversion | Recipient asset or released resource, construction/procurement action, commissioning test, useful throughput, and lead time. |
| Retention | Applicability scope, environmental dependencies, invalidation triggers, rollback/recovery, and parent lineage. |

## User journey

The main experience remains one mission: **Discover the restriction → construct the alternative → demonstrate the outcome → retain the capability → measure what it enables next**. The user should not have to supply the right strategy or know which inherited task can disappear before beginning.

A project should visibly distinguish proposed, constructed, executed, checked, accepted, paid, and commissioned results. Simulated credits and actual settlement must never share an unlabeled success state. A successful synthetic study remains inspectable before a financial route is activated.

## Ecosystem roles and safeguards

Alpha organizes discovery, experiments, construction, and capability retention. Jobs can commission bounded work and review under separately admitted terms. Fleet can provide qualified execution and transport retained evidence. These roles are proposed integration responsibilities, not evidence that every workflow has run.

Keep AGIJobManager's USDC route distinct from the Alpha / Jobs v0 AGIALPHA route. Real-wallet signing, funding, physical intervention, deployment, and authority changes require their own explicit approval. Preserve historical records, prior paper URLs, old request semantics, and existing security/release gates.

## Evidence required for an integration claim

One real configured-model mission, executed artifact, independent outcome checker, strong same-permission comparison, fresh confirmation, accurate cost record, interruption/recovery case, and a future case in which reuse should be declined. A commercial-conversion claim additionally needs actual accepted delivery and net receipts; a capacity claim needs measured commissioned throughput. Staged physical projects require qualified domain partners and separate evidence.
