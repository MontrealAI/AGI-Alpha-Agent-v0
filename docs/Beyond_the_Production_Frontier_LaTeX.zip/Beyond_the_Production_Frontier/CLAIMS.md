# Claim–evidence register

The primary object of invention is the problem-solving and production setup, not a favorable score or an authority change.

| Claim | Evidence | Limit |
|---|---|---|
| Non-substitutable resource consumption bounds output. | Proposition 3.1, direct conservation proof. | The bound is conditional on the stated recipes, resources, and comparison boundary. |
| From one seed module, the old or either single-project recipe cannot build a second module. | Proposition 4.1 and all three exact factorial arms. | Indivisible one-period construction, no stored residual flows, no outside purchase of finished modules. |
| The joint main portfolio reaches nineteen modules optimally. | Complete `capacity_certificate.json`; raw-record checker; independent forward enumeration; exact cash upper bound. | Supplied deterministic project effects and six abstract periods; not AI-invented physical processes or nineteen-fold wealth. |
| Six required service deliveries are retained. | Every period records one service; checkers reject omission. | Service and maintenance reservation are stipulated by the model, not measured on hardware. |
| A smaller treasury can bootstrap by waiting. | Three-unit flexible-procurement control reaches ten modules; independently enumerated optimum. | Receipts are modeled, fixed, and settled at period end; no actual finance or demand evidence. |
| Exact finite comparisons cover a useful set of changed assumptions. | Ten named controls; 54 configurations and 216 portfolio checks; three flexible cases. | Finite coverage, not independent discovery campaigns or natural-world generalization. |
| A scalable schedule can construct successive capacity increments within a domain. | Conditional expansion theorem and induction. | Must already have a feasible bootstrap, scalable admitted supplies, maintenance, and all required capacities. Not an unconditional growth law. |
| Ideas, profits, and installed capacity are different quantities. | Typed accounting and worked cash/capacity contrast. | No company valuation, revenue estimate, investment advice, or return forecast. |
| Stellar-scale energy handling implies explicit material and heat burdens. | `stellar_ledger.json`; IAU/CODATA inputs; equations and declared assumptions. | Ideal geometry, hypothetical areal masses, efficiency and temperature; no feasible hardware/orbital architecture established. |
| All locally absorbed energy ultimately dissipated locally belongs in the heat load. | Declared steady boundary and energy balance; regression check includes converted electrical energy. | Exported work/energy would require a different explicitly accounted boundary. |
| Recycling can multiply gross processing but not net stock. | Geometric upper bound and numeric sensitivity. | Assumed recovery model; no material creation or claim of lossless recycling. |
| The project is an implementation target. | Pinned Alpha README and guide; `IMPLEMENTATION.md`. | Proposed adapter is not implemented, qualified, merged, or released by this manuscript. |
| A better SUCCESSOR Ω discovery policy may improve future outcomes. | Six falsifiable hypotheses and matched-campaign design. | No model-driven or natural-workload superiority study is reported. |

## Not claimed

No frontier-model calls, algorithmic novelty for ordinary exact planning, measured throughput or energy savings, net-profit measurements, real contracts or settlements, physical production, autonomous replication, investment returns, completed Type II capability, or external peer review are reported. The companion makes no claim that a hash, signature, or passing test establishes a complete model of reality.

## Independence and supplied information

`checker.py` is separately written and does not import the optimizer. Its forward enumeration uses a different search direction and execution pattern, but shares the specified model and project authorship. The investigator supplies all recipes, project effects, receipts, stocks, and permissions. The strong flexible planner is permitted to alter procurement timing. A system that is not allowed to wait must not be presented as the best unrestricted comparator.
