import json
import os
from pathlib import Path

os.environ.setdefault('MPLCONFIGDIR', '/tmp/autonomous-enterprises-matplotlib')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from matplotlib.ticker import FuncFormatter, LogLocator, NullFormatter

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'figures'
D = json.loads((ROOT / 'data/figure-data.json').read_text())
PURPLE, TEAL, GOLD = '#5B2A91', '#187C80', '#B27C32'
INK, MUTED, LIGHT = '#241934', '#655D70', '#F4F0F8'
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10.5,
    'axes.labelsize': 10.5, 'xtick.labelsize': 10, 'ytick.labelsize': 10.5,
    'text.color': INK, 'axes.labelcolor': INK, 'axes.edgecolor': '#C8C2CE',
    'xtick.color': MUTED, 'ytick.color': MUTED, 'axes.spines.top': False,
    'axes.spines.right': False, 'pdf.fonttype': 42, 'ps.fonttype': 42,
    'svg.fonttype': 'none', 'svg.hashsalt': 'successor-capability-paper-v1',
    'figure.facecolor': 'white', 'axes.facecolor': 'white', 'savefig.facecolor': 'white'})


def save(fig, name):
    OUT.mkdir(exist_ok=True)
    fig.savefig(OUT / (name + '.pdf'), metadata={'Title': name, 'Author': 'MONTREAL.AI',
        'CreationDate': None, 'ModDate': None})
    fig.savefig(OUT / (name + '.svg'), metadata={'Title': name, 'Date': None})
    fig.savefig(OUT / (name + '.png'), dpi=160)
    plt.close(fig)


def title(fig, text, note=None):
    fig.text(.07, .957, text, fontsize=12.5, fontweight='bold', va='top', color=INK)
    if note:
        fig.text(.07, .902, note, fontsize=10.2, va='top', color=MUTED)


def lineage():
    fig = plt.figure(figsize=(6.8, 4.8))
    ax = fig.add_axes([.035, .11, .93, .76])
    ax.set(xlim=(0, 9.4), ylim=(0, 6.2)); ax.axis('off')
    title(fig, 'An accepted achievement becomes a reusable dependency',
        'Six retained assets support a distinct, locally accepted successor.')
    positions = {'identity1': (1.35, 5.4), 'walsh2': (4.1, 5.4), 'walsh4': (7.25, 5.4),
        'walsh8': (7.25, 3.85), 'convolution8': (1.35, 2.1),
        'inverse9': (4.45, 2.1), 'inverse11': (7.7, 2.1)}
    width, height = 2.45, .85
    def line(start, end):
        ax.add_patch(FancyArrowPatch(start, end, arrowstyle='-|>', mutation_scale=12,
            color=MUTED, linewidth=1.35, zorder=1))
    line((2.58,5.4),(2.87,5.4)); line((5.33,5.4),(6.02,5.4))
    line((7.25,4.96),(7.25,4.29))
    for node in ['convolution8','inverse9','inverse11']:
        x,y=positions[node]; line((7.25,3.40),(x,2.55))
    for node in D['lineage']['nodes']:
        x,y=positions[node['id']]; new=node['state']=='new-local-acceptance'
        ax.add_patch(FancyBboxPatch((x-width/2,y-height/2), width,height,
            boxstyle='round,pad=0.04,rounding_size=.08', facecolor=PURPLE if new else LIGHT,
            edgecolor=PURPLE if new else '#C7B6DB', linewidth=1.2,zorder=3))
        ax.text(x,y,node['label'],ha='center',va='center',fontsize=10.1,
            color='white' if new else INK, linespacing=1.38,zorder=4)
    ax.plot([1.35,1.35,7.7],[1.62,.58,.58], color=TEAL, linewidth=1.5,
        linestyle=(0,(4,3)),zorder=1)
    ax.add_patch(FancyArrowPatch((7.7,.58),(7.7,1.62),arrowstyle='-|>',mutation_scale=12,
        color=TEAL,linewidth=1.5,linestyle=(0,(4,3)),zorder=1))
    ax.text(4.45,.91,'Qualification reference only',ha='center',color=TEAL,fontsize=10.3,
        bbox={'facecolor':'white','edgecolor':'none','pad':2})
    fig.text(.07,.055,'Solid arrows: execution inheritance. Dashed arrow: a separate checking dependency.',
        fontsize=10.0,color=MUTED)
    save(fig,'01-capability-lineage')


def workloads():
    fig = plt.figure(figsize=(6.8, 4.7))
    ax = fig.add_axes([.18,.24,.75,.54])
    title(fig,'Reuse saves work; the supplied expert still wins')
    arms=[('rebuild-per-round','Rebuild each round',GOLD,'s'),
        ('retained-assets','Retain generated assets',PURPLE,'o'),
        ('competent-static-specialist','Supplied expert',TEAL,'D')]
    for arm,label,color,marker in arms:
        vals=[r['units'] for r in D['workload'] if r['arm']==arm]
        ax.plot(range(3),vals,color=color,marker=marker,lw=2.0,ms=6,label=label)
        for i,y in enumerate(vals):
            if i==0 and arm!='competent-static-specialist': continue
            offset = -15 if arm=='retained-assets' else 8
            ax.annotate(f'{y:,}',(i,y),xytext=(0,offset),textcoords='offset points',
                ha='center',va='top' if offset<0 else 'bottom',fontsize=10.5,color=color,
                bbox={'facecolor':'white','edgecolor':'none','pad':1})
    ax.annotate('57,196\n(tie)',(0,57196),xytext=(0,12),textcoords='offset points',
        ha='center',va='bottom',fontsize=10.3,color=INK,
        bbox={'facecolor':'white','edgecolor':'none','pad':1})
    ax.set_yscale('log'); ax.set_ylim(180,2200000); ax.set_xlim(-.22,2.22)
    ax.set_xticks([0,1,2],['3','12','48']); ax.set_xlabel('Sequential tasks (3 per round)',labelpad=8)
    ax.set_ylabel('Declared arithmetic-work units (log scale)',labelpad=10)
    ax.yaxis.set_major_locator(LogLocator(base=10)); ax.yaxis.set_minor_formatter(NullFormatter())
    ax.yaxis.set_major_formatter(FuncFormatter(lambda v,p:f'{v:,.0f}'))
    ax.grid(axis='y',which='major',color='#E4DEE9',linewidth=.7); ax.set_axisbelow(True)
    fig.legend(*ax.get_legend_handles_labels(),loc='upper center',bbox_to_anchor=(.55,.91),
        ncol=1,frameon=False,fontsize=10.3,labelspacing=.35)
    fig.text(.07,.078,'Construction, admission and checks are counted.\nMoney, human effort and energy remain unmeasured.',
        fontsize=10.0,color=MUTED,linespacing=1.35)
    save(fig,'02-workload-cost')


def changed():
    fig=plt.figure(figsize=(6.8,4.4)); ax=fig.add_axes([.14,.26,.80,.52])
    title(fig,'Full validation reverses the apparent saving')
    for off,key,label,color in [(-.19,'direct','Direct reference',GOLD),(.19,'inherited','Inherited reference',PURPLE)]:
        values=[D['changedKernel'][key]['selected'],D['changedKernel'][key]['fullCurrent']]
        bars=ax.bar([off,1+off],values,width=.34,color=color,label=label,zorder=3)
        for rect,v in zip(bars,values):
            ax.text(rect.get_x()+rect.get_width()/2,v+170,f'{v:,}',ha='center',va='bottom',
                fontsize=11,fontweight='bold',color=color)
    ax.set_xticks([0,1],['Selected construction\nand checking path','Full current construction\nand validation'])
    ax.tick_params(axis='x',length=0,pad=7); ax.set_ylim(0,9300);ax.set_xlim(-.58,1.58)
    ax.set_ylabel('Declared arithmetic-work units',labelpad=9)
    ax.yaxis.set_major_formatter(FuncFormatter(lambda v,p:f'{v:,.0f}'))
    ax.grid(axis='y',color='#E4DEE9',lw=.7);ax.set_axisbelow(True)
    fig.legend(*ax.get_legend_handles_labels(),loc='upper center',bbox_to_anchor=(.55,.90),ncol=2,
        frameon=False,fontsize=10.5)
    fig.text(.07,.078,'Changed kernel: (11,1,...,1).\nA further 7,886 child-admission units are charged separately.',
        fontsize=10,color=MUTED,linespacing=1.35)
    save(fig,'03-successor-cost')


def thermal():
    fig=plt.figure(figsize=(6.8,4.7)); ax=fig.add_axes([.27,.26,.66,.51])
    title(fig,'A separate observation exposes the hidden mismatch',
        'Numerical experiment with simulated acquisition; no physical calibration.')
    d=D['thermal']; ref=float(d['referenceHeatJ']); old=float(d['commandedHeatJ'])
    lo,est,hi=[int(d['witnessMicroJ'][x])/1e6 for x in ['low','estimate','high']]
    ax.axvline(ref,color=MUTED,lw=1.1,ls=(0,(4,3)),alpha=.7,zorder=1)
    ax.plot(old,3,'s',ms=7,color=GOLD,zorder=4)
    ax.annotate(f'{old:,.3f} J',(old,3),xytext=(-5,14),textcoords='offset points',
        ha='right',va='bottom',color=GOLD,fontsize=10.5)
    ax.plot(ref,2,'D',ms=6,color=INK,zorder=4)
    ax.annotate(f'{ref:,.3f} J',(ref,2),xytext=(8,0),textcoords='offset points',
        ha='left',va='center',color=INK,fontsize=10.5)
    ax.plot([lo,hi],[1,1],color=PURPLE,lw=7,alpha=.17,solid_capstyle='butt')
    ax.plot([lo,hi],[1,1],color=PURPLE,lw=1.7,zorder=3)
    ax.vlines([lo,hi],.90,1.10,color=PURPLE,lw=1.7)
    ax.plot(est,1,'o',ms=7,color=PURPLE,zorder=4)
    ax.annotate(f'{est:,.3f} J',(est,1),xytext=(0,13),textcoords='offset points',
        ha='center',va='bottom',color=PURPLE,fontsize=10.5)
    ax.text((lo+hi)/2,.57,f'[{lo:,.3f}, {hi:,.3f}] J',ha='center',va='center',
        color=PURPLE,fontsize=10.3)
    ax.set_yticks([3,2,1],['Commanded-flow\ncalorimeter','Numerical\nreference','Volume witness\n(simulated)'])
    ax.set_ylim(.25,3.55);ax.set_xlim(4880,5540);ax.set_xticks([4900,5100,5300,5500])
    ax.set_xlabel('Delivered heat (J)',labelpad=8);ax.tick_params(axis='y',length=0,pad=10)
    ax.spines['left'].set_visible(False);ax.grid(axis='x',color='#EEE9F1',lw=.7);ax.set_axisbelow(True)
    fig.text(.07,.10,'Witness bound: 1.8862% under the declared premises.',fontsize=10.3,color=PURPLE)
    fig.text(.07,.05,'Conditional deterministic interval; no confidence level is asserted.',
        fontsize=10,color=MUTED)
    save(fig,'04-thermal-witness')


def replay():
    fig=plt.figure(figsize=(6.8,4.4));ax=fig.add_axes([.27,.26,.62,.52])
    title(fig,'Replay dominates the observed controller work')
    c=D['controller']; vals=[c[x] for x in ['original','bundleReplay','futureReplay','successorReplay']]
    labels=['Original execution','Bundle replays','Future-treatment\nreplays','Successor replays']
    colors=[TEAL,'#936FB3',PURPLE,'#B5A2CD']
    bars=ax.barh([3,2,1,0],vals,height=.55,color=colors,zorder=3)
    for bar,v in zip(bars,vals):
        ax.text(v+19000,bar.get_y()+bar.get_height()/2,f'{v:,}',va='center',fontsize=10.7,color=INK)
    ax.set_yticks([3,2,1,0],labels);ax.tick_params(axis='y',length=0,pad=10)
    ax.set_xlim(0,1100000);ax.set_xticks([0,250000,500000,750000,1000000])
    ax.xaxis.set_major_formatter(FuncFormatter(lambda v,p:'0' if v==0 else f'{v/1000:,.0f}k'))
    ax.set_xlabel('Declared arithmetic-work units',labelpad=8)
    ax.spines['left'].set_visible(False);ax.grid(axis='x',color='#E4DEE9',lw=.7);ax.set_axisbelow(True)
    replay_sum=sum(vals[1:]); frac=100*replay_sum/c['total']
    fig.text(.07,.87,f'{frac:.2f}% replay  |  {c["total"]:,} total counted units',color=PURPLE,
        fontsize=11.3,fontweight='bold')
    fig.text(.07,.09,'Original construction, future tasks and successor work are charged once.',fontsize=10,color=MUTED)
    fig.text(.07,.045,'Human effort, money, energy and general maintenance are unmeasured.',
        fontsize=10,color=MUTED)
    save(fig,'05-controller-cost')


if __name__=='__main__':
    lineage();workloads();changed();thermal();replay()
    print('Created five PDF/SVG/PNG figure sets from retained data.')
