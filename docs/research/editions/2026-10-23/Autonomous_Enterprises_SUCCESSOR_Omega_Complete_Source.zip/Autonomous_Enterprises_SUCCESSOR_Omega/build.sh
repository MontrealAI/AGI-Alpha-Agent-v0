#!/bin/sh
# Build the complete paper from this directory. No experiments or chain access.
set -eu
paper_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$paper_dir"
if command -v latexmk >/dev/null 2>&1; then
  exec latexmk -xelatex -bibtex -interaction=nonstopmode -halt-on-error \
    Autonomous_Enterprises_Capability_Inheritance.tex
fi
xelatex -interaction=nonstopmode -halt-on-error Autonomous_Enterprises_Capability_Inheritance.tex
bibtex Autonomous_Enterprises_Capability_Inheritance
xelatex -interaction=nonstopmode -halt-on-error Autonomous_Enterprises_Capability_Inheritance.tex
xelatex -interaction=nonstopmode -halt-on-error Autonomous_Enterprises_Capability_Inheritance.tex
