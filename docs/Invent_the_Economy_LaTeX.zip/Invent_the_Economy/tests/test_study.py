from dataclasses import replace
from fractions import Fraction as F
from itertools import combinations, product
from pathlib import Path
import copy, json, subprocess, sys, tempfile, unittest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'experiments'))
from market_model import Buyer, Model, analyze, choose, certificate, minimum_buyers, maximum_route_cost, staged_reuse
from check_certificate import check, load_unique

class Study(unittest.TestCase):
    def setUp(self):
        self.bs=tuple(Buyer(f'b{i}') for i in range(4))
        self.m=Model(self.bs)
        self.names=tuple(b.name for b in self.bs)
    def plan(self,model=None):return analyze(model or self.m,self.names)
    def cert(self):return certificate(self.m,self.plan())
    def test_shared_four_expected(self): self.assertEqual(self.plan()['expected_margin'],120)
    def test_success_is_not_expectation(self): self.assertEqual(self.plan()['success_margin'],300)
    def test_common_failure_cost(self): self.assertEqual(self.plan()['failure_margin'],-600)
    def test_buyer_surplus(self): self.assertEqual(sum(self.plan()['buyer_surplus'].values()),192)
    def test_surplus_conservation(self): self.assertEqual(self.plan()['expected_total_surplus'],312)
    def test_development_and_delivery_financing(self):self.assertEqual(self.plan()['peak_financing'],900)
    def test_profitable_unfunded(self):
        a=self.plan(replace(self.m,available_cash=600));self.assertEqual(a['expected_margin'],120)
        self.assertIn('PREFUNDING_SHORTFALL',a['reasons']);self.assertFalse(a['admissible'])
    def test_joint_factorial(self):
        got=[choose(replace(self.m,shared_core=s,coordinated_commitments=c))['best_with_stop'] for s,c in product((False,True),repeat=2)]
        self.assertEqual(got,[0,0,0,120])
    def test_selected_four(self):self.assertEqual(choose(self.m)['winner']['coalition'],self.names)
    def test_all_subsets_retained(self):self.assertEqual(len(choose(self.m)['attempts']),15)
    def test_three_buyers_not_positive(self):self.assertEqual(analyze(self.m,self.names[:3])['expected_margin'],-60)
    def test_three_success_positive(self):self.assertEqual(analyze(self.m,self.names[:3])['success_margin'],75)
    def test_missing_commitment(self):
        m=replace(self.m,buyers=self.bs[:-1]+(replace(self.bs[-1],committed=False),))
        self.assertIn('UNCOMMITTED_BUYER',self.plan(m)['reasons'])
    def test_missing_rights(self):
        m=replace(self.m,buyers=self.bs[:-1]+(replace(self.bs[-1],shared_use_allowed=False),))
        self.assertIn('SHARED_USE_NOT_ADMITTED',self.plan(m)['reasons'])
    def test_participant_declines(self):
        m=replace(self.m,buyers=self.bs[:-1]+(replace(self.bs[-1],value=280),))
        self.assertIn('BUYER_PARTICIPATION',self.plan(m)['reasons'])
    def test_fee_10(self):self.assertEqual(self.plan(replace(self.m,route_cost=10))['expected_margin'],88)
    def test_fee_40_kills_market(self):self.assertEqual(self.plan(replace(self.m,route_cost=40))['expected_margin'],-8)
    def test_fee_threshold(self):self.assertEqual(maximum_route_cost(600,F(4,5),4,225),F(75,2))
    def test_threshold_four(self):self.assertEqual(minimum_buyers(600,F(4,5),225),4)
    def test_threshold_zero_probability(self):self.assertIsNone(minimum_buyers(600,F(0),225))
    def test_threshold_exact_break_even(self):self.assertEqual(minimum_buyers(450,F(1),225),3)
    def test_zero_setup_positive_unit(self):self.assertEqual(minimum_buyers(0,F(1),225),1)
    def test_zero_unit_no_viability(self):self.assertIsNone(minimum_buyers(0,F(1),0))
    def test_coordination_cost_counted(self):self.assertEqual(self.plan(replace(self.m,coordination_cost=120,available_cash=1020))['expected_margin'],0)
    def test_certificate_checks(self):self.assertTrue(check(self.cert())['admissible'])
    def test_checker_is_separate(self):
        text=(ROOT/'experiments/check_certificate.py').read_text();self.assertNotIn('from market_model',text)
    def test_mutate_revenue(self):
        c=self.cert();c['plan']['success_receipts']+=1
        with self.assertRaises(ValueError):check(c)
    def test_mutate_cash(self):
        c=self.cert();c['paths'][1]['balances'][2]+=1
        with self.assertRaises(ValueError):check(c)
    def test_omit_failure(self):
        c=self.cert();c['paths']=c['paths'][1:]
        with self.assertRaises(ValueError):check(c)
    def test_mutate_probability(self):
        c=self.cert();c['paths'][0]['probability']=[1,10]
        with self.assertRaises(ValueError):check(c)
    def test_live_acceptance_not_inferred(self):
        c=self.cert();c['live_acceptance']=True
        with self.assertRaises(ValueError):check(c)
    def test_authority_not_created(self):
        c=self.cert();c['authority_granted']=True
        with self.assertRaises(ValueError):check(c)
    def test_invalid_decision_rejected(self):
        m=replace(self.m,available_cash=600);c=certificate(m,self.plan(m));c['plan']['admissible']=True
        with self.assertRaises(ValueError):check(c)
    def test_duplicate_names(self):
        with self.assertRaises(ValueError):Model((Buyer('a'),Buyer('a')))
    def test_bool_cost_rejected(self):
        with self.assertRaises(ValueError):Buyer('a',price=True)
    def test_float_probability_rejected(self):
        with self.assertRaises(ValueError):replace(self.m,probability=.8)
    def test_out_of_range_probability_rejected(self):
        with self.assertRaises(ValueError):replace(self.m,probability=F(6,5))
    def test_unknown_coalition(self):
        with self.assertRaises(ValueError):analyze(self.m,('missing',))
    def test_duplicate_coalition(self):
        with self.assertRaises(ValueError):analyze(self.m,('b0','b0'))
    def test_nothing_is_an_available_option(self):self.assertIsNone(choose(replace(self.m,probability=F(0)))['winner'])
    def test_grid_2240(self):
        count=0
        for n,num,k,f,funded in product(range(1,9),range(1,6),(0,150,300,450,600,900,1200),(0,10,40,100),(False,True)):
            m=Model(tuple(Buyer(f'x{i}') for i in range(n)),development_cost=k,probability=F(num,5),
                    route_cost=f,available_cash=max(0,k+75*n-(not funded)))
            a=analyze(m,tuple(b.name for b in m.buyers))
            self.assertEqual(check(certificate(m,a))['admissible'],a['admissible'])
            self.assertEqual(a['admissible'],F(num,5)*n*(225-f)>k and m.available_cash>=k+75*n)
            count+=1
        self.assertEqual(count,2240)
    def test_common_failure_not_diversified(self):self.assertEqual(self.cert()['paths'][0]['probability'],[1,5])
    def test_second_positive_but_unfunded(self):
        r=staged_reuse(next_development=300);self.assertEqual(r['second']['expected_margin'],60)
        self.assertFalse(r['second']['admissible']);self.assertEqual(r['expected_contribution'],120)
    def test_earned_surplus_funds_reuse(self):
        r=staged_reuse(next_development=150);self.assertEqual(r['earned_cash'],300)
        self.assertTrue(r['second']['admissible']);self.assertEqual(r['second']['peak_financing'],300)
    def test_staged_exact_expectation(self):
        r=staged_reuse(next_development=150);self.assertEqual(r['expected_terminal_cash'],1188)
        self.assertEqual(r['expected_contribution'],288)
        self.assertEqual([x['terminal_cash'] for x in r['paths']],[300,1050,1500])
    def test_staged_probability_mass(self):self.assertEqual(sum(x['probability'] for x in staged_reuse()['paths']),1)
    def test_weak_second_project_declined(self):self.assertFalse(staged_reuse(p2=F(1,5))['second']['admissible'])
    def test_artifact_cli(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'record.json';p.write_text(json.dumps(self.cert()))
            r=subprocess.run([sys.executable,str(ROOT/'experiments/check_certificate.py'),str(p)],capture_output=True,text=True)
            self.assertEqual(r.returncode,0,r.stderr);self.assertTrue(json.loads(r.stdout)['valid_model_record'])
    def test_duplicate_json_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'bad.json';p.write_text('{"x":1,"x":2}')
            with self.assertRaises(ValueError):load_unique(str(p))
    def test_regenerated_results_match(self):
        before={p.name:p.read_bytes() for p in (ROOT/'results').glob('*.json')}
        r=subprocess.run([sys.executable,str(ROOT/'experiments/run_study.py')],capture_output=True,text=True)
        self.assertEqual(r.returncode,0,r.stderr)
        self.assertEqual(before,{p.name:p.read_bytes() for p in (ROOT/'results').glob('*.json')})

if __name__=='__main__':unittest.main()
