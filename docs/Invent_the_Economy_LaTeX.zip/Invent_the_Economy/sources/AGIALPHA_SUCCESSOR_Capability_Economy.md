# $AGIALPHA × SUCCESSOR Ω
## A productive-capability economy, not a price-dependent funding loop

**MONTREAL.AI · Proposed economic and implementation design · 19 October 2026**

**Project:** https://github.com/MontrealAI/AGI-Alpha-Agent-v0

> Build intelligence that discovers which restrictions are unnecessary, constructs a better way forward, and leaves behind a capability that someone will use again.

The strategic objective is to make $AGIALPHA useful in a network that commissions, checks, and supplies those capabilities. The network should create value for customers who have no interest in token appreciation. Reinvesting a conservative portion of actual earned surplus can then expand the productive capacity available to later SUCCESSOR Ω missions.

This is a proposed design plus an executed arithmetic laboratory. It does not amend token-holder rights, activate a service, change token supply, create an investment product, or guarantee adoption, profitability, token value, superintelligence, or stellar-scale infrastructure.

## 1. The different game

A price-dependent formulation asks how a token can attract enough buyers to finance an increasingly ambitious story. The proposed formulation asks what valuable capability customers need, which bottleneck prevents its delivery, and how the native token route can coordinate accountable delivery better than the alternatives.

The product is not an unlimited population of agents or a large volume of paid actions. It is a **maintained capability**: an algorithm, solver, tested software tool, evidence-producing workflow, or independently reproducible investigation that meets a declared need. A transformation may eliminate recurring actions, invent a different experiment, or enable an outcome previously infeasible within the budget.

Every new mission compares at least the incumbent, a strong unrestricted alternative with the same tools and budget, and the proposed structural change. An explanation of a new formulation does not count as its execution. A successful prototype does not automatically qualify reuse on another task.

The economic test is equally direct: would a customer still pay for the deliverable while expecting the token's market price to remain flat? Can the service continue when token issuance, grants, and self-funded promotional transactions no longer count as recurring revenue?

## 2. What the inspected project does and does not establish

The main branch observed in this work was `b44ba296e00500c91c1617fc942b5f0050ceabd6`. Its README identifies the canonical token as `0xA61a3B3a130a9c20768EEBF97E21515A6046a1fA`, with 18 decimals. It distinguishes the Manager USDC settlement route from the Alpha / Jobs v0 AGIALPHA routes. It also distinguishes free browser preparation, configured execution, review, and settlement. [S1]

The current deployment guide records an October 18 five-contract Ascension suite and names deployed-source revision `c0fc5217e364a39a4cd123d17a8317c06b80f820`. The guide explicitly states that activation and public funding are not approved and that there is no global pause. This design preserves that boundary; it is not an activation instruction. [S2]

The inspected deployed-source `AscensionJobMarket` uses a 500-basis-point review pool, split between two approving reviewers, and burns `floor(gross / 100)` from each actual payout. `_pay` distributes worker/reviewer payouts and refunds; it does not make a separate automatic allocation to a company-wide reinvestment pool. [S3]

For an accepted price of exactly 100 AGIALPHA, the arithmetic is 94.05 to the worker, 2.475 to each of the two approving reviewers, and 1 burned. Tiny amounts have integer rounding. These numbers describe that payment path, not net profit, investor distributions, or every fee rule elsewhere in the ecosystem. A company may earn revenue by actually being a qualified payee under a real service agreement; merely operating a repository does not create a payment claim.

Ascension MARK funding is plan-restricted; funding lots, job escrow, remaining refunds, worker receipts, and enterprise cash are distinct objects. The documentation describes no general treasury withdrawal. Customer principal must not be relabeled as company surplus. [S4]

The underlying token's complete administration, minting, proxy, distribution, custody and liquidity conditions were not audited in this work. An explorer fetch was unavailable; no current supply, ownership concentration, market price or market depth is asserted.

## 3. Give the token concrete roles—and do not invent holder rights

### Native commissioning and settlement

Keep AGIALPHA as the native settlement asset of its existing admitted route. A mission quote names the exact deliverable, acceptance conditions, provider and reviewer roles, due dates, total native-token amount, and all fees. Any fiat display is informational and time-bound; it is not a guaranteed redemption value. Funding, conversion and signatures require their existing independent authority.

Providers must explicitly accept native-token exposure, or separately arrange a lawful, executable, risk-controlled means to cover external costs. Do not imply that an escrowed number of AGIALPHA will always buy a fixed amount of external compute. Do not introduce a hidden subsidy from the USDC route.

### Actual service obligations, not idle-token yield

Existing participant bonding can support an admitted native job, subject to the actual contract. A bond is neither evidence of competence nor a complete insurance policy. Work assignment also needs qualified capability, conflict checks, capacity limits, current identity/admission, and inspectable results.

Do not add an automatic yield for merely holding or locking tokens. A provider earns compensation for an actual service. A separately commissioned reviewer earns compensation under disclosed terms for real review, including substantiated negative findings where the selected contract supports that compensation. The existing Ascension payout logic is not changed by this proposal; it must not be advertised as having a new review-fee scheme that has not been implemented.

Native-token collateral can lose purchasing power with demand. Admission should therefore limit exposure and require separately available operating resources for external obligations. Supplementary reserves or new bond assets would require separate architecture, economic review, and authorization—not a reinterpretation of deployed storage or old permissions.

### Capability services, not an open-source tollbooth

Offer bounded services around retained capabilities: qualified execution, fresh independent review, maintenance, recovery, support, or reserved delivery capacity. Preserve public research, free exploration and existing open-source license rights. Do not charge a token toll merely to download code already publicly licensed.

A service reservation is a capacity-backed contract with a provider, term, quantity, cancellation conditions and delivery limits. It is not an unlimited promise attached to every token in circulation. No new tradable receipt or secondary token is required for the pilot.

### Holder rights

The design grants no equity in the parent company, automatic dividends, intellectual-property ownership, rights to customer deposits, or ownership of infrastructure. Owning an NFT commitment or token does not by itself transfer an artifact's copyright or commercial license. A capability must name its actual rights holder and granted license.

Financial participation in future separately governed ventures would be a separate product with explicit rights, liabilities and jurisdiction-specific legal review. Calling a token useful does not determine whether an offering involves securities. [S5–S7]

## 4. The missing link is real value capture

Separate three ledgers:

| Ledger | What it demonstrates | What it cannot imply on its own |
|---|---|---|
| Customer outcome | A required outcome, measured benefit or accepted capability | Revenue, profitability or universal correctness |
| Enterprise economics | Earned external receipts, all costs, reserves and free cash | Token-holder equity or guaranteed appreciation |
| Native token operations | Actual native fees, settlement, outstanding obligations, locks and burns | External demand, recurring operating profit or a price floor |

A larger ecosystem can succeed while its token price falls. More transactions can coexist with zero net external demand. A token can circulate quickly enough that useful throughput grows without a proportional increase in standing balances. Therefore, **throughput, token demand, and valuation must not be equated**.

A bookkeeping relationship, not a valuation formula, is:

`operating balances ≈ average native settlement flow × average holding duration + native capital genuinely committed to active obligations`.

Specify consistent time/asset units, avoid counting escrow in both terms, and disclose concentration and turnover. Fees paid and immediately sold can offset new acquisition. Bonds must be sized for a real service risk, not chosen to fabricate scarcity.

The current burn is a settlement rule to disclose, not the engine of the business. Raising burn or inducing circular volume is not the recommended transformation. Provider compensation, quality and affordability take priority over a deflationary headline.

## 5. Make reuse economically valuable

The first useful capability can be expensive to discover. A retained, validated version may cost less to execute for a later customer. Charge the second customer for the useful service actually delivered—not for pretending to repeat the original research.

The advantage must survive the complete lifecycle: discovery, failed attempts, implementation, verification, licensing, maintenance, support, requalification, external compute, conversion, and human effort. Reuse outside its valid scope must be refused or investigated again.

A capability registry should retain the original restriction, the realized alternative, the executable artifact and source identity, the outcome evidence, the license, the compatible environment, known failure conditions, the cost record, and the next review date. A successor earns a new claim on new evidence; it does not inherit approval merely from a parent identity.

This changes the supply-side objective from maximizing paid agent activity to lowering the cost of achieving a maintained result. Lower delivery cost can benefit customers and operators simultaneously. The protocol should not require more wasteful activity to earn more fees.

## 6. An earned-surplus reinvestment rule

Evaluate each operating entity and the consolidated network, so internal transfers cannot masquerade as external economic progress. Count a customer receipt once. Report related-party demonstrations separately without publishing personal identities.

For the reference cash model, define:

- `R`: actually collected, earned, unrestricted external service cash in one declared numeraire, after conversion costs if converted from AGIALPHA;
- `C`: cash already paid for that period's service costs;
- `L`: new unpaid service liabilities, disjoint from C;
- `V`: new support/refund/tax or other reserves not already counted in C or L;
- `B0`: opening unrestricted cash after pre-existing restrictions and liabilities;
- `Bmin`: a separately chosen minimum cash buffer.

Then:

`earned_surplus = R − C − L − V`

`cash_above_commitments = B0 + R − C − L − V − Bmin`

`eligible_earned_reinvestment = max(0, min(earned_surplus, cash_above_commitments))`.

This is a conservative proposed policy, not financial reporting advice or a universal definition of profit. The opening cash can provide a legitimate seed. Initial capitalization, grants and lawfully raised external funds may finance separately approved experiments, but they are not proof of a self-funding service loop. Existing client escrow, marked token inventory, unrealized savings, internal transfers and token-sale proceeds are excluded from the **earned-service** reinvestment metric.

The rule is meaningful only if inputs are true, classifications are sound, currencies are consistent and no liability is omitted. It cannot audit those premises. No estimated conversion becomes cash merely because an oracle provides a price.

### Executed illustrative cases

The base case assumes 5,000 units of external earned cash, 3,400 already paid service costs, 300 new liabilities, 300 reserves, and a 2,000-unit opening cash/buffer. Eligible earned reinvestment is 1,000. A proposed investment of 600 fits, leaving 400 of additional headroom.

A 50% increase in paid service costs produces a 700-unit loss and zero earned reinvestment. A 30% fall in earned receipts also stops reinvestment. Adding one million units of own-token marked inventory or refundable escrow does not enlarge the budget. One million units of token-sale cash without external earned service receipts still establishes no service-funded reinvestment.

A separate price-sensitivity illustration uses 94.05 worker tokens, assumed initial unit price 1, and external cost 60. At a flat price, the estimated margin before conversion cost is 34.05. At a 90% price decline, it is −50.595. Neither is recognized cash. This illustrates native quote exposure; it forecasts no market outcome and assumes no executable liquidity.

These are supplied synthetic assumptions and arithmetic outcomes. The companion executes 11 cash cases, three native-price sensitivities and exact integer payout arithmetic. They are not business results or a whole-economy simulation.

## 7. The first product: one retained capability, multiple independent uses

The initial offer should be a bounded public-input capability mission for a buyer with a measurable need. Prefer a reusable software or computational improvement with a domain-specific checker over an open-ended promise to solve every kind of work.

The intended user path is:

`Describe the outcome → inspect alternatives → choose a bounded experiment → approve a native quote → execute → inspect independent evidence → settle under admitted terms → retain the capability → test reuse on a new case`.

No account, token balance or wallet should be needed merely to read the research or explore a free planning example. Show the token quote only when a funded service is relevant. Show exactly what is being bought: artifact, run, review, maintenance period, or capacity reservation.

For the first pilot, propose three paid missions from genuinely separate external beneficiaries after commissioning. This is an operating milestone, not statistical proof of market fit. At least one retained capability must be used on a new workload with preserved correctness and useful cost. The third-party benefit must be measured or explicitly remain unknown; a sub-millisecond isolated function gain is not automatically a flagship commercial result.

All costs, failed attempts, refunds, commissions and operator time must remain visible. Report customer satisfaction and repurchase separately from token transfers. Only a completed native-route transaction, with the actual economic and review identities verified, should be labeled AGIALPHA-settled.

## 8. Comparison that can reject our preferred story

A/B the native offering against a matched stablecoin-only service outside the AGIALPHA-only contracts. Same outcome, quality, fulfillment limits and total budget; each route retains its actual permissions and code. Compare net user cost, successful delivery, review cost, disputes, renewal, provider net receipts and operator effort. The counterfactual does not authorize swapping settlement assets inside a deployed contract.

The token mechanism must earn its overhead. A blockchain payment route that adds fees, volatility, delays and compliance burden without compensating coordination value should be simplified or rejected. The native route's value may be cross-provider settlement and accountability, but that advantage must be demonstrated rather than assumed.

Useful sensitivity cases include weak external demand, aggressive provider selling, falling token prices, rising compute cost, expensive review, collaborator conflict, failed delivery, missing quorum, withdrawn liquidity and changed capability validity. No pass on a toy model proves these real conditions are controlled.

## 9. Implementation target and boundary

Use the existing AGI Alpha Agent / SUCCESSOR project, not a competing token or a new parent company. Preserve the known division: Alpha discovery/development, Jobs bounded commissioning/review, Fleet qualified execution, and separate settlement adapters. [S1]

Prepare an additive proposal on the next coordinated reviewed source, not the frozen release candidate. The following module names are proposed boundaries, not claims that they exist:

| Proposed component | Function |
|---|---|
| `capability_service_manifest` | Outcome, artifact, rights, validity, provider capacity and checker |
| `native_service_quote` | Fixed native amount, fees, quote expiry, exact scope and exposure acknowledgment |
| `settlement_outcome_link` | Bind the accepted artifact, review and actual native receipt without double counting |
| `earned_surplus_policy` | Reconcile earned external cash, liabilities, reserves and permissible proposed reinvestment |
| `reuse_evaluation` | Compare valid retained capability with the best relevant alternative on new inputs |
| `economic_status_view` | Plain-language EN/FR supported scope, delivered outcomes, costs and explicit unknowns |

Start with native inspection and disposable fixtures. Do not change existing fee constants, mint authority, token address, ENS policies, old releases, deployed contracts, funding lots, treasury rights or zero-allowance request semantics. No new token is needed to test this product thesis.

Before funding, the existing source, dependency, security, installed package, real-provider, review, token-behavior and participant gates still need completion. Current source publication is not that completion. The economic pilot must have a separate actual authorization and a lawful operating model. New financial rights or products require their own design review; no label in a generated JSON is permission.

## 10. From digital capabilities to physical capacity

The long-horizon ambition is a succession of earned capabilities, not a projection from token capitalization to engineering achievement. First demonstrate a useful computational improvement and repeated external adoption. Then justify additional qualified compute or test equipment through actual service needs and conservative financing. Later physical experiments require competent domain partners, measurement, rights and separate operational controls.

Energy, materials, manufacturing, transport, heat rejection, maintenance and lead time are physical constraints to investigate, not quantities that disappear when an asset is repriced. Physical partnerships and separately governed ventures can be necessary. Owning a token does not create authority over other participants or a civilization.

At every transition ask what restriction is genuinely binding; which compatible combination could remove it; what test discriminates it; who benefits; what costs are shifted; and what new capability has actually been commissioned. The stellar-scale endpoint remains a research motivation, not a funding promise, valuation target or timeline.

## 11. Milestones and stop conditions

**Before a live pilot:** exact-source release qualification; verified native-token behavior and authority inventory; independent provider/reviewer commissioning; jurisdiction-specific legal review; explicit service terms; bounded costs and reserves; no client-principal reuse.

**First acceptance:** one real external customer receives one independently accepted artifact through the native route. Record settlement separately from realized cash and commercial benefit.

**Repeatability:** new external use of a retained capability, with full costs counted, preserved outcomes, and no reliance on speculative price gains or internal transactions. Three pilot missions are a useful checkpoint, not a statistically sufficient superiority study.

**Reinvestment:** only genuinely available, authorized resources are committed; customer/refund obligations and safety buffers remain covered. Stop new campaigns when the funded plan is no longer feasible. Do not spend more to manufacture a positive token-demand story.

**Capacity expansion:** the acquired resource is installed, checked and shown to improve subsequent mission outcomes. An order, treasury balance or purchased token is not installed capacity.

## 12. The public message

> **$AGIALPHA × SUCCESSOR Ω: turn verified intelligence into capabilities people can use—and use earned results to build what becomes possible next.**

Describe intended utility and actual evidence. Do not state that buyers own the company, hold a claim on all machine-created wealth, will earn passive yield, or are guaranteed an increase in token value. Promotion itself can affect the legal analysis of an offering; counsel must assess rights, conduct and representations together. [S5–S7]

## Sources and evidence scope

**S1.** AGI Alpha Agent README, inspected main `b44ba296e00500c91c1617fc942b5f0050ceabd6`; source blob `1f65ee5a12cc36891dae9bab76424ff027b8105b`.
https://github.com/MontrealAI/AGI-Alpha-Agent-v0/blob/b44ba296e00500c91c1617fc942b5f0050ceabd6/README.md

**S2.** Current Mainnet deployment guide, source blob `35d7bb1c602f6c97d4dbc20ef76dee988a66776d`; point-in-time deployment/authority record, not a newly performed chain audit.
https://github.com/MontrealAI/AGI-Alpha-Agent-v0/blob/b44ba296e00500c91c1617fc942b5f0050ceabd6/docs/agent/CURRENT_MAINNET_DEPLOYMENT.md

**S3.** AscensionJobMarket deployed-source snapshot, `VALIDATOR_BPS=500`, `_pay`, `_payout`; blob `a50a5cc584ccb6c096c6df6aa862aa48d27d9ffe`.
https://github.com/MontrealAI/AGI-Alpha-Agent-v0/blob/c0fc5217e364a39a4cd123d17a8317c06b80f820/contracts/ascension/AscensionJobMarket.sol

**S4.** Ascension protocol guide, including settlement/namespace separation, MARK funding and refund restrictions; source blob `06ed3e0440b8462eff5454c3e0ed84ede614b540`. This is a documented reference protocol containing historical sections and local examples; later code or deployment qualification must not be inferred from those examples.
https://github.com/MontrealAI/AGI-Alpha-Agent-v0/blob/b44ba296e00500c91c1617fc942b5f0050ceabd6/docs/agent/ASCENSION_PROTOCOL.md

**S5.** Canadian Securities Administrators, *Canadian securities regulators provide additional guidance on securities law implications for offerings of tokens*, June 11, 2018; accessed October 19, 2026. Guidance explicitly includes tokens described as utility tokens.
https://www.securities-administrators.ca/news/canadian-securities-regulators-provide-additional-guidance-on-securities-law-implications-for-offerings-of-tokens/

**S6.** Autorité des marchés financiers, *Initial cryptoasset offerings*, accessed October 19, 2026. Discusses potential token rights, volatility, early-stage risk, and possible securities/prospectus requirements.
https://lautorite.qc.ca/en/general-public/investments/crypto/initial-cryptoasset-offerings

**S7.** CSA Staff Notice 46-308, *Securities Law Implications for Offerings of Tokens*, June 11, 2018; current regulator index checked October 19, 2026. Listing is not a project-specific classification or legal opinion.
https://lautorite.qc.ca/en/professionals/regulations-and-obligations/securities/4-distribution-requirements-41-101-a-46-201/csa-notice

The reference program, scenario outputs and tests are newly generated local artifacts. No independent external auditor or qualified legal professional reviewed them. No private credentials or personal data were used. No repository, PR, release, token, wallet, contract or external account was changed.
