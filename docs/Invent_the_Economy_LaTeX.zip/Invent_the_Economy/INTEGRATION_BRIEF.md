# Proposed Alpha / SUCCESSOR Ω increment

This is an additive research handoff, not deployed software. It is based on the pinned README at `b44ba296e00500c91c1617fc942b5f0050ceabd6`; it does not infer the status of later commits.

## One mission identity, separate evidence states

Use the existing project journal and history instead of a second incompatible archive. Keep the following states semantically distinct:

`investigation → proposed technical package → modeled feasibility → actual accepted arrangement → separately authorized execution → independently accepted delivery → reconciled settlement → fresh reuse`

An imported record cannot restore approval. The certificate in this pack is explicitly `synthetic-model-only` with no live acceptance or authority.

## Proposed module responsibilities

| Boundary | Responsibility |
|---|---|
| `economic_possibility` | Purposes, baseline restrictions, candidates, buyer-specific requirements, and uncertainties. |
| `capability_commonality` | Evidence of shared structure and independent adaptation checks. |
| `arrangement_feasibility` | Participation, resources, rights, full cash prefixes, and explicit risks. |
| `counterparty_evidence` | Interest versus proposed terms versus actual authorized acceptance and performance. |
| `realization_ledger` | External receipts, costs, liabilities, reserves, and exact settlement links. |
| `native_route_comparison` | Added coordination value versus added burden on a matched service. |
| `successor_market_reuse` | Conditional capability, fresh beneficiary and environment, maintenance, rollback, and retirement. |

Names are proposed boundaries, not existing-file assertions. The reference calculator is not a production account system and must not be integrated by simply removing its synthetic labels.

## Boundaries to preserve

Maintain the original task outcomes, existing open-source rights, supported input rules, current security and review gates, exact-source release qualification, and explicit spending/operating authorizations. The main AGIJobManager USDC route and Alpha / Jobs v0 AGIALPHA routes remain distinct.

No mint/burn/fee constants, token administration, holder rights, collateral terms, ENS policies, deployed contract storage, historical releases, or paper URLs change. No new token is required. Existing mission types and zero-allowance semantics keep their original meaning.

## Acceptance of an implementation

Require ordinary full-module tests, actual isolated execution, a domain-specific independent checker, bounded interruption/recovery, installed-package evidence, and a clear English/French project view before making corresponding product claims. A model-generated commercial offer must require authorized confirmation before external communication or commitment.

The first external pilot must complete its own participant, economic, and legal admission. The research package makes no release or production recommendation for a particular current PR.
