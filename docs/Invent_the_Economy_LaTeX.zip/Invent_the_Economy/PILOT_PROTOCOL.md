# A natural joint-capability / arrangement campaign

**Proposed protocol. Not an executed commercial pilot, investment offer, or authorization.**

## Research question

Can Alpha discover a technical construction and an accepted commercial arrangement that jointly make previously unserved requirements economically realizable, under the original outcome obligations and a fully accounted budget?

A completed business plan is not the endpoint. The positive endpoint is an executed capability, independently accepted delivery, actual economic evidence, and a fresh adoption. A valid negative result documents why no admitted package deserves execution.

## Choose the case before selecting the preferred transformation

Use an independently selected family of public, synthetic, or explicitly licensed nonpersonal computational workloads. Seek several real beneficiaries with related structure but distinct requirements. Do not supply a hidden winning method and later describe it as autonomous discovery.

Possible territory includes shared numerical kernels, verified software transformations, reproducible scientific computation, and maintained evidence-producing tools. These are task families, not commitments that a specific method or market exists. Do not treat a visible code repository as a customer, and do not access personal data, credentials, inboxes, or private customer systems through the public-input pilot.

## Admission record

Record each beneficiary's independently specified outcome, baseline, acceptance checker, deadline, rights, affordability limit, and permitted public source. Distinguish nonbinding interest, a conditional offer, an accepted contract, funding, performance, and settlement.

The sponsor names the resource budget, maximum tolerable loss, approved expenditure stages, reviewer independence, operator-time budget, and the person authorized to accept commercial terms. Do not infer these values from the paper's synthetic examples.

## Preserve serious alternatives

Evaluate the incumbent and strong technical/commercial alternatives. Include an unrestricted agent that may reframe, coordinate buyers, change funding timing, and reuse capabilities within the same permissions. Include capable human technical/commercial teams where feasible, reporting their complete effort.

For mechanism diagnosis, cross technical-capability mutability with commercial-arrangement mutability. Restricted arms diagnose complementarity; they are not the sole competitive baselines. Supplying a discovered method to another solver is a separate diagnostic, not evidence that the original solver discovered it.

## Stage 1 — diagnose the joint restriction

Map what each buyer needs to what must be constructed, checked, licensed, funded, and delivered. Identify a specific obstruction rather than an abstract desire for growth. Preserve hard requirements. An unknown constraint is not automatically removable.

Output a proposed economic-possibility package: technical candidate, counterparty set, arrangement, financing schedule, rights, and evidence obligations. Unknowns remain unknown. An empty commercial assumption must not become a confident estimated price.

## Stage 2 — run a bounded technical experiment

Construct a candidate with separately approved execution. Test the shared core and every buyer-specific adaptation against independent checks. Count unsuccessful search, setup, verification, integration, and operator effort. Distinguish a generic shared method from the four different developments hidden behind a common API.

A known standard solver is allowed to win. Record implementation novelty, novelty to the agent, and scientific novelty separately. New model proposals do not grant source-execution or provider-access permission.

## Stage 3 — establish actual counterparty and financing evidence

Obtain real acceptance of the precise commercial terms from authorized parties. State what happens on technical failure, buyer withdrawal, delayed acceptance, missing input rights, default, or partial delivery. Identify any right to share or license the common construction.

Make a time-indexed cash ledger including development, adapters, review, support, refunds, reserves, taxes/fees where applicable, and the permitted source of each advance. Conditional purchase receipts payable on acceptance do not fund earlier delivery costs. No refundable customer principal is treated as unrestricted surplus.

External investment, a grant, genuine supplier credit, or an advance can be legitimate funding, but each must remain labeled and costed. Seek the appropriate professional review for financing and procurement arrangements; the reference formula supplies none of that advice.

## Stage 4 — freeze and confirm

Freeze candidate source, model/environment identity, comparator resources, acceptance instrument, claims, budgets, and confirmation cases. Retain all confirmatory attempts. Coalition-wide common risks cannot be treated as independent buyer trials.

A changed purpose or evaluation instrument needs a separately authorized comparison. Code identity proves neither usefulness nor counterparty consent.

## Stage 5 — deliver and reconcile

Run the admitted service. Obtain independent acceptance, actual receipts, and a complete liability/cost reconciliation. Verify actual asset, network, amount, and beneficiary for any native settlement. Report native receipts separately from realized cash or purchasing power. Do not convert an exchange quote into cash that was never received.

The first positive result supports one exchange, not market fit. A paid invoice does not establish recurring profit or token appreciation.

## Stage 6 — test independent reuse

Admit a new beneficiary and fresh workload. Retain a protected reserve and check the second project's full prefunding requirement, not only its expected margin. Validate input/output contracts, licenses, technical scope, and maintenance needs.

Count the previous discovery cost once across the appropriate lifecycle and give comparisons matched starting libraries. Do not obtain a second revenue claim by replaying an internal demonstration.

## Native-route comparison

Only use already admitted routes with their actual assets and authority boundaries. Compare the complete native burden and benefit with a matched alternative outside AGIALPHA-only contracts. Measure cost, fulfillment, review effort, disputes, retention, and real working commitments. No token purchase, issuance, buyback, new lock requirement, or fee change is authorized by this protocol.

## Report

Publish, with permission, what was supplied by investigators; what the system proposed; what it executed; what counterparties actually accepted; why the common capability mattered; what capital was at risk; what happened on each relevant branch; and whether independent reuse worked. Preserve negative results and unknown costs.

The research must be able to conclude that a viable business was found but the native route added no benefit—or that the native route was useful without supporting a token-valuation claim.
