"""Regenerate deterministic rational reference results. No network, provider, or wallet."""
from __future__ import annotations
from dataclasses import replace
from fractions import Fraction
from itertools import product
from pathlib import Path
import json
from market_model import Buyer, Model, analyze, choose, certificate, minimum_buyers, maximum_route_cost, staged_reuse, wire
from check_certificate import check

ROOT=Path(__file__).resolve().parents[1]

def dump(name, value):
    (ROOT/'results'/name).write_text(json.dumps(wire(value),ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')

def main():
    (ROOT/'results').mkdir(exist_ok=True)
    buyers=tuple(Buyer(f"buyer-{i+1}") for i in range(4))
    base=Model(buyers)
    factorial=[]
    for shared,coordinated in product((False,True),repeat=2):
        m=replace(base,shared_core=shared,coordinated_commitments=coordinated)
        r=choose(m)
        for a in r['attempts']: check(certificate(m,a))
        factorial.append({'shared_core':shared,'coordinated_commitments':coordinated,
                          'best_expected_contribution':r['best_with_stop'],
                          'winning_buyers':None if r['winner'] is None else r['winner']['coalition'],
                          'attempts_checked':len(r['attempts'])})
    winner=choose(base)['winner']
    c=certificate(base,winner)
    check(c)
    dump('formation_certificate.json',c)
    table=[]
    for n in range(1,5):
        a=analyze(base,tuple(b.name for b in buyers[:n]))
        table.append({'buyers':n,**a})
    negatives={}
    variants={
        'unfunded_delivery':replace(base,available_cash=600),
        'one_missing_commitment':replace(base,buyers=buyers[:-1]+(replace(buyers[-1],committed=False),)),
        'shared_license_missing':replace(base,buyers=buyers[:-1]+(replace(buyers[-1],shared_use_allowed=False),)),
        'weak_technical_probability':replace(base,probability=Fraction(3,5)),
        'route_cost_10':replace(base,route_cost=10),
        'route_cost_40':replace(base,route_cost=40),
        'coordination_cost_120':replace(base,coordination_cost=120,available_cash=1020),
        'buyer_value_below_price':replace(base,buyers=buyers[:-1]+(replace(buyers[-1],value=280),)),
    }
    for name,m in variants.items():
        a=analyze(m,tuple(b.name for b in m.buyers))
        check(certificate(m,a))
        negatives[name]=a
    dump('formation_results.json',{'scope':'supplied synthetic model; amounts in thousands of a common numeraire',
        'factorial':factorial,'coalition_table':table,'negative_controls':negatives,
        'minimum_buyers':minimum_buyers(600,Fraction(4,5),225),
        'route_cost_strict_upper_bound':maximum_route_cost(600,Fraction(4,5),4,225),
        'risk':{'common_failure_probability':Fraction(1,5),'failure_loss':600,
                'expected_margin':winner['expected_margin'],'success_margin':winner['success_margin'],
                'expected_buyer_surplus':sum(winner['buyer_surplus'].values()),
                'expected_total_surplus':winner['expected_total_surplus']}})
    grid=[]
    for n,num,k,fee,fully_funded in product(range(1,9),range(1,6),(0,150,300,450,600,900,1200),(0,10,40,100),(False,True)):
        cash=max(0,k+75*n-(0 if fully_funded else 1))
        m=Model(tuple(Buyer(f'b{i}') for i in range(n)),development_cost=k,probability=Fraction(num,5),
                available_cash=cash,route_cost=fee)
        a=analyze(m,tuple(b.name for b in m.buyers))
        verified=check(certificate(m,a))
        closed_form=(Fraction(num,5)*n*(225-fee)>k and cash>=k+75*n)
        assert a['admissible']==closed_form==verified['admissible']
        grid.append({'n':n,'p':[num,5],'K':k,'fee':fee,'fully_funded':fully_funded,
                     'admissible':a['admissible'],'expected_margin':a['expected_margin']})
    dump('exhaustive_grid.json',{'cases':len(grid),'admitted':sum(x['admissible'] for x in grid),
         'rejected':sum(not x['admissible'] for x in grid),'rows':grid})
    seq={f'next_development_{k}':staged_reuse(next_development=k) for k in (600,300,150)}
    seq['weaker_second_probability']=staged_reuse(p2=Fraction(1,5),next_development=150)
    dump('reuse_results.json',seq)
    # Construction of shared subexpressions is not claimed; this study isolates economic feasibility.
    flows=[]
    for annual in (1_000_000,1_000_000_000):
        for days in (1,7,30):
            flows.append({'annual_service_value':annual,'holding_days':days,
                          'average_transaction_inventory_value':Fraction(annual*days,365)})
    abundance=[]
    for g in (1,4,16):
        abundance.append({'productivity':g,'sqrt_demand_multiplier':int(g**0.5),
            'operation_fee_flow_multiplier':Fraction(int(g**0.5),g),
            'fixed_outcome_fee_flow_multiplier':int(g**0.5)})
    dump('token_accounting.json',{'scope':'illustrative accounting, no price target or equilibrium model',
        'transaction_inventory':flows,'abundance_elasticity_assumption':Fraction(1,2),
        'abundance':abundance,'holder_profit_entitlement_created':False})
    print(json.dumps({'grid_cases':len(grid),'grid_admitted':sum(x['admissible'] for x in grid),
                      'factorial_best':[str(x['best_expected_contribution']) for x in factorial],
                      'main_certificate':check(c)},sort_keys=True))

if __name__=='__main__': main()
