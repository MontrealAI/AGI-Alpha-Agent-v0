"""Separate exact event-ledger checker. Does not import the constructor."""
from __future__ import annotations
from fractions import Fraction
import json
from pathlib import Path
import sys


def exact_int(x, nonnegative=False):
    if type(x) is not int or (nonnegative and x < 0): raise ValueError("invalid integer")
    return x


def ratio(x):
    if type(x) is not list or len(x)!=2: raise ValueError("invalid rational")
    return Fraction(exact_int(x[0]), exact_int(x[1], True))


def check(c: dict) -> dict:
    if c.get("schema") != "economic-possibility-model/v1" or c.get("evidence_class") != "synthetic-model-only":
        raise ValueError("wrong schema or evidence class")
    if c.get("live_acceptance") is not False or c.get("authority_granted") is not False:
        raise ValueError("a model cannot certify live acceptance or authority")
    m, plan, paths = c["model"], c["plan"], c["paths"]
    p = ratio(m["probability"])
    if not 0 <= p <= 1: raise ValueError("invalid probability")
    for key in ("shared_core", "coordinated_commitments"):
        if type(m[key]) is not bool: raise ValueError("invalid mode")
    for key in ("development_cost", "available_cash", "route_cost", "coordination_cost", "required_expected_margin"):
        exact_int(m[key], True)
    bs = m["buyers"]
    if not 1 <= len(bs) <= 8: raise ValueError("model size")
    if len({b["name"] for b in bs}) != len(bs): raise ValueError("duplicate economic actor")
    for b in bs:
        for k in ("price", "value", "delivery_cost", "adoption_cost"): exact_int(b[k], True)
        for k in ("committed", "shared_use_allowed"):
            if type(b[k]) is not bool: raise ValueError("invalid model declaration")
    names = plan["coalition"]
    if not names or len(set(names)) != len(names): raise ValueError("bad coalition")
    lookup = {b["name"]: b for b in bs}
    chosen = [lookup[n] for n in names]
    n = len(chosen)
    setup = m["coordination_cost"]
    setup += m["development_cost"] if m["shared_core"] else sum(m["development_cost"] for _ in chosen)
    deliver = sum(b["delivery_cost"] for b in chosen)
    price = sum(b["price"] for b in chosen)
    route = sum(m["route_cost"] for _ in chosen)
    if len(paths)!=2: raise ValueError("both modeled branches required")
    expected_flows = [[-setup], [-setup,-deliver,price,-route]]
    probabilities = [1-p,p]
    terminal = []
    count = 0
    for j, path in enumerate(paths):
        if ratio(path["probability"]) != probabilities[j] or path["flows"] != expected_flows[j]:
            raise ValueError("incorrect branch flows or probability")
        balances = [m["available_cash"]]
        for flow in path["flows"]:
            balances.append(balances[-1]+exact_int(flow))
            count += 1
        if balances != path["balances"]: raise ValueError("balance conservation")
        terminal.append(balances[-1])
    gain = sum(probabilities[j]*(terminal[j]-m["available_cash"]) for j in (0,1))
    surpluses = {b["name"]: p*(b["value"]-b["price"])-b["adoption_cost"] for b in chosen}
    facts = {"upfront_development":setup, "delivery_prefunding":deliver,
             "peak_financing":setup+deliver+max(0,route-price),"success_receipts":price,"route_cost":route,
             "success_margin":terminal[1]-m["available_cash"], "failure_margin":terminal[0]-m["available_cash"]}
    for k, v in facts.items():
        if type(plan[k]) is not int or plan[k]!=v: raise ValueError("wrong fact: "+k)
    if ratio(plan["expected_margin"])!=gain: raise ValueError("wrong expectation")
    if set(plan["buyer_surplus"]) != set(surpluses): raise ValueError("buyer entries")
    for name, u in surpluses.items():
        if ratio(plan["buyer_surplus"][name])!=u: raise ValueError("buyer participation record")
    if ratio(plan["expected_total_surplus"]) != gain+sum(surpluses.values()): raise ValueError("surplus accounting")
    reasons=[]
    if not m["coordinated_commitments"] and n>1: reasons.append("MULTIBUYER_COMMITMENT_NOT_ADMITTED")
    if any(not b["committed"] for b in chosen): reasons.append("UNCOMMITTED_BUYER")
    if m["shared_core"] and any(not b["shared_use_allowed"] for b in chosen): reasons.append("SHARED_USE_NOT_ADMITTED")
    if any(u<0 for u in surpluses.values()): reasons.append("BUYER_PARTICIPATION")
    if min(paths[1]["balances"])<0 or min(paths[0]["balances"])<0: reasons.append("PREFUNDING_SHORTFALL")
    if gain <= m["required_expected_margin"]: reasons.append("EXPECTED_MARGIN_NOT_STRICTLY_POSITIVE")
    if type(plan["admissible"]) is not bool or plan["admissible"] != (not reasons) or plan["reasons"] != reasons:
        raise ValueError("incorrect modeled decision")
    return {"valid_model_record":True,"admissible":not reasons,"cash_flow_equalities":count,
            "evidence_class":"synthetic-model-only"}


def load_unique(path: str):
    def pairs(items):
        d={}
        for k,v in items:
            if k in d: raise ValueError("duplicate JSON key")
            d[k]=v
        return d
    p=Path(path)
    if p.stat().st_size>2_000_000: raise ValueError("oversized reference artifact")
    return json.loads(p.read_text(encoding="utf-8"),object_pairs_hook=pairs,
                      parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))

if __name__ == "__main__":
    try:
        if len(sys.argv)!=2: raise ValueError("usage: python experiments/check_certificate.py FILE.json")
        print(json.dumps(check(load_unique(sys.argv[1])),sort_keys=True))
    except (ValueError, KeyError, TypeError, ZeroDivisionError, OSError) as e:
        print(f"REJECTED: {e}", file=sys.stderr)
        sys.exit(1)
