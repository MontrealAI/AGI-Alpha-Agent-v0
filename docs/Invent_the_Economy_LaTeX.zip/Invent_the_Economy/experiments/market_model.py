"""Exact synthetic market-formation model. No external actions or real commitments."""
from __future__ import annotations
from dataclasses import dataclass
from fractions import Fraction
from itertools import combinations
from typing import Iterable

@dataclass(frozen=True)
class Buyer:
    name: str
    price: int = 300
    value: int = 360
    delivery_cost: int = 75
    adoption_cost: int = 0
    committed: bool = True
    shared_use_allowed: bool = True

    def __post_init__(self) -> None:
        if not isinstance(self.name, str) or not self.name:
            raise ValueError("buyer name required")
        for x in (self.price, self.value, self.delivery_cost, self.adoption_cost):
            if type(x) is not int or x < 0:
                raise ValueError("costs and amounts require nonnegative exact integers")
        if type(self.committed) is not bool or type(self.shared_use_allowed) is not bool:
            raise ValueError("model declarations require booleans")

@dataclass(frozen=True)
class Model:
    buyers: tuple[Buyer, ...]
    development_cost: int = 600
    probability: Fraction = Fraction(4, 5)
    available_cash: int = 900
    shared_core: bool = True
    coordinated_commitments: bool = True
    route_cost: int = 0
    coordination_cost: int = 0
    required_expected_margin: int = 0

    def __post_init__(self) -> None:
        if not self.buyers or len(self.buyers) > 8 or len({b.name for b in self.buyers}) != len(self.buyers):
            raise ValueError("one to eight uniquely identified model buyers required")
        if type(self.probability) is not Fraction or not 0 <= self.probability <= 1:
            raise ValueError("probability must be an exact Fraction in [0,1]")
        for x in (self.development_cost, self.available_cash, self.route_cost,
                  self.coordination_cost, self.required_expected_margin):
            if type(x) is not int or x < 0:
                raise ValueError("nonnegative exact integer required")
        if type(self.shared_core) is not bool or type(self.coordinated_commitments) is not bool:
            raise ValueError("exact mode booleans required")


def analyze(model: Model, names: Iterable[str]) -> dict:
    names = tuple(names)
    if not names or len(set(names)) != len(names):
        raise ValueError("nonempty distinct coalition required")
    lookup = {b.name: b for b in model.buyers}
    if any(name not in lookup for name in names):
        raise ValueError("unknown buyer")
    selected = tuple(lookup[name] for name in names)
    n = len(selected)
    k = model.development_cost * (1 if model.shared_core else n) + model.coordination_cost
    delivery = sum(b.delivery_cost for b in selected)
    revenue = sum(b.price for b in selected)
    routes = model.route_cost * n
    success_margin = revenue - delivery - routes - k
    failure_margin = -k
    expected = model.probability * (revenue - delivery - routes) - k
    buyer_surplus = {b.name: model.probability * (b.value - b.price) - b.adoption_cost for b in selected}
    reasons = []
    if not model.coordinated_commitments and n > 1:
        reasons.append("MULTIBUYER_COMMITMENT_NOT_ADMITTED")
    if any(not b.committed for b in selected):
        reasons.append("UNCOMMITTED_BUYER")
    if model.shared_core and any(not b.shared_use_allowed for b in selected):
        reasons.append("SHARED_USE_NOT_ADMITTED")
    if any(x < 0 for x in buyer_surplus.values()):
        reasons.append("BUYER_PARTICIPATION")
    peak = k + delivery + max(0, routes - revenue)
    if model.available_cash < peak:
        reasons.append("PREFUNDING_SHORTFALL")
    if expected <= model.required_expected_margin:
        reasons.append("EXPECTED_MARGIN_NOT_STRICTLY_POSITIVE")
    return {"coalition": names, "upfront_development": k, "delivery_prefunding": delivery,
            "peak_financing": peak, "success_receipts": revenue, "route_cost": routes,
            "success_margin": success_margin, "failure_margin": failure_margin,
            "expected_margin": expected, "buyer_surplus": buyer_surplus,
            "expected_total_surplus": expected + sum(buyer_surplus.values()),
            "admissible": not reasons, "reasons": reasons}


def choose(model: Model) -> dict:
    """Finite catalogue/subset screening; the constructor does not invent the core."""
    names = tuple(b.name for b in model.buyers)
    attempts = [analyze(model, coalition) for n in range(1, len(names)+1) for coalition in combinations(names, n)]
    eligible = [x for x in attempts if x["admissible"]]
    winner = max(eligible, key=lambda x: (x["expected_margin"], -len(x["coalition"])), default=None)
    return {"winner": winner, "attempts": attempts, "best_with_stop": Fraction(0) if winner is None else winner["expected_margin"]}


def fraction_wire(x: Fraction) -> list[int]:
    return [x.numerator, x.denominator]


def wire(obj):
    if isinstance(obj, Fraction): return fraction_wire(obj)
    if isinstance(obj, tuple): return [wire(x) for x in obj]
    if isinstance(obj, list): return [wire(x) for x in obj]
    if isinstance(obj, dict): return {str(k): wire(v) for k,v in obj.items()}
    return obj


def certificate(model: Model, plan: dict) -> dict:
    p = model.probability
    k = plan["upfront_development"]
    d = plan["delivery_prefunding"]
    r = plan["success_receipts"]
    f = plan["route_cost"]
    start = model.available_cash
    return wire({"schema": "economic-possibility-model/v1", "evidence_class": "synthetic-model-only",
        "live_acceptance": False, "authority_granted": False,
        "model": {"buyers": [b.__dict__ for b in model.buyers],
                  "development_cost": model.development_cost, "probability": p,
                  "available_cash": start, "shared_core": model.shared_core,
                  "coordinated_commitments": model.coordinated_commitments,
                  "route_cost": model.route_cost, "coordination_cost": model.coordination_cost,
                  "required_expected_margin": model.required_expected_margin},
        "plan": plan,
        "paths": [
            {"outcome": "core-fails", "probability": 1-p,
             "flows": [-k], "balances": [start, start-k]},
            {"outcome": "core-qualifies-and-delivery-succeeds", "probability": p,
             "flows": [-k, -d, r, -f], "balances": [start, start-k, start-k-d, start-k-d+r, start-k-d+r-f]}
        ]})


def minimum_buyers(k: int, p: Fraction, contribution: int) -> int | None:
    if k < 0 or not 0 <= p <= 1:
        raise ValueError("invalid inputs")
    expected_unit = p * contribution
    if expected_unit <= 0: return None
    return k // expected_unit + 1


def maximum_route_cost(k: int, p: Fraction, n: int, base_contribution: int) -> Fraction | None:
    if k < 0 or n < 1 or not 0 <= p <= 1:
        raise ValueError("invalid inputs")
    return None if p == 0 else Fraction(base_contribution) - Fraction(k)/(p*n)


def staged_reuse(p1=Fraction(4,5), p2=Fraction(4,5), next_development=150) -> dict:
    """Exact three-leaf tree; second build uses only earned cash above the 900 reserve."""
    first = Model(tuple(Buyer(f"A{i}") for i in range(4)))
    first = Model(first.buyers, probability=p1)
    a = analyze(first, [b.name for b in first.buyers])
    if not a["admissible"]: raise ValueError("first stage not admitted")
    success_cash = first.available_cash + a["success_margin"]
    earned = success_cash - first.available_cash
    second = Model(tuple(Buyer(f"B{i}") for i in range(2)), development_cost=next_development,
                   probability=p2, available_cash=earned)
    b = analyze(second, [x.name for x in second.buyers])
    if not b["admissible"]:
        paths = [(1-p1, first.available_cash+a["failure_margin"]), (p1, success_cash)]
    else:
        paths = [(1-p1, first.available_cash+a["failure_margin"]),
                 (p1*(1-p2), success_cash+b["failure_margin"]),
                 (p1*p2, success_cash+b["success_margin"])]
    return {"first": a, "second": b, "earned_cash": earned,
            "paths": [{"probability": p, "terminal_cash": c} for p,c in paths],
            "expected_terminal_cash": sum(p*c for p,c in paths),
            "expected_contribution": sum(p*c for p,c in paths)-first.available_cash,
            "second_uses_only_earned_surplus": True}
