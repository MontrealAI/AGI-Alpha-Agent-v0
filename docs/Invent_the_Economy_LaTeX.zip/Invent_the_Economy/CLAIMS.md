# Claim–evidence register

| Claim | Evidence | What it does not establish |
|---|---|---|
| Technical and commercial reformulation can be jointly necessary under a named frame. | Conditional joint-emergence theorem; factorial optima 0,0,0,120. | General superiority over unrestricted entrepreneurs or market designers. |
| The four-buyer reference has expected contribution 120, success contribution 300, and common failure loss 600. | Exact rational arithmetic; `formation_certificate.json`; separate event-ledger checker. | Real customer values, a learned 80% success probability, or commercial revenues. |
| The delivery-before-payment package requires 900 prefunding. | Cash-prefix proposition; complete 600-development / 300-delivery / 1200-receipt path. | General financing sufficiency with defaults, partial delivery, taxes, delays, or unmodeled liabilities. |
| Additional route costs can erase newly created viability. | Strict cost ceiling 37.5 per success; modeled 10 and 40 scenarios yield 88 and -8. | Actual protocol costs, optimal fee design, or a recommended fee increase. |
| 2,240 supplied cases agree across three checks. | Full grid, separate event checker, closed-form inequalities; 540 admitted / 1700 rejected. | Frequency of viable markets or independent AI-discovery campaigns. |
| Retained capability can change later financing feasibility. | `reuse_results.json`; K'=300 remains unfunded, K'=150 fits earned 300 and gives expected contribution 288 over two stages. | Measured reuse cost reductions or indefinite compounding. |
| More technical productivity can reduce operation-fee flow. | Conditional elasticity proposition and exact g=1,4,16 examples at elasticity 1/2. | An empirical demand-elasticity estimate or a universal pricing rule. |
| Business outputs and profit alone do not identify token price. | Rescaling/non-identification proposition and inventory examples. | A claim that all rescaled prices are equilibria, that utility is irrelevant, or a valuation target. |
| 50 tests pass. | `verification/test_run.log` and fresh-archive rerun. | Independent institutional review, an operational security audit, or proof that economic inputs are true. |
| Alpha / SUCCESSOR is a named implementation target. | Pinned README and proposed integration brief. | A live integration, source change, merge, release, contract, or paid service. |
| AI can create viable new natural markets through joint discovery. | Proposed six hypotheses and natural-campaign protocol. | Not demonstrated in this manuscript. |

All amounts in experiment JSON are thousands of a common numeraire. Sum of buyer and venture surplus is a combined-participant measure; an economy-wide welfare interpretation additionally requires real opportunity-cost and external-effect assumptions. External service-route recipients are not modeled.

The complete supplied economic design retained under `sources/` is historical context, not a set of new rights granted by this paper. The paper's novel discussion and constructed examples are distinct from that source material and from the externally referenced literature.
