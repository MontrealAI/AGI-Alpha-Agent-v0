// SPDX-License-Identifier: Apache-2.0
// Ordinary local product journey using already-installed runtime tools. No installer or external request.
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import fs from 'node:fs/promises';
import http from 'node:http';
import {createRequire} from 'node:module';
import path from 'node:path';
import {fileURLToPath, pathToFileURL} from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(process.env.ENTERPRISE_ROOT || path.join(here, '../enterprise-work'));
const output = path.resolve(process.env.ENTERPRISE_BROWSER_EVIDENCE || path.join(here, 'browser-existing-runtime'));
const axePath = path.resolve(process.env.AXE_SCRIPT || path.join(here, '../native-increment/site-component-preview/test-tools/axe.min.js'));
const chromiumPath = process.env.CHROMIUM_EXECUTABLE || '/root/.cache/ms-playwright/chromium-1181/chrome-linux/chrome';
const require = createRequire(import.meta.url);
assert.ok(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES, 'Use the already-installed runtime modules explicitly.');
const playwrightPath = require.resolve('playwright', {paths: [process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES]});
const {chromium} = require(playwrightPath);
const playwrightVersion = require(path.join(path.dirname(playwrightPath), 'package.json')).version;
const {verifyDiscoveryDocket} = await import(pathToFileURL(path.join(root, 'examples/successor-capability/discovery-lab-docket.mjs')));
await fs.mkdir(output, {recursive: true});
assert.equal((await fs.readdir(output)).length, 0, 'Keep earlier browser evidence; choose an empty output directory.');
const source = JSON.parse(await fs.readFile(path.join(root, 'docs/successor/capabilities/sources.json'), 'utf8'));
const checks = [], errors = [], requests = [];
const json = async (name, value) => fs.writeFile(path.join(output, name), JSON.stringify(value, null, 2) + '\n');
const sha = value => createHash('sha256').update(value).digest('hex');
const server = http.createServer(async (request, response) => {
    try {
        let pathname = decodeURIComponent(new URL(request.url, 'http://127.0.0.1').pathname);
        let filename = path.resolve(root, '.' + pathname);
        assert.ok(filename.startsWith(root + path.sep));
        if ((await fs.stat(filename)).isDirectory()) filename = path.join(filename, 'index.html');
        const types = {'.html': 'text/html; charset=utf-8', '.json': 'application/json', '.js': 'application/javascript',
            '.mjs': 'application/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.png': 'image/png'};
        response.writeHead(200, {'Content-Type': types[path.extname(filename)] || 'application/octet-stream'});
        response.end(await fs.readFile(filename));
    } catch { response.writeHead(404); response.end('Not found'); }
});
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const origin = 'http://127.0.0.1:' + server.address().port;
const url = origin + '/docs/successor/capabilities/#autonomous-enterprises';
let browser, page;
try {
    browser = await chromium.launch({executablePath: chromiumPath});
    const context = await browser.newContext({acceptDownloads: true, viewport: {width: 1440, height: 1000}});
    context.on('request', request => requests.push(request.url()));
    const attach = value => { value.on('pageerror', error => errors.push(String(error))); value.on('dialog', dialog => dialog.accept()); };
    page = await context.newPage(); attach(page);
    const waitEnabled = async (selector, enabled = true, current = page) => current.waitForFunction(
        ({selector, enabled}) => document.querySelector(selector)?.disabled === !enabled, {selector, enabled}, {timeout: 120000});
    const waitText = async (selector, text, current = page) => current.waitForFunction(
        ({selector, text}) => document.querySelector(selector)?.textContent.includes(text), {selector, text}, {timeout: 120000});
    const history = async (current = page) => JSON.parse(await current.locator('#history-json').textContent());
    const audit = async label => {
        await page.evaluate(await fs.readFile(axePath, 'utf8'));
        const result = await page.evaluate(async () => await axe.run(document, {runOnly: {type: 'tag',
            values: ['wcag2a', 'wcag2aa', 'wcag21aa', 'best-practice']}}));
        await json('accessibility-' + label + '.json', result);
        assert.equal(result.testEngine.version, '4.10.3');
        assert.deepEqual(result.violations, [], 'Accessibility violations at ' + label);
    };
    assert.equal((await page.goto(url)).status(), 200);
    await waitEnabled('#enterprise-build');
    await page.locator('#witness-enabled').check();
    await page.locator('#public-confirmation').check();
    await page.locator('#freeze').click();
    await waitText('#draft-badge', 'Frozen version');
    await waitEnabled('#development');
    await page.locator('#lab-public-confirmation').check();
    await waitEnabled('#lab-construct');
    checks.push('ordinary witness and Discovery controls runnable before enterprise');
    await page.locator('#enterprise-build').click();
    await waitText('#enterprise-status', 'Frozen');
    await waitEnabled('#enterprise-seed');
    assert.match(await page.locator('#enterprise-facts').textContent(), /1,508,042/);
    checks.push('actual n32 construction and complete counted campaign');
    for (const selector of ['#brief-title', '#start-successor', '#freeze', '#development', '#heldout', '#lab-construct', '#lab-successor']) {
        await waitEnabled(selector, false);
    }
    await waitText('#run-gate', 'Finish or stop the active enterprise attempt');
    await waitText('#lab-reservation', 'Finish or stop the active enterprise attempt');
    checks.push('active enterprise blocks witness and Discovery appends with visible explanation');
    const frozen = await history();
    await fs.writeFile(path.join(output, 'frozen-workspace.json'), JSON.stringify(frozen));
    const cutoff = frozen.events.findIndex(event => event.kind === 'enterprise-constructed') + 1;
    assert.ok(cutoff > 1);
    const constructed = {...frozen, events: frozen.events.slice(0, cutoff), revision: cutoff - 1};
    await json('accepted-construction-workspace.json', constructed);
    const envelope = await page.evaluate(async value => {
        const db = await new Promise((resolve, reject) => {
            const request = indexedDB.open('agialpha.successor-capability.v1', 1);
            request.onsuccess = () => resolve(request.result); request.onerror = () => reject(request.error);
        });
        let envelope;
        await new Promise((resolve, reject) => {
            const tx = db.transaction('missions', 'readwrite'), store = tx.objectStore('missions');
            const request = store.get(value.missionId);
            request.onsuccess = () => {
                const prior = request.result;
                envelope = {missionId: value.missionId, revision: prior.revision - (prior.workspace.events.length - value.events.length), workspace: value};
                store.put(envelope);
            };
            tx.oncomplete = () => resolve(); tx.onerror = () => reject(tx.error); tx.onabort = () => reject(tx.error);
        });
        db.close(); return envelope;
    }, constructed);
    await json('accepted-construction-storage-envelope.json', envelope);
    await page.reload();
    await waitText('#enterprise-status', 'Construction accepted');
    await waitEnabled('#enterprise-build', false);
    await waitEnabled('#enterprise-seed', false);
    await waitEnabled('#enterprise-continue');
    await page.locator('#lab-public-confirmation').check();
    await waitEnabled('#lab-construct', false);
    checks.push('actual accepted construction prefix reloads without repeating construction');
    await page.locator('#enterprise-continue').click();
    await waitText('#enterprise-status', 'Frozen');
    await waitEnabled('#enterprise-seed');
    const recovered = await history();
    assert.deepEqual(recovered.events.slice(0, cutoff), constructed.events);
    assert.equal(recovered.events.filter(event => event.kind === 'enterprise-constructed').length, 1);
    assert.equal(recovered.events.at(-1).kind, 'enterprise-frozen');
    assert.equal(recovered.events.some(event => event.kind === 'enterprise-tasks'), false);
    await json('recovered-frozen-workspace.json', recovered);
    checks.push('freeze retains exact prefix and precedes future input commitment');
    await page.locator('#enterprise-capital-run').click();
    await waitText('#enterprise-capital-summary', '13');
    checks.push('synthetic capital controls compute the cash-only pruning penalty');
    await page.locator('#enterprise-seed').fill('20261021');
    await page.locator('#enterprise-continue').click();
    await waitText('#enterprise-status', 'Successor accepted locally');
    await waitText('#enterprise-future-summary', '15 of 15');
    checks.push('five later treatments and changed-kernel successor accepted locally');
    for (const selector of ['#brief-title', '#start-successor', '#development', '#lab-construct']) await waitEnabled(selector);
    checks.push('terminal enterprise releases witness and Discovery controls');
    const downloading = page.waitForEvent('download', {timeout: 120000});
    await page.locator('#enterprise-export').click();
    const download = await downloading;
    const docketPath = path.join(output, 'evidence-docket.json'); await download.saveAs(docketPath);
    const docketRaw = await fs.readFile(docketPath, 'utf8'), docket = JSON.parse(docketRaw);
    assert.equal(Object.keys(docket.files).length, 13);
    const run = JSON.parse(docket.files['05_agialpha_runs/run.json']), events = run.workspace.events;
    assert.equal(events[0].kind, 'version');
    assert.ok(events.findIndex(event => event.kind === 'enterprise-frozen') < events.findIndex(event => event.kind === 'enterprise-tasks'));
    checks.push('actual 13-section docket download binds the observed event order');
    const verification = await verifyDiscoveryDocket(docketRaw);
    assert.equal(verification.verified, true); await json('docket-verification.json', verification);
    checks.push('download independently replays through fixed current source');
    await audit('desktop');
    await page.locator('#autonomous-enterprises').screenshot({path: path.join(output, 'desktop.png'), animations: 'disabled'});
    await page.reload(); await waitText('#enterprise-status', 'Successor accepted locally');
    await waitEnabled('#development');
    checks.push('terminal history persists across reload');
    await page.setViewportSize({width: 390, height: 844});
    assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth));
    await audit('mobile');
    await page.locator('#autonomous-enterprises').screenshot({path: path.join(output, 'mobile.png'), animations: 'disabled'});
    checks.push('390-pixel mobile layout has no horizontal overflow');
    await page.locator('#enterprise-capital-run').focus();
    assert.ok(await page.locator('#enterprise-capital-run').evaluate(element => element === document.activeElement));
    checks.push('capital control receives keyboard focus');
    checks.push('Axe 4.10.3 reports zero violations on desktop and mobile');
    // A separate empty browser context imports the actual earlier frozen history through the public importer.
    const stoppedContext = await browser.newContext({viewport: {width: 1440, height: 1000}});
    stoppedContext.on('request', request => requests.push(request.url()));
    const stoppedPage = await stoppedContext.newPage(); attach(stoppedPage);
    assert.equal((await stoppedPage.goto(url)).status(), 200);
    await waitEnabled('#import', true, stoppedPage);
    await stoppedPage.locator('#import').setInputFiles(path.join(output, 'frozen-workspace.json'));
    await waitText('#enterprise-status', 'Frozen', stoppedPage);
    await stoppedPage.locator('#lab-public-confirmation').check();
    await waitEnabled('#development', false, stoppedPage); await waitEnabled('#lab-construct', false, stoppedPage);
    await stoppedPage.locator('#enterprise-stop').click();
    await waitText('#enterprise-status', 'Stopped', stoppedPage);
    await waitEnabled('#development', true, stoppedPage); await waitEnabled('#lab-construct', true, stoppedPage);
    const stopped = await history(stoppedPage);
    assert.deepEqual(stopped.events.slice(0, frozen.events.length), frozen.events);
    assert.equal(stopped.events.at(-1).kind, 'enterprise-stopped');
    await json('stopped-imported-workspace.json', stopped);
    checks.push('public import and Stop preserve the frozen prefix and release unrelated controls');
    await stoppedPage.locator('#development').click();
    await waitText('#development-state', 'Computed PASS', stoppedPage);
    await json('post-stop-witness-workspace.json', await history(stoppedPage));
    checks.push('ordinary witness evaluation works after explicit enterprise Stop');
    await stoppedContext.close();
    assert.ok(requests.every(value => value.startsWith(origin + '/') || value.startsWith('data:') || value.startsWith('blob:')));
    checks.push('all observed requests stay local');
    assert.deepEqual(errors, []); checks.push('no page JavaScript errors');
    await json('summary.json', {status: 'PASSED', scope: 'LOCAL_SOURCE_ONLY; canonical Python browser runner NOT_RUN in this profile',
        node: process.version, playwright: playwrightVersion, browser: browser.version(), executable: chromiumPath,
        tools: 'Already installed runtime Playwright and Chromium; no install or dependency download',
        source, axeSha256: sha(await fs.readFile(axePath)), missionId: run.workspace.missionId, eventCount: events.length,
        checkCount: checks.length, checks, errors, requests, hosted: 'NOT_RUN', installedEnterpriseCustody: 'NOT_RUN', realTaskPilot: 'NOT_RUN'});
    console.log(JSON.stringify({status: 'PASSED', checkCount: checks.length, sourceHash: source.sourceHash, browser: browser.version(), playwright: playwrightVersion, output}));
} catch (error) {
    await json('FAILURE.json', {status: 'FAILED', sourceHash: source.sourceHash, checks, errors, error: String(error), stack: error.stack});
    if (page && !page.isClosed()) await page.screenshot({path: path.join(output, 'failure.png'), fullPage: true}).catch(() => {});
    console.error(error); process.exitCode = 1;
} finally {
    if (browser) await browser.close();
    await new Promise(resolve => server.close(resolve));
}
