"""Rebuild fixed page and complete gallery digest from exact public source bytes."""

import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys

EVIDENCE = Path(__file__).resolve().parent
ROOT = EVIDENCE.parent / "enterprise-work"
sys.path.insert(0, str(ROOT / "scripts"))
import build_service_worker as workers
import mirror_demo_pages as mirrors


def blob_sha(raw):
    return hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()


manifest = json.loads((EVIDENCE / "public-cache-blob-manifest.json").read_text())
tree = json.loads((EVIDENCE / "public-alpha2c-tree-leaves.json").read_text())
leaves = {entry["path"]: entry for entry in tree}
expected = sorted(entry["path"][5:] for entry in tree if entry["path"].startswith("docs/")
                  and workers.is_cache_asset(Path(entry["path"][5:])))
asset_bytes = {}
total_bytes = 0
for entry in manifest["blobs"]:
    raw = (EVIDENCE / "public-cache-bytes" / entry["sha"]).read_bytes()
    assert blob_sha(raw) == entry["sha"]
    for name in entry["paths"]:
        assert leaves[name]["sha"] == entry["sha"] and leaves[name]["mode"] == "100644"
        asset_bytes[name[5:]] = raw
        total_bytes += len(raw)
assert sorted(asset_bytes) == expected
catalog = ROOT / "alpha_factory_v1/demos/catalog.json"
assert blob_sha(catalog.read_bytes()) == leaves["alpha_factory_v1/demos/catalog.json"]["sha"]
release = json.loads(catalog.read_bytes())["release"]
before = workers.render_scripts(asset_bytes, release)
for name, content in before.items():
    assert blob_sha(content.encode()) == leaves["docs/" + name]["sha"], name

subprocess.run([sys.executable, "scripts/generate_successor_capability.py"], cwd=ROOT, check=True)
source = ROOT / "docs/successor/capabilities"
target = ROOT / "docs/alpha_factory_v1/demos/successor/capabilities"
shutil.copytree(source, target, dirs_exist_ok=True)
# The unmodified helper takes the mirrored top-level directory (successor).
mirrors.fix_paths(target.parent)
changed = []
for name in ["successor/capabilities/index.html", "alpha_factory_v1/demos/successor/capabilities/index.html"]:
    raw = (ROOT / "docs" / name).read_bytes()
    assert raw != asset_bytes[name]
    asset_bytes[name] = raw
    changed.append(name)
rendered = workers.render_scripts(asset_bytes, release)
for name, content in rendered.items():
    destination = ROOT / "docs" / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(content, encoding="utf-8")
current = json.loads((source / "sources.json").read_text())
assert current == json.loads((target / "sources.json").read_text())
assert len(current["sources"]) == 53
for name, expected_sha in current["sources"].items():
    assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == expected_sha, name
result = {
    "status": "PASS", "baseCommit": manifest["commit"], "baseTree": manifest["tree"],
    "uniquePublicBlobs": len(manifest["blobs"]), "cacheAssetCount": len(asset_bytes),
    "completePublicAssetBytes": total_bytes, "publicWorkerReproduction": "all three byte-exact by Git blob SHA",
    "changedCacheInputs": changed, "release": release,
    "sourceHash": current["sourceHash"], "sourceCount": len(current["sources"]),
    "cache": json.loads(rendered["service-worker.js"].split("const CACHE = ", 1)[1].split(";", 1)[0]),
    "workers": {"docs/" + name: hashlib.sha256(content.encode()).hexdigest() for name, content in rendered.items()},
    "scope": "Public tracked bytes read as data; no installation, external dependency execution, partial-cache generation or deployment."
}
(EVIDENCE / "GENERATION_PROOF.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
