"""Restore exact public tracked blobs as data; no dependency installation or execution."""

import hashlib
import json
from pathlib import Path
import sys
import termios
import tty

ROOT = Path(__file__).resolve().parent
DEST = ROOT / "public-cache-bytes"
DEST.mkdir(exist_ok=True)
original = termios.tcgetattr(0)
tty.setraw(0)
count = 0
size = 0
try:
    print("READY_PUBLIC_SOURCE_DATA", flush=True)
    for line in sys.stdin:
        record = json.loads(line)
        if record.get("op") == "finish":
            print(json.dumps({"status": "PASS", "blobs": count, "bytes": size}), flush=True)
            break
        content = record["content"].encode("utf-8")
        sha = record["sha"]
        actual = hashlib.sha1(b"blob " + str(len(content)).encode() + b"\0" + content).hexdigest()
        if actual != sha:
            raise ValueError("Public blob byte mismatch: " + sha + " != " + actual)
        target = DEST / sha
        target.write_bytes(content)
        count += 1
        size += len(content)
        print(json.dumps({"sha": sha, "bytes": len(content), "verified": True}), flush=True)
finally:
    termios.tcsetattr(0, termios.TCSADRAIN, original)
