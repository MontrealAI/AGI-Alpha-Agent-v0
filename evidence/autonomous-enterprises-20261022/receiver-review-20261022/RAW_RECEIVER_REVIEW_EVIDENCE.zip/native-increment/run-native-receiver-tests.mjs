import fs from 'node:fs';import {createHash} from 'node:crypto';
import * as workspace from '../enterprise-work/examples/successor-capability/workspace.mjs';
import * as controller from '../enterprise-work/examples/autonomous-enterprises/controller.mjs';
import * as protocol from '../enterprise-work/examples/autonomous-enterprises/protocol.mjs';
import * as native from '../enterprise-work/examples/autonomous-enterprises/native-contract.mjs';
const sha=data=>createHash('sha256').update(data).digest('hex');
const inputs={};for(const folder of ['enterprise-work/examples/autonomous-enterprises','enterprise-work/examples/successor-capability'])for(const name of fs.readdirSync(folder,{recursive:true})){const path=folder+'/'+name;if(name.endsWith('.mjs')&&!name.endsWith('.test.mjs')&&fs.statSync(path).isFile())inputs[path]=sha(fs.readFileSync(path));}
const source={repository:'MontrealAI/AGI-Alpha-Agent-v0',commit:'0'.repeat(40),constructor:inputs['enterprise-work/examples/autonomous-enterprises/foundry.mjs'],checker:inputs['enterprise-work/examples/autonomous-enterprises/checker.mjs'],closure:await protocol.digest(inputs)};
const charter={...protocol.defaultCharter({constructor:source.constructor,checker:source.checker,closure:source.closure}),maxN:2,constructionLimit:100000,perTaskLimit:100000,taskLimit:1};
let frozen=await controller.start(await workspace.createWorkspace(),charter);for(let i=0;i<2;i++)frozen=await controller.next(frozen,{expectedSource:charter.source});
let reserved=await controller.next(frozen,{expectedSource:charter.source,seed:20261021});reserved=await controller.next(reserved,{expectedSource:charter.source});
globalThis.__ENTERPRISE_NATIVE_TEST_RUNTIME__={workspace,controller,protocol,native,source,frozen,reserved};
console.log('Scope: actual local fixed-source n2 interoperability; commit000 is an explicit uncommitted fixture identity; no source capture, installed release or operational qualification.');
await import('./manager/scripts/integrations/enterprise-work-request.test.mjs');
await import('./jobs/integrations/alpha-agent/enterprise-work-request.test.mjs');
