import errno,json,pathlib,threading
checks={};written=0
try:
 with open("/tmp/scratch-limit","wb") as output:
  for _ in range(18): written+=output.write(b"x"*1048576);output.flush()
except OSError as error: checks["scratch_exhaustion"]=error.errno==errno.ENOSPC
else: checks["scratch_exhaustion"]=False
event=threading.Event();threads=[]
try:
 for _ in range(80):
  thread=threading.Thread(target=event.wait,args=(5,));thread.start();threads.append(thread)
except RuntimeError: checks["pids_exhaustion"]=1<=len(threads)<64
else: checks["pids_exhaustion"]=False
finally:
 event.set()
 for thread in threads: thread.join(timeout=6)
print(json.dumps({"checks":checks,"scratch_bytes_written":written,"threads_started":len(threads)},sort_keys=True))
