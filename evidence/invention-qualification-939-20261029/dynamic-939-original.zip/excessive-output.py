import os
os.write(1,b'x'*(1048576+8192))
