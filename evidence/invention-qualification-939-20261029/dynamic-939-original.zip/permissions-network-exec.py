import errno,json,os,pathlib,socket,subprocess,sys
checks={}
def denied(name,operation):
 try: operation()
 except OSError as error:
  checks[name]=error.errno in (errno.EACCES,errno.EPERM,errno.EROFS,errno.ENOENT)
 else: checks[name]=False
denied("root_write",lambda:open("/alpha-forbidden","w"))
denied("input_write",lambda:open(sys.argv[0],"w"))
denied("privilege_escalation",lambda:os.setuid(0))
checks["nonroot"]=os.getuid()==65534 and os.getgid()==65534
status=dict(line.split(":",1) for line in pathlib.Path("/proc/self/status").read_text().splitlines() if ":" in line)
checks["capabilities_dropped"]=int(status["CapEff"].strip(),16)==0
checks["no_new_privileges"]=status["NoNewPrivs"].strip()=="1"
checks["seccomp_filter"]=status["Seccomp"].strip()=="2"
checks["no_docker_socket"]=not pathlib.Path("/var/run/docker.sock").exists()
checks["no_host_mounts"]=not pathlib.Path("/workspace").exists() and not pathlib.Path("/github").exists()
def limit(name): return pathlib.Path("/sys/fs/cgroup",name).read_text().strip()
limits={name:limit(name) for name in ("cpu.max","memory.max","pids.max")}
cpu,period=map(int,limits["cpu.max"].split())
checks["cpu_limit"]=cpu/period<=2
checks["memory_limit"]=int(limits["memory.max"])<=2147483648
checks["pids_limit"]=int(limits["pids.max"])<=64
probe=pathlib.Path("/tmp/writable")
probe.write_bytes(b"scratch")
checks["scratch_writable"]=probe.read_bytes()==b"scratch"
binary=pathlib.Path("/tmp/forbidden-exec")
binary.write_bytes(pathlib.Path("/bin/true").read_bytes());binary.chmod(0o755)
denied("scratch_exec",lambda:subprocess.run([str(binary)],check=True))
connection=socket.socket();connection.settimeout(0.25)
try: connection.connect(("198.51.100.1",80))
except OSError: checks["external_network_denied"]=True
else: checks["external_network_denied"]=False
finally: connection.close()
checks["no_default_route"]=all(line.split()[1]!="00000000" for line in pathlib.Path("/proc/net/route").read_text().splitlines()[1:])
print(json.dumps({"checks":checks,"observed_cgroup_limits":limits},sort_keys=True))
