// SPDX-License-Identifier: Apache-2.0
// Bounded exact-source CLI interoperability journey; no operational authority.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {pathToFileURL} from 'node:url';

const OUT='/dev/shm/alpha-41-native-journey';
const BASE='/workspace/scratch/32717074a7f1';
const ALPHA={repository:'MontrealAI/AGI-Alpha-Agent-v0',root:BASE+'/integration-alpha',commit:'cde3010e1e137c49885477f1f514ece6efec0fdd',tree:'dca53a253eae34c67ee7ea7ad0dffd264239bd41'};
const SPEC={
 manager:{repository:'MontrealAI/AGIJobManager',root:'/workspace/scratch/ce7e013c0938/manager-lab',commit:'68d1d3cae2e6f2d46c21e8e73311d309b2b307fd',tree:'c96140e3e0db9e47a68cab5883bb900ce9670912',adapter:'scripts/integrations/discovery-lab-work-request.mjs',contract:'scripts/integrations/discovery-lab-contract.mjs',adapterSha256:'da307c2d0621a2f323d60c56dfec01d2fda2b72b753939657ea303d619d68e43'},
 jobs:{repository:'MontrealAI/AGIJobsv0',root:'/workspace/scratch/ce7e013c0938/jobs-lab',commit:'285034830b6cddc47c7e1002ee85a8b008b9763d',tree:'6e7630783248ca95777f92a6729942caebe909df',adapter:'integrations/alpha-agent/discovery-lab-work-request.mjs',contract:'integrations/alpha-agent/discovery-lab-contract.mjs',adapterSha256:'337fabca02ece2a25b8cc50e56fea5bf5338f2b6f18343eb4a3353a634aefec4'},
 fleet:{repository:'MontrealAI/AGI-Fleet-Linux',root:'/workspace/scratch/ce7e013c0938/fleet-lab',commit:'0dd352fdd2b1af00bc8358e0ac7f96682fd6f796',tree:'79415af24ebf57d30981f841f13b7969e4193502',adapter:'discovery-lab/receiver.mjs',contract:'discovery-lab/contract.mjs',adapterSha256:'55000194e7743dc9725d32a516287fec6bd7e0fc42bd36bf26c1665975f734cd'}
};
const CONTRACT_SHA='98c8de8ce2774b7650bf4ee11eeedfb0a69b75fa6d1b080ef823637d77d0ab47';
const SOURCE_HASH='644258ac21cc938aff861d02ad728e8f3c9716f6ea78700acc35e4d7400eebf2';
const GRAPH_SHA='8d3575ece582c158c30f3cc1c5f438b9b32ad2a31f190d6867acf9712beedad5';
const sha=x=>createHash('sha256').update(x).digest('hex');
const load=x=>import(pathToFileURL(x).href);
const git=(root,...args)=>execFileSync('git',['--no-pager','-C',root,...args],{maxBuffer:16_000_000,timeout:30000});
const journal=[];
let written=0;
function save(name,raw){
 raw=typeof raw==='string'||Buffer.isBuffer(raw)?raw:JSON.stringify(raw,null,2)+'\n';
 const bytes=Buffer.byteLength(raw);assert.ok(bytes<=32_000_000);written+=bytes;assert.ok(written<=256_000_000);
 const target=path.join(OUT,name);fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,raw,{flag:'wx',mode:0o600});
 return {path:name,bytes,sha256:sha(raw)};
}
function log(phase,fields={}){const entry={at:new Date().toISOString(),phase,...fields};journal.push(entry);console.log(JSON.stringify(entry));}
function head(spec){
 const head=git(spec.root,'rev-parse','HEAD').toString().trim();
 const tree=git(spec.root,'rev-parse',spec.commit+'^{tree}').toString().trim();assert.equal(tree,spec.tree);
 return {headAtCapture:head,pinnedCommit:spec.commit,pinnedTree:tree,trackedDiffAtCapture:git(spec.root,'diff','--name-only').toString().trim()};
}
function capture(spec,name,expected){
 assert.ok(name&&!path.isAbsolute(name)&&name.split('/').every(x=>x&&x!=='.'&&x!=='..'));
 const source=path.join(spec.root,name);assert.equal(fs.realpathSync(source),source);
 const info=fs.lstatSync(source);assert.ok(info.isFile()&&info.size<=2_000_000);
 const raw=fs.readFileSync(source),committed=git(spec.root,'show',spec.commit+':'+name);assert.deepEqual(raw,committed,name);
 const entry=git(spec.root,'ls-tree','-z',spec.commit,'--',name).toString();assert.match(entry,/^100(?:644|755) blob [a-f0-9]{40}\t/);
 assert.equal(Boolean(info.mode&0o111),entry.startsWith('100755 '));if(expected)assert.equal(sha(raw),expected,name);
 return {raw,record:{path:name,sha256:sha(raw),bytes:raw.length,mode:entry.slice(0,6)}};
}
let boundary;
try {
 assert.ok(!fs.existsSync(path.join(OUT,'exact-source-manifest.json')),'Fresh output required');
 const env={node:process.version,binarySha256:sha(fs.readFileSync(process.execPath)),platform:process.platform,arch:process.arch};
 const alphaState=head(ALPHA);
 assert.equal(git(ALPHA.root,'merge-base',ALPHA.commit,alphaState.headAtCapture).toString().trim(),ALPHA.commit,'Observed checkout must retain the exact selected source ancestry');
 const catalogName='docs/successor/capabilities/sources.json',catalogCapture=capture(ALPHA,catalogName);
 const catalog=JSON.parse(catalogCapture.raw);assert.equal(catalog.sourceHash,SOURCE_HASH);assert.equal(Object.keys(catalog.sources).length,41);
 const sorted=Object.fromEntries(Object.keys(catalog.sources).sort().map(k=>[k,catalog.sources[k]]));assert.equal(sha(JSON.stringify(sorted)),SOURCE_HASH);
 const alphaFiles=new Map(),alphaRecords=[catalogCapture.record];save('captured/alpha/'+catalogName,catalogCapture.raw);
 for(const[name,digest]of Object.entries(catalog.sources)){const x=capture(ALPHA,name,digest);alphaFiles.set(name,x.raw);alphaRecords.push(x.record);save('captured/alpha/'+name,x.raw);}
 const inspectorName='examples/successor-capability/discovery-lab-inspector.mjs';
 if(!alphaFiles.has(inspectorName)){const x=capture(ALPHA,inspectorName);alphaFiles.set(inspectorName,x.raw);alphaRecords.push(x.record);save('captured/alpha/'+inspectorName,x.raw);}
 const native={},sourceRecords=[];
 for(const[key,spec]of Object.entries(SPEC)){
  const state=head(spec);assert.equal(state.headAtCapture,spec.commit);
  const records=[];for(const[name,digest]of[[spec.adapter,spec.adapterSha256],[spec.contract,CONTRACT_SHA]]){
   const x=capture(spec,name,digest);records.push(x.record);save('captured/'+key+'/'+name,x.raw);
  }
  native[key]={spec,state,records,source:{repository:spec.repository,commit:spec.commit,tree:spec.tree,adapterSha256:spec.adapterSha256,contractSha256:CONTRACT_SHA}};
  sourceRecords.push({repository:spec.repository,commit:spec.commit,tree:spec.tree,files:records.map(({path,sha256})=>({path,sha256}))});
 }
 const graphRaw=git(BASE+'/jobs-release-local','show','40c2c6b540dcfcf4c7e9cd0f7bb2e77cab785b2c:integrations/alpha-agent/discovery-installed-module-graph.mjs');assert.equal(sha(graphRaw),GRAPH_SHA);
 save('captured/module-closure.mjs',graphRaw);const graph=await load(path.join(OUT,'captured/module-closure.mjs'));
 const modules=new Map([...alphaFiles].filter(([name])=>name.endsWith('.mjs')));
 const parsed=graph.parseModuleSources([...modules].map(([name,raw])=>({name,source:raw.toString('utf8')})),graphRaw.toString('utf8'));
 graph.checkDependencyRecords(parsed,new Set(modules.keys()));save('alpha-static-module-records.json',parsed);
 const names=['workspace','discovery-lab-history','discovery-lab','discovery-lab-contract','discovery-lab-evidence-history','discovery-lab-future','discovery-lab-real-task','discovery-lab-receipts','discovery-lab-docket','discovery-lab-inspector'];
 boundary=graph.createModuleBoundary(path.join(OUT,'captured/alpha'),modules,names.map(name=>'examples/successor-capability/'+name+'.mjs'));
 const imported=await Promise.all(names.map(name=>boundary.importModule('examples/successor-capability/'+name+'.mjs')));
 const [workspace,history,runtime,contract,evidence,future,realTask,receipts,docket,{createInspector}]=imported;
 const sources={sourceDigest:SOURCE_HASH,modelDigest:catalog.sources['examples/successor-capability/discovery-lab.mjs'],evaluatorDigest:catalog.sources['examples/successor-capability/discovery-lab-checker.mjs']};
 const alphaSource={repository:ALPHA.repository,commit:ALPHA.commit,tree:ALPHA.tree,files:alphaRecords.map(({path,sha256})=>({path,sha256}))};sourceRecords.unshift(alphaSource);
 const manifest={schema:'alpha-41-cli-journey-exact-source/v1',scope:'CLI/source interoperability only; not hosted browser, released installed service, organizational acceptance or execution authority',alpha:{...ALPHA,state:alphaState,catalogSha256:sha(catalogCapture.raw),sourceHash:SOURCE_HASH,catalogCount:41,files:alphaRecords},receivers:Object.fromEntries(Object.entries(native).map(([key,x])=>[key,{...x.spec,state:x.state,files:x.records}])),graph:{sourceCommit:'40c2c6b540dcfcf4c7e9cd0f7bb2e77cab785b2c',sha256:GRAPH_SHA},environment:env,authority:'none'};
 save('exact-source-manifest.json',manifest);log('exact-source-capture-complete',{sourceHash:SOURCE_HASH,catalogCount:41,capturedAlphaFiles:alphaRecords.length,moduleCount:modules.size});
 let value=await workspace.createWorkspace();const initialMission=value.missionId;
 function checkpoint(name){save('workspaces/'+name+'.json',contract.canonical(value));}
 async function campaign(name,charter,parent=null){
  const begin=await history.startPayload(value,charter,sources,parent?.campaignDigest||null);
  value=await workspace.recordDiscoveryEvent(value,'lab-started',begin);
  const started=performance.now(),result=runtime.runCampaign(charter,{parent:parent?.result||null});
  const verified=history.verifyForRecording(charter,result,parent?.result||null),elapsedMs=Math.ceil(performance.now()-started);
  value=await workspace.recordDiscoveryEvent(value,'lab-completed',await history.completedPayload(begin.attempt,result,elapsedMs,verified.verificationResources));
  const record=(await workspace.inspectWorkspace(value)).discovery.campaigns.at(-1);assert.equal(record.state,'accepted');assert.equal(record.artifacts.length,6);assert.equal(record.lineageQualified,true);
  save('campaigns/'+name+'.json',record);checkpoint(name);log('campaign-accepted',{name,campaignDigest:record.campaignDigest,stages:record.result.stages.map(x=>x.status),elapsedMs});return record;
 }
 const parent=await campaign('accepted-parent',structuredClone(runtime.DEFAULT_CHARTER));
 const stronger=await campaign('accepted-successor',{...structuredClone(runtime.DEFAULT_CHARTER),controls:4,memory:16,operations:['flip-z','flip-w']},parent);
 assert.equal(stronger.parent.campaignDigest,parent.campaignDigest);assert.notEqual(parent.campaignDigest,stronger.campaignDigest);assert.equal(stronger.result.reuse.priorPurposePreservedOnOldSlice,true);assert.equal(stronger.result.reuse.acceptedPredecessorPreserved,true);assert.ok(stronger.result.reuse.retainedFactors.length>0);
 async function attach(kind,record){const before=value.events.at(-1).digest;value=await workspace.recordDiscoveryEvent(value,'lab-evidence-attached',await evidence.evidencePayload(stronger.campaignDigest,kind,record));assert.equal(value.events.at(-1).previous,before);assert.equal(value.missionId,initialMission);}
 const capsule=await evidence.freezeRecord(stronger);save('future/frozen-capsule.json',capsule);await attach('future-freeze',evidence.freezeReference(capsule));
 const bank=await future.publicFutureBank(capsule,41);save('future/later-task-bank.json',bank);await attach('future-task-bank',bank);
 const perTaskWorkLimit=3_000_000;await attach('future-run-reserved',{schema:'discovery-lab-future-reservation/v1',taskBankDigest:bank.digest,perTaskWorkLimit,attempt:'future-'+crypto.randomUUID()});
 const evaluation=await future.evaluateFutureTasks(capsule,bank,{perTaskWorkLimit});assert.equal(evaluation.runs.length,42);assert.equal(evaluation.summaries.length,7);save('future/all-42-outcomes-and-costs.json',evaluation);await attach('future-evaluation',evaluation);checkpoint('future-complete');
 log('future-evaluation-complete',{tasks:bank.tasks.length,treatments:evaluation.summaries.length,outcomes:evaluation.runs.length,statuses:Object.fromEntries(['accepted','rejected','inconclusive'].map(s=>[s,evaluation.runs.filter(x=>x.status===s).length]))});
 const limits={acquisitions:0,search:0,checking:2*contract.DISCOVERY_LAB_INSPECTION_CHECKS,memoryBytes:10_000_000,storageBytes:4_000_000,workerCapacity:4,installations:0,elapsedMs:120_000};
 for(let item=stronger;item;item=item.parent)for(const key of['acquisitions','search','checking','installations'])limits[key]+=item.charter.budget[key];
 const realRequest=await history.workRequest(stronger,'AGIALPHA',limits),realDigest=catalog.sources['examples/successor-capability/discovery-lab-real-task.mjs'];
 const realRecord=await realTask.createRealTaskRecord({workRequest:realRequest,workspaceHead:value.events.at(-1).digest,campaignDigest:stronger.campaignDigest,publicSource:'https://github.com/MontrealAI/AGI-Alpha-Agent-v0/blob/'+ALPHA.commit+'/examples/successor-capability/discovery-lab-real-task.mjs',specification:{multiplier:'2',offset:'1',maxBatchRows:16},resourceLimits:limits,adapterSources:{adapterSourceDigest:realDigest,checkerSourceDigest:realDigest}});
 assert.equal(realRecord.operationalState,'NOT_RUN');assert.equal(realRecord.artifact,null);assert.deepEqual(realRecord.checks,[]);save('real-task/not-run-contract.json',realRecord);save('real-task/producer-packet.json',await realTask.realTaskProducerPacket(realRecord));await attach('real-task-contract',realRecord);checkpoint('real-task-not-run');
 const inspector=createInspector(sources),returned=[];
 for(const key of['manager','jobs']){
  const receiver=await load(path.join(OUT,'captured',key,native[key].spec.adapter));
  for(const stage of contract.STAGES){
   const request=await history.workRequest(stronger,key==='manager'?'USDC':'AGIALPHA',limits);request.stage=stage;request.inputArtifacts=stronger.artifacts.slice(0,contract.STAGES.indexOf(stage)).map(x=>x.digest);
   const original=JSON.stringify(request),receipt=await receiver.receiveDiscoveryLabWorkRequest(original,{expectedBindings:Object.fromEntries(contract.BINDING_KEYS.map(k=>[k,stronger.bindings[k]])),expectedCommission:Object.fromEntries(['id','branch','route'].map(k=>[k,request.commission[k]])),inspectCampaign:inspector});
   assert.equal(receipt.original,original);assert.equal(receipt.state,'local-checked');assert.equal(receipt.authority,'none');assert.equal(receipt.lifecycle.reservedBaseUnits,'0');
   const receiptRaw=JSON.stringify(receipt),wrapper={raw:receiptRaw,source:native[key].source};
   const checked=await receipts.inspectReceiverReceipt(wrapper,receipts.makeReceiverContext(stronger),{expectedReceiverSources:[native[key].source]});
   save('native/'+key+'/'+stage+'-request.json',original);save('native/'+key+'/'+stage+'-receipt.json',receiptRaw);save('native/'+key+'/'+stage+'-wrapper.json',JSON.stringify(wrapper));save('native/'+key+'/'+stage+'-checked.json',checked);
   await attach('receiver-receipt',wrapper);returned.push({receiver:key,stage,state:receipt.state,receiptId:checked.receiptId,receiptDigest:checked.receiptDigest,resources:checked.resources});
   log('native-return-imported',{receiver:key,stage,state:receipt.state,eventCount:value.events.length});
  }
  checkpoint(key+'-all-six-native-returns');
 }
 const fleet=await load(path.join(OUT,'captured/fleet',native.fleet.spec.adapter));
 const request=await history.workRequest(stronger,'USDC',limits),original=JSON.stringify(request);
 const runtimeDigest=await contract.payloadDigest({environment:env,alphaCommit:ALPHA.commit,sourceHash:SOURCE_HASH,inspectorSha256:sha(alphaFiles.get(inspectorName))});
 const installed={executorId:'exact-public-fleet-cli-source-review',runtimeDigest,currentRuntimeDigest:runtimeDigest,expected:Object.fromEntries(contract.BINDING_KEYS.map(k=>[k,request[k]])),expectedCommission:Object.fromEntries(['id','branch','route'].map(k=>[k,request.commission[k]])),stages:contract.STAGES,resourceCapacity:limits,inspectCampaign:inspector};
 const receipt=await fleet.reviewDiscoveryRequest(original,installed);assert.equal(receipt.state,'accepted-local-review');assert.equal(receipt.authority,'none');
 const receiptRaw=JSON.stringify(receipt),fleetWrapper={raw:JSON.stringify({schema:'agi-fleet/discovery-review-return/v1',original,receiptRaw}),source:native.fleet.source};
 const fleetChecked=await receipts.inspectReceiverReceipt(fleetWrapper,receipts.makeReceiverContext(stronger),{expectedReceiverSources:[native.fleet.source]});
 save('native/fleet/evolve-request.json',original);save('native/fleet/evolve-receipt.json',receiptRaw);save('native/fleet/evolve-wrapper.json',JSON.stringify(fleetWrapper));save('native/fleet/evolve-checked.json',fleetChecked);save('native/fleet/installed-context.json',{...installed,inspectCampaign:'actual captured Alpha createInspector(sources) function'});
 await attach('receiver-receipt',fleetWrapper);returned.push({receiver:'fleet',stage:'evolve',state:receipt.state,receiptId:fleetChecked.receiptId,receiptDigest:fleetChecked.receiptDigest,resources:fleetChecked.resources});log('native-return-imported',{receiver:'fleet',stage:'evolve',state:receipt.state,eventCount:value.events.length});
 assert.equal(value.events.length,23);assert.equal(value.authority.length,0);assert.equal(value.paymentRoute,'none');
 const workspaceRaw=contract.canonical(value);save('workspace.json',workspaceRaw);
 const options={expectedSources:sourceRecords,expectedReceiverSources:Object.values(native).map(x=>x.source),expectedWorkspaceHead:value.events.at(-1).digest,expectedMissionId:value.missionId};
 const attachments=await docket.emptyDocketAttachments(value);attachments.sources=sourceRecords;save('docket-attachments.json',attachments);
 const exported=await docket.exportDiscoveryDocket(value,attachments,options);save('docket.json',exported);const parsedDocket=JSON.parse(exported);
 assert.equal(Object.keys(parsedDocket.files).length,13);for(const name of docket.DOCKET_PATHS)save('docket-sections/'+name,parsedDocket.files[name]);
 const verified=await docket.verifyDiscoveryDocket(fs.readFileSync(path.join(OUT,'docket.json'),'utf8'),options);assert.equal(verified.verified,true);save('docket-reconciliation.json',verified);
 const reopened=await workspace.parseWorkspace(fs.readFileSync(path.join(OUT,'workspace.json'),'utf8'));assert.equal(contract.canonical(reopened),workspaceRaw);
 const reopenedAttachments=await docket.emptyDocketAttachments(reopened);reopenedAttachments.sources=sourceRecords;const reopenedDocket=await docket.exportDiscoveryDocket(reopened,reopenedAttachments,options);assert.equal(reopenedDocket,exported);save('reopened-workspace.json',contract.canonical(reopened));save('reopened-docket.json',reopenedDocket);
 const outcome=JSON.parse(parsedDocket.files['12_summary_tables/outcome.json']),costs=JSON.parse(parsedDocket.files['08_cost_ledgers/costs.json']);assert.equal(outcome.receiverReceiptCount,13);assert.equal(outcome.futureEvaluationCount,1);assert.equal(outcome.realTaskRecordCount,1);assert.equal(costs.currenciesCombined,false);assert.equal(costs.totalComplete,false);
 const report={schema:'alpha-41-bounded-native-cli-journey/v1',scope:manifest.scope,alphaCommit:ALPHA.commit,alphaTree:ALPHA.tree,sourceHash:SOURCE_HASH,catalogCount:41,environment:env,missionId:value.missionId,workspaceHead:value.events.at(-1).digest,eventCount:value.events.length,workspaceBytes:Buffer.byteLength(workspaceRaw),campaigns:[parent,stronger].map(x=>({campaignDigest:x.campaignDigest,state:x.state,bindings:x.bindings,stageStates:x.result.stages.map(x=>x.status)})),future:{tasks:bank.tasks.length,treatments:evaluation.summaries.length,outcomes:evaluation.runs.length,statuses:Object.fromEntries(['accepted','rejected','inconclusive'].map(s=>[s,evaluation.runs.filter(x=>x.status===s).length])),summaries:evaluation.summaries},realTask:{operationalState:realRecord.operationalState,artifactInvoked:false,outputChecks:0},nativeReturns:returned,allNativeWrappersImported:true,docketSections:13,docketVerified:true,docketSha256:sha(exported),workspaceSha256:sha(workspaceRaw),reopenedWorkspaceByteIdentical:true,reopenedDocketByteIdentical:true,all42OutcomesAndCostsRetained:true,currenciesCombined:costs.currenciesCombined,totalComplete:costs.totalComplete,authority:'none',externalExecution:'unprovisioned',releaseInstalledQualification:false,hostedBrowserQualification:false,organizationalAcceptance:false,sourceLimits:{workspaceEvents:workspace.LIMITS.events,workspaceBytes:workspace.LIMITS.bytes,chosenReceiverCoverage:'Manager+Jobs six successor stages each; Fleet successor evolve; parent and successor each contain all six actual finite stages'}};
 save('report.json',report);save('cost-ledger.json',costs);log('journey-complete',{missionId:value.missionId,eventCount:value.events.length,workspaceBytes:Buffer.byteLength(workspaceRaw),nativeReturns:returned.length,docketSha256:sha(exported),reopenedByteIdentical:true});save('journey-log.json',journal);
}catch(error){
 log('journey-failed',{message:error.message,stack:error.stack});try{save('failure.json',{message:error.message,stack:error.stack,journal});}catch{}process.exitCode=1;
}finally{boundary?.close();}
