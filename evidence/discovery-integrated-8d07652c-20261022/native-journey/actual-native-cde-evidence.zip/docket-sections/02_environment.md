# Environment

Bounded public synthetic integer computations in the installed browser/Node runtime.
Source/file identities are retained declarations unless separately authenticated against installed context.
Receiver checking is local; no remote execution, payment, energy measurement or organizational independence is inferred.
