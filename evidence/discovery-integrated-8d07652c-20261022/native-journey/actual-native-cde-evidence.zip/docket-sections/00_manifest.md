# Discovery Lab Evidence Docket

Schema: successor-discovery-evidence-docket/v1

Mission: capability-511cd038-a94f-4dc1-9303-c69974db703c

History head: 1d3796e068c5e3723835e096366eb2e222dc6f610dc0353bdb402160c3b0f0b7

Run commitment: 9fc36dd3e45340216182280754b05c2fa6fa1663a2ba6b34efe0869460bceb11

Derived from the complete existing mission history. Attachments bind this exact head; they are not new history events.
Replay checks bounded synthetic computations. Imported evidence grants no capability, payment or execution authority.
