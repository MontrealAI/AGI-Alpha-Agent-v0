import errno,json,pathlib
checks={}
for name,path in (('verifier_state','/home/runner/work/AGI-Alpha-Agent-v0/AGI-Alpha-Agent-v0/dynamic-evidence/verifier-state.txt'),('oracle_source','/home/runner/work/AGI-Alpha-Agent-v0/AGI-Alpha-Agent-v0/contrib/invention_automation/dynamic_oracle.py')):
 try: pathlib.Path(path).write_text('candidate-mutated')
 except OSError as error: checks[name]=error.errno in (errno.ENOENT,errno.EACCES,errno.EROFS,errno.EPERM)
 else: checks[name]=False
print(json.dumps({'checks':checks},sort_keys=True))
