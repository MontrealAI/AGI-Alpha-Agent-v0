# AGI ALPHA — recorded discovery demonstration

Open `index.html` locally. Everything is embedded; the interface makes no network requests and requires no installation. Choose English or French, select any of the nine measured scopes, inspect the two timing evaluations, and download the original source-assurance ZIP or all embedded evidence data.

This is a replay of recorded discovery evidence. It does not execute an AGI ALPHA mission, add a runtime, or demonstrate a new productive asset. No qualifying investment was selected, no new confirmation cohort was frozen, and no incremental repayment is claimed. Its authoring and inference costs remain unknown. Existing Harness, Fleet, operator and production holds are preserved.

## Rebuild

Use Python's standard library. The root can be the original research workspace, the extracted companion directory containing `evidence/`, or the delivery directory containing `companion/evidence/`.

```bash
python demo/build_demo.py --root /absolute/path/to/companion
python demo/verify_demo.py --root /absolute/path/to/companion
```

The builder defaults to writing beside itself. An optional `--output` path writes elsewhere. The verifier requires Node for syntax checking and a small DOM stub that exercises both languages, all nine scopes and all three downloads. It also reconciles embedded data with source records, verifies the actual ZIP, checks the content security policy hashes and performs an identical rebuild. This is code-level validation; no real-browser or visual qualification is claimed.

## Evidence boundary

- Five source scopes, two recorded evaluations each, include planning, delivery, the existing independent software verifier, research ZIP packaging, reconnect and revalidation. “Independent” describes the separate verifier implementation, not an independent external reviewer.
- Four catalogue scopes, two evaluations each, include local catalogue output and the native recovery path where it succeeds. The 1,216-row scope preserves the native `ARTIFACT_POLICY` refusal. The historical JSON field `browserDelivery` records local catalogue production in this study; it is not browser execution evidence.
- Source CPU includes recorded waited-child accounting. Catalogue scope CPU is Node process CPU; campaign child-process measurements are separate. These are different useful workflows, not interchangeable efficiency benchmarks.
- The original nine-file archive is 7,529 bytes and has SHA-256 `b5265c2ac5db499de527573c63594256eae332196c583576ae48bd2b48930053`.
- The oversized `joined.csv` has **253,267 UTF-8 bytes**, **253,263 JavaScript UTF-16 code units**, and an existing native cap of **200,000 code units**. The original opportunity-screen prose called the byte count characters. This viewer preserves the records and displays corrected units; it changes no policy.
- Nine discovery scopes overlap. Eighteen evaluations are not eighteen unique customer jobs. All inspected inputs are discovery inputs, not an untouched confirmation set.
- Zero fixed-workflow service model calls does not imply zero study authoring cost, operator effort or total monetary cost. No sales or financial transactions occurred.

## Files

`index.html` is the portable user-facing demonstration. `build_demo.py` reproduces it from evidence; `verify_demo.py` validates data and controls. `build-manifest.json` and `verification.json` state identities, checks and limits. No external fonts, scripts, images or services are used.
