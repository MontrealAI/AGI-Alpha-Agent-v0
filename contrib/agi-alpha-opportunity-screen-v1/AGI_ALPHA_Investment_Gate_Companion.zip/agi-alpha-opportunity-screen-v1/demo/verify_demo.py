#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Offline data, integrity, syntax and control checks. Not browser visual QA."""
import argparse
import base64
import hashlib
from html.parser import HTMLParser
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import tempfile
import zipfile


class Page(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=False)
        self.ids = []
        self.translations = []
        self.scripts = []
        self.styles = []
        self.active = None
        self.external = []
        self.csp = None
    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if 'id' in a:
            self.ids.append(a['id'])
        if 'data-t' in a:
            self.translations.append(a['data-t'])
        for key in ['src', 'href']:
            if key in a and not a[key].startswith(('#', 'data:')):
                self.external.append(a[key])
        if tag == 'meta' and a.get('http-equiv') == 'Content-Security-Policy':
            self.csp = a['content']
        if tag in ['script', 'style']:
            self.active = (tag, a, [])
    def handle_endtag(self, tag):
        if self.active and self.active[0] == tag:
            _, attrs, data = self.active
            (self.scripts if tag == 'script' else self.styles).append((attrs, ''.join(data)))
            self.active = None
    def handle_data(self, data):
        if self.active:
            self.active[2].append(data)


NODE_TEST = r'''
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const input=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));
class Element{constructor(id){this.id=id;this.innerHTML='';this.textContent='';this.value='';this.dataset={};this.attrs={};this.listeners={};}setAttribute(k,v){this.attrs[k]=v;}addEventListener(k,f){this.listeners[k]=f;}click(){if(this.listeners.click)this.listeners.click();}remove(){}}
const ids=Object.fromEntries(input.ids.map(k=>[k,new Element(k)]));ids['evidence-data'].textContent=JSON.stringify(input.data);
const translations=input.translations.map(k=>{const e=new Element('');e.dataset.t=k;e.innerHTML='EN:'+k;return e;});
let downloads=[],revoked=0;
const context={document:{getElementById:k=>{assert.ok(ids[k],k);return ids[k]},querySelectorAll:s=>{assert.equal(s,'[data-t]');return translations},documentElement:{lang:'en'},createElement:()=>new Element('download'),body:{appendChild:()=>{}}},Blob,URL:{createObjectURL:b=>{downloads.push(b);return 'blob:recorded-demo'},revokeObjectURL:()=>{revoked++}},atob:s=>Buffer.from(s,'base64').toString('binary'),setTimeout:f=>f()};
vm.createContext(context);vm.runInContext(input.script,context,{timeout:2000});
assert.equal(context.document.documentElement.lang,'en');assert.equal(ids.scope.value,'source-prior-versions');
assert.equal(ids.count.textContent,'5');assert.match(ids['changed-paths'].innerHTML,/run-mission.mjs/);
for(const language of ['en','fr']){ids[language].click();assert.equal(context.document.documentElement.lang,language);assert.equal(ids[language].attrs['aria-pressed'],'true');for(const element of translations){assert.equal(typeof element.innerHTML,'string');assert.ok(element.innerHTML.length>0,element.dataset.t);assert.ok(!element.innerHTML.includes('undefined'),element.dataset.t);}for(const scope of input.data.scopes){ids.scope.value=scope.id;ids.scope.listeners.change();assert.ok(ids.wall.textContent.includes(' s'));assert.ok(ids.cpu.textContent.includes(' s'));assert.ok(ids['run-rows'].innerHTML.includes('<td>'));assert.ok(ids['scope-status'].textContent.length>0);}}
for(const id of ['download-zip','download-data','download-report'])ids[id].click();
assert.equal(downloads.length,3);assert.equal(revoked,3);
(async()=>{const zip=Buffer.from(await downloads[0].arrayBuffer());assert.equal(zip.toString('base64'),input.data.archive.base64);const data=JSON.parse(await downloads[1].text());assert.equal(data.scopes.length,9);assert.equal(data.selectedAsset,null);assert.equal(data.repayment,null);assert.equal(await downloads[2].text(),input.data.archive.report);console.log(JSON.stringify({languages:2,scopeControlsExercised:18,downloadsVerified:3,realBrowser:false}));})().catch(e=>{console.error(e);process.exitCode=1;});
'''


def verify(root: Path, here: Path) -> dict:
    spec = importlib.util.spec_from_file_location('demo_builder', here / 'build_demo.py')
    builder = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(builder)
    expected = builder.collect(root)
    page = (here / 'index.html').read_text()
    parsed = Page()
    parsed.feed(page)
    assert len(parsed.ids) == len(set(parsed.ids)), 'Duplicate IDs'
    assert not parsed.external, parsed.external
    assert len(parsed.scripts) == 2 and len(parsed.styles) == 1
    data = json.loads(next(text for attrs, text in parsed.scripts if attrs.get('type') == 'application/json'))
    script = next(text for attrs, text in parsed.scripts if not attrs)
    assert data == expected, 'Embedded data differ from measured evidence'
    assert len(data['scopes']) == 9 and sum(len(s['wall']) for s in data['scopes']) == 18
    assert data['selectedAsset'] is None and data['repayment'] is None and data['gate'] == 'HOLD'
    assert 'connect-src \'none\'' in parsed.csp
    assert 'sha256-' + base64.b64encode(hashlib.sha256(script.encode()).digest()).decode() in parsed.csp
    style = parsed.styles[0][1]
    assert 'sha256-' + base64.b64encode(hashlib.sha256(style.encode()).digest()).decode() in parsed.csp
    archive = base64.b64decode(data['archive']['base64'])
    assert hashlib.sha256(archive).hexdigest() == data['archive']['sha256']
    with zipfile.ZipFile(io.BytesIO(archive)) as z:
        assert z.testzip() is None and z.namelist() == data['archive']['members']
    with tempfile.TemporaryDirectory(prefix='alpha-demo-check-') as temp:
        t = Path(temp)
        script_path = t / 'script.js'
        script_path.write_text(script)
        syntax = subprocess.run(['node', '--check', str(script_path)], capture_output=True, text=True)
        assert syntax.returncode == 0, syntax.stderr
        (t / 'input.json').write_text(json.dumps(dict(ids=parsed.ids, translations=parsed.translations, data=data, script=script)))
        (t / 'smoke.cjs').write_text(NODE_TEST)
        smoke = subprocess.run(['node', str(t / 'smoke.cjs'), str(t / 'input.json')], capture_output=True, text=True, timeout=10)
        assert smoke.returncode == 0, smoke.stderr
        dom = json.loads(smoke.stdout)
        builder.build(root, t / 'rebuilt')
        assert (t / 'rebuilt/index.html').read_bytes() == (here / 'index.html').read_bytes(), 'Nondeterministic rebuild'
    result = dict(schema='agi-alpha-recorded-demo-check/v1', status='PASS',
        evidenceReconciliation=True, bilingualKeys=len(parsed.translations), archiveMembers=9,
        archiveSha256=data['archive']['sha256'], cspHashesMatch=True, externalResources=[],
        javascriptSyntax='PASS', controls=dom, deterministicRebuild=True,
        browserVisualValidation=False, workflowExecution=False,
        pageSha256=hashlib.sha256(page.encode()).hexdigest(),
        limitations='Minimal DOM stub checks handlers and downloads only; no layout, assistive-technology, or real-browser validation.')
    (here / 'verification.json').write_text(json.dumps(result, indent=2) + '\n')
    return result


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root', type=Path, required=True)
    a = p.parse_args()
    print(json.dumps(verify(a.root.resolve(), Path(__file__).resolve().parent), indent=2))
