# AGI ALPHA: opportunity screen and exposed-discovery replay

This companion preserves measured discovery evidence and its adverse outcomes. **No productive investment was selected, no confirmation set was frozen, and no repayment or acceleration claim was admitted.** It is an additive record of the existing system, not a replacement runtime or economic calculator.

## Reproduce offline

Use Python 3.12, Node 24.22.1 and Git 2.51.1, the versions exercised in the recorded run. All reproduction dependencies are the language standard libraries and the byte-identical public source files in `vendor/`. No package download, credential, paid model, network service, wallet, operator installation, Fleet provisioning or held Harness action is needed.

From this directory, choose an output path that does not exist:

```sh
python3 reproduce.py --output ./new-reproduction
```

The command first checks the entire companion manifest and original source blob identities. It then materializes a disposable, partial local Git object database and invokes the **unchanged existing Python source-assurance verifier** against all ten saved deliveries. Finally, it reruns the existing catalogue CLI and native return/reopen path on the four archived discovery inputs. These inputs were already exposed; rerunning them does not produce fresh confirmation missions.

For a saved-evidence audit without catalogue recomputation:

```sh
python3 reproduce.py --audit-only --output ./new-audit
```

The source-assurance database retains the original commit, relevant directory trees and required blobs. It intentionally omits unrelated objects and parent history. It is not a full clone and has no configured remote. `GIT_OBJECT_MANIFEST.json` identifies every archived object and the original public commit. The object pack is sufficient for the scoped, exact committed-path reads performed by the unchanged verifier.

## Expected results

- Ten source-assurance deliveries and their retained reservations, artifacts, CSVs, source hashes and report context pass the existing independent verifier. Their customer ZIPs contain the same verified payloads.
- All four catalogue scopes reproduce their deterministic CSV outputs and complete catalogue delivery.
- Runtime, examples and tests scopes reproduce native delivery and continuity reopening.
- The full-package scope preserves the expected `ARTIFACT_POLICY` refusal. The source's native cap measures JavaScript string length; source output byte counts are a separate quantity. No limit is changed to make this case pass.
- Financial collections, full monetary costs, human attention, fixed construction, review and maintenance costs remain unknown where the original records say unknown.

`verification.json` reports the actual reproduction outcome. A successful saved-output audit verifies retained evidence; it does not establish approved-operator execution, source-profile adoption, production security clearance, customer demand or commercial acceptance.

## Contents and provenance

| Location | Contents |
| --- | --- |
| `evidence/source-profile/` | Original profiling harness, sandbox refusals, additive failure adjudication, successful separately approved local run, exact commands, process observations, plans, full delivery directories and customer ZIPs. |
| `evidence/catalog-profile/` | Original four-scope profiling, two replications per scope, exact public CSV inputs, complete reports, native returns/continuity, package refusal and process accounting. |
| `evidence/prior-review/` | Previous-study audit, original package/identity rechecks and economic audit. Duplicate extracted paper text is omitted. |
| `vendor/alpha-main/` | Byte-identical required source closure at `3b040e68adae8196f7bda4c65f92af92ee6f7335`. |
| `vendor/alpha-integration/` | Byte-identical guide, source-assurance verification and canonical cost/shadow-ledger sources at `496fa3c00dc7498173a896404ec756dfdeb94033`. |
| `SOURCE_MANIFEST.json` | Original public path, commit, Git blob identity, byte count and SHA-256 for every vendored file. Original licenses and notices remain. |
| `source-496fa3c.objects.pack` | Minimal original Git object set for offline saved-source-output verification. |
| `MANIFEST.json` | SHA-256 and size of every immutable companion member at sealing. Reproduction outputs are separate. |
| `replay.mjs` | Invocation adapter using unchanged installed catalogue/native functions and archived inputs. |
| `reproduce.py` | Independent manifest/CSV/package audit, local object materialization, invocation of the existing verifier and catalogue replay. |

## Reproducibility limits

The original source profiling records complete foreground execution, including waited Git child CPU, on its recorded host. This offline companion rechecks those original outputs; it does not pretend to regenerate those historical timings. Fresh full source-service profiling requires a full public checkout at the exact integration commit and the recorded local foreground permissions. The unchanged original profiler is preserved as historical executed research code and retains its original workspace paths.

The original catalogue profile includes preparation by comparing committed Git tree identities with checkout bytes. This companion archives the exact resulting CSVs and the preparation record. Catalogue replay starts from those committed CSVs and therefore does not repeat a full checkout inventory. It checks the original CSV SHA-256 identities, recomputes their outcomes and preserves every original catalogue/native limit.

The first source-profile sandbox run failed before producing a plan because Node's native Git subprocess was refused. Its records remain intact. An ordinary automatic-review-approved invocation then ran the unchanged foreground public-source workflow successfully. Separately, `strace` was refused by the host; it was not retried. Full tool counts are explicitly source-derived; measured runtime receipts cover only their declared components.

Reproduction verifies finite local software behavior and evidence consistency. It creates no approval, credential, financial right, deployment or revised security policy. Neither `$AGIALPHA` route labels in unfunded drafts nor USDC ledger units represent an actual transaction.
