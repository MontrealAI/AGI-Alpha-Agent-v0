// SPDX-License-Identifier: Apache-2.0
import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {dirname,resolve,join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {runCli} from './vendor/alpha-main/examples/successor-alpha/cli.mjs';
import {inspectProject} from './vendor/alpha-main/examples/successor-alpha/project.mjs';
import {computeInstalledSourceHash,runHandoffFile} from './vendor/alpha-main/examples/successor-alpha/native-cli.mjs';
import {createNativeHandoff,inspectNativeReturn,importNativeReturn,inspectContinuity} from './vendor/alpha-main/examples/successor-alpha/continuity.mjs';
const base=dirname(fileURLToPath(import.meta.url));
const output=resolve(process.argv[2]??join(base,'catalogue-replay'));
await mkdir(output,{recursive:false});
const prior=JSON.parse(await readFile(join(base,'evidence/catalog-profile/summary.json'),'utf8'));
const digest=value=>createHash('sha256').update(value).digest('hex');
const sourceHash=await computeInstalledSourceHash();
const rows=[];
for(const task of ['runtime','examples','tests','package']){
 const old=prior.runs.find(r=>r.task===task&&r.repetition===1);
 assert.equal(sourceHash,old.nativeSourceHash,'Archived installed source identity changed');
 const input=join(base,'evidence/catalog-profile',task+'-1'),dest=join(output,task);await mkdir(dest);
 const left=await readFile(join(input,'expected.csv')),right=await readFile(join(input,'actual.csv'));
 assert.equal(digest(left),old.inputs.leftSha256);assert.equal(digest(right),old.inputs.rightSha256);
 let log='';await runCli(['--left',join(input,'expected.csv'),'--right',join(input,'actual.csv'),'--left-key','path','--right-key','path','--out',join(dest,'delivery')],{write:s=>{log+=s;}});
 await writeFile(join(dest,'cli.log'),log);
 const project=await inspectProject(await readFile(join(dest,'delivery/project.json'),'utf8'));
 assert.equal(project.cycles[0].result.reconciliation.matchedPairs,old.inputs.rows);
 assert.equal(project.cycles[0].result.reconciliation.conflicts.length,old.inputs.expectedConflicts);
 for(const name of ['joined.csv','conflicts.csv','unmatched-left.csv','unmatched-right.csv'])
  assert.deepEqual(await readFile(join(dest,'delivery',name)),await readFile(join(input,'delivery',name)),'Archived deterministic CSV changed: '+name);
 const handoff=await createNativeHandoff(project,{route:'AGIALPHA',sourceHash,rights:{dataClass:'public',source:'Replay of already exposed public source inventory at '+prior.source+'; not fresh confirmation',license:'Public Apache-2.0 repository metadata; per-file licenses retained'},owner:'local-research',reviewMinutes:1});
 await writeFile(join(dest,'handoff.json'),handoff);
 const row={task,sourceHash,rows:old.inputs.rows,uniqueFreshMissions:0,catalogueDelivery:true,deterministicCsvBytesEqual:true,native:null};
 try{
  await runHandoffFile(join(dest,'handoff.json'),join(dest,'native-return.json'));
  const returned=await readFile(join(dest,'native-return.json'),'utf8');const checked=await inspectNativeReturn(handoff,returned);
  const continuity=await importNativeReturn(project,handoff,returned,{sourceHash});await writeFile(join(dest,'continuity.json'),continuity);
  const restored=await inspectContinuity(continuity);assert.equal(restored.project.id,project.id);
  assert.equal(old.outcome,'full-native-delivery-and-history-reopen');row.native='DELIVERED_REOPENED';row.returnFiles=checked.files.length;
 }catch(error){
  if(task!=='package'||error.message!=='ARTIFACT_POLICY'||old.failure!=='ARTIFACT_POLICY')throw error;
  row.native='EXPECTED_REFUSAL';row.reason=error.message;
 }
 rows.push(row);
}
const result={schema:'agi-alpha-exposed-discovery-replay/v1',passed:true,sourceCommit:prior.source,sourceHash,rows,limits:'New executions of already exposed archived inputs. Same fixed existing methods, artifact limits and unfunded drafts. No model, network, wallet, credential, operator or held Harness/Fleet execution; no fresh confirmation or economic promotion.'};
await writeFile(join(output,'replay.json'),JSON.stringify(result,null,2)+'\n');process.stdout.write(JSON.stringify(result)+'\n');
