# SPDX-License-Identifier: Apache-2.0
"""Audit archived discovery evidence and optionally replay the existing catalogue.

All runtime implementation files are byte-identical archived sources. This
wrapper adapts their invocation paths and does not create fresh confirmation data.
"""

import argparse
import csv
import hashlib
import json
import os
import pathlib
import shutil
import subprocess
import sys
import time
import zipfile
from typing import Any

BASE = pathlib.Path(__file__).resolve().parent


def read(path: pathlib.Path) -> Any:
    """Read one archived JSON record without changing its contents."""
    return json.loads(path.read_text())


def sha(path: pathlib.Path) -> str:
    """Return the SHA-256 identity of the exact file bytes."""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def call(
    args: list[str], cwd: pathlib.Path | None = None, raw: bytes | None = None
) -> bytes:
    """Run a bounded local command and retain its stdout or raised failure."""
    env = dict(
        os.environ,
        PYTHONDONTWRITEBYTECODE="1",
        GIT_TERMINAL_PROMPT="0",
        GIT_OPTIONAL_LOCKS="0",
    )
    return subprocess.run(
        args,
        cwd=cwd,
        input=raw,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=True,
        timeout=120,
        env=env,
    ).stdout


def audit_saved(out: pathlib.Path) -> dict[str, Any]:
    """Check sealed bytes and saved deliveries through the unchanged verifier."""
    manifest = read(BASE / "MANIFEST.json")
    count = 0
    for row in manifest["files"]:
        f = BASE / row["path"]
        assert (
            f.is_file() and f.stat().st_size == row["bytes"] and sha(f) == row["sha256"]
        ), row["path"]
        count += 1
    source = read(BASE / "SOURCE_MANIFEST.json")
    for row in source["files"]:
        f = BASE / row["path"]
        raw = f.read_bytes()
        assert (
            hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
            == row["gitBlob"]
        )
    cat = read(BASE / "evidence/catalog-profile/summary.json")
    for path, digest in cat["sourceFiles"].items():
        assert sha(BASE / "vendor/alpha-main" / path) == digest
    for run in cat["runs"]:
        d = BASE / "evidence/catalog-profile" / f"{run['task']}-{run['repetition']}"
        assert (
            sha(d / "expected.csv") == run["inputs"]["leftSha256"]
            and sha(d / "actual.csv") == run["inputs"]["rightSha256"]
        )
        with (d / "expected.csv").open(newline="") as f:
            left = list(csv.DictReader(f))
        with (d / "actual.csv").open(newline="") as f:
            right = list(csv.DictReader(f))
        assert len(left) == len(right) == run["inputs"]["rows"]
        rightmap = {r["path"]: r["git_blob_oid"] for r in right}
        assert len(rightmap) == len(right)
        conflicts = sum(row["git_blob_oid"] != rightmap[row["path"]] for row in left)
        assert conflicts == run["inputs"]["expectedConflicts"]
        with (d / "delivery/joined.csv").open(newline="") as f:
            assert len(list(csv.reader(f))) - 1 == len(left)
        if run["task"] == "package":
            assert (
                run["outcome"] == "catalogue-delivered-native-path-refused"
                and run["failure"] == "ARTIFACT_POLICY"
                and not (d / "native-return.json").exists()
            )
    pack = read(BASE / "GIT_OBJECT_MANIFEST.json")
    assert sha(BASE / pack["packFile"]) == pack["packSha256"]
    workspace = out / "source-workspace"
    shutil.copytree(BASE / "vendor/alpha-integration", workspace)
    call(["git", "init", "--quiet"], cwd=workspace)
    call(
        ["git", "index-pack", "--stdin"],
        cwd=workspace,
        raw=(BASE / pack["packFile"]).read_bytes(),
    )
    objects = (
        call(
            ["git", "cat-file", "--batch-check"],
            cwd=workspace,
            raw=("\n".join(x["oid"] for x in pack["objects"]) + "\n").encode(),
        )
        .decode()
        .splitlines()
    )
    assert objects == [f"{x['oid']} {x['type']} {x['bytes']}" for x in pack["objects"]]
    profile = BASE / "evidence/source-profile/approved-process-run"
    results = read(profile / "results.json")
    verifications = []
    for row in results:
        run = profile / "runs" / ("profile-" + row["id"])
        complete = read(run / "COMPLETE.json")
        for name, digest in complete["artifacts"].items():
            assert sha(run / name) == digest
        verified = json.loads(
            call(
                [
                    sys.executable,
                    "-I",
                    str(
                        workspace
                        / "contrib/productive-capability-ledger/automation-v1/verify-run.py"
                    ),
                    str(run),
                ]
            )
        )
        assert (
            verified["accepted"]
            and verified["changedPaths"] == row["changedPaths"]
            and verified["sourceRows"] == row["sourceCount"]
        )
        archive = profile / (row["id"] + ".zip")
        assert sha(archive) == row["export"]["sha256"]
        with zipfile.ZipFile(archive) as z:
            assert z.testzip() is None and len(z.namelist()) == 9
            for name in z.namelist():
                if name != "independent-acceptance.json":
                    assert z.read(name) == (run / name).read_bytes()
        verifications.append(
            {
                "id": row["id"],
                "accepted": True,
                "checks": verified["checks"],
                "sourceRows": verified["sourceRows"],
                "changedPaths": verified["changedPaths"],
            }
        )
    return {
        "manifestFiles": count,
        "byteIdenticalVendorFiles": len(source["files"]),
        "originalGitObjects": len(pack["objects"]),
        "catalogueDiscoveryScopes": 4,
        "catalogueOperatingReplications": len(cat["runs"]),
        "sourceDiscoveryScopes": 5,
        "sourceSavedOutputVerifications": verifications,
        "originalNegativeOutcomesPreserved": True,
    }


def main() -> None:
    """Write audit results to a new directory, keeping original evidence intact."""
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output", type=pathlib.Path, default=BASE / "reproduction-output"
    )
    parser.add_argument("--node", default="node")
    parser.add_argument("--audit-only", action="store_true")
    args = parser.parse_args()
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    started = time.monotonic()
    result = {
        "scope": "Offline recheck of saved discovery evidence; no investment candidate or confirmation set was selected."
    }
    try:
        result["audit"] = audit_saved(out)
        if not args.audit_only:
            response = call(
                [args.node, str(BASE / "replay.mjs"), str(out / "catalogue")]
            )
            result["catalogueReplay"] = json.loads(response)
        result.update(
            passed=True,
            elapsedSeconds=time.monotonic() - started,
            models=0,
            networkRequests=0,
            monetaryPaybackEstablished=False,
        )
    except Exception as error:
        result.update(
            passed=False, error=str(error), elapsedSeconds=time.monotonic() - started
        )
        if isinstance(error, subprocess.CalledProcessError):
            result["stderr"] = error.stderr.decode(errors="replace")
        (out / "verification.json").write_text(json.dumps(result, indent=2) + "\n")
        print(json.dumps(result))
        raise
    (out / "verification.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
