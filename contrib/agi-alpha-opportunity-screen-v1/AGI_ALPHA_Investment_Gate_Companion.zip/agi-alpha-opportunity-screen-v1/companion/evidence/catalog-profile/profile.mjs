import { readFile, writeFile, mkdir, lstat, readlink, readdir } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { resolve, join } from 'node:path';
import { performance } from 'node:perf_hooks';
import * as catalog from '../../repos/alpha/examples/successor-alpha/engine.mjs';
import * as project from '../../repos/alpha/examples/successor-alpha/project.mjs';
import { runCli } from '../../repos/alpha/examples/successor-alpha/cli.mjs';
import { computeInstalledSourceHash, runHandoffFile } from '../../repos/alpha/examples/successor-alpha/native-cli.mjs';
import { createNativeHandoff, inspectNativeReturn, importNativeReturn, inspectContinuity, LIMITS } from '../../repos/alpha/examples/successor-alpha/continuity.mjs';

const root = resolve('repos/alpha'), out = resolve('evidence/catalog-profile');
const begun = performance.now(), startCpu = process.cpuUsage();
const digest = value => createHash('sha256').update(value).digest('hex');
const gitInputs=JSON.parse(await readFile(join(out,'git-preparation.json'),'utf8'));
const summary = {schema:'agi-alpha-local-opportunity-profile/v1',startedAt:new Date().toISOString(),source:gitInputs.source,runtime:process.version,limits:{wallSeconds:900,cpuSeconds:600,catalog:catalog.DEFAULT_LIMITS,continuity:LIMITS,nativeArtifactCharacters:200000},scope:'Existing fixed local catalogue workflow, public repository inventory reconciliation, no authenticated execution',stages:[],runs:[],costs:{providerCalls:0,financialTransactions:0,authoringInferenceCost:null,operatorAttention:null,computePrice:null,reviewMinutes:'Native required minimum allowance 1; no performed review or attention measurement'},uniqueTasks:4,repetitionsPerTask:2,claims:{economicWin:false,customerAcceptance:false,independentReview:false},sourceFiles:{}};
await mkdir(out,{recursive:true});
for(const p of ['examples/successor-alpha/engine.mjs','examples/successor-alpha/project.mjs','examples/successor-alpha/cli.mjs','examples/successor-alpha/continuity.mjs','examples/successor-alpha/native-cli.mjs','examples/successor-workbench/engine.mjs','docs/assets/successor/engine.mjs']) summary.sourceFiles[p]=digest(await readFile(join(root,p)));
async function stage(task, repetition, name, fn) {
    if (performance.now()-begun>900000 || (process.cpuUsage(startCpu).user+process.cpuUsage(startCpu).system)>600000000) throw Error('PROFILE_RESOURCE_CEILING');
    const cpu=process.cpuUsage(), t=performance.now(), row={task,repetition,stage:name};
    try {const value=await fn(); row.status='pass'; return value;}
    catch(error){row.status='failed';row.error=String(error.message);throw error;}
    finally {const used=process.cpuUsage(cpu);Object.assign(row,{wallMs:performance.now()-t,cpuMs:(used.user+used.system)/1000,maxRssKiB:process.resourceUsage().maxRSS});summary.stages.push(row);await writeFile(join(out,'summary.json'),JSON.stringify(summary,null,2)+'\n');}
}
const scopes=[['runtime','alpha_factory_v1/core/runtime'],['examples','examples'],['tests','tests'],['package','alpha_factory_v1']];
for(const [task,scope] of scopes) for(let repetition=1;repetition<=2;repetition++) {
    const taskDir=join(out,task+'-'+repetition);await mkdir(taskDir);
    const run={task,repetition,scope,startedAt:new Date().toISOString(),outcome:'incomplete'};summary.runs.push(run);
    const totalCpu=process.cpuUsage(), totalStart=performance.now();
    try {
        const inputs=await stage(task,repetition,'prepare-public-git-inventories',async()=>{
            const tree=gitInputs.trees[task].split('\0').filter(Boolean);
            const expected=[],actual=[];
            for(const entry of tree){const at=entry.indexOf('\t'),[mode,type,oid]=entry.slice(0,at).split(' '),name=entry.slice(at+1);if(type!=='blob')throw Error('Unsupported non-blob');expected.push([name,oid]);const st=await lstat(join(root,name));const bytes=st.isSymbolicLink()?Buffer.from(await readlink(join(root,name))):await readFile(join(root,name));const actualOid=createHash('sha1').update(Buffer.from('blob '+bytes.length+'\0')).update(bytes).digest('hex');actual.push([name,actualOid]);}
            const left=project.tableCsv({headers:['path','git_blob_oid'],rows:expected}),right=project.tableCsv({headers:['path','git_blob_oid'],rows:actual});
            await writeFile(join(taskDir,'expected.csv'),left);await writeFile(join(taskDir,'actual.csv'),right);
            return {rows:expected.length,leftBytes:Buffer.byteLength(left),rightBytes:Buffer.byteLength(right),leftSha256:digest(left),rightSha256:digest(right),expectedConflicts:expected.filter((r,i)=>r[1]!==actual[i][1]).length};
        });run.inputs=inputs;
        let cliLog='';
        await stage(task,repetition,'complete-catalogue-cli-nine-artifacts',()=>runCli(['--left',join(taskDir,'expected.csv'),'--right',join(taskDir,'actual.csv'),'--left-key','path','--right-key','path','--out',join(taskDir,'delivery')],{write:s=>{cliLog+=s;}}));
        await writeFile(join(taskDir,'cli.log'),cliLog);
        const dossier=await stage(task,repetition,'restore-and-semantically-recheck-project',async()=>project.inspectProject(await readFile(join(taskDir,'delivery/project.json'),'utf8')));
        run.browserDelivery={status:'pass',artifacts:await readdir(join(taskDir,'delivery')),rows:dossier.cycles[0].mission.left.rows.length,matched:dossier.cycles[0].result.reconciliation.matchedPairs,conflicts:dossier.cycles[0].result.reconciliation.conflicts.length};
        if(run.browserDelivery.matched!==inputs.rows||run.browserDelivery.conflicts!==inputs.expectedConflicts)throw Error('Independent inventory counts disagree');
        const sourceHash=await stage(task,repetition,'compute-installed-source-identity',()=>computeInstalledSourceHash());run.nativeSourceHash=sourceHash;
        const handoff=await stage(task,repetition,'create-native-handoff-and-seven-work-drafts',()=>createNativeHandoff(dossier,{route:'AGIALPHA',sourceHash,rights:{dataClass:'public',source:'Public MontrealAI/AGI-Alpha-Agent-v0 Git tree '+summary.source+' '+scope+' versus exact checkout bytes',license:'Public Apache-2.0 repository metadata; original per-file licenses retained'},owner:'local-research',reviewMinutes:1}));
        await writeFile(join(taskDir,'handoff.json'),handoff);run.handoffBytes=Buffer.byteLength(handoff);
        await stage(task,repetition,'native-host-full-run-and-exclusive-output',()=>runHandoffFile(join(taskDir,'handoff.json'),join(taskDir,'native-return.json')));
        const returned=await readFile(join(taskDir,'native-return.json'),'utf8');run.returnBytes=Buffer.byteLength(returned);
        const checked=await stage(task,repetition,'inspect-native-return',()=>inspectNativeReturn(handoff,returned));
        run.nativeDelivery={status:'pass',files:checked.files.map(f=>({name:f.name,bytes:Buffer.byteLength(f.content),sha256:digest(f.content)})),summary:checked.pack.result.summary};
        const continuity=await stage(task,repetition,'import-return-and-retain-project-history',()=>importNativeReturn(dossier,handoff,returned,{sourceHash}));
        await writeFile(join(taskDir,'continuity.json'),continuity);run.continuityBytes=Buffer.byteLength(continuity);
        const restored=await stage(task,repetition,'reopen-continuity-and-recheck-all-history',async()=>inspectContinuity(await readFile(join(taskDir,'continuity.json'),'utf8')));
        if(restored.project.id!==dossier.id)throw Error('Project identity changed');
        run.outcome='full-native-delivery-and-history-reopen';
    } catch(error) {run.failure=String(error.message);run.outcome=run.browserDelivery?'catalogue-delivered-native-path-refused':'delivery-refused';}
    const used=process.cpuUsage(totalCpu);run.wallMs=performance.now()-totalStart;run.cpuMs=(used.user+used.system)/1000;run.finishedAt=new Date().toISOString();
    await writeFile(join(out,'summary.json'),JSON.stringify(summary,null,2)+'\n');
    process.stdout.write(JSON.stringify({task,repetition,outcome:run.outcome,rows:run.inputs?.rows,wallMs:run.wallMs,cpuMs:run.cpuMs,failure:run.failure})+'\n');
}
summary.finishedAt=new Date().toISOString();summary.totalWallMs=performance.now()-begun;const cpu=process.cpuUsage(startCpu);summary.totalNodeCpuMs=(cpu.user+cpu.system)/1000;summary.maxRssKiB=process.resourceUsage().maxRSS;
await writeFile(join(out,'summary.json'),JSON.stringify(summary,null,2)+'\n');
