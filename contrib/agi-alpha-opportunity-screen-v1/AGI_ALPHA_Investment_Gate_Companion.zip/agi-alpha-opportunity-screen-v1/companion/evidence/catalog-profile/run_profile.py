import json, pathlib, resource, subprocess, time, shutil
root=pathlib.Path.cwd(); out=root/'evidence/catalog-profile'
if (out/'process-accounting.json').exists(): raise SystemExit('Preserve existing observations; reproduce in a clean companion workspace.')
start=time.monotonic(); usage=resource.getrusage(resource.RUSAGE_CHILDREN)
repo=str(root/'repos/alpha'); prep_start=time.monotonic()
source=subprocess.check_output(['git','-C',repo,'rev-parse','HEAD'],text=True).strip()
trees={name:subprocess.check_output(['git','-C',repo,'ls-tree','-rz','HEAD','--',scope],text=True) for name,scope in [('runtime','alpha_factory_v1/core/runtime'),('examples','examples'),('tests','tests'),('package','alpha_factory_v1')]}
(out/'git-preparation.json').write_text(json.dumps({'source':source,'trees':trees,'wallSeconds':time.monotonic()-prep_start})+'\n')
def limits(): resource.setrlimit(resource.RLIMIT_CPU,(600,600))
try:
    run=subprocess.run(['node',str(out/'profile.mjs')],cwd=root,capture_output=True,text=True,timeout=900,preexec_fn=limits)
    result={'exitCode':run.returncode,'stdout':run.stdout,'stderr':run.stderr}
except subprocess.TimeoutExpired as e: result={'exitCode':None,'timeout':True,'stdout':str(e.stdout),'stderr':str(e.stderr)}
after=resource.getrusage(resource.RUSAGE_CHILDREN)
result.update(wallSeconds=time.monotonic()-start,childUserSeconds=after.ru_utime-usage.ru_utime,childSystemSeconds=after.ru_stime-usage.ru_stime,maxRssKiB=after.ru_maxrss)
(out/'process-accounting.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
