# Prior-study audit: The Advantage That Funds the Next

Audit date: 25 October 2026, America/Toronto. Read-only audit for the new
"Build an Advantage That Repays Its Cost" assignment. The original paper,
companion, outputs, source candidates and publication ownership remain unchanged.

## Finding

The prior edition supplies a working release-inventory intake capability and an
honest negative economic result. It does not supply a measured historical
operating baseline, material avoided recurring expense, additional accepted
output, measured attention reduction, a complete monetary construction cost, or
an economically admitted asset. Its positive financing example relies on an
explicitly unmeasured attention benefit. A new study cannot repair those missing
observations by increasing scenario counts, prices, figures or nominal reuse.

The decisive design failure happened at selection: inventory intake was selected
while the discovery register reported current delivery cost, recurring jobs,
customer attention, construction/integration/verification/upkeep and prospective
payback as unknown. Four heterogeneous inventory files established artifact
variety, not an expensive recurring problem. The technical experiment was well
enough bounded to confirm useful output, but could not manufacture the missing
incremental economic effect.

## Audit scope and preservation

The complete original 14-page paper was read, together with the companion's
protocol, both prospective amendments, candidate freezes, construction records,
development failure, normalizers, ordinary interpreter, integration runner,
evaluator, discovery/fallback screens, resource record, canonical accounting
adapter, cash projection, economic audit, output ledgers and publication limits.
The complete archive inventory was checked byte-for-byte. Saved evidence was
rechecked with its inspected existing pack and economics checkers; the old
technical campaign and model construction were not rerun.

- All 381 manifest entries matched SHA-256 and byte length, totaling 53,518,040
  manifest-listed bytes. The directory contains 382 files; the manifest itself
  is the sole intentionally unlisted file.
- All 20 bindings across the original, candidate and boundary freezes matched.
- Saved-pack recheck passed 10,870 assertions over 192 original method packs,
  preserving 16 unique jobs, 128 source paths, 72 refusal evaluations and 24
  secondary valid-boundary evaluations.
- Saved-economic recheck passed 126,396 assertions over 6,720 original cash
  scenarios and 60 complete traces. It confirmed zero primary investments,
  944 counterfactual investments and 364 cash-depletion scenarios.
- These are repeated verification counts, not new jobs, independent customers,
  new technical confirmation or new financial evidence.
- The first small identity verifier assumed every freeze used a `files` map;
  the boundary freeze uses singular `file`/`sha256`. That read-only KeyError was
  corrected. No original file changed.

Receipts: `identity-audit.json`, `pack-audit-recheck.json`,
`economic-audit-recheck.json` in this directory. The existing audit code was
reused; the recheck is not a newly independent implementation or external peer
review. Its inherited limitation remains: recorded refusal outcomes are audited,
but candidate parsers are not freshly executed by the pack checker.

## What was actually built

The candidate exports `normalize(text, format)` and accepts four JSON inventory
shapes, two-column CSV and SHA256SUMS. It validates exact paths and digests and
returns sorted path/SHA-256 rows. It uses ordinary parsing techniques. The
adapter calls the existing TI guide and `createWorkbench`, returning a report,
normalized inventories, complete comparison, differences CSV, actions CSV and
asset identity. It performs no inspected-source execution or security analysis.

The candidate is a model-assisted research artifact. It was authored outside the
installed Alpha operator runtime. It is not evidence of autonomous invention by
a deployed enterprise.

| Construction quantity | Alpha | Conventional |
| --- | ---: | ---: |
| Recorded elapsed interval | 246.660815 seconds | 170 seconds |
| Candidate attempts | 1 | 2 |
| Final development checks | 62 | 39 |
| Authoring/model token count | Unknown | Unknown |
| Monetary model bill | Unknown | Unknown |
| Complete authoring cost | Unknown | Unknown |
| Active human effort | Unknown | Unknown |

The conventional first candidate rejected a legal U+2028 filename because the
JavaScript regex dot did not include that separator. The initial source, failing
probe and correction remain in its construction record. The fix happened before
confirmation. Both final candidates froze before the new inputs were generated.

## Control and confirmation interpretation

All three methods accepted 16/16 unique source requests and 64/64 representations
per method. Each correctly refused 24 prohibited inputs and passed eight valid
secondary cases. Four representations are robustness repetitions, not 64 jobs.
The archive contains two real changed identities, both in one eight-file Fleet
comparison: `README.md` and `.github/workflows/local-skills.yml`.

| Complete pack timing | Ordinary recipes | Alpha | Conventional |
| --- | ---: | ---: | ---: |
| Upper median | 23.154 ms | 23.233 ms | 23.238 ms |
| Sum over 64 representations | 1.547578 s | 1.512454 s | 1.510767 s |
| Median preparation component | 0.552 ms | 0.232 ms | 0.275 ms |

The sign differs between the median and aggregate comparison; ordinary Python
IPC is included. The differences are extremely small, with no demonstrated
monetary billing change. No reliable economic or algorithmic speed ranking
follows. Equal accepted outputs supply zero measured incremental production
quantity. Quality, waiting, attention and demand value were not priced from
actual customers.

The ordinary interpreter was assembled for the study. Its source is
`evaluation/oracle.py`, using standard parsing and equally available caching.
It is a useful strong capability comparator, but it is not the measured
pre-investment workflow. Its assembly elapsed time and complete cost are unknown.
The study later discloses and charges a hypothetical common setup envelope, which
does not transform it into a historical baseline.

The oracle also defines expected normalization while supplying the ordinary arm.
The independent JS candidate implementations and separate pack/CSV checks remain
useful, but the ordinary arm and expectation generator share one interpretation.
This is a bounded same-team computational cross-check, not independently blinded
ground-truth custody.

Downstream limits matter. The normalizer's 1 MB/128-row limits exceed the guide's
200 kB CSV/4,096-character-cell limits and the Workbench artifact limits. Three
post-primary diagnostics correctly refuse parser-valid inputs at those later
boundaries. No claimed intake success should bypass whole-delivery acceptance.

## Financing reconciliation

The experiment reuses `alpha-automated-costs/v1` and `alpha-shadow-ledger/v1`.
Every hypothetical investment binds to the same tested candidate hash. The cash
projection tracks seed, setup, costs, delayed receipts, reserves, maintenance and
asset use separately. Canonical observed collections and observed surplus remain
null. There are no financial transactions.

All 3,360 primary scenarios use zero assumed additional provider-attention saving
and make no investment. The primary timing result does not provide positive
recurring savings under the chosen median comparison.

The favorable secondary example uses an assumed $100 seed, $20 common setup,
$20 complete incremental construction envelope, $5 accepted-output price,
two-job collection delay and **60 unmeasured seconds of provider attention saved
per retained use**. The cents-rounded ordinary cost is 88 cents per attempt;
retained cost is 27 cents. The resulting assumed 61-cent saving drives every
dollar of the positive outcome. It funds the asset after job 13, permits 39
retained uses and first recovers cost strictly at job 46. Terminal benefit is
39 × $0.61 − $20 = $3.79. With zero added attention benefit or a $10 maintenance
exposure, admission fails over that horizon.

The $20 investment envelope explicitly includes discovery, failed construction,
integration, verification and unknown authoring/inference. It is an assumed
aggregate amount, not a defensible measured upper bound. The alternative $5,
$50, $100, $250 and $500 points are sensitivities, not evidence. Complete cost
remains unknown for every method.

At a common price and equal accepted quantity, price cancels from incremental
value: `Delta V = P * Delta Q - Delta C = -Delta C`. A higher assumed price can
make cash available sooner; it cannot create the missing asset benefit.

## Already screened follow-up opportunities

The prior post-primary screen spent 116.522 recorded seconds within its separate
three-minute allowance and constructed no second candidate.

1. Generic pack verification: the Workbench already verifies pack identity,
   artifacts and policy; a retained Python audit checks full inventory/CSV
   semantics. The original audit took 0.379494 seconds for 192 packs, with
   0.363654 seconds on replay. At a hypothetical $10/hour, eliminating the
   entire original audit is only $0.001054 per 192-pack batch; full elimination
   would also remove necessary checking. No manual review burden was measured.
2. Reusable builder fixtures: both builders already retained standard test
   runners, four development inventories and regression checks. One Unicode
   development defect did not establish recurring repair incidence, isolated
   repair effort, unseen construction transfer or cost reduction.

These ordinary tools are owned assets, not candidates to remove from a control.

## Earlier-edition findings inspected alongside the complete prior edition

The current published source PDFs were extracted and their relevant methods,
results, economics, limitations and claim boundaries read. They are preserved as
prior evidence, not reproduced experiments in this audit.

| Edition | Decisive finding | Consequence for new selection |
| --- | --- | --- |
| The Autonomous Work Economy | 16 accepted primary artifacts, eight intended refusals; new quote transfer 8/8 for successor and MILP, 2/8 for initial capsule. Local batch 626.53 ms; zero runtime provider calls. Average solver-only saving 1.476 ms, both methods fit the same session charge. | A useful scope extension can exist without distinct algorithm or monetary savings. Do not turn capsule emission time into construction cost or reuse old transfer data as new confirmation. |
| Build the Next Advantage | Five methods accepted 96 nominal missions. Active specialist, learned recipe and LLM-assisted constructor used 29 production examples; ordinary reuse used 61. Learned recipe additionally used 31 development examples. | Preserve active selection as incumbent. Example count is a measured resource; each example's real preparation effort is unknown. The learned recipe remains HOLD. |
| The Productive Capital Engine | 72 joint executions across six projects; both cache methods reused 114/132 source cards. Fresh-change CPU: child 4.069055 s, conventional cache 4.032727 s. Later boundary correction preserved original failures. | Parent calls, source reuse and growing archives are not gains over ordinary caching. One joint workflow cost cannot be counted as three sales. |
| The Economic Engine | All 144 primary financial paths buy no capability/capacity. Fourfold-demand success prescribes candidate improvement; a stipulated failure keeps its cost. | Financing arithmetic does not construct or validate the financed improvement. Requested new experiment must bind cash to a measured exact asset. |

These papers' modeled service costs and hypothetical human labor durations must
not be imported into a different current offering as observations.

## Requirements before a new construction decision

1. Freeze the actual operating source, full invocation and existing reusable
   tools as Control A. If historical production operation is unavailable, call
   it a source-frozen local operating baseline, not measured historical business.
2. Measure a full useful request from accepted input through all outputs and
   restore/verification. Keep unchanged limits, recovery and refusal behavior.
3. Establish an economically material recurring burden or a newly enabled
   outcome with explicit value uncertainty. A zero-model-call deterministic
   workflow has no repeated inference bill to remove.
4. Estimate credible recurrence from real tasks or report the reuse threshold
   without presenting it as demand. Four repos do not imply a weekly paid job.
5. Instrument discovery, unsuccessful attempts, both builders, integration,
   checking, maintenance, compute and intervention before construction starts.
   Do not substitute elapsed agent time for human labor or a model invoice.
6. Where construction cost lacks a defensible upper bound, publish the maximum
   unknown cost that measured savings could support. Do not arbitrarily choose
   a small number and call it a conservative complete-cost bound.
7. Admit a primary investment only after prospective value is credible. A
   no-build decision with exact evidence requirements is a valid screen outcome;
   it is not itself a completed economic Flywheel.
8. Preserve distinct decisions: technical acceptance, incremental economic value,
   cash affordability, actual collections, builder advantage and acceleration.

## Exact missing evidence

No current record provides metered full authoring/model charges, a material
recurring service expense outside tiny local deterministic runs, measured
provider/customer attention reduction, demonstrated purchase demand, equivalent
non-AI human task duration, or realized collections. A positive result requires
new evidence for at least one incremental benefit and enough true reuse to
cover all attributed costs. Better charts and higher assumed prices cannot fill
those quantities.

## Reusable components and exact identities

- Canonical costs: `vendor/shared/automated-costs.mjs`, SHA-256
  `0dfca3ae4e7ef1d17bc78521f91917ef068280cf832d3565c354de2085c52506`.
- Canonical ledger: `vendor/shared/shadow-ledger.mjs`, SHA-256
  `cdc7c5a73593050a9af79b54589462e27f61b868e88ca6985d5cb639f3066d21`.
- Alpha asset: `ad0b0adc9baa78de5b76cb7cf583fa8179fb977469ab5da47b75455953bf9fda`.
- Conventional asset: `ce44d675dc840b3bfd68e2bdb13d1aa5a5be230ff6a0318d430835a16826cb72`.
- Ordinary interpreter: `bf1721a3e75d63691b3b538ae334532cd9a8e1d13053390ab24d815ab17dbe22`.
- Original protocol: `f78f4a02556d48f79ceb116fe747c0d4515beb22c3df5b98a200b8ee60ce2df5`.

The existing adapter, semantic audit, exact-input cache and canonical cost/ledger
modules can be reused where their contracts apply. Their ownership and genuine
construction costs remain visible. No new competing runtime or calculator is
needed to carry these measurements into the current study.

## Concrete gap before substantially richer useful work can be measured

Read-only source inspection at Alpha main
`3b040e68adae8196f7bda4c65f92af92ee6f7335` identifies the following exact seams.
These describe missing capabilities and evidence; they are not instructions to
enable a new profile, retry held work or bypass an existing restriction.

| Existing path | What is implemented | Gap for useful public-repository repair |
| --- | --- | --- |
| `docs/agent/FLYWHEEL_CAPABILITIES.json` | Explicitly marks public-repository maintenance not implemented. | Calls for a reviewed snapshot/patch adapter, usable isolated configured executor, actual baseline/patch/tests/recovery and reuse evidence. |
| `alpha_factory_v1/core/runtime/models.py`, `Coding` | A bounded candidate string and up to 100 `solve(*args)` cases, with host-owned expected outputs. | No pinned repository snapshot, dependency/install boundary, patch artifact, repository test contract or complete deliverable schema. |
| `alpha_factory_v1/core/runtime/engine.py`, `Engine.run` coding branch | Requires explicit code-execution configuration; optionally calls `generate_code`, then `work.coding`; records stages, verification and review. | Existing orchestration is reusable, but the solve-function route is not a repository-maintenance adapter. |
| `alpha_factory_v1/core/runtime/work.py`, `coding` | Executes the finite coding evaluator and returns its bounded result. | Cannot be relabeled as a pinned repository repair workflow without actual implementation and admission. |
| `alpha_factory_v1/core/eval/fitness.py`, `evaluate_agent` | Sends only source and argument inputs to isolation; keeps expected outputs outside; scores returned JSON. | Needs a reviewed repository fixture/patch/test protocol with independent oracle and complete artifacts, preserving isolation. |
| `alpha_factory_v1/core/utils/secure_run.py` | Requires a usable Docker daemon for untrusted code; stages explicit regular files, caps resources and output, disables container network; host execution is forbidden. | The recorded delivery host lacks Docker. No host fallback or broader filesystem sharing is legitimate. Available backend/profile must be established through existing owners. |
| `alpha_factory_v1/core/runtime/provider.py` | Existing provider adapter retains configured/reported model, request/response hashes and provider-reported prompt/completion/total token fields. | Token counts are not a bill. Real authorized calls, failed-call accounting, tariff/invoice mapping, local inference resource costs and complete authoring usage are needed. |
| `alpha_factory_v1/core/runtime/successor/computer.py` | Records an UNKNOWN-cost attempt before network I/O, retains validated provider usage when returned and does not automatically retry uncertain failures. | This is a useful metering seam, not authority to run the restricted computer/operator profile. Preserve UNKNOWN on timeout and invoice uncertainty. |

An approved repository-repair route could expose genuinely costly semantic
analysis, test execution or repeated corrections. That is a hypothesis requiring
measurement, not a promise that repair is profitable. The first qualifying study
would need a small series of real permitted repository requests, the current
ordinary successful workflow, complete metered requests/retries/verifier and
packaging, correct accepted patches, and a credible recurrence basis. Only then
could a retained repair, analysis or verification asset pass the value gate.

The existing scopes already have source/recovery owners. Their open correctness
work must not be claimed as a new study asset or counted again as a discovery.
Security approval, exact operator/profile adoption and the original Harness/Fleet
held actions remain separate source-specific decisions with their original
owners. A local read, test or derived artifact supplies none of that authority.
