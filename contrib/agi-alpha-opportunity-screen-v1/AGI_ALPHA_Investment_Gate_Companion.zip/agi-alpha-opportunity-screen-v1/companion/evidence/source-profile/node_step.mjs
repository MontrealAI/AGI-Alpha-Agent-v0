import {readFile} from 'node:fs/promises';
import {makePlan,runPlan} from '../../repos/alpha-integration/contrib/productive-capability-ledger/automation-v1/run-mission.mjs';
let raw=''; for await (const chunk of process.stdin) raw+=chunk;
const request=JSON.parse(raw);
if(request.operation==='plan') process.stdout.write(JSON.stringify(await makePlan(request.options)));
else if(request.operation==='run') process.stdout.write(JSON.stringify(await runPlan(request.plan,{approvalDigest:request.approvalDigest,outputRoot:request.outputRoot})));
else throw Error('Unrecognized measurement action');
