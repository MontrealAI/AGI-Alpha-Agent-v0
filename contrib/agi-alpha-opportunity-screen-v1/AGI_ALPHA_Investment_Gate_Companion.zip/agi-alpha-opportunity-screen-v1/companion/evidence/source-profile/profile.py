import datetime,hashlib,importlib.util,io,json,os,pathlib,re,resource,signal,subprocess,sys,time,zipfile
WORK=pathlib.Path(__file__).resolve().parent
ROOT=WORK.parents[1]/'repos/alpha-integration'
BASE=WORK
if len(sys.argv)>1:
 assert len(sys.argv)==2 and re.fullmatch(r'[a-z0-9-]+',sys.argv[1])
 BASE=WORK/sys.argv[1];BASE.mkdir(exist_ok=False)
SHA='496fa3c00dc7498173a896404ec756dfdeb94033'
NODE='/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node'
VERIFY=ROOT/'contrib/productive-capability-ledger/automation-v1/verify-run.py'
START=time.monotonic(); CPU=0.; EVENTS=[]; RESULTS=[]
SCOPES=[('guide','docs/try/sources.json'),('flagship','docs/successor/alpha/sources.json'),('capabilities','docs/successor/capabilities/sources.json'),('mission','docs/successor/mission/sources.json'),('prior-versions','contrib/productive-capability-ledger/completion-v3/previous-published-source.json')]
def dump(name,value):
 (BASE/name).write_text(json.dumps(value,indent=2)+'\n')
def measure(name,argv,request=None,traced=False):
 global CPU
 if time.monotonic()-START>840 or CPU>540: raise RuntimeError('Discovery allowance exhausted')
 stdin=BASE/(name+'.stdin.json'); stdout=BASE/(name+'.stdout.json'); stderr=BASE/(name+'.stderr.txt')
 stdin.write_text(json.dumps(request) if request is not None else '')
 command=list(argv)
 if traced: command=['strace','-f','-e','trace=execve','-o',str(BASE/(name+'.execve.log')),*command]
 env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',GIT_TERMINAL_PROMPT='0',GIT_OPTIONAL_LOCKS='0')
 with stdin.open('rb') as inf,stdout.open('wb') as outf,stderr.open('wb') as errf:
  start=time.monotonic_ns();pid=os.fork()
  if pid==0:
   try:
    os.setsid();os.chdir(ROOT);os.dup2(inf.fileno(),0);os.dup2(outf.fileno(),1);os.dup2(errf.fileno(),2)
    resource.setrlimit(resource.RLIMIT_CPU,(55,60));os.execvpe(command[0],command,env)
   except BaseException as e: print(str(e),file=sys.stderr);os._exit(127)
  deadline=time.monotonic()+65
  while True:
   got,status,usage=os.wait4(pid,os.WNOHANG)
   if got: break
   if time.monotonic()>deadline: os.killpg(pid,signal.SIGKILL);got,status,usage=os.wait4(pid,0);break
   time.sleep(.005)
 elapsed=(time.monotonic_ns()-start)/1e9;code=os.waitstatus_to_exitcode(status);CPU+=usage.ru_utime+usage.ru_stime
 event={'id':name,'argv':command,'cwd':str(ROOT),'sourceRef':SHA,'inputFile':str(stdin),'stdoutFile':str(stdout),'stderrFile':str(stderr),'exitCode':code,'wallSeconds':elapsed,'userAndWaitedDescendantSeconds':usage.ru_utime,'systemAndWaitedDescendantSeconds':usage.ru_stime,'cpuAndWaitedDescendantSeconds':usage.ru_utime+usage.ru_stime,'maximumReportedRSSKiB':usage.ru_maxrss,'straceEnabled':traced,'outputSha256':hashlib.sha256(stdout.read_bytes()).hexdigest(),'modelCalls':0,'completeMonetaryCost':None}
 if traced:
  logs=(BASE/(name+'.execve.log')).read_text();success=[line for line in logs.splitlines() if 'execve(' in line and re.search(r'= 0$',line)]
  event['successfulExecCalls']=len(success);event['successfulGitExecCalls']=sum('"git",' in line or '"/usr/local/bin/git",' in line for line in success)
 EVENTS.append(event);dump('process-observations.json',EVENTS)
 if code: return None
 try: return json.loads(stdout.read_text())
 except json.JSONDecodeError:return None
def package(run,accepted,name):
 start=time.monotonic_ns();cpu=time.process_time_ns();complete_raw=(run/'COMPLETE.json').read_bytes();complete=json.loads(complete_raw)
 assert hashlib.sha256(complete_raw).hexdigest()==accepted['completeSha256']
 files=['plan.json','declared-inventory.csv','observed-inventory.csv','differences.csv','action-plan.csv','workspace.json','report.md','final-acceptance.json']
 target=BASE/(name+'.zip');total=0
 with zipfile.ZipFile(target,'x',zipfile.ZIP_DEFLATED) as archive:
  for f in files:
   data=(run/f).read_bytes();assert hashlib.sha256(data).hexdigest()==complete['artifacts'][f];total+=len(data);assert len(data)<=512000 and total<=512000;archive.writestr(f,data)
  archive.writestr('independent-acceptance.json',json.dumps(accepted,sort_keys=True,separators=(',',':'),ensure_ascii=False))
 assert (run/'COMPLETE.json').read_bytes()==complete_raw
 with zipfile.ZipFile(target) as archive: assert archive.testzip() is None
 return {'file':str(target),'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'uncompressedCustomerBytes':total,'members':9,'wallSeconds':(time.monotonic_ns()-start)/1e9,'cpuSeconds':(time.process_time_ns()-cpu)/1e9,'basis':'Research packaging of the same eight canonical customer payloads plus existing independent acceptance, using the existing 512000-byte package bound; not authenticated transport execution.'}
def main():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==SHA
 assert not subprocess.check_output(['git','status','--short'],cwd=ROOT,text=True).strip()
 scopes=[]
 for label,path in SCOPES:
  raw=subprocess.check_output(['git','--no-lazy-fetch','--no-replace-objects','show',SHA+':'+path],cwd=ROOT);manifest=json.loads(raw);sources=manifest['sources'];assert 1<=len(sources)<=128
  scopes.append({'label':label,'path':path,'manifestSha256':hashlib.sha256(raw).hexdigest(),'sourceCount':len(sources),'sourceBytes':sum((ROOT/p).stat().st_size for p in sources),'sourcePaths':list(sources)})
 dump('protocol.json',{'schema':'agi-alpha-source-opportunity-profile/v1','sourceRef':SHA,'startedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'wallLimitSeconds':900,'cpuLimitSeconds':600,'scope':'Bounded foreground native source-assurance API; no operator/HTTP/Fleet/Harness execution; no network or service model calls. No asset construction.','scopes':scopes,'schedule':[{'label':s['label'],'replication':rep,'traced':False} for rep in [1,2] for s in scopes],'candidateSelected':False,'unknownCosts':['research model usage','human attention','input acquisition cost','fixed engineering','hardware price','maintenance','commercial acceptance','collections'],'counting':'Five distinct immutable source scopes; second pass repeats those same scopes; reconnects do not add unique jobs.','discoveryNotConfirmation':True,'timingScope':'Process launch, imports, work, waited Git descendants and stdout collection; POSIX wait4 CPU and maximum RSS. Profiler sleep/polling belongs only to wall overhead.','exportScope':'Packaging canonical customer payloads with unchanged candidate output size bound; additional research ZIP creation identified separately.','observedInputPreparation':'Scope inventory/selection is research preparation, not invented customer labor.','instrumentationFailure':'strace refused PTRACE_TRACEME/SETOPTIONS with EPERM. No retry or alternate tracer. Tool counts are retained runtime receipts plus separately source-derived exact calls, not syscall observations.'})
 schedule=[(s,rep,False) for rep in [1,2] for s in scopes]
 for scope,rep,traced in schedule:
  name=f"{scope['label']}-{rep}";runid='profile-'+name;events_before=len(EVENTS)
  now=datetime.datetime.now(datetime.timezone.utc);created=now.isoformat(timespec='milliseconds').replace('+00:00','Z');expires=(now+datetime.timedelta(minutes=12)).isoformat(timespec='milliseconds').replace('+00:00','Z')
  plan=measure(name+'-plan',[NODE,str(WORK/'node_step.mjs')],{'operation':'plan','options':{'manifestPath':scope['path'],'sourceRef':SHA,'runId':runid,'maxSeconds':20,'maxAttempts':2,'maxTotalSeconds':40,'createdAt':created,'expiresAt':expires}},traced)
  row={'id':name,'scope':scope['label'],'sourceCount':scope['sourceCount'],'sourceBytes':scope['sourceBytes'],'replication':rep,'traced':traced,'newUniqueScope':rep==1,'planPassed':bool(plan),'deliveryPassed':False,'independentVerificationPassed':False,'reconnectPassed':False,'postReconnectVerificationPassed':False}
  if plan:
   req={'operation':'run','plan':plan['plan'],'approvalDigest':plan['approvalDigest'],'outputRoot':str(BASE/'runs')};run=BASE/'runs'/runid
   result=measure(name+'-delivery',[NODE,str(WORK/'node_step.mjs')],req,traced);row['deliveryPassed']=bool(result and result.get('accepted'))
   if row['deliveryPassed']:
    acceptance=measure(name+'-verify',[sys.executable,'-I',str(VERIFY),str(run)],None,traced);row['independentVerificationPassed']=bool(acceptance and acceptance.get('accepted'))
    if row['independentVerificationPassed']:
     row['checks']=acceptance['checks'];row['changedPaths']=acceptance['changedPaths'];row['export']=package(run,acceptance,name)
    reconnect=measure(name+'-reconnect',[NODE,str(WORK/'node_step.mjs')],req,traced);row['reconnectPassed']=bool(reconnect and reconnect.get('accepted') and reconnect.get('reconnected'))
    after=measure(name+'-verify-reconnect',[sys.executable,'-I',str(VERIFY),str(run)],None,traced);row['postReconnectVerificationPassed']=bool(after and after.get('accepted'))
  row['processEvents']=[e['id'] for e in EVENTS[events_before:]];row['wallSeconds']=sum(e['wallSeconds'] for e in EVENTS[events_before:])+row.get('export',{}).get('wallSeconds',0);row['cpuSeconds']=sum(e['cpuAndWaitedDescendantSeconds'] for e in EVENTS[events_before:])+row.get('export',{}).get('cpuSeconds',0);row['monetaryCost']=None
  if row['postReconnectVerificationPassed']:
   n=scope['sourceCount'];row['gitCallsSourceDerived']={'plan':10,'delivery':14+4*n,'verify':15+3*n,'reconnect':12+2*n,'verifyReconnect':15+3*n,'total':66+12*n,'basis':'Derived from unchanged committed()/makePlan()/runPlan()/git_blob() code and successful exercised path; not observed syscall telemetry.'}
   row['runtimeReceiptGitCounts']={'planning':plan['planningFacts']['toolInvocations']['value'],'stages':sum(s['toolInvocations']['value'] for s in result['stages']),'finalRevalidation':result['finalRevalidation']['toolInvocations']['value'],'note':'Stage receipts exclude some validation, independent Python checker and reconnect calls; do not treat their sum as full workflow.'}
  RESULTS.append(row);dump('results.json',RESULTS);print(json.dumps(row),flush=True)
  if not plan and 'EPERM' in (BASE/(name+'-plan.stderr.txt')).read_text(): break
 status=subprocess.check_output(['git','status','--short'],cwd=ROOT,text=True);assert status==''
 dump('summary.json',{'sourceRef':SHA,'uniqueScopes':len(scopes),'scheduledOperatingReplications':10,'attemptedOperatingReplications':len(RESULTS),'tracedInstrumentReplications':0,'straceInstrumentation':'REFUSED_EPERM_NO_RETRY','sourceUnmodified':True,'sourceGitStatus':status,'discoveryWallSeconds':time.monotonic()-START,'measuredCommandCPUSeconds':CPU,'allPassed':len(RESULTS)==10 and all(all(row[k] for k in ['planPassed','deliveryPassed','independentVerificationPassed','reconnectPassed','postReconnectVerificationPassed']) for row in RESULTS),'modelCalls':0,'runtimeModifications':0,'economicPromotion':'NOT_EVALUATED_DISCOVERY_ONLY','unknownMonetaryCostsNotZero':True})
if __name__=='__main__': main()
