#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Rebuild the descriptive figure from the preserved discovery observations."""

import json
from pathlib import Path
from statistics import median

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

HERE = Path(__file__).resolve().parent


def observations() -> dict:
    """Read exact observations when the companion is present; otherwise use the saved table."""
    evidence = HERE.parent / "companion" / "evidence"
    if not evidence.is_dir():
        return json.loads((HERE / "figure-data.json").read_text())
    source = json.loads(
        (evidence / "source-profile/approved-process-run/results.json").read_text()
    )
    catalogue = json.loads((evidence / "catalog-profile/summary.json").read_text())[
        "runs"
    ]
    data = {"source": [], "catalogue": []}
    for scope in ("prior-versions", "guide", "flagship", "capabilities", "mission"):
        rows = [row for row in source if row["scope"] == scope]
        cpu = [row["cpuSeconds"] for row in rows]
        wall = [row["wallSeconds"] for row in rows]
        data["source"].append(
            {
                "scope": scope,
                "cpuMedian": median(cpu),
                "wallMedian": median(wall),
                "cpuObservations": cpu,
                "wallObservations": wall,
                "paths": rows[0]["sourceCount"],
            }
        )
    for scope in ("runtime", "examples", "tests", "package"):
        rows = [row for row in catalogue if row["task"] == scope]
        cpu = [row["cpuMs"] / 1000 for row in rows]
        wall = [row["wallMs"] / 1000 for row in rows]
        data["catalogue"].append(
            {
                "scope": scope,
                "cpuMedian": median(cpu),
                "wallMedian": median(wall),
                "cpuObservations": cpu,
                "wallObservations": wall,
                "rows": rows[0]["inputs"]["rows"],
            }
        )
    (HERE / "figure-data.json").write_text(json.dumps(data, indent=2) + "\n")
    return data


def main() -> None:
    """Render a static vector PDF and PNG; no economic simulation is performed."""
    data = observations()
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 9,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )
    fig = plt.figure(figsize=(9.6, 4.5), facecolor="white")
    fig.text(
        0.02,
        0.968,
        "Useful work delivered. No productive investment admitted.",
        fontsize=12,
        fontweight="bold",
        color="#211A33",
        va="top",
    )
    cards = [
        ("PRODUCTIVE ASSET", "None selected"),
        ("COMPLETE STUDY COST", "Unknown"),
        ("FRESH INCREMENTAL BENEFIT", "Not tested"),
        ("REPAYMENT", "Not demonstrated"),
    ]
    for index, (label, value) in enumerate(cards):
        x = 0.02 + index * 0.245
        fig.patches.append(
            FancyBboxPatch(
                (x, 0.807),
                0.232,
                0.103,
                boxstyle="round,pad=0.004,rounding_size=0.009",
                transform=fig.transFigure,
                linewidth=0,
                facecolor="#F2ECFB",
            )
        )
        fig.text(x + 0.01, 0.877, label, fontsize=7, color="#625D6D", va="center")
        fig.text(
            x + 0.01,
            0.838,
            value,
            fontsize=10,
            fontweight="bold",
            color="#211A33",
            va="center",
        )
    ax = fig.add_axes((0.19, 0.205, 0.76, 0.55))
    rows = data["source"] + data["catalogue"]
    labels = [f"Source · {row['paths']} paths" for row in data["source"]]
    labels += [f"Catalogue · {row['rows']} rows" for row in data["catalogue"]]
    colors = ["#6537BA"] * 5 + ["#236D65"] * 3 + ["#9A641D"]
    for index, row in enumerate(rows):
        value = row["cpuMedian"]
        observed = row["cpuObservations"]
        ax.barh(index, value, color=colors[index], height=0.63, zorder=2)
        ax.errorbar(
            value,
            index,
            xerr=[[value - min(observed)], [max(observed) - value]],
            color="#211A33",
            capsize=2,
            linewidth=0.7,
            zorder=3,
        )
        ax.text(
            max(observed) + 0.17,
            index,
            f"{value:.2f}",
            va="center",
            fontsize=8,
            color="#211A33",
        )
    ax.set_yticks(range(len(rows)), labels, fontsize=8)
    ax.invert_yaxis()
    ax.set_xlim(0, 19.6)
    ax.set_xlabel(
        "Existing-path CPU seconds · median of two observed evaluations", fontsize=8
    )
    ax.grid(axis="x", color="#E6E2EC", linewidth=0.5, zorder=0)
    ax.tick_params(axis="both", length=0)
    for spine in ("top", "right", "left"):
        ax.spines[spine].set_visible(False)
    ax.spines["bottom"].set_color("#C8C2D1")
    fig.text(
        0.02,
        0.086,
        "Purple: complete foreground source checks. Teal: complete native catalogue and history path.",
        fontsize=7.5,
        color="#625D6D",
    )
    fig.text(
        0.02,
        0.055,
        "Amber: local catalogue delivered; native output refused. Its shorter path is not a speed advantage.",
        fontsize=7.5,
        color="#625D6D",
    )
    fig.text(
        0.02,
        0.024,
        "Whiskers span two observations, not a confidence interval. These are resources, not dollars or measured savings.",
        fontsize=7.5,
        color="#625D6D",
    )
    destination = HERE / "figures"
    destination.mkdir(exist_ok=True)
    fig.savefig(
        destination / "observed-burden.pdf",
        metadata={"CreationDate": None, "ModDate": None},
    )
    fig.savefig(destination / "observed-burden.png", dpi=200)
    plt.close(fig)


if __name__ == "__main__":
    main()
