# Build the paper

The PDF is the complete English discovery record. It reports **HOLD** and does not claim a constructed productive asset, fresh confirmation, economic repayment, production execution or website publication.

## Typeset from the supplied sources

The vector figure is already included, so rebuilding the manuscript requires no Python packages or network access. In this directory:

```sh
pdflatex -interaction=nonstopmode -halt-on-error AGI_ALPHA_Investment_Gate.tex
pdflatex -interaction=nonstopmode -halt-on-error AGI_ALPHA_Investment_Gate.tex
```

The observed environment used pdfTeX 1.40.25 (TeX Live 2023/Debian). The preamble lists its ordinary LaTeX packages and fonts. No bibliography service, external image, shell escape or online resource is needed.

## Rebuild the figure

Python 3.12.14 and Matplotlib 3.10.8 were used to regenerate the static figure:

```sh
python3 build_figure.py
```

With the complete companion present, this reads the original two observations per scope and writes `figure-data.json` and the PDF/PNG figure. With only this LaTeX source package present, it uses the supplied exact observation table. The chart depicts CPU use of existing workflows, never incremental monetary savings. Whiskers span the two observations; they are not confidence intervals.

## Verification boundary

The final manuscript was compiled, checked for overfull boxes and visually inspected as rendered pages. The evidence cross-check and its findings are preserved under `../review/`. The previous edition and its adverse findings remain separate and unchanged. Bibliographic URLs are citations, not build dependencies.
