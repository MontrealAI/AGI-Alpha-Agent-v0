# Build an Advantage That Repays Its Cost

## The investment gate: measured discovery and an unselected investment

**Result: HOLD.** This delivery records useful work through the existing AGI ALPHA system and the opportunity screen that followed it. No candidate justified a complete-cost investment claim. No productive asset was selected, no untouched confirmation cohort was frozen, and no incremental repayment or acceleration was demonstrated.

The study contains **nine scoped internal requests and eighteen operating evaluations**, with two timing repetitions per scope. Underlying public material overlaps; rows, assertions, artifacts and timing repetitions are not additional unique customer jobs.

| Scoped requests | Recorded outcome |
| --- | --- |
| Five source-assurance scopes | Complete **foreground local** source verification, customer report, research ZIP export, reconnect and revalidation. These are not authenticated native-transport executions. |
| Three catalogue scopes | Local catalogue delivery, native delivery and history reopening completed. |
| One catalogue scope, 1,216 rows per input | Nine local catalogue artifacts delivered; both native attempts preserved the existing `ARTIFACT_POLICY` refusal. |

The large `joined.csv` has **253,267 UTF-8 bytes** and **253,263 JavaScript UTF-16 code units**, exceeding the native **200,000-code-unit** cap. `analysis/native-limit-adjudication.json` corrects the original prose's byte/character label. No limit was changed.

Whole-study monetary cost remains **unknown**, including authoring, research inference, verification, integration, reporting and allocated overhead. Physical CPU measurements are not a complete bill; elapsed time is not measured human attention. Fixed workflow service-model calls were zero, but that does not make research costs zero. Study sales collections and financial transactions were zero. No fictional price, customer-time saving or financing cycle supplies the missing benefit.

## Read and use the delivery

- Read `paper/AGI_ALPHA_Investment_Gate.pdf` for the complete paper, central figure, methods and limitations.
- Open `demo/index.html` locally for the standalone English/French recorded-evidence interface. It embeds all nine scopes, the actual three-path source finding, the original nine-file ZIP and downloadable data. No server or network is required. It is a replay of evidence, not a newly executed mission or a browser/production qualification.
- Inspect `accounting/` and `analysis/` for costs, outcomes, the canonical ledger, financing limits, opportunity decisions and human-work thresholds.

## Reproduce

Run these commands from this delivery directory. The recorded offline companion used **Python 3.12, Node 24.22.1 and Git 2.51.1**. It uses standard libraries and included source dependencies; no package download, paid model, credential or network service is needed. Choose reproduction output paths that do not already exist.

### Companion

Audit saved evidence, check source identities and invoke the unchanged source-assurance verifier:

```sh
python3 companion/reproduce.py --audit-only --output ./new-audit
```

Additionally replay the existing catalogue and native recovery paths on the archived discovery inputs:

```sh
python3 companion/reproduce.py --output ./new-reproduction
```

These are exposed discovery inputs, not fresh confirmation missions. The companion retains the historical source-profile timing records; it does not claim to recreate historical timings or a full original source checkout. See `companion/README.md` for the partial local Git object database and replay boundaries.

### Canonical accounting

Regenerate the accounting and analysis outputs from the preserved evidence, using the byte-identical existing Alpha monetary modules:

```sh
node accounting/build_accounting.mjs
```

The default evidence directory is `companion/evidence`. An optional argument selects another directory containing the same `source-profile` and `catalog-profile` records. Unknown costs, reserves, obligations and investable surplus remain unknown. This command is evidence aggregation through the existing calculator, not a financial transaction.

### Bilingual demo

Rebuild the embedded recorded-evidence page and run its code-level checks:

```sh
python3 demo/build_demo.py --root .
python3 demo/verify_demo.py --root .
```

The checks reconcile source data, verify the original archive and downloads, exercise EN/FR and scope controls in a minimal DOM stub, check JavaScript and content-security-policy hashes, and require an identical rebuild. They do not claim visual browser validation.

### Paper

The supplied PDF is ready to read. To rebuild it, use a local LaTeX installation with the packages declared in the source, including `mathpazo`, `microtype`, `tikz` and `tcolorbox`. The recorded figure is included.

```sh
cd paper
pdflatex -interaction=nonstopmode -halt-on-error AGI_ALPHA_Investment_Gate.tex
pdflatex -interaction=nonstopmode -halt-on-error AGI_ALPHA_Investment_Gate.tex
cd ..
```

## Directory map

| Directory | Contents |
| --- | --- |
| `companion/` | Preserved discovery evidence, failed attempts, previous-study audit, source/dependency manifests, byte-identical source files and offline reproduction. |
| `accounting/` | Complete cost-coverage inventory, physical resource records, nine-request outcome ledger, canonical monetary evaluations and explicit financing unknowns. |
| `analysis/` | Discovery protocol, opportunity screen, native-limit correction, bounded observed CPU upside and sourced human-work thresholds. |
| `demo/` | Portable EN/FR HTML interface, evidence-based builder, code-level verifier and recorded verification. |
| `paper/` | LaTeX source, PDF, figures, figure data and typesetting records. |
| `review/` | Recorded research review and remaining limitations. |

## Ownership and execution boundaries

This is an additive research delivery. Existing repository maintainers and the publication owner retain integration and publication responsibility, coordinated through [AGI-Alpha-Agent-v0 issue #4850](https://github.com/MontrealAI/AGI-Alpha-Agent-v0/issues/4850). This package does not claim a merge to main or website publication.

Earlier papers, releases, companion records and adverse results—including *The Advantage That Funds the Next*—remain preserved. This study neither replaces them nor requires their publication to wait. The prior-study audit carries forward their unresolved economic findings.

Original Harness and Fleet holds, security gates and execution-profile restrictions remain intact. Foreground local, isolated execution, approved-operator and production scopes remain distinct. No new credential, persistent access, paid commitment, deployed-contract change or financial transaction is introduced. Existing `$AGIALPHA` and USDC references do not create new financial rights or appreciation claims.
