#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Seal the research delivery without changing original measurements or runtime sources."""

import hashlib
import json
import shutil
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DESTINATION = ROOT.parent
STEM = "AGI_ALPHA_Investment_Gate"
PAPER_FILES = {
    "AGI_ALPHA_Investment_Gate.tex",
    "AGI_ALPHA_Investment_Gate.pdf",
    "README.md",
    "build_figure.py",
    "figure-data.json",
    "figures/observed-burden.pdf",
    "figures/observed-burden.png",
}


def digest(data: bytes) -> str:
    """Return the SHA-256 identity of delivered bytes."""
    return hashlib.sha256(data).hexdigest()


def payloads() -> list[Path]:
    """Select deliverables and raw evidence while excluding temporary authoring products."""
    selected = []
    for path in sorted(ROOT.rglob("*")):
        if not path.is_file():
            continue
        relative = path.relative_to(ROOT)
        if "__pycache__" in relative.parts or path.suffix == ".pyc":
            continue
        if relative.as_posix() == "PAYLOAD_MANIFEST.json":
            continue
        if (
            relative.parts[0] == "paper"
            and Path(*relative.parts[1:]).as_posix() not in PAPER_FILES
        ):
            continue
        selected.append(path)
    return selected


def archive(destination: Path, members: list[tuple[str, bytes]]) -> None:
    """Write an ordered archive and verify every byte after CRC checking."""
    with zipfile.ZipFile(
        destination, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9
    ) as package:
        for name, data in members:
            info = zipfile.ZipInfo(name, date_time=(2026, 10, 26, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            package.writestr(
                info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9
            )
    with zipfile.ZipFile(destination) as package:
        assert package.testzip() is None
        assert len(package.namelist()) == len(members)
        assert len(set(package.namelist())) == len(members)
        for name, data in members:
            assert package.read(name) == data, name


def main() -> None:
    """Build the complete companion and compact standalone reader artifacts."""
    selected = payloads()
    manifest = {
        "schema": "agi-alpha-research-delivery-manifest/v1",
        "scope": "Complete discovery/HOLD delivery; original companion manifest is separately preserved.",
        "manifestSelfExcluded": True,
        "temporaryTypesettingProductsExcluded": True,
        "files": [
            {
                "path": path.relative_to(ROOT).as_posix(),
                "bytes": path.stat().st_size,
                "sha256": digest(path.read_bytes()),
            }
            for path in selected
        ],
    }
    manifest_path = ROOT / "PAYLOAD_MANIFEST.json"
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
    selected.append(manifest_path)
    archive(
        DESTINATION / f"{STEM}_Companion.zip",
        [
            (f"{ROOT.name}/{path.relative_to(ROOT).as_posix()}", path.read_bytes())
            for path in selected
        ],
    )
    latex_paths = [
        ROOT / "paper" / name
        for name in sorted(PAPER_FILES)
        if name not in {f"{STEM}.pdf", "figures/observed-burden.png"}
    ]
    archive(
        DESTINATION / f"{STEM}_LaTeX.zip",
        [
            (
                f"{STEM}_LaTeX/{path.relative_to(ROOT / 'paper').as_posix()}",
                path.read_bytes(),
            )
            for path in latex_paths
        ],
    )
    shutil.copyfile(ROOT / "paper" / f"{STEM}.pdf", DESTINATION / f"{STEM}.pdf")
    shutil.copyfile(ROOT / "demo/index.html", DESTINATION / f"{STEM}.html")
    names = [
        f"{STEM}.pdf",
        f"{STEM}.html",
        f"{STEM}_Companion.zip",
        f"{STEM}_LaTeX.zip",
    ]
    identities = [
        {
            "file": name,
            "bytes": (DESTINATION / name).stat().st_size,
            "sha256": digest((DESTINATION / name).read_bytes()),
        }
        for name in names
    ]
    (DESTINATION / "SHA256SUMS").write_text(
        "".join(f"{row['sha256']}  {row['file']}\n" for row in identities)
    )
    print(
        json.dumps(
            {"archiveMembers": len(selected), "deliverables": identities}, indent=2
        )
    )


if __name__ == "__main__":
    main()
