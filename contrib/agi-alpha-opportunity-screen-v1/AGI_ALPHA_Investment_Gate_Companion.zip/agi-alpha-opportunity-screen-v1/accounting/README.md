# Accounting: measured discovery, HOLD

The record contains nine distinct scoped requests and eighteen operating evaluations of existing Alpha workflows. Their underlying public material overlaps. Eight scopes completed their **measured local delivery paths**: five foreground source-assurance scopes and three native catalogue scopes, including history checks. The remaining catalogue scope delivered its local artifacts and correctly refused the native path at its existing per-file size boundary. Foreground source assurance and native catalogue execution are distinct; neither classification implies production or authenticated operator execution. No customer sale, selected investment, untouched confirmation, economic promotion or financing cycle occurred.

## Reproduce the accounting

From the deliverable root, with Node available:

```bash
node accounting/build_accounting.mjs
```

An optional argument points to a different directory containing the original `source-profile` and `catalog-profile` evidence. The default is `companion/evidence`. The script reads the preserved discovery protocol from `analysis/discovery-protocol.json`. It writes accounting and analysis outputs beside itself; original evidence and vendored source are unchanged.

The two imported monetary modules are the existing `alpha-automated-costs/v1` and `alpha-shadow-ledger/v1` implementation at commit `496fa3c00dc7498173a896404ec756dfdeb94033`. `canonical-provenance.json` records their hashes. They are byte-identical to the source repository. This script supplies evidence and aggregates physical measurements; it does not implement another monetary calculator.

## Read the evidence

| File | What it records |
| --- | --- |
| `outcomes.json` | Nine scoped requests, eighteen evaluations, exact local outcome boundaries, timing ranges and references. |
| `resource-ledger.json` | Measured operating CPU and wall durations, failed setup, the existing Git alternative, and unmetered research categories. Overlapping wrapper totals are explicitly identified. |
| `cost-coverage.json` | Full cost inventory, including discovery, failed setup, instrumentation, verification, integration, reporting, residual attention, upkeep and overhead. Complete monetary amounts and conservative upper bounds remain unknown. |
| `shadow-ledger.json` | Canonical events for each distinct mission, ordered by first operating occurrence. They are retrospective study-accounting entries, not financial transactions. Commercial acceptance remains unknown. |
| `shadow-ledger-replay.json` | Canonical result: observed study collections are zero; full cost, reserves, obligations, surplus and eligible investment remain null. |
| `automated-costs-*.json` | Canonical whole-service cost inputs and evaluations. All mandatory stages are represented; unknown costs remain unknown. |
| `financing.json` | Zero authorized transaction cash, zero transaction and paid API caps, unknown actual enterprise cash/reserves/obligations, and no executed investment. |
| `investment-result.json` | Existing canonical investment function with unknown inputs and null payoff outputs. No unselected asset is assigned fictional savings. |

The canonical automated-cost schema requires the names `base`, `conservative` and `stress`. All three carry the same evidence gaps. They are not numerical scenarios chosen to produce repayment.

## Interpret the limits

Operating CPU is a physical measurement, not a bill. The eighteen selected evaluations consumed 86.592901984 CPU seconds in their recorded boundaries. Authoring, source retrieval, model use, manuscript work, review and other study processes are not all metered, so this is not the complete study resource total. Wall duration is not human attention. Recorded local process counts are not complete session tool counts. Fixed workflow provider-model calls were zero; research-model calls and tokens are unknown.

Ten initial source planning attempts and one initial catalogue setup attempt failed before completed delivery and are preserved separately. They are not additional operating evaluations or distinct missions. The larger catalogue's two native refusals are operating outcomes and remain within the eighteen evaluations.

The source `prior-versions` scope reports three changed paths in **each** of its two evaluations: `run-mission.mjs`, `run-mission.test.mjs` and `verify-run.py`. These are observed differences between immutable source versions. They are three distinct changed paths, not six independent changes. `sourceChangesObserved` and `changedPaths` now derive from the raw source results; catalogue conflicts have their own field. The profiling run did not mutate the frozen runtime checkouts or repair those version differences.

Shared research, instrumentation and reporting costs are nonzero work with unknown monetary value and allocation. They are not multiplied numerically by nine. Each mission's canonical cost fields are unknown placeholders. The study's zero collections do not establish the enterprise's bank balance. The zero authorized cash entry describes permission for this experiment; it does not invent seed capital.

The `analysis` directory contains the opportunity screen, native-size units adjudication, protocol interpretation, finite observed CPU upside envelopes and sourced human-work duration thresholds. The original protocol's `gate.material_burden_observed: true` is a **prospective admission requirement**, not a measured passed finding. `analysis/protocol-interpretation-adjudication.json` makes this distinction additive; the original protocol is unchanged. Local resource consumption was measured, but no economically material opportunity passed the selection gate. Every inspected mission is discovery data. Another economic attempt requires a new qualifying opportunity, complete cost bounds, defensible recurrence and fresh untouched confirmation work.
