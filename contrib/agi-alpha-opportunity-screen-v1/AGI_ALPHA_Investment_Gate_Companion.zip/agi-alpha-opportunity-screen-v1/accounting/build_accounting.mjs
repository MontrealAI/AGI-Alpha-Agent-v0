// SPDX-License-Identifier: Apache-2.0
// Evidence aggregation only. Monetary evaluation delegates to unchanged Alpha modules.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {AUTOMATED_COST_SCHEMA,AUTOMATED_STAGES,inspectAutomatedCosts,evaluateAutomatedCosts} from '../companion/vendor/alpha-integration/examples/successor-alpha/automated-costs.mjs';
import {SCHEMA,appendEvent,replayLedger,calculateInvestment} from '../companion/vendor/alpha-integration/examples/successor-alpha/shadow-ledger.mjs';

const out=path.dirname(fileURLToPath(import.meta.url));
const root=path.dirname(out), analysis=path.join(root,'analysis');
const evidence=path.resolve(process.argv[2]??path.join(root,'companion/evidence'));
const read=p=>JSON.parse(fs.readFileSync(path.join(evidence,p),'utf8'));
const write=(p,j)=>fs.writeFileSync(p,JSON.stringify(j,null,2)+'\n');
const sum=a=>a.reduce((x,y)=>x+y,0);
const stats=a=>({min:Math.min(...a),median:a.toSorted((x,y)=>x-y).reduce((x,y)=>x+y,0)/a.length,max:Math.max(...a)});
const sha=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
fs.mkdirSync(analysis,{recursive:true});
const source=read('source-profile/approved-process-run/results.json');
const sourceProcess=read('source-profile/approved-process-run/process-observations.json');
const sourceProtocol=read('source-profile/approved-process-run/protocol.json');
const failedSource=read('source-profile/process-observations.json');
const catalog=read('catalog-profile/summary.json');
const catalogProcess=read('catalog-profile/process-accounting.json');
const failedCatalog=read('catalog-profile/first-attempt-spawn-failure.json');
const alternatives=read('catalog-profile/existing-git-alternative.json');
const discoveryProtocol=JSON.parse(fs.readFileSync(path.join(analysis,'discovery-protocol.json'),'utf8'));
const runtimeBoundaryPath=path.join(analysis,'runtime-capability-boundaries.json');
const runtimeBoundaries=JSON.parse(fs.readFileSync(runtimeBoundaryPath,'utf8'));
if(runtimeBoundaries.observationClass!=='SOURCE_INSPECTION_ONLY')throw Error('Runtime boundary evidence must retain its source-inspection-only scope');
const moneyUnknown={value:null,basis:'unknown',reference:'No complete monetary meter, fixed-cost allocation or verified price; zero is not substituted.'};
const fact=(value,basis,reference)=>({value,basis,reference});
const unknown=reference=>fact(null,'unknown',reference);

const evaluations=[...catalog.runs.map((r,i)=>({id:`catalog-${r.task}-${r.repetition}`,missionId:`catalog-${r.task}`,family:'catalogue',scheduleOrdinal:i+1,
 startedAt:r.startedAt,finishedAt:r.finishedAt,wallSeconds:r.wallMs/1000,cpuSeconds:r.cpuMs/1000,
 localOutcome:r.outcome,fullMeasuredLocalPathComplete:r.nativeDelivery?.status==='pass',
 nativeCatalogueComplete:r.nativeDelivery?.status==='pass',foregroundSourceAssuranceComplete:null,catalogueComplete:r.browserDelivery.status==='pass',
 sourceChangesObserved:null,changedPaths:null,catalogueConflictsObserved:r.browserDelivery.conflicts,runtimeCheckoutMutated:false,
 failure:r.failure??null,customerAcceptance:null,fullMonetaryCost:null,source:`companion/evidence/catalog-profile/summary.json#runs/${i}`})),
 ...source.map((r,i)=>({id:`source-${r.id}`,missionId:`source-${r.scope}`,family:'source-assurance',scheduleOrdinal:i+1,
 startedAt:null,finishedAt:null,runStartedAt:sourceProtocol.startedUTC,wallSeconds:r.wallSeconds,cpuSeconds:r.cpuSeconds,
 localOutcome:'source-report-export-independent-local-check-reconnect-recheck',
 fullMeasuredLocalPathComplete:r.planPassed&&r.deliveryPassed&&r.independentVerificationPassed&&r.reconnectPassed&&r.postReconnectVerificationPassed,
 nativeCatalogueComplete:null,foregroundSourceAssuranceComplete:r.planPassed&&r.deliveryPassed&&r.independentVerificationPassed&&r.reconnectPassed&&r.postReconnectVerificationPassed,
 sourceChangesObserved:r.changedPaths.length,changedPaths:[...r.changedPaths],runtimeCheckoutMutated:false,
 failure:null,customerAcceptance:null,fullMonetaryCost:null,source:`companion/evidence/source-profile/approved-process-run/results.json#${i}`}))];
const missions=[...new Set(evaluations.map(e=>e.missionId))].map((id,i)=>{
 const es=evaluations.filter(e=>e.missionId===id),s=source.find(r=>`source-${r.scope}`===id),c=catalog.runs.find(r=>`catalog-${r.task}`===id);
 const changedPaths=s?[...new Set(es.flatMap(e=>e.changedPaths))]:null;
 return {id,firstOccurrenceOrdinal:i+1,family:es[0].family,evaluationIds:es.map(e=>e.id),evaluations:es.length,
  firstObservedTime:es[0].startedAt,runStartIfMissionTimeUnmetered:es[0].runStartedAt??null,
  sourceCount:s?.sourceCount??null,sourceBytes:s?.sourceBytes??null,rowsPerSide:c?.inputs.rows??null,inputBytesPerSide:c?.inputs.leftBytes??null,
  wallSeconds:stats(es.map(e=>e.wallSeconds)),cpuSeconds:stats(es.map(e=>e.cpuSeconds)),
  fullMeasuredLocalPathComplete:es.every(e=>e.fullMeasuredLocalPathComplete),
  foregroundSourceAssuranceComplete:s?es.every(e=>e.foregroundSourceAssuranceComplete):null,
  nativeCatalogueComplete:c?es.every(e=>e.nativeCatalogueComplete):null,
  catalogueOnlyOutcome:es.some(e=>e.catalogueComplete&&!e.nativeCatalogueComplete),
  sourceChangesObserved:changedPaths?.length??null,changedPaths,runtimeCheckoutMutated:false,
  sourceChangeMeaning:s?'Distinct paths reported changed between the immutable manifest versions, not edits made by the profiling run. Repeated observations do not multiply distinct changed paths.':null,
  catalogueConflictsObserved:c?.browserDelivery.conflicts??null,
  localCorrectness:s?'Existing foreground source-assurance report, export, local verification and reconnect checks passed. Reported source-version differences remain in changedPaths.':'Existing catalogue checks passed; native delivery and history checks passed only where nativeCatalogueComplete is true. Catalogue input identities match with zero conflicts.',
  customerAcceptance:null,commercialDemand:null,repeatCustomerDemand:null,completeMonetaryCost:null,
  gitCallsSourceDerived:s?.gitCallsSourceDerived??null,
  reference:es.map(e=>e.source)};
});
const completionCounts={fullMeasuredLocalPathCompleteScopedRequests:missions.filter(m=>m.fullMeasuredLocalPathComplete).length,
 foregroundSourceAssuranceCompleteScopedRequests:missions.filter(m=>m.foregroundSourceAssuranceComplete===true).length,
 nativeCatalogueCompleteScopedRequests:missions.filter(m=>m.nativeCatalogueComplete===true).length,
 catalogueOnlyNativeRefusedScopedRequests:missions.filter(m=>m.catalogueOnlyOutcome).length};
if(missions.length!==9||evaluations.length!==18||completionCounts.fullMeasuredLocalPathCompleteScopedRequests!==8||completionCounts.foregroundSourceAssuranceCompleteScopedRequests!==5||completionCounts.nativeCatalogueCompleteScopedRequests!==3||completionCounts.catalogueOnlyNativeRefusedScopedRequests!==1)throw Error('Unexpected evidence counts');
write(path.join(out,'outcomes.json'),{schema:'agi-alpha-discovery-outcomes/v1',decision:'HOLD',phase:'DISCOVERY',uniqueScopedRequests:9,
 operatingEvaluations:18,...completionCounts,customerSales:0,
 countDefinition:'Nine deliberately scoped requests with overlapping underlying material; timing repeats, source rows, assertions, exports, reconnects and work drafts are not independent jobs.',
 executionModeDefinition:'Eight complete measured local delivery paths comprise five foreground source-assurance scopes and three native catalogue/history scopes. No production or authenticated operator execution is implied.',
 sourceChangeDefinition:'Source-version differences are read from raw changedPaths. The prior-versions scope reports three distinct changed paths in each of its two evaluations. Frozen runtime checkouts were not mutated by profiling.',
 chronology:'Catalogue mission first occurrences have timestamps and precede the source-assurance run. Source mission order follows its recorded schedule; exact mission timestamps were not metered. Repetitions remain separate evaluations.',
 missions,evaluations,confirmationMissions:0,selectedAssets:0});

let ledger={schema:SCHEMA,currency:'USD',events:[]};
let serial=0;
const add=e=>{ledger=appendEvent(ledger,{id:`e${String(++serial).padStart(4,'0')}`,...e});};
for(const m of missions){
 const reference=`accounting/outcomes.json mission ${m.id}; local outcome only; commercial acceptance unknown; chronological order by first operating occurrence.`;
 add({type:'mission',missionId:m.id,acceptance:'unknown',reference});
 add({type:'revenue',missionId:m.id,category:'collected',amountMinor:0,basis:'observed',reference:'Study observation: no customer sale, invoice, receipt or transaction occurred. Zero study collections is not a statement about enterprise cash.'});
 add({type:'revenue',missionId:m.id,category:'price',amountMinor:null,basis:'unknown',reference:'No customer price or collection assumption assigned.'});
 for(const category of ['delivery','business','capability','maintenance'])add({type:'cost',missionId:m.id,category,amountMinor:null,basis:'unknown',reference:`accounting/cost-coverage.json; ${category} cost and shared discovery allocation are unknown. Includes nonzero authoring and screening work; unknown is not free.`});
 add({type:'reserve',missionId:m.id,category:'reliability',amountMinor:null,basis:'unknown',reference:'Enterprise reliability reserves are unknown; none invented or released.'});
 add({type:'obligation',missionId:m.id,category:'unpaid',amountMinor:null,basis:'unknown',reference:'Enterprise unpaid obligations are unknown; zero has not been assumed.'});
}
const replay=replayLedger(ledger,{reinvestmentBps:0});
if(replay.observed.revenue!==0||replay.observed.fullCost!==null||replay.observed.availableSurplus!==null)throw Error('Unknown propagation violated');
write(path.join(out,'shadow-ledger.json'),ledger);
write(path.join(out,'shadow-ledger-replay.json'),replay);
const investment=calculateInvestment({constructionCostMinor:null,failedConstructionCostMinor:null,maintenancePerReuseMinor:null,expectedSavingPerReuseMinor:null,remainingReuses:null});
write(path.join(out,'investment-result.json'),{decision:'HOLD',selectedCapability:null,constructionAttempts:0,confirmationEvaluations:0,
 reason:'No opportunity passed prospective selection; no investment executed. Discovery instrumentation and report authoring remain charged as unknown costs in cost-coverage.json.',canonicalResult:investment});
write(path.join(out,'financing.json'),{schema:'agi-alpha-study-financing-boundary/v1',currency:'USD',initialAuthorizedExperimentCash:0,
 liveTransactionCap:0,externalCommitmentsCap:0,paidApiCallCap:0,actualEnterpriseCash:null,actualEnterpriseObligations:null,actualEnterpriseReserves:null,
 studyCollections:0,studyCollectionsBasis:'Observed absence of customer sales and financial transactions; not a bank-attested enterprise balance.',
 modeledCollections:null,assumedPrice:null,demand:null,collectionRate:null,technicalBenefitOfNewAsset:null,economicBenefitAfterCompleteCosts:null,
 affordableConstruction:null,actualRealizedIncrementalCashFlow:null,canonicalAvailableSurplus:replay.observed.availableSurplus,
 canonicalEligibleInvestment:replay.observed.eligibleInvestment,investmentExecuted:false,secondCycleRun:false,decision:'HOLD',
 scope:'Preauthorized local infrastructure was used; its complete monetary allocation is unknown. Authorized transaction cash is a permission boundary, not a fabricated cash endowment. No financing cycle was simulated.'});

const ecec='https://www.bls.gov/news.release/ecec.t04.htm';
for(const [family,rate]of[['source-assurance',73690000],['catalogue',36730000]]){
 const record={schema:AUTOMATED_COST_SCHEMA,offeringId:`discovery-${family}`,currency:'USD',scenarios:['base','conservative','stress'].map(name=>({name,
 capacityRequestsPerMonth:unknown('No historical customer demand or monthly capacity evidence.'),utilizationBps:unknown('Discovery scopes do not estimate utilization.'),
 acceptanceBps:unknown('Local correctness is not commercial acceptance.'),attemptsPerRequestPpm:unknown('Two deliberate timing evaluations are not observed production retry frequency.'),
 operations:AUTOMATED_STAGES.map(stage=>({id:`${stage}-complete-cost`,stage,frequency:'request',unitsPerOccurrencePpm:unknown('Per-request service units and complete allocation unmetered.'),unitCostMicros:{...moneyUnknown},implementation:'implemented'})),
 residual:AUTOMATED_STAGES.map(stage=>({id:`${stage}-residual-attention`,stage,exceptionsPerRequestPpm:unknown('No measured exception frequency.'),minutesPerException:unknown('Human attention was not timed.'),hourlyCostMicros:unknown('No matching observed human-role billing rate.')})),
 monthly:['capacity','maintenance','business'].map(kind=>({id:`monthly-${kind}`,kind,amountMicros:{...moneyUnknown},allocationBps:unknown('Allocation depends on unknown real demand and obligations.')})),
 investments:[{id:'research-discovery-instrumentation',kind:'setup',amountMicros:unknown('Nonzero discovery, failed setup, protocol/instrumentation and acquisition work; monetary authoring meter unavailable.'),allocationBps:unknown('Allocation horizon not selected.'),amortizationMonths:unknown('No investment horizon passed gate.')},
 {id:'capability-construction-integration',kind:'development',amountMicros:unknown('No selected capability; no prospective complete construction bound.'),allocationBps:unknown('No selected capability.'),amortizationMonths:unknown('No selected horizon.')}],
 humanBaseline:{minutesPerAccepted:unknown('No matched traditional human-work duration; threshold analysis only.'),hourlyCostMicros:fact(rate,'sourced',`${ecec}; June 2026 private-industry occupation-group compensation; threshold anchor, not a matched task rate.`)}}))};
 inspectAutomatedCosts(record);write(path.join(out,`automated-costs-${family}.json`),record);write(path.join(out,`automated-costs-${family}-evaluated.json`),evaluateAutomatedCosts(record));
}
const sourceCpu=sum(source.map(r=>r.cpuSeconds)),sourceWall=sum(source.map(r=>r.wallSeconds));
const catCpu=sum(catalog.runs.map(r=>r.cpuMs/1000)),catWall=sum(catalog.runs.map(r=>r.wallMs/1000));
const resourceRows=[
 {id:'source-operating-evaluations',evaluations:10,cpuSeconds:sourceCpu,wallSecondsSum:sourceWall,source:'companion/evidence/source-profile/approved-process-run/results.json',boundary:'Five foreground source-assurance processes plus separately identified research packaging per evaluation; includes waited child CPU. This is not native catalogue or authenticated operator execution.'},
 {id:'catalog-operating-evaluations',evaluations:8,cpuSeconds:catCpu,wallSecondsSum:catWall,source:'companion/evidence/catalog-profile/summary.json',boundary:'Complete pipeline stages until success or explicit policy refusal.'},
 {id:'catalog-wrapper-total-overlaps-operating',evaluations:null,cpuSeconds:catalogProcess.childUserSeconds+catalogProcess.childSystemSeconds,wallSecondsSum:catalogProcess.wallSeconds,source:'companion/evidence/catalog-profile/process-accounting.json',boundary:'Includes catalogue operating evaluations and wrapper/preparation; DO NOT ADD to their CPU.'},
 {id:'source-failed-setup-plan-attempts',evaluations:0,attempts:failedSource.length,cpuSeconds:sum(failedSource.map(r=>r.cpuAndWaitedDescendantSeconds)),wallSecondsSum:sum(failedSource.map(r=>r.wallSeconds)),source:'companion/evidence/source-profile/process-observations.json',boundary:'Ten initial EPERM plan attempts; zero delivered evaluations; same five source scopes, no additional unique requests.'},
 {id:'catalog-failed-setup',evaluations:0,attempts:1,cpuSeconds:failedCatalog.childUserSeconds+failedCatalog.childSystemSeconds,wallSecondsSum:failedCatalog.wallSeconds,source:'companion/evidence/catalog-profile/first-attempt-spawn-failure.json',boundary:'Initial Git spawn EPERM before any workflow evaluation.'},
 {id:'existing-git-alternative-screen',evaluations:0,commands:alternatives.length,cpuSeconds:sum(alternatives.map(r=>r.cpuSeconds)),wallSecondsSum:sum(alternatives.map(r=>r.wallSeconds)),source:'companion/evidence/catalog-profile/existing-git-alternative.json',boundary:'Existing Git integrity-only alternative; lacks full Alpha deliverables/history and is not Control B.'}
];
write(path.join(out,'resource-ledger.json'),{schema:'agi-alpha-physical-resource-ledger/v1',monetaryTotal:null,
 operatingEvaluations:18,operatingCpuSeconds:sourceCpu+catCpu,operatingWallSecondsSum:sourceWall+catWall,
 elapsedStudyWallSeconds:null,reason:'Parallel run intervals and summed process durations do not equal total authoring or study elapsed time.',
 totalSessionModelCalls:null,totalSessionModelTokens:null,fixedWorkflowProviderModelCalls:0,totalSessionToolCalls:null,
 traceScope:'Recorded process receipts cover the selected local workflows only, not complete authoring/research/model/tool activity.',
 rows:resourceRows,unknownUncountedResources:['Root and delegated model authoring','Source retrieval and reading','Instrumentation authorship and revisions','Independent review','Paper, demo and package authoring','All other unmetered research processes'],
 allInPhysicalResourceTotal:null,allInMonetaryCost:null});

const costCategories=[
 ['discovery','Repository and prior-paper acquisition, source inspection, economic screening and alternative evaluation','Some fixed workflow measurements only; research and model usage unknown'],
 ['failed-setup','Ten source plan EPERM attempts, one catalogue Git-spawn failure, denied strace instrumentation','CPU and wall partly observed; denied trace cost and all authoring unknown'],
 ['instrumentation','Protocol, harness adaptation, resource accounting, checks and correction of measurement units','Nonzero work; tokens, labor and full compute allocation unknown'],
 ['construction','Selected productive asset construction','No candidate selected; zero construction attempts does not erase discovery costs'],
 ['verification','Substantive local checks, source checks, history validation and independent local script','Measured within workflows; author/reviewer attention and full monetary allocation unknown'],
 ['integration','Native workspace handoff/import, source integration and companion assembly','Workflow CPU observed; packaging/integration authorship unmetered'],
 ['operation','Execution, subprocesses, memory, storage, model/tool use and retained capability invocation','Operating CPU/wall observed; compute tariff and full allocated expense unknown'],
 ['correction-retry','Failed setup diagnosis, operational refusals and any further recovery','Failures preserved; production failure probability unknown'],
 ['packaging-reporting','Canonical artifacts, export, paper, bilingual demonstration and reproducible companion','Export CPU partly observed; publication/report authoring unknown'],
 ['residual-attention','Customer, operator and reviewer work','Unmetered; no wall duration converted to attention'],
 ['upkeep','Future dependency changes, revalidation, repair and maintenance shocks','No selected horizon or asset; unknown prospective cost'],
 ['business','Capacity reservation, security, support, depreciation and overhead','Unknown; not silently excluded'],
 ['financing','Obligations, reserves and collection friction','No sales; enterprise obligations/reserves unknown']
].map(([id,scope,measurement])=>({id,scope,measurement,monetaryCost:null,monetaryLowerBound:null,monetaryUpperBound:null}));
write(path.join(out,'cost-coverage.json'),{schema:'agi-alpha-full-cost-coverage/v1',allInCost:null,fullConservativeUpperBound:null,costCategories,
 conservativeTreatment:'No credible finite all-in monetary upper bound is available. The economic admission gate therefore fails; unknown authoring costs are not assigned zero or hidden by elapsed builder time.',
 sharedCostAllocation:'Research/instrumentation/report costs are shared study costs, not independent amounts multiplied by nine. Canonical per-mission cost fields are unknown placeholders; no numerical allocation has been fabricated.',
 threeCanonicalNames:'The existing schema requires base, conservative and stress. All three retain the same missing evidence. They are not a favorable numerical scenario sweep.',
 originalHoldsPreserved:true});

const ceilings=missions.map(m=>({missionId:m.id,observedCpuSeconds:m.cpuSeconds,
 maximumObservedWholePathCpuSeconds:m.cpuSeconds.max,computeUsdPerCpuHour:null,
 wholePathEliminationCoefficientCpuHours:m.cpuSeconds.max/3600,
 conditionalUpperEnvelope:`For this observed evaluation, even deleting all ${m.cpuSeconds.max} CPU seconds yields no more than (${m.cpuSeconds.max}/3600)*p USD of metered CPU expense, if p is USD per CPU hour and all that allocation is avoidable.`,
 observedIncrementalSaving:null,realisticReuses:null,constructionCostUpperBound:null,
 caveat:'Maximum among two observations is not a statistical population upper confidence bound. Whole-path deletion is deliberately unattainable as a useful service; this is an accounting ceiling, not a predicted optimization or measured gain.'}));
write(path.join(analysis,'upside-ceilings.json'),{schema:'agi-alpha-screening-upside-envelope/v1',purpose:'Algebraic screen only; no compute price, savings, useful demand or human attention benefit assumed.',rows:ceilings,
 selectionInequality:'A candidate needs N * lower_bound(accepted incremental benefit per reuse) > upper_bound(discovery + all construction approaches + verification + integration + upkeep + residual attention). Here N and both required monetary bounds are unknown.',
 financingCondition:'Separately, verified available cash after obligations and reserves must fund complete construction; permission to spend is also required.',
 uncertainty:'Low utilization or maintenance shocks cannot be quantified from this discovery sample. They cannot turn a missing lower benefit bound into evidence.'});
write(path.join(analysis,'human-work-thresholds.json'),{schema:'agi-alpha-human-comparison-thresholds/v1',equivalentAcceptedOutcomeRequired:true,
 observedHumanDurationMinutes:null,observedHumanComparatorCost:null,measuredCustomerAttentionMinutes:null,
 rates:[{occupationGroup:'Professional and related',totalCompensationUsdPerHourWorked:73.69,period:'June 2026',source:ecec,
  roleQualification:'Conditional source-assurance/review anchor; not a verified matching professional or contractor price.',minutesPerDollarThreshold:60/73.69},
 {occupationGroup:'Office and administrative support',totalCompensationUsdPerHourWorked:36.73,period:'June 2026',source:ecec,
  roleQualification:'Conditional catalogue administration anchor; use only if competent equivalent work truly has this occupational scope.',minutesPerDollarThreshold:60/36.73}],
 qaWageOnly:{annualMedianUsd:104300,period:'May 2025',source:'https://www.bls.gov/ooh/computer-and-information-technology/software-developers.htm',
  scope:'Software quality assurance analysts and testers. Annual wage, not total compensation, not contractor price, no task duration inferred.'},
 equations:{providerResourceComparison:'t_H* = 60 C_A / w_H; compare only equal accepted useful outcomes, with fully allocated Agent cost C_A.',
  customerComparison:'t_H* = (60 P + w_A h) / w_H, where P is service price, h is remaining customer minutes, and w_A is that customer time cost per hour.'},
 unknowns:{marginalAgentCost:null,recurringAgentCost:null,fullyLoadedAgentCost:null,providerPrice:null,customerAttention:null},
 conclusion:'No human-cost saving or customer-time saving established. Published occupation costs support transparent break-even thresholds only; favorable service economics would not establish a Flywheel.'});

const rejectionCommon={expectedRecurrence:null,constructionUpperBound:null,discoveryAndFailedSetupCostsIncluded:true,qualityAdmissionPassed:null,economicAdmissionPassed:false};
const candidates=[
 {id:'repeated-source-processes',claim:'Reduce repeated local source validation and process starts',...rejectionCommon,
 measuredBurden:missions.filter(m=>m.family==='source-assurance').map(m=>({missionId:m.id,cpuSeconds:m.cpuSeconds,wallSeconds:m.wallSeconds,sourceDerivedGitCalls:m.gitCallsSourceDerived?.total})),
 alternatives:['Use the actual source-assurance workflow with its retained assets','Batch immutable Git reads or retain validated evidence only if current semantics and freshness guarantees survive','Existing Git for simpler identity-only requests'],
 decision:'REJECT_FOR_PRIMARY_SELECTION',reason:'Real repeated work is observed, but complete work is small locally and no metered inference burden, recurring demand or finite all-in construction bound is established. A process-count reduction alone does not price a benefit.'},
 {id:'catalogue-history-revalidation',claim:'Reduce repeated semantic validation and history reopening',...rejectionCommon,
 measuredBurden:missions.filter(m=>m.family==='catalogue'&&m.nativeCatalogueComplete).map(m=>({missionId:m.id,cpuSeconds:m.cpuSeconds,wallSeconds:m.wallSeconds})),
 alternatives:['Preserve existing retained successor-tool and all native algorithms','Ordinary safe memoization under complete identity/freshness rules','Existing Git diff if only current tracked-file differences are required'],
 decision:'HOLD_UNQUALIFIED',reason:'The 787-row complete path has material local latency, with repeated validation dominant. No realistic reuse frequency, complete construction bound, paid acceptance or measured attention benefit establishes prospective repayment. No optimization constructed.'},
 {id:'large-native-catalogue-delivery',claim:'Enable a currently refused native delivery',...rejectionCommon,
 measuredBurden:{missionId:'catalog-package',evaluations:2,rows:1216,catalogueArtifactsDelivered:9,nativeFailure:'ARTIFACT_POLICY',joinedCsvUtf8Bytes:253267,joinedCsvJsUtf16CodeUnits:253263,nativeCodeUnitLimit:200000},
 alternatives:['Use the successful local catalogue outputs','Choose a smaller supported scope','A separately reviewed semantics-preserving partition adapter might retain existing limits, but its demand and cost remain unproven'],
 decision:'HOLD_PRESERVE_POLICY',reason:'Input and aggregate catalogue limits permit the local result, while native per-file policy refuses it. This is an intentional layer boundary. No authority to expand it or evidence of economically valuable recurrent native demand exists.'},
 {id:'trivial-parser-or-format',claim:'Optimize only parsing or format conversion',...rejectionCommon,measuredBurden:null,
 alternatives:['Existing parsers and complete-workflow helpers'],decision:'REJECT',reason:'No demonstrated material end-to-end burden attributable to a tiny parser or invented preparation step. Does not satisfy the value gate.'},
 {id:'inherited-specialist-as-new-investment',claim:'Reintroduce existing generated join specialist as a new investment',...rejectionCommon,measuredBurden:null,
 alternatives:['Keep the legitimate incumbent specialist in Control A','Permit the conventional builder equally strong existing tools'],decision:'REJECT',reason:'The incumbent already retains the executable specialist. Removal and reintroduction would fabricate an investment advantage; prior equal-outcome evidence remains adverse.'},
 {id:'repeated-paid-semantic-analysis',claim:'Avoid expensive repeated inference or failed analysis',...rejectionCommon,measuredBurden:null,
 alternatives:['Measure authorized production traces if separately available','Use supported fixed local workflows within present authorization'],decision:'HOLD_NO_EVIDENCE',reason:'Selected local workflows make zero provider-model calls. Research-model authoring remains unmetered. No legitimate paid semantic workload with recurrence and costs is available in this scope.'},
 {id:'recurring-repair-recovery',claim:'Reduce recurring repair, interruption or recovery expense',...rejectionCommon,
 observationClass:'SOURCE_INSPECTION_ONLY',evidence:{path:'analysis/runtime-capability-boundaries.json',sha256:sha(runtimeBoundaryPath),sourceRefs:runtimeBoundaries.recurringRepairRecovery.sourceRefs},
 measuredBurden:null,observedRecurringFailureRate:null,incrementalBenefit:null,attentionSaved:null,newWorkloadExecutions:0,
 existingCapability:'Source worker lease/checkpoint controls and the existing Repo-Healer triage, safe-patch, bounded-attempt, copied-workspace, validator and promotion path remain incumbent capabilities. Source inspection is not whole-workflow qualification.',
 alternatives:['Preserve and reconcile the existing source/recovery implementations through their current owners','Use the existing Repo-Healer path under its own authorization and qualification rather than constructing a duplicate','Measure legitimate recurring repair/interruption missions before selecting any new investment'],
 ownerRoutes:runtimeBoundaries.ownershipReferences.filter(r=>r.url.endsWith('/4907')||r.url.endsWith('/4915')),
 missingEvidence:runtimeBoundaries.recurringRepairRecovery.missingEvidence,
 decision:'HOLD_SOURCE_INSPECTION_ONLY',reason:'The measured discovery contains successful completed reconnects and initial setup EPERM failures, not a production failure population or recurring recoverable burden. No failure probability, avoided rework, attention saving or complete cost bound can be inferred. Existing owners and holds remain intact.'},
 {id:'richer-repository-work',claim:'Deliver and measure useful repository-scale analysis or repair',...rejectionCommon,
 observationClass:'SOURCE_INSPECTION_ONLY',evidence:{path:'analysis/runtime-capability-boundaries.json',sha256:sha(runtimeBoundaryPath),sourceRefs:runtimeBoundaries.richerRepositoryWork.sourceRefs},
 measuredBurden:null,observedRecurringFailureRate:null,incrementalBenefit:null,attentionSaved:null,newWorkloadExecutions:0,
 existingCapability:'The canonical Coding route handles bounded solve(*args) tasks and held-out cases. Repo-Healer already supports dry-run/report-only and bounded repair paths; it was source-inspected here, not exercised as a qualified complete useful repair workflow.',
 alternatives:runtimeBoundaries.richerRepositoryWork.existingAlternatives,
 ownerRoutes:runtimeBoundaries.ownershipReferences,
 missingCapabilityOrEvidence:runtimeBoundaries.richerRepositoryWork.missingCapabilityOrEvidence,
 isolationScope:'The inspected generated-code evaluation and DockerComputer paths have their own qualified-isolation/no-host-fallback rules. This is not an inferred universal Docker requirement for Repo-Healer. No held executor or workaround was run.',
 decision:'HOLD_SOURCE_INSPECTION_ONLY',reason:'Source inspection supplies no measured recurring analysis/correction burden, accepted repair population, complete provider/construction costs or incremental benefit. The existing repair implementation must be retained; a bounded solve-function contract alone does not establish an admitted immutable-repository snapshot/patch/review delivery path.'}
];
write(path.join(analysis,'opportunity-screen.json'),{schema:'agi-alpha-opportunity-screen/v1',decision:'DISCOVERY/HOLD',selectedOpportunity:null,
 primaryExperimentFrozen:false,confirmationStarted:false,allInspectedMissionsAreDiscovery:true,constructionAttempts:0,
 measurementSummary:{distinctScopedRequests:9,operatingEvaluations:18,...completionCounts,operatingCpuSeconds:sourceCpu+catCpu,
 sourceVersionDifferences:{scope:'source-prior-versions',distinctChangedPaths:missions.find(m=>m.id==='source-prior-versions').sourceChangesObserved,
  changedPaths:missions.find(m=>m.id==='source-prior-versions').changedPaths,observedInBothEvaluations:true,runtimeCheckoutMutated:false}},
 candidates,sourceInspectionBoundaryRecord:{path:'analysis/runtime-capability-boundaries.json',sha256:sha(runtimeBoundaryPath),observationClass:'SOURCE_INSPECTION_ONLY',additionalWorkloadExecutions:0},
 screenCoverageNote:'The two source-inspected directions make explicit the recurring repair/recovery and richer repository-work directions already discussed in the manuscript. This completion adds no measured workload, constructed asset or confirmation observation.',
 admissionGate:{actualIncumbentSourcesFrozen:true,incumbentToolsPreserved:true,localBurdenMeasured:true,
 economicallyMaterialQualifiedOpportunity:false,prospectiveProtocolInterpretation:'analysis/protocol-interpretation-adjudication.json',
 recurringDemandEstablished:false,completeConstructionUpperBoundEstablished:false,incrementalAcceptedBenefitLowerBoundEstablished:false,
 financesAvailableAfterObligationsAndReservesEstablished:false,qualityAndEconomicsAdmission:false},
 controls:{A:{status:'PREEXISTING_SOURCE_BASELINE_PROFILED',sourceRefs:[catalog.source,sourceProtocol.sourceRef],
 historicalBusinessOperatingBaselineMeasured:false,qualification:'Actual source and legitimate tools retained. These are deliberately run local workflows, not claimed historical customer operating records.'},
 B:{status:'NOT_CONSTRUCTED',reason:'Prospective gate failed before primary selection; no equally resourced builder experiment is falsely reported.',
 futureRule:'Use same model capability, evidence, quality criteria and total resource allowance; charge discovery, failed construction, integration and upkeep for both builders.'},
 alphaInvestment:{status:'NOT_CONSTRUCTED'},claimSeparation:'A win over A could prove a useful investment; only a comparable fully charged win over B could support a distinctive construction method.'},
 searchHistoryOrderDefinition:'Audit sequence of discovery phases, not fabricated cross-agent timestamps. Source and catalogue profiling overlapped. Within-run execution order and observed timestamps remain in the original evidence.',
 priorEditionConstraintsPreserved:['Equal accepted outcomes do not establish incremental production value.','Tiny local execution differences do not establish meaningful savings.','Assumed attention saving is not an observed benefit.','Elapsed builder time is not complete monetary construction cost.','A newly assembled comparator is not a measured historical operating baseline.','Higher common selling prices cannot rescue unestablished incremental benefit.'],
 searchHistory:[
 {order:1,phase:'Prior edition and ownership/source review',outcome:'Adverse prior findings preserved; current Alpha/Fleet/Jobs/Manager execution restrictions identified.',monetaryCost:null},
 {order:2,phase:'Bounded discovery protocol',evidence:'analysis/discovery-protocol.json',outcome:'No asset or confirmation frozen; zero paid calls and external transactions permitted.',monetaryCost:null},
 {order:3,phase:'Initial source instrumentation',evidence:'companion/evidence/source-profile/failure-adjudication.json',outcome:'Ten plan attempts failed with Git-spawn EPERM before delivery; retained. Tracing separately refused; no alternate tracer.',monetaryCost:null},
 {order:4,phase:'Initial catalogue instrumentation',evidence:'companion/evidence/catalog-profile/first-attempt-spawn-failure.json',outcome:'One early Git-spawn EPERM; no workflow output, preserved and charged as discovery.',monetaryCost:null},
 {order:5,phase:'Catalogue complete workflow screen',evidence:'companion/evidence/catalog-profile/summary.json',outcome:'Four real public inventory scopes, two evaluations each; three complete native outcomes and one deliberate native cap refusal.',monetaryCost:null},
 {order:6,phase:'Approved foreground source screen',evidence:'companion/evidence/source-profile/approved-process-run/results.json',outcome:'Five source scopes twice; all complete local report/export/reconnect checks passed.',monetaryCost:null},
 {order:7,phase:'Conventional existing-tool screen',evidence:'companion/evidence/catalog-profile/existing-git-alternative.json',outcome:'Git detects no changed tracked files quickly but offers narrower output; not substituted for equivalent Control B.',monetaryCost:null},
 {order:8,phase:'Independent measurement audit',evidence:'analysis/native-limit-adjudication.json',outcome:'Corrected byte versus UTF-16 unit label without altering raw evidence or refusal outcome.',monetaryCost:null},
 {order:9,phase:'Value gate and bounded stop',outcome:'No qualified opportunity. Stop economic construction; publish useful outputs, full uncertainty and reproducible discovery/HOLD. No exhausted paid budget or economic success asserted.',monetaryCost:null}
 ],
 stopDecision:{reason:'Measured local burdens exist, but the decisive complete-cost and realistic-reuse evidence is missing. More repetitions of the same inspected small workloads cannot repair those gates.',
 globalDiscoveryLimitSeconds:discoveryProtocol.global_discovery_limit_seconds,perProfileWallLimitSeconds:900,perProfileCpuLimitSeconds:600,
 allowedConstructionAttemptsIfGatePassed:2,usedConstructionAttempts:0,secondCycleJustified:false,
 exactEvidenceToResume:['Legitimate recurrent useful mission stream and customer acceptance criteria','Complete research/model/tool/compute and attention metering or defensible finite upper bounds','Realistic reuse horizon and marginal avoidable costs','Same-resource conventional builder control','New untouched confirmation missions','Financing facts after obligations and reserves, plus applicable spending authorization']},
 caveats:['Nine scopes overlap internally and do not measure nine independent customers.','Source assurance identified three existing version differences in the prior-versions scope, observed in both evaluations. Profiling did not mutate frozen runtime checkouts or perform source-change repairs.','Five foreground source-assurance scopes and three native catalogue/history scopes completed their respective measured local paths; these execution modes are distinct.','No independent recruited human panel or task-duration evidence.','Same-study local checks are not production independent-oracle acceptance.','Public outputs do not imply publication-owner approval or website publication.']});
write(path.join(analysis,'protocol-interpretation-adjudication.json'),{schema:'agi-alpha-protocol-interpretation-adjudication/v1',
 reviewFinding:'review/research-review.json#R4',originalProtocol:'analysis/discovery-protocol.json',originalProtocolSha256:sha(path.join(analysis,'discovery-protocol.json')),
 originalField:'gate.material_burden_observed',preservedOriginalValue:discoveryProtocol.gate.material_burden_observed,
 interpretation:'The original true value states a prospective admission requirement: a material burden must be observed before selecting an investment. It is not a recorded measured pass or a finding that an economically material opportunity was established.',
 measuredResult:{localResourceConsumptionObserved:true,economicallyMaterialQualifiedOpportunity:false,incrementalBenefitAfterCompleteCosts:null,qualityAndEconomicsAdmission:false},
 decision:'DISCOVERY/HOLD',selectedOpportunity:null,originalProtocolEdited:false,
 consequence:'Read the prospective gate alongside analysis/opportunity-screen.json. Measured local latency alone does not establish recurrence, complete costs or a positive incremental-value bound. The original protocol is preserved byte-for-byte.'});
write(path.join(analysis,'native-limit-adjudication.json'),{schema:'agi-alpha-measurement-adjudication/v1',originalEvidence:'companion/evidence/catalog-profile/opportunity-screen.json',
 originalLabel:'joined.csv253267characters',correction:{utf8Bytes:253267,jsUtf16CodeUnits:253263,limitJsUtf16CodeUnits:200000},
 cause:'UTF-8 byte count was mislabeled as characters; two U+2011 nonbreaking hyphens account for four additional UTF-8 bytes.',
 governingCheck:'artifact.content.length > 200000; native JavaScript content length is UTF-16 code units.',
 source:'https://github.com/MontrealAI/AGI-Alpha-Agent-v0/blob/3b040e68adae8196f7bda4c65f92af92ee6f7335/alpha_factory_v1/core/runtime/successor/workbench_worker.mjs#L2112',sourceLineAtFrozenCommit:2112,
 decisionUnchanged:'ARTIFACT_POLICY remains a correct refusal. Original evidence is preserved; this adjudication supersedes only the unit label.'});

const canonicalDir=path.join(root,'companion/vendor/alpha-integration/examples/successor-alpha');
write(path.join(out,'canonical-provenance.json'),{sourceRepository:'https://github.com/MontrealAI/AGI-Alpha-Agent-v0',sourceCommit:'496fa3c00dc7498173a896404ec756dfdeb94033',
 modules:['automated-costs.mjs','shadow-ledger.mjs'].map(name=>({path:`companion/vendor/alpha-integration/examples/successor-alpha/${name}`,sha256:sha(path.join(canonicalDir,name)),byteIdenticalRequired:true})),
 calculatorReimplementation:false,note:'This script aggregates measured physical resources and supplies unknown-bearing records to the existing canonical calculators. It introduces no alternate economic or financing model.'});
console.log(JSON.stringify({missions:missions.length,evaluations:evaluations.length,sourceCpuSeconds:sourceCpu,catalogueCpuSeconds:catCpu,operatingCpuSeconds:sourceCpu+catCpu,
 sourceMedianSeconds:missions.filter(m=>m.family==='source-assurance').map(m=>({id:m.id,cpu:m.cpuSeconds.median,wall:m.wallSeconds.median})),
 canonicalCollections:replay.observed.revenue,canonicalFullCost:replay.observed.fullCost,canonicalSurplus:replay.observed.availableSurplus,decision:'HOLD'}));
